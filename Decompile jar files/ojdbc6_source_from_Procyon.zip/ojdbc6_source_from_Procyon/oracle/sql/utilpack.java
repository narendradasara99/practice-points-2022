// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

class utilpack
{
    private static int INTYM3BYTE;
    private static int INTYM2BYTE;
    private static int INTYM1BYTE;
    
    protected static int LEFTSHIFTFIRSTNIBBLE(final byte b) {
        return (b & 0xFF) << utilpack.INTYM3BYTE;
    }
    
    protected static int LEFTSHIFTSECONDNIBBLE(final byte b) {
        return (b & 0xFF) << utilpack.INTYM2BYTE;
    }
    
    protected static int LEFTSHIFTTHIRDNIBBLE(final byte b) {
        return (b & 0xFF) << utilpack.INTYM1BYTE;
    }
    
    protected static byte RIGHTSHIFTFIRSTNIBBLE(final int n) {
        return (byte)(n >> utilpack.INTYM3BYTE & 0xFF);
    }
    
    protected static byte RIGHTSHIFTSECONDNIBBLE(final int n) {
        return (byte)(n >> utilpack.INTYM2BYTE & 0xFF);
    }
    
    protected static byte RIGHTSHIFTTHIRDNIBBLE(final int n) {
        return (byte)(n >> utilpack.INTYM1BYTE & 0xFF);
    }
    
    protected static byte RIGHTSHIFTFOURTHNIBBLE(final int n) {
        return (byte)(n & 0xFF);
    }
    
    static {
        utilpack.INTYM3BYTE = 24;
        utilpack.INTYM2BYTE = 16;
        utilpack.INTYM1BYTE = 8;
    }
}
