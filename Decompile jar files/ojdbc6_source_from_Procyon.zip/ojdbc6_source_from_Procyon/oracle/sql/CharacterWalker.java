// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import java.util.NoSuchElementException;

public final class CharacterWalker
{
    CharacterSet charSet;
    byte[] bytes;
    int next;
    int end;
    int shiftstate;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public CharacterWalker(final CharacterSet charSet, final byte[] bytes, final int next, final int n) {
        this.charSet = charSet;
        this.bytes = bytes;
        this.next = next;
        this.end = next + n;
        if (this.next < 0) {
            this.next = 0;
        }
        if (this.end > bytes.length) {
            this.end = bytes.length;
        }
    }
    
    public int nextCharacter() throws NoSuchElementException {
        try {
            return this.charSet.decode(this);
        }
        catch (SQLException ex) {
            throw new NoSuchElementException(ex.getMessage());
        }
    }
    
    public boolean hasMoreCharacters() {
        return this.next < this.end;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
