// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.internal.ObjectDataFactory;

public interface CustomDatumFactory extends ObjectDataFactory
{
    CustomDatum create(final Datum p0, final int p1) throws SQLException;
}
