// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeFLOAT;
import oracle.jdbc.oracore.OracleTypeNUMBER;
import java.sql.Array;
import oracle.jdbc.OraclePreparedStatement;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.sql.ResultSet;
import oracle.jdbc.OracleResultSet;
import java.util.Map;
import oracle.jdbc.oracore.OracleTypeREF;
import oracle.jdbc.oracore.OracleNamedType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCOLLECTION;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLException;
import java.sql.Connection;
import java.io.Serializable;

public class ArrayDescriptor extends TypeDescriptor implements Serializable
{
    public static final int TYPE_VARRAY = 3;
    public static final int TYPE_NESTED_TABLE = 2;
    public static final int CACHE_NONE = 0;
    public static final int CACHE_ALL = 1;
    public static final int CACHE_LAST = 2;
    static final long serialVersionUID = 3838105394346513809L;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static ArrayDescriptor createDescriptor(final String s, final Connection connection) throws SQLException {
        return createDescriptor(s, connection, false, false);
    }
    
    public static ArrayDescriptor createDescriptor(final String s, final Connection connection, final boolean b, final boolean b2) throws SQLException {
        if (s == null || s.length() == 0 || connection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 60, "ArrayDescriptor.createDescriptor: Invalid argument,'name' should not be an empty string and 'conn' should not be null.");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return createDescriptor(new SQLName(s, (oracle.jdbc.OracleConnection)connection), connection);
    }
    
    public static ArrayDescriptor createDescriptor(final SQLName sqlName, final Connection connection) throws SQLException {
        return createDescriptor(sqlName, connection, false, false);
    }
    
    public static ArrayDescriptor createDescriptor(final SQLName sqlName, final Connection connection, final boolean b, final boolean b2) throws SQLException {
        final String name = sqlName.getName();
        TypeDescriptor typeDescriptor = null;
        if (!b2) {
            typeDescriptor = (ArrayDescriptor)((oracle.jdbc.OracleConnection)connection).getDescriptor(name);
        }
        if (typeDescriptor == null) {
            typeDescriptor = new ArrayDescriptor(sqlName, connection);
            if (b) {
                typeDescriptor.initNamesRecursively();
            }
            ((oracle.jdbc.OracleConnection)connection).putDescriptor(name, typeDescriptor);
        }
        return (ArrayDescriptor)typeDescriptor;
    }
    
    public static ArrayDescriptor createDescriptor(final OracleTypeCOLLECTION oracleTypeCOLLECTION) throws SQLException {
        final String fullName = oracleTypeCOLLECTION.getFullName();
        final OracleConnection connection = oracleTypeCOLLECTION.getConnection();
        ArrayDescriptor arrayDescriptor = (ArrayDescriptor)connection.getDescriptor(fullName);
        if (arrayDescriptor == null) {
            arrayDescriptor = new ArrayDescriptor(new SQLName(oracleTypeCOLLECTION.getSchemaName(), oracleTypeCOLLECTION.getSimpleName(), oracleTypeCOLLECTION.getConnection()), oracleTypeCOLLECTION, connection);
            connection.putDescriptor(fullName, arrayDescriptor);
        }
        return arrayDescriptor;
    }
    
    public static ArrayDescriptor createDescriptor(final SQLName sqlName, final byte[] array, final int n, final byte[] array2, final OracleConnection oracleConnection) throws SQLException {
        final OracleTypeADT oracleTypeADT = new OracleTypeADT(sqlName, array, n, array2, oracleConnection);
        oracleTypeADT.init(array2, oracleConnection);
        return new ArrayDescriptor(sqlName, (OracleTypeCOLLECTION)oracleTypeADT.cleanup(), oracleConnection);
    }
    
    public ArrayDescriptor(final String s, final Connection connection) throws SQLException {
        super((short)122, s, connection);
        this.initPickler();
    }
    
    public ArrayDescriptor(final SQLName sqlName, final Connection connection) throws SQLException {
        super((short)122, sqlName, connection);
        this.initPickler();
    }
    
    public ArrayDescriptor(final SQLName sqlName, final OracleTypeCOLLECTION oracleTypeCOLLECTION, final Connection connection) throws SQLException {
        super((short)122, sqlName, oracleTypeCOLLECTION, connection);
    }
    
    public ArrayDescriptor(final OracleTypeCOLLECTION oracleTypeCOLLECTION, final Connection connection) throws SQLException {
        super((short)122, oracleTypeCOLLECTION, connection);
    }
    
    ArrayDescriptor(final byte[] toid, final int toidVersion, final Connection physicalConnectionOf) throws SQLException {
        super((short)122);
        this.toid = toid;
        this.toidVersion = toidVersion;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.initPickler();
    }
    
    public int getBaseType() throws SQLException {
        return ((OracleTypeCOLLECTION)this.pickler).getElementType().getTypeCode();
    }
    
    public String getBaseName() throws SQLException {
        String s = null;
        switch (this.getBaseType()) {
            case 12: {
                s = "VARCHAR";
                break;
            }
            case 1: {
                s = "CHAR";
                break;
            }
            case -2: {
                s = "RAW";
                break;
            }
            case 6: {
                s = "FLOAT";
                break;
            }
            case 2: {
                s = "NUMBER";
                break;
            }
            case 8: {
                s = "DOUBLE";
                break;
            }
            case 3: {
                s = "DECIMAL";
                break;
            }
            case 91: {
                s = "DATE";
                break;
            }
            case 93: {
                s = "TIMESTAMP";
                break;
            }
            case -101: {
                s = "TIMESTAMP WITH TIME ZONE";
                break;
            }
            case -102: {
                s = "TIMESTAMP WITH LOCAL TIME ZONE";
                break;
            }
            case 2004: {
                s = "BLOB";
                break;
            }
            case 2005: {
                s = "CLOB";
                break;
            }
            case -13: {
                s = "BFILE";
                break;
            }
            case 2002:
            case 2003:
            case 2007:
            case 2008: {
                s = ((OracleNamedType)((OracleTypeCOLLECTION)this.pickler).getElementType()).getFullName();
                break;
            }
            case 2006: {
                s = "REF " + ((OracleTypeREF)((OracleTypeCOLLECTION)this.pickler).getElementType()).getFullName();
                break;
            }
            default: {
                s = null;
                break;
            }
        }
        return s;
    }
    
    public OracleTypeCOLLECTION getOracleTypeCOLLECTION() {
        return (OracleTypeCOLLECTION)this.pickler;
    }
    
    public int getArrayType() throws SQLException {
        return ((OracleTypeCOLLECTION)this.pickler).getUserCode();
    }
    
    public long getMaxLength() throws SQLException {
        return (this.getArrayType() == 3) ? ((OracleTypeCOLLECTION)this.pickler).getMaxLength() : 0L;
    }
    
    public String descType() throws SQLException {
        return this.descType(new StringBuffer(), 0);
    }
    
    String descType(final StringBuffer sb, final int n) throws SQLException {
        String string = "";
        for (int i = 0; i < n; ++i) {
            string += "  ";
        }
        final String string2 = string + "  ";
        sb.append(string);
        sb.append(this.getTypeName());
        sb.append("\n");
        final int baseType = this.getBaseType();
        if (baseType == 2002 || baseType == 2008) {
            StructDescriptor.createDescriptor(this.getBaseName(), this.connection).descType(sb, n + 1);
        }
        else if (baseType == 2003) {
            createDescriptor(this.getBaseName(), this.connection).descType(sb, n + 1);
        }
        else if (baseType == 2007) {
            OpaqueDescriptor.createDescriptor(this.getBaseName(), this.connection).descType(sb, n + 1);
        }
        else {
            sb.append(string2);
            sb.append(this.getBaseName());
            sb.append("\n");
        }
        return sb.substring(0, sb.length());
    }
    
    int toLength(final ARRAY array) throws SQLException {
        if (array.numElems == -1) {
            if (array.datumArray != null) {
                array.numElems = array.datumArray.length;
            }
            else if (array.objArray != null) {
                if (array.objArray instanceof Object[]) {
                    array.numElems = ((Object[])array.objArray).length;
                }
                else if (array.objArray instanceof int[]) {
                    array.numElems = ((long[])array.objArray).length;
                }
                else if (array.objArray instanceof long[]) {
                    array.numElems = ((float[])array.objArray).length;
                }
                else if (array.objArray instanceof float[]) {
                    array.numElems = ((double[])array.objArray).length;
                }
                else if (array.objArray instanceof double[]) {
                    array.numElems = ((boolean[])array.objArray).length;
                }
                else if (array.objArray instanceof boolean[]) {
                    array.numElems = ((int[])array.objArray).length;
                }
                else if (array.objArray instanceof byte[]) {
                    array.numElems = ((byte[])array.objArray).length;
                }
                else if (array.objArray instanceof short[]) {
                    array.numElems = ((short[])array.objArray).length;
                }
                else if (array.objArray instanceof char[]) {
                    array.numElems = ((char[])array.objArray).length;
                }
            }
            else if (array.locator != null) {
                array.numElems = this.toLengthFromLocator(array.locator);
            }
            else {
                if (array.shareBytes() == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Array is in inconsistent status");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.pickler.unlinearize(array.shareBytes(), array.imageOffset, array, 0, null);
                if (array.numElems == -1) {
                    if (array.locator == null) {
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Unable to get array length");
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                    array.numElems = this.toLengthFromLocator(array.locator);
                }
            }
        }
        return array.numElems;
    }
    
    byte[] toBytes(final ARRAY array, final boolean b) throws SQLException {
        byte[] array2 = array.shareBytes();
        if (array2 == null) {
            if (array.datumArray != null || array.locator != null) {
                array2 = this.pickler.linearize(array);
                if (!b) {
                    array.setShareBytes(null);
                }
            }
            else {
                if (array.objArray == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Array is in inconsistent status");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                array.datumArray = this.toOracleArray(array.objArray, 1L, -1);
                array2 = this.pickler.linearize(array);
                if (!b) {
                    array.datumArray = null;
                    array.setShareBytes(null);
                }
            }
        }
        else if (array.imageLength != 0L && (array.imageOffset != 0L || array.imageLength != array2.length)) {
            final byte[] array3 = new byte[(int)array.imageLength];
            System.arraycopy(array2, (int)array.imageOffset, array3, 0, (int)array.imageLength);
            array.setImage(array3, 0L, 0L);
            return array3;
        }
        return array2;
    }
    
    Datum[] toOracleArray(final ARRAY array, final long n, final int n2, final boolean b) throws SQLException {
        final Datum[] datumArray = array.datumArray;
        Datum[] datumArray2;
        if (datumArray == null) {
            if (array.objArray != null) {
                datumArray2 = this.toOracleArray(array.objArray, n, n2);
            }
            else if (array.locator != null) {
                datumArray2 = this.toOracleArrayFromLocator(array.locator, n, n2, null);
            }
            else {
                if (array.shareBytes() == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Array is in inconsistent status.");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.pickler.unlinearize(array.shareBytes(), array.imageOffset, array, n, n2, 1, null);
                if (array.locator != null) {
                    datumArray2 = this.toOracleArrayFromLocator(array.locator, n, n2, null);
                }
                else {
                    datumArray2 = array.datumArray;
                }
                if (!b) {
                    array.datumArray = null;
                }
            }
        }
        else {
            if (n > datumArray.length) {
                return new Datum[0];
            }
            final int n3 = (int)((n2 == -1) ? (datumArray.length - n + 1L) : Math.min(datumArray.length - n + 1L, n2));
            datumArray2 = new Datum[n3];
            System.arraycopy(array.datumArray, (int)n - 1, datumArray2, 0, n3);
        }
        Datum[] array2;
        if (b) {
            array.datumArray = datumArray2;
            array2 = datumArray2.clone();
        }
        else {
            array2 = datumArray2;
        }
        return array2;
    }
    
    Object[] toJavaArray(final ARRAY array, final long n, final int n2, final Map map, final boolean b) throws SQLException {
        Object[] array2;
        if (array.objArray != null) {
            final int length = ((Object[])array.objArray).clone().length;
            final int n3 = (int)((n2 == -1) ? (length - n + 1L) : Math.min(length - n + 1L, n2));
            if (n3 <= 0) {
                return makeJavaArray(n3, this.getBaseType());
            }
            array2 = makeJavaArray(n3, this.getBaseType());
            System.arraycopy(array.objArray, (int)n - 1, array2, 0, n3);
        }
        else {
            if (array.datumArray != null) {
                array2 = (Object[])this.toJavaArray(array.datumArray, n, n2, map);
            }
            else if (array.locator != null) {
                array2 = this.toArrayFromLocator(array.locator, n, n2, map);
            }
            else {
                if (array.shareBytes() == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Array is in inconsistent status");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.pickler.unlinearize(array.shareBytes(), array.imageOffset, array, n, n2, 2, map);
                if (array.locator != null) {
                    array2 = this.toArrayFromLocator(array.locator, n, n2, map);
                }
                else {
                    array2 = (Object[])array.objArray;
                }
            }
            if (b && this.getBaseType() != 2002 && this.getBaseType() != 2008 && array2 != null) {
                array.objArray = array2.clone();
            }
            else {
                array.objArray = null;
            }
        }
        return array2;
    }
    
    private Datum[] toOracleArrayFromLocator(final byte[] array, final long n, final int n2, final Map map) throws SQLException {
        final int lengthFromLocator = this.toLengthFromLocator(array);
        final int n3 = (int)((n2 == -1) ? (lengthFromLocator - n + 1L) : Math.min(lengthFromLocator - n + 1L, n2));
        Datum[] array2;
        if (n3 <= 0) {
            array2 = new Datum[0];
        }
        else {
            array2 = new Datum[n3];
            final ResultSet resultSetFromLocator = this.toResultSetFromLocator(array, n, n2, map);
            int n4 = 0;
            while (resultSetFromLocator.next()) {
                array2[n4] = ((OracleResultSet)resultSetFromLocator).getOracleObject(2);
                ++n4;
            }
            resultSetFromLocator.close();
        }
        return array2;
    }
    
    private Object[] toArrayFromLocator(final byte[] array, final long n, final int n2, final Map map) throws SQLException {
        final int lengthFromLocator = this.toLengthFromLocator(array);
        final int n3 = (int)((n2 == -1) ? (lengthFromLocator - n + 1L) : Math.min(lengthFromLocator - n + 1L, n2));
        Object[] array2;
        if (n3 <= 0) {
            array2 = makeJavaArray(0, this.getBaseType());
        }
        else {
            array2 = makeJavaArray(n3, this.getBaseType());
            final ResultSet resultSetFromLocator = this.toResultSetFromLocator(array, n, n2, map);
            int n4 = 0;
            while (resultSetFromLocator.next()) {
                array2[n4] = ((OracleResultSet)resultSetFromLocator).getObject(2, map);
                ++n4;
            }
            resultSetFromLocator.close();
        }
        return array2;
    }
    
    public ResultSet toResultSet(final ARRAY array, final long n, final int n2, final Map map, final boolean b) throws SQLException {
        ResultSet set = null;
        if (array.datumArray != null) {
            set = this.toResultSet(array.datumArray, n, n2, map);
        }
        else if (array.locator != null) {
            set = this.toResultSetFromLocator(array.locator, n, n2, map);
        }
        else if (array.objArray != null) {
            set = this.toResultSet(this.toOracleArray(array.objArray, n, n2), 1L, -1, map);
        }
        else if (array.shareBytes() != null) {
            if (((OracleTypeCOLLECTION)this.pickler).isInlineImage(array.shareBytes(), (int)array.imageOffset)) {
                set = this.toResultSetFromImage(array, n, n2, map);
            }
            else {
                this.pickler.unlinearize(array.shareBytes(), array.imageOffset, array, 1, null);
                if (array.locator == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Array is in inconsistent status");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                set = this.toResultSetFromLocator(array.locator, n, n2, map);
            }
        }
        if (set == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Unable to create array ResultSet");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return set;
    }
    
    public ResultSet toResultSet(final Datum[] array, final long n, final int n2, final Map map) throws SQLException {
        ResultSet set;
        if (n2 == -1) {
            set = this.connection.newArrayDataResultSet(array, n, array.length, map);
        }
        else {
            set = this.connection.newArrayDataResultSet(array, n, n2, map);
        }
        return set;
    }
    
    public ResultSet toResultSetFromLocator(final byte[] array, final long n, final int n2, final Map map) throws SQLException {
        return this.connection.newArrayLocatorResultSet(this, array, n, n2, map);
    }
    
    public ResultSet toResultSetFromImage(final ARRAY array, final long n, final int n2, final Map map) throws SQLException {
        return this.connection.newArrayDataResultSet(array, n, n2, map);
    }
    
    public static Object[] makeJavaArray(final int n, final int i) throws SQLException {
        Object o = null;
        switch (i) {
            case -7:
            case -6:
            case -5:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7: {
                o = new BigDecimal[n];
                break;
            }
            case 1:
            case 12: {
                o = new String[n];
                break;
            }
            case -102:
            case -101:
            case 91:
            case 92:
            case 93: {
                o = new Timestamp[n];
                break;
            }
            case 2002:
            case 2008: {
                o = new Object[n];
                break;
            }
            case -13: {
                o = new BFILE[n];
                break;
            }
            case 2004: {
                o = new BLOB[n];
                break;
            }
            case 2005: {
                o = new CLOB[n];
                break;
            }
            case -3:
            case -2: {
                o = new byte[n][];
                break;
            }
            case 2006: {
                o = new REF[n];
                break;
            }
            case 2003: {
                o = new Object[n];
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 1, "makeJavaArray doesn't support type " + i);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return (Object[])o;
    }
    
    private int toLengthFromLocator(final byte[] locator) throws SQLException {
        final ARRAY array = new ARRAY(this, this.connection, null);
        array.setLocator(locator);
        final OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)this.connection.prepareStatement("SELECT count(*) FROM TABLE( CAST(:1 AS " + this.getName() + ") )");
        oraclePreparedStatement.setArray(1, array);
        final OracleResultSet set = (OracleResultSet)oraclePreparedStatement.executeQuery();
        if (set.next()) {
            final int int1 = set.getInt(1);
            set.close();
            oraclePreparedStatement.close();
            return int1;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Fail to access array storage table");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    Datum[] toOracleArray(final Object o, final long n, final int n2) throws SQLException {
        Datum[] datumArray = null;
        if (o != null) {
            datumArray = this.getElementType().toDatumArray(o, this.connection, n, n2);
        }
        return datumArray;
    }
    
    private Object toJavaArray(final Datum[] array, final long n, final int n2, final Map map) throws SQLException {
        int n3 = (int)((n2 == -1) ? (array.length - n + 1L) : Math.min(array.length - n + 1L, n2));
        if (n3 < 0) {
            n3 = 0;
        }
        final Object[] array2 = makeJavaArray(n3, this.getBaseType());
        if (this.getBaseType() == 2002) {
            for (int i = 0; i < n3; ++i) {
                final STRUCT struct = (STRUCT)array[(int)n + i - 1];
                array2[i] = ((struct != null) ? struct.toJdbc(map) : null);
            }
        }
        else {
            for (int j = 0; j < n3; ++j) {
                final Datum datum = array[(int)n + j - 1];
                array2[j] = ((datum != null) ? datum.toJdbc() : null);
            }
        }
        return array2;
    }
    
    private Object toNumericArray(final Datum[] array, final long n, final int n2, final int n3) throws SQLException {
        int n4 = (int)((n2 == -1) ? (array.length - n + 1L) : Math.min(array.length - n + 1L, n2));
        if (n4 < 0) {
            n4 = 0;
        }
        int[] array3 = null;
        switch (n3) {
            case 4: {
                final int[] array2 = new int[n4];
                for (int i = 0; i < n4; ++i) {
                    final Datum datum = array[(int)n + i - 1];
                    if (datum != null) {
                        array2[i] = datum.intValue();
                    }
                }
                array3 = array2;
                break;
            }
            case 5: {
                final double[] array4 = new double[n4];
                for (int j = 0; j < n4; ++j) {
                    final Datum datum2 = array[(int)n + j - 1];
                    if (datum2 != null) {
                        array4[j] = datum2.doubleValue();
                    }
                }
                array3 = (int[])array4;
                break;
            }
            case 6: {
                final float[] array5 = new float[n4];
                for (int k = 0; k < n4; ++k) {
                    final Datum datum3 = array[(int)n + k - 1];
                    if (datum3 != null) {
                        array5[k] = datum3.floatValue();
                    }
                }
                array3 = (int[])array5;
                break;
            }
            case 7: {
                final long[] array6 = new long[n4];
                for (int l = 0; l < n4; ++l) {
                    final Datum datum4 = array[(int)n + l - 1];
                    if (datum4 != null) {
                        array6[l] = datum4.longValue();
                    }
                }
                array3 = (int[])array6;
                break;
            }
            case 8: {
                final short[] array7 = new short[n4];
                for (int n5 = 0; n5 < n4; ++n5) {
                    final Datum datum5 = array[(int)n + n5 - 1];
                    if (datum5 != null) {
                        array7[n5] = ((NUMBER)datum5).shortValue();
                    }
                }
                array3 = (int[])array7;
                break;
            }
            default: {
                final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
                unsupportedFeatureSqlException.fillInStackTrace();
                throw unsupportedFeatureSqlException;
            }
        }
        return array3;
    }
    
    private Object toNumericArrayFromLocator(final byte[] array, final long n, final int n2, final int n3) throws SQLException {
        final int lengthFromLocator = this.toLengthFromLocator(array);
        final ResultSet resultSetFromLocator = this.toResultSetFromLocator(array, n, n2, null);
        int n4 = 0;
        int[] array3 = null;
        switch (n3) {
            case 4: {
                int[] array2;
                for (array2 = new int[lengthFromLocator]; resultSetFromLocator.next() && n4 < lengthFromLocator; array2[n4++] = ((OracleResultSet)resultSetFromLocator).getInt(2)) {}
                resultSetFromLocator.close();
                array3 = array2;
                break;
            }
            case 5: {
                double[] array4;
                for (array4 = new double[lengthFromLocator]; resultSetFromLocator.next() && n4 < lengthFromLocator; array4[n4++] = ((OracleResultSet)resultSetFromLocator).getDouble(2)) {}
                resultSetFromLocator.close();
                array3 = (int[])array4;
                break;
            }
            case 6: {
                float[] array5;
                for (array5 = new float[lengthFromLocator]; resultSetFromLocator.next() && n4 < lengthFromLocator; array5[n4++] = ((OracleResultSet)resultSetFromLocator).getFloat(2)) {}
                resultSetFromLocator.close();
                array3 = (int[])array5;
                break;
            }
            case 7: {
                long[] array6;
                for (array6 = new long[lengthFromLocator]; resultSetFromLocator.next() && n4 < lengthFromLocator; array6[n4++] = ((OracleResultSet)resultSetFromLocator).getLong(2)) {}
                resultSetFromLocator.close();
                array3 = (int[])array6;
                break;
            }
            case 8: {
                short[] array7;
                for (array7 = new short[lengthFromLocator]; resultSetFromLocator.next() && n4 < lengthFromLocator; array7[n4++] = ((OracleResultSet)resultSetFromLocator).getShort(2)) {}
                resultSetFromLocator.close();
                array3 = (int[])array7;
                break;
            }
            default: {
                final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
                unsupportedFeatureSqlException.fillInStackTrace();
                throw unsupportedFeatureSqlException;
            }
        }
        return array3;
    }
    
    Object toNumericArray(final ARRAY array, final long n, final int n2, final int n3, final boolean b) throws SQLException {
        final OracleType elementType = this.getElementType();
        if (!(elementType instanceof OracleTypeNUMBER) && !(elementType instanceof OracleTypeFLOAT)) {
            final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
            unsupportedFeatureSqlException.fillInStackTrace();
            throw unsupportedFeatureSqlException;
        }
        Object o = null;
        if (array.objArray != null) {
            if (n3 == 4 && array.objArray instanceof int[]) {
                final int length = ((int[])array.objArray).length;
                if (n > length) {
                    return new int[0];
                }
                final int n4 = (int)((n2 == -1) ? (length - n + 1L) : Math.min(length - n + 1L, n2));
                final int[] array2 = new int[n4];
                System.arraycopy(array.objArray, (int)n - 1, array2, 0, n4);
                o = array2;
            }
            else if (n3 == 5 && array.objArray instanceof double[]) {
                final int length2 = ((double[])array.objArray).length;
                if (n > length2) {
                    return new double[0];
                }
                final int n5 = (int)((n2 == -1) ? (length2 - n + 1L) : Math.min(length2 - n + 1L, n2));
                final double[] array3 = new double[n5];
                System.arraycopy(array.objArray, (int)n - 1, array3, 0, n5);
                o = array3;
            }
            else if (n3 == 6 && array.objArray instanceof float[]) {
                final int length3 = ((float[])array.objArray).length;
                if (n > length3) {
                    return new float[0];
                }
                final int n6 = (int)((n2 == -1) ? (length3 - n + 1L) : Math.min(length3 - n + 1L, n2));
                final float[] array4 = new float[n6];
                System.arraycopy(array.objArray, (int)n - 1, array4, 0, n6);
                o = array4;
            }
            else if (n3 == 7 && array.objArray instanceof long[]) {
                final int length4 = ((long[])array.objArray).length;
                if (n > length4) {
                    return new long[0];
                }
                final int n7 = (int)((n2 == -1) ? (length4 - n + 1L) : Math.min(length4 - n + 1L, n2));
                final long[] array5 = new long[n7];
                System.arraycopy(array.objArray, (int)n - 1, array5, 0, n7);
                o = array5;
            }
            else if (n3 == 8 && array.objArray instanceof short[]) {
                final int length5 = ((short[])array.objArray).length;
                if (n > length5) {
                    return new short[0];
                }
                final int n8 = (int)((n2 == -1) ? (length5 - n + 1L) : Math.min(length5 - n + 1L, n2));
                final short[] array6 = new short[n8];
                System.arraycopy(array.objArray, (int)n - 1, array6, 0, n8);
                o = array6;
            }
        }
        else {
            if (array.datumArray != null) {
                o = this.toNumericArray(array.datumArray, n, n2, n3);
            }
            else if (array.locator != null) {
                o = this.toNumericArrayFromLocator(array.locator, n, n2, n3);
            }
            else {
                if (array.shareBytes() == null) {
                    final SQLException unsupportedFeatureSqlException2 = DatabaseError.createUnsupportedFeatureSqlException();
                    unsupportedFeatureSqlException2.fillInStackTrace();
                    throw unsupportedFeatureSqlException2;
                }
                this.pickler.unlinearize(array.shareBytes(), array.imageOffset, array, n, n2, n3, null);
                if (array.locator != null) {
                    o = this.toNumericArrayFromLocator(array.locator, n, n2, n3);
                }
                else {
                    o = array.objArray;
                }
            }
            if (!b) {
                array.objArray = null;
            }
        }
        return o;
    }
    
    private void initPickler() throws SQLException {
        try {
            final OracleTypeADT oracleTypeADT = new OracleTypeADT(this.getName(), (Connection)this.connection);
            oracleTypeADT.init(this.connection);
            this.pickler = oracleTypeADT.cleanup();
            this.toid = ((OracleTypeADT)this.pickler).getTOID();
            this.pickler.setDescriptor(this);
        }
        catch (Exception ex) {
            if (ex instanceof SQLException) {
                throw (SQLException)ex;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Unable to resolve type: \"" + this.getName() + "\"");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    private OracleType getElementType() throws SQLException {
        return ((OracleTypeCOLLECTION)this.pickler).getElementType();
    }
    
    @Override
    public int getTypeCode() throws SQLException {
        return 2003;
    }
    
    public byte[] toBytes(final Datum[] array) throws SQLException {
        return this.pickler.linearize(new ARRAY(this, this.connection, array));
    }
    
    public byte[] toBytes(final Object[] array) throws SQLException {
        return this.toBytes(this.toArray(array));
    }
    
    public int length(final byte[] array) throws SQLException {
        return this.toLength(new ARRAY(this, this.connection, array));
    }
    
    public Datum[] toArray(final byte[] array) throws SQLException {
        Datum[] oracleArray = null;
        if (array != null) {
            oracleArray = this.toOracleArray(new ARRAY(this, this.connection, array), 1L, -1, false);
        }
        return oracleArray;
    }
    
    public Datum[] toArray(final Object o) throws SQLException {
        return this.toOracleArray(o, 1L, -1);
    }
    
    public ResultSet toResultSet(final byte[] array, final Map map) throws SQLException {
        ResultSet resultSet = null;
        if (array != null) {
            resultSet = this.toResultSet((ARRAY)this.pickler.unlinearize(array, 0L, null, 1, null), 1L, -1, map, false);
        }
        return resultSet;
    }
    
    public ResultSet toResultSet(final byte[] array, final long n, final int n2, final Map map) throws SQLException {
        ResultSet resultSet = null;
        if (array != null) {
            resultSet = this.toResultSet((ARRAY)this.pickler.unlinearize(array, 0L, null, 1, null), n, n2, map, false);
        }
        return resultSet;
    }
    
    @Override
    String tagName() {
        return "ArrayDescriptor";
    }
    
    public static int getCacheStyle(final ARRAY array) throws SQLException {
        int n = 2;
        if (array.getAutoIndexing() && (array.getAccessDirection() == 2 || array.getAccessDirection() == 3)) {
            n = 1;
        }
        return n;
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
