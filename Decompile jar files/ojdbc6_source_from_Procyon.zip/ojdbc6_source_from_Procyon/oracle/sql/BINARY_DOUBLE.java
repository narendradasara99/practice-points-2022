// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.math.BigDecimal;
import java.sql.SQLException;

public class BINARY_DOUBLE extends Datum
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public BINARY_DOUBLE() {
    }
    
    public BINARY_DOUBLE(final byte[] array) {
        super(array);
    }
    
    public BINARY_DOUBLE(final double n) {
        super(doubleToCanonicalFormatBytes(n));
    }
    
    public BINARY_DOUBLE(final Double n) {
        super(doubleToCanonicalFormatBytes(n));
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return new Double(canonicalFormatBytesToDouble(this.getBytes()));
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.lang.String") == 0 || name.compareTo("java.lang.Double") == 0;
    }
    
    @Override
    public String stringValue() {
        return Double.toString(canonicalFormatBytesToDouble(this.getBytes()));
    }
    
    @Override
    public double doubleValue() throws SQLException {
        return canonicalFormatBytesToDouble(this.getBytes());
    }
    
    @Override
    public BigDecimal bigDecimalValue() throws SQLException {
        return new BigDecimal(canonicalFormatBytesToDouble(this.getBytes()));
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Double[n];
    }
    
    static byte[] doubleToCanonicalFormatBytes(final double n) {
        double value = n;
        if (value == 0.0) {
            value = 0.0;
        }
        else if (value != value) {
            value = Double.NaN;
        }
        final long doubleToLongBits = Double.doubleToLongBits(value);
        final byte[] array = new byte[8];
        final int n2 = (int)doubleToLongBits;
        final int n3 = (int)(doubleToLongBits >> 32);
        int n4 = n2;
        int n7;
        int n6;
        int n5 = (n6 = (n7 = n2 >> 8) >> 8) >> 8;
        int n8 = n3;
        int n11;
        int n10;
        final int n9 = (n10 = (n11 = n3 >> 8) >> 8) >> 8;
        int n12;
        if ((n9 & 0x80) == 0x0) {
            n12 = (n9 | 0x80);
        }
        else {
            n12 = ~n9;
            n10 ^= -1;
            n11 ^= -1;
            n8 ^= -1;
            n5 ^= -1;
            n6 ^= -1;
            n7 ^= -1;
            n4 ^= -1;
        }
        array[7] = (byte)n4;
        array[6] = (byte)n7;
        array[5] = (byte)n6;
        array[4] = (byte)n5;
        array[3] = (byte)n8;
        array[2] = (byte)n11;
        array[1] = (byte)n10;
        array[0] = (byte)n12;
        return array;
    }
    
    static double canonicalFormatBytesToDouble(final byte[] array) {
        final byte b = array[0];
        final byte b2 = array[1];
        final byte b3 = array[2];
        final byte b4 = array[3];
        final byte b5 = array[4];
        final byte b6 = array[5];
        final byte b7 = array[6];
        final byte b8 = array[7];
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        if ((b & 0x80) != 0x0) {
            n = (b & 0x7F);
            n2 = (b2 & 0xFF);
            n3 = (b3 & 0xFF);
            n4 = (b4 & 0xFF);
            n5 = (b5 & 0xFF);
            n6 = (b6 & 0xFF);
            n7 = (b7 & 0xFF);
            n8 = (b8 & 0xFF);
        }
        else {
            n = (~b & 0xFF);
            n2 = (~b2 & 0xFF);
            n3 = (~b3 & 0xFF);
            n4 = (~b4 & 0xFF);
            n5 = (~b5 & 0xFF);
            n6 = (~b6 & 0xFF);
            n7 = (~b7 & 0xFF);
            n8 = (~b8 & 0xFF);
        }
        return Double.longBitsToDouble((long)(n << 24 | n2 << 16 | n3 << 8 | n4) << 32 | ((long)(n5 << 24 | n6 << 16 | n7 << 8 | n8) & 0xFFFFFFFFL));
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
