// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.RowId;
import java.sql.SQLXML;
import java.sql.NClob;
import java.net.URL;
import java.sql.Array;
import java.sql.Struct;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Ref;
import java.sql.SQLData;
import java.io.InputStream;
import java.io.IOException;
import oracle.jdbc.driver.DatabaseError;
import java.io.Reader;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import java.sql.SQLOutput;

public class OracleSQLOutput implements SQLOutput
{
    private StructDescriptor descriptor;
    private Object[] attributes;
    private int index;
    private OracleConnection conn;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleSQLOutput(final StructDescriptor descriptor, final OracleConnection conn) throws SQLException {
        this.descriptor = descriptor;
        this.attributes = new Object[descriptor.getLength()];
        this.conn = conn;
        this.index = 0;
    }
    
    public STRUCT getSTRUCT() throws SQLException {
        return new STRUCT(this.descriptor, this.conn, this.attributes);
    }
    
    @Override
    public void writeString(final String s) throws SQLException {
        this.attributes[this.index++] = s;
    }
    
    @Override
    public void writeBoolean(final boolean b) throws SQLException {
        this.attributes[this.index++] = b;
    }
    
    @Override
    public void writeByte(final byte i) throws SQLException {
        this.attributes[this.index++] = i;
    }
    
    @Override
    public void writeShort(final short i) throws SQLException {
        this.attributes[this.index++] = i;
    }
    
    @Override
    public void writeInt(final int i) throws SQLException {
        this.attributes[this.index++] = i;
    }
    
    @Override
    public void writeLong(final long value) throws SQLException {
        this.attributes[this.index++] = new Long(value);
    }
    
    @Override
    public void writeFloat(final float value) throws SQLException {
        this.attributes[this.index++] = new Float(value);
    }
    
    @Override
    public void writeDouble(final double value) throws SQLException {
        this.attributes[this.index++] = new Double(value);
    }
    
    @Override
    public void writeBigDecimal(final BigDecimal bigDecimal) throws SQLException {
        this.attributes[this.index++] = bigDecimal;
    }
    
    @Override
    public void writeBytes(final byte[] array) throws SQLException {
        this.attributes[this.index++] = array;
    }
    
    @Override
    public void writeDate(final Date date) throws SQLException {
        this.attributes[this.index++] = date;
    }
    
    @Override
    public void writeTime(final Time time) throws SQLException {
        this.attributes[this.index++] = time;
    }
    
    @Override
    public void writeTimestamp(final Timestamp timestamp) throws SQLException {
        this.attributes[this.index++] = timestamp;
    }
    
    @Override
    public void writeCharacterStream(final Reader reader) throws SQLException {
        final StringBuffer sb = new StringBuffer();
        final char[] array = new char[100];
        try {
            int read;
            while ((read = reader.read(array)) != -1) {
                sb.append(array, 0, read);
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.attributes[this.index++] = sb.substring(0, sb.length());
    }
    
    @Override
    public void writeAsciiStream(final InputStream inputStream) throws SQLException {
        final StringBuffer sb = new StringBuffer();
        final byte[] b = new byte[100];
        final char[] str = new char[100];
        try {
            int read;
            while ((read = inputStream.read(b)) != -1) {
                for (int i = 0; i < read; ++i) {
                    str[i] = (char)b[i];
                }
                sb.append(str, 0, read);
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.attributes[this.index++] = sb.substring(0, sb.length());
    }
    
    @Override
    public void writeBinaryStream(final InputStream inputStream) throws SQLException {
        this.writeAsciiStream(inputStream);
    }
    
    @Override
    public void writeObject(final SQLData sqlData) throws SQLException {
        STRUCT struct = null;
        if (sqlData != null) {
            final SQLOutput jdbc2SQLOutput = StructDescriptor.createDescriptor(sqlData.getSQLTypeName(), this.conn).toJdbc2SQLOutput();
            sqlData.writeSQL(jdbc2SQLOutput);
            struct = ((OracleSQLOutput)jdbc2SQLOutput).getSTRUCT();
        }
        this.writeStruct(struct);
    }
    
    public void writeObject(final Object o) throws SQLException {
        if (o != null && o instanceof SQLData) {
            this.writeObject((SQLData)o);
        }
        else {
            this.attributes[this.index++] = o;
        }
    }
    
    @Override
    public void writeRef(final Ref ref) throws SQLException {
        this.attributes[this.index++] = ref;
    }
    
    @Override
    public void writeBlob(final Blob blob) throws SQLException {
        this.attributes[this.index++] = blob;
    }
    
    @Override
    public void writeClob(final Clob clob) throws SQLException {
        this.attributes[this.index++] = clob;
    }
    
    @Override
    public void writeStruct(final Struct struct) throws SQLException {
        this.attributes[this.index++] = struct;
    }
    
    @Override
    public void writeArray(final Array array) throws SQLException {
        this.attributes[this.index++] = array;
    }
    
    public void writeOracleObject(final Datum datum) throws SQLException {
        this.attributes[this.index++] = datum;
    }
    
    public void writeRef(final REF ref) throws SQLException {
        this.attributes[this.index++] = ref;
    }
    
    public void writeBlob(final BLOB blob) throws SQLException {
        this.attributes[this.index++] = blob;
    }
    
    public void writeBfile(final BFILE bfile) throws SQLException {
        this.attributes[this.index++] = bfile;
    }
    
    public void writeClob(final CLOB clob) throws SQLException {
        this.attributes[this.index++] = clob;
    }
    
    public void writeStruct(final STRUCT struct) throws SQLException {
        this.attributes[this.index++] = struct;
    }
    
    public void writeArray(final ARRAY array) throws SQLException {
        this.attributes[this.index++] = array;
    }
    
    public void writeNUMBER(final NUMBER number) throws SQLException {
        this.attributes[this.index++] = number;
    }
    
    public void writeCHAR(final CHAR char1) throws SQLException {
        this.attributes[this.index++] = char1;
    }
    
    public void writeDATE(final DATE date) throws SQLException {
        this.attributes[this.index++] = date;
    }
    
    public void writeRAW(final RAW raw) throws SQLException {
        this.attributes[this.index++] = raw;
    }
    
    public void writeROWID(final ROWID rowid) throws SQLException {
        this.attributes[this.index++] = rowid;
    }
    
    @Override
    public void writeURL(final URL url) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void writeNClob(final NClob nClob) throws SQLException {
        this.writeClob(nClob);
    }
    
    @Override
    public void writeNString(final String s) throws SQLException {
        this.writeString(s);
    }
    
    @Override
    public void writeSQLXML(final SQLXML sqlxml) throws SQLException {
        this.writeObject(sqlxml);
    }
    
    @Override
    public void writeRowId(final RowId rowId) throws SQLException {
        this.writeROWID((ROWID)rowId);
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
