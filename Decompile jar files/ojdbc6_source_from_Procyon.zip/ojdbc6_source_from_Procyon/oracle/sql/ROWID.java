// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import java.sql.RowId;

public class ROWID extends Datum implements RowId
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public ROWID() {
    }
    
    public ROWID(final byte[] array) {
        super(array);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    @Override
    public String stringValue() {
        final byte[] bytes = this.getBytes();
        return new String(bytes, 0, 0, bytes.length);
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new byte[n][];
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
