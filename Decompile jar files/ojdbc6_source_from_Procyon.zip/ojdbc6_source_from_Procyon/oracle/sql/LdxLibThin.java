// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.text.DateFormatSymbols;
import java.util.Locale;
import java.sql.SQLException;
import oracle.core.lmx.CoreException;

class LdxLibThin implements LdxLib
{
    private static final int LDXFDLSZ = 50;
    private static final byte LDX_CC = 1;
    private static final byte LDX_SCC = 2;
    private static final byte LDX_I = 3;
    private static final byte LDX_Y = 4;
    private static final byte LDX_IY = 5;
    private static final byte LDX_YY = 6;
    private static final byte LDX_IYY = 7;
    private static final byte LDX_YYY = 8;
    private static final byte LDX_IYYY = 9;
    private static final byte LDX_YYYY = 10;
    private static final byte LDX_YCYYY = 11;
    private static final byte LDX_SYYYY = 12;
    private static final byte LDX_SYCYYY = 13;
    private static final byte LDX_YEAR = 14;
    private static final byte LDX_SYEAR = 15;
    private static final byte LDX_Q = 16;
    private static final byte LDX_MM = 17;
    private static final byte LDX_IW = 18;
    private static final byte LDX_WW = 19;
    private static final byte LDX_W = 20;
    private static final byte LDX_D = 21;
    private static final byte LDX_DD = 22;
    private static final byte LDX_DDD = 23;
    private static final byte LDX_HH24 = 24;
    private static final byte LDX_HH = 25;
    private static final byte LDX_MI = 26;
    private static final byte LDX_SS = 27;
    private static final byte LDX_SSSSS = 28;
    private static final byte LDX_J = 29;
    private static final byte LDX_MONTH = 30;
    private static final byte LDX_MON = 31;
    private static final byte LDX_DAY = 32;
    private static final byte LDX_DY = 33;
    private static final byte LDX_AMPM = 34;
    private static final byte LDX_A_M_P_M = 35;
    private static final byte LDX_BCAD = 36;
    private static final byte LDX_B_C_A_D = 37;
    private static final byte LDX_RM = 38;
    private static final byte LDX_FM = 39;
    private static final byte LDX_RR = 40;
    private static final byte LDX_RRRR = 41;
    private static final byte LDX_FX = 42;
    private static final byte LDX_E = 43;
    private static final byte LDX_EE = 44;
    private static final byte LDX_LIT = 45;
    private static final byte LDX_JUS = 16;
    private static final byte LDX_NTH = 1;
    private static final byte LDX_SPL = 2;
    private static final byte LDX_CAP = 4;
    private static final byte LDX_UPR = 8;
    private static final byte LDX_QUO = 1;
    private static final byte LDX_SPA = 2;
    private static final byte LDX_PUN = 4;
    private static final byte LDX_ALPHA = Byte.MIN_VALUE;
    private static final byte LDXFNJUS = 64;
    private static final byte LDX_NEG = 32;
    private static final byte LDX_COMMA = 16;
    private static final byte LDX_LEN = 15;
    private static final byte LDXFL_NOT = 0;
    private static final byte LDXFL_FLEX = 1;
    private static final byte LDXFL_STD = 2;
    private static final byte LDXFL_MDONE = 4;
    private static final byte LDXFL_YDONE = 8;
    private static final byte LDXFL_PUNC = 16;
    private static final byte LDXFL_MSEC = 32;
    private static final int LDXSBUFFERSIZE = 64;
    private static final int LDXWBUFSIZE = 64;
    private static final int LDXTCE = 0;
    private static final int LDXTYE = 1;
    private static final int LDXTMO = 2;
    private static final int LDXTDA = 3;
    private static final int LDXTHO = 4;
    private static final int LDXTMI = 5;
    private static final int LDXTSO = 6;
    private static final int LDXTSIZ = 7;
    private static final int LDX_SUNDAY = 2445029;
    private static final int LDXPMXYR = 9999;
    private static final int LDXPMNYR = -4712;
    private static final char[][] ldxfda;
    private static final byte[] ldxfdc;
    private static final byte[] ldxfcdlen;
    private static int[] ldxfdi;
    private static final char[][] ldxfdx;
    private static final byte[] ldxfdxc;
    private static final byte[] NULLFMT;
    private static final byte[] DEFAULT_FORMAT;
    private static final String[] ldxpaa;
    private static final int[] ldxdom;
    private final byte[][] ldxpmxa;
    
    LdxLibThin() {
        this.ldxpmxa = new byte[][] { { 23, 29 }, { 4, 6, 8, 10, 12, 11, 13 }, { 25, 24 }, { 34, 35 }, { 36, 37 }, { 30, 31, 17, 38 }, { 32, 33, 21 }, { 34, 35, 24 }, { 12, 13, 36, 37 } };
    }
    
    @Override
    public byte[] ldxadm(final byte[] array, int n) throws SQLException {
        final int n2 = ((array[0] & 0xFF) - 100) * 100 + ((array[1] & 0xFF) - 100);
        final int n3 = array[2] & 0xFF;
        final int n4 = array[3] & 0xFF;
        n += (array[2] & 0xFF) + n2 * 12;
        int n5;
        if (n > 0) {
            if ((n5 = n / 12) > 9999) {
                throw new SQLException(CoreException.getMessage((byte)8));
            }
            if ((n %= 12) == 0) {
                --n5;
                n = 12;
            }
        }
        else {
            if ((n5 = n / 12 - 1) < -4712) {
                throw new SQLException(CoreException.getMessage((byte)8));
            }
            n = n % 12 + 12;
        }
        final int n6 = (n == 2 && this.ldxisl(n2)) ? 29 : (LdxLibThin.ldxdom[n3 + 1] - LdxLibThin.ldxdom[n3]);
        array[0] = (byte)(n5 / 100 + 100);
        array[1] = (byte)(n5 % 100 + 100);
        array[2] = (byte)n;
        final int n7 = (n == 2 && this.ldxisl(n5)) ? 29 : (LdxLibThin.ldxdom[n + 1] - LdxLibThin.ldxdom[n]);
        array[3] = (byte)((n4 == n6 || n4 > n7) ? n7 : n4);
        return array;
    }
    
    @Override
    public byte[] ldxads(byte[] ldxjtc, int n, int n2) throws SQLException {
        if (n2 != 0) {
            n2 += ((ldxjtc[4] - 1) * 60 + (ldxjtc[5] - 1)) * 60 + (ldxjtc[6] - 1);
            n += n2 / 86400;
            if ((n2 %= 86400) < 0) {
                n2 += 86400;
                --n;
            }
            ldxjtc[4] = (byte)(n2 / 3600 + 1);
            ldxjtc[5] = (byte)(n2 % 3600 / 60 + 1);
            ldxjtc[6] = (byte)(n2 % 3600 % 60 + 1);
        }
        final int n3 = ((ldxjtc[0] & 0xFF) - 100) * 100 + ((ldxjtc[1] & 0xFF) - 100);
        if (n != 0) {
            n += this.ldxctj(n3, ldxjtc[2], ldxjtc[3]);
            if (n < 1) {
                throw new SQLException(CoreException.getMessage((byte)8));
            }
            ldxjtc = this.ldxjtc(n, ldxjtc);
        }
        if (((ldxjtc[0] & 0xFF) - 100) * 100 + ((ldxjtc[1] & 0xFF) - 100) > 9999) {
            throw new SQLException(CoreException.getMessage((byte)8));
        }
        return ldxjtc;
    }
    
    @Override
    public int ldxchk(final byte[] array) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxdfd(final int n, final int n2) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public void ldxdtd(final byte[] array, final int[] array2, final int[] array3) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public String ldxdts(final byte[] array, final String s, final String s2) throws SQLException {
        return this.ldxdts(array, this.ldxsto(s, s2), s2);
    }
    
    @Override
    public String ldxdts(final byte[] array, byte[] default_FORMAT, final String s) throws SQLException {
        int i = 0;
        int endIndex = 0;
        String s2 = null;
        final StringBuffer sb = new StringBuffer(64);
        if (default_FORMAT.length == 0 || default_FORMAT == null || (default_FORMAT[0] == 0 && default_FORMAT[1] == 16)) {
            default_FORMAT = LdxLibThin.DEFAULT_FORMAT;
        }
        final int length = default_FORMAT.length;
        Locale locale;
        if (s != null && s.compareTo("") != 0) {
            endIndex = s.indexOf("_");
            if (endIndex == -1) {
                locale = LxMetaData.getJavaLocale(s, "");
            }
            else {
                locale = LxMetaData.getJavaLocale(s.substring(0, endIndex), s.substring(endIndex + 1));
            }
            if (locale == null) {
                locale = Locale.getDefault();
            }
        }
        else {
            locale = Locale.getDefault();
        }
        final int n = ((array[0] & 0xFF) - 100) * 100 + ((array[1] & 0xFF) - 100);
        while (i < length) {
            int n2 = default_FORMAT[i++];
            final byte b = default_FORMAT[i++];
            if (n2 == 0) {
                break;
            }
            if (n2 >= 45) {
                final int length2 = n2 - 45;
                sb.append(new String(default_FORMAT, i, length2));
                i += length2;
            }
            else {
                byte b2 = LdxLibThin.ldxfcdlen[n2];
                StringBuffer sb2;
                if (((b2 & 0xFFFFFF80) != 0x0 && (b & 0xC) != 0x0) || ((b & 0x10) != 0x0 && (b2 & 0x40) == 0x0) || ((b & 0xC) != 0x0 && (b & 0x3) != 0x0)) {
                    sb2 = new StringBuffer(64);
                }
                else {
                    sb2 = sb;
                }
                switch (n2) {
                    case 37: {
                        if (locale.getCountry().compareTo("US") == 0 && locale.getLanguage().compareTo("en") == 0) {
                            s2 = ((array[0] < 100) ? LdxLibThin.ldxpaa[2] : LdxLibThin.ldxpaa[0]);
                            break;
                        }
                        --n2;
                    }
                    case 36: {
                        sb2.append(new DateFormatSymbols(locale).getEras()[array[0] >= 100]);
                        sb2.length();
                        break;
                    }
                    case 35: {
                        if (locale.getCountry().compareTo("US") == 0 && locale.getLanguage().compareTo("en") == 0) {
                            s2 = ((array[4] - 1 >= 12) ? LdxLibThin.ldxpaa[3] : LdxLibThin.ldxpaa[1]);
                            break;
                        }
                        --n2;
                    }
                    case 34: {
                        sb2.append(new DateFormatSymbols(locale).getAmPmStrings()[array[4] - 1 >= 12]);
                        sb2.length();
                        break;
                    }
                    case 29: {
                        endIndex = this.ldxctj(n, array[2], array[3]);
                        break;
                    }
                    case 21: {
                        endIndex = this.ldxdow(n, array[2], array[3], locale);
                        break;
                    }
                    case 32:
                    case 33: {
                        int ldxdow = this.ldxdow(n, array[2], array[3], locale);
                        if (Calendar.getInstance(locale).getFirstDayOfWeek() > 1) {
                            ++ldxdow;
                        }
                        if (ldxdow > 7) {
                            ldxdow -= 7;
                        }
                        if (ldxdow == 0) {
                            ++ldxdow;
                        }
                        String[] array2;
                        if (n2 == 32) {
                            array2 = new DateFormatSymbols(locale).getWeekdays();
                        }
                        else {
                            array2 = new DateFormatSymbols(locale).getShortWeekdays();
                        }
                        sb2.append(array2[ldxdow]);
                        sb2.length();
                        break;
                    }
                    case 1:
                    case 2: {
                        final int n3;
                        if ((n3 = n) > 0) {
                            endIndex = (n3 - 1) / 100 + 1;
                            break;
                        }
                        endIndex = -((-1 - n3) / 100) - 1;
                        break;
                    }
                    case 22: {
                        endIndex = array[3];
                        break;
                    }
                    case 43:
                    case 44: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 24:
                    case 25: {
                        endIndex = array[4] - 1;
                        if (n2 == 25) {
                            endIndex = ((endIndex > 12) ? (endIndex - 12) : ((endIndex == 0) ? 12 : endIndex));
                            break;
                        }
                        break;
                    }
                    case 26: {
                        endIndex = array[5] - 1;
                        break;
                    }
                    case 16: {
                        endIndex = (array[2] + 2) / 3;
                        break;
                    }
                    case 17: {
                        endIndex = array[2];
                        break;
                    }
                    case 30:
                    case 31: {
                        endIndex = array[2];
                        String[] array3;
                        if (n2 == 30) {
                            array3 = new DateFormatSymbols(locale).getMonths();
                        }
                        else {
                            array3 = new DateFormatSymbols(locale).getShortMonths();
                        }
                        sb2.append(array3[--endIndex]);
                        sb2.length();
                        break;
                    }
                    case 38: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 27: {
                        endIndex = array[6] - 1;
                        break;
                    }
                    case 28: {
                        endIndex = ((array[4] - 1) * 60 + (array[5] - 1)) * 60 + (array[6] - 1);
                        break;
                    }
                    case 20: {
                        endIndex = (array[3] + 6) / 7;
                        break;
                    }
                    case 23: {
                        endIndex = this.ldxcty(n, array[2], array[3]);
                        break;
                    }
                    case 18: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 19: {
                        endIndex = (this.ldxcty(n, array[2], array[3]) + 6) / 7;
                        break;
                    }
                    case 3: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 4: {
                        endIndex = n % 10;
                        break;
                    }
                    case 5: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 6:
                    case 40: {
                        endIndex = n % 100;
                        break;
                    }
                    case 7: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 8: {
                        endIndex = n % 1000;
                        break;
                    }
                    case 10:
                    case 11:
                    case 12:
                    case 13:
                    case 41: {
                        endIndex = n;
                        break;
                    }
                    case 9: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 14:
                    case 15: {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    case 42: {
                        continue;
                    }
                    default: {
                        throw new SQLException(CoreException.getMessage((byte)7));
                    }
                }
                if ((b2 & 0xFFFFFF80) == 0x0) {
                    if ((b2 & 0x20) == 0x0) {
                        if (endIndex < 0) {
                            endIndex = -endIndex;
                        }
                    }
                    else if (endIndex >= 0) {
                        sb2.insert(0, " ");
                        --b2;
                    }
                    if ((b & 0x2) != 0x0) {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                    int n4;
                    if ((b & 0x10) != 0x0) {
                        n4 = (b2 & 0xF);
                    }
                    else {
                        n4 = 0;
                    }
                    sb2.append(this.lxi42b(64, endIndex, n4, (b2 & 0x10) != 0x0, locale));
                    if ((b & 0x1) != 0x0) {
                        throw new SQLException(CoreException.getMessage((byte)1));
                    }
                }
                else if ((b & 0x10) != 0x0 && (b2 & 0x40) == 0x0) {
                    String[] array4 = null;
                    switch (n2) {
                        case 33: {
                            array4 = new DateFormatSymbols(locale).getShortWeekdays();
                            break;
                        }
                        case 32: {
                            array4 = new DateFormatSymbols(locale).getWeekdays();
                            break;
                        }
                        case 31: {
                            array4 = new DateFormatSymbols(locale).getShortMonths();
                            break;
                        }
                        case 30: {
                            array4 = new DateFormatSymbols(locale).getMonths();
                            break;
                        }
                        default: {
                            throw new SQLException(CoreException.getMessage((byte)7));
                        }
                    }
                    int n5 = 0;
                    for (int j = 0; j < array4.length; ++j) {
                        endIndex = array4[j].length();
                        if (endIndex > n5) {
                            n5 = endIndex;
                        }
                    }
                    for (int n6 = n5 - sb2.length(), k = 0; k < n6; ++k) {
                        sb2.append(" ");
                    }
                }
                if (s2 != null) {
                    if ((b & 0xC) == 0x0) {
                        sb2 = sb;
                    }
                    sb2.append(s2.toLowerCase(locale));
                    s2 = null;
                }
                if ((b & 0x4) != 0x0) {
                    if (Character.isLowerCase(sb2.charAt(0))) {
                        sb2.setCharAt(0, Character.toUpperCase(sb2.charAt(0)));
                    }
                    sb.append(sb2.toString());
                }
                else if ((b & 0x8) != 0x0) {
                    sb.append(sb2.toString().toUpperCase());
                }
                else {
                    if (sb2 == sb) {
                        continue;
                    }
                    sb.append(sb2.toString());
                }
            }
        }
        return sb.toString();
    }
    
    private int ldxdow(final int n, final int n2, final int n3, final Locale aLocale) {
        int n4 = (this.ldxctj(n, n2, n3) - (2445029 + (Calendar.getInstance(aLocale).getFirstDayOfWeek() - 1))) % 7;
        if (n4 < 0) {
            n4 += 7;
        }
        return n4 + 1;
    }
    
    private int ldxctj(final int n, final int n2, final int n3) {
        int n4;
        if (n == -4712) {
            n4 = 0;
        }
        else {
            final int n5 = n + 4712;
            n4 = 365 * n5 + (n5 - 1) / 4;
        }
        if (n >= 1583) {
            n4 = n4 - 10 - (n - 1501) / 100 + (n - 1201) / 400;
        }
        int n6 = n4 + this.ldxcty(n, n2, n3);
        if (n == 1582 && ((n2 == 10 && n3 >= 15) || n2 >= 11)) {
            n6 -= 10;
        }
        return n6;
    }
    
    private byte[] ldxjtc(int n, byte[] array) throws SQLException {
        if (n < 1) {
            throw new SQLException(CoreException.getMessage((byte)10));
        }
        if (n < 366) {
            array[0] = 53;
            array[1] = 28;
            array = this.ldxdyc(-4712, n, array);
        }
        else if (n < 2299161) {
            n -= 366;
            final int n2 = -4711 + n / 1461 * 4;
            n %= 1461;
            int n3 = n / 365;
            int n4 = n % 365;
            if (n4 == 0 && n3 == 4) {
                n4 = 366;
                n3 = 3;
            }
            else {
                ++n4;
            }
            final int n5 = n2 + n3;
            array = this.ldxdyc(n5, n4, array);
            array[0] = (byte)(n5 / 100 + 100);
            array[1] = (byte)(n5 % 100 + 100);
        }
        else {
            n = 4 * (n - 1721119) - 1;
            final int n6 = n / 146097;
            n %= 146097;
            n = 4 * (n / 4) + 3;
            final int n7 = n % 1461;
            n /= 1461;
            int n8 = n7 / 4;
            ++n8;
            final int n9 = 5 * n8 - 3;
            final int n10 = n9 % 153;
            int n11 = n9 / 153;
            int n12 = n10 / 5;
            ++n12;
            int n13 = n6 * 100 + n;
            if (n11 < 10) {
                n11 += 3;
            }
            else {
                n11 -= 9;
                ++n13;
            }
            array[3] = (byte)n12;
            array[2] = (byte)n11;
            array[0] = (byte)(n13 / 100 + 100);
            array[1] = (byte)(n13 % 100 + 100);
        }
        return array;
    }
    
    private byte[] ldxdyc(final int n, final int n2, final byte[] array) throws SQLException {
        final int ldxisl = this.ldxisl(n) ? 1 : 0;
        if (n2 == 366 && ldxisl == 0) {
            throw new SQLException(CoreException.getMessage((byte)9));
        }
        int n3;
        if ((n3 = n2) > 59 + ldxisl) {
            n3 += 2 - ldxisl;
        }
        n3 += 91;
        final int n4 = n3 * 100;
        array[3] = (byte)(n3 - (n4 - n4 % 3055) / 100);
        array[2] = (byte)(n4 / 3055 - 2);
        return array;
    }
    
    private int ldxcty(final int n, final int n2, final int n3) {
        return LdxLibThin.ldxdom[n2] + n3 + ((n2 >= 3 && this.ldxisl(n)) ? 1 : 0);
    }
    
    private boolean ldxisl(final int n) {
        return n % 4 == 0 && ((n > 1582) ? (n % 100 != 0 || n % 400 == 0) : (n != -4712));
    }
    
    private String lxi42b(final int n, final long number, int n2, final boolean b, final Locale inLocale) throws SQLException {
        int n3 = 0;
        long n4 = number;
        final NumberFormat instance = NumberFormat.getInstance(inLocale);
        final DecimalFormat decimalFormat = (DecimalFormat)instance;
        final StringBuffer sb = new StringBuffer();
        final int groupingSize = decimalFormat.getGroupingSize();
        char groupingSeparator = '\0';
        final char zeroDigit = decimalFormat.getDecimalFormatSymbols().getZeroDigit();
        int n5 = 1;
        while ((n4 /= 10L) != 0L) {
            ++n5;
        }
        if (number < 0L) {
            ++n5;
        }
        if (b) {
            n5 += (n5 - 1) / groupingSize;
        }
        if (!b) {
            instance.setGroupingUsed(false);
        }
        sb.append(decimalFormat.format(number));
        if (n5 > n || n2 > n || (n2 != 0 && n5 > n2)) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        if (b) {
            groupingSeparator = decimalFormat.getDecimalFormatSymbols().getGroupingSeparator();
        }
        if (n2 != 0) {
            n2 -= n5;
            while (n2-- != 0) {
                if (b && n3++ == groupingSize && n2 != 0) {
                    sb.insert(0, groupingSeparator);
                    n3 = 1;
                    --n2;
                }
                sb.insert(0, zeroDigit);
            }
        }
        return sb.toString();
    }
    
    @Override
    public byte[] ldxsto(final String s, final String s2) throws SQLException {
        int i = 0;
        int n = 0;
        int n2 = 0;
        final byte[] array = new byte[512];
        byte b = 0;
        final char[] array2 = new char[256];
        if (s == null || s.compareTo("") == 0) {
            return LdxLibThin.NULLFMT;
        }
        final int length = s.length();
    Label_0061:
        while (i < length) {
            int n3 = 16;
            int n4 = 0;
            while (i >= length || s.charAt(i) != '|') {
                int count = 0;
                while (i < length && !Character.isLetterOrDigit(s.charAt(i))) {
                    if (s.charAt(i) == '\"') {
                        b = 1;
                        while (i != length && s.charAt(++i) != '\"') {
                            array2[n4++] = s.charAt(i);
                            ++count;
                        }
                        if (s.charAt(i) != '\"') {
                            continue;
                        }
                        ++i;
                    }
                    else {
                        array2[n4++] = s.charAt(i++);
                        ++count;
                    }
                }
                Label_0971: {
                    if (count > 0) {
                        if (count > 210) {
                            throw new SQLException(CoreException.getMessage((byte)7));
                        }
                        if (Character.isWhitespace(array2[0])) {
                            int n5;
                            int n6;
                            int count2;
                            for (n5 = 0, n6 = count, count2 = 0; n6 > 0 && Character.isWhitespace(array2[n5]); ++n5, ++count2, --n6) {}
                            array[n++] = (byte)(45 + count2);
                            array[n++] = 2;
                            final byte[] bytes = new String(array2, 0, count2).getBytes();
                            System.arraycopy(bytes, 0, array, n, bytes.length);
                            n += bytes.length;
                            count -= count2;
                            if (count == 0) {
                                break Label_0971;
                            }
                            i += count2 + 1;
                            n4 = n5;
                        }
                        else {
                            n4 = 0;
                        }
                        if (b != 1) {
                            b = 4;
                        }
                        array[n++] = (byte)(45 + count);
                        array[n++] = b;
                        final byte[] bytes2 = new String(array2, 0, count).getBytes();
                        System.arraycopy(bytes2, 0, array, n, bytes2.length);
                        n += bytes2.length;
                    }
                    else {
                        if (!Character.isLetterOrDigit(s.charAt(i))) {
                            throw new SQLException(CoreException.getMessage((byte)7));
                        }
                        final char upperCase = Character.toUpperCase(s.charAt(i));
                        final int n7 = upperCase - 'A';
                        if (n7 > 25 || LdxLibThin.ldxfdi[n7] == Integer.MIN_VALUE) {
                            throw new SQLException(CoreException.getMessage((byte)7));
                        }
                        int j = LdxLibThin.ldxfdi[n7];
                        int n8 = 50;
                        while (j < LdxLibThin.ldxfda.length) {
                            final int length2 = LdxLibThin.ldxfda[j].length;
                            int n9 = 0;
                            for (int index = i; n9 < length2 && index < length && Character.toUpperCase(s.charAt(index)) == LdxLibThin.ldxfda[j][n9]; ++n9, ++index) {}
                            if (n9 == length2) {
                                n8 = j;
                            }
                            if (LdxLibThin.ldxfda[j + 1][0] != upperCase) {
                                break;
                            }
                            ++j;
                        }
                        final int n10 = n8;
                        if (n10 >= LdxLibThin.ldxfda.length) {
                            throw new SQLException(CoreException.getMessage((byte)7));
                        }
                        if (length - i > 1 && Character.isUpperCase(s.charAt(i))) {
                            if (Character.isLowerCase(Character.isLetterOrDigit(s.charAt(i + 1)) ? s.charAt(i + 1) : s.charAt(i + 2))) {
                                n3 = (byte)(n3 | 0x4);
                            }
                            else {
                                n3 = (byte)(n3 | 0x8);
                            }
                        }
                        i += LdxLibThin.ldxfda[n10].length;
                        n2 = LdxLibThin.ldxfdc[n10];
                        if ((LdxLibThin.ldxfcdlen[n2] & 0xFFFFFF80) == 0x0) {
                            int k = 0;
                            int n11 = -1;
                            while (k < LdxLibThin.ldxfdx.length) {
                                final int length3 = LdxLibThin.ldxfdx[k].length;
                                int n12 = 0;
                                for (int index2 = i; n12 < length3 && index2 < length && Character.toUpperCase(s.charAt(index2)) == LdxLibThin.ldxfdx[k][n12]; ++n12, ++index2) {}
                                if (n12 == length3) {
                                    n11 = k;
                                }
                                ++k;
                            }
                            final int n13 = n11;
                            if (n13 >= 0 && n13 < LdxLibThin.ldxfdx.length) {
                                n3 = (byte)(n3 | LdxLibThin.ldxfdxc[n13]);
                                i += LdxLibThin.ldxfdx[n13].length;
                            }
                        }
                        if (512 - n < 2) {
                            throw new SQLException(CoreException.getMessage((byte)7));
                        }
                        array[n++] = (byte)n2;
                        array[n++] = (byte)n3;
                    }
                    if (n2 == 39) {
                        n3 = (((n3 & 0x10) == 0x1) ? 0 : 16);
                    }
                }
                if (n2 != 39) {
                    continue Label_0061;
                }
            }
            ++i;
        }
        final byte[] array3 = new byte[n];
        System.arraycopy(array, 0, array3, 0, array3.length);
        return array3;
    }
    
    @Override
    public byte[] ldxdyf(final byte[] array) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public void ldxftd(final byte[] array, final int[] array2, final int[] array3) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxgdt() throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxldd(final byte[] array) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxnxd(final byte[] array, final int n) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxrnd(final byte[] array, final String s) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxsbm(final byte[] array, final byte[] array2) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public void ldxsub(final byte[] array, final byte[] array2, final int[] array3, final int[] array4) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    @Override
    public byte[] ldxstd(final String text, final String s, final String s2) throws SQLException {
        final char[] value = new char[512];
        int i = 0;
        int count = 0;
        final ParsePosition pos = new ParsePosition(0);
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
        final byte[] ldxsto = this.ldxsto(s, s2);
        this.ldxsti(ldxsto);
        while (i < ldxsto.length) {
            final byte b = ldxsto[i++];
            final byte b2 = ldxsto[i++];
            switch (b) {
                case 43:
                case 44: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 41: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 40: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 4: {
                    value[count++] = 'y';
                    continue;
                }
                case 6: {
                    for (int j = 0; j < 2; ++j) {
                        value[count++] = 'y';
                    }
                    continue;
                }
                case 8: {
                    for (int k = 0; k < 3; ++k) {
                        value[count++] = 'y';
                    }
                    continue;
                }
                case 10: {
                    for (int l = 0; l < 4; ++l) {
                        value[count++] = 'y';
                    }
                    continue;
                }
                case 11:
                case 12:
                case 13: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 38: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 17: {
                    value[count++] = 'M';
                    value[count++] = 'M';
                    continue;
                }
                case 31: {
                    for (int n = 0; n < 3; ++n) {
                        value[count++] = 'M';
                    }
                    continue;
                }
                case 30: {
                    for (int n2 = 0; n2 < 4; ++n2) {
                        value[count++] = 'M';
                    }
                    continue;
                }
                case 21:
                case 33: {
                    value[count++] = 'E';
                    continue;
                }
                case 32: {
                    for (int n3 = 0; n3 < 4; ++n3) {
                        value[count++] = 'E';
                    }
                    continue;
                }
                case 22: {
                    value[count++] = 'd';
                    continue;
                }
                case 23: {
                    value[count++] = 'D';
                    continue;
                }
                case 29: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 25: {
                    value[count++] = 'h';
                    continue;
                }
                case 24: {
                    value[count++] = 'H';
                    continue;
                }
                case 26: {
                    value[count++] = 'm';
                    continue;
                }
                case 27: {
                    value[count++] = 's';
                    continue;
                }
                case 28: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                case 34:
                case 35: {
                    value[count++] = 'a';
                    continue;
                }
                case 36:
                case 37: {
                    value[count++] = 'G';
                    continue;
                }
                case 39:
                case 42: {
                    throw new SQLException(CoreException.getMessage((byte)1));
                }
                default: {
                    final int length = b - 45;
                    final String s3 = new String(ldxsto, i, length);
                    if (b2 == 1) {
                        value[count++] = '\'';
                        System.arraycopy(s3.toCharArray(), 0, value, count, length);
                        count += length;
                        i += length;
                        value[count++] = '\'';
                        continue;
                    }
                    System.arraycopy(s3.toCharArray(), 0, value, count, length);
                    count += length;
                    i += length;
                    continue;
                }
            }
        }
        simpleDateFormat.applyPattern(new String(value, 0, count));
        simpleDateFormat.setLenient(false);
        final Date parse = simpleDateFormat.parse(text, pos);
        if (parse != null) {
            return DATE.toBytes(new Timestamp(parse.getTime()));
        }
        throw new SQLException(CoreException.getMessage((byte)6));
    }
    
    @Override
    public byte[] ldxtrn(final byte[] array, final String s) throws SQLException {
        throw new SQLException(CoreException.getMessage((byte)1));
    }
    
    private void ldxsti(final byte[] array) throws SQLException {
        final int[] array2 = new int[46];
        for (int i = 0; i < array.length; i += 2) {
            if (array[i] < 45) {
                final byte b = array[i];
                if (array[i] != 42 && array[i] != 39 && array2[array[i]] != 0) {
                    throw new SQLException(CoreException.getMessage((byte)7));
                }
                final int[] array3 = array2;
                final byte b2 = array[i];
                ++array3[b2];
                switch (array[i]) {
                    case 1:
                    case 2:
                    case 3:
                    case 5:
                    case 7:
                    case 9:
                    case 14:
                    case 15:
                    case 16:
                    case 18:
                    case 19:
                    case 20: {
                        throw new SQLException(CoreException.getMessage((byte)7));
                    }
                }
            }
            else {
                i += array[i] - 45;
            }
        }
        for (int j = 0; j < this.ldxpmxa.length; ++j) {
            int n = 0;
            for (int k = 0; k < this.ldxpmxa[j].length; ++k) {
                n += array2[this.ldxpmxa[j][k]];
            }
            if (n > 1) {
                throw new SQLException(CoreException.getMessage((byte)7));
            }
        }
    }
    
    static {
        ldxfda = new char[][] { { 'A', '.', 'D', '.' }, { 'A', '.', 'M', '.' }, { 'A', 'D' }, { 'A', 'M' }, { 'B', '.', 'C', '.' }, { 'B', 'C' }, { 'C', 'C' }, { 'D' }, { 'D', 'A', 'Y' }, { 'D', 'D' }, { 'D', 'D', 'D' }, { 'D', 'Y' }, { 'E' }, { 'E', 'E' }, { 'F', 'M' }, { 'F', 'X' }, { 'H', 'H' }, { 'H', 'H', '1', '2' }, { 'H', 'H', '2', '4' }, { 'I' }, { 'I', 'W' }, { 'I', 'Y' }, { 'I', 'Y', 'Y' }, { 'I', 'Y', 'Y', 'Y' }, { 'J' }, { 'M', 'I' }, { 'M', 'M' }, { 'M', 'O', 'N' }, { 'M', 'O', 'N', 'T', 'H' }, { 'P', '.', 'M', '.' }, { 'P', 'M' }, { 'Q' }, { 'R', 'M' }, { 'R', 'R' }, { 'R', 'R', 'R', 'R' }, { 'S', 'C', 'C' }, { 'S', 'S' }, { 'S', 'S', 'S', 'S', 'S' }, { 'S', 'Y', ',', 'Y', 'Y', 'Y' }, { 'S', 'Y', 'E', 'A', 'R' }, { 'S', 'Y', 'Y', 'Y', 'Y' }, { 'W' }, { 'W', 'W' }, { 'Y' }, { 'Y', ',', 'Y', 'Y', 'Y' }, { 'Y', 'E', 'A', 'R' }, { 'Y', 'Y' }, { 'Y', 'Y', 'Y' }, { 'Y', 'Y', 'Y', 'Y' }, { '\0' } };
        ldxfdc = new byte[] { 37, 35, 36, 34, 37, 36, 1, 21, 32, 22, 23, 33, 43, 44, 39, 42, 25, 25, 24, 3, 18, 5, 7, 9, 29, 26, 17, 31, 30, 35, 34, 16, 38, 40, 41, 2, 27, 28, 13, 15, 12, 20, 19, 4, 11, 14, 6, 8, 10, 0 };
        ldxfcdlen = new byte[] { 0, 2, 35, 1, 1, 2, 2, 3, 3, 4, 4, 21, 37, 54, -60, -27, 1, 2, 2, 2, 1, 1, 2, 3, 2, 2, 2, 2, 5, 7, -128, -128, -128, -128, -62, -60, -62, -60, -124, 0, 2, 4, 0, -113, -98, -128, -128 };
        LdxLibThin.ldxfdi = new int[] { 0, 4, 6, 7, 12, 14, Integer.MIN_VALUE, 16, 19, 24, Integer.MIN_VALUE, Integer.MIN_VALUE, 25, Integer.MIN_VALUE, Integer.MIN_VALUE, 29, 31, 32, 35, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, 41, Integer.MIN_VALUE, 43, Integer.MIN_VALUE };
        ldxfdx = new char[][] { { 'S', 'P' }, { 'S', 'P', 'T', 'H' }, { 'T', 'H' }, { 'T', 'H', 'S', 'P' }, { '\0' } };
        ldxfdxc = new byte[] { 2, 3, 1, 3, 0 };
        NULLFMT = new byte[] { 0, 16 };
        DEFAULT_FORMAT = new byte[] { 22, 24, 46, 4, 47, 31, 24, 46, 4, 47, 10, 24 };
        ldxpaa = new String[] { "A.D.", "A.M.", "B.C.", "P.M." };
        ldxdom = new int[] { 0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
    }
}
