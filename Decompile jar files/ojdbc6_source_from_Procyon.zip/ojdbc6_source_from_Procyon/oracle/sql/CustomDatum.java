// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.internal.ObjectData;

public interface CustomDatum extends ObjectData
{
    Datum toDatum(final OracleConnection p0) throws SQLException;
}
