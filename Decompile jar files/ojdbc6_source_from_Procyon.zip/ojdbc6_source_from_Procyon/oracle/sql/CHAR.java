// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.internal.OracleConnection;
import java.io.InputStream;
import java.io.StringReader;
import java.io.Reader;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import oracle.jdbc.driver.DatabaseError;
import java.math.BigDecimal;
import java.sql.SQLException;

public class CHAR extends Datum
{
    public static final CharacterSet DEFAULT_CHARSET;
    private CharacterSet charSet;
    private int oracleId;
    private static final byte[] empty;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected CHAR() {
    }
    
    public CHAR(final byte[] array, final CharacterSet set) {
        this.setValue(array, set);
    }
    
    public CHAR(final byte[] array, final int n, final int n2, final CharacterSet set) {
        final byte[] array2 = new byte[n2];
        System.arraycopy(array, n, array2, 0, n2);
        this.setValue(array2, set);
    }
    
    public CHAR(final String s, CharacterSet default_CHARSET) throws SQLException {
        if (default_CHARSET == null) {
            default_CHARSET = CHAR.DEFAULT_CHARSET;
        }
        this.setValue(default_CHARSET.convertWithReplacement(s), default_CHARSET);
    }
    
    public CHAR(final Object o, final CharacterSet set) throws SQLException {
        this(o.toString(), set);
    }
    
    public CharacterSet getCharacterSet() {
        if (this.charSet == null) {
            if (this.oracleId == 0) {
                this.oracleId = -1;
            }
            if (CHAR.DEFAULT_CHARSET != null && (this.oracleId == -1 || this.oracleId == CHAR.DEFAULT_CHARSET.getOracleId())) {
                this.charSet = CHAR.DEFAULT_CHARSET;
            }
            else {
                this.charSet = CharacterSet.make(this.oracleId);
            }
        }
        return this.charSet;
    }
    
    public int oracleId() {
        return this.oracleId;
    }
    
    public String getString() throws SQLException {
        return this.getCharacterSet().toString(this.shareBytes(), 0, (int)this.getLength());
    }
    
    public String getStringWithReplacement() {
        final byte[] shareBytes = this.shareBytes();
        return this.getCharacterSet().toStringWithReplacement(shareBytes, 0, shareBytes.length);
    }
    
    @Override
    public String toString() {
        return this.getStringWithReplacement();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof CHAR && this.getCharacterSet().equals(((CHAR)o).getCharacterSet()) && super.equals(o);
    }
    
    void setValue(final byte[] array, final CharacterSet set) {
        this.charSet = ((set == null) ? CHAR.DEFAULT_CHARSET : set);
        this.oracleId = this.charSet.getOracleId();
        this.setShareBytes((array == null) ? CHAR.empty : array);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this.stringValue();
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.lang.String") == 0 || name.compareTo("java.lang.Long") == 0 || name.compareTo("java.math.BigDecimal") == 0 || name.compareTo("java.io.InputStream") == 0 || name.compareTo("java.sql.Date") == 0 || name.compareTo("java.sql.Time") == 0 || name.compareTo("java.sql.Timestamp") == 0 || name.compareTo("java.io.Reader") == 0;
    }
    
    @Override
    public String stringValue() {
        return this.toString();
    }
    
    @Override
    public boolean booleanValue() throws SQLException {
        final String stringValue = this.stringValue();
        if (stringValue == null) {
            return false;
        }
        final String trim = stringValue.trim();
        try {
            return new BigDecimal(trim).signum() != 0;
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public int intValue() throws SQLException {
        final long longValue = this.longValue();
        if (longValue > 2147483647L || longValue < -2147483648L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (int)longValue;
    }
    
    @Override
    public long longValue() throws SQLException {
        long longValue;
        try {
            longValue = Long.valueOf(this.stringValue().trim());
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return longValue;
    }
    
    @Override
    public float floatValue() throws SQLException {
        float floatValue;
        try {
            floatValue = Float.valueOf(this.stringValue().trim());
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return floatValue;
    }
    
    @Override
    public double doubleValue() throws SQLException {
        double doubleValue;
        try {
            doubleValue = Double.valueOf(this.stringValue().trim());
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return doubleValue;
    }
    
    @Override
    public byte byteValue() throws SQLException {
        final long longValue = this.longValue();
        if (longValue > 127L || longValue < -128L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (byte)longValue;
    }
    
    @Override
    public Date dateValue() throws SQLException {
        return Date.valueOf(this.stringValue().trim());
    }
    
    @Override
    public Time timeValue() throws SQLException {
        return Time.valueOf(this.stringValue().trim());
    }
    
    @Override
    public Timestamp timestampValue() throws SQLException {
        return Timestamp.valueOf(this.stringValue().trim());
    }
    
    @Override
    public BigDecimal bigDecimalValue() throws SQLException {
        BigDecimal bigDecimal;
        try {
            bigDecimal = new BigDecimal(this.stringValue().trim());
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "bigDecimalValue");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return bigDecimal;
    }
    
    @Override
    public Reader characterStreamValue() throws SQLException {
        return new StringReader(this.getString());
    }
    
    @Override
    public InputStream asciiStreamValue() throws SQLException {
        return this.getStream();
    }
    
    @Override
    public InputStream binaryStreamValue() throws SQLException {
        return this.getStream();
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new String[n];
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        DEFAULT_CHARSET = CharacterSet.make(-1);
        empty = new byte[0];
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
