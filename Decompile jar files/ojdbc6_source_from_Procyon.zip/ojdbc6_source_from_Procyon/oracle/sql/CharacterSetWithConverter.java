// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.sql.converter.CharacterConverterFactoryJDBC;
import java.sql.SQLException;
import oracle.sql.converter.JdbcCharacterConverters;
import oracle.sql.converter.CharacterConverterFactory;

public abstract class CharacterSetWithConverter extends CharacterSet
{
    public static CharacterConverterFactory ccFactory;
    JdbcCharacterConverters m_converter;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetWithConverter(final int n, final JdbcCharacterConverters converter) {
        super(n);
        this.m_converter = converter;
    }
    
    static CharacterSet getInstance(final int n) {
        final JdbcCharacterConverters make = CharacterSetWithConverter.ccFactory.make(n);
        if (make == null) {
            return null;
        }
        final CharacterSet1Byte instance;
        if ((instance = CharacterSet1Byte.getInstance(n, make)) != null) {
            return instance;
        }
        final CharacterSetSJIS instance2;
        if ((instance2 = CharacterSetSJIS.getInstance(n, make)) != null) {
            return instance2;
        }
        final CharacterSetShift instance3;
        if ((instance3 = CharacterSetShift.getInstance(n, make)) != null) {
            return instance3;
        }
        final CharacterSet2ByteFixed instance4;
        if ((instance4 = CharacterSet2ByteFixed.getInstance(n, make)) != null) {
            return instance4;
        }
        final CharacterSetGB18030 instance5;
        if ((instance5 = CharacterSetGB18030.getInstance(n, make)) != null) {
            return instance5;
        }
        final CharacterSet12Byte instance6;
        if ((instance6 = CharacterSet12Byte.getInstance(n, make)) != null) {
            return instance6;
        }
        final CharacterSetJAEUC instance7;
        if ((instance7 = CharacterSetJAEUC.getInstance(n, make)) != null) {
            return instance7;
        }
        final CharacterSetZHTEUC instance8;
        if ((instance8 = CharacterSetZHTEUC.getInstance(n, make)) != null) {
            return instance8;
        }
        return CharacterSetLCFixed.getInstance(n, make);
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return set.getOracleId() != this.getOracleId();
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.getOracleId() == this.getOracleId();
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        return this.m_converter.toUnicodeStringWithReplacement(array, n, n2);
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        return this.m_converter.toUnicodeString(array, n, n2);
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        return this.m_converter.toOracleString(s);
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        return this.m_converter.toOracleStringWithReplacement(s);
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        if (set.getOracleId() == this.getOracleId()) {
            return CharacterSet.useOrCopy(array, n, n2);
        }
        return this.convert(set.toString(array, n, n2));
    }
    
    static {
        CharacterSetWithConverter.ccFactory = new CharacterConverterFactoryJDBC();
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
