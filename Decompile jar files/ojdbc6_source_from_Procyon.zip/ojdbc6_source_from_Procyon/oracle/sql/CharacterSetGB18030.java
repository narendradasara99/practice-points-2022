// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.converter.JdbcCharacterConverters;

class CharacterSetGB18030 extends CharacterSetWithConverter
{
    static final int MAX_7BIT = 127;
    static Class m_charConvSuperclass;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetGB18030(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        super(n, jdbcCharacterConverters);
    }
    
    static CharacterSetGB18030 getInstance(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        if (jdbcCharacterConverters.getGroupId() == 9) {
            return new CharacterSetGB18030(n, jdbcCharacterConverters);
        }
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        int n = characterWalker.bytes[characterWalker.next] & 0xFF;
        if (n > 127) {
            if (characterWalker.bytes.length <= characterWalker.next + 1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182, "destination too small");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if ((characterWalker.bytes[characterWalker.next] & 0xFF) >= 129 && (characterWalker.bytes[characterWalker.next] & 0xFF) <= 254 && (characterWalker.bytes[characterWalker.next + 1] & 0xFF) >= 48 && (characterWalker.bytes[characterWalker.next + 1] & 0xFF) <= 57) {
                if (characterWalker.bytes.length <= characterWalker.next + 3) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182, "destination too small");
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                if ((characterWalker.bytes[characterWalker.next + 2] & 0xFF) >= 129 && (characterWalker.bytes[characterWalker.next + 2] & 0xFF) <= 254 && (characterWalker.bytes[characterWalker.next + 3] & 0xFF) >= 48 && (characterWalker.bytes[characterWalker.next + 3] & 0xFF) <= 57) {
                    n = ((characterWalker.bytes[characterWalker.next] & 0xFF) << 24 | (characterWalker.bytes[characterWalker.next + 1] & 0xFF) << 16 | (characterWalker.bytes[characterWalker.next + 2] & 0xFF) << 8 | (characterWalker.bytes[characterWalker.next + 3] & 0xFF));
                    characterWalker.next += 4;
                }
                else {
                    n = (characterWalker.bytes[characterWalker.next] & 0xFF);
                    ++characterWalker.next;
                }
            }
            else {
                n = ((characterWalker.bytes[characterWalker.next] & 0xFF) << 8 | (characterWalker.bytes[characterWalker.next + 1] & 0xFF));
                characterWalker.next += 2;
            }
        }
        return n;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        for (int n2 = 0, n3 = 0; n >> n2 != 0; n2 = (short)(n2 + 8), n3 = (short)(n3 + 1)) {}
        int i;
        int n4;
        if (n >> 16 != 0) {
            i = 3;
            n4 = 4;
        }
        else if (n >> 8 != 0) {
            i = 1;
            n4 = 2;
        }
        else {
            i = 0;
            n4 = 1;
        }
        CharacterSet.need(characterBuffer, n4);
        while (i >= 0) {
            characterBuffer.bytes[characterBuffer.next++] = (byte)(n >> i & 0xFF);
            i = (short)(i - 8);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
