// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.sql.converter.JdbcCharacterConverters;

class CharacterSet1Byte extends CharacterSetWithConverter
{
    static final String CHAR_CONV_SUPERCLASS_NAME = "oracle.sql.converter.CharacterConverter1Byte";
    static Class m_charConvSuperclass;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSet1Byte(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        super(n, jdbcCharacterConverters);
    }
    
    static CharacterSet1Byte getInstance(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        if (jdbcCharacterConverters.getGroupId() == 0) {
            return new CharacterSet1Byte(n, jdbcCharacterConverters);
        }
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        final int n = characterWalker.bytes[characterWalker.next] & 0xFF;
        ++characterWalker.next;
        return n;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        CharacterSet.need(characterBuffer, 1);
        if (n < 256) {
            characterBuffer.bytes[characterBuffer.next] = (byte)n;
            ++characterBuffer.next;
        }
    }
    
    @Override
    public int toCharWithReplacement(final byte[] array, final int n, final char[] array2, final int n2, final int n3) throws SQLException {
        return this.m_converter.toUnicodeChars(array, n, array2, n2, n3);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
