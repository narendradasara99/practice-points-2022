// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

class CharacterSetUTFE extends CharacterSet implements CharacterRepConstants
{
    static final int MAXBYTEPERCHAR = 4;
    static byte[][] utf8m2utfe;
    static byte[][] utfe2utf8m;
    private static int[] m_byteLen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetUTFE(final int n) {
        super(n);
        this.rep = 3;
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return !set.isUnicode();
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.rep <= 1024;
    }
    
    @Override
    public boolean isUnicode() {
        return true;
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        final char[] value = new char[array.length];
        return new String(value, 0, this.UTFEToJavaChar(array, n, n2, value, CharacterConverterBehavior.REPORT_ERROR));
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        try {
            final char[] value = new char[array.length];
            return new String(value, 0, this.UTFEToJavaChar(array, n, n2, value, CharacterConverterBehavior.REPLACEMENT));
        }
        catch (SQLException ex) {
            throw new IllegalStateException(ex.getMessage());
        }
    }
    
    int UTFEToJavaChar(final byte[] array, final int n, final int n2, final char[] array2, final CharacterConverterBehavior characterConverterBehavior) throws SQLException {
        int i = n;
        final int n3 = n + n2;
        int n4 = 0;
        while (i < n3) {
            final byte b = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
            switch (b >>> 4 & 0xF) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7: {
                    array2[n4++] = (char)(b & 0x7F);
                    continue;
                }
                case 8:
                case 9: {
                    array2[n4++] = (char)(b & 0x1F);
                    continue;
                }
                case 12:
                case 13: {
                    if (i >= n3) {
                        characterConverterBehavior.onFailConversion();
                        i = n3;
                        continue;
                    }
                    final byte b2 = (byte)(b & 0x1F);
                    final byte b3 = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
                    if (!is101xxxxx(b3)) {
                        characterConverterBehavior.onFailConversion();
                        array2[n4++] = '\ufffd';
                        continue;
                    }
                    array2[n4++] = (char)(b2 << 5 | (b3 & 0x1F));
                    continue;
                }
                case 14: {
                    if (i + 1 >= n3) {
                        characterConverterBehavior.onFailConversion();
                        i = n3;
                        continue;
                    }
                    final byte b4 = (byte)(b & 0xF);
                    final byte b5 = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
                    final byte b6 = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
                    if (!is101xxxxx(b5) || !is101xxxxx(b6)) {
                        characterConverterBehavior.onFailConversion();
                        array2[n4++] = '\ufffd';
                        continue;
                    }
                    array2[n4++] = (char)(b4 << 10 | (b5 & 0x1F) << 5 | (b6 & 0x1F));
                    continue;
                }
                case 15: {
                    if (i + 2 >= n3) {
                        characterConverterBehavior.onFailConversion();
                        i = n3;
                        continue;
                    }
                    final byte b7 = (byte)(b & 0x1);
                    final byte b8 = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
                    final byte b9 = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
                    final byte b10 = CharacterSetUTFE.utfe2utf8m[high(array[i])][low(array[i++])];
                    if (!is101xxxxx(b8) || !is101xxxxx(b9) || !is101xxxxx(b10)) {
                        characterConverterBehavior.onFailConversion();
                        array2[n4++] = '\ufffd';
                        continue;
                    }
                    array2[n4++] = (char)(b7 << 15 | (b8 & 0x1F) << 10 | (b9 & 0x1F) << 5 | (b10 & 0x1F));
                    continue;
                }
                default: {
                    characterConverterBehavior.onFailConversion();
                    array2[n4++] = '\ufffd';
                    continue;
                }
            }
        }
        return n4;
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        final char[] charArray = s.toCharArray();
        final byte[] array = new byte[charArray.length * 4];
        final int javaCharsToUTFE = this.javaCharsToUTFE(charArray, 0, charArray.length, array, 0);
        final byte[] array2 = new byte[javaCharsToUTFE];
        System.arraycopy(array, 0, array2, 0, javaCharsToUTFE);
        return array2;
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        return this.convertWithReplacement(s);
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        byte[] array2;
        if (set.rep == 3) {
            array2 = CharacterSet.useOrCopy(array, n, n2);
        }
        else {
            array2 = this.convert(set.toString(array, n, n2));
        }
        return array2;
    }
    
    int javaCharsToUTFE(final char[] array, final int n, final int n2, final byte[] array2, final int n3) {
        final int n4 = n + n2;
        int n5 = 0;
        for (int i = n; i < n4; ++i) {
            final char c = array[i];
            if (c <= '\u001f') {
                final int n6 = c | '\u0080';
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n6)][low(n6)];
            }
            else if (c <= '\u007f') {
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(c)][low(c)];
            }
            else if (c <= '\u03ff') {
                final int n7 = (c & '\u03e0') >> 5 | 0xC0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n7)][low(n7)];
                final int n8 = (c & '\u001f') | 0xA0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n8)][low(n8)];
            }
            else if (c <= '\u3fff') {
                final int n9 = (c & '\u3c00') >> 10 | 0xE0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n9)][low(n9)];
                final int n10 = (c & '\u03e0') >> 5 | 0xA0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n10)][low(n10)];
                final int n11 = (c & '\u001f') | 0xA0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n11)][low(n11)];
            }
            else {
                final int n12 = (c & '\u8000') >> 15 | 0xF0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n12)][low(n12)];
                final int n13 = (c & '\u7c00') >> 10 | 0xA0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n13)][low(n13)];
                final int n14 = (c & '\u03e0') >> 5 | 0xA0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n14)][low(n14)];
                final int n15 = (c & '\u001f') | 0xA0;
                array2[n5++] = CharacterSetUTFE.utf8m2utfe[high(n15)][low(n15)];
            }
        }
        return n5;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        final byte[] bytes = characterWalker.bytes;
        final int next = characterWalker.next;
        final int end = characterWalker.end;
        final int n = 0;
        if (next >= end) {
            failUTFConversion();
        }
        final int utfByteLength = getUTFByteLength(bytes[next]);
        if (utfByteLength == 0 || next + (utfByteLength - 1) >= end) {
            failUTFConversion();
        }
        try {
            final char[] array = new char[2];
            final int utfeToJavaChar = this.UTFEToJavaChar(bytes, next, utfByteLength, array, CharacterConverterBehavior.REPORT_ERROR);
            characterWalker.next += utfByteLength;
            if (utfeToJavaChar == 1) {
                return array[0];
            }
            return array[0] << 16 | array[1];
        }
        catch (SQLException ex) {
            failUTFConversion();
            characterWalker.next = next;
            return n;
        }
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        if ((n & 0xFFFF0000) != 0x0) {
            failUTFConversion();
        }
        else if (n <= 31) {
            CharacterSet.need(characterBuffer, 1);
            final int n2 = n | 0x80;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n2)][low(n2)];
        }
        else if (n <= 127) {
            CharacterSet.need(characterBuffer, 1);
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n)][low(n)];
        }
        else if (n <= 1023) {
            CharacterSet.need(characterBuffer, 2);
            final int n3 = (n & 0x3E0) >> 5 | 0xC0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n3)][low(n3)];
            final int n4 = (n & 0x1F) | 0xA0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n4)][low(n4)];
        }
        else if (n <= 16383) {
            CharacterSet.need(characterBuffer, 3);
            final int n5 = (n & 0x3C00) >> 10 | 0xE0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n5)][low(n5)];
            final int n6 = (n & 0x3E0) >> 5 | 0xA0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n6)][low(n6)];
            final int n7 = (n & 0x1F) | 0xA0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n7)][low(n7)];
        }
        else {
            CharacterSet.need(characterBuffer, 4);
            final int n8 = (n & 0x8000) >> 15 | 0xF0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n8)][low(n8)];
            final int n9 = (n & 0x7C00) >> 10 | 0xA0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n9)][low(n9)];
            final int n10 = (n & 0x3E0) >> 5 | 0xA0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n10)][low(n10)];
            final int n11 = (n & 0x1F) | 0xA0;
            characterBuffer.bytes[characterBuffer.next++] = CharacterSetUTFE.utf8m2utfe[high(n11)][low(n11)];
        }
    }
    
    private static int high(final int n) {
        return n >> 4 & 0xF;
    }
    
    private static int low(final int n) {
        return n & 0xF;
    }
    
    private static boolean is101xxxxx(final byte b) {
        return (b & 0xFFFFFFE0) == 0xFFFFFFA0;
    }
    
    private static int getUTFByteLength(final byte b) {
        return CharacterSetUTFE.m_byteLen[CharacterSetUTFE.utfe2utf8m[high(b)][low(b)] >>> 4 & 0xF];
    }
    
    static {
        CharacterSetUTFE.utf8m2utfe = new byte[][] { { 0, 1, 2, 3, 55, 45, 46, 47, 22, 5, 21, 11, 12, 13, 14, 15 }, { 16, 17, 18, 19, 60, 61, 50, 38, 24, 25, 63, 39, 28, 29, 30, 31 }, { 64, 90, 127, 123, 91, 108, 80, 125, 77, 93, 92, 78, 107, 96, 75, 97 }, { -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, 122, 94, 76, 126, 110, 111 }, { 124, -63, -62, -61, -60, -59, -58, -57, -56, -55, -47, -46, -45, -44, -43, -42 }, { -41, -40, -39, -30, -29, -28, -27, -26, -25, -24, -23, -83, -32, -67, 95, 109 }, { 121, -127, -126, -125, -124, -123, -122, -121, -120, -119, -111, -110, -109, -108, -107, -106 }, { -105, -104, -103, -94, -93, -92, -91, -90, -89, -88, -87, -64, 79, -48, -95, 7 }, { 32, 33, 34, 35, 36, 37, 6, 23, 40, 41, 42, 43, 44, 9, 10, 27 }, { 48, 49, 26, 51, 52, 53, 54, 8, 56, 57, 58, 59, 4, 20, 62, -1 }, { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 81, 82, 83, 84, 85, 86 }, { 87, 88, 89, 98, 99, 100, 101, 102, 103, 104, 105, 106, 112, 113, 114, 115 }, { 116, 117, 118, 119, 120, -128, -118, -117, -116, -115, -114, -113, -112, -102, -101, -100 }, { -99, -98, -97, -96, -86, -85, -84, -82, -81, -80, -79, -78, -77, -76, -75, -74 }, { -73, -72, -71, -70, -69, -68, -66, -65, -54, -53, -52, -51, -50, -49, -38, -37 }, { -36, -35, -34, -33, -31, -22, -21, -20, -19, -18, -17, -6, -5, -4, -3, -2 } };
        CharacterSetUTFE.utfe2utf8m = new byte[][] { { 0, 1, 2, 3, -100, 9, -122, 127, -105, -115, -114, 11, 12, 13, 14, 15 }, { 16, 17, 18, 19, -99, 10, 8, -121, 24, 25, -110, -113, 28, 29, 30, 31 }, { -128, -127, -126, -125, -124, -123, 23, 27, -120, -119, -118, -117, -116, 5, 6, 7 }, { -112, -111, 22, -109, -108, -107, -106, 4, -104, -103, -102, -101, 20, 21, -98, 26 }, { 32, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, 46, 60, 40, 43, 124 }, { 38, -86, -85, -84, -83, -82, -81, -80, -79, -78, 33, 36, 42, 41, 59, 94 }, { 45, 47, -77, -76, -75, -74, -73, -72, -71, -70, -69, 44, 37, 95, 62, 63 }, { -68, -67, -66, -65, -64, -63, -62, -61, -60, 96, 58, 35, 64, 39, 61, 34 }, { -59, 97, 98, 99, 100, 101, 102, 103, 104, 105, -58, -57, -56, -55, -54, -53 }, { -52, 106, 107, 108, 109, 110, 111, 112, 113, 114, -51, -50, -49, -48, -47, -46 }, { -45, 126, 115, 116, 117, 118, 119, 120, 121, 122, -44, -43, -42, 88, -41, -40 }, { -39, -38, -37, -36, -35, -34, -33, -32, -31, -30, -29, -28, -27, 93, -26, -25 }, { 123, 65, 66, 67, 68, 69, 70, 71, 72, 73, -24, -23, -22, -21, -20, -19 }, { 13, 74, 75, 76, 77, 78, 79, 80, 81, 82, -18, -17, -16, -15, -14, -13 }, { 92, -12, 83, 84, 85, 86, 87, 88, 89, 90, -11, -10, -9, -8, -7, -6 }, { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, -5, -4, -3, -2, -1, -97 } };
        CharacterSetUTFE.m_byteLen = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 2, 2, 3, 4 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
