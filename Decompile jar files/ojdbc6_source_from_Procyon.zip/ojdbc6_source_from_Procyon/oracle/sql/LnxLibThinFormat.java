// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.core.lmx.CoreException;

class LnxLibThinFormat
{
    boolean LNXNFFMI;
    boolean LNXNFFDS;
    boolean LNXNFFPR;
    boolean LNXNFFBL;
    boolean LNXNFFDA;
    boolean LNXNFFED;
    boolean LNXNFFSN;
    boolean LNXNFFVF;
    boolean LNXNFFSH;
    boolean LNXNFFST;
    boolean LNXNFFCH;
    boolean LNXNFFCT;
    boolean LNXNFFRC;
    boolean LNXNFFRN;
    boolean LNXNFFLC;
    boolean LNXNFFIC;
    boolean LNXNFNRD;
    boolean LNXNFRDX;
    boolean LNXNFFIL;
    boolean LNXNFFPT;
    boolean LNXNFF05;
    boolean LNXNFFHX;
    boolean LNXNFFTM;
    boolean LNXNFFUN;
    byte[] lnxnfgps;
    int lnxnflhd;
    int lnxnfrhd;
    int lnxnfsiz;
    int lnxnfzld;
    int lnxnfztr;
    private static final int LNXPFL_US = 1;
    private static final int LNXPFL_NLS = -1;
    private static final int LXM_LILCURR = 11;
    private static final int LXM_LIUCURR = 11;
    private static final int LXM_LIICURR = 8;
    private static final int LXM_ROMOUT = 15;
    
    LnxLibThinFormat() {
        this.LNXNFFMI = false;
        this.LNXNFFDS = false;
        this.LNXNFFPR = false;
        this.LNXNFFBL = false;
        this.LNXNFFDA = false;
        this.LNXNFFED = false;
        this.LNXNFFSN = false;
        this.LNXNFFVF = false;
        this.LNXNFFSH = false;
        this.LNXNFFST = false;
        this.LNXNFFCH = false;
        this.LNXNFFCT = false;
        this.LNXNFFRC = false;
        this.LNXNFFRN = false;
        this.LNXNFFLC = false;
        this.LNXNFFIC = false;
        this.LNXNFNRD = false;
        this.LNXNFRDX = false;
        this.LNXNFFIL = false;
        this.LNXNFFPT = false;
        this.LNXNFF05 = false;
        this.LNXNFFHX = false;
        this.LNXNFFTM = false;
        this.LNXNFFUN = false;
        this.lnxnfgps = new byte[40];
        this.lnxnflhd = 0;
        this.lnxnfrhd = 0;
        this.lnxnfsiz = 0;
        this.lnxnfzld = 0;
        this.lnxnfztr = 0;
    }
    
    public void parseFormat(final String s) throws SQLException {
        int lnxnflhd = 0;
        int n = 0;
        int n2 = 0;
        boolean b = false;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        char c = '\0';
        char c2 = '\0';
        int n7 = 0;
        final int n8 = 39;
        int n9 = 0;
        int i = s.length();
        final char[] charArray = s.toCharArray();
        this.LNXNFFIL = true;
        while (i != 0) {
            int lowerCase = Character.toLowerCase(charArray[n5]);
            switch (lowerCase) {
                case 48:
                case 53:
                case 57:
                case 120: {
                    if (this.LNXNFFSN) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    if (n4 == 120 && lowerCase != 120) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    if (lowerCase == 53) {
                        if (i == 2) {
                            c = Character.toLowerCase(charArray[n5 + 1]);
                        }
                        else if (i == 3) {
                            c = Character.toLowerCase(charArray[n5 + 1]);
                            c2 = Character.toLowerCase(charArray[n5 + 2]);
                        }
                        if (this.LNXNFF05 || (i != 1 && (i != 2 || c != 's') && c != 'c' && c != 'l' && c != 'u' && (i != 3 || ((c != 'p' || c2 != 'r') && (c != 'p' || c2 != 't') && (c != 'm' || c2 != 'i'))))) {
                            throw new SQLException(CoreException.getMessage((byte)5));
                        }
                        this.LNXNFF05 = true;
                    }
                    if (lowerCase == 120) {
                        if (n4 != 0 && n4 != 109 && n4 != 48 && n4 != 120) {
                            throw new SQLException(CoreException.getMessage((byte)5));
                        }
                        this.LNXNFFHX = true;
                        if (charArray[n5] == 'x') {
                            this.LNXNFFLC = true;
                        }
                    }
                    ++lnxnflhd;
                    if (lowerCase == 48 && (n2 != 0 || n == 0)) {
                        n = lnxnflhd;
                        break;
                    }
                    break;
                }
                case 103: {
                    if (this.LNXNFFSN || this.LNXNFFHX || n2 != 0 || n7 == n8 || n9 > 0 || lnxnflhd == 0) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    n9 = -1;
                    this.lnxnfgps[n7] = (byte)(0x80 | lnxnflhd);
                    ++n7;
                    break;
                }
                case 44: {
                    if (this.LNXNFFSN || this.LNXNFFHX || n2 != 0 || n7 == n8 || n9 < 0 || lnxnflhd == 0) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    b = true;
                    this.lnxnfgps[n7] = (byte)lnxnflhd;
                    ++n7;
                    n9 = 1;
                    break;
                }
                case 99:
                case 108:
                case 117: {
                    if (this.LNXNFFCH || this.LNXNFFCT || this.LNXNFFRC || this.LNXNFFSN || this.LNXNFFDS || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    if (lowerCase == 99) {
                        n3 += 7;
                        this.LNXNFFIC = true;
                    }
                    else if (lowerCase == 108) {
                        n3 += 10;
                    }
                    else {
                        n3 += 10;
                        this.LNXNFFUN = true;
                    }
                    if (n5 == n6) {
                        this.LNXNFFCH = true;
                        break;
                    }
                    if (i == 2) {
                        c = Character.toLowerCase(charArray[n5 + 1]);
                    }
                    else if (i == 3) {
                        c = Character.toLowerCase(charArray[n5 + 1]);
                        c2 = Character.toLowerCase(charArray[n5 + 2]);
                    }
                    if (i == 1 || (i == 2 && c == 's') || (i == 3 && ((c == 'p' && c2 == 'r') || (c == 'p' && c2 == 't') || (c == 'm' && c2 == 'i')))) {
                        this.LNXNFFCT = true;
                        break;
                    }
                    if (this.LNXNFF05) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFRC = true;
                }
                case 100: {
                    if (n9 > 0 || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    n9 = -1;
                }
                case 118: {
                    if (lowerCase == 118) {
                        this.LNXNFNRD = true;
                    }
                }
                case 46: {
                    if (this.LNXNFFSN || this.LNXNFFHX || n2 != 0) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    n2 = 1;
                    this.lnxnflhd = lnxnflhd;
                    if (n != 0) {
                        this.lnxnfzld = lnxnflhd - n + 1;
                        n = 0;
                    }
                    else {
                        this.lnxnfzld = 0;
                    }
                    lnxnflhd = 0;
                    if (lowerCase != 46 && lowerCase != 100) {
                        break;
                    }
                    ++n3;
                    if (lowerCase != 46) {
                        break;
                    }
                    if (n9 < 0) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    n9 = 1;
                    this.LNXNFRDX = true;
                    break;
                }
                case 98: {
                    if (this.LNXNFFSN || this.LNXNFFBL || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFBL = true;
                    break;
                }
                case 101: {
                    if (this.LNXNFFSN || this.LNXNFF05 || this.LNXNFFHX || b) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFSN = true;
                    if (i < 4 || charArray[n5] != charArray[n5 + 1] || charArray[n5] != charArray[n5 + 2] || charArray[n5] != charArray[n5 + 3]) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    n5 += 3;
                    i -= 3;
                    n3 += 5;
                    break;
                }
                case 36: {
                    if (this.LNXNFFSN || this.LNXNFFDS || this.LNXNFFCH || this.LNXNFFCT || this.LNXNFFRC || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFDS = true;
                    ++n3;
                    break;
                }
                case 114: {
                    if (n5 != n6 || i != 2) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFRN = true;
                    if (charArray[n5] == 'r') {
                        this.LNXNFFLC = true;
                    }
                    this.lnxnfsiz = 15;
                    this.LNXNFFVF = true;
                    return;
                }
                case 102: {
                    if (n5 != n6 || !this.LNXNFFIL) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFIL = false;
                    ++n5;
                    if (Character.toLowerCase(charArray[n5]) == 'm') {
                        --i;
                        n6 = n5 + 1;
                        lowerCase = 109;
                        break;
                    }
                    throw new SQLException(CoreException.getMessage((byte)5));
                }
                case 112: {
                    if (this.LNXNFFSH || this.LNXNFFST || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    ++n3;
                    if (--i > 1) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    ++n5;
                    if (Character.toLowerCase(charArray[n5]) == 'r') {
                        this.LNXNFFPR = true;
                        break;
                    }
                    if (Character.toLowerCase(charArray[n5]) == 't') {
                        this.LNXNFFPT = true;
                        break;
                    }
                    throw new SQLException(CoreException.getMessage((byte)5));
                }
                case 109: {
                    if (this.LNXNFFSH || this.LNXNFFST || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFMI = true;
                    ++n5;
                    if (Character.toLowerCase(charArray[n5]) != 'i') {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    if (--i > 1) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    break;
                }
                case 115: {
                    if (this.LNXNFFSH || this.LNXNFFHX) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    if (n5 == n6) {
                        this.LNXNFFSH = true;
                        ++n6;
                        break;
                    }
                    if (i == 1) {
                        this.LNXNFFST = true;
                        break;
                    }
                    throw new SQLException(CoreException.getMessage((byte)5));
                }
                case 116: {
                    if (n5 != n6 || i < 2 || i > 3) {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    if (Character.toLowerCase(charArray[n5 + 1]) != 'm') {
                        throw new SQLException(CoreException.getMessage((byte)5));
                    }
                    this.LNXNFFTM = true;
                    this.LNXNFFIL = false;
                    switch ((i == 3) ? Character.toLowerCase(charArray[n5 + 2]) : '9') {
                        case '9': {
                            break;
                        }
                        case 'e': {
                            this.LNXNFFSN = true;
                            break;
                        }
                        default: {
                            throw new SQLException(CoreException.getMessage((byte)5));
                        }
                    }
                    this.lnxnflhd = 0;
                    this.lnxnfrhd = 0;
                    this.lnxnfsiz = 64;
                    this.lnxnfzld = 0;
                    this.lnxnfztr = 0;
                    this.LNXNFFVF = true;
                    return;
                }
                default: {
                    throw new SQLException(CoreException.getMessage((byte)5));
                }
            }
            n4 = lowerCase;
            ++n5;
            --i;
        }
        if (n2 != 0) {
            this.lnxnfrhd = lnxnflhd;
            this.lnxnfztr = ((this.LNXNFFIL || this.LNXNFNRD) ? lnxnflhd : n);
        }
        else {
            this.lnxnflhd = lnxnflhd;
            this.lnxnfzld = ((n != 0) ? (lnxnflhd - n + 1) : 0);
            this.lnxnfrhd = 0;
            this.lnxnfztr = 0;
            this.LNXNFNRD = true;
        }
        if (this.LNXNFFSN) {
            if (this.lnxnflhd <= 1) {
                if (this.lnxnflhd == 0) {
                    throw new SQLException(CoreException.getMessage((byte)5));
                }
            }
            else {
                this.lnxnflhd = 1;
            }
            if (this.lnxnfzld > 1) {
                this.lnxnfzld = 1;
            }
        }
        final int lnxnfsiz = n3 + this.lnxnflhd + this.lnxnfrhd + (n7 + 1);
        if (lnxnfsiz > 64) {
            throw new SQLException(CoreException.getMessage((byte)5));
        }
        this.lnxnfsiz = lnxnfsiz;
    }
}
