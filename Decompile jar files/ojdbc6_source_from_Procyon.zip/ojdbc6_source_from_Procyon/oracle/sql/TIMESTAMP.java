// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.TimeZone;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;
import java.sql.Timestamp;
import java.sql.Date;
import java.sql.Time;
import java.io.Serializable;

public class TIMESTAMP extends Datum implements Serializable
{
    static final int CENTURY_DEFAULT = 119;
    static final int DECADE_DEFAULT = 100;
    static final int MONTH_DEFAULT = 1;
    static final int DAY_DEFAULT = 1;
    static final int DECADE_INIT = 170;
    static final int JAVA_YEAR = 1970;
    static final int JAVA_MONTH = 0;
    static final int JAVA_DATE = 1;
    public static final int SIZE_DATE = 7;
    public static final int SIZE_TIMESTAMP = 11;
    public static final int SIZE_TIMESTAMP_NOFRAC = 7;
    static final int SIZE_TIMESTAMPTZ = 13;
    static final int MINYEAR = -4712;
    static final int MAXYEAR = 9999;
    static final int JANMONTH = 1;
    static final int DECMONTH = 12;
    static final int MINDAYS = 1;
    static final int MAXDAYS = 31;
    static final int MINHOURS = 1;
    static final int MAXHOURS = 24;
    static final int MINMINUTES = 1;
    static final int MAXMINUTES = 60;
    static final int MINSECONDS = 1;
    static final int MAXSECONDS = 60;
    static final int[] daysInMonth;
    static final long serialVersionUID = -7964732752952728545L;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public TIMESTAMP() {
        super(initTimestamp());
    }
    
    public TIMESTAMP(final byte[] array) {
        super(array);
    }
    
    public TIMESTAMP(final Time time) {
        super(toBytes(time));
    }
    
    public TIMESTAMP(final Date date) {
        super(toBytes(date));
    }
    
    public TIMESTAMP(final Timestamp timestamp) {
        super(toBytes(timestamp));
    }
    
    public TIMESTAMP(final Timestamp timestamp, final Calendar calendar) {
        super(toBytes(timestamp, calendar));
    }
    
    public TIMESTAMP(final DATE date) {
        super(toBytes(date));
    }
    
    public static final int getNanos(final byte[] array, final int n) {
        return (array[n] & 0xFF) << 24 | (array[n + 1] & 0xFF) << 16 | (array[n + 2] & 0xFF) << 8 | (array[n + 3] & 0xFF & 0xFF);
    }
    
    public TIMESTAMP(final String s) {
        super(toBytes(s));
    }
    
    public static Date toDate(final byte[] array) throws SQLException {
        int[] array2;
        if (array.length == 11) {
            array2 = new int[11];
        }
        else {
            array2 = new int[7];
        }
        for (int i = 0; i < array.length; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int value = (array2[0] - 100) * 100 + (array2[1] - 100);
        final Calendar instance = Calendar.getInstance();
        instance.set(1, value);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        return new Date(instance.getTime().getTime());
    }
    
    public static Time toTime(final byte[] array) throws SQLException {
        return new Time((array[4] & 0xFF) - 1, (array[5] & 0xFF) - 1, (array[6] & 0xFF) - 1);
    }
    
    public static Timestamp toTimestamp(final byte[] array) throws SQLException {
        final int length = array.length;
        int[] array2;
        if (length == 11) {
            array2 = new int[11];
        }
        else {
            array2 = new int[7];
        }
        for (int i = 0; i < array.length; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int value = (array2[0] - 100) * 100 + (array2[1] - 100);
        final Calendar instance = Calendar.getInstance();
        instance.set(1, value);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        final Timestamp timestamp = new Timestamp(instance.getTime().getTime());
        int nanos = 0;
        if (length == 11) {
            nanos = getNanos(array, 7);
        }
        timestamp.setNanos(nanos);
        return timestamp;
    }
    
    public static Timestamp toTimestamp(final byte[] array, Calendar instance) throws SQLException {
        final int length = array.length;
        int[] array2;
        if (length == 11) {
            array2 = new int[11];
        }
        else {
            array2 = new int[7];
        }
        for (int i = 0; i < array.length; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int value = (array2[0] - 100) * 100 + (array2[1] - 100);
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.set(1, value);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        final Timestamp timestamp = new Timestamp(instance.getTime().getTime());
        int nanos = 0;
        if (length == 11) {
            nanos = getNanos(array, 7);
        }
        timestamp.setNanos(nanos);
        return timestamp;
    }
    
    public static DATE toDATE(final byte[] array) throws SQLException {
        final byte[] array2 = new byte[7];
        System.arraycopy(array, 0, array2, 0, 7);
        return new DATE(array2);
    }
    
    @Override
    public Timestamp timestampValue() throws SQLException {
        return toTimestamp(this.getBytes());
    }
    
    @Override
    public Timestamp timestampValue(final Calendar calendar) throws SQLException {
        return toTimestamp(this.getBytes(), calendar);
    }
    
    public static String toString(final byte[] array) {
        final int[] array2 = new int[array.length];
        for (int i = 0; i < array.length; ++i) {
            if (array[i] < 0) {
                array2[i] = array[i] + 256;
            }
            else {
                array2[i] = array[i];
            }
        }
        final int n = (array2[0] - 100) * 100 + (array2[1] - 100);
        final int n2 = array2[2];
        final int n3 = array2[3];
        final int n4 = array2[4] - 1;
        final int n5 = array2[5] - 1;
        final int n6 = array2[6] - 1;
        int nanos = 0;
        if (array.length > 7) {
            nanos = getNanos(array, 7);
        }
        return TIMESTAMPTZ.toString(n, n2, n3, n4, n5, n6, nanos, null);
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    public static byte[] toBytes(final Time time) {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[7];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        array[0] = 119;
        array[1] = 100;
        array[3] = (array[2] = 1);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        return array;
    }
    
    public static byte[] toBytes(final Date time) {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[7];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        array[0] = (byte)(instance.get(1) / 100 + 100);
        array[1] = (byte)(instance.get(1) % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = 1;
        array[6] = (array[5] = 1);
        return array;
    }
    
    public static byte[] toBytes(final Timestamp time) {
        if (time == null) {
            return null;
        }
        final int nanos = time.getNanos();
        byte[] array;
        if (nanos == 0) {
            array = new byte[7];
        }
        else {
            array = new byte[11];
        }
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        array[0] = (byte)(instance.get(1) / 100 + 100);
        array[1] = (byte)(instance.get(1) % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        if (nanos != 0) {
            array[7] = (byte)(nanos >> 24);
            array[8] = (byte)(nanos >> 16 & 0xFF);
            array[9] = (byte)(nanos >> 8 & 0xFF);
            array[10] = (byte)(nanos & 0xFF);
        }
        return array;
    }
    
    public static byte[] toBytes(final Timestamp time, Calendar instance) {
        if (time == null) {
            return null;
        }
        final int nanos = time.getNanos();
        byte[] array;
        if (nanos == 0) {
            array = new byte[7];
        }
        else {
            array = new byte[11];
        }
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.setTime(time);
        int value = instance.get(1);
        if (instance.get(0) == 0) {
            value = -(value - 1);
        }
        if (value < -4712 || value > 9999) {
            throw new IllegalArgumentException("Invalid year value");
        }
        array[0] = (byte)(value / 100 + 100);
        array[1] = (byte)(value % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        if (nanos != 0) {
            array[7] = (byte)(nanos >> 24);
            array[8] = (byte)(nanos >> 16 & 0xFF);
            array[9] = (byte)(nanos >> 8 & 0xFF);
            array[10] = (byte)(nanos & 0xFF);
        }
        return array;
    }
    
    public static byte[] toBytes(final DATE date) {
        if (date == null) {
            return null;
        }
        final byte[] array = new byte[7];
        System.arraycopy(date.getBytes(), 0, array, 0, 7);
        return array;
    }
    
    public static byte[] toBytes(final String s) {
        return toBytes(Timestamp.valueOf(s));
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this.timestampValue();
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Timestamp[n];
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.sql.Date") == 0 || clazz.getName().compareTo("java.sql.Time") == 0 || clazz.getName().compareTo("java.sql.Timestamp") == 0 || clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    public static TIMESTAMP TimeZoneConvert(final Connection connection, final TIMESTAMP timestamp, final TimeZone zone, final TimeZone zone2) throws SQLException {
        final byte[] bytes = timestamp.getBytes();
        final int length = bytes.length;
        int[] array;
        if (length == 11) {
            array = new int[11];
        }
        else {
            array = new int[7];
        }
        for (int i = 0; i < length; ++i) {
            array[i] = (bytes[i] & 0xFF);
        }
        final int value = (array[0] - 100) * 100 + (array[1] - 100);
        final Calendar instance = Calendar.getInstance(zone);
        final Calendar instance2 = Calendar.getInstance(zone2);
        instance.set(1, value);
        instance.set(2, array[2] - 1);
        instance.set(5, array[3]);
        instance.set(11, array[4] - 1);
        instance.set(12, array[5] - 1);
        instance.set(13, array[6] - 1);
        instance.set(14, 0);
        TIMESTAMPLTZ.TimeZoneAdjust(connection, instance, instance2);
        final Timestamp timestamp2 = new Timestamp(instance2.getTime().getTime());
        int nanos = 0;
        if (length == 11) {
            nanos = getNanos(bytes, 7);
        }
        timestamp2.setNanos(nanos);
        return new TIMESTAMP(timestamp2);
    }
    
    @Override
    public String stringValue() {
        return toString(this.getBytes());
    }
    
    @Override
    public String toString() {
        return this.stringValue();
    }
    
    @Override
    public Date dateValue() throws SQLException {
        return toDate(this.getBytes());
    }
    
    @Override
    public Time timeValue() throws SQLException {
        return toTime(this.getBytes());
    }
    
    private static byte[] initTimestamp() {
        return new byte[] { 119, -86, 1, 1, 1, 1, 1, 0, 0, 0, 0 };
    }
    
    private boolean isLeapYear(final int n) {
        return n % 4 == 0 && ((n > 1582) ? (n % 100 != 0 || n % 400 == 0) : (n != -4712));
    }
    
    private boolean isValid() {
        final byte[] bytes = this.getBytes();
        if (bytes.length != 11 && bytes.length != 7) {
            return false;
        }
        final int n = ((bytes[0] & 0xFF) - 100) * 100 + ((bytes[1] & 0xFF) - 100);
        if (n < -4712 || n > 9999) {
            return false;
        }
        if (n == 0) {
            return false;
        }
        final int n2 = bytes[2] & 0xFF;
        if (n2 < 1 || n2 > 12) {
            return false;
        }
        final int n3 = bytes[3] & 0xFF;
        if (n3 < 1 || n3 > 31) {
            return false;
        }
        if (n3 > TIMESTAMP.daysInMonth[n2 - 1] && (!this.isLeapYear(n) || n2 != 2 || n3 != 29)) {
            return false;
        }
        if (n == 1582 && n2 == 10 && n3 >= 5 && n3 < 15) {
            return false;
        }
        final int n4 = bytes[4] & 0xFF;
        if (n4 < 1 || n4 > 24) {
            return false;
        }
        final int n5 = bytes[5] & 0xFF;
        if (n5 < 1 || n5 > 60) {
            return false;
        }
        final int n6 = bytes[6] & 0xFF;
        return n6 >= 1 && n6 <= 60;
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        if (!this.isValid()) {
            throw new IOException("Invalid TIMESTAMP");
        }
    }
    
    static {
        daysInMonth = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
