// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ByteArrayInputStream;
import java.io.Reader;
import java.io.OutputStream;
import java.io.InputStream;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import java.sql.Blob;

public class BLOB extends DatumWithConnection implements Blob
{
    public static final int MAX_CHUNK_SIZE = 32768;
    public static final int DURATION_SESSION = 10;
    public static final int DURATION_CALL = 12;
    static final int OLD_WRONG_DURATION_SESSION = 1;
    static final int OLD_WRONG_DURATION_CALL = 2;
    public static final int MODE_READONLY = 0;
    public static final int MODE_READWRITE = 1;
    BlobDBAccess dbaccess;
    int dbChunkSize;
    boolean isFree;
    boolean fromObject;
    private long cachedLobLength;
    private byte[] prefetchData;
    private int prefetchDataSize;
    private boolean activePrefetch;
    static final int KDLCTLSIZE = 16;
    static final int KDF_FLAG = 88;
    static final int KDLIDDAT = 8;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected BLOB() {
        this.dbChunkSize = -1;
        this.isFree = false;
        this.fromObject = false;
        this.cachedLobLength = -1L;
        this.prefetchDataSize = 0;
        this.activePrefetch = false;
    }
    
    public BLOB(final OracleConnection oracleConnection) throws SQLException {
        this(oracleConnection, null);
    }
    
    public BLOB(final OracleConnection oracleConnection, final byte[] array, final boolean fromObject) throws SQLException {
        this(oracleConnection, array);
        this.fromObject = fromObject;
    }
    
    public BLOB(final OracleConnection physicalConnectionOf, final byte[] array) throws SQLException {
        super(array);
        this.dbChunkSize = -1;
        this.isFree = false;
        this.fromObject = false;
        this.cachedLobLength = -1L;
        this.prefetchDataSize = 0;
        this.activePrefetch = false;
        DatumWithConnection.assertNotNull(physicalConnectionOf);
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.dbaccess = this.getPhysicalConnection().createBlobDBAccess();
    }
    
    @Override
    public long length() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        long n;
        if (this.activePrefetch && this.cachedLobLength != -1L) {
            n = this.cachedLobLength;
        }
        else if (this.canReadBasicLobDataInLocator()) {
            n = this.dilLength();
        }
        else {
            n = this.getDBAccess().length(this);
        }
        return n;
    }
    
    @Override
    public byte[] getBytes(final long n, final int b) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (b < 0 || n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getBytes()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetBytes(n, b);
        }
        Object o = null;
        if (b == 0) {
            return new byte[0];
        }
        if (this.activePrefetch && (this.cachedLobLength == 0L || (this.cachedLobLength > 0L && n - 1L >= this.cachedLobLength))) {
            o = null;
        }
        else {
            byte[] array;
            if (this.activePrefetch && this.cachedLobLength != -1L) {
                array = new byte[Math.min((int)this.cachedLobLength, b)];
            }
            else {
                array = new byte[b];
            }
            final long n2 = this.getBytes(n, b, array);
            if (n2 > 0L) {
                if (n2 == b) {
                    o = array;
                }
                else {
                    o = new byte[(int)n2];
                    System.arraycopy(array, 0, o, 0, (int)n2);
                }
            }
        }
        return (byte[])o;
    }
    
    @Override
    public InputStream getBinaryStream() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetBinaryStream(1L);
        }
        return this.getDBAccess().newInputStream(this, this.getBufferSize(), 0L);
    }
    
    @Override
    public long position(final byte[] array, final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().position(this, array, n);
    }
    
    @Override
    public long position(final Blob blob, final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().position(this, (BLOB)blob, n);
    }
    
    public int getBytes(final long n, final int n2, final byte[] array) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().getBytes(this, n, n2, array);
    }
    
    @Deprecated
    public int putBytes(final long n, final byte[] array) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.setBytes(n, array);
    }
    
    @Deprecated
    public int putBytes(final long n, final byte[] array, final int n2) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.setBytes(n, array, 0, n2);
    }
    
    @Deprecated
    public OutputStream getBinaryOutputStream() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.setBinaryStream(1L);
    }
    
    public byte[] getLocator() {
        return this.getBytes();
    }
    
    public void setLocator(final byte[] bytes) {
        this.setBytes(bytes);
    }
    
    public int getChunkSize() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.dbChunkSize <= 0) {
            this.dbChunkSize = this.getDBAccess().getChunkSize(this);
        }
        return this.dbChunkSize;
    }
    
    public int getBufferSize() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int chunkSize = this.getChunkSize();
        int n;
        if (chunkSize >= 32768 || chunkSize <= 0) {
            n = 32768;
        }
        else {
            n = 32768 / chunkSize * chunkSize;
        }
        return n;
    }
    
    @Deprecated
    public static BLOB empty_lob() throws SQLException {
        return getEmptyBLOB();
    }
    
    public static BLOB getEmptyBLOB() throws SQLException {
        final byte[] shareBytes = new byte[86];
        shareBytes[1] = 84;
        shareBytes[5] = 24;
        final BLOB blob = new BLOB();
        blob.setShareBytes(shareBytes);
        return blob;
    }
    
    public boolean isEmptyLob() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (this.shareBytes()[5] & 0x10) != 0x0;
    }
    
    public boolean isSecureFile() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (this.shareBytes()[7] & 0xFFFFFF80) != 0x0;
    }
    
    @Deprecated
    public OutputStream getBinaryOutputStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().newOutputStream(this, this.getBufferSize(), n, false);
    }
    
    public InputStream getBinaryStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetBinaryStream(n);
        }
        return this.getDBAccess().newInputStream(this, this.getBufferSize(), n);
    }
    
    @Deprecated
    public void trim(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.truncate(n);
    }
    
    public static BLOB createTemporary(final Connection connection, final boolean b, final int n) throws SQLException {
        int n2 = n;
        if (n == 1) {
            n2 = 10;
        }
        if (n == 2) {
            n2 = 12;
        }
        if (connection == null || (n2 != 10 && n2 != 12)) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 68, "'conn' should not be null and 'duration' should either be equal to DURATION_SESSION or to DURATION_CALL");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final oracle.jdbc.internal.OracleConnection physicalConnectionWithin = ((OracleConnection)connection).physicalConnectionWithin();
        return getDBAccess(physicalConnectionWithin).createTemporaryBlob(physicalConnectionWithin, b, n2);
    }
    
    public static void freeTemporary(final BLOB blob) throws SQLException {
        if (blob == null) {
            return;
        }
        blob.freeTemporary();
    }
    
    public static boolean isTemporary(final BLOB blob) throws SQLException {
        return blob != null && blob.isTemporary();
    }
    
    public void freeTemporary() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().freeTemporary(this, this.fromObject);
    }
    
    public boolean isTemporary() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().isTemporary(this);
    }
    
    public void open(final int n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().open(this, n);
    }
    
    public void close() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().close(this);
    }
    
    public boolean isOpen() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().isOpen(this);
    }
    
    @Override
    public int setBytes(final long n, final byte[] array) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().putBytes(this, n, array, 0, (array != null) ? array.length : 0);
    }
    
    @Override
    public int setBytes(final long n, final byte[] array, final int n2, final int n3) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().putBytes(this, n, array, n2, n3);
    }
    
    @Override
    public OutputStream setBinaryStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().newOutputStream(this, this.getBufferSize(), n, true);
    }
    
    @Override
    public void truncate(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n < 0L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "'len' should be >= 0. ");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.getDBAccess().trim(this, n);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.io.InputStream") == 0 || name.compareTo("java.io.Reader") == 0;
    }
    
    @Override
    public Reader characterStreamValue() throws SQLException {
        final BlobDBAccess dbAccess = this.getDBAccess();
        this.getInternalConnection();
        return dbAccess.newConversionReader(this, 8);
    }
    
    @Override
    public InputStream asciiStreamValue() throws SQLException {
        final BlobDBAccess dbAccess = this.getDBAccess();
        this.getInternalConnection();
        return dbAccess.newConversionInputStream(this, 2);
    }
    
    @Override
    public InputStream binaryStreamValue() throws SQLException {
        return this.getBinaryStream();
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new BLOB[n];
    }
    
    public BlobDBAccess getDBAccess() throws SQLException {
        if (this.dbaccess == null) {
            if (this.isEmptyLob()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 98);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.dbaccess = this.getInternalConnection().createBlobDBAccess();
        }
        if (this.getPhysicalConnection().isClosed()) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return this.dbaccess;
    }
    
    public static BlobDBAccess getDBAccess(final Connection connection) throws SQLException {
        return ((OracleConnection)connection).physicalConnectionWithin().createBlobDBAccess();
    }
    
    @Override
    public Connection getJavaSqlConnection() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return super.getJavaSqlConnection();
    }
    
    public final void setLength(final long cachedLobLength) {
        this.cachedLobLength = cachedLobLength;
    }
    
    public final void setChunkSize(final int dbChunkSize) {
        this.dbChunkSize = dbChunkSize;
    }
    
    public final void setPrefetchedData(final byte[] array) {
        if (array == null) {
            this.setPrefetchedData(null, 0);
        }
        else {
            this.setPrefetchedData(array, array.length);
        }
    }
    
    public final void setPrefetchedData(final byte[] prefetchData, final int prefetchDataSize) {
        this.prefetchData = prefetchData;
        this.prefetchDataSize = prefetchDataSize;
    }
    
    public final byte[] getPrefetchedData() {
        return this.prefetchData;
    }
    
    public final int getPrefetchedDataSize() {
        return this.prefetchDataSize;
    }
    
    public final void setActivePrefetch(final boolean activePrefetch) {
        if (this.activePrefetch && !activePrefetch) {
            this.clearCachedData();
        }
        this.activePrefetch = activePrefetch;
    }
    
    public final void clearCachedData() {
        this.cachedLobLength = -1L;
        this.prefetchData = null;
    }
    
    public final boolean isActivePrefetch() {
        return this.activePrefetch;
    }
    
    boolean canReadBasicLobDataInLocator() throws SQLException {
        final byte[] shareBytes = this.shareBytes();
        if (shareBytes == null || shareBytes.length < 102) {
            return false;
        }
        if (!this.getPhysicalConnection().isDataInLocatorEnabled()) {
            return false;
        }
        final int n = shareBytes[6] & 0xFF;
        final int n2 = shareBytes[7] & 0xFF;
        final boolean b = (n & 0x8) == 0x8;
        final boolean b2 = (n2 & 0xFFFFFF80) == 0xFFFFFF80;
        boolean b3 = false;
        if (b && !b2) {
            b3 = ((shareBytes[88] & 0xFF & 0x8) == 0x8);
        }
        return b && !b2 && b3;
    }
    
    int dilLength() {
        return this.shareBytes().length - 86 - 16;
    }
    
    byte[] dilGetBytes(final long n, final int n2) throws SQLException {
        if (n2 == 0) {
            return new byte[0];
        }
        if (this.dilLength() == 0) {
            return null;
        }
        final int n3 = (int)Math.min(n2, this.dilLength() - (n - 1L));
        if (n3 <= 0) {
            return null;
        }
        final byte[] array = new byte[n3];
        System.arraycopy(this.shareBytes(), (int)(n - 1L) + 86 + 16, array, 0, n3);
        return array;
    }
    
    InputStream dilGetBinaryStream(final long n) throws SQLException {
        if (n - 1L > this.dilLength()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new ByteArrayInputStream(this.dilGetBytes(n, this.dilLength()));
    }
    
    @Override
    public void free() throws SQLException {
        if (this.isFree) {
            return;
        }
        if (this.isOpen()) {
            this.close();
        }
        if (this.isTemporary()) {
            this.freeTemporary();
        }
        this.isFree = true;
        this.dbaccess = null;
    }
    
    @Override
    public InputStream getBinaryStream(final long n, final long n2) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetBinaryStream(n, n2);
        }
        final long length = this.length();
        if (n < 1L || n2 < 0L || n > length || n - 1L + n2 > length) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return this.getDBAccess().newInputStream(this, this.getChunkSize(), n, n2);
    }
    
    InputStream dilGetBinaryStream(final long n, final long n2) throws SQLException {
        final int dilLength = this.dilLength();
        if (n < 1L || n2 < 0L || n > dilLength || n - 1L + n2 > dilLength) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new ByteArrayInputStream(this.dilGetBytes(n, dilLength - (int)(n - 1L)), 0, (int)n2);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
