// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.math.BigDecimal;
import java.sql.SQLException;

public class BINARY_FLOAT extends Datum
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public BINARY_FLOAT() {
    }
    
    public BINARY_FLOAT(final byte[] array) {
        super(array);
    }
    
    public BINARY_FLOAT(final float n) {
        super(floatToCanonicalFormatBytes(n));
    }
    
    public BINARY_FLOAT(final Float n) {
        super(floatToCanonicalFormatBytes(n));
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return new Float(canonicalFormatBytesToFloat(this.getBytes()));
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.lang.String") == 0 || name.compareTo("java.lang.Float") == 0;
    }
    
    @Override
    public String stringValue() {
        return Float.toString(canonicalFormatBytesToFloat(this.getBytes()));
    }
    
    @Override
    public float floatValue() throws SQLException {
        return canonicalFormatBytesToFloat(this.getBytes());
    }
    
    @Override
    public double doubleValue() throws SQLException {
        return this.floatValue();
    }
    
    @Override
    public BigDecimal bigDecimalValue() throws SQLException {
        return new BigDecimal(this.floatValue());
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Float[n];
    }
    
    static byte[] floatToCanonicalFormatBytes(final float n) {
        float value = n;
        if (value == 0.0f) {
            value = 0.0f;
        }
        else if (value != value) {
            value = Float.NaN;
        }
        final int floatToIntBits = Float.floatToIntBits(value);
        final byte[] array = new byte[4];
        int n2 = floatToIntBits;
        int n5;
        int n4;
        final int n3 = (n4 = (n5 = floatToIntBits >> 8) >> 8) >> 8;
        int n6;
        if ((n3 & 0x80) == 0x0) {
            n6 = (n3 | 0x80);
        }
        else {
            n6 = ~n3;
            n4 ^= -1;
            n5 ^= -1;
            n2 ^= -1;
        }
        array[3] = (byte)n2;
        array[2] = (byte)n5;
        array[1] = (byte)n4;
        array[0] = (byte)n6;
        return array;
    }
    
    static float canonicalFormatBytesToFloat(final byte[] array) {
        final byte b = array[0];
        final byte b2 = array[1];
        final byte b3 = array[2];
        final byte b4 = array[3];
        int n;
        int n2;
        int n3;
        int n4;
        if ((b & 0x80) != 0x0) {
            n = (b & 0x7F);
            n2 = (b2 & 0xFF);
            n3 = (b3 & 0xFF);
            n4 = (b4 & 0xFF);
        }
        else {
            n = (~b & 0xFF);
            n2 = (~b2 & 0xFF);
            n3 = (~b3 & 0xFF);
            n4 = (~b4 & 0xFF);
        }
        return Float.intBitsToFloat(n << 24 | n2 << 16 | n3 << 8 | n4);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
