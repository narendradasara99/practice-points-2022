// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.net.URL;
import java.io.StreamCorruptedException;
import java.io.ObjectInputStream;
import java.util.zip.ZipInputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.ObjectOutputStream;
import java.util.zip.ZipEntry;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.util.zip.ZipFile;
import java.io.InputStream;
import java.util.zip.ZipOutputStream;
import java.io.FileOutputStream;

public class ConverterArchive
{
    private String m_izipName;
    private FileOutputStream m_ifStream;
    private ZipOutputStream m_izStream;
    private InputStream m_riStream;
    private ZipFile m_rzipFile;
    private static final String TEMPFILE = "gsstemp.zip";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public ConverterArchive() {
        this.m_ifStream = null;
        this.m_izStream = null;
        this.m_riStream = null;
        this.m_rzipFile = null;
    }
    
    public void openArchiveforInsert(final String izipName) {
        this.m_izipName = izipName;
        try {
            this.m_ifStream = new FileOutputStream(this.m_izipName);
            this.m_izStream = new ZipOutputStream(this.m_ifStream);
        }
        catch (FileNotFoundException ex) {}
        catch (IOException ex2) {}
    }
    
    public void closeArchiveforInsert() {
        try {
            this.m_izStream.close();
            this.m_ifStream.close();
        }
        catch (IOException ex) {}
    }
    
    public void insertObj(final Object obj, final String name) {
        final ZipEntry e = new ZipEntry(name);
        try {
            this.m_izStream.putNextEntry(e);
            final ObjectOutputStream objectOutputStream = new ObjectOutputStream(this.m_izStream);
            objectOutputStream.writeObject(obj);
            objectOutputStream.close();
            this.m_izStream.closeEntry();
        }
        catch (IOException ex) {}
    }
    
    public void insertSingleObj(final String x, final Object o, final String s) throws IOException {
        final File dest = new File(x);
        if (dest.isFile()) {
            try {
                final ZipInputStream in = new ZipInputStream(new FileInputStream(x));
                final ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream("gsstemp.zip"));
                ZipEntry nextEntry;
                while ((nextEntry = in.getNextEntry()) != null) {
                    if (!nextEntry.getName().equals(s)) {
                        zipOutputStream.putNextEntry(nextEntry);
                        new ObjectOutputStream(zipOutputStream).writeObject(new ObjectInputStream(in).readObject());
                    }
                }
                zipOutputStream.putNextEntry(new ZipEntry(s));
                final ObjectOutputStream objectOutputStream = new ObjectOutputStream(zipOutputStream);
                objectOutputStream.writeObject(o);
                objectOutputStream.close();
                in.close();
            }
            catch (FileNotFoundException ex) {
                throw new IOException(ex.getMessage());
            }
            catch (StreamCorruptedException ex2) {
                throw new IOException(ex2.getMessage());
            }
            catch (IOException ex3) {
                throw ex3;
            }
            catch (ClassNotFoundException ex4) {
                throw new IOException(ex4.getMessage());
            }
            final File file = new File("gsstemp.zip");
            dest.delete();
            try {
                if (!file.renameTo(dest)) {
                    throw new IOException("can't write to target file " + x);
                }
            }
            catch (SecurityException ex5) {
                throw new IOException(ex5.getMessage());
            }
            catch (NullPointerException ex6) {
                throw new IOException(ex6.getMessage());
            }
        }
        else {
            try {
                final ZipOutputStream out = new ZipOutputStream(new FileOutputStream(x));
                out.putNextEntry(new ZipEntry(s));
                final ObjectOutputStream objectOutputStream2 = new ObjectOutputStream(out);
                objectOutputStream2.writeObject(o);
                objectOutputStream2.close();
            }
            catch (FileNotFoundException ex7) {
                throw new IOException(ex7.getMessage());
            }
            catch (StreamCorruptedException ex8) {
                throw new IOException(ex8.getMessage());
            }
            catch (IOException ex9) {
                throw ex9;
            }
        }
        System.out.print(s + " has been successfully stored in ");
        System.out.println(x);
    }
    
    public void insertObjtoFile(final String s, final String s2, final Object obj) throws IOException {
        final File file = new File(s);
        final File file2 = new File(s + s2);
        if (!file.isDirectory()) {
            throw new IOException("directory " + s + " doesn't exist");
        }
        if (file2.exists()) {
            try {
                file2.delete();
            }
            catch (SecurityException ex) {
                throw new IOException("file exist,can't overwrite file.");
            }
        }
        try {
            final ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(file2));
            objectOutputStream.writeObject(obj);
            objectOutputStream.close();
        }
        catch (FileNotFoundException ex2) {
            throw new IOException("file can't be created.");
        }
        System.out.print(s2 + " has been successfully stored in ");
        System.out.println(s);
    }
    
    public void openArchiveforRead() {
        try {
            this.m_rzipFile = new ZipFile(this.m_izipName);
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(0);
        }
    }
    
    public void closeArchiveforRead() {
        try {
            this.m_rzipFile.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
            System.exit(0);
        }
    }
    
    public Object readObj(final String name) {
        final URL resource = this.getClass().getResource(name);
        ObjectInputStream objectInputStream = null;
        InputStream openStream = null;
        if (resource == null) {
            return null;
        }
        try {
            openStream = resource.openStream();
            objectInputStream = new ObjectInputStream(openStream);
            return objectInputStream.readObject();
        }
        catch (IOException ex) {}
        catch (ClassNotFoundException ex2) {}
        finally {
            try {
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
                if (openStream != null) {
                    openStream.close();
                }
            }
            catch (IOException ex3) {}
        }
        return null;
    }
    
    public Object readObj(final String name, final String anObject) {
        try {
            final ZipInputStream in = new ZipInputStream(new FileInputStream(name));
            Object object = null;
            while (in.available() != 0) {
                final ZipEntry nextEntry = in.getNextEntry();
                if (nextEntry != null && nextEntry.getName().equals(anObject)) {
                    object = new ObjectInputStream(in).readObject();
                    break;
                }
            }
            in.close();
            return object;
        }
        catch (IOException ex) {}
        catch (ClassNotFoundException ex2) {}
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
