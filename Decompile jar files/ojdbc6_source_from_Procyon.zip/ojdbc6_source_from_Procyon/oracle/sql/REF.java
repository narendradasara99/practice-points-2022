// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.OraclePreparedStatement;
import java.util.Map;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import java.io.Serializable;
import java.sql.Ref;

public class REF extends DatumWithConnection implements Ref, Serializable, Cloneable
{
    static final boolean DEBUG = false;
    static final long serialVersionUID = 1328446996944583167L;
    String typename;
    transient StructDescriptor descriptor;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    public String getBaseTypeName() throws SQLException {
        if (this.typename == null) {
            if (this.descriptor == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 52);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.typename = this.descriptor.getName();
        }
        return this.typename;
    }
    
    public REF(final String typename, final Connection physicalConnectionOf, final byte[] array) throws SQLException {
        super(array);
        if (physicalConnectionOf == null || typename == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.typename = typename;
        this.descriptor = null;
        this.setPhysicalConnectionOf(physicalConnectionOf);
    }
    
    public REF(final StructDescriptor descriptor, final Connection physicalConnectionOf, final byte[] array) throws SQLException {
        super(array);
        if (physicalConnectionOf == null || descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.descriptor = descriptor;
        this.setPhysicalConnectionOf(physicalConnectionOf);
    }
    
    public Object getValue(final Map map) throws SQLException {
        final STRUCT struct = this.getSTRUCT();
        return (struct != null) ? struct.toJdbc(map) : null;
    }
    
    public Object getValue() throws SQLException {
        final STRUCT struct = this.getSTRUCT();
        return (struct != null) ? struct.toJdbc() : null;
    }
    
    public STRUCT getSTRUCT() throws SQLException {
        synchronized (this.getInternalConnection()) {
            STRUCT struct = null;
            final OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)this.getInternalConnection().prepareStatement("select deref(:1) from dual");
            oraclePreparedStatement.setRowPrefetch(1);
            oraclePreparedStatement.setREF(1, this);
            final OracleResultSet set = (OracleResultSet)oraclePreparedStatement.executeQuery();
            try {
                if (!set.next()) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 52);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                struct = set.getSTRUCT(1);
            }
            finally {
                set.close();
                oraclePreparedStatement.close();
            }
            return struct;
        }
    }
    
    public void setValue(final Object o) throws SQLException {
        synchronized (this.getInternalConnection()) {
            final STRUCT struct = STRUCT.toSTRUCT(o, this.getInternalConnection());
            if (struct.getInternalConnection() != this.getInternalConnection()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 77, "Incompatible connection object");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (!this.getBaseTypeName().equals(struct.getSQLTypeName())) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 77, "Incompatible type");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final byte[] bytes = struct.toBytes();
            final byte[] toid = struct.getDescriptor().getOracleTypeADT().getTOID();
            CallableStatement prepareCall = null;
            try {
                prepareCall = this.getInternalConnection().prepareCall("begin :1 := dbms_pickler.update_through_ref (:2, :3, :4, :5); end;");
                prepareCall.registerOutParameter(1, 2);
                prepareCall.setBytes(2, this.shareBytes());
                prepareCall.setInt(3, 0);
                prepareCall.setBytes(4, toid);
                prepareCall.setBytes(5, bytes);
                prepareCall.execute();
                final int int1;
                if ((int1 = prepareCall.getInt(1)) != 0) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 77, "ORA-" + int1);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
            }
            finally {
                if (prepareCall != null) {
                    prepareCall.close();
                }
            }
        }
    }
    
    public StructDescriptor getDescriptor() throws SQLException {
        if (this.descriptor == null) {
            this.descriptor = StructDescriptor.createDescriptor(this.typename, this.getInternalConnection());
        }
        return this.descriptor;
    }
    
    public String getSQLTypeName() throws SQLException {
        return this.getBaseTypeName();
    }
    
    @Override
    public Object getObject(final Map map) throws SQLException {
        final STRUCT struct = this.getSTRUCT();
        return (struct != null) ? struct.toJdbc(map) : null;
    }
    
    @Override
    public Object getObject() throws SQLException {
        final STRUCT struct = this.getSTRUCT();
        return (struct != null) ? struct.toJdbc() : null;
    }
    
    @Override
    public void setObject(final Object o) throws SQLException {
        PreparedStatement prepareStatement = null;
        try {
            prepareStatement = this.getInternalConnection().prepareStatement("call sys.utl_ref.update_object( :1, :2 )");
            prepareStatement.setRef(1, this);
            prepareStatement.setObject(2, o);
            prepareStatement.execute();
        }
        finally {
            if (prepareStatement != null) {
                prepareStatement.close();
            }
        }
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return false;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new REF[n];
    }
    
    public Object clone() throws CloneNotSupportedException {
        REF ref;
        try {
            ref = new REF(this.getBaseTypeName(), this.getInternalConnection(), this.getBytes());
        }
        catch (SQLException ex) {
            throw new CloneNotSupportedException(ex.getMessage());
        }
        return ref;
    }
    
    @Override
    public boolean equals(final Object o) {
        boolean b = false;
        try {
            b = (o instanceof REF && super.equals(o) && this.getBaseTypeName().equals(((REF)o).getSQLTypeName()));
        }
        catch (Exception ex) {}
        return b;
    }
    
    @Override
    public int hashCode() {
        final byte[] shareBytes = this.shareBytes();
        int n = 0;
        if ((shareBytes[2] & 0x5) == 0x5) {
            for (int i = 0; i < 4; ++i) {
                n = n * 256 + (shareBytes[8 + i] & 0xFF);
            }
        }
        else if ((shareBytes[2] & 0x3) == 0x3) {
            for (int n2 = 0; n2 < 4 && n2 < shareBytes.length; ++n2) {
                n = n * 256 + (shareBytes[6 + n2] & 0xFF);
            }
        }
        else if ((shareBytes[2] & 0x2) == 0x2) {
            for (int j = 0; j < 4; ++j) {
                n = n * 256 + (shareBytes[8 + j] & 0xFF);
            }
        }
        return n;
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.writeObject(this.shareBytes());
        try {
            objectOutputStream.writeUTF(this.getBaseTypeName());
        }
        catch (SQLException ex) {
            throw new IOException(ex.getMessage());
        }
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        this.setBytes((byte[])objectInputStream.readObject());
        this.typename = objectInputStream.readUTF();
    }
    
    @Override
    public Connection getJavaSqlConnection() throws SQLException {
        return super.getJavaSqlConnection();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
