// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.Reader;
import java.io.InputStream;
import java.sql.SQLException;

public interface BfileDBAccess
{
    long length(final BFILE p0) throws SQLException;
    
    long position(final BFILE p0, final byte[] p1, final long p2) throws SQLException;
    
    long position(final BFILE p0, final BFILE p1, final long p2) throws SQLException;
    
    int getBytes(final BFILE p0, final long p1, final int p2, final byte[] p3) throws SQLException;
    
    String getName(final BFILE p0) throws SQLException;
    
    String getDirAlias(final BFILE p0) throws SQLException;
    
    void openFile(final BFILE p0) throws SQLException;
    
    boolean isFileOpen(final BFILE p0) throws SQLException;
    
    boolean fileExists(final BFILE p0) throws SQLException;
    
    void closeFile(final BFILE p0) throws SQLException;
    
    void open(final BFILE p0, final int p1) throws SQLException;
    
    void close(final BFILE p0) throws SQLException;
    
    boolean isOpen(final BFILE p0) throws SQLException;
    
    InputStream newInputStream(final BFILE p0, final int p1, final long p2) throws SQLException;
    
    InputStream newConversionInputStream(final BFILE p0, final int p1) throws SQLException;
    
    Reader newConversionReader(final BFILE p0, final int p1) throws SQLException;
}
