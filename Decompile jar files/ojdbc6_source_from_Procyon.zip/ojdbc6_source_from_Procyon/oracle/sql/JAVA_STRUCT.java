// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.driver.DatabaseError;
import java.util.Hashtable;
import java.util.Map;
import java.sql.SQLException;
import java.sql.Connection;

public class JAVA_STRUCT extends STRUCT
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public JAVA_STRUCT(final StructDescriptor structDescriptor, final Connection connection, final Object[] array) throws SQLException {
        super(structDescriptor, connection, array);
    }
    
    public JAVA_STRUCT(final StructDescriptor structDescriptor, final byte[] array, final Connection connection) throws SQLException {
        super(structDescriptor, array, connection);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        Map<String, Class> javaObjectTypeMap = (Map<String, Class>)this.getInternalConnection().getJavaObjectTypeMap();
        Class clazz = null;
        if (javaObjectTypeMap != null) {
            clazz = this.descriptor.getClass(javaObjectTypeMap);
        }
        else {
            javaObjectTypeMap = new Hashtable<String, Class>(10);
            this.getInternalConnection().setJavaObjectTypeMap(javaObjectTypeMap);
        }
        if (clazz == null) {
            final String javaObjectClassName = StructDescriptor.getJavaObjectClassName(this.getInternalConnection(), this.getDescriptor());
            final String schemaName = this.getDescriptor().getSchemaName();
            if (javaObjectClassName == null || javaObjectClassName.length() == 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            try {
                clazz = this.getInternalConnection().classForNameAndSchema(javaObjectClassName, schemaName);
            }
            catch (ClassNotFoundException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, "ClassNotFoundException: " + ex.getMessage());
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            javaObjectTypeMap.put(this.getSQLTypeName(), clazz);
        }
        return this.toClass(clazz, this.getMap());
    }
    
    @Override
    public Object toJdbc(final Map map) throws SQLException {
        return this.toJdbc();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
