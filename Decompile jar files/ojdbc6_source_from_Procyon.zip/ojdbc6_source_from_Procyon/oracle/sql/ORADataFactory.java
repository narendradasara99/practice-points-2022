// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.internal.ObjectDataFactory;

public interface ORADataFactory extends ObjectDataFactory
{
    ORAData create(final Datum p0, final int p1) throws SQLException;
}
