// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.text.DecimalFormatSymbols;
import java.util.Locale;
import oracle.core.lmx.CoreException;
import java.sql.SQLException;

class LnxLibThin implements LnxLib
{
    private static final byte[] lnxqone;
    private static final byte[] lnxqtwo;
    private static final int LNXQACOS = 0;
    private static final int LNXQASIN = 1;
    private static final int LNXQATAN = 2;
    private static final int LNXQCOS = 3;
    private static final int LNXQSIN = 4;
    private static final int LNXQTAN = 5;
    private static final int LNXQCSH = 6;
    private static final int LNXQSNH = 7;
    private static final int LNXQTNH = 8;
    private static final int LNXQEXP = 9;
    private static final int LNXM_NUM = 22;
    private static final int LNXDIGS = 20;
    private static final int LNXSGNBT = 128;
    private static final int LNXEXPMX = 127;
    private static final int LNXEXPMN = 0;
    private static final int LNXEXPBS = 64;
    private static final int LNXBASE = 100;
    private static final int LNXMXFMT = 64;
    private static final int LNXMXOUT = 40;
    private static final int LNXDIV_LNXBASE_SQUARED = 10000;
    private static final int MINUB1MAXVAL = 255;
    private static final double ORANUM_FBASE = 100.0;
    private static final int LNXQNOSGN = 127;
    private static final char LNXNFT_COMMA = ',';
    private static final int LNXBYTEMASK = 255;
    private static final int LNXSHORTMASK = 65535;
    private static byte[] LnxqFirstDigit;
    private static byte[] LnxqNegate;
    private static byte[] LnxqTruncate_P;
    private static byte[] LnxqTruncate_N;
    private static byte[] LnxqRound_P;
    private static byte[] LnxqRound_N;
    private static byte[][] LnxqComponents_P;
    private static byte[][] LnxqComponents_N;
    private static byte[][] LnxqAdd_PPP;
    private static byte[][] LnxqAdd_NNN;
    private static byte[][] LnxqAdd_PNP;
    private static byte[][] LnxqAdd_PNN;
    private static byte[] LnxsubIdentity;
    private static byte[][] LnxqDigit_P;
    private static byte[][] LnxqDigit_N;
    private static final double[][] powerTable;
    private static final double[][] factorTable;
    private char[] lnx_chars;
    
    LnxLibThin() {
        this.lnx_chars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '-', ' ', '.', ',', '$', '<', '>', '(', ')', '#', '~', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'i', 'l', 'm', 'p', 'r', 's', 't', 'v', 'A', 'B', 'C', 'D', 'E', 'F', 'I', 'L', 'M', 'P', 'R', 'S', 'T' };
    }
    
    @Override
    public byte[] lnxabs(final byte[] array) throws SQLException {
        final byte[] array2 = new byte[array.length];
        if (NUMBER._isPositive(array)) {
            System.arraycopy(array, 0, array2, 0, array.length);
            return array2;
        }
        if (NUMBER._isNegInf(array)) {
            return NUMBER.posInf().shareBytes();
        }
        int length = array.length;
        if (array[length - 1] == 102) {
            --length;
        }
        System.arraycopy(array, 0, array2, 0, length);
        _negateNumber(array2);
        return _setLength(array2, length);
    }
    
    @Override
    public byte[] lnxacos(final byte[] array) throws SQLException {
        return this.lnxqtri(array, 0);
    }
    
    @Override
    public byte[] lnxadd(final byte[] array, final byte[] array2) throws SQLException {
        int length = array.length;
        final int n = 0;
        int length2 = array2.length;
        final int n2 = 0;
        final byte[] array3 = new byte[41];
        final int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = n3 + 1;
        final boolean isPositive = NUMBER._isPositive(array);
        final int n7 = (array[0] < 0) ? (256 + array[0]) : (255 - array[0]);
        if (!isPositive && array[length - 1] == 102) {
            --length;
        }
        final int n8 = length - 1;
        final boolean isPositive2 = NUMBER._isPositive(array2);
        final int n9 = (array2[0] < 0) ? (256 + array2[0]) : (255 - array2[0]);
        if (!isPositive2 && array2[length2 - 1] == 102) {
            --length2;
        }
        final int n10 = length2 - 1;
        if (n7 == 255 && (n8 == 0 || array[1] == 101)) {
            if (isPositive) {
                return NUMBER._makePosInf();
            }
            return NUMBER._makeNegInf();
        }
        else if (n9 == 255 && (n10 == 0 || array2[1] == 101)) {
            if (isPositive2) {
                return NUMBER._makePosInf();
            }
            return NUMBER._makeNegInf();
        }
        else {
            if (n7 == 128 && n8 == 0) {
                final byte[] array4 = new byte[length2];
                System.arraycopy(array2, 0, array4, 0, length2);
                return _setLength(array4, length2);
            }
            if (n9 == 128 && n10 == 0) {
                final byte[] array5 = new byte[length];
                System.arraycopy(array, 0, array5, 0, length);
                return _setLength(array5, length);
            }
            int n11 = n7 - n9;
            boolean b;
            byte[][] array6;
            byte b2;
            byte b3;
            if (isPositive == isPositive2) {
                b = isPositive;
                if (b) {
                    array6 = LnxLibThin.LnxqAdd_PPP;
                    b2 = 1;
                    b3 = 1;
                }
                else {
                    array6 = LnxLibThin.LnxqAdd_NNN;
                    b2 = 101;
                    b3 = -1;
                }
            }
            else {
                int n12 = n11;
                if (n12 == 0) {
                    int n13;
                    int n14;
                    int n15;
                    for (n13 = n + 1, n14 = n2 + 1, n15 = n + ((n8 < n10) ? n8 : n10); n13 <= n15 && array[n13] + array2[n14] == 102; ++n13, ++n14) {}
                    if (n13 <= n15) {
                        n12 = (isPositive ? (array[n13] + array2[n14] - 102) : (102 - (array[n13] + array2[n14])));
                    }
                    else {
                        n12 = n8 - n10;
                    }
                }
                if (n12 == 0) {
                    return NUMBER._makeZero();
                }
                b = ((n12 > 0) ? isPositive : isPositive2);
                if (b) {
                    array6 = LnxLibThin.LnxqAdd_PNP;
                    b2 = 1;
                    b3 = -1;
                }
                else {
                    array6 = LnxLibThin.LnxqAdd_PNN;
                    b2 = 101;
                    b3 = 1;
                }
            }
            int n16;
            int n17;
            int n18;
            int n19;
            int n20;
            int n21;
            int n22;
            int n23;
            int n24;
            boolean b4;
            if (n11 >= 0) {
                n16 = n7;
                if (n11 + n10 <= n8) {
                    n17 = n11;
                    n18 = n10;
                    n19 = n8 - (n11 + n10);
                    n20 = n + n17;
                    n21 = 1;
                    n4 = n20 + n18;
                    n5 = n2 + n10;
                    n22 = n + n8;
                    n23 = 1;
                    n24 = n8;
                    b4 = (n19 != 0 && isPositive != b);
                }
                else if (n11 < n8) {
                    n17 = n11;
                    n18 = n8 - n11;
                    n19 = n10 - n18;
                    n20 = n + n17;
                    n21 = 1;
                    n4 = n + n8;
                    n5 = n2 + n18;
                    n22 = n2 + n10;
                    n23 = 2;
                    n24 = n11 + n10;
                    b4 = (isPositive2 != b);
                }
                else {
                    n17 = n8;
                    n18 = -(n11 - n8);
                    n19 = n10;
                    n20 = n + n8;
                    n21 = 1;
                    n22 = n2 + n10;
                    n23 = 2;
                    n24 = n11 + n10;
                    b4 = (isPositive2 != b);
                }
            }
            else {
                n16 = n9;
                n11 = -n11;
                if (n11 + n8 <= n10) {
                    n17 = n11;
                    n18 = n8;
                    n19 = n10 - (n11 + n8);
                    n20 = n2 + n17;
                    n21 = 2;
                    n4 = n + n8;
                    n5 = n20 + n18;
                    n22 = n2 + n10;
                    n23 = 2;
                    n24 = n10;
                    b4 = (n19 != 0 && isPositive2 != b);
                }
                else if (n11 < n10) {
                    n17 = n11;
                    n18 = n10 - n11;
                    n19 = n8 - n18;
                    n20 = n2 + n17;
                    n21 = 2;
                    n4 = n + n18;
                    n5 = n2 + n10;
                    n22 = n + n8;
                    n23 = 1;
                    n24 = n11 + n8;
                    b4 = (isPositive != b);
                }
                else {
                    n17 = n10;
                    n18 = -(n11 - n10);
                    n19 = n8;
                    n20 = n2 + n10;
                    n21 = 2;
                    n22 = n + n8;
                    n23 = 1;
                    n24 = n11 + n8;
                    b4 = (isPositive != b);
                }
            }
            if (n24 > 20) {
                if (n11 > 20) {
                    n18 = 0;
                    n19 = 0;
                    n24 = n17;
                    b4 = false;
                }
                else {
                    n6 = 1;
                }
            }
            int i;
            int n25 = i = n6 + (n24 - 1);
            if (n19 != 0) {
                final int n26 = i - n19;
                if (n23 == 1) {
                    array3[i] = array[n22];
                }
                else {
                    array3[i] = array2[n22];
                }
                --n22;
                --i;
                if (b4) {
                    while (i > n26) {
                        if (n23 == 1) {
                            array3[i] = (byte)(array[n22] + b3);
                        }
                        else {
                            array3[i] = (byte)(array2[n22] + b3);
                        }
                        --n22;
                        --i;
                    }
                }
                else {
                    while (i > n26) {
                        if (n23 == 1) {
                            array3[i] = array[n22];
                        }
                        else {
                            array3[i] = array2[n22];
                        }
                        --n22;
                        --i;
                    }
                }
            }
            if (n18 > 0) {
                final int n27 = i - n18;
                final byte b5 = 0;
                int n28 = b4 ? (b5 + 1) : b5;
                do {
                    n28 = b5 + array[n4] + array2[n5] + array6[n28][1];
                    array3[i] = array6[n28][0];
                    --n4;
                    --n5;
                } while (--i > n27);
                b4 = ((array6[n28][1] & 0x1) != 0x0);
            }
            else {
                final byte b6 = (byte)(b4 ? ((b3 == 1) ? 2 : 100) : b2);
                while (i > i + n18) {
                    array3[i] = b6;
                    --i;
                }
            }
            if (n17 != 0) {
                final int n29 = i - n17;
                if (b4) {
                    final int n30 = ((b3 == 1) ? 100 : 1) + (b ? 0 : 1);
                    final int n31 = ((b3 == 1) ? 1 : 100) + (b ? 0 : 1);
                    do {
                        if (n21 == 1) {
                            b4 = (array[n20] == n30);
                            array3[i] = (byte)(b4 ? n31 : (array[n20] + b3));
                        }
                        else {
                            b4 = (array2[n20] == n30);
                            array3[i] = (byte)(b4 ? n31 : (array2[n20] + b3));
                        }
                        --n20;
                        --i;
                    } while (b4 && i > n29);
                }
                while (i > n29) {
                    if (n21 == 1) {
                        array3[i] = array[n20];
                    }
                    else {
                        array3[i] = array2[n20];
                    }
                    --n20;
                    --i;
                }
            }
            if (b4) {
                if (n16 == 255) {
                    if (b) {
                        return NUMBER._makePosInf();
                    }
                    return NUMBER._makeNegInf();
                }
                else {
                    --n6;
                    array3[n6] = (byte)(b ? 2 : 100);
                    ++n16;
                    ++n24;
                }
            }
            if (array3[n6] == b2) {
                do {
                    ++n6;
                    --n16;
                    --n24;
                } while (array3[n6] == b2);
                if (n16 < 128) {
                    return NUMBER._makeZero();
                }
            }
            if (n24 > 20) {
                n25 = n6 + 19;
                n24 = 20;
                if ((b ? array3[n25 + 1] : LnxLibThin.LnxqNegate[array3[n25 + 1]]) > 50) {
                    final int n32 = b ? 100 : 2;
                    if (!b4) {
                        array3[n6 - 1] = b2;
                    }
                    while (array3[n25] == n32) {
                        --n25;
                        --n24;
                    }
                    if (n25 < n6) {
                        if (n16 == 255) {
                            if (b) {
                                return NUMBER._makePosInf();
                            }
                            return NUMBER._makeNegInf();
                        }
                        else {
                            --n6;
                            ++n16;
                            n24 = 1;
                        }
                    }
                    final byte[] array7 = array3;
                    final int n33 = n25;
                    array7[n33] += (byte)(b ? 1 : -1);
                }
            }
            while (array3[n25] == b2) {
                --n25;
                --n24;
            }
            if (n6 != 1) {
                final byte[] array8 = new byte[41];
                System.arraycopy(array3, n6, array8, 1, n24);
                System.arraycopy(array8, 1, array3, 1, n24);
            }
            int n34 = n24 + 1;
            if (!b && n34 <= 20) {
                array3[n34] = 102;
                ++n34;
            }
            array3[n3] = (byte)(b ? (n16 - 256) : (255 - n16));
            return _setLength(array3, n34);
        }
    }
    
    @Override
    public byte[] lnxasin(final byte[] array) throws SQLException {
        return this.lnxqtri(array, 1);
    }
    
    @Override
    public byte[] lnxatan(final byte[] array) throws SQLException {
        return this.lnxqtri(array, 2);
    }
    
    @Override
    public byte[] lnxatan2(final byte[] array, final byte[] array2) throws SQLException {
        if (NUMBER._isZero(array) && NUMBER._isZero(array2)) {
            throw new SQLException(CoreException.getMessage((byte)11));
        }
        final byte[] lnxatan = this.lnxatan(this.lnxdiv(array, array2));
        if (NUMBER._isPositive(array2)) {
            return lnxatan;
        }
        final byte[] shareBytes = NUMBER.pi().shareBytes();
        if (NUMBER._isPositive(array)) {
            return this.lnxadd(lnxatan, shareBytes);
        }
        return this.lnxsub(lnxatan, shareBytes);
    }
    
    @Override
    public byte[] lnxbex(final byte[] array, final byte[] array2) throws SQLException {
        switch (this.lnxsgn(array)) {
            case 1: {
                return this.lnxexp(this.lnxmul(array2, this.lnxln(array)));
            }
            case 0: {
                if (NUMBER._isZero(array2)) {
                    final byte[] array3 = new byte[LnxLibThin.lnxqone.length];
                    System.arraycopy(LnxLibThin.lnxqone, 0, array3, 0, LnxLibThin.lnxqone.length);
                    return array3;
                }
                return NUMBER._makeZero();
            }
            case -1: {
                if (new NUMBER(array2).isInt()) {
                    byte[] array4 = this.lnxexp(this.lnxmul(array2, this.lnxln(this.lnxneg(array))));
                    if (!NUMBER._isZero(this.lnxmod(array2, LnxLibThin.lnxqtwo))) {
                        array4 = this.lnxneg(array4);
                    }
                    return array4;
                }
                return NUMBER._makePosInf();
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public byte[] lnxcos(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 3);
    }
    
    @Override
    public byte[] lnxcsh(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 6);
    }
    
    @Override
    public byte[] lnxdec(final byte[] array) throws SQLException {
        int length = array.length;
        final byte[] array2 = new byte[22];
        System.arraycopy(array, 0, array2, 0, length);
        if (NUMBER._isPositive(array2)) {
            int n = (byte)((array2[0] & 0xFFFFFF7F) - 65);
            if (n >= 0 && n <= 18) {
                int i = n + 1;
                final int n2 = length - 1;
                if (i <= n2) {
                    final byte[] array3 = array2;
                    final int n3 = i;
                    --array3[n3];
                    if (array2[i] == 1 && i == n2 && --length == 1) {
                        return NUMBER._makeZero();
                    }
                }
                else {
                    final byte[] array4 = array2;
                    final int n4 = n2;
                    --array4[n4];
                    while (i > n2) {
                        array2[i] = 100;
                        --i;
                    }
                    if (array2[1] == 1) {
                        for (int j = 1; j <= n; ++j) {
                            array2[j] = array2[j + 1];
                        }
                        --n;
                    }
                    length = n + 2;
                }
                array2[0] = (byte)(n + 128 + 64 + 1);
                final byte[] array5 = new byte[length];
                System.arraycopy(array2, 0, array5, 0, length);
                return array5;
            }
        }
        return NUMBER._makeZero();
    }
    
    @Override
    public byte[] lnxdiv(final byte[] array, final byte[] array2) throws SQLException {
        int length = array.length;
        int length2 = array2.length;
        final byte[] array3 = new byte[22];
        final int[] array4 = new int[22];
        final int[] array5 = new int[10];
        final int[] array6 = new int[13];
        final boolean b = array[0] >> 7 != 0;
        byte b2 = array[0];
        if (!b) {
            b2 ^= -1;
            if (array[length - 1] == 102) {
                --length;
            }
        }
        final boolean b3 = array2[0] >> 7 != 0;
        byte b4 = array2[0];
        if (!b3) {
            b4 ^= -1;
            if (array2[length2 - 1] == 102) {
                --length2;
            }
        }
        if ((b4 & 0xFF) == 0x80 && length2 == 1) {
            if (b == b3) {
                return NUMBER._makePosInf();
            }
            return NUMBER._makeNegInf();
        }
        else {
            if ((b2 & 0xFF) == 0x80 && length == 1) {
                return NUMBER._makeZero();
            }
            int n;
            if (length == 1) {
                n = 0;
            }
            else {
                n = 1;
            }
            if (((b2 & 0xFF) == 0xFF && (length == 2 || array[n] == 101)) || (length == 1 && array[0] == 0)) {
                if (b == b3) {
                    return NUMBER._makePosInf();
                }
                return NUMBER._makeNegInf();
            }
            else {
                int n2;
                if (length2 == 1) {
                    n2 = 0;
                }
                else {
                    n2 = 1;
                }
                if (((b4 & 0xFF) == 0xFF && (length2 == 2 || array2[n2] == 101)) || (length2 == 1 && array2[0] == 0)) {
                    return NUMBER._makeZero();
                }
                final int n3 = length / 2 - 1;
                int i = 21;
                int j = length - 2;
                while (i > n3) {
                    array4[i] = 0;
                    --i;
                }
                if (b) {
                    if ((length & 0x1) == 0x0) {
                        array4[i] = array[j + 1] * 100 - 100;
                        --j;
                        --i;
                    }
                    while (j > 0) {
                        array4[i] = array[j] * 100 + array[j + 1] - 101;
                        j -= 2;
                        --i;
                    }
                }
                else {
                    if ((length & 0x1) == 0x0) {
                        array4[i] = 10100 - array[j + 1] * 100;
                        --j;
                        --i;
                    }
                    while (j > 0) {
                        array4[i] = 10201 - (array[j] * 100 + array[j + 1]);
                        j -= 2;
                        --i;
                    }
                }
                int n5;
                final int n4 = n5 = length2 / 2 - 1;
                int k = length2 - 2;
                if (b3) {
                    if ((length2 & 0x1) == 0x0) {
                        array5[n5] = array2[k + 1] * 100 - 100;
                        --k;
                        --n5;
                    }
                    while (k > 0) {
                        array5[n5] = array2[k] * 100 + array2[k + 1] - 101;
                        k -= 2;
                        --n5;
                    }
                }
                else {
                    if ((length2 & 0x1) == 0x0) {
                        array5[n5] = 10100 - array2[k + 1] * 100;
                        --k;
                        --n5;
                    }
                    while (k > 0) {
                        array5[n5] = 10201 - (array2[k] * 100 + array2[k + 1]);
                        k -= 2;
                        --n5;
                    }
                }
                int n6 = 0;
                int l = -1;
                if (length2 <= 3) {
                    int n7 = 0;
                    int n8 = array4[0];
                    final int n9 = array5[0];
                    do {
                        final int n10 = n8 / n9;
                        ++n7;
                        n8 = (n8 - n10 * n9) * 10000 + array4[n7];
                        ++l;
                        array6[l] = n10;
                        if (n8 == 0 && n7 >= n3) {
                            break;
                        }
                    } while (l < 10 + ((array6[0] == 0) ? 2 : 1));
                }
                else {
                    int n11 = 0;
                    int n12 = n4;
                    double n13 = array4[n11] * 10000 + (double)array4[n11 + 1];
                    final double n14 = array5[0] * 10000 + (double)array5[1];
                    do {
                        int n15 = (int)(n13 / n14);
                        if (n15 != 0) {
                            for (int n16 = n11 + 2, n17 = 2; n16 <= n12; ++n16, ++n17) {
                                final int[] array7 = array4;
                                final int n18 = n16;
                                array7[n18] -= n15 * array5[n17];
                            }
                        }
                        n13 = (n13 - n15 * n14) * 10000.0 + array4[n11 + 2];
                        if (n15 >= 10000) {
                            int n19;
                            for (n19 = l; array6[n19] == 9999; --n19) {
                                array6[n19] = 0;
                            }
                            final int[] array8 = array6;
                            final int n20 = n19;
                            ++array8[n20];
                            n15 -= 10000;
                        }
                        if (n15 < 0) {
                            int n21;
                            for (n21 = l; array6[n21] == 0; --n21) {
                                array6[n21] = 9999;
                            }
                            final int[] array9 = array6;
                            final int n22 = n21;
                            --array9[n22];
                            n15 += 10000;
                        }
                        ++l;
                        array6[l] = n15;
                        if (n11 >= n3 && ((n13 < 0.0) ? (-n13) : n13) < 0.1) {
                            int n23;
                            for (n23 = n11 + 2; n23 <= n12 && array4[n23] == 0; ++n23) {}
                            if (n23 > n12) {
                                break;
                            }
                        }
                        ++n11;
                        ++n12;
                    } while (l < 10 + ((array6[0] == 0) ? 2 : 1));
                }
                if (array6[0] == 0) {
                    ++n6;
                }
                while (array6[l] == 0) {
                    --l;
                }
                int n24 = (array6[n6] >= 100) ? 1 : 0;
                int n25 = (array6[l] % 100 != 0) ? 1 : 0;
                int n26 = 2 * (l - n6) + n24 + n25;
                if (n26 > 20) {
                    if (n24 > 0) {
                        l = n6 + 9;
                        final int[] array10 = array6;
                        final int n27 = l;
                        array10[n27] += ((array6[l + 1] >= 5000) ? 1 : 0);
                    }
                    else {
                        l = n6 + 10;
                        array6[l] = (array6[l] + 50) / 100 * 100;
                    }
                    if (array6[l] == 10000) {
                        do {
                            --l;
                        } while (array6[l] == 9999);
                        final int[] array11 = array6;
                        final int n28 = l;
                        ++array11[n28];
                    }
                    if (array6[0] != 0) {
                        n6 = 0;
                    }
                    while (array6[l] == 0) {
                        --l;
                    }
                    n24 = ((array6[n6] >= 100) ? 1 : 0);
                    n25 = ((array6[l] % 100 != 0) ? 1 : 0);
                    n26 = 2 * (l - n6) + n24 + n25;
                }
                final int n29 = (b2 & 0xFF) - (b4 & 0xFF) - ((array6[0] == 0) ? 1 : 0) + 193;
                if (n29 > 255) {
                    if (b == b3) {
                        return NUMBER._makePosInf();
                    }
                    return NUMBER._makeNegInf();
                }
                else {
                    if (n29 < 128) {
                        return NUMBER._makeZero();
                    }
                    int n30 = n26 + 1;
                    final byte[] array12 = new byte[n30];
                    int n31 = n26;
                    int n32 = l;
                    if (n25 == 0) {
                        array12[n31] = (byte)(array6[n32] / 100 + 1);
                        --n31;
                        --n32;
                    }
                    while (n31 > 1) {
                        final int n33 = array6[n32] / 100;
                        array12[n31] = (byte)(array6[n32] - n33 * 100 + 1);
                        --n31;
                        array12[n31] = (byte)(n33 + 1);
                        --n31;
                        --n32;
                    }
                    if (n24 == 0) {
                        array12[n31] = (byte)(array6[n32] + 1);
                    }
                    array12[0] = (byte)n29;
                    if (b != b3) {
                        byte[] array13;
                        if (++n30 > 20) {
                            array13 = new byte[21];
                            n30 = 21;
                        }
                        else {
                            array13 = new byte[n30];
                        }
                        array13[0] = (byte)~n29;
                        int n34;
                        for (n34 = 0; n34 < n30 - 2; ++n34) {
                            array13[n34 + 1] = (byte)(102 - array12[n34 + 1]);
                        }
                        if (n30 <= 20) {
                            array13[n30 - 1] = 102;
                        }
                        else if (array12.length == 20) {
                            array13[n30 - 1] = 102;
                        }
                        else {
                            array13[n34 + 1] = (byte)(102 - array12[n34 + 1]);
                        }
                        return array13;
                    }
                    return array12;
                }
            }
        }
    }
    
    @Override
    public byte[] lnxexp(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 9);
    }
    
    @Override
    public byte[] lnxflo(final byte[] array) throws SQLException {
        byte[] array2 = this.lnxtru(array, 0);
        if (Datum.compareBytes(array2, array) != 0 && !NUMBER._isPositive(array)) {
            array2 = this.lnxsub(array2, LnxLibThin.lnxqone);
        }
        return array2;
    }
    
    @Override
    public byte[] lnxceil(final byte[] array) throws SQLException {
        byte[] array2 = this.lnxtru(array, 0);
        if (Datum.compareBytes(array2, array) != 0 && NUMBER._isPositive(array)) {
            array2 = this.lnxadd(array2, LnxLibThin.lnxqone);
        }
        return array2;
    }
    
    @Override
    public byte[] lnxfpr(final byte[] array, int n) throws SQLException {
        int length = array.length;
        if (NUMBER._isZero(array)) {
            return NUMBER._makeZero();
        }
        if (NUMBER._isNegInf(array)) {
            return NUMBER._makeNegInf();
        }
        if (NUMBER._isPosInf(array)) {
            return NUMBER._makePosInf();
        }
        if (n < 0) {
            return NUMBER._makeZero();
        }
        final boolean isPositive;
        int n2;
        boolean b;
        byte b2;
        byte b3;
        byte b4;
        if (isPositive = NUMBER._isPositive(array)) {
            n += (((array[1] & 0xFF) < 11) ? 2 : 1);
            n2 = n >> 1;
            b = ((n & 0x1) == 0x1);
            b2 = 1;
            b3 = 100;
            b4 = 1;
        }
        else {
            n += (((array[1] & 0xFF) > 91) ? 2 : 1);
            n2 = n >> 1;
            b = ((n & 0x1) == 0x1);
            b2 = 101;
            b3 = 2;
            b4 = -1;
            length -= (((array[length - 1] & 0xFF) == 0x66) ? 1 : 0);
        }
        final byte[] array2 = new byte[length];
        System.arraycopy(array, 0, array2, 0, length);
        if (n2 > length - 1 || (n2 == length - 1 && (b || LnxLibThin.LnxqFirstDigit[array[n2]] == 1))) {
            return _setLength(array, length);
        }
        if (n2 == 0) {
            if (!b) {
                return NUMBER._makeZero();
            }
            if (isPositive) {
                if (array[1] < 51) {
                    return NUMBER._makeZero();
                }
            }
            else if (array[1] > 51) {
                return NUMBER._makeZero();
            }
        }
        if (n2 == 1 && !b) {
            if (isPositive) {
                if (array[1] < 6) {
                    return NUMBER._makeZero();
                }
            }
            else if (array[1] > 96) {
                return NUMBER._makeZero();
            }
        }
        if (n2 != 0) {
            final byte b6;
            final byte b5 = b6 = (byte)n2;
            Label_0457: {
                if (b) {
                    Label_0418: {
                        if (isPositive) {
                            if (array[b5 + 1] <= 50) {
                                break Label_0418;
                            }
                        }
                        else if (array[b5 + 1] >= 52) {
                            break Label_0418;
                        }
                        array2[b6] = (byte)(array[b5] + b4);
                        break Label_0457;
                    }
                    array2[b6] = array[b5];
                }
                else {
                    array2[b6] = (isPositive ? LnxLibThin.LnxqRound_P[array[b5]] : LnxLibThin.LnxqRound_N[array[b5]]);
                }
            }
            byte b7 = (byte)(b5 - 1);
            int n3;
            if (array2[b6] == b3 + b4) {
                while (b7 > 0 && array[b7] == b3) {
                    --b7;
                }
                if (b7 == 0) {
                    if (!NUMBER._isInf(array)) {
                        array2[0] = (byte)(array[0] + b4);
                        array2[1] = (byte)(b2 + b4);
                        return _setLength(array2, 2);
                    }
                    if (isPositive) {
                        return NUMBER._makePosInf();
                    }
                    return NUMBER._makeNegInf();
                }
                else {
                    array2[b7] = (byte)(array[b7] + b4);
                    n3 = b7 + 1;
                    final byte b8 = (byte)(b7 - 1);
                }
            }
            else if (array2[b6] == b2) {
                while (array[b7] == b2) {
                    --b7;
                }
                n3 = b7 + 1;
            }
            else {
                n3 = n2 + 1;
            }
            return _setLength(array2, n3);
        }
        if (!NUMBER._isInf(array)) {
            array2[0] = (byte)(array[0] + b4);
            array2[1] = (byte)(b2 + b4);
            return _setLength(array2, 2);
        }
        if (isPositive) {
            return NUMBER._makePosInf();
        }
        return NUMBER._makeNegInf();
    }
    
    @Override
    public byte[] lnxinc(final byte[] array) throws SQLException {
        int length = array.length;
        final byte[] array2 = new byte[22];
        System.arraycopy(array, 0, array2, 0, length);
        final byte b = 0;
        int n = (byte)((array2[0] & 0xFFFFFF7F) - 65);
        if (n >= 0 && n <= 18) {
            byte b2 = (byte)(n + 1);
            final byte b3 = (byte)(length - 1);
            if (b2 <= b3) {
                if (array2[b2] < 100) {
                    final byte[] array3 = array2;
                    final byte b4 = b2;
                    ++array3[b4];
                }
                else {
                    array2[b] = 0;
                    do {
                        --b2;
                    } while (array2[b2] == 100);
                    if (b2 > b) {
                        final byte[] array4 = array2;
                        final byte b5 = b2;
                        ++array4[b5];
                    }
                    else {
                        ++n;
                        ++b2;
                        array2[b2] = 2;
                    }
                    array2[b] = (byte)(n + 128 + 64 + 1);
                    length = b2 - b + 1;
                }
            }
            else {
                array2[b2] = 2;
                for (byte b6 = (byte)(b2 - 1); b6 > b3; --b6) {
                    array2[b6] = 1;
                }
                length = n + 2;
            }
        }
        else {
            array2[0] = -63;
            array2[1] = 2;
            length = 2;
        }
        final byte[] array5 = new byte[length];
        System.arraycopy(array2, 0, array5, 0, length);
        return array5;
    }
    
    @Override
    public byte[] lnxln(final byte[] array) throws SQLException {
        if (this.lnxsgn(array) <= 0) {
            return NUMBER._makeNegInf();
        }
        if (NUMBER._isPosInf(array)) {
            return NUMBER._makePosInf();
        }
        final byte[] array2 = new byte[array.length];
        System.arraycopy(array, 0, array2, 0, array.length);
        final int n = (array2[0] & 0xFF) - 193;
        array2[0] = -63;
        final byte[] bytes = NUMBER.toBytes(Math.log(this.lnxnur(array2)));
        final byte[] lnxsub = this.lnxsub(this.lnxdiv(array2, this.lnxexp(bytes)), LnxLibThin.lnxqone);
        byte[] lnxadd = new byte[lnxsub.length];
        System.arraycopy(lnxsub, 0, lnxadd, 0, lnxsub.length);
        byte[] array3 = this.lnxmul(lnxsub, lnxsub);
        int n2 = 1;
        while ((array3[0] & 0xFF) > 172) {
            ++n2;
            final byte[] lnxsub2 = this.lnxsub(lnxadd, this.lnxqIDiv(array3, n2));
            final byte[] lnxmul = this.lnxmul(lnxsub, array3);
            ++n2;
            lnxadd = this.lnxadd(lnxsub2, this.lnxqIDiv(lnxmul, n2));
            array3 = this.lnxmul(lnxsub, lnxmul);
        }
        return this.lnxadd(this.lnxadd(this.lnxmul(this.lnxmin(n * 2), NUMBER.ln10().shareBytes()), bytes), lnxadd);
    }
    
    @Override
    public byte[] lnxlog(final byte[] array, final byte[] array2) throws SQLException {
        final double double1 = NUMBER.toDouble(array2);
        if (double1 <= 0.0) {
            return NUMBER._makeNegInf();
        }
        if (double1 == 10.0) {
            return this.lnxdiv(this.lnxln(array), NUMBER.ln10().shareBytes());
        }
        return this.lnxdiv(this.lnxln(array), this.lnxln(array2));
    }
    
    @Override
    public byte[] lnxmod(final byte[] array, final byte[] array2) throws SQLException {
        return this.lnxsub(array, this.lnxmul(array2, this.lnxtru(this.lnxdiv(array, array2), 0)));
    }
    
    @Override
    public byte[] lnxmul(final byte[] array, final byte[] array2) throws SQLException {
        byte[] array3 = array;
        int length = array3.length;
        byte[] array4 = array2;
        int length2 = array4.length;
        final byte[] array5 = new byte[22];
        final int[] array6 = new int[10];
        final int[] array7 = new int[10];
        final byte[] array8 = new byte[41];
        final int n = 0;
        int n2 = (array3[0] >> 7 != 0) ? 1 : 0;
        byte b = array3[0];
        if (n2 == 0) {
            b ^= -1;
            if (array3[length - 1] == 102) {
                --length;
            }
        }
        int n3 = (array4[0] >> 7 != 0) ? 1 : 0;
        byte b2 = array4[0];
        if (n3 == 0) {
            b2 ^= -1;
            if (array4[length2 - 1] == 102) {
                --length2;
            }
        }
        if (-b == 128 && length == 1) {
            return NUMBER._makeZero();
        }
        if (-b2 == 128 && length2 == 1) {
            return NUMBER._makeZero();
        }
        if ((b & 0xFF) == 0xFF && (length == 1 || array3[1] == 101)) {
            byte[] array9;
            if (n2 == n3) {
                array9 = NUMBER._makePosInf();
            }
            else {
                array9 = NUMBER._makeNegInf();
            }
            return array9;
        }
        if ((b2 & 0xFF) == 0xFF && (length2 == 1 || array4[1] == 101)) {
            byte[] array10;
            if (n2 == n3) {
                array10 = NUMBER._makePosInf();
            }
            else {
                array10 = NUMBER._makeNegInf();
            }
            return array10;
        }
        if (length > length2) {
            final byte[] array11 = array3;
            array3 = array4;
            array4 = array11;
            final int n4 = length;
            length = length2;
            length2 = n4;
            final int n5 = n2;
            n2 = n3;
            n3 = n5;
        }
        int n7;
        final int n6 = n7 = length / 2 - 1;
        int i = length - 2;
        if (n2 != 0) {
            if ((length & 0x1) == 0x0) {
                array6[n7] = array3[i + 1] * 100 - 100;
                --i;
                --n7;
            }
            while (i > 0) {
                array6[n7] = array3[i] * 100 + array3[i + 1] - 101;
                i -= 2;
                --n7;
            }
        }
        else {
            if ((length & 0x1) == 0x0) {
                array6[n7] = 10100 - array3[i + 1] * 100;
                --i;
                --n7;
            }
            while (i > 0) {
                array6[n7] = 10201 - (array3[i] * 100 + array3[i + 1]);
                i -= 2;
                --n7;
            }
        }
        int n9;
        final int n8 = n9 = length2 / 2 - 1;
        int j = length2 - 2;
        if (n3 != 0) {
            if ((length2 & 0x1) == 0x0) {
                array7[n9] = array4[j + 1] * 100 - 100;
                --j;
                --n9;
            }
            while (j > 0) {
                array7[n9] = array4[j] * 100 + array4[j + 1] - 101;
                j -= 2;
                --n9;
            }
        }
        else {
            if ((length2 & 0x1) == 0x0) {
                array7[n9] = 10100 - array4[j + 1] * 100;
                --j;
                --n9;
            }
            while (j > 0) {
                array7[n9] = 10201 - (array4[j] * 100 + array4[j + 1]);
                j -= 2;
                --n9;
            }
        }
        short n10;
        int n11;
        if (array6[0] * array7[0] < 1000000) {
            n10 = (short)((b & 0xFF) + (b2 & 0xFF) - 193);
            n11 = (length & 0xFE) + (length2 & 0xFE);
        }
        else {
            n10 = (short)((b & 0xFF) + (b2 & 0xFF) - 192);
            n11 = (length & 0xFE) + (length2 & 0xFE) + 1;
        }
        int n12 = 1;
        final int n13 = n11;
        int n16;
        if (length <= 3) {
            int n14 = LnxmulSetDigit1(array8, n13, array6[0] * array7[n8]);
            int n15 = n13 - 2;
            for (int k = n8 - 1; k >= 0; --k) {
                n14 = LnxmulSetDigit1(array8, n15, n14 + array6[0] * array7[k]);
                n15 -= 2;
            }
            LnxmulSetDigit2(array8, n15, n14);
            n16 = n15 - 2;
        }
        else {
            int n17 = LnxmulSetDigit1(array8, n13, n + array6[n6] * array7[n8]);
            int n18 = n13 - 2;
            int l;
            for (l = n8 - 1; l > n8 - (length / 2 - 1); --l) {
                switch (n8 - l + 1) {
                    case 9: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 8, n17);
                    }
                    case 8: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 7, n17);
                    }
                    case 7: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 6, n17);
                    }
                    case 6: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 5, n17);
                    }
                    case 5: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 4, n17);
                    }
                    case 4: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 3, n17);
                    }
                    case 3: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 2, n17);
                    }
                    case 2: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 1, n17);
                        break;
                    }
                }
                n17 = LnxmulSetDigit1(array8, n18, LnxmulSetSum(array6, array7, n6, l, 0, n17));
                n18 -= 2;
            }
            do {
                switch (length / 2) {
                    case 10: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 9, n17);
                    }
                    case 9: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 8, n17);
                    }
                    case 8: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 7, n17);
                    }
                    case 7: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 6, n17);
                    }
                    case 6: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 5, n17);
                    }
                    case 5: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 4, n17);
                    }
                    case 4: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 3, n17);
                    }
                    case 3: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 2, n17);
                    }
                    case 2: {
                        n17 = LnxmulSetSum(array6, array7, n6, l, 1, n17);
                        break;
                    }
                }
                n17 = LnxmulSetDigit1(array8, n18, LnxmulSetSum(array6, array7, n6, l, 0, n17));
                n18 -= 2;
            } while (--l >= 0);
            for (int n19 = n6 - 1; n19 > 0; --n19) {
                switch (n19 + 1) {
                    case 9: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 8, n17);
                    }
                    case 8: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 7, n17);
                    }
                    case 7: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 6, n17);
                    }
                    case 6: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 5, n17);
                    }
                    case 5: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 4, n17);
                    }
                    case 4: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 3, n17);
                    }
                    case 3: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 2, n17);
                    }
                    case 2: {
                        n17 = LnxmulSetSum(array6, array7, n19, 0, 1, n17);
                        break;
                    }
                }
                n17 = LnxmulSetDigit1(array8, n18, LnxmulSetSum(array6, array7, n19, 0, 0, n17));
                n18 -= 2;
            }
            final int lnxmulSetDigit1 = LnxmulSetDigit1(array8, n18, n17 + array6[0] * array7[0]);
            final int n20 = n18 - 2;
            LnxmulSetDigit2(array8, n20, lnxmulSetDigit1);
            n16 = n20 - 2;
        }
        if ((n11 & 0x1) == 0x0 && array8[n16] != 1) {
            ++n10;
            ++n11;
            --n12;
        }
        while (array8[n12 + n11 - 2] == 1) {
            --n11;
        }
        if (n11 > 21) {
            int n21 = n12 + 19;
            n11 = 21;
            if (array8[n21 + 1] > 50) {
                while (array8[n21] == 100) {
                    --n21;
                    --n11;
                }
                if (n21 < n12) {
                    array8[n12] = 2;
                    ++n10;
                    ++n11;
                }
                final byte[] array12 = array8;
                final int n22 = n21;
                ++array12[n22];
            }
            else {
                while (array8[n12 + n11 - 2] == 1) {
                    --n11;
                }
            }
        }
        if ((n10 & 0xFFFF) > 255) {
            if (n2 == n3) {
                return NUMBER._makePosInf();
            }
            return NUMBER._makeNegInf();
        }
        else {
            if ((n10 & 0xFFFF) < 128) {
                return NUMBER._makeZero();
            }
            byte[] array13;
            if (n2 != n3) {
                array13 = new byte[++n11];
                array13[0] = (byte)~n10;
                for (int n23 = 0; n23 < n11 - 1; ++n23) {
                    array13[n23 + 1] = (byte)(102 - array8[n12 + n23]);
                }
                array13[n11 - 1] = 102;
            }
            else {
                array13 = new byte[n11];
                array13[0] = (byte)n10;
                for (int n24 = 0; n24 < n11 - 1; ++n24) {
                    array13[n24 + 1] = array8[n12 + n24];
                }
            }
            return array13;
        }
    }
    
    private static int LnxmulSetSum(final int[] array, final int[] array2, final int n, final int n2, final int n3, final int n4) throws SQLException {
        int n5;
        try {
            n5 = n4 + array[n - n3] * array2[n2 + n3];
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            throw new SQLException(CoreException.getMessage((byte)4));
        }
        return n5;
    }
    
    private static int LnxmulSetDigit1(final byte[] array, int n, final int n2) {
        final int n3 = n2 / 100;
        final int n4 = n2 / 10000;
        n -= 2;
        array[n + 1] = (byte)(n2 - n3 * 100 + 1);
        array[n] = (byte)(n3 - n4 * 100 + 1);
        return n4;
    }
    
    private static void LnxmulSetDigit2(final byte[] array, int n, final int n2) {
        final int n3 = n2 / 100;
        n -= 2;
        array[n] = (byte)(n3 + 1);
        array[n + 1] = (byte)(n2 - n3 * 100 + 1);
    }
    
    @Override
    public byte[] lnxneg(final byte[] array) throws SQLException {
        if (NUMBER._isZero(array)) {
            return NUMBER._makeZero();
        }
        if (NUMBER._isPosInf(array)) {
            return NUMBER._makeNegInf();
        }
        if (NUMBER._isNegInf(array)) {
            return NUMBER._makePosInf();
        }
        int length = array.length;
        if (!NUMBER._isPositive(array) && array[length - 1] == 102) {
            --length;
        }
        final byte[] array2 = new byte[length];
        System.arraycopy(array, 0, array2, 0, length);
        _negateNumber(array2);
        return _setLength(array2, length);
    }
    
    @Override
    public byte[] lnxpow(final byte[] array, int i) throws SQLException {
        byte[] array2;
        if (i >= 0) {
            array2 = new byte[array.length];
            System.arraycopy(array, 0, array2, 0, array.length);
        }
        else {
            final int n = Integer.MIN_VALUE;
            if (i == n) {
                return this.lnxdiv(this.lnxpow(array, n + 1), array);
            }
            i = -i;
            array2 = this.lnxdiv(LnxLibThin.lnxqone, array);
        }
        byte[] array3 = LnxLibThin.lnxqone;
        while (i > 0) {
            if ((i & 0x1) == 0x1) {
                array3 = this.lnxmul(array3, array2);
            }
            if ((i >>= 1) > 0) {
                array2 = this.lnxmul(array2, array2);
            }
        }
        return array3;
    }
    
    @Override
    public byte[] lnxrou(final byte[] array, int n) throws SQLException {
        int length = array.length;
        final int n2 = 0;
        if (length == 1) {
            if (array[n2] == -128) {
                return NUMBER._makeZero();
            }
            return NUMBER._makeNegInf();
        }
        else {
            if (length == 2 && array[0] == -1 && array[1] == 101) {
                return NUMBER._makePosInf();
            }
            final int n3 = (array[0] < 0) ? (256 + array[0]) : array[0];
            final boolean isPositive;
            int n4;
            boolean b;
            byte b2;
            byte b3;
            byte b4;
            if (isPositive = NUMBER._isPositive(array)) {
                if (n >= 0) {
                    n4 = n3 + (n + 1 >> 1) - 192;
                    b = ((n & 0x1) != 0x0);
                }
                else {
                    n = -n;
                    n4 = n3 - (n >> 1) - 192;
                    b = ((n & 0x1) != 0x0);
                }
                b2 = 1;
                b3 = 100;
                b4 = 1;
            }
            else {
                if (n >= 0) {
                    n4 = 63 + (n + 1 >> 1) - n3;
                    b = ((n & 0x1) != 0x0);
                }
                else {
                    n = -n;
                    n4 = 63 - (n >> 1) - n3;
                    b = ((n & 0x1) != 0x0);
                }
                b2 = 101;
                b3 = 2;
                b4 = -1;
                length -= ((array[length - 1] == 102) ? 1 : 0);
            }
            final byte[] array2 = new byte[length];
            System.arraycopy(array, 0, array2, 0, length);
            if (n4 > length - 1 || (n4 == length - 1 && (!b || LnxLibThin.LnxqFirstDigit[array[n4]] == 1))) {
                return _setLength(array, length);
            }
            if (n4 >= 0) {
                if (n4 == 0) {
                    if (b) {
                        return NUMBER._makeZero();
                    }
                    if (isPositive) {
                        if (array[1] < 51) {
                            return NUMBER._makeZero();
                        }
                    }
                    else if (array[1] > 51) {
                        return NUMBER._makeZero();
                    }
                }
                if (n4 == 1 && b) {
                    if (isPositive) {
                        if (array[1] < 6) {
                            return NUMBER._makeZero();
                        }
                    }
                    else if (array[1] > 96) {
                        return NUMBER._makeZero();
                    }
                }
                if (n4 == 0) {
                    Label_0418: {
                        if (isPositive) {
                            if (array[n2] != -1) {
                                break Label_0418;
                            }
                        }
                        else if (array[n2] != 0) {
                            break Label_0418;
                        }
                        if (isPositive) {
                            return NUMBER._makePosInf();
                        }
                        return NUMBER._makeNegInf();
                    }
                    array2[0] = (byte)(array[n2] + b4);
                    array2[1] = (byte)(b2 + b4);
                    return _setLength(array2, 2);
                }
                final byte b6;
                final byte b5 = b6 = (byte)n4;
                Label_0547: {
                    if (b) {
                        array2[b5] = (isPositive ? LnxLibThin.LnxqRound_P[array[b6]] : LnxLibThin.LnxqRound_N[array[b6]]);
                    }
                    else {
                        Label_0538: {
                            if (isPositive) {
                                if (array[b6 + 1] <= 50) {
                                    break Label_0538;
                                }
                            }
                            else if (array[b6 + 1] >= 52) {
                                break Label_0538;
                            }
                            array2[b5] = (byte)(array[b6] + b4);
                            break Label_0547;
                        }
                        array2[b5] = array[b6];
                    }
                }
                byte b7 = (byte)(b6 - 1);
                int n5;
                if (array2[b5] == b3 + b4) {
                    while (b7 > n2 && array[b7] == b3) {
                        --b7;
                    }
                    if (b7 == n2) {
                        Label_0636: {
                            if (isPositive) {
                                if (array[n2] != -1) {
                                    break Label_0636;
                                }
                            }
                            else if (array[n2] != 0) {
                                break Label_0636;
                            }
                            if (isPositive) {
                                return NUMBER._makePosInf();
                            }
                            return NUMBER._makeNegInf();
                        }
                        array2[0] = (byte)(array[n2] + b4);
                        array2[1] = (byte)(b2 + b4);
                        return _setLength(array2, 2);
                    }
                    array2[b7 - n2] = (byte)(array[b7] + b4);
                    n5 = b7 - n2 + 1;
                    final byte b8 = (byte)(b7 - 1);
                }
                else if (array2[b5] == b2) {
                    while (array[b7] == b2) {
                        --b7;
                    }
                    n5 = b7 - n2 + 1;
                }
                else {
                    n5 = n4 + 1;
                }
                return _setLength(array2, n5);
            }
            return NUMBER._makeZero();
        }
    }
    
    @Override
    public byte[] lnxsca(final byte[] array, final int n, final int n2, final boolean[] array2) throws SQLException {
        int length = array.length;
        if (length == 1) {
            array2[0] = false;
            return NUMBER._makeZero();
        }
        byte b;
        byte b2;
        byte b3;
        if (NUMBER._isPositive(array)) {
            b = (byte)((array[0] & 0xFFFFFF7F) - 65);
            b2 = array[1];
            b3 = array[length - 1];
        }
        else {
            --length;
            b = (byte)((~array[0] & 0xFFFFFF7F) - 65);
            b2 = LnxLibThin.LnxqNegate[array[1]];
            b3 = LnxLibThin.LnxqNegate[array[length - 1]];
        }
        if (2 * (length - b) - ((b3 % 10 == 1) ? 1 : 0) > n2) {
            final byte[] lnxrou = this.lnxrou(array, n2);
            byte b4;
            byte b5;
            if (NUMBER._isPositive(lnxrou)) {
                b4 = (byte)((lnxrou[0] & 0xFFFFFF7F) - 65);
                b5 = (byte)((lnxrou.length != 1) ? lnxrou[1] : 1);
            }
            else {
                b4 = (byte)((~lnxrou[0] & 0xFFFFFF7F) - 65);
                b5 = LnxLibThin.LnxqNegate[lnxrou[1]];
            }
            array2[0] = (2 * (b4 + 1) - ((b5 < 11) ? 1 : 0) > n);
            return lnxrou;
        }
        final int length2 = array.length;
        final byte[] array3 = new byte[length2];
        System.arraycopy(array, 0, array3, 0, length2);
        array2[0] = (2 * (b + 1) - ((b2 < 11) ? 1 : 0) > n);
        return array3;
    }
    
    @Override
    public byte[] lnxshift(final byte[] array, final int n) throws SQLException {
        final int length = array.length;
        final byte[] array2 = new byte[22];
        int n2;
        if (length == 1) {
            n2 = 0;
        }
        else {
            n2 = 1;
        }
        if (((array[0] & 0xFF) == 0x80 && length == 1) || (length == 2 && (array[0] & 0xFF) == 0xFF && array[n2] == 101) || (length == 1 && array[0] == 0)) {
            final byte[] array3 = new byte[length];
            for (int i = 0; i < length; ++i) {
                array3[i] = array[i];
            }
            return array3;
        }
        final boolean b = array[0] >> 7 == 0;
        final int n3 = b ? (255 - array[0] & 0xFF) : (array[0] & 0xFF);
        int n4 = length;
        int n5;
        if ((n & 0x1) > 0) {
            byte[][] array4;
            byte[][] array5;
            byte b2;
            if (b) {
                if (array[n4 - 1] == 102) {
                    --n4;
                }
                array4 = LnxLibThin.LnxqComponents_N;
                array5 = LnxLibThin.LnxqDigit_N;
                b2 = 101;
            }
            else {
                array4 = LnxLibThin.LnxqComponents_P;
                array5 = LnxLibThin.LnxqDigit_P;
                b2 = 1;
            }
            if (array4[array[1]][0] != 0) {
                n5 = ((n >= 0) ? (n3 + (n / 2 + 1)) : (n3 - -n / 2));
                int j = n4 - 2;
                int n6 = n4 - 1;
                boolean b3;
                if (n4 > 20) {
                    b3 = (array4[array[j + 1]][1] >= 5);
                }
                else {
                    array2[n6 + 1] = array5[array4[array[j + 1]][1]][0];
                    ++n4;
                    b3 = false;
                }
                while (j > 0) {
                    array2[n6] = array5[array4[array[j + 0]][1]][array4[array[j + 1]][0]];
                    --j;
                    --n6;
                }
                array2[1] = array5[0][array4[array[j + 1]][0]];
                if (b3) {
                    final int n7 = b ? 2 : 100;
                    final int n8 = b ? -1 : 1;
                    int n9;
                    for (n9 = 20; array2[n9] == n7; --n9, --n4) {}
                    final byte[] array6 = array2;
                    final int n10 = n9;
                    array6[n10] += (byte)n8;
                }
            }
            else {
                n5 = ((n >= 0) ? (n3 + n / 2) : (n3 - (-n / 2 + 1)));
                int n11 = 1;
                int k;
                for (k = 1; k < n4 - 1; ++k) {
                    array2[k] = array5[array4[array[n11 + 0]][1]][array4[array[n11 + 1]][0]];
                    ++n11;
                }
                array2[k] = array5[array4[array[n11 + 0]][1]][0];
            }
            while (array2[n4 - 1] == b2) {
                --n4;
            }
            if (b) {
                ++n4;
                array2[n4 - 1] = 102;
            }
        }
        else {
            n5 = ((n >= 0) ? (n3 + n / 2) : (n3 - -n / 2));
            for (int l = 1; l < n4; ++l) {
                array2[l] = array[l];
            }
        }
        if (n5 > 255) {
            byte[] array7;
            if (b) {
                array7 = new byte[] { 0 };
            }
            else {
                array7 = new byte[] { -1, 101 };
            }
            return array7;
        }
        if (n5 < 128) {
            return new byte[] { -128 };
        }
        array2[0] = (b ? ((byte)(255 - n5)) : ((byte)n5));
        final byte[] array8 = new byte[n4];
        for (int n12 = 0; n12 < n4; ++n12) {
            array8[n12] = array2[n12];
        }
        return array8;
    }
    
    @Override
    public byte[] lnxsin(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 4);
    }
    
    @Override
    public byte[] lnxsnh(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 7);
    }
    
    @Override
    public byte[] lnxsqr(final byte[] array) throws SQLException {
        final int length = array.length;
        final int[] array2 = new int[29];
        final int[] array3 = new int[29];
        if (!NUMBER._isPositive(array)) {
            return NUMBER._makeNegInf();
        }
        if (NUMBER._isPosInf(array)) {
            return NUMBER._makePosInf();
        }
        if (NUMBER._isZero(array)) {
            return NUMBER._makeZero();
        }
        final int n = (array[0] & 0xFF) - 193;
        for (int i = 1; i < length; ++i) {
            array2[i] = array[i] - 1;
        }
        int j = 1;
        final int n2 = j + 20 + 3;
        int n3;
        if ((n + 128 & 0x1) != 0x0) {
            n3 = ((array2[j] * 100 + array2[j + 1]) * 100 + array2[j + 2]) * 100 + array2[j + 3];
            j += 3;
        }
        else {
            n3 = (array2[j] * 100 + array2[j + 1]) * 100 + array2[j + 2];
            j += 2;
        }
        final int n4 = (int)(Math.sqrt(n3) * 100.0);
        array3[1] = n4 / 10000;
        array3[2] = n4 / 100 % 100;
        array3[3] = n4 % 100;
        int n5 = ((n3 - array3[1] * n4) * 100 + array2[j + 1] - array3[2] * n4) * 100 + array2[j + 2] - array3[3] * n4;
        j += 3;
        final int n6 = n4 * 2;
        final int n7 = 3;
        int k;
        for (k = n7 + 1; j < n2; ++j, ++k) {
            final int n8 = n5 * 100 + array2[j];
            final int n9 = n8 / n6;
            n5 = n8 - n9 * n6;
            array3[k] = n9;
            final int n10 = (n7 + (n2 - j) < k) ? (n7 + (n2 - j)) : k;
            if (n9 != 0) {
                int n11 = j + 1;
                for (int l = n7 + 1; l < n10; ++l) {
                    final int[] array4 = array2;
                    final int n12 = n11;
                    array4[n12] -= 2 * n9 * array3[l];
                    ++n11;
                }
                if (n11 < n2) {
                    final int[] array5 = array2;
                    final int n13 = n11;
                    array5[n13] -= n9 * n9;
                }
            }
            else if (n5 == 0) {
                int n14;
                for (n14 = j + 1; n14 < n2 && array2[n14] == 0; ++n14) {}
                if (n14 == n2) {
                    break;
                }
            }
        }
        int n15 = k;
        --k;
        array3[0] = 0;
        while (k > 0) {
            while (array3[k] > 99) {
                final int[] array6 = array3;
                final int n16 = k;
                array6[n16] -= 100;
                final int[] array7 = array3;
                final int n17 = k - 1;
                ++array7[n17];
            }
            while (array3[k] < 0) {
                final int[] array8 = array3;
                final int n18 = k;
                array8[n18] += 100;
                final int[] array9 = array3;
                final int n19 = k - 1;
                --array9[n19];
            }
            --k;
        }
        int n20 = (n - (n + 128 & 0x1)) / 2 + 1;
        while (array3[k] == 0) {
            ++k;
            if (--n20 < -65) {
                return NUMBER._makeZero();
            }
        }
        do {
            --n15;
        } while (array3[n15] == 0);
        int n21 = n15 - k + 2;
        if (n21 > 21) {
            n15 = k + 20;
            if (array3[n15] >= 50) {
                do {
                    --n15;
                } while (array3[n15] == 99);
                final int[] array10 = array3;
                final int n22 = n15;
                ++array10[n22];
            }
            else {
                do {
                    --n15;
                } while (array3[n15] == 0);
            }
            if (n15 < k) {
                k = n15;
                if (++n20 > 62) {
                    return NUMBER._makePosInf();
                }
            }
            n21 = n15 - k + 2;
        }
        final byte[] array11 = new byte[n21];
        array11[0] = (byte)(n20 - 63);
        for (int n23 = k; n23 <= n15; ++n23) {
            array11[n23 - (k - 1)] = (byte)(array3[n23] + 1);
        }
        return array11;
    }
    
    @Override
    public byte[] lnxsub(final byte[] array, final byte[] array2) throws SQLException {
        return this.lnxadd(array, this.lnxneg(array2));
    }
    
    @Override
    public byte[] lnxtan(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 5);
    }
    
    @Override
    public byte[] lnxtnh(final byte[] array) throws SQLException {
        return this.lnxqtra(array, 8);
    }
    
    @Override
    public byte[] lnxtru(final byte[] array, int n) throws SQLException {
        int length = array.length;
        if (NUMBER._isZero(array)) {
            return NUMBER._makeZero();
        }
        if (NUMBER._isNegInf(array)) {
            return NUMBER._makeNegInf();
        }
        if (NUMBER._isPosInf(array)) {
            return NUMBER._makePosInf();
        }
        final int n2 = (array[0] < 0) ? (256 + array[0]) : array[0];
        final boolean isPositive;
        int n3;
        boolean b;
        byte b2;
        if (isPositive = NUMBER._isPositive(array)) {
            if (n >= 0) {
                n3 = n2 + (n + 1 >> 1) - 192;
                b = ((n & 0x1) == 0x1);
            }
            else {
                n = -n;
                n3 = n2 - (n >> 1) - 192;
                b = ((n & 0x1) == 0x1);
            }
            b2 = 1;
        }
        else {
            if (n >= 0) {
                n3 = 63 + (n + 1 >> 1) - n2;
                b = ((n & 0x1) == 0x1);
            }
            else {
                n = -n;
                n3 = 63 - (n >> 1) - n2;
                b = ((n & 0x1) == 0x1);
            }
            b2 = 101;
            if (array[length - 1] == 102) {
                --length;
            }
        }
        final byte[] array2 = new byte[length];
        System.arraycopy(array, 0, array2, 0, length);
        if (n3 > length - 1 || (n3 == length - 1 && (b || LnxLibThin.LnxqFirstDigit[array[n3]] == 1))) {
            return _setLength(array, length);
        }
        if (n3 > 0) {
            if (n3 == 1 && b) {
                if (isPositive) {
                    if (array[1] < 11) {
                        return NUMBER._makeZero();
                    }
                }
                else if (array[1] > 91) {
                    return NUMBER._makeZero();
                }
            }
            final byte b4;
            final byte b3 = b4 = (byte)n3;
            if (b) {
                if (isPositive) {
                    array2[b4] = LnxLibThin.LnxqTruncate_P[array[b3]];
                }
                else {
                    array2[b4] = LnxLibThin.LnxqTruncate_N[array[b3]];
                }
            }
            else {
                array2[b4] = array[b3];
            }
            byte b5 = (byte)(b3 - 1);
            int n4;
            if (array2[b4] == b2) {
                while (array[b5] == b2) {
                    --b5;
                }
                n4 = b5 + 1;
            }
            else {
                n4 = n3 + 1;
            }
            return _setLength(array2, n4);
        }
        return NUMBER._makeZero();
    }
    
    @Override
    public byte[] lnxcpn(final String s, final boolean b, int n, final boolean b2, int n2, final String s2) throws SQLException {
        int n3 = 0;
        int n4 = 0;
        boolean b3 = false;
        boolean b4 = false;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        boolean b5 = false;
        boolean b6 = false;
        boolean b7 = false;
        boolean b8 = false;
        boolean b9 = false;
        Locale locale;
        if (s2 != null) {
            final int index = s2.indexOf("_");
            if (index == -1) {
                locale = LxMetaData.getJavaLocale(s2, "");
            }
            else {
                locale = LxMetaData.getJavaLocale(s2.substring(0, index), s2.substring(index + 1));
            }
            if (locale == null) {
                locale = Locale.getDefault();
            }
        }
        else {
            locale = Locale.getDefault();
        }
        final DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols(locale);
        final char decimalSeparator = decimalFormatSymbols.getDecimalSeparator();
        final char minusSign = decimalFormatSymbols.getMinusSign();
        char[] charArray;
        int n8;
        int n9;
        for (charArray = s.toCharArray(), n8 = 0, n9 = charArray.length - 1; n8 <= n9 && Character.isSpaceChar(charArray[n8]); ++n8) {}
        if (n8 <= n9 && (charArray[n8] == minusSign || charArray[n8] == '+')) {
            b3 = (charArray[n8] == minusSign);
            ++n8;
        }
        final int n10 = n8;
        while (n8 <= n9 && charArray[n8] == '0') {
            ++n8;
        }
        final int n11 = n8;
        while (n8 <= n9 && Character.isDigit(charArray[n8])) {
            ++n8;
        }
        final int n12 = n8 - n10;
        final int n13 = n8 - n11;
        if (n8 <= n9 && charArray[n8] == decimalSeparator) {
            for (n3 = ++n8; n8 <= n9 && Character.isDigit(charArray[n8]); ++n8) {}
            n5 = n8 - n3;
            final int n14 = n8;
            while (--n8 >= n3 && charArray[n8] == '0') {}
            n6 = n8 - n3 + 1;
            n8 = n14;
        }
        if (n12 + n5 != 0) {
            if (n8 <= n9 && (charArray[n8] == 'E' || charArray[n8] == 'e')) {
                if (++n8 <= n9 && (charArray[n8] == minusSign || charArray[n8] == '+')) {
                    b4 = (charArray[n8] == minusSign);
                    ++n8;
                }
                final int n15 = n8;
                while (n8 <= n9 && charArray[n8] == '0') {
                    ++n8;
                }
                final int n16 = n8;
                while (n8 <= n9 && Character.isDigit(charArray[n8])) {
                    n4 = n4 * 10 + (charArray[n8] - '0');
                    ++n8;
                }
                final int n17 = n8 - n15;
                n7 = n8 - n16;
                if (n17 != 0 && b4) {
                    n4 = -n4;
                }
            }
            while (n8 <= n9 && Character.isSpaceChar(charArray[n8])) {
                ++n8;
            }
        }
        int n18;
        int n19;
        int n20;
        int n21;
        if (n13 != 0) {
            if (n6 != 0) {
                n18 = n4 + (n13 - 1);
                n19 = n13;
                n20 = n6;
                n21 = n11;
            }
            else {
                n18 = n4 + (n13 - 1);
                int n22;
                for (n22 = n11 + (n13 - 1); charArray[n22] == '0'; --n22) {}
                n19 = n22 - n11 + 1;
                n20 = 0;
                n21 = n11;
            }
        }
        else {
            if (n6 == 0) {
                return NUMBER._makeZero();
            }
            int n23;
            for (n23 = n3; charArray[n23] == '0'; ++n23) {}
            n18 = n4 - (n23 - n3 + 1);
            n19 = n6 - (n23 - n3);
            n20 = 0;
            n21 = n23;
        }
        final int b10 = ((n18 & 0x1) == 0x1) ? 40 : 39;
        final int n24 = n19 + n20;
        int a;
        if (b || b2) {
            if (!b) {
                n = Integer.MAX_VALUE;
            }
            if (!b2) {
                n2 = 0;
            }
            a = n18 + 1 + n2;
        }
        else {
            a = n24;
        }
        final int min = Math.min(a, b10);
        if (min < 0 || (min == 0 && charArray[n21] < '5')) {
            return NUMBER._makeZero();
        }
        boolean b11 = false;
        if (min < n24) {
            int n25 = n21 + min + ((min >= n19) ? 1 : 0);
            if (charArray[n25] < '5') {
                while (--n25 >= n21) {
                    if (charArray[n25] != '0' && charArray[n25] != decimalSeparator) {
                        break;
                    }
                }
            }
            else {
                while (--n25 >= n21 && (charArray[n25] == '9' || charArray[n25] == decimalSeparator)) {}
                b11 = true;
            }
            if (n25 < n21) {
                charArray[1] = '1';
                charArray[2] = '0';
                n21 = 1;
                ++n18;
                b5 = false;
                b7 = ((n18 & 0x1) != 0x1);
                b8 = false;
                n19 = (((n18 & 0x1) == 0x1) ? 2 : 0);
                n20 = 0;
                b11 = false;
                b9 = true;
            }
            else if (n20 != 0) {
                if (n25 - n21 < n19) {
                    n19 = n25 - n21 + 1;
                    n20 = 0;
                }
                else {
                    n20 = n25 - n21 - n19;
                }
            }
            else {
                n19 = n25 - n21 + 1;
            }
        }
        if (!b9) {
            if (n20 != 0) {
                b5 = true;
                b6 = ((n18 & 0x1) == (n19 & 0x1));
                b7 = ((n18 & 0x1) != 0x1);
                b8 = (b6 != ((n20 & 0x1) == 0x1));
                n19 -= ((b7 + b6) ? 1 : 0);
                n20 -= ((b6 + b8) ? 1 : 0);
            }
            else {
                b5 = false;
                b7 = ((n18 & 0x1) != 0x1);
                b8 = ((n18 & 0x1) == (n19 & 0x1));
                n19 -= ((b7 + b8) ? 1 : 0);
            }
        }
        if (!b4 && (n7 > 3 || n18 > 125)) {
            if (b3) {
                return NUMBER._makeNegInf();
            }
            return NUMBER._makePosInf();
        }
        else {
            if (b4 && (n7 > 3 || n18 < -130)) {
                return NUMBER._makeZero();
            }
            final byte[] array = new byte[22];
            int n26 = 1;
            int i = n21;
            if (b7) {
                array[n26] = digitPtr(0, lnxqctn(charArray[i]), b3);
                ++n26;
                ++i;
            }
            if (n19 != 0) {
                while (i < i + n19) {
                    array[n26] = digitPtr(lnxqctn(charArray[i]), lnxqctn(charArray[i + 1]), b3);
                    ++n26;
                    i += 2;
                }
            }
            if (b5) {
                if (b6) {
                    array[n26] = digitPtr(lnxqctn(charArray[i]), lnxqctn(charArray[i + 2]), b3);
                    ++n26;
                    i += 3;
                }
                else {
                    ++i;
                }
            }
            if (n20 != 0) {
                while (i < i + n20) {
                    array[n26] = digitPtr(lnxqctn(charArray[i]), lnxqctn(charArray[i + 1]), b3);
                    ++n26;
                    i += 2;
                }
            }
            if (b8) {
                array[n26] = digitPtr(lnxqctn(charArray[i]), 0, b3);
                ++n26;
                ++i;
            }
            if (b11) {
                final byte[] array2 = array;
                final int n27 = n26 - 1;
                array2[n27] += (byte)((b3 ? -1 : 1) * (b8 ? 10 : 1));
            }
            byte b12;
            if (n18 < 0) {
                b12 = (byte)(193 - (1 - n18) / 2);
            }
            else {
                b12 = (byte)(193 + n18 / 2);
            }
            final int n28 = n26;
            array[0] = (byte)(b3 ? (~b12) : b12);
            return _setLength(array, n28);
        }
    }
    
    private static byte digitPtr(final int n, final int n2, final boolean b) {
        return b ? LnxLibThin.LnxqDigit_N[n][n2] : LnxLibThin.LnxqDigit_P[n][n2];
    }
    
    private static int lnxqctn(final char ch) {
        return Character.digit(ch, 10);
    }
    
    @Override
    public byte[] lnxfcn(final String s, final String s2, final String s3) throws SQLException {
        if (s3 != null && !s3.equals("AMERICAN_AMERICAN")) {
            throw new SQLException(CoreException.getMessage((byte)12));
        }
        final LnxLibThinFormat lnxLibThinFormat = new LnxLibThinFormat();
        lnxLibThinFormat.parseFormat(s2);
        lnxLibThinFormat.LNXNFRDX = true;
        final int lnxnflhd = lnxLibThinFormat.lnxnflhd;
        final int lnxnfrhd = lnxLibThinFormat.lnxnfrhd;
        final int lnxnfsiz = lnxLibThinFormat.lnxnfsiz;
        final int lnxnfzld = lnxLibThinFormat.lnxnfzld;
        if (lnxLibThinFormat.LNXNFFDA | lnxLibThinFormat.LNXNFFED | lnxLibThinFormat.LNXNFFRN | lnxLibThinFormat.LNXNFFTM) {
            throw new SQLException(CoreException.getMessage((byte)5));
        }
        if (lnxLibThinFormat.LNXNFFRC | lnxLibThinFormat.LNXNFFCH | lnxLibThinFormat.LNXNFFCT) {
            throw new SQLException(CoreException.getMessage((byte)12));
        }
        char[] charArray;
        int i;
        int n;
        int n2;
        for (charArray = s.toCharArray(), i = 0, n = charArray.length - 1, n2 = 0; i <= n && Character.isSpaceChar(charArray[i]); ++i, ++n2) {}
        if (lnxLibThinFormat.LNXNFFBL && n2 == lnxnfsiz && n2 == charArray.length) {
            return NUMBER._makeZero();
        }
        if (i > n) {
            throw new SQLException(CoreException.getMessage((byte)14));
        }
        final char[] value = new char[255];
        int n3 = 0;
        if (lnxLibThinFormat.LNXNFFSH) {
            if (charArray[i] != '-' && charArray[i] != '+') {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
            value[n3++] = charArray[i++];
        }
        else if (lnxLibThinFormat.LNXNFFPR) {
            if (charArray[i] == '<') {
                value[n3++] = '-';
                ++i;
            }
            else {
                value[n3++] = '+';
            }
        }
        else if (lnxLibThinFormat.LNXNFFPT) {
            if (charArray[i] == '(') {
                value[n3++] = '-';
                ++i;
            }
            else {
                value[n3++] = '+';
            }
        }
        else if (!lnxLibThinFormat.LNXNFFMI && !lnxLibThinFormat.LNXNFFST) {
            if (charArray[i] == '-') {
                value[n3++] = charArray[i++];
            }
        }
        else {
            ++n3;
        }
        if (i > n) {
            throw new SQLException(CoreException.getMessage((byte)14));
        }
        if (lnxLibThinFormat.LNXNFFDS) {
            if (charArray[i] != '$') {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
            if (++i > n) {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
        }
        else if (lnxLibThinFormat.LNXNFFCH) {
            throw new SQLException(CoreException.getMessage((byte)12));
        }
        final byte[] array = new byte[40];
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        while (i <= n) {
            if (Character.isDigit(charArray[i]) || (lnxLibThinFormat.LNXNFFHX && ((charArray[i] >= 'a' && charArray[i] <= 'f') || (charArray[i] >= 'A' && charArray[i] <= 'F')))) {
                value[n3++] = charArray[i++];
                ++n6;
            }
            else {
                if (n7 == 0) {
                    if (!lnxLibThinFormat.LNXNFRDX) {
                        throw new SQLException(CoreException.getMessage((byte)12));
                    }
                    if (charArray[i] == ',') {
                        ++i;
                        array[n4++] = (byte)n6;
                        continue;
                    }
                    if (charArray[i] == '.') {
                        if (n6 > lnxnflhd || n6 < lnxnfzld) {
                            throw new SQLException(CoreException.getMessage((byte)14));
                        }
                        final int n8 = lnxnflhd - n6;
                        n4 = 0;
                        while (lnxLibThinFormat.lnxnfgps[n5] != 0) {
                            final byte b = (byte)(lnxLibThinFormat.lnxnfgps[n5] & 0x7F);
                            if (b > n8) {
                                if (array[n4] != b - n8) {
                                    throw new SQLException(CoreException.getMessage((byte)14));
                                }
                                ++n4;
                            }
                            ++n5;
                        }
                        n6 = 0;
                        n7 = 1;
                        value[n3] = '.';
                        ++n3;
                        ++i;
                        continue;
                    }
                }
                if ((charArray[i] == 'E' || charArray[i] == 'e') && lnxLibThinFormat.LNXNFFSN) {
                    if (n6 <= 0 && n7 == 0) {
                        throw new SQLException(CoreException.getMessage((byte)14));
                    }
                    value[n3++] = charArray[i++];
                    if (i > n) {
                        throw new SQLException(CoreException.getMessage((byte)14));
                    }
                    if (charArray[i] == '+' || charArray[i] == '-') {
                        value[n3++] = charArray[i++];
                    }
                    final int n9 = i;
                    while (i <= n && Character.isDigit(charArray[i])) {
                        value[n3++] = charArray[i++];
                    }
                    if (n9 == i) {
                        throw new SQLException(CoreException.getMessage((byte)14));
                    }
                    continue;
                }
                else {
                    if (lnxLibThinFormat.LNXNFFRC) {
                        throw new SQLException(CoreException.getMessage((byte)12));
                    }
                    break;
                }
            }
        }
        if (n7 == 0) {
            final int n10 = lnxnflhd - n6;
            int n11 = 0;
            while (lnxLibThinFormat.lnxnfgps[n5] != 0) {
                final byte b2 = (byte)(lnxLibThinFormat.lnxnfgps[n5] & 0x7F);
                if (b2 > n10) {
                    if (array[n11] != b2 - n10) {
                        throw new SQLException(CoreException.getMessage((byte)14));
                    }
                    ++n11;
                }
                ++n5;
            }
        }
        if (lnxLibThinFormat.LNXNFFCT) {
            throw new SQLException(CoreException.getMessage((byte)12));
        }
        if (lnxLibThinFormat.LNXNFFST) {
            if (i > n) {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
            if (charArray[i] != '-' && charArray[i] != '+') {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
            value[0] = charArray[i];
            ++i;
        }
        else if (lnxLibThinFormat.LNXNFFMI) {
            if (i > n) {
                if (lnxLibThinFormat.LNXNFFIL || i != charArray.length) {
                    throw new SQLException(CoreException.getMessage((byte)14));
                }
                value[0] = '+';
            }
            else {
                value[0] = ((charArray[i] == '-') ? '-' : '+');
                ++i;
            }
        }
        else if (lnxLibThinFormat.LNXNFFPR) {
            if (charArray[i] == '>' && value[0] == '-') {
                ++i;
            }
        }
        else if (lnxLibThinFormat.LNXNFFPT && i < charArray.length && charArray[i] == ')' && value[0] == '-') {
            ++i;
        }
        if (i <= n) {
            throw new SQLException(CoreException.getMessage((byte)14));
        }
        if (n7 != 0) {
            if (n6 > lnxnfrhd) {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
        }
        else {
            if (n6 > lnxnflhd) {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
            if (n6 < lnxnfzld) {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
        }
        if (lnxLibThinFormat.LNXNFF05 && ((n7 != 0 && n6 == lnxnfrhd) || lnxnfrhd == 0)) {
            --n3;
            if (value[n3] != '0' && value[n3] != '5') {
                throw new SQLException(CoreException.getMessage((byte)14));
            }
            ++n3;
        }
        if (lnxLibThinFormat.LNXNFFHX) {
            return this.lnxqh2n(value);
        }
        return this.lnxcpn(new String(value), false, 0, false, 0, s3);
    }
    
    @Override
    public String lnxnfn(final byte[] array, final String s, final String s2) throws SQLException {
        int n = 0;
        int n2 = 0;
        byte[] lnxrou = null;
        final boolean[] array2 = { false };
        boolean b = false;
        boolean b2 = true;
        final LnxLibThinFormat lnxLibThinFormat = new LnxLibThinFormat();
        lnxLibThinFormat.parseFormat(s);
        int lnxnflhd = lnxLibThinFormat.lnxnflhd;
        int lnxnfrhd = lnxLibThinFormat.lnxnfrhd;
        int lnxnfsiz = lnxLibThinFormat.lnxnfsiz;
        final int lnxnfzld = lnxLibThinFormat.lnxnfzld;
        final int lnxnfztr = lnxLibThinFormat.lnxnfztr;
        if (lnxLibThinFormat.LNXNFFRN || lnxLibThinFormat.LNXNFFHX) {
            if (lnxLibThinFormat.LNXNFFRN) {
                throw new SQLException(CoreException.getMessage((byte)1));
            }
            throw new SQLException(CoreException.getMessage((byte)1));
        }
        else {
            if (lnxLibThinFormat.LNXNFFTM) {
                int length = array.length;
                int n4;
                int n5;
                int n6;
                if (!NUMBER._isZero(array)) {
                    if (NUMBER._isPositive(array)) {
                        final int n3 = length - 1;
                        n4 = 2 * ((array[0] & 0xFF) - 193) + (((array[1] & 0xFF) > 10) ? 1 : 0);
                        n5 = 2 * n3 - (((array[1] & 0xFF) < 11) ? 1 : 0) - LnxLibThin.LnxqFirstDigit[array[n3]];
                        n6 = 0;
                    }
                    else {
                        if ((array[length - 1] & 0xFF) == 0x66) {
                            --length;
                        }
                        final int n7 = length - 1;
                        n4 = 2 * (62 - array[0]) + (((array[1] & 0xFF) < 92) ? 1 : 0);
                        n5 = 2 * n7 - (((array[1] & 0xFF) > 91) ? 1 : 0) - LnxLibThin.LnxqFirstDigit[array[n7]];
                        n6 = 1;
                    }
                }
                else {
                    n4 = 0;
                    n5 = 1;
                    n6 = 0;
                }
                int n8;
                if (n4 >= 0) {
                    n8 = n6 + ((n5 > n4 + 1) ? (n5 + 1) : (n4 + 1));
                }
                else {
                    n8 = n6 + (-(n4 + 1) + n5 + 1);
                }
                if (!lnxLibThinFormat.LNXNFFSN && n8 > 64) {
                    lnxLibThinFormat.LNXNFFSN = true;
                }
                if (lnxLibThinFormat.LNXNFFSN) {
                    lnxnflhd = 1;
                    lnxnfrhd = n5 - 1;
                    lnxnfsiz = ((n5 > 1) ? (n5 + 7) : 7);
                }
                else {
                    lnxnflhd = ((n4 + 1 > 0) ? (n4 + 1) : 0);
                    lnxnfrhd = ((n5 - (n4 + 1) > 0) ? (n5 - (n4 + 1)) : 0);
                    lnxnfsiz = ((lnxnfrhd != 0) ? (lnxnflhd + lnxnfrhd + 2) : (lnxnflhd + 1));
                }
                if (lnxnfrhd == 0) {
                    lnxLibThinFormat.LNXNFNRD = true;
                }
            }
            final boolean b3 = (array[0] & 0xFF) >= 128;
            byte[] array3;
            if (lnxLibThinFormat.LNXNFFSN) {
                array3 = this.lnxfpr(array, lnxnfrhd + lnxnflhd);
            }
            else {
                array3 = this.lnxsca(array, lnxnflhd, lnxnfrhd, array2);
                if (array2[0]) {
                    throw new SQLException(CoreException.getMessage((byte)4));
                }
            }
            final char[] array4 = new char[64];
            int n9 = 0;
            boolean b4;
            int n10;
            int n11;
            int n12;
            int j;
            if (NUMBER._isZero(array3)) {
                if (lnxLibThinFormat.LNXNFFBL) {
                    if (lnxLibThinFormat.LNXNFFIL) {
                        final char[] value = new char[lnxnfsiz];
                        for (int i = 0; i < lnxnfsiz; ++i) {
                            value[i] = ' ';
                        }
                        return new String(value);
                    }
                    return null;
                }
                else {
                    b4 = b3;
                    b = false;
                    n10 = 0;
                    n11 = 0;
                    n12 = n10;
                    j = ((lnxnflhd > 0 && lnxnfztr == 0) ? 1 : 0);
                }
            }
            else {
                if (NUMBER._isNegInf(array3) || NUMBER._isPosInf(array3)) {
                    throw new SQLException(CoreException.getMessage((byte)4));
                }
                n11 = array3.length - 1;
                b4 = ((array3[0] & 0x80) != 0x0);
                if (!b4) {
                    lnxrou = new byte[n11];
                    if (array3[n11] == 102) {
                        --n11;
                    }
                    for (int k = 1; k <= n11; ++k) {
                        lnxrou[k] = (byte)(102 - array3[k]);
                    }
                    lnxrou[0] = (byte)~array3[0];
                }
                else {
                    lnxrou = array3;
                }
                final int n13 = ((lnxrou[n11] & 0xFF) % 10 == 1) ? 1 : 0;
                n12 = 2 * ((lnxrou[0] & 0xFF) - 192);
                n = 1;
                if (b2 = ((lnxrou[n] & 0xFF) < 11)) {
                    n2 = ((lnxrou[n] & 0xFF) - 1) / 10;
                }
                if (lnxLibThinFormat.LNXNFFSN) {
                    n10 = 2 * n11 - (b2 ? 1 : 0) - n13 - (j = 1);
                    n12 -= (b2 ? 1 : 0) + 1;
                    if (b = (n12 < 0)) {
                        n12 = -n12;
                    }
                    if (n12 < 100 && lnxLibThinFormat.LNXNFFIL) {
                        array4[n9] = ' ';
                        ++n9;
                    }
                }
                else {
                    n10 = 2 * n11 - n12 - n13;
                    j = n12 - (b2 ? 1 : 0);
                    if (lnxLibThinFormat.LNXNFF05 && (lnxnfrhd == 0 || n10 == lnxnfrhd)) {
                        final int n14 = n + n11 - 1;
                        int n16;
                        if (n13 == 0) {
                            final int n15 = (lnxrou[n14] & 0xFF) % 10;
                            n16 = ((n15 != 0) ? (n15 - 1) : 9);
                            if (n16 <= 2) {
                                lnxrou[n14] = (byte)((lnxrou[n14] & 0xFF) - n16);
                            }
                            else if (n16 <= 7) {
                                lnxrou[n14] = (byte)((lnxrou[n14] & 0xFF) + (5 - n16));
                            }
                        }
                        else {
                            n16 = (lnxrou[n14] & 0xFF) / 10;
                            if (n16 <= 2) {
                                lnxrou[n14] = 1;
                            }
                            else if (n16 <= 7) {
                                lnxrou[n14] = 51;
                            }
                        }
                        if (n16 > 7) {
                            --n;
                            lnxrou = this.lnxrou(lnxrou, n10 - 1);
                            n11 = lnxrou.length - 1;
                            final int n17 = ((lnxrou[n] & 0xFF) % 10 == 1) ? 1 : 0;
                            n12 = 2 * ((lnxrou[n] & 0xFF) - 192);
                            ++n;
                            if (b2 = ((lnxrou[n] & 0xFF) < 11)) {
                                n2 = ((lnxrou[n] & 0xFF) - 1) / 10;
                            }
                            n10 = 2 * n11 - n12 - n17;
                            j = n12 - (b2 ? 1 : 0);
                            if (j > lnxnflhd) {
                                throw new SQLException(CoreException.getMessage((byte)4));
                            }
                        }
                    }
                }
            }
            int l = lnxnflhd - ((lnxnfzld > j) ? lnxnfzld : j);
            if (l != 0 && lnxLibThinFormat.LNXNFFIL) {
                for (int n18 = l + n9, n19 = 0; n19 < n18; ++n19, ++n9) {
                    array4[n19] = ' ';
                }
            }
            if (!lnxLibThinFormat.LNXNFFMI && !lnxLibThinFormat.LNXNFFST) {
                int n20;
                if (b4) {
                    n20 = (lnxLibThinFormat.LNXNFFSH ? 43 : 32);
                }
                else {
                    n20 = (lnxLibThinFormat.LNXNFFPR ? 60 : (lnxLibThinFormat.LNXNFFPT ? 40 : 45));
                }
                if (lnxLibThinFormat.LNXNFFIL || n20 != 32) {
                    array4[n9] = (char)n20;
                    ++n9;
                }
            }
            String s3;
            if (lnxLibThinFormat.LNXNFFIC) {
                s3 = "USD";
            }
            else if (lnxLibThinFormat.LNXNFFUN) {
                s3 = "$";
            }
            else {
                s3 = "$";
            }
            if (lnxLibThinFormat.LNXNFFDS) {
                array4[n9] = '$';
                ++n9;
            }
            else if (lnxLibThinFormat.LNXNFFCH) {
                for (int index = 0; index < s3.length(); ++index, ++n9) {
                    array4[n9] = s3.charAt(index);
                }
            }
            int n21;
            int n22;
            for (n21 = 0; (n22 = (lnxLibThinFormat.lnxnfgps[n21] & 0x7F)) != 0 && n22 <= l; ++n21) {}
            int n23;
            if ((n23 = lnxnfzld - ((j > 0) ? j : 0)) > 0) {
                while (n23 > 0) {
                    array4[n9] = '0';
                    ++n9;
                    ++l;
                    while (l == n22) {
                        array4[n9] = ',';
                        ++n9;
                        ++n21;
                        n22 = (lnxLibThinFormat.lnxnfgps[n21] & 0x7F);
                    }
                    --n23;
                }
            }
            if (j > 0) {
                while (j > 0 && n11 != 0) {
                    int n24;
                    if (b2) {
                        n24 = (lnxrou[n] & 0xFF) - 1 - n2 * 10;
                        ++n;
                        --n11;
                    }
                    else {
                        n24 = (n2 = ((lnxrou[n] & 0xFF) - 1) / 10);
                    }
                    array4[n9] = this.lnx_chars[n24];
                    ++n9;
                    ++l;
                    while (l == n22) {
                        array4[n9] = ',';
                        ++n9;
                        ++n21;
                        n22 = (lnxLibThinFormat.lnxnfgps[n21] & 0x7F);
                    }
                    --j;
                    b2 = !b2;
                }
                while (j > 0) {
                    array4[n9] = '0';
                    ++n9;
                    ++l;
                    while (l == n22) {
                        array4[n9] = ',';
                        ++n9;
                        ++n21;
                        n22 = (lnxLibThinFormat.lnxnfgps[n21] & 0x7F);
                    }
                    --j;
                }
            }
            if (!lnxLibThinFormat.LNXNFNRD) {
                if (lnxLibThinFormat.LNXNFRDX) {
                    array4[n9] = '.';
                    ++n9;
                }
                else if (lnxLibThinFormat.LNXNFFRC) {
                    for (int index2 = 0; index2 < s3.length(); ++index2, ++n9) {
                        array4[n9] = s3.charAt(index2);
                    }
                }
                else {
                    array4[n9] = '.';
                    ++n9;
                }
            }
            int n25;
            if ((n25 = lnxnfztr - ((n10 > 0) ? n10 : 0)) < 0) {
                n25 = 0;
            }
            if (j != 0) {
                int n26 = -j;
                n10 -= n26;
                while (n26 != 0) {
                    array4[n9] = '0';
                    ++n9;
                    --n26;
                }
            }
            while (n11 != 0 && n10 != 0) {
                int n27;
                if (b2) {
                    n27 = (lnxrou[n] & 0xFF) - 1 - n2 * 10;
                    ++n;
                    --n11;
                }
                else {
                    n27 = (n2 = ((lnxrou[n] & 0xFF) - 1) / 10);
                }
                array4[n9] = this.lnx_chars[n27];
                ++n9;
                --n10;
                b2 = !b2;
            }
            while (n25 != 0) {
                array4[n9] = '0';
                ++n9;
                --n25;
            }
            if (lnxLibThinFormat.LNXNFFSN) {
                array4[n9] = 'E';
                ++n9;
                array4[n9] = (b ? '-' : '+');
                ++n9;
                if (n12 > 99) {
                    array4[n9] = '1';
                    ++n9;
                    n12 -= 100;
                }
                array4[n9] = this.lnx_chars[n12 / 10];
                ++n9;
                array4[n9] = this.lnx_chars[n12 % 10];
                ++n9;
            }
            if (lnxLibThinFormat.LNXNFFCT) {
                for (int index3 = 0; index3 < s3.length(); ++index3, ++n9) {
                    array4[n9] = s3.charAt(index3);
                }
            }
            if (b4) {
                if (lnxLibThinFormat.LNXNFFST) {
                    array4[n9] = '+';
                    ++n9;
                }
                else if ((lnxLibThinFormat.LNXNFFPR || lnxLibThinFormat.LNXNFFMI || lnxLibThinFormat.LNXNFFPT) && lnxLibThinFormat.LNXNFFIL) {
                    array4[n9] = ' ';
                    ++n9;
                }
            }
            else if (lnxLibThinFormat.LNXNFFPR) {
                array4[n9] = '>';
                ++n9;
            }
            else if (lnxLibThinFormat.LNXNFFPT) {
                array4[n9] = ')';
                ++n9;
            }
            else if (lnxLibThinFormat.LNXNFFMI || lnxLibThinFormat.LNXNFFST) {
                array4[n9] = '-';
                ++n9;
            }
            final int n28 = n9;
            if (lnxLibThinFormat.LNXNFFIL && n28 != lnxnfsiz) {
                final int n29 = lnxnfsiz - n28;
                final char[] str = new char[n29];
                for (int n30 = 0; n30 < n29; ++n30) {
                    str[n30] = ' ';
                }
                final StringBuffer sb = new StringBuffer();
                sb.append(str);
                sb.append(array4, 0, n28);
                return sb.toString();
            }
            return new String(array4, 0, n28);
        }
    }
    
    @Override
    public String lnxnuc(byte[] array, int n, final String s) throws SQLException {
        final byte[] array2 = new byte[22];
        boolean b = false;
        if (s != null) {
            throw new SQLException(CoreException.getMessage((byte)12));
        }
        final char[] lnx_chars = this.lnx_chars;
        final char c = '.';
        if (n == 0) {
            throw new SQLException(CoreException.getMessage((byte)13));
        }
        final boolean b2;
        if (!(b2 = (n >= 0))) {
            n = -n;
        }
        final char[] array3 = new char[n];
        int n2;
        byte[][] array4;
        int n3;
        if ((n2 = (NUMBER._isPositive(array) ? 0 : 1)) != 0) {
            array4 = LnxLibThin.LnxqComponents_N;
            n3 = n - 1;
        }
        else {
            array4 = LnxLibThin.LnxqComponents_P;
            n3 = n;
        }
        int i = 1;
        while (i != 0) {
            boolean b3 = b2;
            int length = array.length;
            if (length == 1) {
                if ((array[0] & 0xFF) == 0x80) {
                    int n4;
                    if (b3) {
                        n4 = n - 1;
                        array3[n4] = lnx_chars[0];
                    }
                    else {
                        if (n < 5) {
                            throw new SQLException(CoreException.getMessage((byte)13));
                        }
                        n4 = n - 5;
                        array3[n4] = lnx_chars[0];
                        array3[n4 + 1] = lnx_chars[41];
                        array3[n4 + 2] = lnx_chars[10];
                        array3[n4 + 3] = lnx_chars[0];
                        array3[n4 + 4] = lnx_chars[0];
                    }
                    if (n4 != 0) {
                        for (int j = 0; j < n4; ++j) {
                            array3[j] = lnx_chars[12];
                        }
                    }
                    return new String(array3);
                }
                if (n < 2) {
                    throw new SQLException(CoreException.getMessage((byte)13));
                }
                final int n5 = n - 2;
                array3[n5] = lnx_chars[11];
                array3[n5 + 1] = lnx_chars[21];
                if (n5 != 0) {
                    for (int k = 0; k < n5; ++k) {
                        array3[k] = lnx_chars[12];
                    }
                }
                return new String(array3);
            }
            else {
                if (length == 2 && (array[0] & 0xFF) == 0xFF && (array[1] & 0xFF) == 0x65) {
                    final int n6 = n - 1;
                    array3[n6] = lnx_chars[21];
                    if (n6 != 0) {
                        for (int l = 0; l < n6; ++l) {
                            array3[l] = lnx_chars[12];
                        }
                    }
                    return new String(array3);
                }
                int n8;
                int n9;
                if (n2 != 0) {
                    if (array[length - 1] == 102) {
                        --length;
                    }
                    final int n7 = length - 1;
                    n8 = 2 * (62 - (array[0] & 0xFF)) + (((array[1] & 0xFF) < 92) ? 1 : 0);
                    n9 = 2 * n7 - (((array[1] & 0xFF) > 91) ? 1 : 0) - LnxLibThin.LnxqFirstDigit[array[n7]];
                }
                else {
                    final int n10 = length - 1;
                    n8 = 2 * ((array[0] & 0xFF) - 193) + (((array[1] & 0xFF) > 10) ? 1 : 0);
                    n9 = 2 * n10 - (((array[1] & 0xFF) < 11) ? 1 : 0) - LnxLibThin.LnxqFirstDigit[array[n10]];
                }
                if (b3) {
                    if (n8 >= 0) {
                        b3 = (n8 < n3);
                    }
                    else {
                        b3 = (n8 >= -5 || n9 - n8 <= n3 || n3 <= 6);
                    }
                }
                boolean b4;
                boolean b5;
                int n13;
                int n15;
                int n16;
                int n17;
                if (b3) {
                    int n11;
                    if (n8 >= 0) {
                        n11 = ((n3 <= n8 + 1) ? n3 : (n3 - 1));
                    }
                    else {
                        n11 = n3 + n8;
                    }
                    if (n11 < n9) {
                        array = this.lnxfpr(array, n11);
                        continue;
                    }
                    i = 0;
                    int n12;
                    if (n8 >= 0) {
                        if (n9 > n8 + 1) {
                            n12 = n3 - (n9 + 1);
                            b4 = true;
                            b = false;
                            b5 = ((n8 & 0x1) <= 0);
                            n13 = (((n9 - n8 & 0x1) <= 0) ? 1 : 0);
                            final int n14 = Integer.MAX_VALUE;
                            n15 = (n8 + 1 & n14 - 1);
                            n16 = (n9 - (n8 + 1) & n14 - 1);
                            n17 = n12;
                        }
                        else {
                            n12 = n3 - (n8 + 1);
                            final int n18 = n8 + 1 - n9;
                            b4 = false;
                            b5 = ((n8 & 0x1) <= 0);
                            n13 = (((n18 & 0x1) > 0) ? 1 : 0);
                            n15 = n9 - (b5 ? 1 : 0) - ((n13 != 0) ? 1 : 0);
                            n16 = 0;
                            if (n18 != 0) {
                                final int n19 = n12 + ((n2 != 0) ? 1 : 0) + n9;
                                for (int n20 = 0; n20 < n18; ++n20) {
                                    array3[n19 + n20] = lnx_chars[0];
                                }
                            }
                            n17 = n12;
                        }
                    }
                    else {
                        n12 = n3 - (n9 - n8);
                        final int n21 = -(n8 + 1);
                        b4 = false;
                        b5 = ((n21 & 0x1) > 0);
                        n13 = (((n21 + n9 & 0x1) > 0) ? 1 : 0);
                        n15 = 0;
                        n16 = n9 - (b5 ? 1 : 0) - ((n13 != 0) ? 1 : 0);
                        int n22 = n12;
                        if (n2 != 0) {
                            array3[n22] = lnx_chars[11];
                            ++n22;
                            n2 = 0;
                        }
                        array3[n22] = c;
                        ++n22;
                        if (n21 != 0) {
                            for (int n23 = 0; n23 < n21; ++n23) {
                                array3[n22 + n23] = lnx_chars[0];
                            }
                            n22 += n21;
                        }
                        n17 = n22;
                    }
                    if (n12 != 0) {
                        for (int n24 = 0; n24 < n12; ++n24) {
                            array3[n24] = lnx_chars[12];
                        }
                    }
                }
                else {
                    final int n25 = n3 - ((n8 > 99 || n8 < -99) ? 6 : 5);
                    if (n25 < 2) {
                        throw new SQLException(CoreException.getMessage((byte)13));
                    }
                    if (n25 < n9) {
                        array = this.lnxfpr(array, n25);
                        continue;
                    }
                    i = 0;
                    int n26;
                    if (n9 == 1) {
                        n26 = n25 - 1;
                        b4 = true;
                        b = ((n8 & 0x1) > 0);
                        b5 = !b;
                        n13 = 0;
                        n15 = 0;
                        n16 = 0;
                    }
                    else {
                        n26 = n25 - n9;
                        b4 = true;
                        b = ((n8 & 0x1) > 0);
                        b5 = !b;
                        n13 = ((b == (n9 & 0x1) > 0) ? 1 : 0);
                        n15 = 0;
                        n16 = n9 - (b5 ? 1 : 2) - ((n13 != 0) ? 1 : 0);
                    }
                    int n27 = ((n2 != 0) ? 1 : 0) + 1 + n9;
                    if (n26 != 0) {
                        for (int n28 = 0; n28 < n26; ++n28) {
                            array3[n27 + n28] = lnx_chars[0];
                        }
                        n27 += n26;
                    }
                    if (n8 < 0) {
                        n8 = -n8;
                        array3[n27] = lnx_chars[41];
                        array3[n27 + 1] = lnx_chars[11];
                    }
                    else {
                        array3[n27] = lnx_chars[41];
                        array3[n27 + 1] = lnx_chars[10];
                    }
                    if (n8 > 99) {
                        array3[n27 + 2] = lnx_chars[1];
                        array2[0] = (byte)(n8 - 99);
                        array3[n27 + 3] = lnx_chars[LnxLibThin.LnxqComponents_P[array2[0] & 0xFF][0]];
                        array3[n27 + 4] = lnx_chars[LnxLibThin.LnxqComponents_P[array2[0] & 0xFF][1]];
                    }
                    else {
                        array2[0] = (byte)(n8 + 1);
                        array3[n27 + 2] = lnx_chars[LnxLibThin.LnxqComponents_P[array2[0] & 0xFF][0]];
                        array3[n27 + 3] = lnx_chars[LnxLibThin.LnxqComponents_P[array2[0] & 0xFF][1]];
                    }
                    n17 = 0;
                }
                int n29 = 1;
                int n30 = n17;
                if (n2 != 0) {
                    array3[n30] = lnx_chars[11];
                    ++n30;
                }
                if (b5) {
                    array3[n30] = lnx_chars[array4[array[n29]][1]];
                    ++n30;
                    ++n29;
                }
                if (n15 != 0) {
                    while (n30 < n30 + n15) {
                        array3[n30] = lnx_chars[array4[array[n29]][0]];
                        ++n30;
                        array3[n30] = lnx_chars[array4[array[n29]][1]];
                        ++n30;
                        ++n29;
                    }
                }
                if (b4) {
                    if (b) {
                        array3[n30] = lnx_chars[array4[array[n29]][0]];
                        ++n30;
                        array3[n30] = c;
                        ++n30;
                        array3[n30] = lnx_chars[array4[array[n29]][1]];
                        ++n30;
                        ++n29;
                    }
                    else {
                        array3[n30] = c;
                        ++n30;
                    }
                }
                if (n16 != 0) {
                    while (n30 < n30 + n16) {
                        array3[n30] = lnx_chars[array4[array[n29]][0]];
                        ++n30;
                        array3[n30] = lnx_chars[array4[array[n29]][1]];
                        ++n30;
                        ++n29;
                    }
                }
                if (n13 == 0) {
                    continue;
                }
                array3[n30] = lnx_chars[array4[array[n29]][0]];
                ++n30;
                ++n29;
            }
        }
        return new String(array3);
    }
    
    @Override
    public byte[] lnxren(double abs) throws SQLException {
        final byte[] array = new byte[20];
        int n = 0;
        final boolean b = abs >= 0.0;
        abs = Math.abs(abs);
        if (abs < 1.0) {
            for (int i = 0; i < 8; ++i) {
                if (LnxLibThin.powerTable[i][2] >= abs) {
                    n -= (int)LnxLibThin.powerTable[i][0];
                    abs *= LnxLibThin.powerTable[i][1];
                }
            }
            if (abs < 1.0) {
                --n;
                abs *= 100.0;
            }
        }
        else {
            for (int j = 0; j < 8; ++j) {
                if (LnxLibThin.powerTable[j][1] <= abs) {
                    n += (int)LnxLibThin.powerTable[j][0];
                    abs *= LnxLibThin.powerTable[j][2];
                }
            }
        }
        if (n > 62) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        if (n < -65) {
            throw new SQLException(CoreException.getMessage((byte)2));
        }
        final boolean b2 = abs < 10.0;
        int n2 = 8;
        int k = 0;
        byte b3 = (byte)abs;
        while (k < n2) {
            array[k] = b3;
            abs = (abs - b3) * 100.0;
            b3 = (byte)abs;
            ++k;
        }
        int n3 = 7;
        if (b2) {
            if (b3 >= 50) {
                final byte[] array2 = array;
                final int n4 = n3;
                ++array2[n4];
            }
        }
        else if (n == 62 && (array[n3] + 5) / 10 * 10 == 100) {
            array[n3] = (byte)((array[n3] - 5) / 10 * 10);
        }
        else {
            array[n3] = (byte)((array[n3] + 5) / 10 * 10);
        }
        while (array[n3] == 100) {
            if (n3 == 0) {
                ++n;
                array[n3] = 1;
                break;
            }
            array[n3] = 0;
            --n3;
            final byte[] array3 = array;
            final int n5 = n3;
            ++array3[n5];
        }
        for (int n6 = 7; n6 != 0 && array[n6] == 0; --n6) {
            n2 = (byte)(n2 - 1);
        }
        final byte[] array4 = new byte[n2 + 1];
        array4[0] = (byte)n;
        System.arraycopy(array, 0, array4, 1, n2);
        return NUMBER._toLnxFmt(array4, b);
    }
    
    @Override
    public byte[] lnxmin(long n) {
        final byte[] array = new byte[20];
        final byte[] array2 = new byte[20];
        byte b = 0;
        if (n == 0L) {
            return NUMBER._makeZero();
        }
        final boolean b2 = n >= 0L;
        int n2;
        for (n2 = 0; n != 0L; n /= 100L, ++n2) {
            array[n2] = (byte)Math.abs(n % 100L);
        }
        int n3;
        byte b3;
        for (b3 = (byte)(n3 = (byte)(--n2)); b <= b3; ++b, --n3) {
            array2[b] = array[n3];
        }
        while (n2 > 0 && array2[n2--] == 0) {
            --b;
        }
        final byte[] array3 = new byte[b + 1];
        array3[0] = b3;
        System.arraycopy(array2, 0, array3, 1, b);
        return NUMBER._toLnxFmt(array3, b2);
    }
    
    @Override
    public double lnxnur(final byte[] array) {
        int n = 1;
        boolean b = false;
        final int length = LnxLibThin.factorTable.length;
        final byte[] fromLnxFmt = NUMBER._fromLnxFmt(array);
        final boolean b2 = fromLnxFmt[1] < 10;
        final double n2 = LnxLibThin.factorTable[0][0];
        final double n3 = LnxLibThin.factorTable[0][0] - (length - 20);
        int n4;
        int i;
        if (fromLnxFmt[0] > n2 || fromLnxFmt[0] < n3) {
            if (fromLnxFmt[0] > n2) {
                n4 = -1;
                i = (int)(fromLnxFmt[0] - n2);
            }
            else {
                n4 = -1 + (length - 20);
                i = (int)(fromLnxFmt[0] - n3);
            }
        }
        else {
            n4 = -1 + (int)(n2 - fromLnxFmt[0]);
            i = 0;
        }
        int j = fromLnxFmt.length - 1;
        Label_0186: {
            if (b2) {
                if (j <= 8) {
                    break Label_0186;
                }
            }
            else if (j < 8) {
                break Label_0186;
            }
            j = 8;
            b = true;
        }
        double n6 = 0.0;
        switch (j % 4) {
            case 3: {
                final int n5 = (fromLnxFmt[1] * 100 + fromLnxFmt[2]) * 100 + fromLnxFmt[3];
                n4 += 3;
                if (LnxLibThin.factorTable[n4][1] < 1.0) {
                    n6 = n5 / LnxLibThin.factorTable[n4][2];
                }
                else {
                    n6 = n5 * LnxLibThin.factorTable[n4][1];
                }
                n += 3;
                j -= 3;
                break;
            }
            case 2: {
                final int n7 = fromLnxFmt[1] * 100 + fromLnxFmt[2];
                n4 += 2;
                if (LnxLibThin.factorTable[n4][1] < 1.0) {
                    n6 = n7 / LnxLibThin.factorTable[n4][2];
                }
                else {
                    n6 = n7 * LnxLibThin.factorTable[n4][1];
                }
                n += 2;
                j -= 2;
                break;
            }
            case 1: {
                final byte b3 = fromLnxFmt[1];
                ++n4;
                if (LnxLibThin.factorTable[n4][1] < 1.0) {
                    n6 = b3 / LnxLibThin.factorTable[n4][2];
                }
                else {
                    n6 = b3 * LnxLibThin.factorTable[n4][1];
                }
                ++n;
                --j;
                break;
            }
            default: {
                n6 = 0.0;
                break;
            }
        }
        while (j > 0) {
            final int n8 = ((fromLnxFmt[n] * 100 + fromLnxFmt[n + 1]) * 100 + fromLnxFmt[n + 2]) * 100 + fromLnxFmt[n + 3];
            n4 += 4;
            if (LnxLibThin.factorTable[n4][1] < 1.0) {
                n6 += n8 / LnxLibThin.factorTable[n4][2];
            }
            else {
                n6 += n8 * LnxLibThin.factorTable[n4][1];
            }
            n += 4;
            j -= 4;
        }
        if (b) {
            if (b2) {
                if (fromLnxFmt[n] > 50) {
                    n6 += 1 * LnxLibThin.factorTable[n4][1];
                }
            }
            else {
                --n;
                int n9;
                if (fromLnxFmt[n] % 10 >= 5) {
                    n9 = (fromLnxFmt[n] / 10 + 1) * 10;
                }
                else {
                    n9 = fromLnxFmt[n] / 10 * 10;
                }
                n6 += (n9 - fromLnxFmt[n]) * LnxLibThin.factorTable[n4][1];
            }
        }
        if (i != 0) {
            int n10 = 0;
            while (i > 0) {
                if ((int)LnxLibThin.powerTable[n10][0] <= i) {
                    i -= (int)LnxLibThin.powerTable[n10][0];
                    n6 *= LnxLibThin.powerTable[n10][1];
                }
                ++n10;
            }
            while (i < 0) {
                if ((int)LnxLibThin.powerTable[n10][0] <= -i) {
                    i += (int)LnxLibThin.powerTable[n10][0];
                    n6 *= LnxLibThin.powerTable[n10][2];
                }
                ++n10;
            }
        }
        return NUMBER._isPositive(array) ? n6 : (-n6);
    }
    
    @Override
    public long lnxsni(final byte[] array) throws SQLException {
        long n = 0L;
        final byte[] fromLnxFmt = NUMBER._fromLnxFmt(array);
        final byte b = fromLnxFmt[0];
        final byte b2 = (byte)(fromLnxFmt.length - 1);
        for (int n2 = (b2 > b + 1) ? (b + 1) : b2, i = 0; i < n2; ++i) {
            n = n * 100L + fromLnxFmt[i + 1];
        }
        for (int j = b - b2; j >= 0; --j) {
            n *= 100L;
        }
        return NUMBER._isPositive(array) ? n : (-n);
    }
    
    private byte[] lnxqh2n(final char[] array) {
        int n = 0;
        int i = array.length;
        final long[] array2 = new long[14];
        int n2 = 13;
        final int n3 = 13;
        final byte[] array3 = new byte[42];
        int n4 = 1;
        while (i != 0 && array[i - 1] == '\0') {
            --i;
        }
        while (i != 0 && array[n] == '0') {
            ++n;
            --i;
        }
        if (i == 0) {
            return NUMBER._makeZero();
        }
        array2[n3] = 0L;
        switch (i % 3) {
            case 0: {
                array2[n3] = this.LNXQH2N_DIGIT(array[n], 8, array2[n3]);
                ++n;
                --i;
            }
            case 2: {
                array2[n3] = this.LNXQH2N_DIGIT(array[n], 4, array2[n3]);
                ++n;
                --i;
            }
            case 1: {
                array2[n3] = this.LNXQH2N_DIGIT(array[n], 0, array2[n3]);
                ++n;
                --i;
                break;
            }
        }
        while (i != 0) {
            long lnxqh2N_DIGIT = this.LNXQH2N_DIGIT(array[n + 2], 0, this.LNXQH2N_DIGIT(array[n + 1], 4, this.LNXQH2N_DIGIT(array[n], 8, 0L)));
            for (int j = n3; j >= n2; --j) {
                final long n5 = lnxqh2N_DIGIT + (array2[j] << 12);
                array2[j] = n5 % 1000000L;
                lnxqh2N_DIGIT = n5 / 1000000L;
            }
            if (lnxqh2N_DIGIT != 0L) {
                --n2;
                array2[n2] = lnxqh2N_DIGIT;
            }
            n += 3;
            i -= 3;
        }
        final int n6 = 3 * (n3 - n2) + 1 + ((array2[n2] >= 100L) ? 1 : 0) + ((array2[n2] >= 10000L) ? 1 : 0);
        final byte[] array4 = new byte[22];
        final int n7 = 0;
        array4[n7] = (byte)(n6 + 192);
        byte[] array5;
        int n8;
        int n9;
        if (n6 > 20) {
            array5 = array3;
            n8 = n4;
            n9 = 21;
        }
        else {
            array5 = array4;
            n8 = n7 + 1;
            n9 = n6 + 1;
        }
        switch (n6 % 3) {
            case 0: {
                array5[n8] = (byte)(array2[n2] / 10000L + 1L);
                ++n8;
            }
            case 2: {
                array5[n8] = (byte)(array2[n2] % 10000L / 100L + 1L);
                ++n8;
            }
            case 1: {
                array5[n8] = (byte)(array2[n2] % 100L + 1L);
                ++n8;
                break;
            }
        }
        for (int k = n2 + 1; k <= n3; ++k) {
            array5[n8] = (byte)(array2[k] / 10000L + 1L);
            array5[n8 + 1] = (byte)(array2[k] % 10000L / 100L + 1L);
            array5[n8 + 2] = (byte)(array2[k] % 100L + 1L);
            n8 += 3;
        }
        if (n6 > 20) {
            int n10 = n4 + 20;
            if (array3[n10] > 50) {
                array3[n4 - 1] = 1;
                --n10;
                while (array3[n10] == 100) {
                    --n10;
                    --n9;
                }
                final byte[] array6 = array3;
                final int n11 = n10;
                ++array6[n11];
                if (n10 < n4) {
                    --n4;
                    final byte[] array7 = array4;
                    final int n12 = n7;
                    ++array7[n12];
                    n9 = 2;
                }
            }
            for (int l = 0; l < n9; ++l) {
                array4[n7 + 1 + l] = array3[n4 + l];
            }
        }
        for (int n13 = n7 + (n9 - 1); array5[n13] == 1; --n13, --n9) {}
        final byte[] array8 = new byte[n9];
        System.arraycopy(array4, 0, array8, 0, n9);
        return array8;
    }
    
    private long LNXQH2N_DIGIT(final char c, final int n, final long n2) {
        if (c >= 'a' && c <= 'f') {
            return n2 + (c - 'a' + 10 << n);
        }
        if (c >= 'A' && c <= 'F') {
            return n2 + (c - 'A' + 10 << n);
        }
        return n2 + (c - '0' << n);
    }
    
    private byte[] lnxqtra(final byte[] array, final int n) throws SQLException {
        final byte[] shareBytes = NUMBER.pi().shareBytes();
        final byte[] lnxmin = this.lnxmin(-1L);
        long lnxsni = 0L;
        byte[] array2;
        byte[] array3;
        if (n == 3 || n == 4 || n == 5) {
            final byte[] lnxmul = this.lnxmul(LnxLibThin.lnxqtwo, shareBytes);
            array2 = this.lnxmod(this.lnxabs(array), lnxmul);
            if (this.lnxcmp(array2, shareBytes) > 0) {
                array2 = this.lnxsub(array2, lnxmul);
            }
            if (this.lnxsgn(array) == -1) {
                array2 = this.lnxneg(array2);
            }
            array3 = this.lnxmul(array2, array2);
        }
        else if (n == 9) {
            array2 = this.lnxmod(array, LnxLibThin.lnxqone);
            final byte[] lnxsub = this.lnxsub(array, array2);
            if ((lnxsub[0] & 0xFF) < 60) {
                return NUMBER._makeZero();
            }
            if ((lnxsub[0] & 0xFF) > 195) {
                return NUMBER._makePosInf();
            }
            lnxsni = this.lnxsni(lnxsub);
            array3 = this.lnxmul(array2, array2);
        }
        else {
            array2 = new byte[array.length];
            System.arraycopy(array, 0, array2, 0, array.length);
            array3 = this.lnxmul(array2, array2);
        }
        byte[] array4 = null;
        byte[] array5 = null;
        if (n != 4 && n != 7) {
            byte[] array6 = LnxLibThin.lnxqone;
            array4 = LnxLibThin.lnxqone;
            array5 = NUMBER._makeZero();
            int n2 = 0;
            do {
                final byte[] lnxmul2 = this.lnxmul(array3, array6);
                final int n3 = (n2 + 1) * (n2 + 2);
                n2 += 2;
                final byte[] lnxqIDiv = this.lnxqIDiv(lnxmul2, n3);
                array5 = this.lnxadd(array5, lnxqIDiv);
                final byte[] lnxmul3 = this.lnxmul(array3, lnxqIDiv);
                final int n4 = (n2 + 1) * (n2 + 2);
                n2 += 2;
                array6 = this.lnxqIDiv(lnxmul3, n4);
                array4 = this.lnxadd(array4, array6);
            } while ((array6[0] & 0xFF) + 20 >= (array4[0] & 0xFF) && (array5[0] & 0xFF) != 0xFF);
        }
        byte[] lnxadd = null;
        byte[] array7 = null;
        if (n != 3 && n != 6) {
            byte[] lnxqIDiv2 = new byte[array2.length];
            System.arraycopy(array2, 0, lnxqIDiv2, 0, array2.length);
            lnxadd = new byte[array2.length];
            System.arraycopy(array2, 0, lnxadd, 0, array2.length);
            array7 = NUMBER._makeZero();
            int n5 = 1;
            do {
                final byte[] lnxmul4 = this.lnxmul(array3, lnxqIDiv2);
                final int n6 = (n5 + 1) * (n5 + 2);
                n5 += 2;
                final byte[] lnxqIDiv3 = this.lnxqIDiv(lnxmul4, n6);
                array7 = this.lnxadd(array7, lnxqIDiv3);
                final byte[] lnxmul5 = this.lnxmul(array3, lnxqIDiv3);
                final int n7 = (n5 + 1) * (n5 + 2);
                n5 += 2;
                lnxqIDiv2 = this.lnxqIDiv(lnxmul5, n7);
                lnxadd = this.lnxadd(lnxadd, lnxqIDiv2);
                if ((lnxqIDiv2[0] & 0xFF) == 0x80 && lnxqIDiv2.length == 1) {
                    break;
                }
                if ((lnxqIDiv2[0] & 0xFF) >= 128 && (lnxqIDiv2[0] & 0xFF) + 20 < (lnxadd[0] & 0xFF)) {
                    break;
                }
                if ((lnxqIDiv2[0] & 0xFF) < 128 && (lnxqIDiv2[0] & 0xFF) > (lnxadd[0] & 0xFF) + 20) {
                    break;
                }
            } while ((array7[0] & 0xFF) != 0xFF && (array7[0] & 0xFF) != 0x0);
        }
        byte[] array8 = null;
        if (n == 3 || n == 4 || n == 5) {
            if (n == 3 || n == 5) {
                array8 = this.lnxsub(array4, array5);
                if (this.lnxcmp(array8, LnxLibThin.lnxqone) > 0) {
                    array8 = LnxLibThin.lnxqone;
                }
                else if (this.lnxcmp(array8, lnxmin) < 0) {
                    array8 = lnxmin;
                }
            }
            if (n == 3) {
                return array8;
            }
            byte[] array9 = this.lnxsub(lnxadd, array7);
            if (this.lnxcmp(array9, LnxLibThin.lnxqone) > 0) {
                array9 = LnxLibThin.lnxqone;
            }
            else if (this.lnxcmp(array9, lnxmin) < 0) {
                array9 = lnxmin;
            }
            if (n == 4) {
                return array9;
            }
            return this.lnxdiv(array9, array8);
        }
        else {
            if (n == 6) {
                return this.lnxadd(array4, array5);
            }
            if (n == 7) {
                return this.lnxadd(lnxadd, array7);
            }
            final byte[] lnxadd2 = this.lnxadd(lnxadd, array7);
            final byte[] lnxadd3 = this.lnxadd(array4, array5);
            if (n == 8) {
                return this.lnxdiv(lnxadd2, lnxadd3);
            }
            return this.lnxmul(this.lnxadd(lnxadd3, lnxadd2), this.lnxpow(NUMBER.e().shareBytes(), (int)lnxsni));
        }
    }
    
    private byte[] lnxqtri(final byte[] array, final int n) throws SQLException {
        final byte[] shareBytes = NUMBER.pi().shareBytes();
        final byte[] lnxdiv = this.lnxdiv(shareBytes, LnxLibThin.lnxqtwo);
        if (n == 2) {
            if (NUMBER._isPosInf(array)) {
                return lnxdiv;
            }
            if (NUMBER._isNegInf(array)) {
                return this.lnxneg(lnxdiv);
            }
        }
        byte[] array2 = this.lnxabs(array);
        if (n == 1 || n == 0) {
            if (this.lnxcmp(array2, LnxLibThin.lnxqone) > 0) {
                throw new SQLException(CoreException.getMessage((byte)11));
            }
            if ((array2[0] & 0xFF) <= 183) {
                if (n == 1) {
                    final byte[] array3 = new byte[array.length];
                    System.arraycopy(array, 0, array3, 0, array.length);
                    return array3;
                }
                return this.lnxsub(lnxdiv, array);
            }
            else {
                array2 = this.lnxsqr(this.lnxdiv(this.lnxsub(LnxLibThin.lnxqone, array2), this.lnxadd(LnxLibThin.lnxqone, array2)));
            }
        }
        final int lnxcmp;
        if ((lnxcmp = this.lnxcmp(array2, LnxLibThin.lnxqone)) > 0) {
            array2 = this.lnxdiv(LnxLibThin.lnxqone, array2);
        }
        byte[] array4 = new byte[array2.length];
        System.arraycopy(array2, 0, array4, 0, array2.length);
        int n2 = 1;
        while (true) {
            final byte[] lnxtan = this.lnxtan(array4);
            final byte[] lnxdiv2 = this.lnxdiv(this.lnxsub(array2, lnxtan), this.lnxadd(this.lnxmul(lnxtan, lnxtan), LnxLibThin.lnxqone));
            final int n3 = ((lnxdiv2[0] & 0xFF) >= 128) ? ((lnxdiv2[0] & 0xFF) - 193) : (62 - (lnxdiv2[0] & 0xFF));
            final int n4 = ((array4[0] & 0xFF) >= 128) ? ((array4[0] & 0xFF) - 193) : (62 - (array4[0] & 0xFF));
            if ((lnxdiv2[0] & 0xFF) == 0x80 && lnxdiv2.length == 1) {
                break;
            }
            if ((n3 & 0xFF) + 15 < (n4 & 0xFF)) {
                break;
            }
            if (n2 > 15) {
                break;
            }
            array4 = this.lnxadd(array4, lnxdiv2);
            ++n2;
        }
        if (lnxcmp > 0) {
            array4 = this.lnxsub(lnxdiv, array4);
        }
        if ((array4[0] & 0xFF) < 128) {
            array4 = NUMBER._makeZero();
        }
        if (this.lnxcmp(array4, lnxdiv) > 0) {
            array4 = lnxdiv;
        }
        if (n == 1 || n == 0) {
            array4 = this.lnxmul(array4, LnxLibThin.lnxqtwo);
        }
        switch (n) {
            case 1: {
                if (NUMBER._isPositive(array)) {
                    return this.lnxsub(lnxdiv, array4);
                }
                return this.lnxsub(array4, lnxdiv);
            }
            case 0: {
                if (NUMBER._isPositive(array)) {
                    return array4;
                }
                return this.lnxsub(shareBytes, array4);
            }
            case 2: {
                if (NUMBER._isPositive(array)) {
                    return array4;
                }
                return this.lnxneg(array4);
            }
            default: {
                throw new SQLException(CoreException.getMessage((byte)11));
            }
        }
    }
    
    private int lnxcmp(final byte[] array, final byte[] array2) {
        return Datum.compareBytes(array, array2);
    }
    
    private int lnxsgn(final byte[] array) {
        if (NUMBER._isZero(array)) {
            return 0;
        }
        if (NUMBER._isPositive(array)) {
            return 1;
        }
        return -1;
    }
    
    private byte[] lnxqIDiv(final byte[] array, final int n) throws SQLException {
        return this.lnxdiv(array, this.lnxmin(n));
    }
    
    private static void _negateNumber(final byte[] array) {
        for (int i = array.length - 1; i > 0; --i) {
            array[i] = LnxLibThin.LnxqNegate[array[i]];
        }
        array[0] ^= -1;
    }
    
    private static byte[] _setLength(final byte[] array, final int n) {
        byte[] array2;
        if (NUMBER._isPositive(array)) {
            array2 = new byte[n];
        }
        else if (n <= 20 && array[n - 1] != 102) {
            array2 = new byte[n + 1];
            array2[n] = 102;
        }
        else {
            array2 = new byte[n];
        }
        System.arraycopy(array, 0, array2, 0, n);
        return array2;
    }
    
    static {
        lnxqone = new byte[] { -63, 2 };
        lnxqtwo = new byte[] { -63, 3 };
        LnxLibThin.LnxqFirstDigit = new byte[] { 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
        LnxLibThin.LnxqNegate = new byte[] { 0, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
        LnxLibThin.LnxqTruncate_P = new byte[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 91, 91, 91, 91, 91, 91, 91, 91, 91, 91 };
        LnxLibThin.LnxqTruncate_N = new byte[] { 0, 0, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 91, 91, 91, 91, 91, 91, 91, 91, 91, 91, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101 };
        LnxLibThin.LnxqRound_P = new byte[] { 0, 1, 1, 1, 1, 1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 91, 91, 91, 91, 91, 91, 91, 91, 91, 91, 101, 101, 101, 101, 101 };
        LnxLibThin.LnxqRound_N = new byte[] { 0, 0, 1, 1, 1, 1, 1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 91, 91, 91, 91, 91, 91, 91, 91, 91, 91, 101, 101, 101, 101, 101 };
        LnxLibThin.LnxqComponents_P = new byte[][] { { 0, 0 }, { 0, 0 }, { 0, 1 }, { 0, 2 }, { 0, 3 }, { 0, 4 }, { 0, 5 }, { 0, 6 }, { 0, 7 }, { 0, 8 }, { 0, 9 }, { 1, 0 }, { 1, 1 }, { 1, 2 }, { 1, 3 }, { 1, 4 }, { 1, 5 }, { 1, 6 }, { 1, 7 }, { 1, 8 }, { 1, 9 }, { 2, 0 }, { 2, 1 }, { 2, 2 }, { 2, 3 }, { 2, 4 }, { 2, 5 }, { 2, 6 }, { 2, 7 }, { 2, 8 }, { 2, 9 }, { 3, 0 }, { 3, 1 }, { 3, 2 }, { 3, 3 }, { 3, 4 }, { 3, 5 }, { 3, 6 }, { 3, 7 }, { 3, 8 }, { 3, 9 }, { 4, 0 }, { 4, 1 }, { 4, 2 }, { 4, 3 }, { 4, 4 }, { 4, 5 }, { 4, 6 }, { 4, 7 }, { 4, 8 }, { 4, 9 }, { 5, 0 }, { 5, 1 }, { 5, 2 }, { 5, 3 }, { 5, 4 }, { 5, 5 }, { 5, 6 }, { 5, 7 }, { 5, 8 }, { 5, 9 }, { 6, 0 }, { 6, 1 }, { 6, 2 }, { 6, 3 }, { 6, 4 }, { 6, 5 }, { 6, 6 }, { 6, 7 }, { 6, 8 }, { 6, 9 }, { 7, 0 }, { 7, 1 }, { 7, 2 }, { 7, 3 }, { 7, 4 }, { 7, 5 }, { 7, 6 }, { 7, 7 }, { 7, 8 }, { 7, 9 }, { 8, 0 }, { 8, 1 }, { 8, 2 }, { 8, 3 }, { 8, 4 }, { 8, 5 }, { 8, 6 }, { 8, 7 }, { 8, 8 }, { 8, 9 }, { 9, 0 }, { 9, 1 }, { 9, 2 }, { 9, 3 }, { 9, 4 }, { 9, 5 }, { 9, 6 }, { 9, 7 }, { 9, 8 }, { 9, 9 } };
        LnxLibThin.LnxqComponents_N = new byte[][] { { 0, 0 }, { 0, 0 }, { 9, 9 }, { 9, 8 }, { 9, 7 }, { 9, 6 }, { 9, 5 }, { 9, 4 }, { 9, 3 }, { 9, 2 }, { 9, 1 }, { 9, 0 }, { 8, 9 }, { 8, 8 }, { 8, 7 }, { 8, 6 }, { 8, 5 }, { 8, 4 }, { 8, 3 }, { 8, 2 }, { 8, 1 }, { 8, 0 }, { 7, 9 }, { 7, 8 }, { 7, 7 }, { 7, 6 }, { 7, 5 }, { 7, 4 }, { 7, 3 }, { 7, 2 }, { 7, 1 }, { 7, 0 }, { 6, 9 }, { 6, 8 }, { 6, 7 }, { 6, 6 }, { 6, 5 }, { 6, 4 }, { 6, 3 }, { 6, 2 }, { 6, 1 }, { 6, 0 }, { 5, 9 }, { 5, 8 }, { 5, 7 }, { 5, 6 }, { 5, 5 }, { 5, 4 }, { 5, 3 }, { 5, 2 }, { 5, 1 }, { 5, 0 }, { 4, 9 }, { 4, 8 }, { 4, 7 }, { 4, 6 }, { 4, 5 }, { 4, 4 }, { 4, 3 }, { 4, 2 }, { 4, 1 }, { 4, 0 }, { 3, 9 }, { 3, 8 }, { 3, 7 }, { 3, 6 }, { 3, 5 }, { 3, 4 }, { 3, 3 }, { 3, 2 }, { 3, 1 }, { 3, 0 }, { 2, 9 }, { 2, 8 }, { 2, 7 }, { 2, 6 }, { 2, 5 }, { 2, 4 }, { 2, 3 }, { 2, 2 }, { 2, 1 }, { 2, 0 }, { 1, 9 }, { 1, 8 }, { 1, 7 }, { 1, 6 }, { 1, 5 }, { 1, 4 }, { 1, 3 }, { 1, 2 }, { 1, 1 }, { 1, 0 }, { 0, 9 }, { 0, 8 }, { 0, 7 }, { 0, 6 }, { 0, 5 }, { 0, 4 }, { 0, 3 }, { 0, 2 }, { 0, 1 }, { 0, 0 } };
        LnxLibThin.LnxqAdd_PPP = new byte[][] { { 0, 0 }, { 0, 1 }, { 1, 0 }, { 2, 0 }, { 3, 0 }, { 4, 0 }, { 5, 0 }, { 6, 0 }, { 7, 0 }, { 8, 0 }, { 9, 0 }, { 10, 0 }, { 11, 0 }, { 12, 0 }, { 13, 0 }, { 14, 0 }, { 15, 0 }, { 16, 0 }, { 17, 0 }, { 18, 0 }, { 19, 0 }, { 20, 0 }, { 21, 0 }, { 22, 0 }, { 23, 0 }, { 24, 0 }, { 25, 0 }, { 26, 0 }, { 27, 0 }, { 28, 0 }, { 29, 0 }, { 30, 0 }, { 31, 0 }, { 32, 0 }, { 33, 0 }, { 34, 0 }, { 35, 0 }, { 36, 0 }, { 37, 0 }, { 38, 0 }, { 39, 0 }, { 40, 0 }, { 41, 0 }, { 42, 0 }, { 43, 0 }, { 44, 0 }, { 45, 0 }, { 46, 0 }, { 47, 0 }, { 48, 0 }, { 49, 0 }, { 50, 0 }, { 51, 0 }, { 52, 0 }, { 53, 0 }, { 54, 0 }, { 55, 0 }, { 56, 0 }, { 57, 0 }, { 58, 0 }, { 59, 0 }, { 60, 0 }, { 61, 0 }, { 62, 0 }, { 63, 0 }, { 64, 0 }, { 65, 0 }, { 66, 0 }, { 67, 0 }, { 68, 0 }, { 69, 0 }, { 70, 0 }, { 71, 0 }, { 72, 0 }, { 73, 0 }, { 74, 0 }, { 75, 0 }, { 76, 0 }, { 77, 0 }, { 78, 0 }, { 79, 0 }, { 80, 0 }, { 81, 0 }, { 82, 0 }, { 83, 0 }, { 84, 0 }, { 85, 0 }, { 86, 0 }, { 87, 0 }, { 88, 0 }, { 89, 0 }, { 90, 0 }, { 91, 0 }, { 92, 0 }, { 93, 0 }, { 94, 0 }, { 95, 0 }, { 96, 0 }, { 97, 0 }, { 98, 0 }, { 99, 0 }, { 100, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 5, 1 }, { 6, 1 }, { 7, 1 }, { 8, 1 }, { 9, 1 }, { 10, 1 }, { 11, 1 }, { 12, 1 }, { 13, 1 }, { 14, 1 }, { 15, 1 }, { 16, 1 }, { 17, 1 }, { 18, 1 }, { 19, 1 }, { 20, 1 }, { 21, 1 }, { 22, 1 }, { 23, 1 }, { 24, 1 }, { 25, 1 }, { 26, 1 }, { 27, 1 }, { 28, 1 }, { 29, 1 }, { 30, 1 }, { 31, 1 }, { 32, 1 }, { 33, 1 }, { 34, 1 }, { 35, 1 }, { 36, 1 }, { 37, 1 }, { 38, 1 }, { 39, 1 }, { 40, 1 }, { 41, 1 }, { 42, 1 }, { 43, 1 }, { 44, 1 }, { 45, 1 }, { 46, 1 }, { 47, 1 }, { 48, 1 }, { 49, 1 }, { 50, 1 }, { 51, 1 }, { 52, 1 }, { 53, 1 }, { 54, 1 }, { 55, 1 }, { 56, 1 }, { 57, 1 }, { 58, 1 }, { 59, 1 }, { 60, 1 }, { 61, 1 }, { 62, 1 }, { 63, 1 }, { 64, 1 }, { 65, 1 }, { 66, 1 }, { 67, 1 }, { 68, 1 }, { 69, 1 }, { 70, 1 }, { 71, 1 }, { 72, 1 }, { 73, 1 }, { 74, 1 }, { 75, 1 }, { 76, 1 }, { 77, 1 }, { 78, 1 }, { 79, 1 }, { 80, 1 }, { 81, 1 }, { 82, 1 }, { 83, 1 }, { 84, 1 }, { 85, 1 }, { 86, 1 }, { 87, 1 }, { 88, 1 }, { 89, 1 }, { 90, 1 }, { 91, 1 }, { 92, 1 }, { 93, 1 }, { 94, 1 }, { 95, 1 }, { 96, 1 }, { 97, 1 }, { 98, 1 }, { 99, 1 }, { 100, 1 } };
        LnxLibThin.LnxqAdd_NNN = new byte[][] { { 0, 2 }, { 0, 1 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 5, 1 }, { 6, 1 }, { 7, 1 }, { 8, 1 }, { 9, 1 }, { 10, 1 }, { 11, 1 }, { 12, 1 }, { 13, 1 }, { 14, 1 }, { 15, 1 }, { 16, 1 }, { 17, 1 }, { 18, 1 }, { 19, 1 }, { 20, 1 }, { 21, 1 }, { 22, 1 }, { 23, 1 }, { 24, 1 }, { 25, 1 }, { 26, 1 }, { 27, 1 }, { 28, 1 }, { 29, 1 }, { 30, 1 }, { 31, 1 }, { 32, 1 }, { 33, 1 }, { 34, 1 }, { 35, 1 }, { 36, 1 }, { 37, 1 }, { 38, 1 }, { 39, 1 }, { 40, 1 }, { 41, 1 }, { 42, 1 }, { 43, 1 }, { 44, 1 }, { 45, 1 }, { 46, 1 }, { 47, 1 }, { 48, 1 }, { 49, 1 }, { 50, 1 }, { 51, 1 }, { 52, 1 }, { 53, 1 }, { 54, 1 }, { 55, 1 }, { 56, 1 }, { 57, 1 }, { 58, 1 }, { 59, 1 }, { 60, 1 }, { 61, 1 }, { 62, 1 }, { 63, 1 }, { 64, 1 }, { 65, 1 }, { 66, 1 }, { 67, 1 }, { 68, 1 }, { 69, 1 }, { 70, 1 }, { 71, 1 }, { 72, 1 }, { 73, 1 }, { 74, 1 }, { 75, 1 }, { 76, 1 }, { 77, 1 }, { 78, 1 }, { 79, 1 }, { 80, 1 }, { 81, 1 }, { 82, 1 }, { 83, 1 }, { 84, 1 }, { 85, 1 }, { 86, 1 }, { 87, 1 }, { 88, 1 }, { 89, 1 }, { 90, 1 }, { 91, 1 }, { 92, 1 }, { 93, 1 }, { 94, 1 }, { 95, 1 }, { 96, 1 }, { 97, 1 }, { 98, 1 }, { 99, 1 }, { 100, 1 }, { 101, 1 }, { 2, 2 }, { 3, 2 }, { 4, 2 }, { 5, 2 }, { 6, 2 }, { 7, 2 }, { 8, 2 }, { 9, 2 }, { 10, 2 }, { 11, 2 }, { 12, 2 }, { 13, 2 }, { 14, 2 }, { 15, 2 }, { 16, 2 }, { 17, 2 }, { 18, 2 }, { 19, 2 }, { 20, 2 }, { 21, 2 }, { 22, 2 }, { 23, 2 }, { 24, 2 }, { 25, 2 }, { 26, 2 }, { 27, 2 }, { 28, 2 }, { 29, 2 }, { 30, 2 }, { 31, 2 }, { 32, 2 }, { 33, 2 }, { 34, 2 }, { 35, 2 }, { 36, 2 }, { 37, 2 }, { 38, 2 }, { 39, 2 }, { 40, 2 }, { 41, 2 }, { 42, 2 }, { 43, 2 }, { 44, 2 }, { 45, 2 }, { 46, 2 }, { 47, 2 }, { 48, 2 }, { 49, 2 }, { 50, 2 }, { 51, 2 }, { 52, 2 }, { 53, 2 }, { 54, 2 }, { 55, 2 }, { 56, 2 }, { 57, 2 }, { 58, 2 }, { 59, 2 }, { 60, 2 }, { 61, 2 }, { 62, 2 }, { 63, 2 }, { 64, 2 }, { 65, 2 }, { 66, 2 }, { 67, 2 }, { 68, 2 }, { 69, 2 }, { 70, 2 }, { 71, 2 }, { 72, 2 }, { 73, 2 }, { 74, 2 }, { 75, 2 }, { 76, 2 }, { 77, 2 }, { 78, 2 }, { 79, 2 }, { 80, 2 }, { 81, 2 }, { 82, 2 }, { 83, 2 }, { 84, 2 }, { 85, 2 }, { 86, 2 }, { 87, 2 }, { 88, 2 }, { 89, 2 }, { 90, 2 }, { 91, 2 }, { 92, 2 }, { 93, 2 }, { 94, 2 }, { 95, 2 }, { 96, 2 }, { 97, 2 }, { 98, 2 }, { 99, 2 }, { 100, 2 }, { 101, 2 } };
        LnxLibThin.LnxqAdd_PNP = new byte[][] { { 0, 2 }, { 0, 1 }, { 0, 0 }, { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 5, 1 }, { 6, 1 }, { 7, 1 }, { 8, 1 }, { 9, 1 }, { 10, 1 }, { 11, 1 }, { 12, 1 }, { 13, 1 }, { 14, 1 }, { 15, 1 }, { 16, 1 }, { 17, 1 }, { 18, 1 }, { 19, 1 }, { 20, 1 }, { 21, 1 }, { 22, 1 }, { 23, 1 }, { 24, 1 }, { 25, 1 }, { 26, 1 }, { 27, 1 }, { 28, 1 }, { 29, 1 }, { 30, 1 }, { 31, 1 }, { 32, 1 }, { 33, 1 }, { 34, 1 }, { 35, 1 }, { 36, 1 }, { 37, 1 }, { 38, 1 }, { 39, 1 }, { 40, 1 }, { 41, 1 }, { 42, 1 }, { 43, 1 }, { 44, 1 }, { 45, 1 }, { 46, 1 }, { 47, 1 }, { 48, 1 }, { 49, 1 }, { 50, 1 }, { 51, 1 }, { 52, 1 }, { 53, 1 }, { 54, 1 }, { 55, 1 }, { 56, 1 }, { 57, 1 }, { 58, 1 }, { 59, 1 }, { 60, 1 }, { 61, 1 }, { 62, 1 }, { 63, 1 }, { 64, 1 }, { 65, 1 }, { 66, 1 }, { 67, 1 }, { 68, 1 }, { 69, 1 }, { 70, 1 }, { 71, 1 }, { 72, 1 }, { 73, 1 }, { 74, 1 }, { 75, 1 }, { 76, 1 }, { 77, 1 }, { 78, 1 }, { 79, 1 }, { 80, 1 }, { 81, 1 }, { 82, 1 }, { 83, 1 }, { 84, 1 }, { 85, 1 }, { 86, 1 }, { 87, 1 }, { 88, 1 }, { 89, 1 }, { 90, 1 }, { 91, 1 }, { 92, 1 }, { 93, 1 }, { 94, 1 }, { 95, 1 }, { 96, 1 }, { 97, 1 }, { 98, 1 }, { 99, 1 }, { 100, 1 }, { 1, 2 }, { 2, 2 }, { 3, 2 }, { 4, 2 }, { 5, 2 }, { 6, 2 }, { 7, 2 }, { 8, 2 }, { 9, 2 }, { 10, 2 }, { 11, 2 }, { 12, 2 }, { 13, 2 }, { 14, 2 }, { 15, 2 }, { 16, 2 }, { 17, 2 }, { 18, 2 }, { 19, 2 }, { 20, 2 }, { 21, 2 }, { 22, 2 }, { 23, 2 }, { 24, 2 }, { 25, 2 }, { 26, 2 }, { 27, 2 }, { 28, 2 }, { 29, 2 }, { 30, 2 }, { 31, 2 }, { 32, 2 }, { 33, 2 }, { 34, 2 }, { 35, 2 }, { 36, 2 }, { 37, 2 }, { 38, 2 }, { 39, 2 }, { 40, 2 }, { 41, 2 }, { 42, 2 }, { 43, 2 }, { 44, 2 }, { 45, 2 }, { 46, 2 }, { 47, 2 }, { 48, 2 }, { 49, 2 }, { 50, 2 }, { 51, 2 }, { 52, 2 }, { 53, 2 }, { 54, 2 }, { 55, 2 }, { 56, 2 }, { 57, 2 }, { 58, 2 }, { 59, 2 }, { 60, 2 }, { 61, 2 }, { 62, 2 }, { 63, 2 }, { 64, 2 }, { 65, 2 }, { 66, 2 }, { 67, 2 }, { 68, 2 }, { 69, 2 }, { 70, 2 }, { 71, 2 }, { 72, 2 }, { 73, 2 }, { 74, 2 }, { 75, 2 }, { 76, 2 }, { 77, 2 }, { 78, 2 }, { 79, 2 }, { 80, 2 }, { 81, 2 }, { 82, 2 }, { 83, 2 }, { 84, 2 }, { 85, 2 }, { 86, 2 }, { 87, 2 }, { 88, 2 }, { 89, 2 }, { 90, 2 }, { 91, 2 }, { 92, 2 }, { 93, 2 }, { 94, 2 }, { 95, 2 }, { 96, 2 }, { 97, 2 }, { 98, 2 }, { 99, 2 }, { 100, 2 } };
        LnxLibThin.LnxqAdd_PNN = new byte[][] { { 0, 0 }, { 0, 1 }, { 0, 0 }, { 2, 0 }, { 3, 0 }, { 4, 0 }, { 5, 0 }, { 6, 0 }, { 7, 0 }, { 8, 0 }, { 9, 0 }, { 10, 0 }, { 11, 0 }, { 12, 0 }, { 13, 0 }, { 14, 0 }, { 15, 0 }, { 16, 0 }, { 17, 0 }, { 18, 0 }, { 19, 0 }, { 20, 0 }, { 21, 0 }, { 22, 0 }, { 23, 0 }, { 24, 0 }, { 25, 0 }, { 26, 0 }, { 27, 0 }, { 28, 0 }, { 29, 0 }, { 30, 0 }, { 31, 0 }, { 32, 0 }, { 33, 0 }, { 34, 0 }, { 35, 0 }, { 36, 0 }, { 37, 0 }, { 38, 0 }, { 39, 0 }, { 40, 0 }, { 41, 0 }, { 42, 0 }, { 43, 0 }, { 44, 0 }, { 45, 0 }, { 46, 0 }, { 47, 0 }, { 48, 0 }, { 49, 0 }, { 50, 0 }, { 51, 0 }, { 52, 0 }, { 53, 0 }, { 54, 0 }, { 55, 0 }, { 56, 0 }, { 57, 0 }, { 58, 0 }, { 59, 0 }, { 60, 0 }, { 61, 0 }, { 62, 0 }, { 63, 0 }, { 64, 0 }, { 65, 0 }, { 66, 0 }, { 67, 0 }, { 68, 0 }, { 69, 0 }, { 70, 0 }, { 71, 0 }, { 72, 0 }, { 73, 0 }, { 74, 0 }, { 75, 0 }, { 76, 0 }, { 77, 0 }, { 78, 0 }, { 79, 0 }, { 80, 0 }, { 81, 0 }, { 82, 0 }, { 83, 0 }, { 84, 0 }, { 85, 0 }, { 86, 0 }, { 87, 0 }, { 88, 0 }, { 89, 0 }, { 90, 0 }, { 91, 0 }, { 92, 0 }, { 93, 0 }, { 94, 0 }, { 95, 0 }, { 96, 0 }, { 97, 0 }, { 98, 0 }, { 99, 0 }, { 100, 0 }, { 101, 0 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 5, 1 }, { 6, 1 }, { 7, 1 }, { 8, 1 }, { 9, 1 }, { 10, 1 }, { 11, 1 }, { 12, 1 }, { 13, 1 }, { 14, 1 }, { 15, 1 }, { 16, 1 }, { 17, 1 }, { 18, 1 }, { 19, 1 }, { 20, 1 }, { 21, 1 }, { 22, 1 }, { 23, 1 }, { 24, 1 }, { 25, 1 }, { 26, 1 }, { 27, 1 }, { 28, 1 }, { 29, 1 }, { 30, 1 }, { 31, 1 }, { 32, 1 }, { 33, 1 }, { 34, 1 }, { 35, 1 }, { 36, 1 }, { 37, 1 }, { 38, 1 }, { 39, 1 }, { 40, 1 }, { 41, 1 }, { 42, 1 }, { 43, 1 }, { 44, 1 }, { 45, 1 }, { 46, 1 }, { 47, 1 }, { 48, 1 }, { 49, 1 }, { 50, 1 }, { 51, 1 }, { 52, 1 }, { 53, 1 }, { 54, 1 }, { 55, 1 }, { 56, 1 }, { 57, 1 }, { 58, 1 }, { 59, 1 }, { 60, 1 }, { 61, 1 }, { 62, 1 }, { 63, 1 }, { 64, 1 }, { 65, 1 }, { 66, 1 }, { 67, 1 }, { 68, 1 }, { 69, 1 }, { 70, 1 }, { 71, 1 }, { 72, 1 }, { 73, 1 }, { 74, 1 }, { 75, 1 }, { 76, 1 }, { 77, 1 }, { 78, 1 }, { 79, 1 }, { 80, 1 }, { 81, 1 }, { 82, 1 }, { 83, 1 }, { 84, 1 }, { 85, 1 }, { 86, 1 }, { 87, 1 }, { 88, 1 }, { 89, 1 }, { 90, 1 }, { 91, 1 }, { 92, 1 }, { 93, 1 }, { 94, 1 }, { 95, 1 }, { 96, 1 }, { 97, 1 }, { 98, 1 }, { 99, 1 }, { 100, 1 }, { 101, 1 } };
        LnxLibThin.LnxsubIdentity = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101 };
        LnxLibThin.LnxqDigit_P = new byte[][] { { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 }, { 21, 22, 23, 24, 25, 26, 27, 28, 29, 30 }, { 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }, { 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 }, { 51, 52, 53, 54, 55, 56, 57, 58, 59, 60 }, { 61, 62, 63, 64, 65, 66, 67, 68, 69, 70 }, { 71, 72, 73, 74, 75, 76, 77, 78, 79, 80 }, { 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 }, { 91, 92, 93, 94, 95, 96, 97, 98, 99, 100 } };
        LnxLibThin.LnxqDigit_N = new byte[][] { { 101, 100, 99, 98, 97, 96, 95, 94, 93, 92 }, { 91, 90, 89, 88, 87, 86, 85, 84, 83, 82 }, { 81, 80, 79, 78, 77, 76, 75, 74, 73, 72 }, { 71, 70, 69, 68, 67, 66, 65, 64, 63, 62 }, { 61, 60, 59, 58, 57, 56, 55, 54, 53, 52 }, { 51, 50, 49, 48, 47, 46, 45, 44, 43, 42 }, { 41, 40, 39, 38, 37, 36, 35, 34, 33, 32 }, { 31, 30, 29, 28, 27, 26, 25, 24, 23, 22 }, { 21, 20, 19, 18, 17, 16, 15, 14, 13, 12 }, { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 } };
        powerTable = new double[][] { { 128.0, 1.0E256, 1.0E-256 }, { 64.0, 1.0E128, 1.0E-128 }, { 32.0, 1.0E64, 1.0E-64 }, { 16.0, 1.0E32, 1.0E-32 }, { 8.0, 1.0E16, 1.0E-16 }, { 4.0, 1.0E8, 1.0E-8 }, { 2.0, 10000.0, 1.0E-4 }, { 1.0, 100.0, 0.01 } };
        factorTable = new double[][] { { 15.0, 1.0E30, 1.0E-30 }, { 14.0, 1.0E28, 1.0E-28 }, { 13.0, 1.0E26, 1.0E-26 }, { 12.0, 1.0E24, 1.0E-24 }, { 11.0, 1.0E22, 1.0E-22 }, { 10.0, 1.0E20, 1.0E-20 }, { 9.0, 1.0E18, 1.0E-18 }, { 8.0, 1.0E16, 1.0E-16 }, { 7.0, 1.0E14, 1.0E-14 }, { 6.0, 1.0E12, 1.0E-12 }, { 5.0, 1.0E10, 1.0E-10 }, { 4.0, 1.0E8, 1.0E-8 }, { 3.0, 1000000.0, 1.0E-6 }, { 2.0, 10000.0, 1.0E-4 }, { 1.0, 100.0, 0.01 }, { 0.0, 1.0, 1.0 }, { -1.0, 0.01, 100.0 }, { -2.0, 1.0E-4, 10000.0 }, { -3.0, 1.0E-6, 1000000.0 }, { -4.0, 1.0E-8, 1.0E8 }, { -5.0, 1.0E-10, 1.0E10 }, { -6.0, 1.0E-12, 1.0E12 }, { -7.0, 1.0E-14, 1.0E14 }, { -8.0, 1.0E-16, 1.0E16 }, { -9.0, 1.0E-18, 1.0E18 }, { -10.0, 1.0E-20, 1.0E20 }, { -11.0, 1.0E-22, 1.0E22 }, { -12.0, 1.0E-24, 1.0E24 }, { -13.0, 1.0E-26, 1.0E26 }, { -14.0, 1.0E-28, 1.0E28 }, { -15.0, 1.0E-30, 1.0E30 }, { -16.0, 1.0E-32, 1.0E32 }, { -17.0, 1.0E-34, 1.0E34 }, { -18.0, 1.0E-36, 1.0E36 }, { -19.0, 1.0E-38, 1.0E38 }, { -20.0, 1.0E-40, 1.0E40 }, { -21.0, 1.0E-42, 1.0E42 }, { -22.0, 1.0E-44, 1.0E44 }, { -23.0, 1.0E-46, 1.0E46 }, { -24.0, 1.0E-48, 1.0E48 }, { -25.0, 1.0E-50, 1.0E50 }, { -26.0, 1.0E-52, 1.0E52 }, { -27.0, 1.0E-54, 1.0E54 }, { -28.0, 1.0E-56, 1.0E56 }, { -29.0, 1.0E-58, 1.0E58 }, { -30.0, 1.0E-60, 1.0E60 }, { -31.0, 1.0E-62, 1.0E62 }, { -32.0, 1.0E-64, 1.0E64 }, { -33.0, 1.0E-66, 1.0E66 }, { -34.0, 1.0E-68, 1.0E68 } };
    }
    
    private static class lnxqc
    {
        static final int LNXQC0 = 0;
        static final int LNXQC1 = 1;
        static final int LNXQC2 = 2;
        static final int LNXQC3 = 3;
        static final int LNXQC4 = 4;
        static final int LNXQC5 = 5;
        static final int LNXQC6 = 6;
        static final int LNXQC7 = 7;
        static final int LNXQC8 = 8;
        static final int LNXQC9 = 9;
        static final int LNXQCPLUS = 10;
        static final int LNXQCMINUS = 11;
        static final int LNXQCSPACE = 12;
        static final int LNXQCDOT = 13;
        static final int LNXQCCOMMA = 14;
        static final int LNXQCDOLLR = 15;
        static final int LNXQCLT = 16;
        static final int LNXQCGRT = 17;
        static final int LNXQCLPT = 18;
        static final int LNXQCRPT = 19;
        static final int LNXQCHASH = 20;
        static final int LNXQCTILDE = 21;
        static final int LNXQCASML = 22;
        static final int LNXQCBSML = 23;
        static final int LNXQCCSML = 24;
        static final int LNXQCDSML = 25;
        static final int LNXQCESML = 26;
        static final int LNXQCFSML = 27;
        static final int LNXQCGSML = 28;
        static final int LNXQCISML = 29;
        static final int LNXQCLSML = 30;
        static final int LNXQCMSML = 31;
        static final int LNXQCPSML = 32;
        static final int LNXQCRSML = 33;
        static final int LNXQCSSML = 34;
        static final int LNXQCTSML = 35;
        static final int LNXQCVSML = 36;
        static final int LNXQCALRG = 37;
        static final int LNXQCBLRG = 38;
        static final int LNXQCCLRG = 39;
        static final int LNXQCDLRG = 40;
        static final int LNXQCELRG = 41;
        static final int LNXQCFLRG = 42;
        static final int LNXQCILRG = 43;
        static final int LNXQCLLRG = 44;
        static final int LNXQCMLRG = 45;
        static final int LNXQCPLRG = 46;
        static final int LNXQCRLRG = 47;
        static final int LNXQCSLRG = 48;
        static final int LNXQCTLRG = 49;
    }
}
