// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import java.sql.NClob;

public class NCLOB extends CLOB implements NClob
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected NCLOB() {
    }
    
    public NCLOB(final OracleConnection oracleConnection) throws SQLException {
        this(oracleConnection, null);
    }
    
    public NCLOB(final OracleConnection oracleConnection, final byte[] array) throws SQLException {
        super(oracleConnection, array, (short)2);
    }
    
    public NCLOB(final CLOB clob) throws SQLException {
        this(clob.getPhysicalConnection(), clob.getBytes());
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
