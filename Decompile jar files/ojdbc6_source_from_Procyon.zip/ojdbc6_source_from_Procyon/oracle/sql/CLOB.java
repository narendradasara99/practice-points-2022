// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.CharArrayReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.OutputStream;
import java.io.Writer;
import java.io.InputStream;
import java.io.Reader;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import java.sql.Clob;

public class CLOB extends DatumWithConnection implements Clob
{
    public static final int MAX_CHUNK_SIZE = 32768;
    public static final int DURATION_SESSION = 10;
    public static final int DURATION_CALL = 12;
    static final int OLD_WRONG_DURATION_SESSION = 1;
    static final int OLD_WRONG_DURATION_CALL = 2;
    public static final int MODE_READONLY = 0;
    public static final int MODE_READWRITE = 1;
    ClobDBAccess dbaccess;
    private int dbChunkSize;
    private short csform;
    boolean isFree;
    boolean fromObject;
    long cachedLengthOfClobInChars;
    char[] prefetchData;
    int prefetchDataSize;
    boolean activePrefetch;
    static final int KDLCTLSIZE = 16;
    static final int KDF_FLAG = 88;
    static final int KDLIDDAT = 8;
    transient CharacterSet dilCharacterSet;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected CLOB() {
        this.dbChunkSize = -1;
        this.isFree = false;
        this.fromObject = false;
        this.cachedLengthOfClobInChars = -1L;
        this.prefetchData = null;
        this.prefetchDataSize = 0;
        this.activePrefetch = false;
        this.dilCharacterSet = null;
    }
    
    public CLOB(final OracleConnection oracleConnection) throws SQLException {
        this(oracleConnection, null);
    }
    
    public CLOB(final OracleConnection oracleConnection, final byte[] array, final boolean fromObject) throws SQLException {
        this(oracleConnection, array);
        this.fromObject = fromObject;
    }
    
    public CLOB(final OracleConnection physicalConnectionOf, final byte[] array) throws SQLException {
        super(array);
        this.dbChunkSize = -1;
        this.isFree = false;
        this.fromObject = false;
        this.cachedLengthOfClobInChars = -1L;
        this.prefetchData = null;
        this.prefetchDataSize = 0;
        this.activePrefetch = false;
        this.dilCharacterSet = null;
        if (array != null) {
            if ((array[5] & 0x40) != 0x0 && (array[5] & 0xFFFFFF80) == 0x0) {
                this.csform = 2;
            }
            else {
                this.csform = 1;
            }
        }
        DatumWithConnection.assertNotNull(physicalConnectionOf);
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.dbaccess = ((oracle.jdbc.internal.OracleConnection)physicalConnectionOf).createClobDBAccess();
    }
    
    public CLOB(final OracleConnection oracleConnection, final byte[] array, final short csform) throws SQLException {
        this(oracleConnection, array);
        this.csform = csform;
    }
    
    public boolean isNCLOB() {
        return this.csform == 2;
    }
    
    @Override
    public long length() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        long n;
        if (this.activePrefetch && this.cachedLengthOfClobInChars != -1L) {
            n = this.cachedLengthOfClobInChars;
        }
        else if (this.canReadBasicLobDataInLocator()) {
            n = this.dilGetChars().length;
        }
        else {
            n = this.getDBAccess().length(this);
        }
        return n;
    }
    
    @Override
    public String getSubString(final long n, final int count) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (count < 0 || n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetSubString(n, count);
        }
        String s;
        if (count == 0 || (this.activePrefetch && (this.cachedLengthOfClobInChars == 0L || (this.cachedLengthOfClobInChars > 0L && n - 1L >= this.cachedLengthOfClobInChars)))) {
            s = new String();
        }
        else if (this.prefetchData != null && this.prefetchDataSize > 0 && this.cachedLengthOfClobInChars == this.prefetchDataSize && n + count - 1L <= this.cachedLengthOfClobInChars) {
            s = new String(this.prefetchData, (int)n - 1, count);
        }
        else {
            final char[] charBufferSync = this.getDBAccess().getCharBufferSync(count);
            final int chars = this.getChars(n, count, charBufferSync);
            if (chars > 0) {
                s = new String(charBufferSync, 0, chars);
            }
            else {
                s = new String();
            }
            this.getDBAccess().cacheBufferSync(charBufferSync);
        }
        return s;
    }
    
    @Override
    public Reader getCharacterStream() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetCharacterStream(1L);
        }
        return this.getDBAccess().newReader(this, this.getBufferSize(), 0L);
    }
    
    @Override
    public InputStream getAsciiStream() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetAsciiStream(1L);
        }
        return this.getDBAccess().newInputStream(this, this.getBufferSize(), 0L);
    }
    
    @Override
    public long position(final String s, final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().position(this, s, n);
    }
    
    @Override
    public long position(final Clob clob, final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().position(this, (CLOB)clob, n);
    }
    
    public int getChars(final long n, final int n2, final char[] array) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().getChars(this, n, n2, array);
    }
    
    @Deprecated
    public Writer getCharacterOutputStream() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.setCharacterStream(1L);
    }
    
    @Deprecated
    public OutputStream getAsciiOutputStream() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.setAsciiStream(1L);
    }
    
    public byte[] getLocator() {
        return this.getBytes();
    }
    
    public void setLocator(final byte[] bytes) {
        this.setBytes(bytes);
    }
    
    public int putChars(final long n, final char[] array) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().putChars(this, n, array, 0, (array != null) ? array.length : 0);
    }
    
    public int putChars(final long n, final char[] array, final int n2) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().putChars(this, n, array, 0, n2);
    }
    
    public int putChars(final long n, final char[] array, final int n2, final int n3) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().putChars(this, n, array, n2, n3);
    }
    
    @Deprecated
    public int putString(final long n, final String s) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.setString(n, s);
    }
    
    public int getChunkSize() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.dbChunkSize <= 0) {
            this.dbChunkSize = this.getDBAccess().getChunkSize(this);
        }
        return this.dbChunkSize;
    }
    
    public int getBufferSize() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int chunkSize = this.getChunkSize();
        int n;
        if (chunkSize >= 32768 || chunkSize <= 0) {
            n = 32768;
        }
        else {
            n = 32768 / chunkSize * chunkSize;
        }
        return n;
    }
    
    @Deprecated
    public static CLOB empty_lob() throws SQLException {
        return getEmptyCLOB();
    }
    
    public static CLOB getEmptyCLOB() throws SQLException {
        final byte[] shareBytes = new byte[86];
        shareBytes[1] = 84;
        shareBytes[5] = 24;
        final CLOB clob = new CLOB();
        clob.setShareBytes(shareBytes);
        return clob;
    }
    
    public boolean isEmptyLob() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (this.shareBytes()[5] & 0x10) != 0x0;
    }
    
    public boolean isSecureFile() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (this.shareBytes()[7] & 0xFFFFFF80) != 0x0;
    }
    
    @Deprecated
    public OutputStream getAsciiOutputStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().newOutputStream(this, this.getBufferSize(), n, false);
    }
    
    @Deprecated
    public Writer getCharacterOutputStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().newWriter(this, this.getBufferSize(), n, false);
    }
    
    public InputStream getAsciiStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetAsciiStream(n);
        }
        return this.getDBAccess().newInputStream(this, this.getBufferSize(), n);
    }
    
    public Reader getCharacterStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetCharacterStream(n);
        }
        return this.getDBAccess().newReader(this, this.getBufferSize(), n);
    }
    
    @Deprecated
    public void trim(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.truncate(n);
    }
    
    public static CLOB createTemporary(final Connection connection, final boolean b, final int n) throws SQLException {
        return createTemporary(connection, b, n, (short)1);
    }
    
    public static CLOB createTemporary(final Connection connection, final boolean b, final int n, final short csform) throws SQLException {
        int n2 = n;
        if (n == 1) {
            n2 = 10;
        }
        if (n == 2) {
            n2 = 12;
        }
        if (connection == null || (n2 != 10 && n2 != 12)) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 68, "'conn' should not be null and 'duration' should either be equal to DURATION_SESSION or DURATION_CALL");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final oracle.jdbc.internal.OracleConnection physicalConnectionWithin = ((OracleConnection)connection).physicalConnectionWithin();
        final CLOB temporaryClob = getDBAccess(physicalConnectionWithin).createTemporaryClob(physicalConnectionWithin, b, n2, csform);
        temporaryClob.csform = csform;
        return temporaryClob;
    }
    
    public static void freeTemporary(final CLOB clob) throws SQLException {
        if (clob == null) {
            return;
        }
        clob.freeTemporary();
    }
    
    public static boolean isTemporary(final CLOB clob) throws SQLException {
        return clob != null && clob.isTemporary();
    }
    
    public void freeTemporary() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().freeTemporary(this, this.fromObject);
    }
    
    public boolean isTemporary() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().isTemporary(this);
    }
    
    public void open(final int n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().open(this, n);
    }
    
    public void close() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().close(this);
    }
    
    public boolean isOpen() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().isOpen(this);
    }
    
    @Override
    public int setString(final long n, final String s) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "'pos' should not be < 1");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        int putChars = 0;
        if (s != null && s.length() != 0) {
            putChars = this.putChars(n, s.toCharArray());
        }
        return putChars;
    }
    
    @Override
    public int setString(final long n, final String s, final int n2, final int n3) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "'pos' should not be < 1");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (n2 < 0) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "'offset' should not be < 0");
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        if (n2 + n3 > s.length()) {
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, " 'offset + len' should not be exceed string length. ");
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        int putChars = 0;
        if (s != null && s.length() != 0) {
            putChars = this.putChars(n, s.toCharArray(), n2, n3);
        }
        return putChars;
    }
    
    @Override
    public OutputStream setAsciiStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().newOutputStream(this, this.getBufferSize(), n, true);
    }
    
    @Override
    public Writer setCharacterStream(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getDBAccess().newWriter(this, this.getBufferSize(), n, true);
    }
    
    @Override
    public void truncate(final long n) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n < 0L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, " 'len' should not be < 0");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.getDBAccess().trim(this, n);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.io.InputStream") == 0 || name.compareTo("java.io.Reader") == 0;
    }
    
    @Override
    public Reader characterStreamValue() throws SQLException {
        return this.getCharacterStream();
    }
    
    @Override
    public InputStream asciiStreamValue() throws SQLException {
        return this.getAsciiStream();
    }
    
    @Override
    public InputStream binaryStreamValue() throws SQLException {
        return this.getAsciiStream();
    }
    
    @Override
    public String stringValue() throws SQLException {
        final Reader characterStream = this.getCharacterStream();
        final int bufferSize = this.getBufferSize();
        final StringWriter stringWriter = new StringWriter(bufferSize);
        final char[] array = new char[bufferSize];
        try {
            int read;
            while ((read = characterStream.read(array)) != -1) {
                stringWriter.write(array, 0, read);
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (IndexOutOfBoundsException ex2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 151);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return stringWriter.getBuffer().substring(0);
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new CLOB[n];
    }
    
    public ClobDBAccess getDBAccess() throws SQLException {
        if (this.dbaccess == null) {
            if (this.isEmptyLob()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 98);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.dbaccess = this.getInternalConnection().createClobDBAccess();
        }
        if (this.getPhysicalConnection().isClosed()) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return this.dbaccess;
    }
    
    public static ClobDBAccess getDBAccess(final Connection connection) throws SQLException {
        return ((OracleConnection)connection).physicalConnectionWithin().createClobDBAccess();
    }
    
    @Override
    public Connection getJavaSqlConnection() throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return super.getJavaSqlConnection();
    }
    
    public final void setLength(final long cachedLengthOfClobInChars) {
        this.cachedLengthOfClobInChars = cachedLengthOfClobInChars;
    }
    
    public final void setChunkSize(final int dbChunkSize) {
        this.dbChunkSize = dbChunkSize;
    }
    
    public final void setPrefetchedData(final char[] array) {
        if (array == null) {
            this.setPrefetchedData(null, 0);
        }
        else {
            this.setPrefetchedData(array, array.length);
        }
    }
    
    public final void setPrefetchedData(final char[] prefetchData, final int prefetchDataSize) {
        this.prefetchData = prefetchData;
        this.prefetchDataSize = prefetchDataSize;
    }
    
    public final char[] getPrefetchedData() {
        return this.prefetchData;
    }
    
    public final int getPrefetchedDataSize() {
        return this.prefetchDataSize;
    }
    
    public final void setActivePrefetch(final boolean activePrefetch) {
        if (this.activePrefetch && !activePrefetch) {
            this.clearCachedData();
        }
        this.activePrefetch = activePrefetch;
    }
    
    public final void clearCachedData() {
        this.cachedLengthOfClobInChars = -1L;
        this.prefetchData = null;
    }
    
    public final boolean isActivePrefetch() {
        return this.activePrefetch;
    }
    
    boolean canReadBasicLobDataInLocator() throws SQLException {
        final byte[] shareBytes = this.shareBytes();
        if (shareBytes == null || shareBytes.length < 102) {
            return false;
        }
        if (!this.getPhysicalConnection().isDataInLocatorEnabled()) {
            return false;
        }
        final int n = shareBytes[6] & 0xFF;
        final int n2 = shareBytes[7] & 0xFF;
        final boolean b = (n & 0x8) == 0x8;
        final boolean b2 = (n2 & 0xFFFFFF80) == 0xFFFFFF80;
        boolean b3 = false;
        if (b && !b2) {
            b3 = ((shareBytes[88] & 0xFF & 0x8) == 0x8);
        }
        final boolean b4 = b && !b2 && b3;
        boolean b5 = false;
        if (b4) {
            this.dilGetCharacterSet();
            b5 = !this.dilCharacterSet.isUnknown();
        }
        return b5;
    }
    
    int dilGetCharSetId() throws SQLException {
        return (this.shareBytes()[32] & 0xFF) << 8 | (this.shareBytes()[33] & 0xFF);
    }
    
    boolean isMigratedAL16UTF16LE() {
        return (this.shareBytes()[7] & 0xFF & 0x40) == 0x40;
    }
    
    boolean isVariableWidth() {
        final int n = this.shareBytes()[6] & 0xFF;
        final int n2 = 128;
        return (n & n2) == n2;
    }
    
    void dilGetCharacterSet() throws SQLException {
        if (this.dilCharacterSet == null) {
            if (this.isMigratedAL16UTF16LE()) {
                this.dilCharacterSet = CharacterSet.make(2002);
            }
            else if (this.isVariableWidth()) {
                this.dilCharacterSet = CharacterSet.make(2000);
            }
            else {
                this.dilCharacterSet = CharacterSet.make(this.dilGetCharSetId());
            }
        }
    }
    
    int dilLength() {
        return this.shareBytes().length - 86 - 16;
    }
    
    char[] dilGetChars() throws SQLException {
        final int dilLength = this.dilLength();
        final byte[] array = new byte[dilLength];
        System.arraycopy(this.shareBytes(), 102, array, 0, dilLength);
        return this.dilCharacterSet.toStringWithReplacement(array, 0, dilLength).toCharArray();
    }
    
    InputStream dilGetAsciiStream(final long n) throws SQLException {
        final char[] dilGetChars = this.dilGetChars();
        if (n - 1L > dilGetChars.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        byte[] convertWithReplacement;
        if (this.dilGetCharSetId() == 1) {
            convertWithReplacement = new byte[dilGetChars.length];
            for (int i = 0; i < dilGetChars.length; ++i) {
                convertWithReplacement[i] = (byte)dilGetChars[i];
            }
        }
        else {
            convertWithReplacement = CharacterSet.make(1).convertWithReplacement(new String(dilGetChars));
        }
        return new ByteArrayInputStream(convertWithReplacement);
    }
    
    Reader dilGetCharacterStream(final long n) throws SQLException {
        final char[] dilGetChars = this.dilGetChars();
        if (n - 1L > dilGetChars.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new CharArrayReader(dilGetChars, (int)(n - 1L), Integer.MAX_VALUE);
    }
    
    String dilGetSubString(final long n, final int n2) throws SQLException {
        final char[] dilGetChars = this.dilGetChars();
        if ((int)n > dilGetChars.length) {
            return "";
        }
        final int count = (int)Math.min(n2, dilGetChars.length - (n - 1L));
        if (count == 0) {
            return "";
        }
        return new String(dilGetChars, (int)(n - 1L), count);
    }
    
    @Override
    public void free() throws SQLException {
        if (this.isFree) {
            return;
        }
        if (this.isOpen()) {
            this.close();
        }
        if (this.isTemporary()) {
            this.freeTemporary();
        }
        this.isFree = true;
        this.dbaccess = null;
    }
    
    @Override
    public Reader getCharacterStream(final long n, final long n2) throws SQLException {
        if (this.isFree) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 192);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.canReadBasicLobDataInLocator()) {
            return this.dilGetCharacterStream(n, n2);
        }
        final long length = this.length();
        if (n < 1L || n2 < 0L || n > length || n - 1L + n2 > length) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return this.getDBAccess().newReader(this, this.getChunkSize(), n, n2);
    }
    
    Reader dilGetCharacterStream(final long n, final long n2) throws SQLException {
        if (n < 1L || n2 < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final char[] dilGetChars = this.dilGetChars();
        final long n3 = dilGetChars.length;
        if (n < 1L || n2 < 0L || n > n3 || n - 1L + n2 > n3) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return new CharArrayReader(dilGetChars, (int)(n - 1L), (int)n2);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
