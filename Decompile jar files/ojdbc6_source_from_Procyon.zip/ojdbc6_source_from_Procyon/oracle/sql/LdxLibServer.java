// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

class LdxLibServer implements LdxLib
{
    @Override
    public native byte[] ldxadm(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] ldxads(final byte[] p0, final int p1, final int p2) throws SQLException;
    
    @Override
    public native int ldxchk(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] ldxdfd(final int p0, final int p1) throws SQLException;
    
    @Override
    public native void ldxdtd(final byte[] p0, final int[] p1, final int[] p2) throws SQLException;
    
    @Override
    public native String ldxdts(final byte[] p0, final String p1, final String p2) throws SQLException;
    
    @Override
    public native String ldxdts(final byte[] p0, final byte[] p1, final String p2) throws SQLException;
    
    @Override
    public native byte[] ldxsto(final String p0, final String p1) throws SQLException;
    
    @Override
    public native byte[] ldxdyf(final byte[] p0) throws SQLException;
    
    @Override
    public native void ldxftd(final byte[] p0, final int[] p1, final int[] p2) throws SQLException;
    
    @Override
    public native byte[] ldxgdt() throws SQLException;
    
    @Override
    public native byte[] ldxldd(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] ldxnxd(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] ldxrnd(final byte[] p0, final String p1) throws SQLException;
    
    @Override
    public native byte[] ldxsbm(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native void ldxsub(final byte[] p0, final byte[] p1, final int[] p2, final int[] p3) throws SQLException;
    
    @Override
    public native byte[] ldxstd(final String p0, final String p1, final String p2) throws SQLException;
    
    @Override
    public native byte[] ldxtrn(final byte[] p0, final String p1) throws SQLException;
    
    static {
        LoadCorejava.init();
    }
}
