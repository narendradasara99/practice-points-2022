// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.Map;
import oracle.sql.converter.CharacterConverterFactoryOGS;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;

public abstract class CharacterSet
{
    public static final short DEFAULT_CHARSET = -1;
    public static final short ASCII_CHARSET = 1;
    public static final short ISO_LATIN_1_CHARSET = 31;
    public static final short UNICODE_1_CHARSET = 870;
    public static final short US7ASCII_CHARSET = 1;
    public static final short WE8DEC_CHARSET = 2;
    public static final short WE8HP_CHARSET = 3;
    public static final short US8PC437_CHARSET = 4;
    public static final short WE8EBCDIC37_CHARSET = 5;
    public static final short WE8EBCDIC500_CHARSET = 6;
    public static final short WE8EBCDIC285_CHARSET = 8;
    public static final short WE8PC850_CHARSET = 10;
    public static final short D7DEC_CHARSET = 11;
    public static final short F7DEC_CHARSET = 12;
    public static final short S7DEC_CHARSET = 13;
    public static final short E7DEC_CHARSET = 14;
    public static final short SF7ASCII_CHARSET = 15;
    public static final short NDK7DEC_CHARSET = 16;
    public static final short I7DEC_CHARSET = 17;
    public static final short NL7DEC_CHARSET = 18;
    public static final short CH7DEC_CHARSET = 19;
    public static final short YUG7ASCII_CHARSET = 20;
    public static final short SF7DEC_CHARSET = 21;
    public static final short TR7DEC_CHARSET = 22;
    public static final short IW7IS960_CHARSET = 23;
    public static final short IN8ISCII_CHARSET = 25;
    public static final short WE8ISO8859P1_CHARSET = 31;
    public static final short EE8ISO8859P2_CHARSET = 32;
    public static final short SE8ISO8859P3_CHARSET = 33;
    public static final short NEE8ISO8859P4_CHARSET = 34;
    public static final short CL8ISO8859P5_CHARSET = 35;
    public static final short AR8ISO8859P6_CHARSET = 36;
    public static final short EL8ISO8859P7_CHARSET = 37;
    public static final short IW8ISO8859P8_CHARSET = 38;
    public static final short WE8ISO8859P9_CHARSET = 39;
    public static final short NE8ISO8859P10_CHARSET = 40;
    public static final short TH8TISASCII_CHARSET = 41;
    public static final short TH8TISEBCDIC_CHARSET = 42;
    public static final short BN8BSCII_CHARSET = 43;
    public static final short VN8VN3_CHARSET = 44;
    public static final short VN8MSWIN1258_CHARSET = 45;
    public static final short WE8NEXTSTEP_CHARSET = 50;
    public static final short AR8ASMO708PLUS_CHARSET = 61;
    public static final short AR8EBCDICX_CHARSET = 70;
    public static final short AR8XBASIC_CHARSET = 72;
    public static final short EL8DEC_CHARSET = 81;
    public static final short TR8DEC_CHARSET = 82;
    public static final short WE8EBCDIC37C_CHARSET = 90;
    public static final short WE8EBCDIC500C_CHARSET = 91;
    public static final short IW8EBCDIC424_CHARSET = 92;
    public static final short TR8EBCDIC1026_CHARSET = 93;
    public static final short WE8EBCDIC871_CHARSET = 94;
    public static final short WE8EBCDIC284_CHARSET = 95;
    public static final short WE8EBCDIC1047_CHARSET = 96;
    public static final short EEC8EUROASCI_CHARSET = 110;
    public static final short EEC8EUROPA3_CHARSET = 113;
    public static final short LA8PASSPORT_CHARSET = 114;
    public static final short BG8PC437S_CHARSET = 140;
    public static final short EE8PC852_CHARSET = 150;
    public static final short RU8PC866_CHARSET = 152;
    public static final short RU8BESTA_CHARSET = 153;
    public static final short IW8PC1507_CHARSET = 154;
    public static final short RU8PC855_CHARSET = 155;
    public static final short TR8PC857_CHARSET = 156;
    public static final short CL8MACCYRILLIC_CHARSET = 158;
    public static final short CL8MACCYRILLICS_CHARSET = 159;
    public static final short WE8PC860_CHARSET = 160;
    public static final short IS8PC861_CHARSET = 161;
    public static final short EE8MACCES_CHARSET = 162;
    public static final short EE8MACCROATIANS_CHARSET = 163;
    public static final short TR8MACTURKISHS_CHARSET = 164;
    public static final short IS8MACICELANDICS_CHARSET = 165;
    public static final short EL8MACGREEKS_CHARSET = 166;
    public static final short IW8MACHEBREWS_CHARSET = 167;
    public static final short EE8MSWIN1250_CHARSET = 170;
    public static final short CL8MSWIN1251_CHARSET = 171;
    public static final short ET8MSWIN923_CHARSET = 172;
    public static final short BG8MSWIN_CHARSET = 173;
    public static final short EL8MSWIN1253_CHARSET = 174;
    public static final short IW8MSWIN1255_CHARSET = 175;
    public static final short LT8MSWIN921_CHARSET = 176;
    public static final short TR8MSWIN1254_CHARSET = 177;
    public static final short WE8MSWIN1252_CHARSET = 178;
    public static final short BLT8MSWIN1257_CHARSET = 179;
    public static final short D8EBCDIC273_CHARSET = 180;
    public static final short I8EBCDIC280_CHARSET = 181;
    public static final short DK8EBCDIC277_CHARSET = 182;
    public static final short S8EBCDIC278_CHARSET = 183;
    public static final short EE8EBCDIC870_CHARSET = 184;
    public static final short CL8EBCDIC1025_CHARSET = 185;
    public static final short F8EBCDIC297_CHARSET = 186;
    public static final short IW8EBCDIC1086_CHARSET = 187;
    public static final short CL8EBCDIC1025X_CHARSET = 188;
    public static final short N8PC865_CHARSET = 190;
    public static final short BLT8CP921_CHARSET = 191;
    public static final short LV8PC1117_CHARSET = 192;
    public static final short LV8PC8LR_CHARSET = 193;
    public static final short BLT8EBCDIC1112_CHARSET = 194;
    public static final short LV8RST104090_CHARSET = 195;
    public static final short CL8KOI8R_CHARSET = 196;
    public static final short BLT8PC775_CHARSET = 197;
    public static final short F7SIEMENS9780X_CHARSET = 201;
    public static final short E7SIEMENS9780X_CHARSET = 202;
    public static final short S7SIEMENS9780X_CHARSET = 203;
    public static final short DK7SIEMENS9780X_CHARSET = 204;
    public static final short N7SIEMENS9780X_CHARSET = 205;
    public static final short I7SIEMENS9780X_CHARSET = 206;
    public static final short D7SIEMENS9780X_CHARSET = 207;
    public static final short WE8GCOS7_CHARSET = 210;
    public static final short EL8GCOS7_CHARSET = 211;
    public static final short US8BS2000_CHARSET = 221;
    public static final short D8BS2000_CHARSET = 222;
    public static final short F8BS2000_CHARSET = 223;
    public static final short E8BS2000_CHARSET = 224;
    public static final short DK8BS2000_CHARSET = 225;
    public static final short S8BS2000_CHARSET = 226;
    public static final short WE8BS2000_CHARSET = 231;
    public static final short CL8BS2000_CHARSET = 235;
    public static final short WE8BS2000L5_CHARSET = 239;
    public static final short WE8DG_CHARSET = 241;
    public static final short WE8NCR4970_CHARSET = 251;
    public static final short WE8ROMAN8_CHARSET = 261;
    public static final short EE8MACCE_CHARSET = 262;
    public static final short EE8MACCROATIAN_CHARSET = 263;
    public static final short TR8MACTURKISH_CHARSET = 264;
    public static final short IS8MACICELANDIC_CHARSET = 265;
    public static final short EL8MACGREEK_CHARSET = 266;
    public static final short IW8MACHEBREW_CHARSET = 267;
    public static final short US8ICL_CHARSET = 277;
    public static final short WE8ICL_CHARSET = 278;
    public static final short WE8ISOICLUK_CHARSET = 279;
    public static final short WE8MACROMAN8_CHARSET = 351;
    public static final short WE8MACROMAN8S_CHARSET = 352;
    public static final short TH8MACTHAI_CHARSET = 353;
    public static final short TH8MACTHAIS_CHARSET = 354;
    public static final short HU8CWI2_CHARSET = 368;
    public static final short EL8PC437S_CHARSET = 380;
    public static final short EL8EBCDIC875_CHARSET = 381;
    public static final short EL8PC737_CHARSET = 382;
    public static final short LT8PC772_CHARSET = 383;
    public static final short LT8PC774_CHARSET = 384;
    public static final short EL8PC869_CHARSET = 385;
    public static final short EL8PC851_CHARSET = 386;
    public static final short CDN8PC863_CHARSET = 390;
    public static final short HU8ABMOD_CHARSET = 401;
    public static final short AR8ASMO8X_CHARSET = 500;
    public static final short AR8NAFITHA711T_CHARSET = 504;
    public static final short AR8SAKHR707T_CHARSET = 505;
    public static final short AR8MUSSAD768T_CHARSET = 506;
    public static final short AR8ADOS710T_CHARSET = 507;
    public static final short AR8ADOS720T_CHARSET = 508;
    public static final short AR8APTEC715T_CHARSET = 509;
    public static final short AR8NAFITHA721T_CHARSET = 511;
    public static final short AR8HPARABIC8T_CHARSET = 514;
    public static final short AR8NAFITHA711_CHARSET = 554;
    public static final short AR8SAKHR707_CHARSET = 555;
    public static final short AR8MUSSAD768_CHARSET = 556;
    public static final short AR8ADOS710_CHARSET = 557;
    public static final short AR8ADOS720_CHARSET = 558;
    public static final short AR8APTEC715_CHARSET = 559;
    public static final short AR8MSAWIN_CHARSET = 560;
    public static final short AR8NAFITHA721_CHARSET = 561;
    public static final short AR8SAKHR706_CHARSET = 563;
    public static final short AR8ARABICMAC_CHARSET = 565;
    public static final short AR8ARABICMACS_CHARSET = 566;
    public static final short AR8ARABICMACT_CHARSET = 567;
    public static final short LA8ISO6937_CHARSET = 590;
    public static final short US8NOOP_CHARSET = 797;
    public static final short WE8DECTST_CHARSET = 798;
    public static final short JA16VMS_CHARSET = 829;
    public static final short JA16EUC_CHARSET = 830;
    public static final short JA16EUCYEN_CHARSET = 831;
    public static final short JA16SJIS_CHARSET = 832;
    public static final short JA16DBCS_CHARSET = 833;
    public static final short JA16SJISYEN_CHARSET = 834;
    public static final short JA16EBCDIC930_CHARSET = 835;
    public static final short JA16MACSJIS_CHARSET = 836;
    public static final short JA16EUCTILDE_CHARSET = 837;
    public static final short JA16SJISTILDE_CHARSET = 838;
    public static final short KO16KSC5601_CHARSET = 840;
    public static final short KO16DBCS_CHARSET = 842;
    public static final short KO16KSCCS_CHARSET = 845;
    public static final short KO16MSWIN949_CHARSET = 846;
    public static final short ZHS16CGB231280_CHARSET = 850;
    public static final short ZHS16MACCGB231280_CHARSET = 851;
    public static final short ZHS16GBK_CHARSET = 852;
    public static final short ZHS16DBCS_CHARSET = 853;
    public static final short ZHS32GB18030_CHARSET = 854;
    public static final short ZHT32EUC_CHARSET = 860;
    public static final short ZHT32SOPS_CHARSET = 861;
    public static final short ZHT16DBT_CHARSET = 862;
    public static final short ZHT32TRIS_CHARSET = 863;
    public static final short ZHT16DBCS_CHARSET = 864;
    public static final short ZHT16BIG5_CHARSET = 865;
    public static final short ZHT16CCDC_CHARSET = 866;
    public static final short ZHT16MSWIN950_CHARSET = 867;
    public static final short AL24UTFFSS_CHARSET = 870;
    public static final short UTF8_CHARSET = 871;
    public static final short UTFE_CHARSET = 872;
    public static final short AL32UTF8_CHARSET = 873;
    public static final short KO16TSTSET_CHARSET = 996;
    public static final short JA16TSTSET2_CHARSET = 997;
    public static final short JA16TSTSET_CHARSET = 998;
    public static final short US16TSTFIXED_CHARSET = 1001;
    public static final short AL16UTF16_CHARSET = 2000;
    public static final short AL16UTF16LE_CHARSET = 2002;
    public static final short TH8TISEBCDICS_CHARSET = 319;
    public static final short BLT8EBCDIC1112S_CHARSET = 314;
    public static final short CE8BS2000_CHARSET = 233;
    public static final short CL8EBCDIC1025R_CHARSET = 323;
    public static final short CL8EBCDIC1158R_CHARSET = 326;
    public static final short D8EBCDIC1141_CHARSET = 189;
    public static final short DK8EBCDIC1142_CHARSET = 198;
    public static final short EE8BS2000_CHARSET = 232;
    public static final short EE8EBCDIC870S_CHARSET = 316;
    public static final short EL8EBCDIC423R_CHARSET = 327;
    public static final short EL8EBCDIC875S_CHARSET = 311;
    public static final short EL8EBCDIC875R_CHARSET = 324;
    public static final short F8EBCDIC1147_CHARSET = 208;
    public static final short I8EBCDIC1144_CHARSET = 200;
    public static final short WE8BS2000E_CHARSET = 230;
    public static final short WE8EBCDIC1047E_CHARSET = 100;
    public static final short WE8EBCDIC1140_CHARSET = 7;
    public static final short WE8EBCDIC1145_CHARSET = 98;
    public static final short WE8EBCDIC1146_CHARSET = 9;
    public static final short WE8EBCDIC1148_CHARSET = 27;
    public static final short AR8EBCDIC420S_CHARSET = 320;
    public static final short IW8EBCDIC424S_CHARSET = 315;
    public static final short TR8EBCDIC1026S_CHARSET = 312;
    public static final short ZHT16HKSCS_CHARSET = 868;
    public static final short BLT8ISO8859P13_CHARSET = 47;
    public static final short WE8ISO8859P15_CHARSET = 46;
    public static final short AR8MSWIN1256_CHARSET = 560;
    public static final short S8EBCDIC1143_CHARSET = 199;
    public static final short ZHT16HKSCS31_CHARSET = 992;
    public static final short AZ8ISO8859P9E_CHARSET = 52;
    public static final short CEL8ISO8859P14_CHARSET = 48;
    public static final short CL8ISOIR111_CHARSET = 49;
    public static final short CL8KOI8U_CHARSET = 51;
    public static final short WE8PC858_CHARSET = 28;
    public static final short CL8EBCDIC1025C_CHARSET = 322;
    public static final short CL8EBCDIC1025S_CHARSET = 317;
    public static final short CL8EBCDIC1158_CHARSET = 325;
    public static final short EE8EBCDIC870C_CHARSET = 301;
    public static final short WE8EBCDIC924_CHARSET = 101;
    public static final short WE8EBCDIC1140C_CHARSET = 97;
    public static final short WE8EBCDIC1148C_CHARSET = 99;
    public static final short UNICODE_2_CHARSET = 871;
    private static CharacterSet asciiCharSet;
    static CharacterSetFactory factory;
    private int oracleId;
    int rep;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSet(final int oracleId) {
        this.oracleId = oracleId;
    }
    
    public static CharacterSet make(final int n) {
        return CharacterSet.factory.make(n);
    }
    
    @Override
    public String toString() {
        if (ReadWriteCharacterSetNamesMap.cache == null) {
            this.buildCharacterSetNames();
        }
        return ReadWriteCharacterSetNamesMap.cache.get(new Short((short)this.oracleId));
    }
    
    synchronized void buildCharacterSetNames() {
        if (ReadWriteCharacterSetNamesMap.cache == null) {
            final Field[] fields = CharacterSet.class.getFields();
            final HashMap<Object, String> cache = new HashMap<Object, String>();
            for (int i = 0; i < fields.length; ++i) {
                try {
                    final String name = fields[i].getName();
                    final int lastIndex = name.lastIndexOf("_CHARSET");
                    if (lastIndex != -1) {
                        final String substring = name.substring(0, lastIndex);
                        if (!substring.equals("ASCII") && !substring.equals("ISO_LATIN_1") && !substring.equals("AR8MSAWIN") && !substring.equals("UNICODE_1") && !substring.equals("UNICODE_2")) {
                            final short short1 = fields[i].getShort(CharacterSet.class);
                            final int modifiers = fields[i].getModifiers();
                            if (Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers)) {
                                if (cache.get(new Short(short1)) != null) {
                                    throw new RuntimeException("duplicate field name: " + substring + " for id: " + short1);
                                }
                                cache.put(new Short(short1), substring);
                            }
                        }
                    }
                }
                catch (Exception cause) {
                    throw new RuntimeException("Failed for field: " + fields[i], cause);
                }
            }
            ReadWriteCharacterSetNamesMap.cache = (Map<Short, String>)cache;
        }
    }
    
    public abstract boolean isLossyFrom(final CharacterSet p0);
    
    public abstract boolean isConvertibleFrom(final CharacterSet p0);
    
    public boolean isUnicode() {
        return false;
    }
    
    boolean isWellFormed(final byte[] array, final int n, final int n2) {
        return true;
    }
    
    public int getOracleId() {
        return this.oracleId;
    }
    
    int getRep() {
        return this.rep;
    }
    
    public int getRatioTo(final CharacterSet set) {
        throw new Error("oracle.sql.CharacterSet.getRationTo Not Implemented");
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof CharacterSet && this.oracleId == ((CharacterSet)o).oracleId;
    }
    
    @Override
    public int hashCode() {
        return this.oracleId;
    }
    
    public abstract String toStringWithReplacement(final byte[] p0, final int p1, final int p2);
    
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        final byte[] convert = this.convert(this.toStringWithReplacement(array, n, n2));
        if (n2 != convert.length) {
            failCharacterConversion(this);
        }
        for (int i = 0; i < n2; ++i) {
            if (convert[i] != array[n + i]) {
                failCharacterConversion(this);
            }
        }
        return null;
    }
    
    public abstract byte[] convert(final String p0) throws SQLException;
    
    public abstract byte[] convertWithReplacement(final String p0);
    
    public abstract byte[] convert(final CharacterSet p0, final byte[] p1, final int p2, final int p3) throws SQLException;
    
    public byte[] convertUnshared(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        byte[] convert = this.convert(set, array, n, n2);
        if (convert == array) {
            convert = new byte[array.length];
            System.arraycopy(array, 0, convert, 0, n2);
        }
        return convert;
    }
    
    abstract int decode(final CharacterWalker p0) throws SQLException;
    
    abstract void encode(final CharacterBuffer p0, final int p1) throws SQLException;
    
    static final void failCharacterConversion(final CharacterSet set) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(null, 55, set);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static final byte[] useOrCopy(final byte[] array, final int n, final int n2) {
        byte[] array2;
        if (array.length == n2 && n == 0) {
            array2 = array;
        }
        else {
            array2 = new byte[n2];
            System.arraycopy(array, n, array2, 0, n2);
        }
        return array2;
    }
    
    static final void need(final CharacterBuffer characterBuffer, final int n) {
        int length = characterBuffer.bytes.length;
        final int i = n + characterBuffer.next;
        if (i <= length) {
            return;
        }
        while (i > length) {
            length *= 2;
        }
        System.arraycopy(characterBuffer.bytes, 0, characterBuffer.bytes = new byte[length], 0, characterBuffer.next);
    }
    
    public static final String UTFToString(final byte[] array, final int n, final int n2, final boolean b) throws SQLException {
        return new String(UTFToJavaChar(array, n, n2, b));
    }
    
    public static final String UTFToString(final byte[] array, final int n, final int n2) throws SQLException {
        return UTFToString(array, n, n2, false);
    }
    
    public static final char[] UTFToJavaChar(final byte[] array, final int n, final int n2) throws SQLException {
        return UTFToJavaChar(array, n, n2, false);
    }
    
    public static final char[] UTFToJavaChar(final byte[] array, final int n, final int n2, final boolean b) throws SQLException {
        final char[] array2 = new char[n2];
        final int convertUTFBytesToJavaChars = convertUTFBytesToJavaChars(array, n, array2, 0, new int[] { n2 }, b);
        final char[] array3 = new char[convertUTFBytesToJavaChars];
        System.arraycopy(array2, 0, array3, 0, convertUTFBytesToJavaChars);
        return array3;
    }
    
    public static final char[] UTFToJavaCharWithReplacement(final byte[] array, final int n, final int n2) {
        try {
            final char[] array2 = new char[n2];
            final int convertUTFBytesToJavaChars = convertUTFBytesToJavaChars(array, n, array2, 0, new int[] { n2 }, true);
            final char[] array3 = new char[convertUTFBytesToJavaChars];
            System.arraycopy(array2, 0, array3, 0, convertUTFBytesToJavaChars);
            return array3;
        }
        catch (SQLException ex) {
            throw new IllegalStateException(ex.getMessage());
        }
    }
    
    public static final int convertUTFBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int[] array3, final boolean b) throws SQLException {
        return convertUTFBytesToJavaChars(array, n, array2, n2, array3, b, array2.length - n2);
    }
    
    public static final int convertUTFBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int[] array3, final boolean b, final int n3) throws SQLException {
        final CharacterConverterBehavior characterConverterBehavior = b ? CharacterConverterBehavior.REPLACEMENT : CharacterConverterBehavior.REPORT_ERROR;
        final int n4 = array3[0];
        array3[0] = 0;
        int i = n;
        final int n5 = n + n4;
        int n6 = n2;
        final int n7 = n2 + n3;
    Label_0592:
        while (i < n5) {
            final byte b2 = array[i++];
            final int n8 = b2 & 0xF0;
            switch (n8 / 16) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7: {
                    if (n6 < n7) {
                        array2[n6++] = (char)(b2 & -1);
                        continue;
                    }
                    array3[0] = n5 - i + 2;
                    break Label_0592;
                }
                case 12:
                case 13: {
                    if (i >= n5) {
                        array3[0] = 1;
                        characterConverterBehavior.onFailConversion();
                        break Label_0592;
                    }
                    final char conv2ByteUTFtoUTF16 = conv2ByteUTFtoUTF16(b2, array[i++]);
                    if (n6 < n7) {
                        characterConverterBehavior.onFailConversion(array2[n6++] = conv2ByteUTFtoUTF16);
                        continue;
                    }
                    array3[0] = n5 - i + 3;
                    break Label_0592;
                }
                case 14: {
                    if (i + 1 >= n5) {
                        array3[0] = n5 - i + 1;
                        characterConverterBehavior.onFailConversion();
                        break Label_0592;
                    }
                    final char conv3ByteUTFtoUTF16 = conv3ByteUTFtoUTF16(b2, array[i++], array[i++]);
                    if (n8 != 244 && array[i - 2] != -65 && array[i - 1] != -67) {
                        characterConverterBehavior.onFailConversion(conv3ByteUTFtoUTF16);
                    }
                    if (isHiSurrogate(conv3ByteUTFtoUTF16)) {
                        if (n6 > n7 - 2) {
                            array3[0] = n5 - i + 4;
                            break Label_0592;
                        }
                        if (i >= n5) {
                            continue;
                        }
                        final byte b3 = array[i];
                        if ((byte)(b3 & 0xF0) != -32) {
                            array2[n6++] = '\ufffd';
                            characterConverterBehavior.onFailConversion();
                            continue;
                        }
                        if (++i + 1 >= n5) {
                            array3[0] = n5 - i + 1;
                            characterConverterBehavior.onFailConversion();
                            break Label_0592;
                        }
                        final char conv3ByteUTFtoUTF17 = conv3ByteUTFtoUTF16(b3, array[i++], array[i++]);
                        if (isLoSurrogate(conv3ByteUTFtoUTF17)) {
                            array2[n6++] = conv3ByteUTFtoUTF16;
                        }
                        else {
                            array2[n6++] = '\ufffd';
                            characterConverterBehavior.onFailConversion();
                        }
                        array2[n6++] = conv3ByteUTFtoUTF17;
                        continue;
                    }
                    else {
                        if (n6 < n7) {
                            array2[n6++] = conv3ByteUTFtoUTF16;
                            continue;
                        }
                        array3[0] = n5 - i + 4;
                        break Label_0592;
                    }
                    break;
                }
                default: {
                    if (n6 < n7) {
                        array2[n6++] = '\ufffd';
                        characterConverterBehavior.onFailConversion();
                        continue;
                    }
                    array3[0] = n5 - i + 2;
                    break Label_0592;
                }
            }
        }
        return n6 - n2;
    }
    
    public static final byte[] stringToUTF(final String s) {
        final char[] charArray = s.toCharArray();
        final byte[] array = new byte[charArray.length * 3];
        final int convertJavaCharsToUTFBytes = convertJavaCharsToUTFBytes(charArray, 0, array, 0, charArray.length);
        final byte[] array2 = new byte[convertJavaCharsToUTFBytes];
        System.arraycopy(array, 0, array2, 0, convertJavaCharsToUTFBytes);
        return array2;
    }
    
    public static final int convertJavaCharsToUTFBytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) {
        final int n4 = n + n3;
        int n5 = n2;
        for (int i = n; i < n4; ++i) {
            final char c = array[i];
            if (c >= '\0' && c <= '\u007f') {
                array2[n5++] = (byte)c;
            }
            else if (c > '\u07ff') {
                array2[n5++] = (byte)(0xE0 | (c >>> 12 & 0xF));
                array2[n5++] = (byte)(0x80 | (c >>> 6 & 0x3F));
                array2[n5++] = (byte)(0x80 | (c >>> 0 & 0x3F));
            }
            else {
                array2[n5++] = (byte)(0xC0 | (c >>> 6 & 0x1F));
                array2[n5++] = (byte)(0x80 | (c >>> 0 & 0x3F));
            }
        }
        return n5 - n2;
    }
    
    public static final int UTFStringLength(final byte[] array, final int n, final int n2) {
        int n3 = 0;
        int i = n;
        final int n4 = n + n2;
        while (i < n4) {
            switch ((array[i] & 0xF0) >>> 4) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7: {
                    ++i;
                    ++n3;
                    continue;
                }
                case 12:
                case 13: {
                    if (i + 1 >= n4) {
                        i = n4;
                        continue;
                    }
                    ++n3;
                    i += 2;
                    continue;
                }
                case 14: {
                    if (i + 2 >= n4) {
                        i = n4;
                        continue;
                    }
                    ++n3;
                    i += 3;
                    continue;
                }
                case 15: {
                    if (i + 3 >= n4) {
                        i = n4;
                        continue;
                    }
                    n3 += 2;
                    i += 4;
                    continue;
                }
                default: {
                    ++i;
                    ++n3;
                    continue;
                }
            }
        }
        return n3;
    }
    
    public static final int stringUTFLength(final String s) {
        return charArrayUTF8Length(s.toCharArray());
    }
    
    static final int charArrayUTF8Length(final char[] array) {
        int n = 0;
        for (final char c : array) {
            if (c >= '\0' && c <= '\u007f') {
                ++n;
            }
            else if (c > '\u07ff') {
                n += 3;
            }
            else {
                n += 2;
            }
        }
        return n;
    }
    
    public static final String AL32UTF8ToString(final byte[] array, final int n, final int n2) {
        return AL32UTF8ToString(array, n, n2, false);
    }
    
    public static final String AL32UTF8ToString(final byte[] array, final int n, final int n2, final boolean b) {
        char[] al32UTF8ToJavaChar = null;
        try {
            al32UTF8ToJavaChar = AL32UTF8ToJavaChar(array, n, n2, b);
        }
        catch (SQLException ex) {}
        return new String(al32UTF8ToJavaChar);
    }
    
    public static final char[] AL32UTF8ToJavaChar(final byte[] array, final int n, final int n2, final boolean b) throws SQLException {
        try {
            final char[] array2 = new char[n2];
            final int convertAL32UTF8BytesToJavaChars = convertAL32UTF8BytesToJavaChars(array, n, array2, 0, new int[] { n2 }, b);
            final char[] array3 = new char[convertAL32UTF8BytesToJavaChars];
            System.arraycopy(array2, 0, array3, 0, convertAL32UTF8BytesToJavaChars);
            return array3;
        }
        catch (SQLException ex) {
            failUTFConversion();
            return new char[0];
        }
    }
    
    public static final int convertAL32UTF8BytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int[] array3, final boolean b) throws SQLException {
        return convertAL32UTF8BytesToJavaChars(array, n, array2, n2, array3, b, array2.length - n2);
    }
    
    public static final int convertAL32UTF8BytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int[] array3, final boolean b, final int n3) throws SQLException {
        final CharacterConverterBehavior characterConverterBehavior = b ? CharacterConverterBehavior.REPLACEMENT : CharacterConverterBehavior.REPORT_ERROR;
        final int n4 = array3[0];
        array3[0] = 0;
        int i = n;
        final int n5 = n + n4;
        int n6 = n2;
        final int n7 = n2 + n3;
    Label_0503:
        while (i < n5) {
            final byte b2 = array[i++];
            switch ((b2 & 0xF0) / 16) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7: {
                    if (n6 < n7) {
                        array2[n6++] = (char)(b2 & -1);
                        continue;
                    }
                    array3[0] = n5 - i + 2;
                    break Label_0503;
                }
                case 12:
                case 13: {
                    if (i >= n5) {
                        array3[0] = 1;
                        characterConverterBehavior.onFailConversion();
                        break Label_0503;
                    }
                    final char conv2ByteUTFtoUTF16 = conv2ByteUTFtoUTF16(b2, array[i++]);
                    if (n6 < n7) {
                        characterConverterBehavior.onFailConversion(array2[n6++] = conv2ByteUTFtoUTF16);
                        continue;
                    }
                    array3[0] = n5 - i + 3;
                    break Label_0503;
                }
                case 14: {
                    if (i + 1 >= n5) {
                        array3[0] = n5 - i + 1;
                        characterConverterBehavior.onFailConversion();
                        break Label_0503;
                    }
                    final char conv3ByteAL32UTF8toUTF16 = conv3ByteAL32UTF8toUTF16(b2, array[i++], array[i++]);
                    if (n6 < n7) {
                        characterConverterBehavior.onFailConversion(array2[n6++] = conv3ByteAL32UTF8toUTF16);
                        continue;
                    }
                    array3[0] = n5 - i + 4;
                    break Label_0503;
                }
                case 15: {
                    if (i + 2 >= n5) {
                        array3[0] = n5 - i + 1;
                        characterConverterBehavior.onFailConversion();
                        break Label_0503;
                    }
                    if (n6 > n7 - 2) {
                        array3[0] = n5 - i + 2;
                        break Label_0503;
                    }
                    if (conv4ByteAL32UTF8toUTF16(b2, array[i++], array[i++], array[i++], array2, n6) == 1) {
                        characterConverterBehavior.onFailConversion();
                        ++n6;
                        continue;
                    }
                    n6 += 2;
                    continue;
                }
                default: {
                    if (n6 < n7) {
                        array2[n6++] = '\ufffd';
                        characterConverterBehavior.onFailConversion();
                        continue;
                    }
                    array3[0] = n5 - i + 2;
                    break Label_0503;
                }
            }
        }
        return n6 - n2;
    }
    
    public static final byte[] stringToAL32UTF8(final String s) {
        final char[] charArray = s.toCharArray();
        final byte[] array = new byte[charArray.length * 3];
        final int convertJavaCharsToAL32UTF8Bytes = convertJavaCharsToAL32UTF8Bytes(charArray, 0, array, 0, charArray.length);
        final byte[] array2 = new byte[convertJavaCharsToAL32UTF8Bytes];
        System.arraycopy(array, 0, array2, 0, convertJavaCharsToAL32UTF8Bytes);
        return array2;
    }
    
    public static final int convertJavaCharsToAL32UTF8Bytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) {
        final int n4 = n + n3;
        int n5 = n2;
        for (int i = n; i < n4; ++i) {
            final char c = array[i];
            if (c >= '\0' && c <= '\u007f') {
                array2[n5++] = (byte)c;
            }
            else if (isHiSurrogate(c)) {
                final char c2;
                if (i + 1 < n4 && isLoSurrogate(c2 = array[i + 1])) {
                    final int n6 = (c >>> 6 & 0xF) + 1;
                    array2[n5++] = (byte)(n6 >>> 2 | 0xF0);
                    array2[n5++] = (byte)((n6 & 0x3) << 4 | (c >>> 2 & 0xF) | 0x80);
                    array2[n5++] = (byte)((c & '\u0003') << 4 | (c2 >>> 6 & 0xF) | 0x80);
                    array2[n5++] = (byte)((c2 & '?') | 0x80);
                    ++i;
                }
                else {
                    array2[n5++] = -17;
                    array2[n5++] = -65;
                    array2[n5++] = -67;
                }
            }
            else if (c > '\u07ff') {
                array2[n5++] = (byte)(0xE0 | (c >>> 12 & 0xF));
                array2[n5++] = (byte)(0x80 | (c >>> 6 & 0x3F));
                array2[n5++] = (byte)(0x80 | (c >>> 0 & 0x3F));
            }
            else {
                array2[n5++] = (byte)(0xC0 | (c >>> 6 & 0x1F));
                array2[n5++] = (byte)(0x80 | (c >>> 0 & 0x3F));
            }
        }
        return n5 - n2;
    }
    
    public static final int string32UTF8Length(final String s) {
        return charArray32UTF8Length(s.toCharArray());
    }
    
    static final int charArray32UTF8Length(final char[] array) {
        int n = 0;
        for (int length = array.length, i = 0; i < length; ++i) {
            final char c = array[i];
            if (c >= '\0' && c <= '\u007f') {
                ++n;
            }
            else if (c > '\u07ff') {
                if (isHiSurrogate(c)) {
                    if (i + 1 < length) {
                        n += 4;
                        ++i;
                    }
                }
                else {
                    n += 3;
                }
            }
            else {
                n += 2;
            }
        }
        return n;
    }
    
    public static final String AL16UTF16BytesToString(final byte[] array, final int n) {
        final char[] value = new char[n >>> 1];
        AL16UTF16BytesToJavaChars(array, n, value);
        return new String(value);
    }
    
    public static final int AL16UTF16BytesToJavaChars(final byte[] array, final int n, final char[] array2) {
        final int n2 = n >>> 1;
        int i = 0;
        int n3 = 0;
        while (i < n2) {
            array2[i] = (char)(array[n3] << 8 | (array[n3 + 1] & 0xFF));
            n3 += 2;
            ++i;
        }
        return i;
    }
    
    public static final int convertAL16UTF16BytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int n3, final boolean b) throws SQLException {
        final CharacterConverterBehavior characterConverterBehavior = b ? CharacterConverterBehavior.REPLACEMENT : CharacterConverterBehavior.REPORT_ERROR;
        int n4 = n2;
        for (int n5 = n; n5 + 1 < n + n3; n5 += 2) {
            array2[n4++] = (char)(array[n5] << 8 | (array[n5 + 1] & 0xFF));
        }
        return n4 - n2;
    }
    
    public static final int convertAL16UTF16LEBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int n3, final boolean b) throws SQLException {
        final CharacterConverterBehavior characterConverterBehavior = b ? CharacterConverterBehavior.REPLACEMENT : CharacterConverterBehavior.REPORT_ERROR;
        int n4 = n2;
        for (int n5 = n, n6 = n + n3; n5 + 1 < n6; n5 += 2) {
            final char c = (char)(array[n5 + 1] << 8 | (array[n5] & 0xFF));
            if (isHiSurrogate(c)) {
                n5 += 2;
                if (n5 + 1 < n6) {
                    final char c2 = (char)((array[n5 + 1] << 8) + (array[n5] & 0xFF));
                    if (isLoSurrogate(c2)) {
                        array2[n4++] = c;
                    }
                    else {
                        array2[n4++] = '\ufffd';
                    }
                    array2[n4++] = c2;
                }
            }
            else {
                array2[n4++] = c;
            }
        }
        return n4 - n2;
    }
    
    public static final byte[] stringToAL16UTF16Bytes(final String s) {
        final char[] charArray = s.toCharArray();
        final int length = charArray.length;
        final byte[] array = new byte[length * 2];
        javaCharsToAL16UTF16Bytes(charArray, length, array);
        return array;
    }
    
    public static final int javaCharsToAL16UTF16Bytes(final char[] array, final int a, final byte[] array2) {
        return convertJavaCharsToAL16UTF16Bytes(array, 0, array2, 0, Math.min(a, array2.length >>> 1));
    }
    
    public static final int convertJavaCharsToAL16UTF16Bytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) {
        int i;
        int n4;
        for (i = n, n4 = n2; i < n + n3; ++i, n4 += 2) {
            array2[n4] = (byte)(array[i] >>> 8 & 0xFF);
            array2[n4 + 1] = (byte)(array[i] & '\u00ff');
        }
        return n4 - n2;
    }
    
    public static final byte[] stringToAL16UTF16LEBytes(final String s) {
        final char[] charArray = s.toCharArray();
        final byte[] array = new byte[charArray.length * 2];
        javaCharsToAL16UTF16LEBytes(charArray, charArray.length, array);
        return array;
    }
    
    public static final int javaCharsToAL16UTF16LEBytes(final char[] array, final int n, final byte[] array2) {
        return convertJavaCharsToAL16UTF16LEBytes(array, 0, array2, 0, n);
    }
    
    public static final int convertJavaCharsToAL16UTF16LEBytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) {
        int i;
        int n4;
        for (i = n, n4 = n2; i < n + n3; ++i, n4 += 2) {
            array2[n4] = (byte)(array[i] & '\u00ff');
            array2[n4 + 1] = (byte)(array[i] >>> 8);
        }
        return n4 - n2;
    }
    
    public static final int convertASCIIBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int n3) throws SQLException {
        for (int n4 = n2 + n3, i = n2, n5 = n; i < n4; ++i, ++n5) {
            array2[i] = (char)(0xFF & array[n5]);
        }
        return n3;
    }
    
    public static final int convertJavaCharsToASCIIBytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) throws SQLException {
        convertJavaCharsToASCIIBytes(array, n, array2, n2, n3, false);
        return n3;
    }
    
    public static final int convertJavaCharsToASCIIBytes(final char[] value, final int offset, final byte[] array, final int n, final int count, final boolean b) throws SQLException {
        if (b) {
            if (CharacterSet.asciiCharSet == null) {
                CharacterSet.asciiCharSet = make(1);
            }
            final byte[] convertWithReplacement = CharacterSet.asciiCharSet.convertWithReplacement(new String(value, offset, count));
            System.arraycopy(convertWithReplacement, 0, array, n, convertWithReplacement.length);
            return convertWithReplacement.length;
        }
        for (int i = 0; i < count; ++i) {
            array[n + i] = (byte)value[offset + i];
        }
        return count;
    }
    
    public static final int convertJavaCharsToISOLATIN1Bytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) throws SQLException {
        for (int i = 0; i < n3; ++i) {
            final char c = array[n + i];
            if (c > '\u00ff') {
                array2[n2 + i] = -65;
            }
            else {
                array2[n2 + i] = (byte)c;
            }
        }
        return n3;
    }
    
    public static final byte[] stringToASCII(final String s) {
        final byte[] array = new byte[s.length()];
        return s.getBytes();
    }
    
    public static final long convertUTF32toUTF16(final long n) {
        if (n > 65535L) {
            return (n & 0xFFL) | (0xDCL | ((n & 0x3FFL) >> 8 & 0xFFL) | ((n - 65536L >> 10 & 0xFFL) | (0xD8L | (n - 65536L >> 18 & 0xFFL)) << 8) << 8) << 8;
        }
        return n;
    }
    
    static final boolean isHiSurrogate(final char c) {
        return (char)(c & '\ufc00') == '\ud800';
    }
    
    static final boolean isLoSurrogate(final char c) {
        return (char)(c & '\ufc00') == '\udc00';
    }
    
    static final boolean check80toBF(final byte b) {
        return (b & 0xFFFFFFC0) == 0xFFFFFF80;
    }
    
    static final boolean check80to8F(final byte b) {
        return (b & 0xFFFFFFF0) == 0xFFFFFF80;
    }
    
    static final boolean check80to9F(final byte b) {
        return (b & 0xFFFFFFE0) == 0xFFFFFF80;
    }
    
    static final boolean checkA0toBF(final byte b) {
        return (b & 0xFFFFFFE0) == 0xFFFFFFA0;
    }
    
    static final boolean check90toBF(final byte b) {
        return (b & 0xFFFFFFC0) == 0xFFFFFF80 && (b & 0x30) != 0x0;
    }
    
    static final char conv2ByteUTFtoUTF16(final byte b, final byte b2) {
        if (b < -62 || b > -33 || !check80toBF(b2)) {
            return '\ufffd';
        }
        return (char)((b & 0x1F) << 6 | (b2 & 0x3F));
    }
    
    static final char conv3ByteUTFtoUTF16(final byte b, final byte b2, final byte b3) {
        if ((b != -32 || !checkA0toBF(b2) || !check80toBF(b3)) && (b < -31 || b > -17 || !check80toBF(b2) || !check80toBF(b3))) {
            return '\ufffd';
        }
        return (char)((b & 0xF) << 12 | (b2 & 0x3F) << 6 | (b3 & 0x3F));
    }
    
    static final char conv3ByteAL32UTF8toUTF16(final byte b, final byte b2, final byte b3) {
        if ((b != -32 || !checkA0toBF(b2) || !check80toBF(b3)) && (b < -31 || b > -20 || !check80toBF(b2) || !check80toBF(b3)) && (b != -19 || !check80to9F(b2) || !check80toBF(b3)) && (b < -18 || b > -17 || !check80toBF(b2) || !check80toBF(b3))) {
            return '\ufffd';
        }
        return (char)((b & 0xF) << 12 | (b2 & 0x3F) << 6 | (b3 & 0x3F));
    }
    
    static final int conv4ByteAL32UTF8toUTF16(final byte b, final byte b2, final byte b3, final byte b4, final char[] array, final int n) {
        if ((b != -16 || !check90toBF(b2) || !check80toBF(b3) || !check80toBF(b4)) && (b < -15 || b > -13 || !check80toBF(b2) || !check80toBF(b3) || !check80toBF(b4)) && (b != -12 || !check80to8F(b2) || !check80toBF(b3) || !check80toBF(b4))) {
            array[n] = '\ufffd';
            return 1;
        }
        array[n] = (char)((((b & 0x7) << 2 | (b2 >>> 4 & 0x3)) - 1 & 0xF) << 6 | (b2 & 0xF) << 2 | (b3 >>> 4 & 0x3) | 0xD800);
        array[n + 1] = (char)((b3 & 0xF) << 6 | (b4 & 0x3F) | 0xDC00);
        return 2;
    }
    
    static void failUTFConversion() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(null, 55);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public int encodedByteLength(final String s) {
        if (s == null || s.length() == 0) {
            return 0;
        }
        return this.convertWithReplacement(s).length;
    }
    
    public int encodedByteLength(final char[] value) {
        if (value == null || value.length == 0) {
            return 0;
        }
        return this.convertWithReplacement(new String(value)).length;
    }
    
    public int toCharWithReplacement(final byte[] array, final int n, final char[] array2, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    public boolean isUnknown() {
        return false;
    }
    
    static {
        CharacterSet.asciiCharSet = null;
        try {
            Class.forName("oracle.i18n.text.converter.CharacterConverterSJIS");
            CharacterSetWithConverter.ccFactory = new CharacterConverterFactoryOGS();
        }
        catch (ClassNotFoundException ex) {}
        CharacterSet.factory = new CharacterSetFactoryDefault();
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    abstract static class CharacterConverterBehavior
    {
        public static final char[] NULL_CHARS;
        public static final char UTF16_REPLACEMENT_CHAR = '\ufffd';
        public static final CharacterConverterBehavior REPORT_ERROR;
        public static final CharacterConverterBehavior REPLACEMENT;
        private final String m_name;
        
        public CharacterConverterBehavior(final String name) {
            this.m_name = name;
        }
        
        public abstract void onFailConversion(final char p0) throws SQLException;
        
        public abstract void onFailConversion() throws SQLException;
        
        static {
            NULL_CHARS = new char[1];
            REPORT_ERROR = new CharacterConverterBehavior("Report Error") {
                @Override
                public void onFailConversion() throws SQLException {
                    final SQLException sqlException = DatabaseError.createSqlException(null, 55);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                
                @Override
                public void onFailConversion(final char c) throws SQLException {
                    if (c == '\ufffd') {
                        final SQLException sqlException = DatabaseError.createSqlException(null, 55);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                }
            };
            REPLACEMENT = new CharacterConverterBehavior("Replacement") {
                @Override
                public void onFailConversion() throws SQLException {
                }
                
                @Override
                public void onFailConversion(final char c) throws SQLException {
                }
            };
        }
    }
}
