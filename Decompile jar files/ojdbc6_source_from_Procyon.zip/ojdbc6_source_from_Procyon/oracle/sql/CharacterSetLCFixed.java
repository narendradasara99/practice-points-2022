// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.converter.JdbcCharacterConverters;

class CharacterSetLCFixed extends CharacterSetWithConverter
{
    static final String CHAR_CONV_SUPERCLASS_NAME = "oracle.sql.converter.CharacterConverterLCFixed";
    static final int CHARLENGTH = 4;
    static Class m_charConvSuperclass;
    char[] m_leadingCodes;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetLCFixed(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        super(n, jdbcCharacterConverters);
        this.m_leadingCodes = jdbcCharacterConverters.getLeadingCodes();
    }
    
    static CharacterSetLCFixed getInstance(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        if (jdbcCharacterConverters.getGroupId() == 3) {
            return new CharacterSetLCFixed(n, jdbcCharacterConverters);
        }
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        if (characterWalker.bytes.length - characterWalker.next < 4) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182, "destination too small");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int n = characterWalker.bytes[characterWalker.next] << 8 | characterWalker.bytes[characterWalker.next + 1];
        for (int i = 0; i < this.m_leadingCodes.length; ++i) {
            if (n == this.m_leadingCodes[i]) {
                int n2 = 0;
                for (int j = 0; j < 4; ++j) {
                    n2 = (n2 << 8 | characterWalker.bytes[characterWalker.next++]);
                }
                return n2;
            }
        }
        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 181, "Leading code invalid");
        sqlException2.fillInStackTrace();
        throw sqlException2;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        final int n2 = n >> 16;
        for (int i = 0; i < this.m_leadingCodes.length; ++i) {
            if (n2 == this.m_leadingCodes[i]) {
                CharacterSet.need(characterBuffer, 4);
                for (int j = 3; j >= 0; --j) {
                    characterBuffer.bytes[characterBuffer.next++] = (byte)(n >> 8 * j & 0xFF);
                }
                return;
            }
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 181, "Leading code invalid");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
