// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.CharArrayReader;
import oracle.jdbc.driver.DBConversion;
import java.io.Reader;
import oracle.jdbc.util.RepConversion;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;

public class RAW extends Datum
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static int hexDigit2Nibble(final char c) throws SQLException {
        final int digit = Character.digit(c, 16);
        if (digit == -1) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 59, "Invalid hex digit: " + c);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return digit;
    }
    
    public static byte[] hexString2Bytes(final String s) throws SQLException {
        final int length = s.length();
        final char[] dst = new char[length];
        s.getChars(0, length, dst, 0);
        int i = 0;
        int n = 0;
        if (length == 0) {
            return new byte[0];
        }
        byte[] array;
        if (length % 2 > 0) {
            array = new byte[(length + 1) / 2];
            array[i++] = (byte)hexDigit2Nibble(dst[n++]);
        }
        else {
            array = new byte[length / 2];
        }
        while (i < array.length) {
            array[i] = (byte)(hexDigit2Nibble(dst[n++]) << 4 | hexDigit2Nibble(dst[n++]));
            ++i;
        }
        return array;
    }
    
    public static RAW newRAW(final Object o) throws SQLException {
        return new RAW(o);
    }
    
    public static RAW oldRAW(final Object o) throws SQLException {
        RAW raw;
        if (o instanceof String) {
            final String s = (String)o;
            byte[] bytes;
            try {
                bytes = s.getBytes("ISO8859_1");
            }
            catch (UnsupportedEncodingException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(null, 109, "ISO8859_1 character encoding not found");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            raw = new RAW(bytes);
        }
        else {
            raw = new RAW(o);
        }
        return raw;
    }
    
    public RAW() {
    }
    
    public RAW(final byte[] array) {
        super(array);
    }
    
    @Deprecated
    public RAW(final Object o) throws SQLException {
        this();
        if (o instanceof byte[]) {
            this.setShareBytes((byte[])o);
        }
        else {
            if (!(o instanceof String)) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59, o);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.setShareBytes(hexString2Bytes((String)o));
        }
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this.getBytes();
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.lang.String") == 0 || name.compareTo("java.io.InputStream") == 0 || name.compareTo("java.io.Reader") == 0;
    }
    
    @Override
    public String stringValue() {
        return RepConversion.bArray2String(this.getBytes());
    }
    
    @Override
    public Reader characterStreamValue() throws SQLException {
        final int n = (int)this.getLength();
        final char[] buf = new char[n * 2];
        DBConversion.RAWBytesToHexChars(this.shareBytes(), n, buf);
        return new CharArrayReader(buf);
    }
    
    @Override
    public InputStream asciiStreamValue() throws SQLException {
        final int n = (int)this.getLength();
        final char[] array = new char[n * 2];
        DBConversion.RAWBytesToHexChars(this.shareBytes(), n, array);
        final byte[] buf = new byte[n * 2];
        DBConversion.javaCharsToAsciiBytes(array, n * 2, buf);
        return new ByteArrayInputStream(buf);
    }
    
    @Override
    public InputStream binaryStreamValue() throws SQLException {
        return this.getStream();
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new byte[n][];
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
