// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

abstract class CharacterSetFactory
{
    public static final short DEFAULT_CHARSET = -1;
    public static final short ASCII_CHARSET = 1;
    public static final short ISO_LATIN_1_CHARSET = 31;
    public static final short UNICODE_1_CHARSET = 870;
    public static final short UNICODE_2_CHARSET = 871;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public abstract CharacterSet make(final int p0);
    
    public static void main(final String[] array) {
        final CharacterSet make = CharacterSet.make(871);
        final int[] array2 = { 1, 31, 870, 871 };
        for (int i = 0; i < array2.length; ++i) {
            final CharacterSet make2 = CharacterSet.make(array2[i]);
            final String s = "longlonglonglong";
            final String string = s + s + s + s;
            final String string2 = string + string + string + string;
            final String string3 = string2 + string2 + string2 + string2;
            final String[] array3 = { "abc", "ab?c", "XYZ", string3 + string3 + string3 + string3 };
            for (int j = 0; j < array3.length; ++j) {
                String string4;
                final String s2 = string4 = array3[j];
                if (s2.length() > 16) {
                    string4 = string4.substring(0, 16) + "...";
                }
                System.out.println("testing " + make2 + " against <" + string4 + ">");
                boolean b = true;
                try {
                    final byte[] convertWithReplacement = make2.convertWithReplacement(s2);
                    final String stringWithReplacement = make2.toStringWithReplacement(convertWithReplacement, 0, convertWithReplacement.length);
                    final byte[] convert = make2.convert(stringWithReplacement);
                    final String string5 = make2.toString(convert, 0, convert.length);
                    if (!stringWithReplacement.equals(string5)) {
                        System.out.println("    FAILED roundTrip " + string5);
                        b = false;
                    }
                    if (make2.isLossyFrom(make)) {
                        try {
                            final byte[] convert2 = make2.convert(s2);
                            if (!make2.toString(convert2, 0, convert2.length).equals(string5)) {
                                System.out.println("    FAILED roundtrip, no throw");
                            }
                        }
                        catch (SQLException ex) {}
                    }
                    else {
                        if (!string5.equals(s2)) {
                            System.out.println("    FAILED roundTrip " + string5);
                            b = false;
                        }
                        final byte[] convert3 = make.convert(s2);
                        final byte[] convert4 = make2.convert(make, convert3, 0, convert3.length);
                        final String string6 = make2.toString(convert4, 0, convert4.length);
                        if (!string6.equals(s2)) {
                            System.out.println("    FAILED withoutReplacement " + string6);
                            b = false;
                        }
                    }
                }
                catch (Exception obj) {
                    System.out.println("    FAILED with Exception " + obj);
                }
                if (b) {
                    System.out.println("    PASSED " + (make2.isLossyFrom(make) ? "LOSSY" : ""));
                }
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
