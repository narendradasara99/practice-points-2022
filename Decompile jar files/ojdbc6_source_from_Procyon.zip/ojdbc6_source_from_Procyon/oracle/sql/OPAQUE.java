// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.Map;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;

public class OPAQUE extends DatumWithConnection
{
    OpaqueDescriptor descriptor;
    byte[] value;
    long imageOffset;
    long imageLength;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OPAQUE(final OpaqueDescriptor descriptor, final Connection physicalConnectionOf, final Object o) throws SQLException {
        if (descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 61, "OPAQUE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.descriptor = descriptor;
        if (physicalConnectionOf != null) {
            this.setPhysicalConnectionOf(physicalConnectionOf);
        }
        if (o instanceof byte[]) {
            this.value = (byte[])o;
            return;
        }
        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
        sqlException2.fillInStackTrace();
        throw sqlException2;
    }
    
    public OPAQUE(final OpaqueDescriptor descriptor, final byte[] array, final Connection physicalConnectionOf) throws SQLException {
        super(array);
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.descriptor = descriptor;
        this.value = null;
    }
    
    public String getSQLTypeName() throws SQLException {
        return this.descriptor.getName();
    }
    
    public OpaqueDescriptor getDescriptor() throws SQLException {
        return this.descriptor;
    }
    
    public void setDescriptor(final OpaqueDescriptor descriptor) {
        this.descriptor = descriptor;
    }
    
    public byte[] toBytes() throws SQLException {
        return this.descriptor.toBytes(this, false);
    }
    
    public Object getValue() throws SQLException {
        return this.descriptor.toValue(this, false);
    }
    
    public byte[] getBytesValue() throws SQLException {
        return this.descriptor.toValue(this, false);
    }
    
    public void setValue(final byte[] value) throws SQLException {
        this.value = value;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return false;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Object[n];
    }
    
    public Map getMap() {
        try {
            return this.getInternalConnection().getTypeMap();
        }
        catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this.toJdbc(this.getMap());
    }
    
    public Object toJdbc(final Map map) throws SQLException {
        Object class1 = this;
        if (map != null) {
            final Class class2 = this.descriptor.getClass(map);
            if (class2 != null) {
                class1 = this.toClass(class2, map);
            }
        }
        return class1;
    }
    
    public Object toClass(final Class clazz) throws SQLException {
        return this.toClass(clazz, this.getMap());
    }
    
    public Object toClass(final Class clazz, final Map map) throws SQLException {
        Object create;
        try {
            if (clazz == null || clazz == OPAQUE.class) {
                create = this;
            }
            else {
                final OPAQUE instance = clazz.newInstance();
                if (!(instance instanceof ORADataFactory)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, this.descriptor.getName());
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                create = ((ORADataFactory)instance).create(this, 2007);
            }
        }
        catch (InstantiationException ex) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, "InstantiationException: " + ex.getMessage());
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        catch (IllegalAccessException ex2) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, "IllegalAccessException: " + ex2.getMessage());
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        return create;
    }
    
    public void setImage(final byte[] shareBytes, final long imageOffset, final long imageLength) throws SQLException {
        this.setShareBytes(shareBytes);
        this.imageOffset = imageOffset;
        this.imageLength = imageLength;
    }
    
    public void setImageLength(final long imageLength) throws SQLException {
        this.imageLength = imageLength;
    }
    
    public long getImageOffset() {
        return this.imageOffset;
    }
    
    public long getImageLength() {
        return this.imageLength;
    }
    
    @Override
    public Connection getJavaSqlConnection() throws SQLException {
        return super.getJavaSqlConnection();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
