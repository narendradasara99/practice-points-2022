// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

public final class CharacterBuffer
{
    CharacterSet charSet;
    byte[] bytes;
    int next;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public CharacterBuffer(final CharacterSet charSet) {
        this.charSet = charSet;
        this.next = 0;
        this.bytes = new byte[32];
    }
    
    public void append(final int n) throws SQLException {
        this.charSet.encode(this, n);
    }
    
    public byte[] getBytes() {
        return CharacterSet.useOrCopy(this.bytes, 0, this.next);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
