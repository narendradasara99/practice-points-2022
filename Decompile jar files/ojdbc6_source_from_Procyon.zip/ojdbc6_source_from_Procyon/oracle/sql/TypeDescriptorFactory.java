// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import oracle.jdbc.oracore.PickleContext;

class TypeDescriptorFactory implements ORADataFactory
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    public ORAData create(final Datum datum, final int n) throws SQLException {
        if (datum == null) {
            return null;
        }
        if (n == 2007) {
            final OPAQUE opaque = (OPAQUE)datum;
            return TypeDescriptor.unpickleOpaqueTypeImage(new PickleContext(opaque.getBytesValue(), 0L), opaque.getPhysicalConnection(), new short[1]);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
