// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.driver.OracleDriver;
import oracle.jdbc.internal.OracleConnection;

public abstract class DatumWithConnection extends Datum
{
    private OracleConnection physicalConnection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleConnection getPhysicalConnection() {
        if (this.physicalConnection == null) {
            try {
                this.physicalConnection = (OracleConnection)new OracleDriver().defaultConnection();
            }
            catch (SQLException ex) {}
        }
        return this.physicalConnection;
    }
    
    public DatumWithConnection(final byte[] array) throws SQLException {
        super(array);
        this.physicalConnection = null;
    }
    
    public DatumWithConnection() {
        this.physicalConnection = null;
    }
    
    public static void assertNotNull(final Connection connection) throws SQLException {
        if (connection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 68, "Connection is null");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public static void assertNotNull(final TypeDescriptor typeDescriptor) throws SQLException {
        if (typeDescriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 61);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public void setPhysicalConnectionOf(final Connection connection) {
        this.physicalConnection = ((oracle.jdbc.OracleConnection)connection).physicalConnectionWithin();
    }
    
    public Connection getJavaSqlConnection() throws SQLException {
        return this.getPhysicalConnection().getWrapper();
    }
    
    public oracle.jdbc.OracleConnection getOracleConnection() throws SQLException {
        return this.getPhysicalConnection().getWrapper();
    }
    
    public OracleConnection getInternalConnection() throws SQLException {
        return this.getPhysicalConnection();
    }
    
    @Deprecated
    public oracle.jdbc.driver.OracleConnection getConnection() throws SQLException {
        oracle.jdbc.driver.OracleConnection oracleConnection;
        try {
            oracleConnection = (oracle.jdbc.driver.OracleConnection)((oracle.jdbc.driver.OracleConnection)this.physicalConnection).getWrapper();
        }
        catch (ClassCastException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 103);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return oracleConnection;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.physicalConnection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
