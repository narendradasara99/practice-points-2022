// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.core.lmx.CoreException;
import java.sql.SQLException;
import java.math.BigInteger;
import java.math.BigDecimal;

public class NUMBER extends Datum
{
    static byte[] MAX_LONG;
    static byte[] MIN_LONG;
    private static final int CHARACTER_ZERO = 48;
    private static final BigDecimal BIGDEC_NEGZERO;
    private static final BigDecimal BIGDEC_ZERO;
    private static final BigDecimal BIGDEC_ONE;
    private static final BigInteger BIGINT_ZERO;
    private static final BigInteger BIGINT_HUND;
    private static final byte DIGEND = 21;
    private static final byte ODIGEND = 9;
    private static final int HUNDIGMAX = 66;
    private static final int BIGINTARRAYMAX = 54;
    private static final double BIGRATIO = 0.1505149978319906;
    private static final int BIGLENMAX = 22;
    static final byte LNXM_NUM = 22;
    static final int LNXSGNBT = 128;
    static final byte LNXDIGS = 20;
    static final byte LNXEXPBS = 64;
    static final double ORANUM_FBASE = 100.0;
    static final int LNXBASE = 100;
    static final byte IEEE_DBL_DIG = 15;
    private static final byte IEEE_FLT_DIG = 6;
    static final int LNXEXPMX = 127;
    static final int LNXEXPMN = 0;
    static final int LNXMXOUT = 40;
    static final int LNXMXFMT = 64;
    private static final byte BYTE_MAX_VALUE = Byte.MAX_VALUE;
    private static final byte BYTE_MIN_VALUE = Byte.MIN_VALUE;
    private static final short SHORT_MAX_VALUE = Short.MAX_VALUE;
    private static final short SHORT_MIN_VALUE = Short.MIN_VALUE;
    private static final byte[] PI;
    private static final byte[] E;
    private static final byte[] LN10;
    private static LnxLib _slnxlib;
    private static LnxLib _thinlib;
    private static int DBL_MAX;
    private static int INT_MAX;
    private static float FLOAT_MAX_INT;
    private static float FLOAT_MIN_INT;
    private static double DOUBLE_MAX_INT;
    private static double DOUBLE_MIN_INT;
    private static double DOUBLE_MAX_INT_2;
    private static double DOUBLE_MIN_INT_2;
    private static Object drvType;
    private static String LANGID;
    
    public NUMBER() {
        super(_makeZero());
    }
    
    public NUMBER(final byte[] array) {
        super(array);
    }
    
    public NUMBER(final byte b) {
        super(toBytes(b));
    }
    
    public NUMBER(final int n) {
        super(toBytes(n));
    }
    
    public NUMBER(final long n) {
        super(toBytes(n));
    }
    
    public NUMBER(final short n) {
        super(toBytes(n));
    }
    
    public NUMBER(final float n) {
        super(toBytes(n));
    }
    
    public NUMBER(final double n) throws SQLException {
        super(toBytes(n));
    }
    
    public NUMBER(final BigDecimal bigDecimal) throws SQLException {
        super(toBytes(bigDecimal));
    }
    
    public NUMBER(final BigInteger bigInteger) throws SQLException {
        super(toBytes(bigInteger));
    }
    
    public NUMBER(final String s, final int n) throws SQLException {
        super(toBytes(s, n));
    }
    
    public NUMBER(final boolean b) {
        super(toBytes(b));
    }
    
    public NUMBER(final Object o) throws SQLException {
        if (o instanceof Integer) {
            this.setShareBytes(toBytes((int)o));
        }
        else if (o instanceof Long) {
            this.setShareBytes(toBytes((long)o));
        }
        else if (o instanceof Float) {
            this.setShareBytes(toBytes((float)o));
        }
        else if (o instanceof Double) {
            this.setShareBytes(toBytes((double)o));
        }
        else if (o instanceof BigInteger) {
            this.setShareBytes(toBytes((BigInteger)o));
        }
        else if (o instanceof BigDecimal) {
            this.setShareBytes(toBytes((BigDecimal)o));
        }
        else if (o instanceof Boolean) {
            this.setShareBytes(toBytes((boolean)o));
        }
        else {
            if (!(o instanceof String)) {
                throw new SQLException("Initialization failed");
            }
            this.setShareBytes(this.stringToBytes((String)o));
        }
    }
    
    public static double toDouble(final byte[] array) {
        if (_isZero(array)) {
            return 0.0;
        }
        if (_isPosInf(array)) {
            return Double.POSITIVE_INFINITY;
        }
        if (_isNegInf(array)) {
            return Double.NEGATIVE_INFINITY;
        }
        String s = null;
        try {
            if (NUMBER.drvType == null) {
                s = NUMBER._slnxlib.lnxnuc(array, NUMBER.DBL_MAX, null);
            }
            else {
                s = NUMBER._slnxlib.lnxnuc(array, NUMBER.DBL_MAX, NUMBER.LANGID);
            }
        }
        catch (Exception ex) {}
        return Double.valueOf(s);
    }
    
    public static float toFloat(final byte[] array) {
        return (float)toDouble(array);
    }
    
    public static long toLong(final byte[] array) throws SQLException {
        if (_isZero(array)) {
            return 0L;
        }
        if (_isInf(array) || Datum.compareBytes(array, NUMBER.MAX_LONG) > 0 || Datum.compareBytes(array, NUMBER.MIN_LONG) < 0) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        return _getLnxLib().lnxsni(array);
    }
    
    public static int toInt(final byte[] array) throws SQLException {
        if (_isInf(array)) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        String s;
        if (NUMBER.drvType == null) {
            s = NUMBER._slnxlib.lnxnuc(array, NUMBER.INT_MAX, null);
        }
        else {
            s = NUMBER._slnxlib.lnxnuc(array, NUMBER.INT_MAX, NUMBER.LANGID);
        }
        final double doubleValue = Double.valueOf(s);
        if ((float)doubleValue > NUMBER.FLOAT_MAX_INT || (float)doubleValue < NUMBER.FLOAT_MIN_INT) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        if (doubleValue > NUMBER.DOUBLE_MAX_INT && doubleValue <= NUMBER.DOUBLE_MAX_INT_2) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        if (doubleValue < NUMBER.DOUBLE_MIN_INT && doubleValue >= NUMBER.DOUBLE_MIN_INT_2) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        return (int)doubleValue;
    }
    
    public static short toShort(final byte[] array) throws SQLException {
        long long1 = 0L;
        try {
            long1 = toLong(array);
            if (long1 > 32767L || long1 < -32768L) {
                throw new SQLException(CoreException.getMessage((byte)3));
            }
        }
        finally {}
        return (short)long1;
    }
    
    public static byte toByte(final byte[] array) throws SQLException {
        long long1 = 0L;
        try {
            long1 = toLong(array);
            if (long1 > 127L || long1 < -128L) {
                throw new SQLException(CoreException.getMessage((byte)3));
            }
        }
        finally {}
        return (byte)long1;
    }
    
    public static BigInteger toBigInteger(final byte[] array) throws SQLException {
        final long[] array2 = new long[10];
        final int n = 9;
        final int n2 = 1;
        int n3 = 0;
        if (_isZero(array)) {
            return NUMBER.BIGINT_ZERO;
        }
        if (_isInf(array)) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        final boolean isPositive = _isPositive(array);
        final byte[] fromLnxFmt = _fromLnxFmt(array);
        if (fromLnxFmt[0] < 0) {
            return NUMBER.BIGINT_ZERO;
        }
        int i;
        final int n4 = i = Math.min(fromLnxFmt[0] + 1, fromLnxFmt.length - 1);
        byte b;
        if ((n4 & 0x1) == 0x1) {
            array2[n] = fromLnxFmt[n2];
            b = (byte)(n2 + 1);
            --i;
        }
        else {
            array2[n] = fromLnxFmt[n2] * 100 + fromLnxFmt[n2 + 1];
            b = (byte)(n2 + 2);
            i -= 2;
        }
        int n5 = n;
        while (i != 0) {
            long n6 = fromLnxFmt[b] * 100 + fromLnxFmt[b + 1];
            for (int j = 9; j >= n5; j = (byte)(j - 1)) {
                final long n7 = n6 + array2[j] * 10000L;
                array2[j] = (n7 & 0xFFFFL);
                n6 = n7 >> 16;
            }
            if (n6 != 0L) {}
            n5 = (byte)(n5 - 1);
            array2[n5] = n6;
            b += 2;
            i -= 2;
        }
        int n8;
        if (array2[n5] >> 8 != 0L) {
            n8 = 2 * (9 - n5) + 2;
        }
        else {
            n8 = 2 * (9 - n5) + 1;
        }
        final byte[] magnitude = new byte[n8];
        if ((n8 & 0x1) == 0x1) {
            magnitude[n3] = (byte)array2[n5];
            ++n3;
        }
        else {
            magnitude[n3] = (byte)(array2[n5] >> 8);
            ++n3;
            magnitude[n3] = (byte)(array2[n5] & 0xFFL);
            ++n3;
        }
        for (byte b2 = (byte)(n5 + 1); b2 <= 9; ++b2) {
            magnitude[n3] = (byte)(array2[b2] >> 8);
            magnitude[n3 + 1] = (byte)(array2[b2] & 0xFFL);
            n3 += 2;
        }
        return new BigInteger(isPositive ? 1 : -1, magnitude).multiply(NUMBER.BIGINT_HUND.pow(fromLnxFmt[0] - (n4 - 1)));
    }
    
    public static BigDecimal toBigDecimal(final byte[] array) throws SQLException {
        final long[] array2 = new long[10];
        final int n = 9;
        final int n2 = 1;
        int n3 = 0;
        if (_isZero(array)) {
            return NUMBER.BIGDEC_ZERO;
        }
        if (_isInf(array)) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        final boolean isPositive = _isPositive(array);
        final byte[] fromLnxFmt = _fromLnxFmt(array);
        int i;
        final int n4 = i = fromLnxFmt.length - 1;
        byte b;
        if ((n4 & 0x1) == 0x1) {
            array2[n] = fromLnxFmt[n2];
            b = (byte)(n2 + 1);
            --i;
        }
        else {
            array2[n] = fromLnxFmt[n2] * 100 + fromLnxFmt[n2 + 1];
            b = (byte)(n2 + 2);
            i -= 2;
        }
        int n5 = n;
        while (i != 0) {
            long n6 = fromLnxFmt[b] * 100 + fromLnxFmt[b + 1];
            for (int j = 9; j >= n5; j = (byte)(j - 1)) {
                final long n7 = n6 + array2[j] * 10000L;
                array2[j] = (n7 & 0xFFFFL);
                n6 = n7 >> 16;
            }
            if (n6 != 0L) {}
            n5 = (byte)(n5 - 1);
            array2[n5] = n6;
            b += 2;
            i -= 2;
        }
        int n8;
        if (array2[n5] >> 8 != 0L) {
            n8 = 2 * (9 - n5) + 2;
        }
        else {
            n8 = 2 * (9 - n5) + 1;
        }
        final byte[] magnitude = new byte[n8];
        if ((n8 & 0x1) == 0x1) {
            magnitude[n3] = (byte)array2[n5];
            ++n3;
        }
        else {
            magnitude[n3] = (byte)(array2[n5] >> 8);
            ++n3;
            magnitude[n3] = (byte)(array2[n5] & 0xFFL);
            ++n3;
        }
        for (byte b2 = (byte)(n5 + 1); b2 <= 9; ++b2) {
            magnitude[n3] = (byte)(array2[b2] >> 8);
            magnitude[n3 + 1] = (byte)(array2[b2] & 0xFFL);
            n3 += 2;
        }
        final BigDecimal bigDecimal = new BigDecimal(new BigInteger(isPositive ? 1 : -1, magnitude));
        final int n9 = fromLnxFmt[0] - n4 + 1;
        BigDecimal bigDecimal2 = bigDecimal.movePointRight(n9 * 2);
        if (n9 < 0 && fromLnxFmt[n4] % 10 == 0) {
            bigDecimal2 = bigDecimal2.setScale(-(n9 * 2 + 1));
        }
        return bigDecimal2;
    }
    
    public static String toString(final byte[] array) {
        int count = 0;
        if (_isZero(array)) {
            return "0";
        }
        if (_isPosInf(array)) {
            return new Double(Double.POSITIVE_INFINITY).toString();
        }
        if (_isNegInf(array)) {
            return new Double(Double.NEGATIVE_INFINITY).toString();
        }
        final byte[] fromLnxFmt = _fromLnxFmt(array);
        int i = fromLnxFmt[0];
        final int n = fromLnxFmt.length - 1;
        final int n2 = i - (n - 1);
        int n3;
        if (n2 >= 0) {
            n3 = 2 * (i + 1) + 1;
        }
        else if (i >= 0) {
            n3 = 2 * (n + 1);
        }
        else {
            n3 = 2 * (n - i) + 3;
        }
        final char[] value = new char[n3];
        if (!_isPositive(array)) {
            value[count++] = '-';
        }
        if (n2 >= 0) {
            count += _byteToChars(fromLnxFmt[1], value, count);
            for (int j = 2; j <= n; ++j, --i) {
                _byteTo2Chars(fromLnxFmt[j], value, count);
                count += 2;
            }
            if (i > 0) {
                while (i > 0) {
                    value[count++] = '0';
                    value[count++] = '0';
                    --i;
                }
            }
        }
        else {
            int k = n + n2;
            if (k > 0) {
                count += _byteToChars(fromLnxFmt[1], value, count);
                if (k == 1) {
                    value[count++] = '.';
                }
                int l;
                for (l = 2; l < n; ++l) {
                    _byteTo2Chars(fromLnxFmt[l], value, count);
                    count += 2;
                    if (k == l) {
                        value[count++] = '.';
                    }
                }
                if (fromLnxFmt[l] % 10 == 0) {
                    count += _byteToChars((byte)(fromLnxFmt[l] / 10), value, count);
                }
                else {
                    _byteTo2Chars(fromLnxFmt[l], value, count);
                    count += 2;
                }
            }
            else {
                value[count++] = '0';
                value[count++] = '.';
                while (k < 0) {
                    value[count++] = '0';
                    value[count++] = '0';
                    ++k;
                }
                int n4;
                for (n4 = 1; n4 < n; ++n4) {
                    _byteTo2Chars(fromLnxFmt[n4], value, count);
                    count += 2;
                }
                if (fromLnxFmt[n4] % 10 == 0) {
                    count += _byteToChars((byte)(fromLnxFmt[n4] / 10), value, count);
                }
                else {
                    _byteTo2Chars(fromLnxFmt[n4], value, count);
                    count += 2;
                }
            }
        }
        return new String(value, 0, count);
    }
    
    public static boolean toBoolean(final byte[] array) {
        return !_isZero(array);
    }
    
    public static byte[] toBytes(final double v) throws SQLException {
        if (Double.isNaN(v)) {
            throw new IllegalArgumentException(CoreException.getMessage((byte)11));
        }
        if (v == 0.0 || v == -0.0) {
            return _makeZero();
        }
        if (v == Double.POSITIVE_INFINITY) {
            return _makePosInf();
        }
        if (v == Double.NEGATIVE_INFINITY) {
            return _makeNegInf();
        }
        return _getThinLib().lnxren(v);
    }
    
    public static byte[] toBytes(final float n) {
        if (Float.isNaN(n)) {
            throw new IllegalArgumentException(CoreException.getMessage((byte)11));
        }
        if (n == 0.0f || n == -0.0f) {
            return _makeZero();
        }
        if (n == Float.POSITIVE_INFINITY) {
            return _makePosInf();
        }
        if (n == Float.NEGATIVE_INFINITY) {
            return _makeNegInf();
        }
        final String string = Float.toString(n);
        try {
            return _getLnxLib().lnxcpn(string, false, 0, false, 0, "AMERICAN_AMERICA");
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public static byte[] toBytes(final long n) {
        return _getLnxLib().lnxmin(n);
    }
    
    public static byte[] toBytes(final int n) {
        return toBytes((long)n);
    }
    
    public static byte[] toBytes(final short n) {
        return toBytes((long)n);
    }
    
    public static byte[] toBytes(final byte b) {
        return toBytes((long)b);
    }
    
    public static byte[] toBytes(final BigInteger bigInteger) throws SQLException {
        final byte[] array = new byte[66];
        final long[] array2 = new long[54];
        final long[] array3 = new long[22];
        final int n = 21;
        final int n2 = 0;
        int n3 = 21;
        int n4 = 0;
        boolean b = true;
        if (bigInteger.signum() == 0) {
            return _makeZero();
        }
        byte[] array4;
        int exponent;
        if (bigInteger.signum() == -1) {
            final BigInteger abs = bigInteger.abs();
            b = false;
            array4 = abs.toByteArray();
            exponent = (int)Math.floor(abs.bitLength() * 0.1505149978319906);
        }
        else {
            array4 = bigInteger.toByteArray();
            exponent = (int)Math.floor(bigInteger.bitLength() * 0.1505149978319906);
        }
        if (bigInteger.abs().compareTo(NUMBER.BIGINT_HUND.pow(exponent)) < 0) {
            --exponent;
        }
        if (array4.length > 54) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        for (int i = 0; i < array4.length; ++i) {
            if (array4[i] < 0) {
                array2[i] = array4[i] + 256;
            }
            else {
                array2[i] = array4[i];
            }
        }
        int j = array4.length;
        byte b2 = 0;
        switch (j % 3) {
            case 2: {
                array3[n] = (array2[n2] << 8) + array2[n2 + 1];
                b2 = (byte)(n2 + 2);
                j -= 2;
                break;
            }
            case 1: {
                array3[n] = array2[n2];
                b2 = (byte)(n2 + 1);
                --j;
                break;
            }
            default: {
                final long n5 = (array2[n2] << 16) + (array2[n2 + 1] << 8) + array2[n2 + 2];
                array3[n] = n5 % 1000000L;
                array3[n - 1] = n5 / 1000000L;
                n3 = (byte)(n3 - ((array3[n - 1] != 0L) ? 1 : 0));
                b2 = (byte)(n2 + 3);
                j -= 3;
                break;
            }
        }
        while (j != 0) {
            long n6 = (array2[b2] << 4) + (array2[b2 + 1] >> 4);
            for (int k = 21; k >= n3; k = (byte)(k - 1)) {
                final long n7 = n6 + (array3[k] << 12);
                array3[k] = n7 % 1000000L;
                n6 = n7 / 1000000L;
            }
            if (n6 != 0L) {
                n3 = (byte)(n3 - 1);
                array3[n3] = n6;
            }
            long n8 = ((array2[b2 + 1] & 0xFL) << 8) + array2[b2 + 2];
            for (int l = 21; l >= n3; l = (byte)(l - 1)) {
                final long n9 = n8 + (array3[l] << 12);
                array3[l] = n9 % 1000000L;
                n8 = n9 / 1000000L;
            }
            if (n8 != 0L) {
                n3 = (byte)(n3 - 1);
                array3[n3] = n8;
            }
            b2 += 3;
            j -= 3;
        }
        int n10;
        if ((array[n4] = (byte)(array3[n3] / 10000L)) != 0) {
            n10 = 3 * (21 - n3) + 3;
            array[n4 + 1] = (byte)(array3[n3] % 10000L / 100L);
            array[n4 + 2] = (byte)(array3[n3] % 100L);
            n4 += 3;
        }
        else if ((array[n4] = (byte)(array3[n3] % 10000L / 100L)) != 0) {
            n10 = 3 * (21 - n3) + 2;
            array[n4 + 1] = (byte)(array3[n3] % 100L);
            n4 += 2;
        }
        else {
            array[n4] = (byte)array3[n3];
            n10 = 3 * (21 - n3) + 1;
            ++n4;
        }
        for (byte b3 = (byte)(n3 + 1); b3 <= 21; ++b3) {
            array[n4] = (byte)(array3[b3] / 10000L);
            array[n4 + 1] = (byte)(array3[b3] % 10000L / 100L);
            array[n4 + 2] = (byte)(array3[b3] % 100L);
            n4 += 3;
        }
        for (int n11 = n4 - 1; n11 >= 0 && array[n11] == 0; --n11) {
            --n10;
        }
        if (n10 > 19) {
            int n12 = 20;
            n10 = 19;
            if (array[n12] >= 50) {
                --n12;
                final byte[] array5 = array;
                final int n13 = n12;
                ++array5[n13];
                while (array[n12] == 100) {
                    if (n12 == 0) {
                        ++exponent;
                        array[n12] = 1;
                        break;
                    }
                    array[n12] = 0;
                    --n12;
                    final byte[] array6 = array;
                    final int n14 = n12;
                    ++array6[n14];
                }
                for (int n15 = n10 - 1; n15 >= 0 && array[n15] == 0; --n15) {
                    --n10;
                }
            }
        }
        if (exponent > 62) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        final byte[] array7 = new byte[n10 + 1];
        array7[0] = (byte)exponent;
        System.arraycopy(array, 0, array7, 1, n10);
        return _toLnxFmt(array7, b);
    }
    
    public static byte[] toBytes(BigDecimal setScale) throws SQLException {
        final byte[] array = new byte[66];
        final long[] array2 = new long[54];
        final long[] array3 = new long[22];
        final int n = 21;
        final int n2 = 0;
        int n3 = 21;
        int n4 = 0;
        final BigDecimal abs = setScale.abs();
        if (setScale.signum() == 0) {
            return _makeZero();
        }
        final boolean b = setScale.signum() != -1;
        int scale = setScale.scale();
        if (scale < 0) {
            setScale = setScale.setScale(0);
            scale = 0;
        }
        final int compareTo = abs.compareTo(NUMBER.BIGDEC_ONE);
        int n5 = 0;
        int n6;
        if (compareTo == -1) {
            do {
                ++n5;
            } while (abs.movePointRight(n5).compareTo(NUMBER.BIGDEC_ONE) < 0);
            n6 = -n5;
        }
        else {
            do {
                ++n5;
            } while (abs.movePointLeft(n5).compareTo(NUMBER.BIGDEC_ONE) >= 0);
            n6 = n5;
        }
        final byte[] byteArray = abs.movePointRight(scale).toBigInteger().toByteArray();
        if (byteArray.length > 54) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        for (int i = 0; i < byteArray.length; ++i) {
            if (byteArray[i] < 0) {
                array2[i] = byteArray[i] + 256;
            }
            else {
                array2[i] = byteArray[i];
            }
        }
        int j = byteArray.length;
        byte b2 = 0;
        switch (j % 3) {
            case 2: {
                array3[n] = (array2[n2] << 8) + array2[n2 + 1];
                b2 = (byte)(n2 + 2);
                j -= 2;
                break;
            }
            case 1: {
                array3[n] = array2[n2];
                b2 = (byte)(n2 + 1);
                --j;
                break;
            }
            default: {
                final long n7 = (array2[n2] << 16) + (array2[n2 + 1] << 8) + array2[n2 + 2];
                array3[n] = n7 % 1000000L;
                array3[n - 1] = n7 / 1000000L;
                n3 = (byte)(n3 - ((array3[n - 1] != 0L) ? 1 : 0));
                b2 = (byte)(n2 + 3);
                j -= 3;
                break;
            }
        }
        while (j != 0) {
            long n8 = (array2[b2] << 4) + (array2[b2 + 1] >> 4);
            for (int k = 21; k >= n3; k = (byte)(k - 1)) {
                final long n9 = n8 + (array3[k] << 12);
                array3[k] = n9 % 1000000L;
                n8 = n9 / 1000000L;
            }
            if (n8 != 0L) {
                n3 = (byte)(n3 - 1);
                array3[n3] = n8;
            }
            long n10 = ((array2[b2 + 1] & 0xFL) << 8) + array2[b2 + 2];
            for (int l = 21; l >= n3; l = (byte)(l - 1)) {
                final long n11 = n10 + (array3[l] << 12);
                array3[l] = n11 % 1000000L;
                n10 = n11 / 1000000L;
            }
            if (n10 != 0L) {
                n3 = (byte)(n3 - 1);
                array3[n3] = n10;
            }
            b2 += 3;
            j -= 3;
        }
        int n12;
        if ((array[n4] = (byte)(array3[n3] / 10000L)) != 0) {
            n12 = 3 * (21 - n3) + 3;
            array[n4 + 1] = (byte)(array3[n3] % 10000L / 100L);
            array[n4 + 2] = (byte)(array3[n3] % 100L);
            n4 += 3;
        }
        else if ((array[n4] = (byte)(array3[n3] % 10000L / 100L)) != 0) {
            n12 = 3 * (21 - n3) + 2;
            array[n4 + 1] = (byte)(array3[n3] % 100L);
            n4 += 2;
        }
        else {
            array[n4] = (byte)array3[n3];
            n12 = 3 * (21 - n3) + 1;
            ++n4;
        }
        for (byte b3 = (byte)(n3 + 1); b3 <= 21; ++b3) {
            array[n4] = (byte)(array3[b3] / 10000L);
            array[n4 + 1] = (byte)(array3[b3] % 10000L / 100L);
            array[n4 + 2] = (byte)(array3[b3] % 100L);
            n4 += 3;
        }
        for (int n13 = n4 - 1; n13 >= 0 && array[n13] == 0; --n13) {
            --n12;
        }
        if (scale > 0 && (scale & 0x1) != 0x0) {
            final int n14 = n12;
            final byte[] array4 = new byte[n14 + 1];
            if (array[0] <= 9) {
                int n15;
                for (n15 = 0; n15 < n14 - 1; ++n15) {
                    array4[n15] = (byte)(array[n15] % 10 * 10 + array[n15 + 1] / 10);
                }
                array4[n15] = (byte)(array[n15] % 10 * 10);
                if (array4[n14 - 1] == 0) {
                    --n12;
                }
            }
            else {
                array4[n14] = (byte)(array[n14 - 1] % 10 * 10);
                int n16;
                for (n16 = n14 - 1; n16 > 0; --n16) {
                    array4[n16] = (byte)(array[n16] / 10 + array[n16 - 1] % 10 * 10);
                }
                array4[n16] = (byte)(array[n16] / 10);
                if (array4[n14] > 0) {
                    ++n12;
                }
            }
            System.arraycopy(array4, 0, array, 0, n12);
        }
        if (n12 > 20) {
            int n17 = 20;
            n12 = 20;
            if (array[n17] >= 50) {
                --n17;
                final byte[] array5 = array;
                final int n18 = n17;
                ++array5[n18];
                while (array[n17] == 100) {
                    if (n17 == 0) {
                        ++n6;
                        array[n17] = 1;
                        break;
                    }
                    array[n17] = 0;
                    --n17;
                    final byte[] array6 = array;
                    final int n19 = n17;
                    ++array6[n19];
                }
            }
            for (int n20 = n12 - 1; n20 >= 0 && array[n20] == 0; --n20) {
                --n12;
            }
        }
        int n21;
        if (n6 <= 0) {
            if (array[0] < 10) {
                n21 = -(2 - n6) / 2 + 1;
            }
            else {
                n21 = -(2 - n6) / 2;
            }
        }
        else {
            n21 = (n6 - 1) / 2;
        }
        if (n21 > 62) {
            throw new SQLException(CoreException.getMessage((byte)3));
        }
        if (n21 <= -65) {
            throw new SQLException(CoreException.getMessage((byte)2));
        }
        final byte[] array7 = new byte[n12 + 1];
        array7[0] = (byte)n21;
        System.arraycopy(array, 0, array7, 1, n12);
        return _toLnxFmt(array7, b);
    }
    
    public static byte[] toBytes(String s, int i) throws SQLException {
        int offset = 0;
        final byte[] array = new byte[22];
        int n = 0;
        boolean b = true;
        boolean b2 = false;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        final int n6 = 40;
        int offset2 = 0;
        int srcBegin = 0;
        int n7 = 0;
        int endIndex;
        if ((endIndex = s.indexOf("E")) != -1 || (endIndex = s.indexOf("e")) != -1) {
            final StringBuffer sb = new StringBuffer(s.length() + 5);
            final int beginIndex = (s.charAt(0) == '-') ? 1 : 0;
            final String substring = s.substring(endIndex + 1);
            final BigDecimal bigDecimal = new BigDecimal(s.substring(beginIndex, endIndex));
            final boolean b3 = substring.charAt(0) == '-';
            int int1 = Integer.parseInt(substring.substring(1));
            String str = bigDecimal.toString();
            final int index = str.indexOf(".");
            int length;
            int n8 = length = str.length();
            if (index != -1) {
                str = str.substring(0, index) + str.substring(index + 1);
                --n8;
                if (b3) {
                    int1 -= index;
                }
                else {
                    length = ++int1;
                }
            }
            else if (b3) {
                int1 -= n8;
            }
            else {
                length = ++int1;
            }
            if (beginIndex != 0) {
                sb.append("-");
            }
            if (b3) {
                sb.append("0.");
                for (int j = 0; j < int1; ++j) {
                    sb.append("0");
                }
                sb.append(str);
            }
            else {
                for (int n9 = (int1 > n8) ? int1 : n8, k = 0; k < n9; ++k) {
                    if (length == k) {
                        sb.append(".");
                    }
                    sb.append((n8 > k) ? str.charAt(k) : '0');
                }
            }
            s = sb.toString();
        }
        s = s.trim();
        int length2 = s.length();
        if (s.charAt(0) == '-') {
            --length2;
            b = false;
            srcBegin = 1;
        }
        int l = length2;
        final char[] array2 = new char[length2];
        s.getChars(srcBegin, length2 + srcBegin, array2, 0);
        for (int n10 = 0; n10 < length2; ++n10) {
            if (array2[n10] == '.') {
                n2 = 1;
                break;
            }
        }
        if (n2 == 0) {
            i = 0;
        }
        while (offset < l && array2[offset] == '0') {
            ++offset;
            if (n2 != 0) {
                ++n7;
            }
        }
        if (offset == l) {
            return _makeZero();
        }
        if (length2 >= 2 && array2[offset] == '.') {
            while (l > 0 && array2[l - 1] == '0') {
                --l;
            }
            if (++offset == l) {
                return _makeZero();
            }
            --n3;
            while (offset < l - 1 && array2[offset] == '0' && array2[offset + 1] == '0') {
                --n3;
                n5 += 2;
                offset += 2;
            }
            if (n3 < -65) {
                throw new SQLException(CoreException.getMessage((byte)2));
            }
            if (l - offset > n6) {
                int n11 = 2 + n6;
                if (n5 > 0) {
                    n11 += n5;
                }
                if (n11 <= l) {
                    l = n11;
                }
                offset2 = l;
                b2 = true;
            }
            int n12 = l - offset >> 1;
            if ((l - offset) % 2 != 0) {
                array[n12] = (byte)(Integer.parseInt(new String(array2, l - 1, 1)) * 10);
                ++n4;
                --l;
            }
            while (l > offset) {
                --n12;
                array[n12] = (byte)Integer.parseInt(new String(array2, l - 2, 2));
                l -= 2;
                ++n4;
            }
        }
        else {
            while (i > 0 && l > 0 && array2[l - 1] == '0') {
                --l;
                --i;
            }
            if (i == 0 && l > 1) {
                if (array2[l - 1] == '.') {
                    --l;
                }
                if (offset == l) {
                    return _makeZero();
                }
                while (l > 1 && array2[l - 2] == '0' && array2[l - 1] == '0') {
                    l -= 2;
                    ++n3;
                }
            }
            if (n3 > 62) {
                throw new SQLException(CoreException.getMessage((byte)3));
            }
            if (l - offset - n2 > n6) {
                final int n13 = n6 + n2;
                final int n14 = l - n13;
                l = n13;
                i -= n14;
                if (i < 0) {
                    i = 0;
                }
                b2 = true;
                offset2 = l;
            }
            int n15 = (i == 0) ? (l - offset) : (l - i - 1);
            if (n7 > 0) {
                n15 -= n7;
            }
            int n16;
            if (n15 % 2 != 0) {
                n16 = Integer.parseInt(new String(array2, offset, 1));
                ++offset;
                --n15;
                if (l - 1 == n6) {
                    --i;
                    --l;
                    b2 = true;
                    offset2 = l;
                }
            }
            else {
                n16 = Integer.parseInt(new String(array2, offset, 2));
                offset += 2;
                n15 -= 2;
            }
            array[n] = (byte)n16;
            ++n;
            ++n4;
            while (n15 > 0) {
                array[n] = (byte)Integer.parseInt(new String(array2, offset, 2));
                ++n;
                offset += 2;
                ++n3;
                n15 -= 2;
                ++n4;
            }
            if (offset < l) {
                if (i % 2 != 0) {
                    n += i / 2;
                    array[n] = (byte)(Integer.parseInt(new String(array2, l - 1, 1)) * 10);
                    --l;
                    --i;
                }
                else {
                    n += i / 2 - 1;
                    array[n] = (byte)Integer.parseInt(new String(array2, l - 2, 2));
                    l -= 2;
                    i -= 2;
                }
                ++n4;
                --n;
            }
            while (i > 0) {
                array[n] = (byte)Integer.parseInt(new String(array2, l - 2, 2));
                --n;
                l -= 2;
                i -= 2;
                ++n4;
            }
        }
        if (b2) {
            int n17 = n4;
            if (Integer.parseInt(new String(array2, offset2, 1)) >= 5) {
                --n17;
                final byte[] array3 = array;
                final int n18 = n17;
                ++array3[n18];
                while (array[n17] == 100) {
                    if (n17 == 0) {
                        ++n3;
                        array[n17] = 1;
                        break;
                    }
                    array[n17] = 0;
                    --n17;
                    final byte[] array4 = array;
                    final int n19 = n17;
                    ++array4[n19];
                }
                for (int n20 = n4 - 1; n20 >= 0 && array[n20] == 0; --n20) {
                    --n4;
                }
            }
        }
        final byte[] array5 = new byte[n4 + 1];
        array5[0] = (byte)n3;
        System.arraycopy(array, 0, array5, 1, n4);
        return _toLnxFmt(array5, b);
    }
    
    public static byte[] toBytes(final boolean b) {
        if (b) {
            return toBytes(1L);
        }
        return toBytes(0L);
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    @Override
    public double doubleValue() {
        return toDouble(this.shareBytes());
    }
    
    @Override
    public float floatValue() {
        return toFloat(this.shareBytes());
    }
    
    @Override
    public long longValue() throws SQLException {
        return toLong(this.shareBytes());
    }
    
    @Override
    public int intValue() throws SQLException {
        return toInt(this.shareBytes());
    }
    
    public short shortValue() throws SQLException {
        return toShort(this.shareBytes());
    }
    
    @Override
    public byte byteValue() throws SQLException {
        return toByte(this.shareBytes());
    }
    
    public BigInteger bigIntegerValue() throws SQLException {
        return toBigInteger(this.shareBytes());
    }
    
    @Override
    public BigDecimal bigDecimalValue() throws SQLException {
        return toBigDecimal(this.shareBytes());
    }
    
    @Override
    public String stringValue() {
        return toString(this.shareBytes());
    }
    
    @Override
    public boolean booleanValue() {
        return toBoolean(this.shareBytes());
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        try {
            return this.bigDecimalValue();
        }
        catch (SQLException ex) {
            return new SQLException(ex.getMessage());
        }
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new BigDecimal[n];
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.lang.Integer") == 0 || name.compareTo("java.lang.Long") == 0 || name.compareTo("java.lang.Float") == 0 || name.compareTo("java.lang.Double") == 0 || name.compareTo("java.math.BigInteger") == 0 || name.compareTo("java.math.BigDecimal") == 0 || name.compareTo("java.lang.String") == 0 || name.compareTo("java.lang.Boolean") == 0;
    }
    
    public NUMBER abs() throws SQLException {
        return new NUMBER(_getLnxLib().lnxabs(this.shareBytes()));
    }
    
    public NUMBER acos() throws SQLException {
        return new NUMBER(_getLnxLib().lnxacos(this.shareBytes()));
    }
    
    public NUMBER add(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxadd(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER asin() throws SQLException {
        return new NUMBER(_getLnxLib().lnxasin(this.shareBytes()));
    }
    
    public NUMBER atan() throws SQLException {
        return new NUMBER(_getLnxLib().lnxatan(this.shareBytes()));
    }
    
    public NUMBER atan2(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxatan2(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER ceil() throws SQLException {
        return new NUMBER(_getLnxLib().lnxceil(this.shareBytes()));
    }
    
    public NUMBER cos() throws SQLException {
        return new NUMBER(_getLnxLib().lnxcos(this.shareBytes()));
    }
    
    public NUMBER cosh() throws SQLException {
        return new NUMBER(_getLnxLib().lnxcsh(this.shareBytes()));
    }
    
    public NUMBER decrement() throws SQLException {
        return new NUMBER(_getLnxLib().lnxdec(this.shareBytes()));
    }
    
    public NUMBER div(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxdiv(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER exp() throws SQLException {
        return new NUMBER(_getLnxLib().lnxexp(this.shareBytes()));
    }
    
    public NUMBER floatingPointRound(final int n) throws SQLException {
        return new NUMBER(_getLnxLib().lnxfpr(this.shareBytes(), n));
    }
    
    public NUMBER floor() throws SQLException {
        return new NUMBER(_getLnxLib().lnxflo(this.shareBytes()));
    }
    
    public NUMBER increment() throws SQLException {
        return new NUMBER(_getLnxLib().lnxinc(this.shareBytes()));
    }
    
    public NUMBER ln() throws SQLException {
        return new NUMBER(_getLnxLib().lnxln(this.shareBytes()));
    }
    
    public NUMBER log(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxlog(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER mod(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxmod(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER mul(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxmul(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER negate() throws SQLException {
        return new NUMBER(_getLnxLib().lnxneg(this.shareBytes()));
    }
    
    public NUMBER pow(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxbex(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER pow(final int n) throws SQLException {
        return new NUMBER(_getLnxLib().lnxpow(this.shareBytes(), n));
    }
    
    public NUMBER round(final int n) throws SQLException {
        return new NUMBER(_getLnxLib().lnxrou(this.shareBytes(), n));
    }
    
    public NUMBER scale(final int n, final int n2, final boolean[] array) throws SQLException {
        return new NUMBER(_getLnxLib().lnxsca(this.shareBytes(), n, n2, array));
    }
    
    public NUMBER shift(final int n) throws SQLException {
        return new NUMBER(_getLnxLib().lnxshift(this.shareBytes(), n));
    }
    
    public NUMBER sin() throws SQLException {
        return new NUMBER(_getLnxLib().lnxsin(this.shareBytes()));
    }
    
    public NUMBER sinh() throws SQLException {
        return new NUMBER(_getLnxLib().lnxsnh(this.shareBytes()));
    }
    
    public NUMBER sqroot() throws SQLException {
        return new NUMBER(_getLnxLib().lnxsqr(this.shareBytes()));
    }
    
    public NUMBER sub(final NUMBER number) throws SQLException {
        return new NUMBER(_getLnxLib().lnxsub(this.shareBytes(), number.shareBytes()));
    }
    
    public NUMBER tan() throws SQLException {
        return new NUMBER(_getLnxLib().lnxtan(this.shareBytes()));
    }
    
    public NUMBER tanh() throws SQLException {
        return new NUMBER(_getLnxLib().lnxtnh(this.shareBytes()));
    }
    
    public NUMBER truncate(final int n) throws SQLException {
        return new NUMBER(_getLnxLib().lnxtru(this.shareBytes(), n));
    }
    
    public static NUMBER formattedTextToNumber(final String s, final String s2, final String s3) throws SQLException {
        return new NUMBER(_getLnxLib().lnxfcn(s, s2, s3));
    }
    
    public static NUMBER textToPrecisionNumber(final String s, final boolean b, final int n, final boolean b2, final int n2, final String s2) throws SQLException {
        return new NUMBER(_getLnxLib().lnxcpn(s, b, n, b2, n2, s2));
    }
    
    public String toFormattedText(final String s, final String s2) throws SQLException {
        return _getLnxLib().lnxnfn(this.shareBytes(), s, s2);
    }
    
    public String toText(final int n, final String s) throws SQLException {
        return _getLnxLib().lnxnuc(this.shareBytes(), n, s);
    }
    
    public int compareTo(final NUMBER number) {
        return Datum.compareBytes(this.shareBytes(), number.shareBytes());
    }
    
    public boolean isInf() {
        return _isInf(this.shareBytes());
    }
    
    public boolean isNegInf() {
        return _isNegInf(this.shareBytes());
    }
    
    public boolean isPosInf() {
        return _isPosInf(this.shareBytes());
    }
    
    public boolean isInt() {
        return _isInt(this.shareBytes());
    }
    
    public static boolean isValid(final byte[] array) {
        byte b = (byte)array.length;
        if (_isPositive(array)) {
            if (b == 1) {
                return _isZero(array);
            }
            if (array[0] == -1 && array[1] == 101) {
                return b == 2;
            }
            if (b > 21) {
                return false;
            }
            if (array[1] < 2 || array[b - 1] < 2) {
                return false;
            }
            for (byte b2 = 1; b2 < b; ++b2) {
                final byte b3 = array[b2];
                if (b3 < 1 || b3 > 100) {
                    return false;
                }
            }
            return true;
        }
        else {
            if (b < 3) {
                return _isNegInf(array);
            }
            if (b > 21) {
                return false;
            }
            if (array[b - 1] != 102) {
                if (b <= 20) {
                    return false;
                }
            }
            else {
                --b;
            }
            if (array[1] > 100 || array[b - 1] > 100) {
                return false;
            }
            for (byte b4 = 1; b4 < b; ++b4) {
                final byte b5 = array[b4];
                if (b5 < 2 || b5 > 101) {
                    return false;
                }
            }
            return true;
        }
    }
    
    public boolean isZero() {
        return _isZero(this.shareBytes());
    }
    
    public static NUMBER e() {
        return new NUMBER(NUMBER.E);
    }
    
    public static NUMBER ln10() {
        return new NUMBER(NUMBER.LN10);
    }
    
    public static NUMBER negInf() {
        return new NUMBER(_makeNegInf());
    }
    
    public static NUMBER pi() {
        return new NUMBER(NUMBER.PI);
    }
    
    public static NUMBER posInf() {
        return new NUMBER(_makePosInf());
    }
    
    public static NUMBER zero() {
        return new NUMBER(_makeZero());
    }
    
    public int sign() {
        if (_isZero(this.shareBytes())) {
            return 0;
        }
        return _isPositive(this.shareBytes()) ? 1 : -1;
    }
    
    static boolean _isInf(final byte[] array) {
        return (array.length == 2 && array[0] == -1 && array[1] == 101) || (array[0] == 0 && array.length == 1);
    }
    
    private static boolean _isInt(final byte[] array) {
        if (_isZero(array)) {
            return true;
        }
        if (_isInf(array)) {
            return false;
        }
        final byte[] fromLnxFmt = _fromLnxFmt(array);
        return (byte)(fromLnxFmt.length - 1) <= fromLnxFmt[0] + 1;
    }
    
    static boolean _isNegInf(final byte[] array) {
        return array[0] == 0 && array.length == 1;
    }
    
    static boolean _isPosInf(final byte[] array) {
        return array.length == 2 && array[0] == -1 && array[1] == 101;
    }
    
    static boolean _isPositive(final byte[] array) {
        return (array[0] & 0xFFFFFF80) != 0x0;
    }
    
    static boolean _isZero(final byte[] array) {
        return array[0] == -128 && array.length == 1;
    }
    
    static byte[] _makePosInf() {
        return new byte[] { -1, 101 };
    }
    
    static byte[] _makeNegInf() {
        return new byte[] { 0 };
    }
    
    static byte[] _makeZero() {
        return new byte[] { -128 };
    }
    
    static byte[] _fromLnxFmt(final byte[] array) {
        final int length = array.length;
        byte[] array2;
        if (_isPositive(array)) {
            array2 = new byte[length];
            array2[0] = (byte)((array[0] & 0xFFFFFF7F) - 65);
            for (int i = 1; i < length; ++i) {
                array2[i] = (byte)(array[i] - 1);
            }
        }
        else {
            if (length - 1 == 20 && array[length - 1] != 102) {
                array2 = new byte[length];
            }
            else {
                array2 = new byte[length - 1];
            }
            array2[0] = (byte)((~array[0] & 0xFFFFFF7F) - 65);
            for (int j = 1; j < array2.length; ++j) {
                array2[j] = (byte)(101 - array[j]);
            }
        }
        return array2;
    }
    
    static byte[] _toLnxFmt(final byte[] array, final boolean b) {
        final int length = array.length;
        byte[] array2;
        if (b) {
            array2 = new byte[length];
            array2[0] = (byte)(array[0] + 128 + 64 + 1);
            for (int i = 1; i < length; ++i) {
                array2[i] = (byte)(array[i] + 1);
            }
        }
        else {
            if (length - 1 < 20) {
                array2 = new byte[length + 1];
            }
            else {
                array2 = new byte[length];
            }
            array2[0] = (byte)~(array[0] + 128 + 64 + 1);
            int j;
            for (j = 1; j < length; ++j) {
                array2[j] = (byte)(101 - array[j]);
            }
            if (j <= 20) {
                array2[j] = 102;
            }
        }
        return array2;
    }
    
    private static LnxLib _getLnxLib() {
        if (NUMBER._slnxlib == null) {
            try {
                if (System.getProperty("oracle.jserver.version") != null) {
                    NUMBER._slnxlib = new LnxLibServer();
                }
                else {
                    NUMBER._slnxlib = new LnxLibThin();
                }
            }
            catch (SecurityException ex) {
                NUMBER._slnxlib = new LnxLibThin();
            }
        }
        return NUMBER._slnxlib;
    }
    
    private static LnxLib _getThinLib() {
        if (NUMBER._thinlib == null) {
            NUMBER._thinlib = new LnxLibThin();
        }
        return NUMBER._thinlib;
    }
    
    private static int _byteToChars(final byte b, final char[] array, final int n) {
        if (b < 0) {
            return 0;
        }
        if (b < 10) {
            array[n] = (char)(48 + b);
            return 1;
        }
        if (b < 100) {
            array[n] = (char)(48 + b / 10);
            array[n + 1] = (char)(48 + b % 10);
            return 2;
        }
        array[n] = '1';
        array[n + 1] = (char)(48 + b / 10 - 10);
        array[n + 2] = (char)(48 + b % 10);
        return 3;
    }
    
    private static void _byteTo2Chars(final byte b, final char[] array, final int n) {
        if (b < 0) {
            array[n + 1] = (array[n] = '0');
        }
        else if (b < 10) {
            array[n] = '0';
            array[n + 1] = (char)(48 + b);
        }
        else if (b < 100) {
            array[n] = (char)(48 + b / 10);
            array[n + 1] = (char)(48 + b % 10);
        }
        else {
            array[n + 1] = (array[n] = '0');
        }
    }
    
    private static void _printBytes(final byte[] array) {
        final int length = array.length;
        System.out.print(length + ": ");
        for (int i = 0; i < length; ++i) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
    
    private byte[] stringToBytes(String trim) throws SQLException {
        int n = 0;
        trim = trim.trim();
        if (trim.indexOf(46) >= 0) {
            n = trim.length() - 1 - trim.indexOf(46);
        }
        return toBytes(trim, n);
    }
    
    static {
        NUMBER.MAX_LONG = toBytes(Long.MAX_VALUE);
        NUMBER.MIN_LONG = toBytes(Long.MIN_VALUE);
        BIGDEC_NEGZERO = new BigDecimal("-0");
        BIGDEC_ZERO = BigDecimal.valueOf(0L);
        BIGDEC_ONE = BigDecimal.valueOf(1L);
        BIGINT_ZERO = BigInteger.valueOf(0L);
        BIGINT_HUND = BigInteger.valueOf(100L);
        PI = new byte[] { -63, 4, 15, 16, 93, 66, 36, 90, 80, 33, 39, 47, 27, 44, 39, 33, 80, 51, 29, 85, 21 };
        E = new byte[] { -63, 3, 72, 83, 82, 83, 85, 60, 5, 53, 36, 37, 3, 88, 48, 14, 53, 67, 25, 98, 77 };
        LN10 = new byte[] { -63, 3, 31, 26, 86, 10, 30, 95, 5, 57, 85, 2, 80, 92, 46, 47, 85, 37, 43, 8, 61 };
        NUMBER._thinlib = null;
        NUMBER.DBL_MAX = 40;
        NUMBER.INT_MAX = 15;
        NUMBER.FLOAT_MAX_INT = 2.14748365E9f;
        NUMBER.FLOAT_MIN_INT = -2.14748365E9f;
        NUMBER.DOUBLE_MAX_INT = 2.147483647E9;
        NUMBER.DOUBLE_MIN_INT = -2.147483648E9;
        NUMBER.DOUBLE_MAX_INT_2 = 2.147483649E9;
        NUMBER.DOUBLE_MIN_INT_2 = -2.147483649E9;
        NUMBER.drvType = null;
        try {
            NUMBER.drvType = System.getProperty("oracle.jserver.version");
        }
        catch (SecurityException ex) {
            NUMBER.drvType = null;
        }
        NUMBER.LANGID = "AMERICAN";
    }
}
