// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

interface LdxLib
{
    byte[] ldxadm(final byte[] p0, final int p1) throws SQLException;
    
    byte[] ldxads(final byte[] p0, final int p1, final int p2) throws SQLException;
    
    int ldxchk(final byte[] p0) throws SQLException;
    
    byte[] ldxdfd(final int p0, final int p1) throws SQLException;
    
    void ldxdtd(final byte[] p0, final int[] p1, final int[] p2) throws SQLException;
    
    String ldxdts(final byte[] p0, final String p1, final String p2) throws SQLException;
    
    String ldxdts(final byte[] p0, final byte[] p1, final String p2) throws SQLException;
    
    byte[] ldxsto(final String p0, final String p1) throws SQLException;
    
    byte[] ldxdyf(final byte[] p0) throws SQLException;
    
    void ldxftd(final byte[] p0, final int[] p1, final int[] p2) throws SQLException;
    
    byte[] ldxgdt() throws SQLException;
    
    byte[] ldxldd(final byte[] p0) throws SQLException;
    
    byte[] ldxnxd(final byte[] p0, final int p1) throws SQLException;
    
    byte[] ldxrnd(final byte[] p0, final String p1) throws SQLException;
    
    byte[] ldxsbm(final byte[] p0, final byte[] p1) throws SQLException;
    
    void ldxsub(final byte[] p0, final byte[] p1, final int[] p2, final int[] p3) throws SQLException;
    
    byte[] ldxstd(final String p0, final String p1, final String p2) throws SQLException;
    
    byte[] ldxtrn(final byte[] p0, final String p1) throws SQLException;
}
