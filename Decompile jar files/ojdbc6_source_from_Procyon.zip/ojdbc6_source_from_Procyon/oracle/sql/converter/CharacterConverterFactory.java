// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

public abstract class CharacterConverterFactory
{
    public abstract JdbcCharacterConverters make(final int p0);
}
