// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import java.util.Hashtable;
import oracle.sql.ConverterArchive;
import java.util.HashMap;
import java.io.Serializable;

public abstract class CharacterConverterJDBC implements JdbcCharacterConverters, Serializable
{
    static final long serialVersionUID = 5948085171100875165L;
    static final String CONVERTERNAMEPREFIX = "converter_xcharset/lx2";
    static final String CONVERTERIDPREFIX = "0000";
    static final int HIBYTEMASK = 65280;
    static final int LOWBYTEMASK = 255;
    static final int STORE_INCREMENT = 10;
    static final int INVALID_ORA_CHAR = -1;
    static final int FIRSTBSHIFT = 24;
    static final int SECONDBSHIFT = 16;
    static final int THIRDBSHIFT = 8;
    static final int UB2MASK = 65535;
    static final int UB4MASK = 65535;
    static final HashMap m_converterStore;
    public int m_groupId;
    public int m_oracleId;
    public int[][] extraUnicodeToOracleMapping;
    
    public CharacterConverterJDBC() {
        this.extraUnicodeToOracleMapping = null;
    }
    
    @Override
    public int getGroupId() {
        return this.m_groupId;
    }
    
    @Override
    public int getOracleId() {
        return this.m_oracleId;
    }
    
    @Override
    public char[] getLeadingCodes() {
        return null;
    }
    
    public static JdbcCharacterConverters getInstance(final int i) {
        final String hexString = Integer.toHexString(i);
        synchronized (CharacterConverterJDBC.m_converterStore) {
            final CharacterConverterJDBC characterConverterJDBC = CharacterConverterJDBC.m_converterStore.get(hexString);
            if (characterConverterJDBC != null) {
                return characterConverterJDBC;
            }
            final CharacterConverterJDBC value = (CharacterConverterJDBC)new ConverterArchive().readObj("converter_xcharset/lx2" + "0000".substring(0, 4 - hexString.length()) + hexString + ".glb");
            if (value == null) {
                return null;
            }
            value.buildUnicodeToOracleMapping();
            CharacterConverterJDBC.m_converterStore.put(hexString, value);
            return value;
        }
    }
    
    protected void storeMappingRange(final int n, final Hashtable hashtable, final Hashtable hashtable2) {
        final int i = n >> 24 & 0xFF;
        final int n2 = n >> 16 & 0xFF;
        final int n3 = n >> 8 & 0xFF;
        final int n4 = n & 0xFF;
        final Integer value = i;
        final Integer value2 = n >> 16 & 0xFFFF;
        final Integer value3 = n >> 8 & 0xFFFFFF;
        if (n >>> 26 == 54) {
            char[] value4 = hashtable.get(value);
            if (value4 == null) {
                value4 = new char[] { '\u00ff', '\0' };
            }
            if (value4[0] == '\u00ff' && value4[1] == '\0') {
                value4[0] = (char)n2;
                value4[1] = (char)n2;
            }
            else {
                if (n2 < (value4[0] & '\uffff')) {
                    value4[0] = (char)n2;
                }
                if (n2 > (value4[0] & '\uffff')) {
                    value4[1] = (char)n2;
                }
            }
            hashtable.put(value, value4);
            char[] value5 = hashtable.get(value2);
            if (value5 == null) {
                value5 = new char[] { '\u00ff', '\0' };
            }
            if (value5[0] == '\u00ff' && value5[1] == '\0') {
                value5[0] = (char)n3;
                value5[1] = (char)n3;
            }
            else {
                if (n3 < (value5[0] & '\uffff')) {
                    value5[0] = (char)n3;
                }
                if (n3 > (value5[0] & '\uffff')) {
                    value5[1] = (char)n3;
                }
            }
            hashtable.put(value2, value5);
        }
        char[] value6 = hashtable2.get(value3);
        if (value6 == null) {
            value6 = new char[] { '\u00ff', '\0' };
        }
        if (value6[0] == '\u00ff' && value6[1] == '\0') {
            value6[0] = (char)n4;
            value6[1] = (char)n4;
        }
        else {
            if (n4 < (value6[0] & '\uffff')) {
                value6[0] = (char)n4;
            }
            if (n4 > (value6[0] & '\uffff')) {
                value6[1] = (char)n4;
            }
        }
        hashtable2.put(value3, value6);
    }
    
    static {
        m_converterStore = new HashMap();
    }
}
