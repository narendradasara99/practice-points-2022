// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import java.util.Vector;
import java.sql.SQLException;

public interface JdbcCharacterConverters
{
    public static final int CHARCONV1BYTEID = 0;
    public static final int CHARCONV12BYTEID = 1;
    public static final int CHARCONVJAEUCID = 2;
    public static final int CHARCONVLCFIXEDID = 3;
    public static final int CHARCONVSJISID = 4;
    public static final int CHARCONVZHTEUCID = 5;
    public static final int CHARCONV2BYTEFIXEDID = 6;
    public static final int CHARCONVSHIFTID = 7;
    public static final int CHARCONVLCID = 8;
    public static final int CHARCONVGB18030ID = 9;
    public static final int CHARCONVAL16UTF16ID = 10;
    public static final int CHARCONVMSOLISO2022JPFWID = 11;
    public static final int CHARCONVMSOLISO2022JPHWID = 12;
    public static final int CHARCONVGBKID = 13;
    
    int getGroupId();
    
    int getOracleId();
    
    String toUnicodeString(final byte[] p0, final int p1, final int p2) throws SQLException;
    
    String toUnicodeStringWithReplacement(final byte[] p0, final int p1, final int p2);
    
    int toUnicodeChars(final byte[] p0, final int p1, final char[] p2, final int p3, final int p4) throws SQLException;
    
    byte[] toOracleString(final String p0) throws SQLException;
    
    byte[] toOracleStringWithReplacement(final String p0);
    
    void buildUnicodeToOracleMapping();
    
    void extractCodepoints(final Vector p0);
    
    void extractExtraMappings(final Vector p0);
    
    boolean hasExtraMappings();
    
    char getOraChar1ByteRep();
    
    char getOraChar2ByteRep();
    
    int getUCS2CharRep();
    
    char[] getLeadingCodes();
}
