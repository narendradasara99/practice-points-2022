// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import oracle.i18n.text.OraBoot;

class Orai18nCharacterSetMetaData implements InternalCharacterSetMetaData
{
    OraBoot oraBoot;
    
    Orai18nCharacterSetMetaData() {
        this.oraBoot = OraBoot.getInstance();
    }
    
    @Override
    public boolean isFixedWidth(final int i) {
        return this.oraBoot.getCharSetIsFixed().contains(this.oraBoot.getCharSetName("" + i));
    }
    
    @Override
    public int getMaxCharLength(final int i) {
        final String charsetMaxCharLen = this.oraBoot.getCharsetMaxCharLen("" + i);
        return (charsetMaxCharLen != null) ? (Integer.parseInt(charsetMaxCharLen) & 0xFF) : 0;
    }
}
