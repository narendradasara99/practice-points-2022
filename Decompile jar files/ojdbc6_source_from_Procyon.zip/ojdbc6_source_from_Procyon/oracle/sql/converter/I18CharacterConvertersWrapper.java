// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import oracle.jdbc.internal.OracleConnection;
import java.util.Vector;
import java.sql.SQLException;
import oracle.i18n.text.converter.CharacterConverter;

public class I18CharacterConvertersWrapper implements JdbcCharacterConverters
{
    CharacterConverter wrapper;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public I18CharacterConvertersWrapper(final CharacterConverter wrapper) {
        this.wrapper = wrapper;
    }
    
    @Override
    public int getGroupId() {
        return this.wrapper.getGroupId();
    }
    
    @Override
    public int getOracleId() {
        return this.wrapper.getOracleId();
    }
    
    @Override
    public char[] getLeadingCodes() {
        return this.wrapper.getLeadingCodes();
    }
    
    @Override
    public String toUnicodeString(final byte[] array, final int n, final int n2) throws SQLException {
        return this.wrapper.toUnicodeString(array, n, n2);
    }
    
    @Override
    public String toUnicodeStringWithReplacement(final byte[] array, final int n, final int n2) {
        return this.wrapper.toUnicodeStringWithReplacement(array, n, n2);
    }
    
    @Override
    public byte[] toOracleString(final String s) throws SQLException {
        return this.wrapper.toOracleString(s);
    }
    
    @Override
    public byte[] toOracleStringWithReplacement(final String s) {
        return this.wrapper.toOracleStringWithReplacement(s);
    }
    
    @Override
    public void buildUnicodeToOracleMapping() {
        this.wrapper.buildUnicodeToOracleMapping();
    }
    
    @Override
    public void extractCodepoints(final Vector vector) {
        this.wrapper.extractCodepoints(vector);
    }
    
    @Override
    public void extractExtraMappings(final Vector vector) {
        this.wrapper.extractExtraMappings(vector);
    }
    
    @Override
    public boolean hasExtraMappings() {
        return this.wrapper.hasExtraMappings();
    }
    
    @Override
    public char getOraChar1ByteRep() {
        return this.wrapper.getOraChar1ByteRep();
    }
    
    @Override
    public char getOraChar2ByteRep() {
        return this.wrapper.getOraChar2ByteRep();
    }
    
    @Override
    public int getUCS2CharRep() {
        return this.wrapper.getUCS2CharRep();
    }
    
    @Override
    public int toUnicodeChars(final byte[] array, final int n, final char[] array2, final int n2, final int n3) throws SQLException {
        return this.wrapper.toUnicodeCharsWithReplacement(array, n, array2, n2, n3);
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
