// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

interface InternalCharacterSetMetaData
{
    boolean isFixedWidth(final int p0);
    
    int getMaxCharLength(final int p0);
}
