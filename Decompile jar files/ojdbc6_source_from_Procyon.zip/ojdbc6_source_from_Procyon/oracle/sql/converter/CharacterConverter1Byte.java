// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import oracle.jdbc.internal.OracleConnection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;

public class CharacterConverter1Byte extends CharacterConverterJDBC
{
    static final long serialVersionUID = 200017349723606452L;
    static final int ORACHARMASK = 255;
    static final int UCSCHARWIDTH = 16;
    public int m_ucsReplacement;
    public int[] m_ucsChar;
    public char[] m_oraCharLevel1;
    public char[] m_oraCharSurrogateLevel;
    public char[] m_oraCharLevel2;
    public byte m_oraCharReplacement;
    protected transient boolean noSurrogate;
    protected transient boolean strictASCII;
    protected transient int m_oraCharLevel2Size;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public CharacterConverter1Byte() {
        this.m_ucsReplacement = 0;
        this.m_ucsChar = null;
        this.m_oraCharLevel1 = null;
        this.m_oraCharSurrogateLevel = null;
        this.m_oraCharLevel2 = null;
        this.m_oraCharReplacement = 0;
        this.noSurrogate = true;
        this.strictASCII = true;
        this.m_oraCharLevel2Size = 0;
        this.m_groupId = 0;
    }
    
    int toUnicode(final byte b) throws SQLException {
        final int n = this.m_ucsChar[b & 0xFF];
        if (n == -1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 154);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return n;
    }
    
    int toUnicodeWithReplacement(final byte b) {
        final int n = this.m_ucsChar[b & 0xFF];
        if (n == -1) {
            return this.m_ucsReplacement;
        }
        return n;
    }
    
    byte toOracleCharacter(final char c, final char c2) throws SQLException {
        final int n = c >>> 8 & 0xFF;
        final int n2 = c & '\u00ff';
        final int n3 = c2 >>> 8 & 0xFF;
        final int n4 = c2 & '\u00ff';
        if (this.m_oraCharLevel1[n] != (char)this.m_oraCharLevel2Size && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] != '\uffff' && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] + n3] != '\uffff' && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] + n3] + n4] != '\uffff') {
            return (byte)this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] + n3] + n4];
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 155);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    byte toOracleCharacter(final char c) throws SQLException {
        final char c2;
        if ((c2 = this.m_oraCharLevel2[this.m_oraCharLevel1[c >>> 8] + (c & '\u00ff')]) != '\uffff') {
            return (byte)c2;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 155);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    byte toOracleCharacterWithReplacement(final char c, final char c2) {
        final int n = c >>> 8 & 0xFF;
        final int n2 = c & '\u00ff';
        final int n3 = c2 >>> 8 & 0xFF;
        final int n4 = c2 & '\u00ff';
        if (this.m_oraCharLevel1[n] != (char)this.m_oraCharLevel2Size && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] != '\uffff' && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] + n3] != '\uffff' && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] + n3] + n4] != '\uffff') {
            return (byte)this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n] + n2] + n3] + n4];
        }
        return this.m_oraCharReplacement;
    }
    
    byte toOracleCharacterWithReplacement(final char c) {
        final char c2;
        if ((c2 = this.m_oraCharLevel2[this.m_oraCharLevel1[c >>> 8] + (c & '\u00ff')]) != '\uffff') {
            return (byte)c2;
        }
        return this.m_oraCharReplacement;
    }
    
    @Override
    public int toUnicodeChars(final byte[] array, final int n, final char[] array2, final int n2, final int n3) throws SQLException {
        int n4;
        int n5;
        int n6;
        for (n4 = n + n3, n5 = n2, n6 = n; n6 < n4 && n5 < array2.length; ++n6) {
            final int n7 = this.m_ucsChar[array[n6] & 0xFF];
            if (n7 == this.m_ucsReplacement) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 154);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (((long)n7 & 0xFFFFFFFFL) > 65535L) {
                if (n5 + 2 < array2.length) {
                    --n6;
                    break;
                }
                array2[n5++] = (char)(n7 >>> 16);
                array2[n5++] = (char)(n7 & 0xFFFF);
            }
            else {
                array2[n5++] = (char)n7;
            }
        }
        return n6;
    }
    
    @Override
    public String toUnicodeString(final byte[] array, final int n, final int capacity) throws SQLException {
        final int n2 = n + capacity;
        final StringBuilder sb = new StringBuilder(capacity);
        for (int i = n; i < n2; ++i) {
            final int n3 = this.m_ucsChar[array[i] & 0xFF];
            if (n3 == this.m_ucsReplacement) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 154);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (((long)n3 & 0xFFFFFFFFL) > 65535L) {
                sb.append((char)(n3 >>> 16));
                sb.append((char)(n3 & 0xFFFF));
            }
            else {
                sb.append((char)n3);
            }
        }
        return sb.substring(0, sb.length());
    }
    
    @Override
    public String toUnicodeStringWithReplacement(final byte[] array, final int n, final int capacity) {
        final int n2 = n + capacity;
        final StringBuilder sb = new StringBuilder(capacity);
        for (int i = n; i < n2; ++i) {
            final int n3 = this.m_ucsChar[array[i] & 0xFF];
            if (n3 == -1) {
                sb.append((char)this.m_ucsReplacement);
            }
            else {
                sb.append((char)n3);
            }
        }
        return sb.substring(0, sb.length());
    }
    
    @Override
    public byte[] toOracleString(final String s) throws SQLException {
        final int length = s.length();
        if (length == 0) {
            return new byte[0];
        }
        final char[] dst = new char[length];
        s.getChars(0, length, dst, 0);
        final byte[] array = new byte[length * 4];
        int n = 0;
        for (int i = 0; i < length; ++i) {
            if (dst[i] >= '\ud800' && dst[i] < '\udc00') {
                if (i + 1 >= length || dst[i + 1] < '\udc00' || dst[i + 1] > '\udfff') {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 155);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                if (this.noSurrogate) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 155);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                array[n++] = this.toOracleCharacter(dst[i], dst[i + 1]);
                ++i;
            }
            else if (dst[i] < '\u0080' && this.strictASCII) {
                array[n++] = (byte)dst[i];
            }
            else {
                array[n++] = this.toOracleCharacter(dst[i]);
            }
        }
        if (n < array.length) {
            final byte[] array2 = new byte[n];
            System.arraycopy(array, 0, array2, 0, n);
            return array2;
        }
        return array;
    }
    
    @Override
    public byte[] toOracleStringWithReplacement(final String s) {
        final int length = s.length();
        if (length == 0) {
            return new byte[0];
        }
        final char[] dst = new char[length];
        s.getChars(0, length, dst, 0);
        final byte[] array = new byte[length * 4];
        int n = 0;
        for (int i = 0; i < length; ++i) {
            if (dst[i] >= '\ud800' && dst[i] < '\udc00') {
                if (i + 1 < length && dst[i + 1] >= '\udc00' && dst[i + 1] <= '\udfff') {
                    if (this.noSurrogate) {
                        array[n++] = this.m_oraCharReplacement;
                    }
                    else {
                        array[n++] = this.toOracleCharacterWithReplacement(dst[i], dst[i + 1]);
                    }
                    ++i;
                }
                else {
                    array[n++] = this.m_oraCharReplacement;
                }
            }
            else if (dst[i] < '\u0080' && this.strictASCII) {
                array[n++] = (byte)dst[i];
            }
            else {
                array[n++] = this.toOracleCharacterWithReplacement(dst[i]);
            }
        }
        if (n < array.length) {
            final byte[] array2 = new byte[n];
            System.arraycopy(array, 0, array2, 0, n);
            return array2;
        }
        return array;
    }
    
    @Override
    public void buildUnicodeToOracleMapping() {
        this.m_oraCharLevel1 = new char[256];
        this.m_oraCharSurrogateLevel = null;
        this.m_oraCharLevel2 = null;
        final Vector<int[]> vector = new Vector<int[]>(45055, 12287);
        final Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>();
        final Hashtable<Object, Object> hashtable2 = new Hashtable<Object, Object>();
        final int length = this.m_ucsChar.length;
        char c = '\0';
        char c2 = '\0';
        for (int i = 0; i < 256; ++i) {
            this.m_oraCharLevel1[i] = '\uffff';
        }
        for (int j = 0; j < length; ++j) {
            final int n = this.m_ucsChar[j];
            if (n != -1) {
                vector.addElement(new int[] { n, j });
                this.storeMappingRange(n, hashtable, hashtable2);
            }
        }
        if (this.extraUnicodeToOracleMapping != null) {
            for (int length2 = this.extraUnicodeToOracleMapping.length, k = 0; k < length2; ++k) {
                this.storeMappingRange(this.extraUnicodeToOracleMapping[k][0], hashtable, hashtable2);
            }
        }
        final Enumeration<Object> keys = hashtable.keys();
        int n2 = 0;
        int oraCharLevel2Size = 0;
        while (keys.hasMoreElements()) {
            if (hashtable.get(keys.nextElement()) != null) {
                n2 += 256;
            }
        }
        final Enumeration<Object> keys2 = hashtable2.keys();
        while (keys2.hasMoreElements()) {
            if (hashtable2.get(keys2.nextElement()) != null) {
                oraCharLevel2Size += 256;
            }
        }
        if (n2 != 0) {
            this.m_oraCharSurrogateLevel = new char[n2];
        }
        if (oraCharLevel2Size != 0) {
            this.m_oraCharLevel2 = new char[oraCharLevel2Size + 256];
        }
        for (int l = 0; l < n2; ++l) {
            this.m_oraCharSurrogateLevel[l] = '\uffff';
        }
        for (int n3 = 0; n3 < oraCharLevel2Size + 256; ++n3) {
            this.m_oraCharLevel2[n3] = '\uffff';
        }
        for (int index = 0; index < vector.size(); ++index) {
            final int[] array = vector.elementAt(index);
            final int n4 = array[0] >> 24 & 0xFF;
            final int n5 = array[0] >> 16 & 0xFF;
            final int n6 = array[0] >> 8 & 0xFF;
            final int n7 = array[0] & 0xFF;
            if (n4 >= 216 && n4 < 220) {
                if (this.m_oraCharLevel1[n4] == '\uffff') {
                    this.m_oraCharLevel1[n4] = c2;
                    c2 += '\u0100';
                }
                if (this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n4] + n5] == '\uffff') {
                    this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n4] + n5] = c2;
                    c2 += '\u0100';
                }
                if (this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n4] + n5] + n6] == '\uffff') {
                    this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n4] + n5] + n6] = c;
                    c += '\u0100';
                }
                if (this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n4] + n5] + n6] + n7] == '\uffff') {
                    this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n4] + n5] + n6] + n7] = (char)(array[1] & 0xFFFF);
                }
            }
            else {
                if (this.m_oraCharLevel1[n6] == '\uffff') {
                    this.m_oraCharLevel1[n6] = c;
                    c += '\u0100';
                }
                if (this.m_oraCharLevel2[this.m_oraCharLevel1[n6] + n7] == '\uffff') {
                    this.m_oraCharLevel2[this.m_oraCharLevel1[n6] + n7] = (char)(array[1] & 0xFFFF);
                }
            }
        }
        if (this.extraUnicodeToOracleMapping != null) {
            for (int length3 = this.extraUnicodeToOracleMapping.length, n8 = 0; n8 < length3; ++n8) {
                final int n9 = this.extraUnicodeToOracleMapping[n8][0];
                final int n10 = n9 >>> 24 & 0xFF;
                final int n11 = n9 >>> 16 & 0xFF;
                final int n12 = n9 >>> 8 & 0xFF;
                final int n13 = n9 & 0xFF;
                if (n10 >= 216 && n10 < 220) {
                    if (this.m_oraCharLevel1[n10] == '\uffff') {
                        this.m_oraCharLevel1[n10] = c2;
                        c2 += '\u0100';
                    }
                    if (this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n10] + n11] == '\uffff') {
                        this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n10] + n11] = c2;
                        c2 += '\u0100';
                    }
                    if (this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n10] + n11] + n12] == '\uffff') {
                        this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n10] + n11] + n12] = c;
                        c += '\u0100';
                    }
                    this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[n10] + n11] + n12] + n13] = (char)(this.extraUnicodeToOracleMapping[n8][1] & 0xFF);
                }
                else {
                    if (this.m_oraCharLevel1[n12] == '\uffff') {
                        this.m_oraCharLevel1[n12] = c;
                        c += '\u0100';
                    }
                    this.m_oraCharLevel2[this.m_oraCharLevel1[n12] + n13] = (char)(this.extraUnicodeToOracleMapping[n8][1] & 0xFFFF);
                }
            }
        }
        if (this.m_oraCharSurrogateLevel == null) {
            this.noSurrogate = true;
        }
        else {
            this.noSurrogate = false;
        }
        this.strictASCII = true;
        for (char c3 = '\0'; c3 < '\u0080'; ++c3) {
            if (this.m_oraCharLevel2[c3] != c3) {
                this.strictASCII = false;
                break;
            }
        }
        for (int n14 = 0; n14 < 256; ++n14) {
            if (this.m_oraCharLevel1[n14] == '\uffff') {
                this.m_oraCharLevel1[n14] = (char)oraCharLevel2Size;
            }
        }
        this.m_oraCharLevel2Size = oraCharLevel2Size;
    }
    
    @Override
    public void extractCodepoints(final Vector vector) {
        final int n = 0;
        for (int n2 = 255, i = n; i <= n2; ++i) {
            try {
                vector.addElement(new int[] { i, this.toUnicode((byte)i) });
            }
            catch (SQLException ex) {}
        }
    }
    
    @Override
    public void extractExtraMappings(final Vector vector) {
        if (this.extraUnicodeToOracleMapping == null) {
            return;
        }
        for (int i = 0; i < this.extraUnicodeToOracleMapping.length; ++i) {
            vector.addElement(new int[] { this.extraUnicodeToOracleMapping[i][0], this.extraUnicodeToOracleMapping[i][1] });
        }
    }
    
    @Override
    public boolean hasExtraMappings() {
        return this.extraUnicodeToOracleMapping != null;
    }
    
    @Override
    public char getOraChar1ByteRep() {
        return (char)this.m_oraCharReplacement;
    }
    
    @Override
    public char getOraChar2ByteRep() {
        return '\0';
    }
    
    @Override
    public int getUCS2CharRep() {
        return this.m_ucsReplacement;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
