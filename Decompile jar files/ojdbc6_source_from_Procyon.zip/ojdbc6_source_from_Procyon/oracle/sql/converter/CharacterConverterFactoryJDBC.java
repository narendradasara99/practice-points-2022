// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

public class CharacterConverterFactoryJDBC extends CharacterConverterFactory
{
    @Override
    public JdbcCharacterConverters make(final int n) {
        return CharacterConverterJDBC.getInstance(n);
    }
}
