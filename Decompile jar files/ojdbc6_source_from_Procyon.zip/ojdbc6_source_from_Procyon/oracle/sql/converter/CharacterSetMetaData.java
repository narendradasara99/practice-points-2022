// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import java.sql.SQLException;
import java.util.Locale;
import java.util.StringTokenizer;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.HashMap;

public class CharacterSetMetaData
{
    static final short WIDTH_SIZE = 8;
    static final short WIDTH_MASK = 255;
    static final short FLAG_FIXEDWIDTH = 256;
    public static final int ST_BADCODESET = 0;
    private static final HashMap language;
    private static final HashMap territory;
    static InternalCharacterSetMetaData metaDataImpl;
    private static final short[][] m_maxCharWidth;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    private static final void getMapProperties() {
        try {
            final String[] array = { "oracle.jdbc.languageMap", "oracle.jdbc.territoryMap" };
            final HashMap[] array2 = { CharacterSetMetaData.language, CharacterSetMetaData.territory };
            for (int i = 0; i < array.length; ++i) {
                final String str = AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction<String>() {
                    final /* synthetic */ String val$fstr = array[i];
                    
                    @Override
                    public String run() {
                        return System.getProperty(this.val$fstr, null);
                    }
                });
                if (str != null) {
                    final StringTokenizer stringTokenizer = new StringTokenizer(str, "=;");
                    if (stringTokenizer.countTokens() % 2 == 0) {
                        while (stringTokenizer.hasMoreTokens()) {
                            array2[i].put(stringTokenizer.nextToken(), stringTokenizer.nextToken());
                        }
                    }
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public static String getNLSLanguage(final Locale locale) {
        String s = CharacterSetMetaData.language.get(locale.getLanguage() + "_" + locale.getCountry());
        if (s == null) {
            s = CharacterSetMetaData.language.get(locale.getLanguage());
        }
        return s;
    }
    
    public static String getNLSTerritory(final Locale locale) {
        String s = CharacterSetMetaData.territory.get(locale.getLanguage() + "_" + locale.getCountry());
        if (s == null) {
            s = CharacterSetMetaData.territory.get(locale.getCountry());
            if (s == null) {
                s = CharacterSetMetaData.territory.get(locale.getLanguage());
            }
        }
        return s;
    }
    
    public static boolean isFixedWidth(final int n) throws SQLException {
        return CharacterSetMetaData.metaDataImpl.isFixedWidth(n);
    }
    
    public static int getRatio(final int n, final int n2) {
        if (n2 == n) {
            return 1;
        }
        final int maxCharLength = CharacterSetMetaData.metaDataImpl.getMaxCharLength(n);
        if (maxCharLength == 0) {
            return 0;
        }
        if (maxCharLength == 1) {
            return 1;
        }
        if (n2 == 1) {
            return maxCharLength;
        }
        if (CharacterSetMetaData.metaDataImpl.isFixedWidth(n2)) {
            return maxCharLength;
        }
        final int maxCharLength2 = CharacterSetMetaData.metaDataImpl.getMaxCharLength(n2);
        if (maxCharLength2 == 0) {
            return 0;
        }
        int n3 = maxCharLength / maxCharLength2;
        if (maxCharLength % maxCharLength2 != 0) {
            ++n3;
        }
        return n3;
    }
    
    static {
        language = new HashMap(58, 1.0f);
        territory = new HashMap(134, 1.0f);
        CharacterSetMetaData.language.put("", "AMERICAN");
        CharacterSetMetaData.language.put("ar_EG", "EGYPTIAN");
        CharacterSetMetaData.language.put("ar", "ARABIC");
        CharacterSetMetaData.language.put("as", "ASSAMESE");
        CharacterSetMetaData.language.put("bg", "BULGARIAN");
        CharacterSetMetaData.language.put("bn", "BANGLA");
        CharacterSetMetaData.language.put("ca", "CATALAN");
        CharacterSetMetaData.language.put("cs", "CZECH");
        CharacterSetMetaData.language.put("da", "DANISH");
        CharacterSetMetaData.language.put("de", "GERMAN");
        CharacterSetMetaData.language.put("el", "GREEK");
        CharacterSetMetaData.language.put("en", "AMERICAN");
        CharacterSetMetaData.language.put("es_ES", "SPANISH");
        CharacterSetMetaData.language.put("es_MX", "MEXICAN SPANISH");
        CharacterSetMetaData.language.put("es", "LATIN AMERICAN SPANISH");
        CharacterSetMetaData.language.put("et", "ESTONIAN");
        CharacterSetMetaData.language.put("fi", "FINNISH");
        CharacterSetMetaData.language.put("fr_CA", "CANADIAN FRENCH");
        CharacterSetMetaData.language.put("fr", "FRENCH");
        CharacterSetMetaData.language.put("ga", "IRISH");
        CharacterSetMetaData.language.put("gu", "GUJARATI");
        CharacterSetMetaData.language.put("he", "HEBREW");
        CharacterSetMetaData.language.put("hi", "HINDI");
        CharacterSetMetaData.language.put("hr", "CROATIAN");
        CharacterSetMetaData.language.put("hu", "HUNGARIAN");
        CharacterSetMetaData.language.put("id", "INDONESIAN");
        CharacterSetMetaData.language.put("in", "INDONESIAN");
        CharacterSetMetaData.language.put("is", "ICELANDIC");
        CharacterSetMetaData.language.put("it", "ITALIAN");
        CharacterSetMetaData.language.put("iw", "HEBREW");
        CharacterSetMetaData.language.put("ja", "JAPANESE");
        CharacterSetMetaData.language.put("kn", "KANNADA");
        CharacterSetMetaData.language.put("ko", "KOREAN");
        CharacterSetMetaData.language.put("kk", "CYRILLIC KAZAKH");
        CharacterSetMetaData.language.put("kk_KZ", "CYRILLIC KAZAKH");
        CharacterSetMetaData.language.put("lt", "LITHUANIAN");
        CharacterSetMetaData.language.put("lv", "LATVIAN");
        CharacterSetMetaData.language.put("mk", "MACEDONIAN");
        CharacterSetMetaData.language.put("ml", "MALAYALAM");
        CharacterSetMetaData.language.put("mr", "MARATHI");
        CharacterSetMetaData.language.put("ms", "MALAY");
        CharacterSetMetaData.language.put("nb", "NORWEGIAN");
        CharacterSetMetaData.language.put("nl", "DUTCH");
        CharacterSetMetaData.language.put("no", "NORWEGIAN");
        CharacterSetMetaData.language.put("or", "ORIYA");
        CharacterSetMetaData.language.put("pa", "PUNJABI");
        CharacterSetMetaData.language.put("pl", "POLISH");
        CharacterSetMetaData.language.put("pt_BR", "BRAZILIAN PORTUGUESE");
        CharacterSetMetaData.language.put("pt", "PORTUGUESE");
        CharacterSetMetaData.language.put("ro", "ROMANIAN");
        CharacterSetMetaData.language.put("ru", "RUSSIAN");
        CharacterSetMetaData.language.put("sk", "SLOVAK");
        CharacterSetMetaData.language.put("sq", "ALBANIAN");
        CharacterSetMetaData.language.put("sl", "SLOVENIAN");
        CharacterSetMetaData.language.put("sr", "CYRILLIC SERBIAN");
        CharacterSetMetaData.language.put("sh", "LATIN SERBIAN");
        CharacterSetMetaData.language.put("sv", "SWEDISH");
        CharacterSetMetaData.language.put("ta", "TAMIL");
        CharacterSetMetaData.language.put("te", "TELUGU");
        CharacterSetMetaData.language.put("th", "THAI");
        CharacterSetMetaData.language.put("tr", "TURKISH");
        CharacterSetMetaData.language.put("uk", "UKRAINIAN");
        CharacterSetMetaData.language.put("vi", "VIETNAMESE");
        CharacterSetMetaData.language.put("zh_HK", "TRADITIONAL CHINESE");
        CharacterSetMetaData.language.put("zh_TW", "TRADITIONAL CHINESE");
        CharacterSetMetaData.language.put("zh", "SIMPLIFIED CHINESE");
        CharacterSetMetaData.territory.put("AE", "UNITED ARAB EMIRATES");
        CharacterSetMetaData.territory.put("AL", "ALBANIA");
        CharacterSetMetaData.territory.put("AT", "AUSTRIA");
        CharacterSetMetaData.territory.put("AU", "AUSTRALIA");
        CharacterSetMetaData.territory.put("BD", "BANGLADESH");
        CharacterSetMetaData.territory.put("BE", "BELGIUM");
        CharacterSetMetaData.territory.put("BG", "BULGARIA");
        CharacterSetMetaData.territory.put("BH", "BAHRAIN");
        CharacterSetMetaData.territory.put("BR", "BRAZIL");
        CharacterSetMetaData.territory.put("CA", "CANADA");
        CharacterSetMetaData.territory.put("CH", "SWITZERLAND");
        CharacterSetMetaData.territory.put("CL", "CHILE");
        CharacterSetMetaData.territory.put("CN", "CHINA");
        CharacterSetMetaData.territory.put("CO", "COLOMBIA");
        CharacterSetMetaData.territory.put("CR", "COSTA RICA");
        CharacterSetMetaData.territory.put("CY", "CYPRUS");
        CharacterSetMetaData.territory.put("CZ", "CZECH REPUBLIC");
        CharacterSetMetaData.territory.put("DE", "GERMANY");
        CharacterSetMetaData.territory.put("DJ", "DJIBOUTI");
        CharacterSetMetaData.territory.put("DK", "DENMARK");
        CharacterSetMetaData.territory.put("DZ", "ALGERIA");
        CharacterSetMetaData.territory.put("EE", "ESTONIA");
        CharacterSetMetaData.territory.put("EG", "EGYPT");
        CharacterSetMetaData.territory.put("ES", "SPAIN");
        CharacterSetMetaData.territory.put("ca_ES", "CATALONIA");
        CharacterSetMetaData.territory.put("FI", "FINLAND");
        CharacterSetMetaData.territory.put("FR", "FRANCE");
        CharacterSetMetaData.territory.put("GB", "UNITED KINGDOM");
        CharacterSetMetaData.territory.put("GR", "GREECE");
        CharacterSetMetaData.territory.put("GT", "GUATEMALA");
        CharacterSetMetaData.territory.put("HK", "HONG KONG");
        CharacterSetMetaData.territory.put("HR", "CROATIA");
        CharacterSetMetaData.territory.put("HU", "HUNGARY");
        CharacterSetMetaData.territory.put("ID", "INDONESIA");
        CharacterSetMetaData.territory.put("IE", "IRELAND");
        CharacterSetMetaData.territory.put("IL", "ISRAEL");
        CharacterSetMetaData.territory.put("IN", "INDIA");
        CharacterSetMetaData.territory.put("IQ", "IRAQ");
        CharacterSetMetaData.territory.put("IS", "ICELAND");
        CharacterSetMetaData.territory.put("IT", "ITALY");
        CharacterSetMetaData.territory.put("JO", "JORDAN");
        CharacterSetMetaData.territory.put("JP", "JAPAN");
        CharacterSetMetaData.territory.put("KR", "KOREA");
        CharacterSetMetaData.territory.put("KW", "KUWAIT");
        CharacterSetMetaData.territory.put("LB", "LEBANON");
        CharacterSetMetaData.territory.put("LT", "LITHUANIA");
        CharacterSetMetaData.territory.put("LU", "LUXEMBOURG");
        CharacterSetMetaData.territory.put("LV", "LATVIA");
        CharacterSetMetaData.territory.put("LY", "LIBYA");
        CharacterSetMetaData.territory.put("MA", "MOROCCO");
        CharacterSetMetaData.territory.put("MK", "FYR MACEDONIA");
        CharacterSetMetaData.territory.put("MR", "MAURITANIA");
        CharacterSetMetaData.territory.put("MX", "MEXICO");
        CharacterSetMetaData.territory.put("MY", "MALAYSIA");
        CharacterSetMetaData.territory.put("NI", "NICARAGUA");
        CharacterSetMetaData.territory.put("NL", "THE NETHERLANDS");
        CharacterSetMetaData.territory.put("NO", "NORWAY");
        CharacterSetMetaData.territory.put("NZ", "NEW ZEALAND");
        CharacterSetMetaData.territory.put("OM", "OMAN");
        CharacterSetMetaData.territory.put("PA", "PANAMA");
        CharacterSetMetaData.territory.put("PE", "PERU");
        CharacterSetMetaData.territory.put("PL", "POLAND");
        CharacterSetMetaData.territory.put("PR", "PUERTO RICO");
        CharacterSetMetaData.territory.put("PT", "PORTUGAL");
        CharacterSetMetaData.territory.put("QA", "QATAR");
        CharacterSetMetaData.territory.put("RO", "ROMANIA");
        CharacterSetMetaData.territory.put("RU", "CIS");
        CharacterSetMetaData.territory.put("SA", "SAUDI ARABIA");
        CharacterSetMetaData.territory.put("SD", "SUDAN");
        CharacterSetMetaData.territory.put("SE", "SWEDEN");
        CharacterSetMetaData.territory.put("SG", "SINGAPORE");
        CharacterSetMetaData.territory.put("SI", "SLOVENIA");
        CharacterSetMetaData.territory.put("SK", "SLOVAKIA");
        CharacterSetMetaData.territory.put("SO", "SOMALIA");
        CharacterSetMetaData.territory.put("SV", "EL SALVADOR");
        CharacterSetMetaData.territory.put("SY", "SYRIA");
        CharacterSetMetaData.territory.put("TH", "THAILAND");
        CharacterSetMetaData.territory.put("TN", "TUNISIA");
        CharacterSetMetaData.territory.put("TR", "TURKEY");
        CharacterSetMetaData.territory.put("TW", "TAIWAN");
        CharacterSetMetaData.territory.put("UA", "UKRAINE");
        CharacterSetMetaData.territory.put("US", "AMERICA");
        CharacterSetMetaData.territory.put("VE", "VENEZUELA");
        CharacterSetMetaData.territory.put("VN", "VIETNAM");
        CharacterSetMetaData.territory.put("YE", "YEMEN");
        CharacterSetMetaData.territory.put("ZA", "SOUTH AFRICA");
        CharacterSetMetaData.territory.put("ar", "SAUDI ARABIA");
        CharacterSetMetaData.territory.put("as", "INDIA");
        CharacterSetMetaData.territory.put("bg", "BULGARIA");
        CharacterSetMetaData.territory.put("bn", "BANGLADESH");
        CharacterSetMetaData.territory.put("ca", "CATALONIA");
        CharacterSetMetaData.territory.put("cs", "CZECH REPUBLIC");
        CharacterSetMetaData.territory.put("da", "DENMARK");
        CharacterSetMetaData.territory.put("de", "GERMANY");
        CharacterSetMetaData.territory.put("el", "GREECE");
        CharacterSetMetaData.territory.put("en", "AMERICA");
        CharacterSetMetaData.territory.put("es", "AMERICA");
        CharacterSetMetaData.territory.put("et", "ESTONIA");
        CharacterSetMetaData.territory.put("fi", "FINLAND");
        CharacterSetMetaData.territory.put("fr", "FRANCE");
        CharacterSetMetaData.territory.put("gu", "INDIA");
        CharacterSetMetaData.territory.put("he", "ISRAEL");
        CharacterSetMetaData.territory.put("hi", "INDIA");
        CharacterSetMetaData.territory.put("hr", "CROATIA");
        CharacterSetMetaData.territory.put("hu", "HUNGARY");
        CharacterSetMetaData.territory.put("id", "INDONESIA");
        CharacterSetMetaData.territory.put("in", "INDONESIA");
        CharacterSetMetaData.territory.put("is", "ICELAND");
        CharacterSetMetaData.territory.put("it", "ITALY");
        CharacterSetMetaData.territory.put("iw", "ISRAEL");
        CharacterSetMetaData.territory.put("ja", "JAPAN");
        CharacterSetMetaData.territory.put("kn", "INDIA");
        CharacterSetMetaData.territory.put("ko", "KOREA");
        CharacterSetMetaData.territory.put("kk", "KAZAKHSTAN");
        CharacterSetMetaData.territory.put("kk_KZ", "KAZAKHSTAN");
        CharacterSetMetaData.territory.put("lt", "LITHUANIA");
        CharacterSetMetaData.territory.put("lv", "LATVIA");
        CharacterSetMetaData.territory.put("mk", "FYR MACEDONIA");
        CharacterSetMetaData.territory.put("ml", "INDIA");
        CharacterSetMetaData.territory.put("mr", "INDIA");
        CharacterSetMetaData.territory.put("ms", "MALAYSIA");
        CharacterSetMetaData.territory.put("nl", "THE NETHERLANDS");
        CharacterSetMetaData.territory.put("no", "NORWAY");
        CharacterSetMetaData.territory.put("or", "INDIA");
        CharacterSetMetaData.territory.put("pa", "INDIA");
        CharacterSetMetaData.territory.put("pl", "POLAND");
        CharacterSetMetaData.territory.put("pt", "PORTUGAL");
        CharacterSetMetaData.territory.put("ro", "ROMANIA");
        CharacterSetMetaData.territory.put("ru", "CIS");
        CharacterSetMetaData.territory.put("sk", "SLOVAKIA");
        CharacterSetMetaData.territory.put("sl", "SLOVENIA");
        CharacterSetMetaData.territory.put("sq", "ALBANIA");
        CharacterSetMetaData.territory.put("sr", "SERBIA AND MONTENEGRO");
        CharacterSetMetaData.territory.put("sh", "SERBIA AND MONTENEGRO");
        CharacterSetMetaData.territory.put("sv", "SWEDEN");
        CharacterSetMetaData.territory.put("ta", "INDIA");
        CharacterSetMetaData.territory.put("te", "INDIA");
        CharacterSetMetaData.territory.put("th", "THAILAND");
        CharacterSetMetaData.territory.put("tr", "TURKEY");
        CharacterSetMetaData.territory.put("uk", "UKRAINE");
        CharacterSetMetaData.territory.put("vi", "VIETNAM");
        CharacterSetMetaData.territory.put("zh", "CHINA");
        CharacterSetMetaData.metaDataImpl = null;
        Orai18nCharacterSetMetaData metaDataImpl = null;
        try {
            Class.forName("oracle.i18n.text.OraBoot");
            metaDataImpl = new Orai18nCharacterSetMetaData();
        }
        catch (ClassNotFoundException ex) {}
        if (metaDataImpl != null && metaDataImpl.oraBoot != null) {
            CharacterSetMetaData.metaDataImpl = metaDataImpl;
        }
        else {
            CharacterSetMetaData.metaDataImpl = new JdbcCharacterSetMetaData();
        }
        m_maxCharWidth = new short[][] { { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 5, 1 }, { 6, 1 }, { 7, 1 }, { 8, 1 }, { 9, 1 }, { 10, 1 }, { 11, 1 }, { 12, 1 }, { 13, 1 }, { 14, 1 }, { 15, 1 }, { 16, 1 }, { 17, 1 }, { 18, 1 }, { 19, 1 }, { 20, 1 }, { 21, 1 }, { 22, 1 }, { 23, 1 }, { 25, 1 }, { 27, 1 }, { 28, 1 }, { 31, 1 }, { 32, 1 }, { 33, 1 }, { 34, 1 }, { 35, 1 }, { 36, 1 }, { 37, 1 }, { 38, 1 }, { 39, 1 }, { 40, 1 }, { 41, 1 }, { 42, 1 }, { 43, 1 }, { 44, 1 }, { 45, 1 }, { 46, 1 }, { 47, 1 }, { 48, 1 }, { 49, 1 }, { 50, 1 }, { 51, 1 }, { 61, 1 }, { 70, 1 }, { 72, 1 }, { 81, 1 }, { 82, 1 }, { 90, 1 }, { 91, 1 }, { 92, 1 }, { 93, 1 }, { 94, 1 }, { 95, 1 }, { 96, 1 }, { 97, 1 }, { 98, 1 }, { 99, 1 }, { 100, 1 }, { 101, 1 }, { 110, 1 }, { 113, 1 }, { 114, 1 }, { 140, 1 }, { 150, 1 }, { 152, 1 }, { 153, 1 }, { 154, 1 }, { 155, 1 }, { 156, 1 }, { 158, 1 }, { 159, 1 }, { 160, 1 }, { 161, 1 }, { 162, 1 }, { 163, 1 }, { 164, 1 }, { 165, 1 }, { 166, 1 }, { 167, 1 }, { 170, 1 }, { 171, 1 }, { 172, 1 }, { 173, 1 }, { 174, 1 }, { 175, 1 }, { 176, 1 }, { 177, 1 }, { 178, 1 }, { 179, 1 }, { 180, 1 }, { 181, 1 }, { 182, 1 }, { 183, 1 }, { 184, 1 }, { 185, 1 }, { 186, 1 }, { 187, 1 }, { 188, 1 }, { 189, 1 }, { 190, 1 }, { 191, 1 }, { 192, 1 }, { 193, 1 }, { 194, 1 }, { 195, 1 }, { 196, 1 }, { 197, 1 }, { 198, 1 }, { 199, 1 }, { 200, 1 }, { 201, 1 }, { 202, 1 }, { 203, 1 }, { 204, 1 }, { 205, 1 }, { 206, 1 }, { 207, 1 }, { 208, 1 }, { 210, 1 }, { 211, 1 }, { 221, 1 }, { 222, 1 }, { 223, 1 }, { 224, 1 }, { 225, 1 }, { 226, 1 }, { 230, 1 }, { 231, 1 }, { 232, 1 }, { 233, 1 }, { 235, 1 }, { 239, 1 }, { 241, 1 }, { 251, 1 }, { 261, 1 }, { 262, 1 }, { 263, 1 }, { 264, 1 }, { 265, 1 }, { 266, 1 }, { 267, 1 }, { 277, 1 }, { 278, 1 }, { 279, 1 }, { 301, 1 }, { 311, 1 }, { 312, 1 }, { 314, 1 }, { 315, 1 }, { 316, 1 }, { 317, 1 }, { 319, 1 }, { 320, 1 }, { 322, 1 }, { 323, 1 }, { 324, 1 }, { 351, 1 }, { 352, 1 }, { 353, 1 }, { 354, 1 }, { 368, 1 }, { 380, 1 }, { 381, 1 }, { 382, 1 }, { 383, 1 }, { 384, 1 }, { 385, 1 }, { 386, 1 }, { 390, 1 }, { 401, 1 }, { 500, 1 }, { 504, 1 }, { 505, 1 }, { 506, 1 }, { 507, 1 }, { 508, 1 }, { 509, 1 }, { 511, 1 }, { 514, 1 }, { 554, 1 }, { 555, 1 }, { 556, 1 }, { 557, 1 }, { 558, 1 }, { 559, 1 }, { 560, 1 }, { 561, 1 }, { 563, 1 }, { 565, 1 }, { 566, 1 }, { 567, 1 }, { 590, 1 }, { 798, 1 }, { 799, 258 }, { 829, 2 }, { 830, 3 }, { 831, 3 }, { 832, 2 }, { 833, 3 }, { 834, 2 }, { 835, 3 }, { 836, 2 }, { 837, 3 }, { 838, 2 }, { 840, 2 }, { 842, 3 }, { 845, 2 }, { 846, 2 }, { 850, 2 }, { 851, 2 }, { 852, 2 }, { 853, 3 }, { 854, 4 }, { 860, 4 }, { 861, 4 }, { 862, 2 }, { 863, 4 }, { 864, 3 }, { 865, 2 }, { 866, 2 }, { 867, 2 }, { 868, 2 }, { 870, 3 }, { 871, 3 }, { 872, 4 }, { 873, 4 }, { 992, 2 }, { 994, 2 }, { 995, 2 }, { 996, 3 }, { 997, 2 }, { 998, 3 }, { 1001, 258 }, { 1830, 258 }, { 1832, 258 }, { 1833, 258 }, { 1840, 258 }, { 1842, 258 }, { 1850, 258 }, { 1852, 258 }, { 1853, 258 }, { 1860, 258 }, { 1863, 260 }, { 1864, 258 }, { 1865, 258 }, { 2000, 258 }, { 2002, 258 }, { 9996, 3 }, { 9997, 3 }, { 9998, 3 }, { 9999, 3 } };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
        getMapProperties();
    }
    
    static class JdbcCharacterSetMetaData implements InternalCharacterSetMetaData
    {
        @Override
        public boolean isFixedWidth(final int n) {
            if (n == 0) {
                return false;
            }
            int n2 = -1;
            int i = 0;
            int n3 = CharacterSetMetaData.m_maxCharWidth.length - 1;
            while (i <= n3) {
                final int n4 = (i + n3) / 2;
                if (n < CharacterSetMetaData.m_maxCharWidth[n4][0]) {
                    n3 = n4 - 1;
                }
                else {
                    if (n <= CharacterSetMetaData.m_maxCharWidth[n4][0]) {
                        n2 = n4;
                        break;
                    }
                    i = n4 + 1;
                }
            }
            return (CharacterSetMetaData.m_maxCharWidth[n2][1] & 0x100) != 0x0;
        }
        
        @Override
        public int getMaxCharLength(final int n) {
            int n2 = -1;
            int i = 0;
            int n3 = CharacterSetMetaData.m_maxCharWidth.length - 1;
            while (i <= n3) {
                final int n4 = (i + n3) / 2;
                if (n < CharacterSetMetaData.m_maxCharWidth[n4][0]) {
                    n3 = n4 - 1;
                }
                else {
                    if (n <= CharacterSetMetaData.m_maxCharWidth[n4][0]) {
                        n2 = n4;
                        break;
                    }
                    i = n4 + 1;
                }
            }
            if (n2 < 0) {
                return 0;
            }
            return CharacterSetMetaData.m_maxCharWidth[n2][1] & 0xFF;
        }
    }
}
