// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql.converter;

import oracle.i18n.text.converter.CharacterConverter;
import oracle.i18n.text.converter.CharacterConverterOGS;

public class CharacterConverterFactoryOGS extends CharacterConverterFactory
{
    @Override
    public JdbcCharacterConverters make(final int n) {
        final CharacterConverter instance = CharacterConverterOGS.getInstance(n);
        return (instance == null) ? null : new I18CharacterConvertersWrapper(instance);
    }
}
