// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.GregorianCalendar;
import java.util.TimeZone;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Timestamp;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Connection;
import java.util.Calendar;

public class TIMESTAMPLTZ extends Datum
{
    private static int SIZE_TIMESTAMPLTZ;
    private static int SIZE_TIMESTAMPLTZ_NOFRAC;
    private static int SIZE_DATE;
    private static int CENTURY_DEFAULT;
    private static int DECADE_DEFAULT;
    private static int MONTH_DEFAULT;
    private static int DAY_DEFAULT;
    private static int DECADE_INIT;
    private static int HOUR_MILLISECOND;
    private static int MINUTE_MILLISECOND;
    private static int JAVA_YEAR;
    private static int JAVA_MONTH;
    private static int JAVA_DATE;
    private static int MINYEAR;
    private static int MAXYEAR;
    private static boolean cached;
    private static Calendar dbtz;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public TIMESTAMPLTZ() {
        super(initTimestampltz());
    }
    
    public TIMESTAMPLTZ(final byte[] array) {
        super(array);
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final Time time, final Calendar calendar) throws SQLException {
        super(toBytes(connection, time, calendar));
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final Date date, final Calendar calendar) throws SQLException {
        super(toBytes(connection, date, calendar));
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        super(toBytes(connection, timestamp, calendar));
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final DATE date, final Calendar calendar) throws SQLException {
        super(toBytes(connection, date, calendar));
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final String s, final Calendar calendar) throws SQLException {
        super(toBytes(connection, s, calendar));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Calendar calendar, final Time time) throws SQLException {
        super(toBytes(connection, calendar, time));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Calendar calendar, final Date date) throws SQLException {
        super(toBytes(connection, calendar, date));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Calendar calendar, final Timestamp timestamp) throws SQLException {
        super(toBytes(connection, calendar, timestamp));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Calendar calendar, final DATE date) throws SQLException {
        super(toBytes(connection, calendar, date));
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final Calendar calendar, final String s) throws SQLException {
        super(toBytes(connection, getSessCalendar(connection), s));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Time time) throws SQLException {
        super(toBytes(connection, getSessCalendar(connection), time));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Date date) throws SQLException {
        super(toBytes(connection, getSessCalendar(connection), date));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final Timestamp timestamp) throws SQLException {
        super(toBytes(connection, getSessCalendar(connection), timestamp));
    }
    
    public TIMESTAMPLTZ(final Connection connection, final DATE date) throws SQLException {
        super(toBytes(connection, getSessCalendar(connection), date));
    }
    
    @Deprecated
    public TIMESTAMPLTZ(final Connection connection, final String s) throws SQLException {
        super(toBytes(connection, getSessCalendar(connection), Timestamp.valueOf(s)));
    }
    
    public static Date toDate(final Connection connection, final byte[] array, final Calendar calendar) throws SQLException {
        return new Date(toCalendar(connection, Calendar.getInstance(), array, calendar).getTime().getTime());
    }
    
    public static Time toTime(final Connection connection, final byte[] array, final Calendar calendar) throws SQLException {
        final Calendar calendar2 = toCalendar(connection, Calendar.getInstance(), array, calendar);
        return new Time(calendar2.get(11), calendar2.get(12), calendar2.get(13));
    }
    
    public static Timestamp toTimestamp(final Connection connection, final byte[] array, final Calendar calendar) throws SQLException {
        return toTimestamp(connection, Calendar.getInstance(), array, calendar);
    }
    
    public static DATE toDATE(final Connection connection, final byte[] array, final Calendar calendar) throws SQLException {
        return new DATE(toTimestamp(connection, getSessCalendar(connection), array, null));
    }
    
    public Timestamp timestampValue(final Connection connection, final Calendar calendar) throws SQLException {
        return toTimestamp(connection, this.getBytes(), calendar);
    }
    
    @Deprecated
    public static String toString(final Connection connection, final byte[] array, final Calendar calendar) throws SQLException {
        final Calendar calendar2 = toCalendar(connection, null, array, calendar);
        final int value = calendar2.get(1);
        final int n = calendar2.get(2) + 1;
        final int value2 = calendar2.get(5);
        final int value3 = calendar2.get(11);
        final int value4 = calendar2.get(12);
        final int value5 = calendar2.get(13);
        int nanos = -1;
        if (array.length == TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ) {
            nanos = TIMESTAMP.getNanos(array, 7);
        }
        return TIMESTAMPTZ.toString(value, n, value2, value3, value4, value5, nanos, calendar2.getTimeZone().getID());
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    @Deprecated
    public static byte[] toBytes(final Connection connection, final Time time, final Calendar calendar) throws SQLException {
        if (time == null) {
            return null;
        }
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        instance.set(1, (TIMESTAMPLTZ.CENTURY_DEFAULT - 100) * 100 + TIMESTAMPLTZ.DECADE_DEFAULT % 100);
        instance.set(2, TIMESTAMPLTZ.MONTH_DEFAULT - 1);
        instance.set(5, TIMESTAMPLTZ.DAY_DEFAULT);
        return toBytes(connection, instance, calendar, 0);
    }
    
    @Deprecated
    public static byte[] toBytes(final Connection connection, final Date time, final Calendar calendar) throws SQLException {
        if (time == null) {
            return null;
        }
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        return toBytes(connection, instance, calendar, 0);
    }
    
    @Deprecated
    public static byte[] toBytes(final Connection connection, final Timestamp time, final Calendar calendar) throws SQLException {
        if (time == null) {
            return null;
        }
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        return toBytes(connection, instance, calendar, time.getNanos());
    }
    
    @Deprecated
    public static byte[] toBytes(final Connection connection, final DATE date, final Calendar calendar) throws SQLException {
        if (date == null) {
            return null;
        }
        final Calendar instance = Calendar.getInstance();
        instance.setTime(DATE.toDate(date.toBytes()));
        return toBytes(connection, instance, calendar, 0);
    }
    
    public static byte[] toBytes(final Connection connection, final String s, final Calendar calendar) throws SQLException {
        return toBytes(connection, Timestamp.valueOf(s), calendar);
    }
    
    public static Date toDate(final Connection connection, final byte[] array) throws SQLException {
        return new Date(toCalendar(connection, null, array, null).getTime().getTime());
    }
    
    public static Time toTime(final Connection connection, final byte[] array) throws SQLException {
        final Calendar calendar = toCalendar(connection, null, array, null);
        return new Time(calendar.get(11), calendar.get(12), calendar.get(13));
    }
    
    public static Timestamp toTimestamp(final Connection connection, final byte[] array) throws SQLException {
        return toTimestamp(connection, null, array, null);
    }
    
    public static DATE toDATE(final Connection connection, final byte[] array) throws SQLException {
        return new DATE(new Timestamp(toCalendar(connection, null, array, null).getTime().getTime()));
    }
    
    public static TIMESTAMP toTIMESTAMP(final Connection connection, final byte[] array) throws SQLException {
        return new TIMESTAMP(toTimestamp(connection, getSessCalendar(connection), array, null));
    }
    
    public static TIMESTAMPTZ toTIMESTAMPTZ(final Connection connection, final byte[] array) throws SQLException {
        return new TIMESTAMPTZ(connection, toTimestamp(connection, getSessCalendar(connection), array, null), getSessCalendar(connection));
    }
    
    public static String toString(final Connection connection, final byte[] array) throws SQLException {
        return toString(connection, array, null);
    }
    
    public static byte[] toBytes(final Connection connection, final Calendar calendar, final Time time) throws SQLException {
        if (time == null) {
            return null;
        }
        calendar.setTime(time);
        calendar.set(1, (TIMESTAMPLTZ.CENTURY_DEFAULT - 100) * 100 + TIMESTAMPLTZ.DECADE_DEFAULT % 100);
        calendar.set(2, TIMESTAMPLTZ.MONTH_DEFAULT - 1);
        calendar.set(5, TIMESTAMPLTZ.DAY_DEFAULT);
        initDbTimeZone(connection);
        return toBytes(connection, calendar, (Calendar)TIMESTAMPLTZ.dbtz.clone(), 0);
    }
    
    public static byte[] toBytes(final Connection connection, final Calendar calendar, final Date time) throws SQLException {
        if (time == null) {
            return null;
        }
        calendar.setTime(time);
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        initDbTimeZone(connection);
        return toBytes(connection, calendar, (Calendar)TIMESTAMPLTZ.dbtz.clone(), 0);
    }
    
    public static byte[] toBytes(final Connection connection, final Calendar calendar, final Timestamp time) throws SQLException {
        if (time == null) {
            return null;
        }
        calendar.setTime(time);
        final int nanos = time.getNanos();
        initDbTimeZone(connection);
        return toBytes(connection, calendar, (Calendar)TIMESTAMPLTZ.dbtz.clone(), nanos);
    }
    
    public static byte[] toBytes(final Connection connection, final Calendar calendar, final DATE date) throws SQLException {
        if (date == null) {
            return null;
        }
        calendar.setTime(DATE.toDate(date.toBytes()));
        initDbTimeZone(connection);
        return toBytes(connection, calendar, (Calendar)TIMESTAMPLTZ.dbtz.clone(), 0);
    }
    
    public static byte[] toBytes(final Connection connection, final Calendar calendar, final String s) throws SQLException {
        return toBytes(connection, calendar, Timestamp.valueOf(s));
    }
    
    @Override
    public String stringValue(final Connection connection) throws SQLException {
        return toString(connection, this.getBytes());
    }
    
    public String stringValue(final Connection connection, final Calendar calendar) throws SQLException {
        return toString(connection, this.getBytes(), calendar);
    }
    
    public Date dateValue(final Connection connection, final Calendar calendar) throws SQLException {
        return toDate(connection, this.getBytes(), calendar);
    }
    
    public Date dateValue(final Connection connection) throws SQLException {
        return toDate(connection, this.getBytes());
    }
    
    public Time timeValue(final Connection connection) throws SQLException {
        return toTime(connection, this.getBytes());
    }
    
    public Time timeValue(final Connection connection, final Calendar calendar) throws SQLException {
        return toTime(connection, this.getBytes(), calendar);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return null;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Timestamp[n];
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.sql.Date") == 0 || clazz.getName().compareTo("java.sql.Time") == 0 || clazz.getName().compareTo("java.sql.Timestamp") == 0 || clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    private static byte[] initTimestampltz() {
        final byte[] array = new byte[TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ];
        array[0] = (byte)TIMESTAMPLTZ.CENTURY_DEFAULT;
        array[1] = (byte)TIMESTAMPLTZ.DECADE_INIT;
        array[2] = (byte)TIMESTAMPLTZ.MONTH_DEFAULT;
        array[3] = (byte)TIMESTAMPLTZ.DAY_DEFAULT;
        array[4] = 1;
        array[6] = (array[5] = 1);
        return array;
    }
    
    private static byte[] toBytes(final Connection connection, final Calendar calendar, final Calendar calendar2, final int n) throws SQLException {
        byte[] array;
        if (n == 0) {
            array = new byte[TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ_NOFRAC];
        }
        else {
            array = new byte[TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ];
        }
        TimeZoneAdjust(connection, calendar, calendar2);
        final int value = calendar2.get(1);
        if (value < TIMESTAMPLTZ.MINYEAR || value > TIMESTAMPLTZ.MAXYEAR) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(calendar2.get(1) / 100 + 100);
        array[1] = (byte)(calendar2.get(1) % 100 + 100);
        array[2] = (byte)(calendar2.get(2) + 1);
        array[3] = (byte)calendar2.get(5);
        array[4] = (byte)(calendar2.get(11) + 1);
        array[5] = (byte)(calendar2.get(12) + 1);
        array[6] = (byte)(calendar2.get(13) + 1);
        if (n != 0) {
            array[7] = (byte)(n >> 24);
            array[8] = (byte)(n >> 16 & 0xFF);
            array[9] = (byte)(n >> 8 & 0xFF);
            array[10] = (byte)(n & 0xFF);
        }
        return array;
    }
    
    private static Timestamp toTimestamp(final Connection connection, final Calendar calendar, final byte[] array, final Calendar calendar2) throws SQLException {
        final Timestamp timestamp = new Timestamp(toCalendar(connection, calendar, array, calendar2).getTime().getTime());
        int nanos = 0;
        if (array.length == TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ) {
            nanos = TIMESTAMP.getNanos(array, 7);
        }
        timestamp.setNanos(nanos);
        return timestamp;
    }
    
    private static final Calendar toCalendar(final Connection connection, Calendar sessCalendar, final byte[] array, Calendar calendar) throws SQLException {
        int[] array2;
        if (array.length == TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ) {
            array2 = new int[TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ];
        }
        else {
            array2 = new int[TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ_NOFRAC];
        }
        for (int i = 0; i < array.length; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int javaYear = getJavaYear(array2[0], array2[1]);
        if (calendar == null) {
            initDbTimeZone(connection);
            calendar = (Calendar)TIMESTAMPLTZ.dbtz.clone();
        }
        calendar.set(1, javaYear);
        calendar.set(2, array2[2] - 1);
        calendar.set(5, array2[3]);
        calendar.set(11, array2[4] - 1);
        calendar.set(12, array2[5] - 1);
        calendar.set(13, array2[6] - 1);
        calendar.set(14, 0);
        if (sessCalendar == null) {
            sessCalendar = getSessCalendar(connection);
        }
        TimeZoneAdjust(connection, calendar, sessCalendar);
        return sessCalendar;
    }
    
    static void TimeZoneAdjust(final Connection connection, final Calendar calendar, final Calendar calendar2) throws SQLException {
        final TimeZone timeZone = calendar.getTimeZone();
        final String anObject = new String(calendar.getTimeZone().getID());
        final String s = new String(calendar2.getTimeZone().getID());
        if (!s.equals(anObject) && (!s.equals("Custom") || !anObject.equals("Custom"))) {
            final OffsetDST offsetDST = new OffsetDST();
            getZoneOffset(connection, calendar, offsetDST);
            final int offset = offsetDST.getOFFSET();
            final boolean inDaylightTime = timeZone.inDaylightTime(calendar.getTime());
            calendar.add(11, -(offset / TIMESTAMPLTZ.HOUR_MILLISECOND));
            calendar.add(12, -(offset % TIMESTAMPLTZ.HOUR_MILLISECOND) / TIMESTAMPLTZ.MINUTE_MILLISECOND);
            final boolean inDaylightTime2 = timeZone.inDaylightTime(calendar.getTime());
            if (inDaylightTime && !inDaylightTime2) {
                calendar.add(14, 3600000);
            }
            else if (!inDaylightTime && inDaylightTime2) {
                calendar.add(14, -3600000);
            }
            int n;
            if (s.equals("Custom")) {
                n = calendar2.getTimeZone().getRawOffset();
            }
            else {
                final int id = ZONEIDMAP.getID(s);
                if (!ZONEIDMAP.isValidID(id)) {
                    if (calendar2.getTimeZone().useDaylightTime()) {
                        throw new SQLException("Timezone not supported");
                    }
                    n = calendar2.getTimeZone().getRawOffset();
                }
                else {
                    final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                    if (timezonetab.checkID(id)) {
                        timezonetab.updateTable(connection, id);
                    }
                    n = timezonetab.getOffset(calendar, id);
                }
            }
            final boolean inDaylightTime3 = timeZone.inDaylightTime(calendar.getTime());
            calendar.add(11, n / TIMESTAMPLTZ.HOUR_MILLISECOND);
            calendar.add(12, n % TIMESTAMPLTZ.HOUR_MILLISECOND / TIMESTAMPLTZ.MINUTE_MILLISECOND);
            final boolean inDaylightTime4 = timeZone.inDaylightTime(calendar.getTime());
            if (inDaylightTime3 && !inDaylightTime4) {
                calendar.add(14, 3600000);
            }
            else if (!inDaylightTime3 && inDaylightTime4) {
                calendar.add(14, -3600000);
            }
        }
        if (s.equals("Custom") && anObject.equals("Custom")) {
            final int rawOffset = calendar.getTimeZone().getRawOffset();
            final int rawOffset2 = calendar2.getTimeZone().getRawOffset();
            int n2 = 0;
            if (rawOffset != rawOffset2) {
                final int n3 = rawOffset - rawOffset2;
                n2 = ((n3 > 0) ? n3 : (-n3));
            }
            if (rawOffset > rawOffset2) {
                n2 = -n2;
            }
            calendar.add(11, n2 / TIMESTAMPLTZ.HOUR_MILLISECOND);
            calendar.add(12, n2 % TIMESTAMPLTZ.HOUR_MILLISECOND / TIMESTAMPLTZ.MINUTE_MILLISECOND);
        }
        final int value = calendar.get(1);
        final int value2 = calendar.get(2);
        final int value3 = calendar.get(5);
        final int value4 = calendar.get(11);
        final int value5 = calendar.get(12);
        final int value6 = calendar.get(13);
        final int value7 = calendar.get(14);
        calendar2.set(1, value);
        calendar2.set(2, value2);
        calendar2.set(5, value3);
        calendar2.set(11, value4);
        calendar2.set(12, value5);
        calendar2.set(13, value6);
        calendar2.set(14, value7);
    }
    
    private static int getJavaYear(final int n, final int n2) {
        return (n - 100) * 100 + (n2 - 100);
    }
    
    private static byte getZoneOffset(final Connection connection, final Calendar calendar, final OffsetDST offsetDST) throws SQLException {
        byte localOffset = 0;
        if (calendar.getTimeZone().getID() == "Custom") {
            offsetDST.setOFFSET(calendar.getTimeZone().getRawOffset());
        }
        else {
            final int id = ZONEIDMAP.getID(new String(calendar.getTimeZone().getID()));
            if (!ZONEIDMAP.isValidID(id)) {
                if (calendar.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                offsetDST.setOFFSET(calendar.getTimeZone().getRawOffset());
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id)) {
                    timezonetab.updateTable(connection, id);
                }
                localOffset = timezonetab.getLocalOffset(calendar, id, offsetDST);
            }
        }
        return localOffset;
    }
    
    private static Calendar getDbTzCalendar(final String str) {
        final char char1 = str.charAt(0);
        String string;
        if (char1 == '+' || char1 == '-') {
            string = "GMT" + str;
        }
        else {
            string = str;
        }
        return new GregorianCalendar(TimeZone.getTimeZone(string));
    }
    
    static Calendar getSessCalendar(final Connection connection) {
        final String sessionTimeZone = ((oracle.jdbc.OracleConnection)connection).getSessionTimeZone();
        Calendar calendar;
        if (sessionTimeZone == null) {
            calendar = Calendar.getInstance();
        }
        else {
            calendar = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        }
        return calendar;
    }
    
    private static synchronized void initDbTimeZone(final Connection connection) throws SQLException {
        if (!TIMESTAMPLTZ.cached) {
            TIMESTAMPLTZ.dbtz = getDbTzCalendar(((oracle.jdbc.OracleConnection)connection).physicalConnectionWithin().getDatabaseTimeZone());
            TIMESTAMPLTZ.cached = true;
        }
    }
    
    static TIMEZONETAB getTIMEZONETAB(final Connection connection) throws SQLException {
        return ((oracle.jdbc.OracleConnection)connection).physicalConnectionWithin().getTIMEZONETAB();
    }
    
    static {
        TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ = 11;
        TIMESTAMPLTZ.SIZE_TIMESTAMPLTZ_NOFRAC = 7;
        TIMESTAMPLTZ.SIZE_DATE = 7;
        TIMESTAMPLTZ.CENTURY_DEFAULT = 119;
        TIMESTAMPLTZ.DECADE_DEFAULT = 100;
        TIMESTAMPLTZ.MONTH_DEFAULT = 1;
        TIMESTAMPLTZ.DAY_DEFAULT = 1;
        TIMESTAMPLTZ.DECADE_INIT = 170;
        TIMESTAMPLTZ.HOUR_MILLISECOND = 3600000;
        TIMESTAMPLTZ.MINUTE_MILLISECOND = 60000;
        TIMESTAMPLTZ.JAVA_YEAR = 1970;
        TIMESTAMPLTZ.JAVA_MONTH = 0;
        TIMESTAMPLTZ.JAVA_DATE = 1;
        TIMESTAMPLTZ.MINYEAR = -4712;
        TIMESTAMPLTZ.MAXYEAR = 9999;
        TIMESTAMPLTZ.cached = false;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
