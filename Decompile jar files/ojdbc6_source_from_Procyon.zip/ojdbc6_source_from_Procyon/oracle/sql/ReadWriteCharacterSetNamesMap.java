// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.Map;

class ReadWriteCharacterSetNamesMap
{
    static Map<Short, String> cache;
    
    static {
        ReadWriteCharacterSetNamesMap.cache = null;
    }
}
