// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;

public class DATE extends Datum
{
    public static final int BDA = 1;
    public static final int BDAL = 2;
    public static final int BMO = 4;
    public static final int BMOL = 8;
    public static final int BYR = 16;
    public static final int BYRL = 32;
    public static final int BHR = 64;
    public static final int BHRL = 128;
    public static final int BMN = 256;
    public static final int BMNL = 512;
    public static final int BSC = 1024;
    public static final int BSCL = 2048;
    public static final int MSD = 4096;
    public static final int YR0 = 8192;
    public static final int BDT = 32768;
    public static final int HRZER0 = 65536;
    public static final int MIZERO = 131072;
    public static final int SEZERO = 262144;
    private static final byte LDXTCE = 0;
    private static final byte LDXTYE = 1;
    private static final byte LDXTMO = 2;
    private static final byte LDXTDA = 3;
    private static final byte LDXTHO = 4;
    private static final byte LDXTMI = 5;
    private static final byte LDXTSE = 6;
    private static LdxLib _sldxlib;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public DATE() {
        super(_initDate());
    }
    
    public DATE(final byte[] array) {
        super(array);
    }
    
    public DATE(final Date date) {
        super(toBytes(date));
    }
    
    public DATE(final Time time) {
        super(toBytes(time));
    }
    
    public DATE(final Timestamp timestamp) {
        super(toBytes(timestamp));
    }
    
    public DATE(final Date date, final Calendar calendar) {
        super(toBytes(date, calendar));
    }
    
    public DATE(final Time time, final Calendar calendar) {
        super(toBytes(time, calendar));
    }
    
    public DATE(final Timestamp timestamp, final Calendar calendar) {
        super(toBytes(timestamp, calendar));
    }
    
    public DATE(final String s) {
        super(toBytes(s));
    }
    
    public DATE(final String source, final boolean b) throws ParseException {
        super(toBytes(source));
        if (!b) {
            final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
            simpleDateFormat.setLenient(false);
            simpleDateFormat.parse(source);
        }
    }
    
    public DATE(final String s, final Calendar calendar) {
        super(toBytes(s, calendar));
    }
    
    public DATE(final Object o) throws SQLException {
        if (o instanceof Date) {
            this.setShareBytes(toBytes((Date)o));
        }
        else if (o instanceof Time) {
            this.setShareBytes(toBytes((Time)o));
        }
        else if (o instanceof Timestamp) {
            this.setShareBytes(toBytes((Timestamp)o));
        }
        else {
            if (!(o instanceof String)) {
                throw new SQLException("Initialization failed");
            }
            this.setShareBytes(toBytes((String)o));
        }
    }
    
    public DATE(final Object o, final Calendar calendar) throws SQLException {
        if (o instanceof Date) {
            this.setShareBytes(toBytes((Date)o, calendar));
        }
        else if (o instanceof Time) {
            this.setShareBytes(toBytes((Time)o, calendar));
        }
        else if (o instanceof Timestamp) {
            this.setShareBytes(toBytes((Timestamp)o, calendar));
        }
        else {
            if (!(o instanceof String)) {
                throw new SQLException("Initialization failed");
            }
            this.setShareBytes(toBytes((String)o, calendar));
        }
    }
    
    public static Date toDate(final byte[] array) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int n = (array2[0] - 100) * 100 + (array2[1] - 100);
        int year = n - 1900;
        if (n <= 0) {
            ++year;
        }
        return new Date(year, array2[2] - 1, array2[3]);
    }
    
    public static Time toTime(final byte[] array) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        return new Time(array2[4] - 1, array2[5] - 1, array2[6] - 1);
    }
    
    public static Timestamp toTimestamp(final byte[] array) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int n = (array2[0] - 100) * 100 + (array2[1] - 100);
        int year = n - 1900;
        if (n <= 0) {
            ++year;
        }
        return new Timestamp(year, array2[2] - 1, array2[3], array2[4] - 1, array2[5] - 1, array2[6] - 1, 0);
    }
    
    public static Date toDate(final byte[] array, Calendar instance) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int value = (array2[0] - 100) * 100 + (array2[1] - 100);
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.set(1, value);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        instance.set(14, 0);
        return new Date(instance.getTime().getTime());
    }
    
    public static Time toTime(final byte[] array, Calendar instance) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.set(1, 1970);
        instance.set(2, 0);
        instance.set(5, 1);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        return new Time(instance.getTime().getTime());
    }
    
    public static Timestamp toTimestamp(final byte[] array, Calendar instance) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int value = (array2[0] - 100) * 100 + (array2[1] - 100);
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.set(1, value);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        return new Timestamp(instance.getTime().getTime());
    }
    
    public static String toString(final byte[] array) {
        final int[] array2 = new int[7];
        for (int i = 0; i < 7; ++i) {
            if (array[i] < 0) {
                array2[i] = array[i] + 256;
            }
            else {
                array2[i] = array[i];
            }
        }
        return TIMESTAMPTZ.toString((array2[0] - 100) * 100 + (array2[1] - 100), array2[2], array2[3], array2[4] - 1, array2[5] - 1, array2[6] - 1, -1, null);
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    public static byte[] toBytes(final Date time) {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[7];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        int value = instance.get(1);
        if (instance.get(0) == 0) {
            value = -value;
        }
        if (value < -4712 || value > 9999) {
            throw new IllegalArgumentException("Invalid year value");
        }
        array[0] = (byte)(value / 100 + 100);
        array[1] = (byte)(value % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = 1;
        array[6] = (array[5] = 1);
        return array;
    }
    
    public static byte[] toBytes(final Time time) {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[7];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        array[0] = 119;
        array[1] = 100;
        array[3] = (array[2] = 1);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        return array;
    }
    
    public static byte[] toBytes(final Timestamp time) {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[7];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        int value = instance.get(1);
        if (instance.get(0) == 0) {
            value = -value;
        }
        if (value < -4712 || value > 9999) {
            throw new IllegalArgumentException("Invalid year value");
        }
        array[0] = (byte)(value / 100 + 100);
        array[1] = (byte)(value % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        return array;
    }
    
    public static byte[] toBytes(final Date time, Calendar instance) {
        if (time == null) {
            return null;
        }
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.setTime(time);
        final byte[] array = new byte[7];
        int value = instance.get(1);
        if (instance.get(0) == 0) {
            value = -value;
        }
        if (value < -4712 || value > 9999) {
            throw new IllegalArgumentException("Invalid year value");
        }
        array[0] = (byte)(value / 100 + 100);
        array[1] = (byte)(value % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = 1;
        array[6] = (array[5] = 1);
        return array;
    }
    
    public static byte[] toBytes(final Time time, Calendar instance) {
        if (time == null) {
            return null;
        }
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.setTime(time);
        return new byte[] { 119, 100, 1, 1, (byte)(instance.get(11) + 1), (byte)(instance.get(12) + 1), (byte)(instance.get(13) + 1) };
    }
    
    public static byte[] toBytes(final Timestamp time, Calendar instance) {
        if (time == null) {
            return null;
        }
        if (instance == null) {
            instance = Calendar.getInstance();
        }
        instance.clear();
        instance.setTime(time);
        final byte[] array = new byte[7];
        int value = instance.get(1);
        if (instance.get(0) == 0) {
            value = -value;
        }
        if (value < -4712 || value > 9999) {
            throw new IllegalArgumentException("Invalid year value");
        }
        array[0] = (byte)(value / 100 + 100);
        array[1] = (byte)(value % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        return array;
    }
    
    public static byte[] toBytes(final String s) {
        return toBytes(Timestamp.valueOf(s));
    }
    
    public static byte[] toBytes(final String s, final Calendar calendar) {
        return toBytes(Timestamp.valueOf(s), calendar);
    }
    
    @Override
    public Date dateValue() {
        return toDate(this.getBytes());
    }
    
    @Override
    public Time timeValue() {
        return toTime(this.getBytes());
    }
    
    @Override
    public Timestamp timestampValue() {
        return toTimestamp(this.getBytes());
    }
    
    public Date dateValue(final Calendar calendar) {
        return toDate(this.getBytes(), calendar);
    }
    
    @Override
    public Time timeValue(final Calendar calendar) {
        return toTime(this.getBytes(), calendar);
    }
    
    @Override
    public Timestamp timestampValue(final Calendar calendar) {
        return toTimestamp(this.getBytes(), calendar);
    }
    
    @Override
    public String stringValue() {
        return toString(this.getBytes());
    }
    
    @Override
    public String toString() {
        return this.stringValue();
    }
    
    @Override
    public Object toJdbc() {
        return this.timestampValue();
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Timestamp[n];
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.sql.Date") == 0 || clazz.getName().compareTo("java.sql.Time") == 0 || clazz.getName().compareTo("java.sql.Timestamp") == 0 || clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    public DATE addJulianDays(final int n, final int n2) throws SQLException {
        return new DATE(_getLdxLib().ldxads(this.shareBytes(), n, n2));
    }
    
    public DATE addMonths(final int n) throws SQLException {
        return new DATE(_getLdxLib().ldxadm(this.shareBytes(), n));
    }
    
    public void diffInJulianDays(final DATE date, final int[] array, final int[] array2) throws SQLException {
        _getLdxLib().ldxsub(this.shareBytes(), date.shareBytes(), array, array2);
    }
    
    public NUMBER diffInMonths(final DATE date) throws SQLException {
        return new NUMBER(_getLdxLib().ldxsbm(this.shareBytes(), date.shareBytes()));
    }
    
    public static DATE getCurrentDate() throws SQLException {
        return new DATE(_getLdxLib().ldxgdt());
    }
    
    public static int checkValidity(final byte[] array) throws SQLException {
        return _getLdxLib().ldxchk(array);
    }
    
    public static DATE fromJulianDays(final int n, final int n2) throws SQLException {
        return new DATE(_getLdxLib().ldxdfd(n, n2));
    }
    
    public static DATE fromText(final String s, final String s2, final String s3) throws SQLException {
        return new DATE(_getLdxLib().ldxstd(s, s2, s3));
    }
    
    public DATE lastDayOfMonth() throws SQLException {
        return new DATE(_getLdxLib().ldxldd(this.shareBytes()));
    }
    
    public static void numberToJulianDays(final NUMBER number, final int[] array, final int[] array2) throws SQLException {
        _getLdxLib().ldxftd(number.toBytes(), array, array2);
    }
    
    public DATE round(final String s) throws SQLException {
        return new DATE(_getLdxLib().ldxrnd(this.shareBytes(), s));
    }
    
    public DATE setDayOfWeek(final int n) throws SQLException {
        return new DATE(_getLdxLib().ldxnxd(this.shareBytes(), n));
    }
    
    public void toJulianDays(final int[] array, final int[] array2) throws SQLException {
        _getLdxLib().ldxdtd(this.shareBytes(), array, array2);
    }
    
    public NUMBER toNumber() throws SQLException {
        return new NUMBER(_getLdxLib().ldxdyf(this.shareBytes()));
    }
    
    public String toText(final String s, final String s2) throws SQLException {
        return _getLdxLib().ldxdts(this.shareBytes(), s, s2);
    }
    
    public String toText(final byte[] array, final String s) throws SQLException {
        return _getLdxLib().ldxdts(this.shareBytes(), array, s);
    }
    
    public static byte[] parseFormat(final String s, final String s2) throws SQLException {
        return _getLdxLib().ldxsto(s, s2);
    }
    
    public DATE truncate(final String s) throws SQLException {
        return new DATE(_getLdxLib().ldxtrn(this.shareBytes(), s));
    }
    
    public int compareTo(final DATE date) {
        return Datum.compareBytes(this.shareBytes(), date.shareBytes());
    }
    
    private static byte[] _initDate() {
        return new byte[] { 119, -86, 1, 1, 1, 1, 1 };
    }
    
    private static LdxLib _getLdxLib() {
        if (DATE._sldxlib == null) {
            try {
                if (System.getProperty("oracle.jserver.version") != null) {
                    DATE._sldxlib = new LdxLibServer();
                }
                else {
                    DATE._sldxlib = new LdxLibThin();
                }
            }
            catch (SecurityException ex) {
                DATE._sldxlib = new LdxLibThin();
            }
        }
        return DATE._sldxlib;
    }
    
    private static void _printBytes(final byte[] array) {
        System.out.println(toString(array));
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
