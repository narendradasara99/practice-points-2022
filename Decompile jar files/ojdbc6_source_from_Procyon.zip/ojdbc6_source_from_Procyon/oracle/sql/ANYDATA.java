// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.driver.DatabaseError;
import java.io.InputStream;
import java.io.IOException;
import oracle.jdbc.driver.InternalFactory;
import java.sql.Connection;
import oracle.jdbc.oracore.PickleContext;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

public class ANYDATA implements ORAData
{
    static final byte KAD_VSN = 1;
    static final byte KAD_VSN2 = 2;
    boolean isNull;
    byte[] data;
    TypeDescriptor type;
    boolean isREF;
    short serverCharsetId;
    short serverNCharsetId;
    OracleConnection connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    ANYDATA(final TypeDescriptor type, final boolean isNull, final byte[] data, final boolean isREF) {
        this.isREF = false;
        this.serverCharsetId = 0;
        this.serverNCharsetId = 0;
        this.type = type;
        this.isNull = isNull;
        this.data = data;
        this.isREF = isREF;
    }
    
    public ANYDATA(final OPAQUE opaque) throws SQLException {
        this.isREF = false;
        this.serverCharsetId = 0;
        this.serverNCharsetId = 0;
        final byte[] bytesValue = opaque.getBytesValue();
        this.connection = opaque.getPhysicalConnection();
        if (this.connection != null) {
            this.serverCharsetId = this.connection.getDbCsId();
            this.serverNCharsetId = this.connection.getNCharSet();
        }
        this.unpickle(bytesValue, 0);
    }
    
    int unpickle(final byte[] array, final int n) throws SQLException {
        final PickleContext pickleContext = new PickleContext(array, n);
        if (pickleContext.readByte() == 2) {
            pickleContext.skipBytes(4);
        }
        final short[] array2 = { 0 };
        this.type = TypeDescriptor.unpickleOpaqueTypeImage(pickleContext, this.connection, array2);
        if (pickleContext.readByte() != 0) {
            this.isNull = true;
        }
        else {
            this.isNull = false;
        }
        if (!this.isNull) {
            this.data = pickleContext.readDataValue((int)pickleContext.readUB4());
        }
        if (array2[0] == 110) {
            this.isREF = true;
        }
        else {
            this.isREF = false;
        }
        return pickleContext.offset();
    }
    
    int pickle(final byte[] array, int pickleOpaqueTypeImage) {
        array[pickleOpaqueTypeImage++] = 1;
        pickleOpaqueTypeImage = this.type.pickleOpaqueTypeImage(array, pickleOpaqueTypeImage, this.isREF);
        if (this.isNull) {
            array[pickleOpaqueTypeImage++] = 1;
        }
        else {
            array[pickleOpaqueTypeImage++] = 0;
        }
        if (!this.isNull) {
            final int length = this.data.length;
            array[pickleOpaqueTypeImage++] = (byte)((length & 0xFF000000) >> 24 & 0xFF);
            array[pickleOpaqueTypeImage++] = (byte)((length & 0xFF0000) >> 16 & 0xFF);
            array[pickleOpaqueTypeImage++] = (byte)((length & 0xFF00) >> 8 & 0xFF);
            array[pickleOpaqueTypeImage++] = (byte)(length & 0xFF);
            System.arraycopy(this.data, 0, array, pickleOpaqueTypeImage, length);
        }
        return pickleOpaqueTypeImage;
    }
    
    int getImageSize() {
        int n = this.type.getOpaqueImageTypeSize() + 1 + 1;
        if (!this.isNull) {
            n += 4 + this.data.length;
        }
        return n;
    }
    
    @Override
    public Datum toDatum(final Connection connection) throws SQLException {
        this.connection = (OracleConnection)connection;
        final OpaqueDescriptor descriptor = OpaqueDescriptor.createDescriptor("SYS.ANYDATA", connection);
        final byte[] array = new byte[this.getImageSize()];
        this.pickle(array, 0);
        final OPAQUE opaque = new OPAQUE(descriptor, this.connection, array);
        opaque.setShareBytes(opaque.toBytes());
        return opaque;
    }
    
    public static ANYDATA convertDatum(final Datum datum) throws SQLException {
        ANYDATA anydata;
        if (datum instanceof STRUCT) {
            anydata = new ANYDATA(((STRUCT)datum).getDescriptor(), false, ((STRUCT)datum).toBytes(), false);
        }
        else if (datum instanceof ARRAY) {
            anydata = new ANYDATA(((ARRAY)datum).getDescriptor(), false, ((ARRAY)datum).toBytes(), false);
        }
        else if (datum instanceof REF) {
            anydata = new ANYDATA(((REF)datum).getDescriptor(), false, ((REF)datum).getBytes(), true);
        }
        else if (datum instanceof OPAQUE) {
            anydata = new ANYDATA(((OPAQUE)datum).getDescriptor(), false, ((OPAQUE)datum).toBytes(), false);
        }
        else {
            TypeDescriptor typeDescriptor = null;
            if (datum instanceof NUMBER) {
                typeDescriptor = new TypeDescriptor((short)2);
            }
            else if (datum instanceof DATE) {
                typeDescriptor = new TypeDescriptor((short)12);
            }
            else if (datum instanceof INTERVALDS) {
                typeDescriptor = new TypeDescriptor((short)190);
            }
            else if (datum instanceof INTERVALYM) {
                typeDescriptor = new TypeDescriptor((short)189);
            }
            else if (datum instanceof TIMESTAMPTZ) {
                typeDescriptor = new TypeDescriptor((short)188);
            }
            else if (datum instanceof TIMESTAMPLTZ) {
                typeDescriptor = new TypeDescriptor((short)232);
            }
            else if (datum instanceof TIMESTAMP) {
                typeDescriptor = new TypeDescriptor((short)187);
            }
            else if (datum instanceof NCLOB) {
                typeDescriptor = new TypeDescriptor((short)288);
            }
            else if (datum instanceof CLOB) {
                typeDescriptor = new TypeDescriptor((short)112);
            }
            else if (datum instanceof BLOB) {
                typeDescriptor = new TypeDescriptor((short)113);
            }
            else if (datum instanceof BFILE) {
                typeDescriptor = new TypeDescriptor((short)114);
            }
            else if (datum instanceof RAW) {
                typeDescriptor = new TypeDescriptor((short)95);
            }
            else if (datum instanceof BINARY_DOUBLE) {
                typeDescriptor = new TypeDescriptor((short)101);
            }
            else if (datum instanceof BINARY_FLOAT) {
                typeDescriptor = new TypeDescriptor((short)100);
            }
            else if (datum instanceof ROWID) {
                typeDescriptor = new TypeDescriptor((short)104);
            }
            else if (datum instanceof CHAR) {
                typeDescriptor = new TypeDescriptor((short)96);
            }
            if (datum instanceof ROWID) {
                final byte[] shareBytes = datum.shareBytes();
                final long[] rowid2urowid = InternalFactory.rowid2urowid(shareBytes, 0, shareBytes.length);
                anydata = new ANYDATA(typeDescriptor, false, new byte[] { 1, (byte)((rowid2urowid[0] & 0xFFFFFFFFFF000000L) >> 24), (byte)((rowid2urowid[0] & 0xFF0000L) >> 16), (byte)((rowid2urowid[0] & 0xFF00L) >> 8), (byte)(rowid2urowid[0] & 0xFFL), (byte)((rowid2urowid[1] & 0xFF00L) >> 8), (byte)(rowid2urowid[1] & 0xFFL), (byte)((rowid2urowid[2] & 0xFFFFFFFFFF000000L) >> 24), (byte)((rowid2urowid[2] & 0xFF0000L) >> 16), (byte)((rowid2urowid[2] & 0xFF00L) >> 8), (byte)(rowid2urowid[2] & 0xFFL), (byte)((rowid2urowid[3] & 0xFF00L) >> 8), (byte)(rowid2urowid[3] & 0xFFL) }, false);
            }
            else {
                anydata = new ANYDATA(typeDescriptor, false, datum.shareBytes(), false);
            }
        }
        if (datum instanceof DatumWithConnection) {
            anydata.connection = ((DatumWithConnection)datum).getInternalConnection();
        }
        return anydata;
    }
    
    public TypeDescriptor getTypeDescriptor() {
        return this.type;
    }
    
    public boolean isNull() {
        return this.isNull;
    }
    
    public byte[] getData() {
        return this.data;
    }
    
    public boolean isREF() {
        return this.isREF;
    }
    
    public String stringValue() throws SQLException {
        return this.stringValue(this.connection);
    }
    
    public String stringValue(final Connection connection) throws SQLException {
        String s = "ANYDATA TypeCode: \"" + this.getTypeDescriptor().getTypeCodeName();
        if (this.isREF) {
            s += "(REF)";
        }
        String s2 = s + "\" - ANYDATA Value: \"";
        final Datum accessDatum = this.accessDatum();
        boolean b = false;
        try {
            s2 += accessDatum.stringValue();
            b = true;
        }
        catch (SQLException ex) {}
        if (!b) {
            if ((this.type.getInternalTypeCode() == 108 || this.type.getInternalTypeCode() == 110) && !this.type.isTransient()) {
                s2 = s2 + ((StructDescriptor)this.type).getName() + "(...)";
            }
            else if (this.type.getInternalTypeCode() == 122 && !this.type.isTransient()) {
                s2 = s2 + ((ArrayDescriptor)this.type).getName() + "(...)";
            }
            else {
                switch (this.type.getInternalTypeCode()) {
                    case 113: {
                        final InputStream binaryStream = ((BLOB)accessDatum).getBinaryStream();
                        try {
                            String string = "";
                            int read;
                            while ((read = binaryStream.read()) != -1) {
                                string += Integer.toHexString(read);
                            }
                            s2 += string;
                        }
                        catch (IOException ex2) {}
                        finally {
                            try {
                                binaryStream.close();
                            }
                            catch (IOException ex3) {}
                        }
                        break;
                    }
                    case 188: {
                        if (connection == null) {
                            s2 += "?";
                            break;
                        }
                        s2 += ((TIMESTAMPTZ)accessDatum).stringValue(connection);
                        break;
                    }
                    case 232: {
                        if (connection == null) {
                            s2 += "?";
                            break;
                        }
                        s2 += ((TIMESTAMPLTZ)accessDatum).stringValue(connection);
                        break;
                    }
                    case 114: {
                        s2 = s2 + "bfile_dir=" + ((BFILE)accessDatum).getDirAlias() + " bfile_name=" + ((BFILE)accessDatum).getName();
                        break;
                    }
                }
            }
        }
        return s2 + "\"";
    }
    
    public Datum accessDatum() throws SQLException {
        Datum datum = null;
        if (!this.isNull) {
            final short internalTypeCode = this.type.getInternalTypeCode();
            switch (internalTypeCode) {
                case 58: {
                    datum = new OPAQUE((OpaqueDescriptor)this.type, this.data, this.connection);
                    break;
                }
                case 108: {
                    if (this.type instanceof OpaqueDescriptor) {
                        datum = new OPAQUE((OpaqueDescriptor)this.type, this.data, this.connection);
                        break;
                    }
                    if (!this.isREF) {
                        datum = new STRUCT((StructDescriptor)this.type, this.data, this.connection);
                        break;
                    }
                    datum = new REF((StructDescriptor)this.type, this.connection, this.data);
                    break;
                }
                case 122: {
                    datum = new ARRAY((ArrayDescriptor)this.type, this.data, this.connection);
                    break;
                }
                case 110: {
                    datum = new REF((StructDescriptor)this.type, this.connection, this.data);
                    break;
                }
                case 2: {
                    datum = new NUMBER(this.data);
                    break;
                }
                case 12: {
                    datum = new DATE(this.data);
                    break;
                }
                case 190: {
                    datum = new INTERVALDS(this.data);
                    break;
                }
                case 189: {
                    datum = new INTERVALYM(this.data);
                    break;
                }
                case 188: {
                    datum = new TIMESTAMPTZ(this.data);
                    break;
                }
                case 232: {
                    datum = new TIMESTAMPLTZ(this.data);
                    break;
                }
                case 187: {
                    datum = new TIMESTAMP(this.data);
                    break;
                }
                case 112: {
                    datum = new CLOB(this.connection, this.data);
                    break;
                }
                case 288: {
                    datum = new NCLOB(this.connection, this.data);
                    break;
                }
                case 113: {
                    datum = new BLOB(this.connection, this.data);
                    break;
                }
                case 114: {
                    datum = new BFILE(this.connection, this.data);
                    break;
                }
                case 95: {
                    datum = new RAW(this.data);
                    break;
                }
                case 101: {
                    datum = new BINARY_DOUBLE(this.data);
                    break;
                }
                case 100: {
                    datum = new BINARY_FLOAT(this.data);
                    break;
                }
                case 104: {
                    datum = new ROWID(InternalFactory.urowid2rowid(new long[] { ((long)this.data[1] & 0xFFL) << 24 | ((long)this.data[2] & 0xFFL) << 16 | ((long)this.data[3] & 0xFFL) << 8 | ((long)this.data[4] & 0xFFL), ((long)this.data[5] & 0xFFL) << 8 | ((long)this.data[6] & 0xFFL), ((long)this.data[7] & 0xFFL) << 24 | ((long)this.data[8] & 0xFFL) << 16 | ((long)this.data[9] & 0xFFL) << 8 | ((long)this.data[10] & 0xFFL), ((long)this.data[11] & 0xFFL) << 8 | ((long)this.data[12] & 0xFFL) }));
                    break;
                }
                case 1:
                case 9:
                case 96: {
                    if (this.serverCharsetId != 0) {
                        datum = new CHAR(this.data, CharacterSet.make(this.serverCharsetId));
                        break;
                    }
                    datum = new CHAR(this.data, null);
                    break;
                }
                case 286:
                case 287: {
                    if (this.serverNCharsetId != 0) {
                        datum = new CHAR(this.data, CharacterSet.make(this.serverNCharsetId));
                        break;
                    }
                    datum = new CHAR(this.data, null);
                    break;
                }
                default: {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "internal typecode: " + internalTypeCode);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
        }
        return datum;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
