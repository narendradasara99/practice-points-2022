// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.Connection;
import java.sql.CallableStatement;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.OracleCallableStatement;
import java.sql.SQLException;

public class LobPlsqlUtil
{
    static boolean PLSQL_DEBUG;
    static final int MAX_PLSQL_SIZE = 32512;
    static final int MAX_PLSQL_INSTR_SIZE = 32512;
    static final int MAX_CHUNK_SIZE = 32512;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static long hasPattern(final BLOB blob, final byte[] array, final long n) throws SQLException {
        return hasPattern(blob.getInternalConnection(), blob, 2004, array, n);
    }
    
    public static long isSubLob(final BLOB blob, final BLOB blob2, final long n) throws SQLException {
        return isSubLob(blob.getInternalConnection(), blob, 2004, blob2, n);
    }
    
    public static long hasPattern(final CLOB clob, final char[] value, final long n) throws SQLException {
        if (value == null || n <= 0L) {
            return 0L;
        }
        final OracleConnection internalConnection = clob.getInternalConnection();
        final long n2 = value.length;
        final long length = length(internalConnection, clob, 2005);
        if (n2 == 0L || n2 > length - n + 1L || n > length) {
            return 0L;
        }
        if (n2 <= getPlsqlMaxInstrSize(internalConnection)) {
            OraclePreparedStatement oraclePreparedStatement = null;
            try {
                oraclePreparedStatement = (OracleCallableStatement)internalConnection.prepareCall("begin :1 := dbms_lob.instr(:2, :3, :4); end;");
                ((CallableStatement)oraclePreparedStatement).registerOutParameter(1, 2);
                if (clob.isNCLOB()) {
                    oraclePreparedStatement.setFormOfUse(2, (short)2);
                    oraclePreparedStatement.setFormOfUse(3, (short)2);
                }
                oraclePreparedStatement.setCLOB(2, clob);
                oraclePreparedStatement.setString(3, new String(value));
                oraclePreparedStatement.setLong(4, n);
                oraclePreparedStatement.execute();
                return ((CallableStatement)oraclePreparedStatement).getLong(1);
            }
            finally {
                oraclePreparedStatement.close();
            }
        }
        long n3 = n;
        int i = 0;
        long n4 = 0L;
        while (i == 0) {
            if (n2 > length - n3 + 1L) {
                return 0L;
            }
            final int n5 = 0;
            final int n6 = (int)Math.min(getPlsqlMaxInstrSize(internalConnection), n2 - n5);
            final char[] array = new char[n6];
            System.arraycopy(value, n5, array, 0, n6);
            final long hasPattern = hasPattern(clob, array, n3);
            if (hasPattern == 0L) {
                return 0L;
            }
            n4 = hasPattern;
            int n7 = n5 + n6;
            n3 = hasPattern + n6;
            int j = 1;
            while (j != 0) {
                final int n8 = (int)Math.min(getPlsqlMaxInstrSize(internalConnection), n2 - n7);
                final char[] array2 = new char[n8];
                System.arraycopy(value, n7, array2, 0, n8);
                final long hasPattern2 = hasPattern(clob, array2, n3);
                if (hasPattern2 == n3) {
                    n7 += n8;
                    n3 += n8;
                    if (n7 != n2) {
                        continue;
                    }
                    j = 0;
                    i = 1;
                }
                else {
                    if (hasPattern2 == 0L) {
                        return 0L;
                    }
                    n3 = hasPattern2 - n7;
                    j = 0;
                }
            }
        }
        return n4;
    }
    
    public static long isSubLob(final CLOB clob, final CLOB clob2, final long n) throws SQLException {
        if (clob2 == null || n <= 0L) {
            return 0L;
        }
        final OracleConnection internalConnection = clob.getInternalConnection();
        final long length = length(internalConnection, clob2, 2005);
        final long length2 = length(internalConnection, clob, 2005);
        if (length == 0L || length > length2 - n + 1L || n > length2) {
            return 0L;
        }
        if (length <= getPlsqlMaxInstrSize(internalConnection)) {
            final char[] array = new char[(int)length];
            clob2.getChars(1L, (int)length, array);
            return hasPattern(clob, array, n);
        }
        long n2 = n;
        int i = 0;
        long n3 = 0L;
        while (i == 0) {
            if (length > length2 - n2 + 1L) {
                return 0L;
            }
            final int n4 = 0;
            final int n5 = (int)Math.min(getPlsqlMaxInstrSize(internalConnection), length - n4);
            final char[] array2 = new char[n5];
            clob2.getChars(n4 + 1, n5, array2);
            final long hasPattern = hasPattern(clob, array2, n2);
            if (hasPattern == 0L) {
                return 0L;
            }
            n3 = hasPattern;
            int n6 = n4 + n5;
            n2 = hasPattern + n5;
            int j = 1;
            while (j != 0) {
                final int n7 = (int)Math.min(getPlsqlMaxInstrSize(internalConnection), length - n6);
                final char[] array3 = new char[n7];
                clob2.getChars(n6 + 1, n7, array3);
                final long hasPattern2 = hasPattern(clob, array3, n2);
                if (hasPattern2 == n2) {
                    n6 += n7;
                    n2 += n7;
                    if (n6 != length) {
                        continue;
                    }
                    j = 0;
                    i = 1;
                }
                else {
                    if (hasPattern2 == 0L) {
                        return 0L;
                    }
                    n2 = hasPattern2 - n6;
                    j = 0;
                }
            }
        }
        return n3;
    }
    
    public static long hasPattern(final BFILE bfile, final byte[] array, final long n) throws SQLException {
        return hasPattern(bfile.getInternalConnection(), bfile, -13, array, n);
    }
    
    public static long isSubLob(final BFILE bfile, final BFILE bfile2, final long n) throws SQLException {
        return isSubLob(bfile.getInternalConnection(), bfile, -13, bfile2, n);
    }
    
    public static String fileGetName(final BFILE bfile) throws SQLException {
        CallableStatement callableStatement = null;
        String string = null;
        try {
            callableStatement = bfile.getInternalConnection().prepareCall("begin dbms_lob.fileGetName(:1, :2, :3); end; ");
            ((OraclePreparedStatement)callableStatement).setBFILE(1, bfile);
            callableStatement.registerOutParameter(2, 12);
            callableStatement.registerOutParameter(3, 12);
            callableStatement.execute();
            string = callableStatement.getString(3);
        }
        finally {
            if (callableStatement != null) {
                callableStatement.close();
            }
        }
        return string;
    }
    
    public static String fileGetDirAlias(final BFILE bfile) throws SQLException {
        CallableStatement callableStatement = null;
        String string = null;
        try {
            callableStatement = bfile.getInternalConnection().prepareCall("begin dbms_lob.fileGetName(:1, :2, :3); end; ");
            ((OraclePreparedStatement)callableStatement).setBFILE(1, bfile);
            callableStatement.registerOutParameter(2, 12);
            callableStatement.registerOutParameter(3, 12);
            callableStatement.execute();
            string = callableStatement.getString(2);
        }
        finally {
            if (callableStatement != null) {
                callableStatement.close();
            }
        }
        return string;
    }
    
    private static int getPlsqlMaxInstrSize(final OracleConnection oracleConnection) throws SQLException {
        final boolean charSetMultibyte = oracleConnection.isCharSetMultibyte(oracleConnection.getDriverCharSet());
        final int maxCharbyteSize = oracleConnection.getMaxCharbyteSize();
        int n = 32512;
        if (charSetMultibyte) {
            n = 32512 / (oracleConnection.getC2SNlsRatio() * maxCharbyteSize);
        }
        return n;
    }
    
    public static long read(final OracleConnection oracleConnection, final Datum datum, final int n, final long n2, long n3, final byte[] array) throws SQLException {
        CallableStatement callableStatement = null;
        int n4 = 0;
        try {
            callableStatement = oracleConnection.prepareCall("begin dbms_lob.read (:1, :2, :3, :4); end;");
            if (isNCLOB(datum)) {
                ((OraclePreparedStatement)callableStatement).setFormOfUse(1, (short)2);
                ((OraclePreparedStatement)callableStatement).setFormOfUse(4, (short)2);
            }
            callableStatement.setObject(1, datum, n);
            callableStatement.registerOutParameter(2, 2);
            callableStatement.registerOutParameter(4, -3);
            while (n4 < n3) {
                callableStatement.setInt(2, Math.min((int)n3, 32512));
                callableStatement.setInt(3, (int)n2 + n4);
                callableStatement.execute();
                final int int1 = callableStatement.getInt(2);
                System.arraycopy(callableStatement.getBytes(4), 0, array, n4, int1);
                n4 += int1;
                n3 -= int1;
            }
        }
        catch (SQLException ex) {
            if (ex.getErrorCode() != 1403) {
                throw ex;
            }
        }
        finally {
            if (callableStatement != null) {
                callableStatement.close();
            }
        }
        return n4;
    }
    
    public static long length(final OracleConnection oracleConnection, final Datum datum, final int n) throws SQLException {
        long long1 = 0L;
        CallableStatement callableStatement = null;
        try {
            callableStatement = oracleConnection.prepareCall("begin :1 := dbms_lob.getLength (:2); end;");
            if (isNCLOB(datum)) {
                ((OraclePreparedStatement)callableStatement).setFormOfUse(2, (short)2);
            }
            callableStatement.setObject(2, datum, n);
            callableStatement.registerOutParameter(1, 2);
            callableStatement.execute();
            long1 = callableStatement.getLong(1);
        }
        finally {
            if (callableStatement != null) {
                callableStatement.close();
            }
        }
        return long1;
    }
    
    public static long hasPattern(final OracleConnection oracleConnection, final Datum datum, final int n, final byte[] array, final long n2) throws SQLException {
        if (array == null || n2 <= 0L) {
            return 0L;
        }
        final long n3 = array.length;
        final long length = length(oracleConnection, datum, n);
        if (n3 == 0L || n3 > length - n2 + 1L || n2 > length) {
            return 0L;
        }
        if (n3 <= 32512L) {
            CallableStatement callableStatement = null;
            try {
                callableStatement = oracleConnection.prepareCall("begin :1 := dbms_lob.instr(:2, :3, :4); end;");
                callableStatement.registerOutParameter(1, 2);
                callableStatement.setObject(2, datum, n);
                callableStatement.setBytes(3, array);
                callableStatement.setLong(4, n2);
                callableStatement.execute();
                return callableStatement.getLong(1);
            }
            finally {
                callableStatement.close();
            }
        }
        long n4 = n2;
        int i = 0;
        long n5 = 0L;
        while (i == 0) {
            if (n3 > length - n4 + 1L) {
                return 0L;
            }
            final int n6 = 0;
            final int n7 = (int)Math.min(32512L, n3 - n6);
            final byte[] array2 = new byte[n7];
            System.arraycopy(array, n6, array2, 0, n7);
            final long hasPattern = hasPattern(oracleConnection, datum, n, array2, n4);
            if (hasPattern == 0L) {
                return 0L;
            }
            n5 = hasPattern;
            int n8 = n6 + n7;
            n4 = hasPattern + n7;
            int j = 1;
            while (j != 0) {
                final int n9 = (int)Math.min(32512L, n3 - n8);
                final byte[] array3 = new byte[n9];
                System.arraycopy(array, n8, array3, 0, n9);
                final long hasPattern2 = hasPattern(oracleConnection, datum, n, array3, n4);
                if (hasPattern2 == n4) {
                    n8 += n9;
                    n4 += n9;
                    if (n8 != n3) {
                        continue;
                    }
                    j = 0;
                    i = 1;
                }
                else {
                    if (hasPattern2 == 0L) {
                        return 0L;
                    }
                    n4 = hasPattern2 - n8;
                    j = 0;
                }
            }
        }
        return n5;
    }
    
    public static long isSubLob(final OracleConnection oracleConnection, final Datum datum, final int n, final Datum datum2, final long n2) throws SQLException {
        if (datum2 == null || n2 <= 0L) {
            return 0L;
        }
        final long length = length(oracleConnection, datum2, n);
        final long length2 = length(oracleConnection, datum, n);
        if (length == 0L || length > length2 - n2 + 1L || n2 > length2) {
            return 0L;
        }
        if (length <= 32512L) {
            final byte[] array = new byte[(int)length];
            read(oracleConnection, datum2, n, 1L, length, array);
            return hasPattern(oracleConnection, datum, n, array, n2);
        }
        long n3 = n2;
        int i = 0;
        long n4 = 0L;
        while (i == 0) {
            if (length > length2 - n3 + 1L) {
                return 0L;
            }
            final int n5 = 0;
            final int n6 = (int)Math.min(32512L, length - n5);
            final byte[] array2 = new byte[n6];
            read(oracleConnection, datum2, n, n5 + 1, n6, array2);
            final long hasPattern = hasPattern(oracleConnection, datum, n, array2, n3);
            if (hasPattern == 0L) {
                return 0L;
            }
            n4 = hasPattern;
            int n7 = n5 + n6;
            n3 = hasPattern + n6;
            int j = 1;
            while (j != 0) {
                final int n8 = (int)Math.min(32512L, length - n7);
                final byte[] array3 = new byte[n8];
                read(oracleConnection, datum2, n, n7 + 1, n8, array3);
                final long hasPattern2 = hasPattern(oracleConnection, datum, n, array3, n3);
                if (hasPattern2 == n3) {
                    n7 += n8;
                    n3 += n8;
                    if (n7 != length) {
                        continue;
                    }
                    j = 0;
                    i = 1;
                }
                else {
                    if (hasPattern2 == 0L) {
                        return 0L;
                    }
                    n3 = hasPattern2 - n7;
                    j = 0;
                }
            }
        }
        return n4;
    }
    
    private static boolean isNCLOB(final Datum datum) {
        Class<?> forName;
        try {
            forName = Class.forName("oracle.sql.CLOB");
        }
        catch (ClassNotFoundException ex) {
            return false;
        }
        return forName.isInstance(datum) && ((CLOB)datum).isNCLOB();
    }
    
    public static Datum createTemporaryLob(final Connection connection, final boolean b, final int n, final int n2, final short n3) throws SQLException {
        OracleCallableStatement oracleCallableStatement = null;
        Datum oracleObject = null;
        try {
            oracleCallableStatement = (OracleCallableStatement)connection.prepareCall("begin dbms_lob.createTemporary (:1," + (b ? "TRUE" : "FALSE") + ", :2); end;");
            oracleCallableStatement.registerOutParameter(1, n2);
            oracleCallableStatement.setFormOfUse(1, n3);
            oracleCallableStatement.setInt(2, n);
            oracleCallableStatement.execute();
            oracleObject = oracleCallableStatement.getOracleObject(1);
        }
        finally {
            if (oracleCallableStatement != null) {
                oracleCallableStatement.close();
            }
        }
        return oracleObject;
    }
    
    public static void freeTemporaryLob(final Connection connection, final Datum datum, final int n) throws SQLException {
        OracleCallableStatement oracleCallableStatement = null;
        try {
            oracleCallableStatement = (OracleCallableStatement)connection.prepareCall("begin dbms_lob.freeTemporary (:1); end;");
            oracleCallableStatement.registerOutParameter(1, n);
            if (isNCLOB(datum)) {
                oracleCallableStatement.setFormOfUse(1, (short)2);
            }
            oracleCallableStatement.setOracleObject(1, datum);
            oracleCallableStatement.execute();
            datum.setShareBytes(oracleCallableStatement.getOracleObject(1).shareBytes());
        }
        finally {
            if (oracleCallableStatement != null) {
                oracleCallableStatement.close();
            }
        }
    }
    
    static {
        LobPlsqlUtil.PLSQL_DEBUG = false;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
