// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

class LnxLibServer implements LnxLib
{
    @Override
    public native byte[] lnxabs(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxacos(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxadd(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxasin(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxatan(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxatan2(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxbex(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxcos(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxcsh(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxdec(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxdiv(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxexp(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxflo(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxceil(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxfpr(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] lnxinc(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxln(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxlog(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxmod(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxmul(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxneg(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxpow(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] lnxrou(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] lnxsca(final byte[] p0, final int p1, final int p2, final boolean[] p3) throws SQLException;
    
    @Override
    public native byte[] lnxshift(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] lnxsin(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxsnh(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxsqr(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxsub(final byte[] p0, final byte[] p1) throws SQLException;
    
    @Override
    public native byte[] lnxtan(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxtnh(final byte[] p0) throws SQLException;
    
    @Override
    public native byte[] lnxtru(final byte[] p0, final int p1) throws SQLException;
    
    @Override
    public native byte[] lnxcpn(final String p0, final boolean p1, final int p2, final boolean p3, final int p4, final String p5) throws SQLException;
    
    @Override
    public native byte[] lnxfcn(final String p0, final String p1, final String p2) throws SQLException;
    
    @Override
    public native String lnxnfn(final byte[] p0, final String p1, final String p2) throws SQLException;
    
    @Override
    public native String lnxnuc(final byte[] p0, final int p1, final String p2) throws SQLException;
    
    @Override
    public native byte[] lnxren(final double p0) throws SQLException;
    
    @Override
    public native double lnxnur(final byte[] p0);
    
    @Override
    public native byte[] lnxmin(final long p0);
    
    @Override
    public native long lnxsni(final byte[] p0) throws SQLException;
    
    static {
        LoadCorejava.init();
    }
}
