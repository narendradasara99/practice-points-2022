// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.Reader;
import java.sql.Timestamp;
import java.util.Calendar;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;

public abstract class Datum implements Serializable
{
    private byte[] data;
    static final long serialVersionUID = 4645732484621936751L;
    
    public Datum() {
    }
    
    public Datum(final byte[] data) {
        this.data = data;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || !(o instanceof Datum)) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final Datum datum = (Datum)o;
        if (this.data == null && datum.data == null) {
            return true;
        }
        if ((this.data == null && datum.data != null) || (this.data != null && datum.data == null)) {
            return false;
        }
        if (this.data.length != datum.data.length) {
            return false;
        }
        for (int i = 0; i < this.data.length; ++i) {
            if (this.data[i] != datum.data[i]) {
                return false;
            }
        }
        return true;
    }
    
    public byte[] shareBytes() {
        return this.data;
    }
    
    public long getLength() {
        if (null == this.data) {
            return 0L;
        }
        return this.data.length;
    }
    
    public void setBytes(final byte[] array) {
        final int length = array.length;
        System.arraycopy(array, 0, this.data = new byte[length], 0, length);
    }
    
    public void setShareBytes(final byte[] data) {
        this.data = data;
    }
    
    public byte[] getBytes() {
        final byte[] array = new byte[this.data.length];
        System.arraycopy(this.data, 0, array, 0, this.data.length);
        return array;
    }
    
    public InputStream getStream() {
        return new ByteArrayInputStream(this.data);
    }
    
    public String stringValue() throws SQLException {
        throw new SQLException("Conversion to String failed");
    }
    
    public String stringValue(final Connection connection) throws SQLException {
        return this.stringValue();
    }
    
    public boolean booleanValue() throws SQLException {
        throw new SQLException("Conversion to boolean failed");
    }
    
    public int intValue() throws SQLException {
        throw new SQLException("Conversion to integer failed");
    }
    
    public long longValue() throws SQLException {
        throw new SQLException("Conversion to long failed");
    }
    
    public float floatValue() throws SQLException {
        throw new SQLException("Conversion to float failed");
    }
    
    public double doubleValue() throws SQLException {
        throw new SQLException("Conversion to double failed");
    }
    
    public byte byteValue() throws SQLException {
        throw new SQLException("Conversion to byte failed");
    }
    
    public BigDecimal bigDecimalValue() throws SQLException {
        throw new SQLException("Conversion to BigDecimal failed");
    }
    
    public Date dateValue() throws SQLException {
        throw new SQLException("Conversion to Date failed");
    }
    
    public Time timeValue() throws SQLException {
        throw new SQLException("Conversion to Time failed");
    }
    
    public Time timeValue(final Calendar calendar) throws SQLException {
        throw new SQLException("Conversion to Time failed");
    }
    
    public Timestamp timestampValue() throws SQLException {
        throw new SQLException("Conversion to Timestamp failed");
    }
    
    public Timestamp timestampValue(final Calendar calendar) throws SQLException {
        throw new SQLException("Conversion to Timestamp failed");
    }
    
    public Reader characterStreamValue() throws SQLException {
        throw new SQLException("Conversion to character stream failed");
    }
    
    public InputStream asciiStreamValue() throws SQLException {
        throw new SQLException("Conversion to ascii stream failed");
    }
    
    public InputStream binaryStreamValue() throws SQLException {
        throw new SQLException("Conversion to binary stream failed");
    }
    
    public abstract boolean isConvertibleTo(final Class p0);
    
    public abstract Object toJdbc() throws SQLException;
    
    public abstract Object makeJdbcArray(final int p0);
    
    protected static int compareBytes(final byte[] array, final byte[] array2) {
        final int length = array.length;
        final int length2 = array2.length;
        int i = 0;
        while (i < Math.min(length, length2)) {
            final int n = array[i] & 0xFF;
            final int n2 = array2[i] & 0xFF;
            if (n != n2) {
                if (n < n2) {
                    return -1;
                }
                return 1;
            }
            else {
                ++i;
            }
        }
        if (length == length2) {
            return 0;
        }
        if (length > length2) {
            return 1;
        }
        return -1;
    }
}
