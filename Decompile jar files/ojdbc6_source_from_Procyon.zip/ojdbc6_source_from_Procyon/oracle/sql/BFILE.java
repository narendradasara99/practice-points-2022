// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.Reader;
import java.io.InputStream;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;

public class BFILE extends DatumWithConnection
{
    public static final int MAX_CHUNK_SIZE = 32512;
    public static final int MODE_READONLY = 0;
    public static final int MODE_READWRITE = 1;
    BfileDBAccess dbaccess;
    private long bfileLength;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected BFILE() {
        this.bfileLength = -1L;
    }
    
    public BFILE(final OracleConnection oracleConnection) throws SQLException {
        this(oracleConnection, null);
    }
    
    public BFILE(final OracleConnection physicalConnectionOf, final byte[] array) throws SQLException {
        super(array);
        this.bfileLength = -1L;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.dbaccess = this.getInternalConnection().createBfileDBAccess();
    }
    
    public long length() throws SQLException {
        return this.bfileLength = this.getDBAccess().length(this);
    }
    
    public byte[] getBytes(final long n, final int n2) throws SQLException {
        if (n < 1L || n2 < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, null);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        byte[] array;
        if (n2 == 0) {
            array = new byte[0];
        }
        else {
            final byte[] array2 = new byte[n2];
            final long n3 = this.getBytes(n, n2, array2);
            if (n3 > 0L) {
                if (n3 == n2) {
                    array = array2;
                }
                else {
                    array = new byte[(int)n3];
                    System.arraycopy(array2, 0, array, 0, (int)n3);
                }
            }
            else {
                array = new byte[0];
            }
        }
        return array;
    }
    
    public int getBytes(final long n, final int n2, final byte[] array) throws SQLException {
        return this.getDBAccess().getBytes(this, n, n2, array);
    }
    
    public InputStream getBinaryStream() throws SQLException {
        return this.getDBAccess().newInputStream(this, 32512, 0L);
    }
    
    public long position(final byte[] array, final long n) throws SQLException {
        return this.getDBAccess().position(this, array, n);
    }
    
    public long position(final BFILE bfile, final long n) throws SQLException {
        return this.getDBAccess().position(this, bfile, n);
    }
    
    public String getName() throws SQLException {
        return this.getDBAccess().getName(this);
    }
    
    public String getDirAlias() throws SQLException {
        return this.getDBAccess().getDirAlias(this);
    }
    
    public void openFile() throws SQLException {
        this.getDBAccess().openFile(this);
    }
    
    public boolean isFileOpen() throws SQLException {
        return this.getDBAccess().isFileOpen(this);
    }
    
    public boolean fileExists() throws SQLException {
        return this.getDBAccess().fileExists(this);
    }
    
    public void closeFile() throws SQLException {
        this.getDBAccess().closeFile(this);
    }
    
    public byte[] getLocator() {
        return this.getBytes();
    }
    
    public void setLocator(final byte[] bytes) {
        this.setBytes(bytes);
    }
    
    public InputStream getBinaryStream(final long n) throws SQLException {
        return this.getDBAccess().newInputStream(this, 32512, n);
    }
    
    public void open() throws SQLException {
        this.getDBAccess().open(this, 0);
    }
    
    public void open(final int n) throws SQLException {
        if (n != 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 102);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.getDBAccess().open(this, n);
    }
    
    public void close() throws SQLException {
        this.getDBAccess().close(this);
    }
    
    public boolean isOpen() throws SQLException {
        return this.getDBAccess().isOpen(this);
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        final String name = clazz.getName();
        return name.compareTo("java.io.InputStream") == 0 || name.compareTo("java.io.Reader") == 0;
    }
    
    @Override
    public Reader characterStreamValue() throws SQLException {
        final BfileDBAccess dbAccess = this.getDBAccess();
        this.getInternalConnection();
        return dbAccess.newConversionReader(this, 8);
    }
    
    @Override
    public InputStream asciiStreamValue() throws SQLException {
        final BfileDBAccess dbAccess = this.getDBAccess();
        this.getInternalConnection();
        return dbAccess.newConversionInputStream(this, 2);
    }
    
    @Override
    public InputStream binaryStreamValue() throws SQLException {
        return this.getBinaryStream();
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new BFILE[n];
    }
    
    public BfileDBAccess getDBAccess() throws SQLException {
        if (this.dbaccess == null) {
            this.dbaccess = this.getInternalConnection().createBfileDBAccess();
        }
        if (this.getPhysicalConnection().isClosed()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.dbaccess;
    }
    
    public final void setLength(final long bfileLength) {
        this.bfileLength = bfileLength;
    }
    
    @Override
    public Connection getJavaSqlConnection() throws SQLException {
        return super.getJavaSqlConnection();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
