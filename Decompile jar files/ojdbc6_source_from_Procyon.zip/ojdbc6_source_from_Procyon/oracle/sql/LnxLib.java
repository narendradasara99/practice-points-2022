// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

interface LnxLib
{
    byte[] lnxabs(final byte[] p0) throws SQLException;
    
    byte[] lnxacos(final byte[] p0) throws SQLException;
    
    byte[] lnxadd(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxasin(final byte[] p0) throws SQLException;
    
    byte[] lnxatan(final byte[] p0) throws SQLException;
    
    byte[] lnxatan2(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxbex(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxcos(final byte[] p0) throws SQLException;
    
    byte[] lnxcsh(final byte[] p0) throws SQLException;
    
    byte[] lnxdec(final byte[] p0) throws SQLException;
    
    byte[] lnxdiv(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxexp(final byte[] p0) throws SQLException;
    
    byte[] lnxflo(final byte[] p0) throws SQLException;
    
    byte[] lnxceil(final byte[] p0) throws SQLException;
    
    byte[] lnxfpr(final byte[] p0, final int p1) throws SQLException;
    
    byte[] lnxinc(final byte[] p0) throws SQLException;
    
    byte[] lnxln(final byte[] p0) throws SQLException;
    
    byte[] lnxlog(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxmod(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxmul(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxneg(final byte[] p0) throws SQLException;
    
    byte[] lnxpow(final byte[] p0, final int p1) throws SQLException;
    
    byte[] lnxrou(final byte[] p0, final int p1) throws SQLException;
    
    byte[] lnxsca(final byte[] p0, final int p1, final int p2, final boolean[] p3) throws SQLException;
    
    byte[] lnxshift(final byte[] p0, final int p1) throws SQLException;
    
    byte[] lnxsin(final byte[] p0) throws SQLException;
    
    byte[] lnxsnh(final byte[] p0) throws SQLException;
    
    byte[] lnxsqr(final byte[] p0) throws SQLException;
    
    byte[] lnxsub(final byte[] p0, final byte[] p1) throws SQLException;
    
    byte[] lnxtan(final byte[] p0) throws SQLException;
    
    byte[] lnxtnh(final byte[] p0) throws SQLException;
    
    byte[] lnxtru(final byte[] p0, final int p1) throws SQLException;
    
    byte[] lnxcpn(final String p0, final boolean p1, final int p2, final boolean p3, final int p4, final String p5) throws SQLException;
    
    byte[] lnxfcn(final String p0, final String p1, final String p2) throws SQLException;
    
    String lnxnfn(final byte[] p0, final String p1, final String p2) throws SQLException;
    
    String lnxnuc(final byte[] p0, final int p1, final String p2) throws SQLException;
    
    byte[] lnxren(final double p0) throws SQLException;
    
    double lnxnur(final byte[] p0);
    
    byte[] lnxmin(final long p0);
    
    long lnxsni(final byte[] p0) throws SQLException;
}
