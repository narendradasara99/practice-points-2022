// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import java.io.Serializable;

public class SQLName implements Serializable
{
    static boolean DEBUG;
    static boolean s_parseAllFormat;
    static final long serialVersionUID = 2266340348729491526L;
    String name;
    String schema;
    String simple;
    int version;
    boolean synonym;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected SQLName() {
    }
    
    public SQLName(final String s, final OracleConnection oracleConnection) throws SQLException {
        this.init(s, oracleConnection);
        this.version = 2;
        this.synonym = false;
    }
    
    public SQLName(final String schema, final String simple, final OracleConnection oracleConnection) throws SQLException {
        this.schema = schema;
        this.simple = simple;
        this.name = this.schema + "." + this.simple;
        this.version = 2;
        this.synonym = false;
    }
    
    private void init(final String s, final OracleConnection oracleConnection) throws SQLException {
        final String[] array = { null };
        final String[] array2 = { null };
        if (parse(s, array, array2, true)) {
            this.schema = array[0];
            this.simple = array2[0];
        }
        else {
            this.schema = oracleConnection.physicalConnectionWithin().getDefaultSchemaNameForNamedTypes();
            this.simple = array2[0];
        }
        this.name = this.schema + "." + this.simple;
    }
    
    public String getName() throws SQLException {
        return this.name;
    }
    
    public String getSchema() throws SQLException {
        return this.schema;
    }
    
    public String getSimpleName() throws SQLException {
        return this.simple;
    }
    
    public int getVersion() throws SQLException {
        return this.version;
    }
    
    public static boolean parse(final String s, final String[] array, final String[] array2) throws SQLException {
        return parse(s, array, array2, SQLName.s_parseAllFormat);
    }
    
    public static boolean parse(final String s, final String[] array, final String[] array2, final boolean b) throws SQLException {
        if (s == null) {
            return false;
        }
        if (array == null || array.length < 1 || array2 == null || array2.length < 1) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (!b) {
            final int index = s.indexOf(".");
            if (index < 0) {
                array2[0] = s;
                return false;
            }
            array[0] = s.substring(0, index);
            array2[0] = s.substring(index + 1);
            return true;
        }
        else {
            final int length = s.length();
            final int index2 = s.indexOf("\"");
            final int index3 = s.indexOf("\"", index2 + 1);
            if (index2 < 0) {
                final int index4 = s.indexOf(".");
                if (index4 < 0) {
                    array2[0] = s;
                    return false;
                }
                array[0] = s.substring(0, index4);
                array2[0] = s.substring(index4 + 1);
                return true;
            }
            else {
                if (index2 != 0) {
                    array[0] = s.substring(0, s.indexOf("."));
                    array2[0] = s.substring(index2 + 1, index3);
                    return true;
                }
                if (index3 == length - 1) {
                    array2[0] = s.substring(index2 + 1, index3);
                    return false;
                }
                final int index5 = s.indexOf(".", index3);
                array[0] = s.substring(index2 + 1, index3);
                final int index6 = s.indexOf("\"", index5);
                final int index7 = s.indexOf("\"", index6 + 1);
                if (index6 < 0) {
                    array2[0] = s.substring(index5 + 1);
                    return true;
                }
                array2[0] = s.substring(index6 + 1, index7);
                return true;
            }
        }
    }
    
    public static void setHandleDoubleQuote(final boolean s_parseAllFormat) throws SQLException {
        SQLName.s_parseAllFormat = s_parseAllFormat;
    }
    
    public static boolean getHandleDoubleQuote() throws SQLException {
        return SQLName.s_parseAllFormat;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o == this || (o instanceof SQLName && ((SQLName)o).name.equals(this.name));
    }
    
    @Override
    public int hashCode() {
        return (this.name == null) ? -1 : this.name.hashCode();
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.writeUTF(this.name);
        objectOutputStream.writeUTF(this.schema);
        objectOutputStream.writeUTF(this.simple);
        objectOutputStream.writeInt(this.version);
        objectOutputStream.writeBoolean(this.synonym);
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        this.name = objectInputStream.readUTF();
        this.schema = objectInputStream.readUTF();
        this.simple = objectInputStream.readUTF();
        this.version = objectInputStream.readInt();
        this.synonym = objectInputStream.readBoolean();
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        SQLName.DEBUG = false;
        SQLName.s_parseAllFormat = false;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
