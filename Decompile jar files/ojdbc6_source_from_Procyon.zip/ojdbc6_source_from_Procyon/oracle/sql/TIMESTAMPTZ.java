// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.Locale;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.OracleConnection;
import java.util.SimpleTimeZone;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Connection;
import java.util.TimeZone;
import java.util.Calendar;

public class TIMESTAMPTZ extends Datum
{
    static final Calendar CAL_GMT_US;
    static final TimeZone TIMEZONE_UTC;
    private static int HOUR_MILLISECOND;
    private static int MINUTE_MILLISECOND;
    private static int OFFSET_HOUR;
    private static int OFFSET_MINUTE;
    private static byte REGIONIDBIT;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public TIMESTAMPTZ() {
        super(initTimestamptz());
    }
    
    public TIMESTAMPTZ(final byte[] array) {
        super(array);
    }
    
    public TIMESTAMPTZ(final Connection connection, final Date date) throws SQLException {
        super(toBytes(connection, date));
    }
    
    public TIMESTAMPTZ(final Connection connection, final Date date, final Calendar calendar) throws SQLException {
        super(toBytes(connection, date, calendar));
    }
    
    public TIMESTAMPTZ(final Connection connection, final Time time) throws SQLException {
        super(toBytes(connection, time));
    }
    
    public TIMESTAMPTZ(final Connection connection, final Time time, final Calendar calendar) throws SQLException {
        super(toBytes(connection, time, calendar));
    }
    
    public TIMESTAMPTZ(final Connection connection, final Timestamp timestamp) throws SQLException {
        super(toBytes(connection, timestamp));
    }
    
    public TIMESTAMPTZ(final Connection connection, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        super(toBytes(connection, timestamp, calendar));
    }
    
    public TIMESTAMPTZ(final Connection connection, final DATE date) throws SQLException {
        super(toBytes(connection, date));
    }
    
    public TIMESTAMPTZ(final Connection connection, final String s) throws SQLException {
        super(toBytes(connection, s));
    }
    
    public TIMESTAMPTZ(final Connection connection, final String s, final Calendar calendar) throws SQLException {
        super(toBytes(connection, s, calendar));
    }
    
    public static Date toDate(final Connection connection, final byte[] array) throws SQLException {
        final int[] array2 = new int[13];
        for (int i = 0; i < 13; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int javaYear = getJavaYear(array2[0], array2[1]);
        final Calendar instance = Calendar.getInstance();
        instance.set(1, javaYear);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        if ((array2[11] & TIMESTAMPTZ.REGIONIDBIT) != 0x0) {
            final int n = getHighOrderbits(array2[11]) + getLowOrderbits(array2[12]);
            final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
            if (timezonetab.checkID(n)) {
                timezonetab.updateTable(connection, n);
            }
            final int offset = timezonetab.getOffset(instance, n);
            instance.add(10, offset / TIMESTAMPTZ.HOUR_MILLISECOND);
            instance.add(12, offset % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND);
        }
        else {
            instance.add(10, array2[11] - TIMESTAMPTZ.OFFSET_HOUR);
            instance.add(12, array2[12] - TIMESTAMPTZ.OFFSET_MINUTE);
        }
        return new Date(instance.getTime().getTime());
    }
    
    public static Date toDate2(final Connection connection, final byte[] array) throws SQLException {
        final int[] array2 = new int[13];
        for (int i = 0; i < 13; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int javaYear = getJavaYear(array2[0], array2[1]);
        final Calendar calendar = (Calendar)TIMESTAMPTZ.CAL_GMT_US.clone();
        calendar.set(1, javaYear);
        calendar.set(2, array2[2] - 1);
        calendar.set(5, array2[3]);
        calendar.set(11, array2[4] - 1);
        calendar.set(12, array2[5] - 1);
        calendar.set(13, array2[6] - 1);
        calendar.set(14, 0);
        return new Date(calendar.getTime().getTime());
    }
    
    public static Time toTime(final Connection connection, final byte[] array) throws SQLException {
        final int[] array2 = new int[13];
        for (int i = 0; i < 13; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final Calendar instance = Calendar.getInstance();
        instance.setTimeZone(TIMESTAMPTZ.TIMEZONE_UTC);
        instance.set(1, getJavaYear(array2[0], array2[1]));
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        return new Time(instance.getTimeInMillis());
    }
    
    public static DATE toDATE(final Connection connection, final byte[] array) throws SQLException {
        return new DATE(toTimestampInSessionTimezone(connection, array));
    }
    
    public static TIMESTAMP toTIMESTAMP(final Connection connection, final byte[] array) throws SQLException {
        return new TIMESTAMP(toTimestampInSessionTimezone(connection, array));
    }
    
    public static Timestamp toTimestamp(final Connection connection, final byte[] array) throws SQLException {
        final int[] array2 = new int[13];
        for (int i = 0; i < 13; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final Calendar instance = Calendar.getInstance();
        final Calendar calendar = (Calendar)TIMESTAMPTZ.CAL_GMT_US.clone();
        final Calendar instance2 = Calendar.getInstance();
        final int javaYear = getJavaYear(array2[0], array2[1]);
        instance.set(1, javaYear);
        instance.set(2, array2[2] - 1);
        instance.set(5, array2[3]);
        instance.set(11, array2[4] - 1);
        instance.set(12, array2[5] - 1);
        instance.set(13, array2[6] - 1);
        instance.set(14, 0);
        calendar.set(1, javaYear);
        calendar.set(2, array2[2] - 1);
        calendar.set(5, array2[3]);
        calendar.set(11, array2[4] - 1);
        calendar.set(12, array2[5] - 1);
        calendar.set(13, array2[6] - 1);
        calendar.set(14, 0);
        final long time = instance.getTime().getTime();
        long time2;
        if ((array2[11] & TIMESTAMPTZ.REGIONIDBIT) != 0x0) {
            final int n = getHighOrderbits(array2[11]) + getLowOrderbits(array2[12]);
            final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
            if (timezonetab.checkID(n)) {
                timezonetab.updateTable(connection, n);
            }
            time2 = time + timezonetab.getOffset(calendar, n);
            final TimeZone timeZone = instance.getTimeZone();
            final TimeZone timeZone2 = instance2.getTimeZone();
            if (!timeZone.inDaylightTime(instance.getTime()) && timeZone2.inDaylightTime(new Timestamp(time2))) {
                if (timeZone2 instanceof SimpleTimeZone) {
                    time2 -= ((SimpleTimeZone)timeZone2).getDSTSavings();
                }
                else {
                    time2 -= 3600000L;
                }
            }
            if (timeZone.inDaylightTime(instance.getTime()) && !timeZone2.inDaylightTime(new Timestamp(time2))) {
                if (timeZone2 instanceof SimpleTimeZone) {
                    time2 += ((SimpleTimeZone)timeZone).getDSTSavings();
                }
                else {
                    time2 += 3600000L;
                }
            }
        }
        else {
            instance.add(10, array2[11] - TIMESTAMPTZ.OFFSET_HOUR);
            instance.add(12, array2[12] - TIMESTAMPTZ.OFFSET_MINUTE);
            time2 = instance.getTime().getTime();
        }
        Timestamp time3 = new Timestamp(time2);
        final long time4 = calendar.getTime().getTime();
        final Calendar instance3 = Calendar.getInstance();
        instance3.setTimeInMillis(time4);
        final Calendar instance4 = Calendar.getInstance();
        instance4.setTime(time3);
        final boolean inDaylightTime = instance3.getTimeZone().inDaylightTime(instance3.getTime());
        final boolean inDaylightTime2 = instance4.getTimeZone().inDaylightTime(instance4.getTime());
        if (inDaylightTime && !inDaylightTime2) {
            time3 = new Timestamp(time2 - instance3.getTimeZone().getDSTSavings());
        }
        else if (!inDaylightTime && inDaylightTime2) {
            time3 = new Timestamp(time2 + instance4.getTimeZone().getDSTSavings());
        }
        time3.setNanos(TIMESTAMP.getNanos(array, 7));
        return time3;
    }
    
    public static Timestamp toTimestamp2(final Connection connection, final byte[] array) throws SQLException {
        final int[] array2 = new int[13];
        for (int i = 0; i < 13; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int javaYear = getJavaYear(array2[0], array2[1]);
        final Calendar calendar = (Calendar)TIMESTAMPTZ.CAL_GMT_US.clone();
        calendar.clear();
        calendar.set(1, javaYear);
        calendar.set(2, array2[2] - 1);
        calendar.set(5, array2[3]);
        calendar.set(11, array2[4] - 1);
        calendar.set(12, array2[5] - 1);
        calendar.set(13, array2[6] - 1);
        calendar.set(14, 0);
        final Timestamp timestamp = new Timestamp(calendar.getTime().getTime());
        timestamp.setNanos(TIMESTAMP.getNanos(array, 7));
        return timestamp;
    }
    
    static Timestamp toTimestampInSessionTimezone(final Connection connection, final byte[] array) throws SQLException {
        final int[] array2 = new int[13];
        for (int i = 0; i < 13; ++i) {
            array2[i] = (array[i] & 0xFF);
        }
        final int javaYear = getJavaYear(array2[0], array2[1]);
        final Calendar calendar = (Calendar)TIMESTAMPTZ.CAL_GMT_US.clone();
        calendar.clear();
        calendar.set(1, javaYear);
        calendar.set(2, array2[2] - 1);
        calendar.set(5, array2[3]);
        calendar.set(11, array2[4] - 1);
        calendar.set(12, array2[5] - 1);
        calendar.set(13, array2[6] - 1);
        calendar.set(14, 0);
        final Calendar sessCalendar = TIMESTAMPLTZ.getSessCalendar(connection);
        TIMESTAMPLTZ.TimeZoneAdjust(connection, calendar, sessCalendar);
        final Timestamp timestamp = new Timestamp(sessCalendar.getTime().getTime());
        timestamp.setNanos(TIMESTAMP.getNanos(array, 7));
        return timestamp;
    }
    
    public static String toString(final Connection connection, final byte[] array) throws SQLException {
        final Timestamp timestamp = toTimestamp(connection, array);
        final Calendar instance = Calendar.getInstance();
        instance.setTime(timestamp);
        final int value = instance.get(1);
        final int n = instance.get(2) + 1;
        final int value2 = instance.get(5);
        final int value3 = instance.get(11);
        final int value4 = instance.get(12);
        final int value5 = instance.get(13);
        final int n2 = (array[7] & 0xFF) << 24 | (array[8] & 0xFF) << 16 | (array[9] & 0xFF) << 8 | (array[10] & 0xFF & 0xFF);
        String s;
        if ((array[11] & TIMESTAMPTZ.REGIONIDBIT) != 0x0) {
            s = ZONEIDMAP.getRegion(getHighOrderbits(array[11]) + getLowOrderbits(array[12]));
        }
        else {
            final int i = array[11] - TIMESTAMPTZ.OFFSET_HOUR;
            final int j = array[12] - TIMESTAMPTZ.OFFSET_MINUTE;
            final String string = i + ":";
            if (j == 0) {
                s = string + "00";
            }
            else {
                s = string + "" + j;
            }
        }
        return toString(value, n, value2, value3, value4, value5, n2, s);
    }
    
    public static final String toString(final int i, final int n, final int n2, final int n3, final int n4, final int n5, final int j, final String str) {
        String s = "" + i + "-" + toStr(n) + "-" + toStr(n2) + " " + toStr(n3) + ":" + toStr(n4) + ":" + toStr(n5);
        if (j >= 0) {
            final String format = String.format("%09d", j);
            char[] charArray;
            int length;
            for (charArray = format.toCharArray(), length = charArray.length; length > 1 && charArray[length - 1] == '0'; --length) {}
            s = s + "." + format.substring(0, length);
        }
        if (str != null) {
            s = s + " " + str;
        }
        return s;
    }
    
    private static final String toStr(final int n) {
        return (n < 10) ? ("0" + n) : Integer.toString(n);
    }
    
    public Timestamp timestampValue(final Connection connection) throws SQLException {
        if (((OracleConnection)connection).physicalConnectionWithin().getTimestamptzInGmt()) {
            return toTimestamp2(connection, this.getBytes());
        }
        return toTimestamp(connection, this.getBytes());
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    public static byte[] toBytes(final Connection connection, final Date time) throws SQLException {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[13];
        final String sessionTimeZone = ((OracleConnection)connection).getSessionTimeZone();
        Calendar calendar;
        if (sessionTimeZone == null) {
            calendar = Calendar.getInstance();
        }
        else {
            calendar = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        }
        calendar.setTime(time);
        final boolean inDaylightTime = calendar.getTimeZone().inDaylightTime(time);
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        int n;
        if (calendar.getTimeZone().getID() == "Custom") {
            n = calendar.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = calendar.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (calendar.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = calendar.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                final byte localOffset = timezonetab.getLocalOffset(calendar, id2, offsetDST);
                n = offsetDST.getOFFSET();
                if (inDaylightTime && localOffset == 1) {
                    if (offsetDST.getDSTFLAG() != 0) {
                        throw new SQLException();
                    }
                    n += TIMESTAMPTZ.HOUR_MILLISECOND;
                }
                final int id3 = ZONEIDMAP.getID(id);
                array[11] = (byte)setHighOrderbits(id3);
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(id3);
            }
        }
        calendar.add(10, -(n / TIMESTAMPTZ.HOUR_MILLISECOND));
        calendar.add(12, -(n % TIMESTAMPTZ.HOUR_MILLISECOND) / TIMESTAMPTZ.MINUTE_MILLISECOND);
        final int value = calendar.get(1);
        if (value < -4712 || value > 9999) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(calendar.get(1) / 100 + 100);
        array[1] = (byte)(calendar.get(1) % 100 + 100);
        array[2] = (byte)(calendar.get(2) + 1);
        array[3] = (byte)calendar.get(5);
        array[4] = (byte)(calendar.get(11) + 1);
        array[5] = (byte)(calendar.get(12) + 1);
        array[6] = (byte)(calendar.get(13) + 1);
        array[8] = (array[7] = 0);
        array[10] = (array[9] = 0);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final Date time, final Calendar calendar) throws SQLException {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[13];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        final boolean inDaylightTime = calendar.getTimeZone().inDaylightTime(time);
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        int n;
        if (calendar.getTimeZone().getID() == "Custom") {
            n = calendar.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = calendar.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (calendar.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = calendar.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                final byte localOffset = timezonetab.getLocalOffset(instance, id2, offsetDST);
                n = offsetDST.getOFFSET();
                if (inDaylightTime && localOffset == 1) {
                    if (offsetDST.getDSTFLAG() != 0) {
                        throw new SQLException();
                    }
                    n += TIMESTAMPTZ.HOUR_MILLISECOND;
                }
                array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
            }
        }
        instance.add(10, -(n / TIMESTAMPTZ.HOUR_MILLISECOND));
        instance.add(12, -(n % TIMESTAMPTZ.HOUR_MILLISECOND) / TIMESTAMPTZ.MINUTE_MILLISECOND);
        final int value = instance.get(1);
        if (value < -4712 || value > 9999) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(instance.get(1) / 100 + 100);
        array[1] = (byte)(instance.get(1) % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        array[8] = (array[7] = 0);
        array[10] = (array[9] = 0);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final Time time) throws SQLException {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[13];
        final String sessionTimeZone = ((OracleConnection)connection).getSessionTimeZone();
        Calendar calendar;
        if (sessionTimeZone == null) {
            calendar = Calendar.getInstance();
        }
        else {
            calendar = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        }
        calendar.setTime(time);
        if (calendar.getTimeZone().inDaylightTime(time)) {}
        calendar.set(1, 1900);
        calendar.set(2, 0);
        calendar.set(5, 1);
        int n;
        if (calendar.getTimeZone().getID() == "Custom") {
            n = calendar.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = calendar.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (calendar.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = calendar.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                timezonetab.getLocalOffset(calendar, id2, offsetDST);
                n = offsetDST.getOFFSET();
                array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
            }
        }
        calendar.add(10, -(n / TIMESTAMPTZ.HOUR_MILLISECOND));
        calendar.add(12, -(n % TIMESTAMPTZ.HOUR_MILLISECOND) / TIMESTAMPTZ.MINUTE_MILLISECOND);
        final int value = calendar.get(1);
        if (value < -4712 || value > 9999) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(calendar.get(1) / 100 + 100);
        array[1] = (byte)(calendar.get(1) % 100 + 100);
        array[2] = (byte)(calendar.get(2) + 1);
        array[3] = (byte)calendar.get(5);
        array[4] = (byte)(calendar.get(11) + 1);
        array[5] = (byte)(calendar.get(12) + 1);
        array[6] = (byte)(calendar.get(13) + 1);
        array[8] = (array[7] = 0);
        array[10] = (array[9] = 0);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final Time time, final Calendar calendar) throws SQLException {
        if (time == null) {
            return null;
        }
        final Calendar instance = Calendar.getInstance();
        final byte[] array = new byte[13];
        instance.setTime(time);
        final boolean inDaylightTime = calendar.getTimeZone().inDaylightTime(time);
        instance.set(1, 1900);
        instance.set(2, 0);
        instance.set(5, 1);
        int n;
        if (calendar.getTimeZone().getID() == "Custom") {
            n = calendar.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = calendar.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (calendar.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = calendar.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                final byte localOffset = timezonetab.getLocalOffset(instance, id2, offsetDST);
                n = offsetDST.getOFFSET();
                if (inDaylightTime && localOffset == 1) {
                    if (offsetDST.getDSTFLAG() != 0) {
                        throw new SQLException();
                    }
                    n += TIMESTAMPTZ.HOUR_MILLISECOND;
                }
                array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
            }
        }
        instance.add(11, -(n / TIMESTAMPTZ.HOUR_MILLISECOND));
        instance.add(12, -(n % TIMESTAMPTZ.HOUR_MILLISECOND) / TIMESTAMPTZ.MINUTE_MILLISECOND);
        final int value = instance.get(1);
        if (value < -4712 || value > 9999) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(instance.get(1) / 100 + 100);
        array[1] = (byte)(instance.get(1) % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        array[8] = (array[7] = 0);
        array[10] = (array[9] = 0);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final Timestamp time) throws SQLException {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[13];
        String s = ((OracleConnection)connection).getSessionTimeZone();
        long time2;
        if (s == null) {
            s = TimeZone.getDefault().getID();
            time2 = time.getTime();
        }
        else {
            final int nanos = time.getNanos();
            final Calendar instance = Calendar.getInstance();
            instance.setTime(time);
            final String string = Integer.valueOf(instance.get(1)).toString() + "/" + Integer.valueOf(instance.get(2) + 1).toString() + "/" + Integer.valueOf(instance.get(5)).toString() + " " + Integer.valueOf(instance.get(11)).toString() + ":" + Integer.valueOf(instance.get(12)).toString() + ":" + Integer.valueOf(instance.get(13)).toString() + ":" + Double.valueOf(nanos / 1000000).toString();
            final TimeZone timeZone = TimeZone.getTimeZone(s);
            final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("y/M/d H:m:s:S");
            simpleDateFormat.setTimeZone(timeZone);
            java.util.Date parse;
            try {
                parse = simpleDateFormat.parse(string);
            }
            catch (ParseException ex) {
                throw new SQLException(ex.getMessage());
            }
            time2 = parse.getTime();
        }
        final Calendar instance2 = Calendar.getInstance(TimeZone.getTimeZone(s));
        final boolean inDaylightTime = instance2.getTimeZone().inDaylightTime(time);
        instance2.setTime(new Timestamp(time2));
        int n;
        if (instance2.getTimeZone().getID() == "Custom") {
            n = instance2.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = instance2.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (instance2.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = instance2.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                final byte localOffset = timezonetab.getLocalOffset(instance2, id2, offsetDST);
                n = offsetDST.getOFFSET();
                if (inDaylightTime && localOffset == 1) {
                    if (offsetDST.getDSTFLAG() != 0) {
                        throw new SQLException();
                    }
                    n += TIMESTAMPTZ.HOUR_MILLISECOND;
                }
                array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
            }
        }
        final Calendar instance3 = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
        instance3.set(1, instance2.get(1));
        instance3.set(2, instance2.get(2));
        instance3.set(5, instance2.get(5));
        instance3.set(11, instance2.get(11));
        instance3.set(12, instance2.get(12));
        instance3.set(13, instance2.get(13));
        instance3.add(14, -1 * n);
        final int value = instance3.get(1);
        if (value < -4712 || value > 9999) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(instance3.get(1) / 100 + 100);
        array[1] = (byte)(instance3.get(1) % 100 + 100);
        array[2] = (byte)(instance3.get(2) + 1);
        array[3] = (byte)instance3.get(5);
        array[4] = (byte)(instance3.get(11) + 1);
        array[5] = (byte)(instance3.get(12) + 1);
        array[6] = (byte)(instance3.get(13) + 1);
        array[7] = (byte)(time.getNanos() >> 24);
        array[8] = (byte)(time.getNanos() >> 16 & 0xFF);
        array[9] = (byte)(time.getNanos() >> 8 & 0xFF);
        array[10] = (byte)(time.getNanos() & 0xFF);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final Timestamp time, final Calendar calendar) throws SQLException {
        if (time == null) {
            return null;
        }
        final byte[] array = new byte[13];
        Calendar calendar2;
        if (calendar == null) {
            calendar2 = Calendar.getInstance();
        }
        else {
            calendar2 = Calendar.getInstance(calendar.getTimeZone());
        }
        calendar2.setTime(time);
        calendar2.getTimeZone();
        final boolean inDaylightTime = calendar.getTimeZone().inDaylightTime(time);
        int n;
        if (calendar.getTimeZone().getID() == "Custom") {
            n = calendar.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = calendar.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (calendar.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = calendar.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                final byte localOffset = timezonetab.getLocalOffset(calendar2, id2, offsetDST);
                n = offsetDST.getOFFSET();
                if (inDaylightTime && localOffset == 1) {
                    if (offsetDST.getDSTFLAG() != 0) {
                        throw new SQLException();
                    }
                    n += TIMESTAMPTZ.HOUR_MILLISECOND;
                }
                array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
            }
        }
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
        instance.set(1, calendar2.get(1));
        instance.set(2, calendar2.get(2));
        instance.set(5, calendar2.get(5));
        instance.set(11, calendar2.get(11));
        instance.set(12, calendar2.get(12));
        instance.set(13, calendar2.get(13));
        instance.add(14, -1 * n);
        final int value = instance.get(1);
        if (value < -4712 || value > 9999) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0] = (byte)(instance.get(1) / 100 + 100);
        array[1] = (byte)(instance.get(1) % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        array[7] = (byte)(time.getNanos() >> 24);
        array[8] = (byte)(time.getNanos() >> 16 & 0xFF);
        array[9] = (byte)(time.getNanos() >> 8 & 0xFF);
        array[10] = (byte)(time.getNanos() & 0xFF);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final DATE date) throws SQLException {
        if (date == null) {
            return null;
        }
        final byte[] array = new byte[13];
        final Calendar instance = Calendar.getInstance();
        instance.setTime(DATE.toDate(date.toBytes()));
        final boolean inDaylightTime = instance.getTimeZone().inDaylightTime(DATE.toDate(date.toBytes()));
        int n;
        if (instance.getTimeZone().getID() == "Custom") {
            n = instance.getTimeZone().getRawOffset();
            array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
            array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
        }
        else {
            final String id = instance.getTimeZone().getID();
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                if (instance.getTimeZone().useDaylightTime()) {
                    throw new SQLException("Timezone not supported");
                }
                n = instance.getTimeZone().getRawOffset();
                array[11] = (byte)(n / TIMESTAMPTZ.HOUR_MILLISECOND + TIMESTAMPTZ.OFFSET_HOUR);
                array[12] = (byte)(n % TIMESTAMPTZ.HOUR_MILLISECOND / TIMESTAMPTZ.MINUTE_MILLISECOND + TIMESTAMPTZ.OFFSET_MINUTE);
            }
            else {
                final TIMEZONETAB timezonetab = getTIMEZONETAB(connection);
                if (timezonetab.checkID(id2)) {
                    timezonetab.updateTable(connection, id2);
                }
                final OffsetDST offsetDST = new OffsetDST();
                final byte localOffset = timezonetab.getLocalOffset(instance, id2, offsetDST);
                n = offsetDST.getOFFSET();
                if (inDaylightTime && localOffset == 1) {
                    if (offsetDST.getDSTFLAG() != 0) {
                        throw new SQLException();
                    }
                    n += TIMESTAMPTZ.HOUR_MILLISECOND;
                }
                array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
                final byte[] array2 = array;
                final int n2 = 11;
                array2[n2] |= TIMESTAMPTZ.REGIONIDBIT;
                array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
            }
        }
        instance.add(10, -(n / TIMESTAMPTZ.HOUR_MILLISECOND));
        instance.add(12, -(n % TIMESTAMPTZ.HOUR_MILLISECOND) / TIMESTAMPTZ.MINUTE_MILLISECOND);
        array[0] = (byte)(instance.get(1) / 100 + 100);
        array[1] = (byte)(instance.get(1) % 100 + 100);
        array[2] = (byte)(instance.get(2) + 1);
        array[3] = (byte)instance.get(5);
        array[4] = (byte)(instance.get(11) + 1);
        array[5] = (byte)(instance.get(12) + 1);
        array[6] = (byte)(instance.get(13) + 1);
        array[8] = (array[7] = 0);
        array[10] = (array[9] = 0);
        return array;
    }
    
    public static byte[] toBytes(final Connection connection, final String s) throws SQLException {
        return toBytes(connection, Timestamp.valueOf(s));
    }
    
    public static byte[] toBytes(final Connection connection, final String s, final Calendar calendar) throws SQLException {
        final Calendar instance = Calendar.getInstance();
        final Timestamp value = Timestamp.valueOf(s);
        instance.setTime(value);
        Calendar calendar2;
        if (calendar == null) {
            calendar2 = Calendar.getInstance();
        }
        else {
            calendar2 = Calendar.getInstance(calendar.getTimeZone());
        }
        calendar2.set(1, instance.get(1));
        calendar2.set(2, instance.get(2));
        calendar2.set(5, instance.get(5));
        calendar2.set(11, instance.get(11));
        calendar2.set(12, instance.get(12));
        calendar2.set(13, instance.get(13));
        calendar2.set(14, instance.get(14));
        final int nanos = value.getNanos();
        final Timestamp timestamp = new Timestamp(calendar2.getTime().getTime());
        timestamp.setNanos(nanos);
        return toBytes(connection, timestamp, calendar);
    }
    
    @Override
    public String stringValue(final Connection connection) throws SQLException {
        return toString(connection, this.getBytes());
    }
    
    public Date dateValue(final Connection connection) throws SQLException {
        if (((OracleConnection)connection).physicalConnectionWithin().getTimestamptzInGmt()) {
            return toDate2(connection, this.getBytes());
        }
        return toDate(connection, this.getBytes());
    }
    
    public Time timeValue(final Connection connection) throws SQLException {
        return toTime(connection, this.getBytes());
    }
    
    private static byte[] initTimestamptz() {
        final byte[] array = new byte[13];
        final Calendar instance = Calendar.getInstance();
        array[0] = 119;
        array[1] = -86;
        array[2] = 1;
        array[4] = (array[3] = 1);
        array[6] = (array[5] = 1);
        array[8] = (array[7] = 0);
        array[10] = (array[9] = 0);
        final String id = instance.getTimeZone().getID();
        array[11] = (byte)setHighOrderbits(ZONEIDMAP.getID(id));
        final byte[] array2 = array;
        final int n = 11;
        array2[n] |= TIMESTAMPTZ.REGIONIDBIT;
        array[12] = (byte)setLowOrderbits(ZONEIDMAP.getID(id));
        return array;
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return null;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Timestamp[n];
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.sql.Date") == 0 || clazz.getName().compareTo("java.sql.Time") == 0 || clazz.getName().compareTo("java.sql.Timestamp") == 0 || clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    private static int setHighOrderbits(final int n) {
        return (n & 0x1FC0) >> 6;
    }
    
    private static int setLowOrderbits(final int n) {
        return (n & 0x3F) << 2;
    }
    
    private static int getHighOrderbits(final int n) {
        return (n & 0x7F) << 6;
    }
    
    private static int getLowOrderbits(final int n) {
        return (n & 0xFC) >> 2;
    }
    
    private static int getJavaYear(final int n, final int n2) {
        return (n - 100) * 100 + (n2 - 100);
    }
    
    static TIMEZONETAB getTIMEZONETAB(final Connection connection) throws SQLException {
        return ((OracleConnection)connection).physicalConnectionWithin().getTIMEZONETAB();
    }
    
    static {
        CAL_GMT_US = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
        TIMEZONE_UTC = TimeZone.getTimeZone("UTC");
        TIMESTAMPTZ.HOUR_MILLISECOND = 3600000;
        TIMESTAMPTZ.MINUTE_MILLISECOND = 60000;
        TIMESTAMPTZ.OFFSET_HOUR = 20;
        TIMESTAMPTZ.OFFSET_MINUTE = 60;
        TIMESTAMPTZ.REGIONIDBIT = -128;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
