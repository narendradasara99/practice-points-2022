// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Vector;
import oracle.jdbc.OracleCallableStatement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLOutput;
import java.sql.SQLInput;
import oracle.jdbc.oracore.OracleType;
import java.util.Map;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLException;
import java.sql.Connection;
import java.io.Serializable;

public class StructDescriptor extends TypeDescriptor implements Serializable
{
    static final boolean DEBUG = false;
    static final long serialVersionUID = 1013921343538311063L;
    static final int LOCAL_TYPE = 0;
    static final int LOOK_FOR_USER_SYNONYM = 1;
    static final int LOOK_FOR_PUBLIC_SYNONYM = 2;
    static final String[] initMetaData1_9_0_SQL;
    String sqlHint;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static StructDescriptor createDescriptor(final String s, final Connection connection) throws SQLException {
        return createDescriptor(s, connection, false, false);
    }
    
    public static StructDescriptor createDescriptor(final String s, final Connection connection, final boolean b, final boolean b2) throws SQLException {
        if (s == null || s.length() == 0 || connection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 60, "Invalid arguments");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return createDescriptor(new SQLName(s, (oracle.jdbc.OracleConnection)connection), connection, b, b2);
    }
    
    public static StructDescriptor createDescriptor(final SQLName sqlName, final Connection connection, final boolean b, final boolean b2) throws SQLException {
        final String name = sqlName.getName();
        TypeDescriptor typeDescriptor = null;
        if (!b2) {
            typeDescriptor = (StructDescriptor)((oracle.jdbc.OracleConnection)connection).getDescriptor(name);
            if (typeDescriptor == null) {
                typeDescriptor = new StructDescriptor(sqlName, connection);
                if (b) {
                    typeDescriptor.initNamesRecursively();
                }
                ((oracle.jdbc.OracleConnection)connection).putDescriptor(name, typeDescriptor);
            }
        }
        return (StructDescriptor)typeDescriptor;
    }
    
    public static StructDescriptor createDescriptor(final SQLName sqlName, final Connection connection) throws SQLException {
        return createDescriptor(sqlName, connection, false, false);
    }
    
    public static StructDescriptor createDescriptor(final OracleTypeADT oracleTypeADT) throws SQLException {
        final String fullName = oracleTypeADT.getFullName();
        final OracleConnection connection = oracleTypeADT.getConnection();
        StructDescriptor structDescriptor = (StructDescriptor)connection.getDescriptor(fullName);
        if (structDescriptor == null) {
            structDescriptor = new StructDescriptor(new SQLName(oracleTypeADT.getSchemaName(), oracleTypeADT.getSimpleName(), oracleTypeADT.getConnection()), oracleTypeADT, connection);
            connection.putDescriptor(fullName, structDescriptor);
        }
        return structDescriptor;
    }
    
    public static StructDescriptor createDescriptor(final SQLName sqlName, final byte[] array, final int n, final byte[] array2, final OracleConnection oracleConnection) throws SQLException {
        return new StructDescriptor(sqlName, new OracleTypeADT(sqlName, array, n, array2, oracleConnection), oracleConnection);
    }
    
    public StructDescriptor(final OracleTypeADT oracleTypeADT, final Connection connection) throws SQLException {
        super((short)108, oracleTypeADT, connection);
        this.sqlHint = null;
    }
    
    public StructDescriptor(final String s, final Connection connection) throws SQLException {
        super((short)108, s, connection);
        this.sqlHint = null;
        this.initPickler();
    }
    
    public StructDescriptor(final SQLName sqlName, final Connection connection) throws SQLException {
        super((short)108, sqlName, connection);
        this.sqlHint = null;
        this.initPickler();
    }
    
    public StructDescriptor(final SQLName sqlName, final OracleTypeADT oracleTypeADT, final Connection connection) throws SQLException {
        super((short)108, sqlName, oracleTypeADT, connection);
        this.sqlHint = null;
        this.toid = oracleTypeADT.getTOID();
    }
    
    StructDescriptor(final byte[] toid, final int toidVersion, final Connection physicalConnectionOf) throws SQLException {
        super((short)108);
        this.sqlHint = null;
        this.toid = toid;
        this.toidVersion = toidVersion;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.initPickler();
    }
    
    StructDescriptor(final AttributeDescriptor[] attributesDescriptor, final Connection physicalConnectionOf) throws SQLException {
        super((short)108);
        this.sqlHint = null;
        this.attributesDescriptor = attributesDescriptor;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.isTransient = true;
        this.initPickler();
        this.isInstanciable = Boolean.TRUE;
    }
    
    private void initPickler() throws SQLException {
        try {
            if (this.isTransient) {
                this.pickler = new OracleTypeADT(this.attributesDescriptor, this.connection);
            }
            else {
                this.pickler = new OracleTypeADT(this.getName(), (Connection)this.connection);
                ((OracleTypeADT)this.pickler).init(this.connection);
                this.toid = ((OracleTypeADT)this.pickler).getTOID();
            }
            this.pickler.setDescriptor(this);
        }
        catch (Exception ex) {
            if (ex instanceof SQLException) {
                throw (SQLException)ex;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"" + this.getName() + "\"");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public int getTypeCode() throws SQLException {
        return this.getOracleTypeADT().getTypeCode();
    }
    
    public int getTypeVersion() throws SQLException {
        return this.getOracleTypeADT().getTypeVersion();
    }
    
    void setAttributesDescriptor(final AttributeDescriptor[] attributesDescriptor) {
        this.attributesDescriptor = attributesDescriptor;
    }
    
    public AttributeDescriptor[] getAttributesDescriptor() {
        return this.attributesDescriptor;
    }
    
    byte[] toBytes(final STRUCT struct, final boolean b) throws SQLException {
        byte[] array = struct.shareBytes();
        if (array == null) {
            if (struct.datumArray != null) {
                array = this.pickler.linearize(struct);
                if (!b) {
                    struct.setShareBytes(null);
                }
            }
            else {
                if (struct.objectArray == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                struct.datumArray = this.toOracleArray(struct.objectArray);
                array = this.pickler.linearize(struct);
                if (!b) {
                    struct.datumArray = null;
                    struct.setShareBytes(null);
                }
            }
        }
        else if (struct.imageLength != 0L && (struct.imageOffset != 0L || struct.imageLength != array.length)) {
            final byte[] array2 = new byte[(int)struct.imageLength];
            System.arraycopy(array, (int)struct.imageOffset, array2, 0, (int)struct.imageLength);
            struct.setImage(array2, 0L, 0L);
            array = array2;
        }
        return array;
    }
    
    Datum[] toOracleArray(final STRUCT struct, final boolean b) throws SQLException {
        Datum[] datumArray = struct.datumArray;
        if (datumArray == null) {
            if (struct.objectArray != null) {
                datumArray = this.toOracleArray(struct.objectArray);
            }
            else {
                if (struct.shareBytes() == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                if ((struct.shareBytes()[0] & 0x80) <= 0 && ((OracleTypeADT)this.pickler).isEmbeddedADT()) {
                    this.pickler = OracleTypeADT.shallowClone((OracleTypeADT)this.pickler);
                }
                this.pickler.unlinearize(struct.shareBytes(), struct.imageOffset, struct, 1, null);
                datumArray = struct.datumArray;
                if (!b) {
                    struct.datumArray = null;
                }
            }
        }
        Datum[] array;
        if (b) {
            struct.datumArray = datumArray;
            array = datumArray.clone();
        }
        else {
            array = datumArray;
        }
        return array;
    }
    
    Object[] toArray(final STRUCT struct, final Map map, final boolean b) throws SQLException {
        Object[] objectArray;
        if (struct.objectArray == null) {
            if (struct.datumArray != null) {
                objectArray = new Object[struct.datumArray.length];
                for (int i = 0; i < struct.datumArray.length; ++i) {
                    if (struct.datumArray[i] != null) {
                        if (struct.datumArray[i] instanceof STRUCT) {
                            objectArray[i] = ((STRUCT)struct.datumArray[i]).toJdbc(map);
                        }
                        else {
                            objectArray[i] = struct.datumArray[i].toJdbc();
                        }
                    }
                }
            }
            else {
                if (struct.shareBytes() == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                if ((struct.shareBytes()[0] & 0x80) <= 0 && ((OracleTypeADT)this.pickler).isEmbeddedADT()) {
                    this.pickler = OracleTypeADT.shallowClone((OracleTypeADT)this.pickler);
                }
                this.pickler.unlinearize(struct.shareBytes(), struct.imageOffset, struct, 2, map);
                objectArray = struct.objectArray;
                struct.objectArray = null;
            }
        }
        else {
            objectArray = struct.objectArray.clone();
        }
        return objectArray;
    }
    
    public int getLength() throws SQLException {
        return this.getFieldTypes().length;
    }
    
    public OracleTypeADT getOracleTypeADT() throws SQLException {
        if (this.pickler == null) {
            this.initPickler();
        }
        return (OracleTypeADT)this.pickler;
    }
    
    private OracleType[] getFieldTypes() throws SQLException {
        return ((OracleTypeADT)this.pickler).getAttrTypes();
    }
    
    public SQLInput toJdbc2SQLInput(final STRUCT struct, final Map map) throws SQLException {
        return new OracleJdbc2SQLInput(this.toOracleArray(struct, false), map, this.connection);
    }
    
    public SQLOutput toJdbc2SQLOutput() throws SQLException {
        return new OracleSQLOutput(this, this.connection);
    }
    
    public Datum[] toOracleArray(final Object[] array) throws SQLException {
        Datum[] array2 = null;
        if (array != null) {
            final OracleType[] fieldTypes = this.getFieldTypes();
            final int length = fieldTypes.length;
            if (array.length != length) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            array2 = new Datum[length];
            final OracleConnection connection = this.connection;
            for (int i = 0; i < length; ++i) {
                array2[i] = fieldTypes[i].toDatum(array[i], connection);
            }
        }
        return array2;
    }
    
    public Datum[] toOracleArray(final Map map) throws SQLException {
        Datum[] array = null;
        int n = 0;
        if (map != null) {
            final OracleType[] fieldTypes = this.getFieldTypes();
            final int length = fieldTypes.length;
            final int size = map.size();
            array = new Datum[length];
            final OracleConnection connection = this.connection;
            for (int i = 0; i < length; ++i) {
                final Object value = map.get(((OracleTypeADT)this.pickler).getAttributeName(i + 1));
                array[i] = fieldTypes[i].toDatum(value, connection);
                if (value != null || map.containsKey(((OracleTypeADT)this.pickler).getAttributeName(i + 1))) {
                    ++n;
                }
            }
            if (n < size) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return array;
    }
    
    public ResultSetMetaData getMetaData() throws SQLException {
        return this.connection.newStructMetaData(this);
    }
    
    public boolean isFinalType() throws SQLException {
        return this.getOracleTypeADT().isFinalType();
    }
    
    public boolean isSubtype() throws SQLException {
        return this.getOracleTypeADT().isSubType();
    }
    
    @Override
    public boolean isInHierarchyOf(final String s) throws SQLException {
        StructDescriptor descriptor = this;
        boolean b;
        if (s.equals(descriptor.getName())) {
            b = true;
        }
        else {
            while (true) {
                final String supertypeName = descriptor.getSupertypeName();
                if (supertypeName == null) {
                    b = false;
                    break;
                }
                if (s.equals(supertypeName)) {
                    b = true;
                    break;
                }
                descriptor = createDescriptor(supertypeName, this.connection);
            }
        }
        return b;
    }
    
    public boolean isInstantiable() throws SQLException {
        if (this.isInstanciable == null) {
            this.initMetaData1();
        }
        return this.isInstanciable;
    }
    
    public boolean isJavaObject() throws SQLException {
        return this.getOracleTypeADT().isJavaObject();
    }
    
    public String getSupertypeName() throws SQLException {
        String supertype = null;
        if (this.isSubtype()) {
            if (this.supertype == null) {
                this.initMetaData1();
            }
            supertype = this.supertype;
        }
        return supertype;
    }
    
    public int getLocalAttributeCount() throws SQLException {
        int n;
        if (!this.isSubtype()) {
            n = this.getOracleTypeADT().getAttrTypes().length;
        }
        else {
            if (this.numLocalAttrs == -1) {
                this.initMetaData1();
            }
            n = this.numLocalAttrs;
        }
        return n;
    }
    
    public String[] getSubtypeNames() throws SQLException {
        if (this.subtypes == null) {
            this.initMetaData2();
        }
        return this.subtypes;
    }
    
    public String getJavaClassName() throws SQLException {
        String javaObjectClassName = null;
        if (this.isJavaObject()) {
            javaObjectClassName = getJavaObjectClassName(this.connection, this);
        }
        return javaObjectClassName;
    }
    
    public String getAttributeJavaName(final int n) throws SQLException {
        String s = null;
        if (this.isJavaObject()) {
            if (this.attrJavaNames == null) {
                this.initMetaData3();
            }
            s = this.attrJavaNames[n];
        }
        return s;
    }
    
    public String[] getAttributeJavaNames() throws SQLException {
        String[] attrJavaNames;
        if (this.isJavaObject()) {
            if (this.attrJavaNames == null) {
                this.initMetaData3();
            }
            attrJavaNames = this.attrJavaNames;
        }
        else {
            attrJavaNames = new String[0];
        }
        return attrJavaNames;
    }
    
    public String getLanguage() throws SQLException {
        String s;
        if (this.isJavaObject()) {
            s = "JAVA";
        }
        else {
            s = "SQL";
        }
        return s;
    }
    
    public Class getClass(final Map map) throws SQLException {
        Class classForType = this.connection.getClassForType(this.getName(), map);
        final String schemaName = this.getSchemaName();
        final String typeName = this.getTypeName();
        if (classForType == null) {
            classForType = map.get(typeName);
        }
        if (SQLName.s_parseAllFormat) {
            if (classForType == null && this.connection.getDefaultSchemaNameForNamedTypes().equals(schemaName)) {
                classForType = map.get("\"" + typeName + "\"");
            }
            if (classForType == null) {
                classForType = map.get("\"" + schemaName + "\"" + "." + "\"" + typeName + "\"");
            }
            if (classForType == null) {
                classForType = map.get("\"" + schemaName + "\"" + "." + typeName);
            }
            if (classForType == null) {
                classForType = map.get(schemaName + "." + "\"" + typeName + "\"");
            }
        }
        return classForType;
    }
    
    public static String getJavaObjectClassName(final Connection connection, final StructDescriptor structDescriptor) throws SQLException {
        return getJavaObjectClassName(connection, structDescriptor.getSchemaName(), structDescriptor.getTypeName());
    }
    
    public static String getJavaObjectClassName(final Connection connection, final String s, final String s2) throws SQLException {
        PreparedStatement prepareStatement = null;
        ResultSet executeQuery = null;
        String string = null;
        try {
            prepareStatement = connection.prepareStatement("select external_name from all_sqlj_types where owner = :1 and type_name = :2");
            prepareStatement.setString(1, s);
            prepareStatement.setString(2, s2);
            executeQuery = prepareStatement.executeQuery();
            if (!executeQuery.next()) {
                final SQLException sqlException = DatabaseError.createSqlException(null, 100);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            string = executeQuery.getString(1);
        }
        catch (SQLException ex) {}
        finally {
            if (executeQuery != null) {
                executeQuery.close();
            }
            if (prepareStatement != null) {
                prepareStatement.close();
            }
        }
        return string;
    }
    
    public String descType() throws SQLException {
        return this.descType(new StringBuffer(), 0);
    }
    
    String descType(final StringBuffer sb, final int n) throws SQLException {
        String string = "";
        for (int i = 0; i < n; ++i) {
            string += "  ";
        }
        final String string2 = string + "  ";
        sb.append(string);
        sb.append(this.getTypeName());
        sb.append("\n");
        sb.append(string);
        sb.append("Subtype=" + this.getOracleTypeADT().isSubType());
        sb.append(" JavaObject=" + this.getOracleTypeADT().isJavaObject());
        sb.append(" FinalType=" + this.getOracleTypeADT().isFinalType());
        sb.append("\n");
        final ResultSetMetaData metaData = this.getMetaData();
        for (int columnCount = metaData.getColumnCount(), j = 0; j < columnCount; ++j) {
            final int columnType = metaData.getColumnType(j + 1);
            if (columnType == 2002 || columnType == 2008) {
                createDescriptor(metaData.getColumnTypeName(j + 1), this.connection).descType(sb, n + 1);
            }
            else if (columnType == 2003) {
                ArrayDescriptor.createDescriptor(metaData.getColumnTypeName(j + 1), this.connection).descType(sb, n + 1);
            }
            else if (columnType == 2007) {
                OpaqueDescriptor.createDescriptor(metaData.getColumnTypeName(j + 1), this.connection).descType(sb, n + 1);
            }
            else {
                sb.append(string2);
                sb.append(metaData.getColumnTypeName(j + 1));
                sb.append("\n");
            }
        }
        return sb.substring(0, sb.length());
    }
    
    public byte[] toBytes(final Object[] array) throws SQLException {
        return this.toBytes(this.toOracleArray(array));
    }
    
    @Deprecated
    public byte[] toBytes(final Datum[] datumArray) throws SQLException {
        final STRUCT struct = new STRUCT(this, null, this.connection);
        struct.setDatumArray(datumArray);
        return this.pickler.linearize(struct);
    }
    
    public Datum[] toArray(final Object[] array) throws SQLException {
        return this.toOracleArray(array);
    }
    
    public Datum[] toArray(final byte[] array) throws SQLException {
        return this.toOracleArray(new STRUCT(this, array, this.connection), false);
    }
    
    private void initMetaData1() throws SQLException {
        if (this.connection.getVersionNumber() >= 9000) {
            this.initMetaData1_9_0();
        }
        else {
            this.initMetaData1_pre_9_0();
        }
    }
    
    private String getSqlHint() throws SQLException {
        if (this.sqlHint == null) {
            if (this.connection.getVersionNumber() >= 11000) {
                this.sqlHint = "";
            }
            else {
                this.sqlHint = "/*+RULE*/";
            }
        }
        return this.sqlHint;
    }
    
    private void initMetaData1_9_0() throws SQLException {
        synchronized (this.connection) {
            int n = 0;
            if (this.numLocalAttrs == -1) {
                PreparedStatement prepareStatement = null;
                OracleCallableStatement oracleCallableStatement = null;
                ResultSet set = null;
                int int1 = -1;
                try {
                    while (true) {
                        switch (n) {
                            case 0: {
                                prepareStatement = this.connection.prepareStatement(this.getSqlHint() + StructDescriptor.initMetaData1_9_0_SQL[n]);
                                prepareStatement.setString(1, this.getTypeName());
                                prepareStatement.setString(2, this.getSchemaName());
                                prepareStatement.setFetchSize(1);
                                set = prepareStatement.executeQuery();
                                break;
                            }
                            case 1:
                            case 2: {
                                try {
                                    oracleCallableStatement = (OracleCallableStatement)this.connection.prepareCall(this.getSqlHint() + StructDescriptor.initMetaData1_9_0_SQL[n]);
                                    oracleCallableStatement.setString(1, this.getTypeName());
                                    oracleCallableStatement.registerOutParameter(2, -10);
                                    oracleCallableStatement.execute();
                                    set = oracleCallableStatement.getCursor(2);
                                    set.setFetchSize(1);
                                }
                                catch (SQLException ex) {
                                    if (ex.getErrorCode() != 1403) {
                                        throw ex;
                                    }
                                    if (n == 1) {
                                        oracleCallableStatement.close();
                                        ++n;
                                        continue;
                                    }
                                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
                                    sqlException.fillInStackTrace();
                                    throw sqlException;
                                }
                                break;
                            }
                        }
                        if (set.next()) {
                            this.isInstanciable = set.getString(1).equals("YES");
                            this.supertype = set.getString(2) + "." + set.getString(3);
                            int1 = set.getInt(4);
                            break;
                        }
                        if (n == 2) {
                            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
                            sqlException2.fillInStackTrace();
                            throw sqlException2;
                        }
                        set.close();
                        if (oracleCallableStatement != null) {
                            oracleCallableStatement.close();
                        }
                        ++n;
                    }
                }
                finally {
                    if (set != null) {
                        set.close();
                    }
                    if (prepareStatement != null) {
                        prepareStatement.close();
                    }
                    if (oracleCallableStatement != null) {
                        oracleCallableStatement.close();
                    }
                }
                this.numLocalAttrs = int1;
            }
        }
    }
    
    private void initMetaData1_pre_9_0() throws SQLException {
        synchronized (this.connection) {
            this.isInstanciable = Boolean.TRUE;
            this.supertype = "";
            this.numLocalAttrs = 0;
        }
    }
    
    private void initMetaData2() throws SQLException {
        if (this.connection.getVersionNumber() >= 9000) {
            this.initMetaData2_9_0();
        }
        else {
            this.initMetaData2_pre_9_0();
        }
    }
    
    private void initMetaData2_9_0() throws SQLException {
        synchronized (this.connection) {
            if (this.subtypes == null) {
                PreparedStatement prepareStatement = null;
                ResultSet executeQuery = null;
                String[] subtypes = null;
                try {
                    prepareStatement = this.connection.prepareStatement("select owner, type_name from all_types where supertype_name = :1 and supertype_owner = :2");
                    prepareStatement.setString(1, this.getTypeName());
                    prepareStatement.setString(2, this.getSchemaName());
                    executeQuery = prepareStatement.executeQuery();
                    final Vector<String> vector = new Vector<String>();
                    while (executeQuery.next()) {
                        vector.addElement(executeQuery.getString(1) + "." + executeQuery.getString(2));
                    }
                    subtypes = new String[vector.size()];
                    for (int i = 0; i < subtypes.length; ++i) {
                        subtypes[i] = vector.elementAt(i);
                    }
                    vector.removeAllElements();
                }
                finally {
                    if (executeQuery != null) {
                        executeQuery.close();
                    }
                    if (prepareStatement != null) {
                        prepareStatement.close();
                    }
                }
                this.subtypes = subtypes;
            }
        }
    }
    
    private void initMetaData2_pre_9_0() throws SQLException {
        this.subtypes = new String[0];
    }
    
    private void initMetaData3() throws SQLException {
        synchronized (this.connection) {
            if (this.attrJavaNames == null) {
                String[] attrJavaNames = null;
                PreparedStatement prepareStatement = null;
                ResultSet executeQuery = null;
                try {
                    prepareStatement = this.connection.prepareStatement("select EXTERNAL_ATTR_NAME from all_sqlj_type_attrs where owner = :1 and type_name = :2");
                    prepareStatement.setString(1, this.getSchemaName());
                    prepareStatement.setString(2, this.getTypeName());
                    executeQuery = prepareStatement.executeQuery();
                    attrJavaNames = new String[this.getOracleTypeADT().getAttrTypes().length];
                    int n = 0;
                    while (executeQuery.next()) {
                        attrJavaNames[n] = executeQuery.getString(1);
                        ++n;
                    }
                }
                finally {
                    if (executeQuery != null) {
                        executeQuery.close();
                    }
                    if (prepareStatement != null) {
                        prepareStatement.close();
                    }
                }
                this.attrJavaNames = attrJavaNames;
            }
        }
    }
    
    @Override
    String tagName() {
        return "StructDescriptor";
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
    }
    
    static {
        initMetaData1_9_0_SQL = new String[] { "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT  TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT  INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT  TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT  INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;" };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
