// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;

class AnyDataFactory implements ORADataFactory
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    public ORAData create(final Datum datum, final int n) throws SQLException {
        if (datum == null) {
            return null;
        }
        if (datum instanceof OPAQUE) {
            return new ANYDATA((OPAQUE)datum);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "expected oracle.sql.OPAQUE got: " + datum.getClass().getName());
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
