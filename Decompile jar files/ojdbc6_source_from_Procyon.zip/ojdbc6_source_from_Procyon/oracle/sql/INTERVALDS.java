// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.StringTokenizer;

public class INTERVALDS extends Datum
{
    private static int MAXLEADPREC;
    private static int MAXHOUR;
    private static int MAXMINUTE;
    private static int MAXSECOND;
    private static int INTERVALDSMAXLENGTH;
    private static int INTERVALDSOFFSET;
    private static int INTERVALDAYOFFSET;
    
    public INTERVALDS() {
        super(_initIntervalDS());
    }
    
    public INTERVALDS(final byte[] array) {
        super(array);
    }
    
    public INTERVALDS(final String s) {
        super(toBytes(s));
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    public static byte[] toBytes(final String s) {
        final byte[] array = new byte[INTERVALDS.INTERVALDSMAXLENGTH];
        final String trim = s.trim();
        final char char1 = trim.charAt(0);
        int beginIndex;
        if (char1 != '-' && char1 != '+') {
            beginIndex = 0;
        }
        else {
            beginIndex = 1;
        }
        final String substring = trim.substring(beginIndex);
        final int index = substring.indexOf(32);
        final String substring2 = substring.substring(0, index);
        if (substring2.length() > INTERVALDS.MAXLEADPREC) {
            throw new NumberFormatException();
        }
        final StringTokenizer stringTokenizer = new StringTokenizer(substring.substring(index + 1), ":.");
        if (!stringTokenizer.hasMoreTokens()) {
            throw new NumberFormatException();
        }
        String nextToken;
        String nextToken2;
        String nextToken3;
        String nextToken4;
        try {
            nextToken = stringTokenizer.nextToken();
            nextToken2 = stringTokenizer.nextToken();
            nextToken3 = stringTokenizer.nextToken();
            nextToken4 = stringTokenizer.nextToken();
        }
        catch (Exception ex) {
            throw new NumberFormatException();
        }
        int intValue = Integer.valueOf(substring2);
        int intValue2 = Integer.valueOf(nextToken);
        int intValue3 = Integer.valueOf(nextToken2);
        int intValue4 = Integer.valueOf(nextToken3);
        if (intValue2 > INTERVALDS.MAXHOUR) {
            throw new NumberFormatException();
        }
        if (intValue3 > INTERVALDS.MAXMINUTE) {
            throw new NumberFormatException();
        }
        if (intValue4 > INTERVALDS.MAXSECOND) {
            throw new NumberFormatException();
        }
        if (nextToken4.length() <= INTERVALDS.MAXLEADPREC) {
            int n;
            if (nextToken4.length() < INTERVALDS.MAXLEADPREC) {
                final char[] value = new char[INTERVALDS.MAXLEADPREC];
                int i;
                for (i = 0; i < nextToken4.length(); ++i) {
                    value[i] = nextToken4.charAt(i);
                }
                for (int j = i; j < INTERVALDS.MAXLEADPREC; ++j) {
                    value[j] = '0';
                }
                n = Integer.valueOf(new String(value));
            }
            else {
                n = Integer.valueOf(nextToken4);
            }
            if (char1 == '-') {
                intValue = -intValue;
                intValue2 = -intValue2;
                intValue3 = -intValue3;
                intValue4 = -intValue4;
                n = -n;
            }
            final int n2 = intValue + INTERVALDS.INTERVALDAYOFFSET;
            array[0] = utilpack.RIGHTSHIFTFIRSTNIBBLE(n2);
            array[1] = utilpack.RIGHTSHIFTSECONDNIBBLE(n2);
            array[2] = utilpack.RIGHTSHIFTTHIRDNIBBLE(n2);
            array[3] = utilpack.RIGHTSHIFTFOURTHNIBBLE(n2);
            array[4] = (byte)(intValue2 + INTERVALDS.INTERVALDSOFFSET);
            array[5] = (byte)(intValue3 + INTERVALDS.INTERVALDSOFFSET);
            array[6] = (byte)(intValue4 + INTERVALDS.INTERVALDSOFFSET);
            final int n3 = n + INTERVALDS.INTERVALDAYOFFSET;
            array[7] = utilpack.RIGHTSHIFTFIRSTNIBBLE(n3);
            array[8] = utilpack.RIGHTSHIFTSECONDNIBBLE(n3);
            array[9] = utilpack.RIGHTSHIFTTHIRDNIBBLE(n3);
            array[10] = utilpack.RIGHTSHIFTFOURTHNIBBLE(n3);
            return array;
        }
        throw new NumberFormatException();
    }
    
    public static String toString(final byte[] array) {
        boolean b = true;
        int n = (utilpack.LEFTSHIFTFIRSTNIBBLE(array[0]) | utilpack.LEFTSHIFTSECONDNIBBLE(array[1]) | utilpack.LEFTSHIFTTHIRDNIBBLE(array[2]) | (array[3] & 0xFF)) - INTERVALDS.INTERVALDAYOFFSET;
        int n2 = array[4] - INTERVALDS.INTERVALDSOFFSET;
        int n3 = array[5] - INTERVALDS.INTERVALDSOFFSET;
        int n4 = array[6] - INTERVALDS.INTERVALDSOFFSET;
        int i = (utilpack.LEFTSHIFTFIRSTNIBBLE(array[7]) | utilpack.LEFTSHIFTSECONDNIBBLE(array[8]) | utilpack.LEFTSHIFTTHIRDNIBBLE(array[9]) | (array[10] & 0xFF)) - INTERVALDS.INTERVALDAYOFFSET;
        if (n < 0) {
            b = false;
            n = -n;
            n2 = -n2;
            n3 = -n3;
            n4 = -n4;
            i = -i;
        }
        else if (n2 < 0) {
            b = false;
            n2 = -n2;
            n3 = -n3;
            n4 = -n4;
            i = -i;
        }
        else if (n3 < 0) {
            b = false;
            n3 = -n3;
            n4 = -n4;
            i = -i;
        }
        else if (n4 < 0) {
            b = false;
            n4 = -n4;
            i = -i;
        }
        else if (i < 0) {
            b = false;
            i = -i;
        }
        final String format = String.format("%09d", i);
        char[] charArray;
        int length;
        for (charArray = format.toCharArray(), length = charArray.length; length > 1 && charArray[length - 1] == '0'; --length) {}
        final String substring = format.substring(0, length);
        if (b) {
            return n + " " + n2 + ":" + n3 + ":" + n4 + "." + substring;
        }
        return "-" + n + " " + n2 + ":" + n3 + ":" + n4 + "." + substring;
    }
    
    @Override
    public Object toJdbc() {
        return this;
    }
    
    @Override
    public String stringValue() {
        return toString(this.getBytes());
    }
    
    @Override
    public String toString() {
        return toString(this.getBytes());
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new INTERVALDS[n];
    }
    
    private static byte[] _initIntervalDS() {
        final byte[] array = new byte[INTERVALDS.INTERVALDSMAXLENGTH];
        final int n = 0;
        final int n2 = 0;
        final int n3 = 0;
        final int n4 = 0;
        final int n5 = 0;
        final int n6 = n + INTERVALDS.INTERVALDAYOFFSET;
        array[0] = utilpack.RIGHTSHIFTFIRSTNIBBLE(n6);
        array[1] = utilpack.RIGHTSHIFTSECONDNIBBLE(n6);
        array[2] = utilpack.RIGHTSHIFTTHIRDNIBBLE(n6);
        array[3] = utilpack.RIGHTSHIFTFOURTHNIBBLE(n6);
        array[4] = (byte)(n2 + INTERVALDS.INTERVALDSOFFSET);
        array[5] = (byte)(n3 + INTERVALDS.INTERVALDSOFFSET);
        array[6] = (byte)(n4 + INTERVALDS.INTERVALDSOFFSET);
        final int n7 = n5 + INTERVALDS.INTERVALDAYOFFSET;
        array[7] = utilpack.RIGHTSHIFTFIRSTNIBBLE(n7);
        array[8] = utilpack.RIGHTSHIFTSECONDNIBBLE(n7);
        array[9] = utilpack.RIGHTSHIFTTHIRDNIBBLE(n7);
        array[10] = utilpack.RIGHTSHIFTFOURTHNIBBLE(n7);
        return array;
    }
    
    static {
        INTERVALDS.MAXLEADPREC = 9;
        INTERVALDS.MAXHOUR = 23;
        INTERVALDS.MAXMINUTE = 59;
        INTERVALDS.MAXSECOND = 59;
        INTERVALDS.INTERVALDSMAXLENGTH = 11;
        INTERVALDS.INTERVALDSOFFSET = 60;
        INTERVALDS.INTERVALDAYOFFSET = Integer.MIN_VALUE;
    }
}
