// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

class CharacterSetAL32UTF8 extends CharacterSet implements CharacterRepConstants
{
    private static int[] m_byteLen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetAL32UTF8(final int n) {
        super(n);
        this.rep = 6;
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return !set.isUnicode();
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.rep <= 1024;
    }
    
    @Override
    public boolean isUnicode() {
        return true;
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        try {
            final char[] value = new char[array.length];
            return new String(value, 0, CharacterSet.convertAL32UTF8BytesToJavaChars(array, n, value, 0, new int[] { n2 }, true));
        }
        catch (SQLException ex) {
            return "";
        }
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        try {
            final char[] value = new char[array.length];
            return new String(value, 0, CharacterSet.convertAL32UTF8BytesToJavaChars(array, n, value, 0, new int[] { n2 }, false));
        }
        catch (SQLException ex) {
            failUTFConversion();
            return "";
        }
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        return CharacterSet.stringToAL32UTF8(s);
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        return CharacterSet.stringToAL32UTF8(s);
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        byte[] array2;
        if (set.rep == 6) {
            array2 = CharacterSet.useOrCopy(array, n, n2);
        }
        else {
            array2 = CharacterSet.stringToAL32UTF8(set.toString(array, n, n2));
        }
        return array2;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        final byte[] bytes = characterWalker.bytes;
        final int next = characterWalker.next;
        final int end = characterWalker.end;
        if (next >= end) {
            failUTFConversion();
        }
        final int utfByteLength = getUTFByteLength(bytes[next]);
        if (utfByteLength == 0 || next + (utfByteLength - 1) >= end) {
            failUTFConversion();
        }
        try {
            final char[] array = new char[2];
            final int convertAL32UTF8BytesToJavaChars = CharacterSet.convertAL32UTF8BytesToJavaChars(bytes, next, array, 0, new int[] { utfByteLength }, false);
            characterWalker.next += utfByteLength;
            if (convertAL32UTF8BytesToJavaChars == 1) {
                return array[0];
            }
            return array[0] << 16 | array[1];
        }
        catch (SQLException ex) {
            failUTFConversion();
            return 0;
        }
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        int n2;
        if ((n & 0xFFFF0000) != 0x0) {
            CharacterSet.need(characterBuffer, 4);
            n2 = CharacterSet.convertJavaCharsToAL32UTF8Bytes(new char[] { (char)(n >>> 16), (char)n }, 0, characterBuffer.bytes, characterBuffer.next, 2);
        }
        else {
            CharacterSet.need(characterBuffer, 3);
            n2 = CharacterSet.convertJavaCharsToAL32UTF8Bytes(new char[] { (char)n }, 0, characterBuffer.bytes, characterBuffer.next, 1);
        }
        characterBuffer.next += n2;
    }
    
    private static int getUTFByteLength(final byte b) {
        return CharacterSetAL32UTF8.m_byteLen[b >>> 4 & 0xF];
    }
    
    @Override
    public int encodedByteLength(final String s) {
        return CharacterSet.string32UTF8Length(s);
    }
    
    @Override
    public int encodedByteLength(final char[] array) {
        return CharacterSet.charArray32UTF8Length(array);
    }
    
    static {
        CharacterSetAL32UTF8.m_byteLen = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 2, 3, 4 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
