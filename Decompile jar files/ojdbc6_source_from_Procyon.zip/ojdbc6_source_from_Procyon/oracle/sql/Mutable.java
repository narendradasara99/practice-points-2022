// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

public interface Mutable
{
    void copy(final CustomDatum p0);
}
