// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.Map;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.OracleConnection;
import java.sql.Connection;
import java.sql.Array;

public class ARRAY extends DatumWithConnection implements Array
{
    static final byte KOPUP_INLINE_COLL = 1;
    ArrayDescriptor descriptor;
    Object objArray;
    Datum[] datumArray;
    byte[] locator;
    byte prefixFlag;
    byte[] prefixSegment;
    int numElems;
    boolean enableBuffering;
    boolean enableIndexing;
    public static final int ACCESS_FORWARD = 1;
    public static final int ACCESS_REVERSE = 2;
    public static final int ACCESS_UNKNOWN = 3;
    int accessDirection;
    long lastIndex;
    long lastOffset;
    long[] indexArray;
    long imageOffset;
    long imageLength;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public ARRAY(final ArrayDescriptor descriptor, final Connection connection, final Object o) throws SQLException {
        this.numElems = -1;
        this.enableBuffering = false;
        this.enableIndexing = false;
        this.accessDirection = 3;
        DatumWithConnection.assertNotNull(descriptor);
        this.descriptor = descriptor;
        DatumWithConnection.assertNotNull(connection);
        if (!descriptor.getInternalConnection().isDescriptorSharable(((OracleConnection)connection).physicalConnectionWithin())) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct ARRAY instance,invalid connection");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        descriptor.setConnection(connection);
        this.setPhysicalConnectionOf(connection);
        if (o == null) {
            this.datumArray = new Datum[0];
        }
        else {
            this.datumArray = this.descriptor.toOracleArray(o, 1L, -1);
        }
    }
    
    public ARRAY(final ArrayDescriptor descriptor, final byte[] array, final Connection connection) throws SQLException {
        super(array);
        this.numElems = -1;
        this.enableBuffering = false;
        this.enableIndexing = false;
        this.accessDirection = 3;
        DatumWithConnection.assertNotNull(descriptor);
        this.descriptor = descriptor;
        DatumWithConnection.assertNotNull(connection);
        if (!descriptor.getInternalConnection().isDescriptorSharable(((OracleConnection)connection).physicalConnectionWithin())) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct ARRAY instance,invalid connection");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        descriptor.setConnection(connection);
        this.setPhysicalConnectionOf(connection);
        this.datumArray = null;
        this.locator = null;
    }
    
    public static ARRAY toARRAY(final Object o, final OracleConnection oracleConnection) throws SQLException {
        ARRAY array = null;
        if (o != null) {
            if (o instanceof ARRAY) {
                array = (ARRAY)o;
            }
            else if (o instanceof ORAData) {
                array = (ARRAY)((ORAData)o).toDatum(oracleConnection);
            }
            else {
                if (!(o instanceof CustomDatum)) {
                    final SQLException sqlException = DatabaseError.createSqlException(null, 59, o);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                array = (ARRAY)oracleConnection.physicalConnectionWithin().toDatum((CustomDatum)o);
            }
        }
        return array;
    }
    
    @Override
    public String getBaseTypeName() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.getBaseName();
        }
    }
    
    @Override
    public int getBaseType() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.getBaseType();
        }
    }
    
    @Override
    public Object getArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toJavaArray(this, 1L, -1, this.getMap(), this.enableBuffering);
        }
    }
    
    @Override
    public Object getArray(final Map map) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toJavaArray(this, 1L, -1, map, this.enableBuffering);
        }
    }
    
    @Override
    public Object getArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            if (n < 1L || n2 < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "Invalid arguments,'index' should be >= 1 and 'count' >= 0. An exception is thrown.");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.descriptor.toJavaArray(this, n, n2, this.getMap(), false);
        }
    }
    
    @Override
    public Object getArray(final long n, final int n2, final Map map) throws SQLException {
        synchronized (this.getInternalConnection()) {
            if (n < 1L || n2 < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "Invalid arguments,'index' should be >= 1 and 'count' >= 0. An exception is thrown.");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.descriptor.toJavaArray(this, n, n2, map, false);
        }
    }
    
    @Override
    public ResultSet getResultSet() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.getResultSet(this.getInternalConnection().getTypeMap());
        }
    }
    
    @Override
    public ResultSet getResultSet(final Map map) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toResultSet(this, 1L, -1, map, this.enableBuffering);
        }
    }
    
    @Override
    public ResultSet getResultSet(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.getResultSet(n, n2, this.getInternalConnection().getTypeMap());
        }
    }
    
    @Override
    public ResultSet getResultSet(final long n, final int n2, final Map map) throws SQLException {
        synchronized (this.getInternalConnection()) {
            if (n < 1L || n2 < -1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getResultSet()");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.descriptor.toResultSet(this, n, n2, map, false);
        }
    }
    
    public Datum[] getOracleArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toOracleArray(this, 1L, -1, this.enableBuffering);
        }
    }
    
    public int length() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toLength(this);
        }
    }
    
    public Datum[] getOracleArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            if (n < 1L || n2 < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getOracleArray()");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.descriptor.toOracleArray(this, n, n2, false);
        }
    }
    
    public String getSQLTypeName() throws SQLException {
        synchronized (this.getInternalConnection()) {
            if (this.descriptor != null) {
                return this.descriptor.getName();
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 61, "ARRAY");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public Map getMap() throws SQLException {
        return this.getInternalConnection().getTypeMap();
    }
    
    public ArrayDescriptor getDescriptor() throws SQLException {
        return this.descriptor;
    }
    
    public byte[] toBytes() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toBytes(this, this.enableBuffering);
        }
    }
    
    public void setDatumArray(final Datum[] datumArray) {
        this.datumArray = datumArray;
    }
    
    public void setObjArray(final Object objArray) throws SQLException {
        synchronized (this.getInternalConnection()) {
            if (objArray == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Invalid argument,'oarray' should not be null. An exception is thrown.");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.objArray = objArray;
        }
    }
    
    public void setLocator(final byte[] locator) {
        if (locator != null && locator.length != 0) {
            this.locator = locator;
        }
    }
    
    public void setPrefixSegment(final byte[] prefixSegment) {
        if (prefixSegment != null && prefixSegment.length != 0) {
            this.prefixSegment = prefixSegment;
        }
    }
    
    public void setPrefixFlag(final byte prefixFlag) {
        this.prefixFlag = prefixFlag;
    }
    
    public byte[] getLocator() {
        return this.locator;
    }
    
    public void setLength(final int numElems) {
        this.numElems = numElems;
    }
    
    public boolean hasDataSeg() {
        return this.locator == null;
    }
    
    public boolean isInline() {
        return (this.prefixFlag & 0x1) == 0x1;
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return false;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Object[n][];
    }
    
    public int[] getIntArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (int[])this.descriptor.toNumericArray(this, 1L, -1, 4, this.enableBuffering);
        }
    }
    
    public int[] getIntArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (int[])this.descriptor.toNumericArray(this, n, n2, 4, false);
        }
    }
    
    public double[] getDoubleArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (double[])this.descriptor.toNumericArray(this, 1L, -1, 5, this.enableBuffering);
        }
    }
    
    public double[] getDoubleArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (double[])this.descriptor.toNumericArray(this, n, n2, 5, false);
        }
    }
    
    public short[] getShortArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (short[])this.descriptor.toNumericArray(this, 1L, -1, 8, this.enableBuffering);
        }
    }
    
    public short[] getShortArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (short[])this.descriptor.toNumericArray(this, n, n2, 8, false);
        }
    }
    
    public long[] getLongArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (long[])this.descriptor.toNumericArray(this, 1L, -1, 7, this.enableBuffering);
        }
    }
    
    public long[] getLongArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (long[])this.descriptor.toNumericArray(this, n, n2, 7, false);
        }
    }
    
    public float[] getFloatArray() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (float[])this.descriptor.toNumericArray(this, 1L, -1, 6, this.enableBuffering);
        }
    }
    
    public float[] getFloatArray(final long n, final int n2) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return (float[])this.descriptor.toNumericArray(this, n, n2, 6, false);
        }
    }
    
    public void setAutoBuffering(final boolean enableBuffering) throws SQLException {
        synchronized (this.getInternalConnection()) {
            this.enableBuffering = enableBuffering;
        }
    }
    
    public boolean getAutoBuffering() throws SQLException {
        return this.enableBuffering;
    }
    
    public void setAutoIndexing(final boolean enableIndexing, final int accessDirection) throws SQLException {
        synchronized (this.getInternalConnection()) {
            this.enableIndexing = enableIndexing;
            this.accessDirection = accessDirection;
        }
    }
    
    public void setAutoIndexing(final boolean enableIndexing) throws SQLException {
        synchronized (this.getInternalConnection()) {
            this.enableIndexing = enableIndexing;
            this.accessDirection = 3;
        }
    }
    
    public boolean getAutoIndexing() throws SQLException {
        return this.enableIndexing;
    }
    
    public int getAccessDirection() throws SQLException {
        return this.accessDirection;
    }
    
    public void setLastIndexOffset(final long lastIndex, final long lastOffset) throws SQLException {
        this.lastIndex = lastIndex;
        this.lastOffset = lastOffset;
    }
    
    public void setIndexOffset(final long n, final long n2) throws SQLException {
        if (this.indexArray == null) {
            this.indexArray = new long[this.numElems];
        }
        this.indexArray[(int)n - 1] = n2;
    }
    
    public long getLastIndex() throws SQLException {
        return this.lastIndex;
    }
    
    public long getLastOffset() throws SQLException {
        return this.lastOffset;
    }
    
    public long getOffset(final long n) throws SQLException {
        long n2 = -1L;
        if (this.indexArray != null) {
            n2 = this.indexArray[(int)n - 1];
        }
        return n2;
    }
    
    public void setImage(final byte[] shareBytes, final long imageOffset, final long imageLength) throws SQLException {
        this.setShareBytes(shareBytes);
        this.imageOffset = imageOffset;
        this.imageLength = imageLength;
    }
    
    public void setImageLength(final long imageLength) throws SQLException {
        this.imageLength = imageLength;
    }
    
    public long getImageOffset() {
        return this.imageOffset;
    }
    
    public long getImageLength() {
        return this.imageLength;
    }
    
    public String dump() throws SQLException {
        return STRUCT.dump(this);
    }
    
    static void dump(final ARRAY array, final PrintWriter printWriter, final int n) throws SQLException {
        if (n > 0) {
            printWriter.println();
        }
        final ArrayDescriptor descriptor = array.getDescriptor();
        for (int i = 0; i < n; ++i) {
            printWriter.print(' ');
        }
        printWriter.println("name = " + descriptor.getName());
        for (int j = 0; j < n; ++j) {
            printWriter.print(' ');
        }
        printWriter.println("max length = " + descriptor.getMaxLength());
        final Object[] array2 = (Object[])array.getArray();
        for (int k = 0; k < n; ++k) {
            printWriter.print(' ');
        }
        final int length;
        printWriter.println("length = " + (length = array2.length));
        for (int l = 0; l < length; ++l) {
            for (int n2 = 0; n2 < n; ++n2) {
                printWriter.print(' ');
            }
            printWriter.print("element[" + l + "] = ");
            STRUCT.dump(array2[l], printWriter, n + 4);
        }
    }
    
    @Override
    public void free() throws SQLException {
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
