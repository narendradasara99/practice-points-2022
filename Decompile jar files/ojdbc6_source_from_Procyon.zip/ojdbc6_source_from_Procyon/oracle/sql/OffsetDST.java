// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.Timestamp;

public class OffsetDST
{
    private Timestamp timestamp;
    private int offset;
    private byte DSTflag;
    
    public OffsetDST(final Timestamp timestamp, final int offset, final byte dsTflag) {
        this.timestamp = timestamp;
        this.offset = offset;
        this.DSTflag = dsTflag;
    }
    
    public OffsetDST() {
        this.timestamp = new Timestamp(0L);
        this.offset = 0;
        this.DSTflag = 0;
    }
    
    public int getOFFSET() {
        return this.offset;
    }
    
    public byte getDSTFLAG() {
        return this.DSTflag;
    }
    
    public Timestamp getTimestamp() {
        return this.timestamp;
    }
    
    public void setOFFSET(final int offset) {
        this.offset = offset;
    }
    
    public void setDSTFLAG(final byte dsTflag) {
        this.DSTflag = dsTflag;
    }
    
    public long getTime() {
        return this.timestamp.getTime();
    }
}
