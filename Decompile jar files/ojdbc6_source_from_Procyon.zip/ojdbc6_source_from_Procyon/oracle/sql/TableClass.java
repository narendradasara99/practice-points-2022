// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.HashMap;

class TableClass
{
    private HashMap<String, Integer> zoneToIdMap;
    private HashMap<Integer, String> idToZoneMap;
    private HashMap<Integer, String> oldIdToZoneMap;
    
    TableClass(final int n, final float n2) {
        this.zoneToIdMap = new HashMap<String, Integer>(n, n2);
        this.idToZoneMap = new HashMap<Integer, String>(n, n2);
        this.oldIdToZoneMap = new HashMap<Integer, String>(10, 0.99f);
    }
    
    void put(final String s, final Integer n) {
        this.zoneToIdMap.put(s, n);
        this.idToZoneMap.put(n, s);
    }
    
    void putOld(final String value, final Integer key) {
        this.oldIdToZoneMap.put(key, value);
    }
    
    Integer getID(final String key) {
        return this.zoneToIdMap.get(key);
    }
    
    String getZone(final Integer key) {
        return this.idToZoneMap.get(key);
    }
    
    String getOldZone(final Integer key) {
        return this.oldIdToZoneMap.get(key);
    }
}
