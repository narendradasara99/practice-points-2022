// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import oracle.jdbc.oracore.PickleContext;
import oracle.jdbc.oracore.OracleTypeCOLLECTION;
import oracle.jdbc.oracore.OracleTypeOPAQUE;
import java.lang.reflect.Field;
import oracle.jdbc.oracore.OracleTypeADT;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleNamedType;
import java.io.Serializable;

public class TypeDescriptor implements Serializable, ORAData
{
    public static boolean DEBUG_SERIALIZATION;
    static final long serialVersionUID = 2022598722047823723L;
    static final int KOIDFLEN = 16;
    static final short KOTA_TRN = 1;
    static final short KOTA_PDF = 2;
    static final short KOTA_ITOID = 4;
    static final short KOTA_LOB = 8;
    static final short KOTA_AD = 16;
    static final short KOTA_NMHSH = 32;
    static final short KOTA_TEV = 64;
    static final short KOTA_INH = 128;
    static final short KOTA_10I = 256;
    static final short KOTA_RBF = 512;
    static final short KOTA_HBF = 1024;
    static final int ANYTYPE_IMAGE_SIZE_TOID = 23;
    static final int ANYTYPE_IMAGE_SIZE_NO_TOID = 5;
    static final byte KOTTDOID = 1;
    static final byte KOTTBOID = 2;
    static final byte KOTADOID = 3;
    static final byte KOTREFOID = 4;
    static final byte KOTMDOID = 5;
    static final byte KOTMIOID = 6;
    static final byte KOTEXOID = 7;
    static final byte KOTDATOID = 8;
    static final byte KOTBYTOID = 9;
    static final byte KOTSHOOID = 10;
    static final byte KOTLONOID = 11;
    static final byte KOTREAOID = 12;
    static final byte KOTDOUOID = 13;
    static final byte KOTFLOOID = 14;
    static final byte KOTNUMOID = 15;
    static final byte KOTDECOID = 16;
    static final byte KOTUBYOID = 17;
    static final byte KOTUSHOID = 18;
    static final byte KOTULOOID = 19;
    static final byte KOTOCTOID = 20;
    static final byte KOTSMLOID = 21;
    static final byte KOTINTOID = 22;
    static final byte KOTRAWOID = 23;
    static final byte KOTPTROID = 24;
    static final byte KOTVSIOID = 25;
    static final byte KOTFSIOID = 26;
    static final byte KOTVSOOID = 27;
    static final byte KOTMLSOID = 28;
    static final byte KOTVAROID = 29;
    static final byte KOTMSTOID = 30;
    static final byte KOTNATOID = 31;
    static final byte KOTDOMOID = 32;
    static final byte KOTUND1OID = 33;
    static final byte KOTCLBOID = 34;
    static final byte KOTBLBOID = 35;
    static final byte KOTCFLOID = 36;
    static final byte KOTBFLOID = 37;
    static final byte KOTOIDOID = 38;
    static final byte KOTCAROID = 39;
    static final byte KOTCANOID = 40;
    static final byte KOTLPTOID = 41;
    static final byte KOTBRIOID = 42;
    static final byte KOTUCOOID = 43;
    static final byte KOTRECOID = 44;
    static final byte KOTRCUOID = 45;
    static final byte KOTBOOOID = 46;
    static final byte KOTRIDOID = 47;
    static final byte KOTPLOOID = 48;
    static final byte KOTPLROID = 49;
    static final byte KOTPBIOID = 50;
    static final byte KOTPINOID = 51;
    static final byte KOTPNAOID = 52;
    static final byte KOTPNNOID = 53;
    static final byte KOTPPOOID = 54;
    static final byte KOTPPNOID = 55;
    static final byte KOTPSTOID = 56;
    static final byte KOTEX1OID = 57;
    static final byte KOTOPQOID = 58;
    static final byte KOTTMOID = 59;
    static final byte KOTTMTZOID = 60;
    static final byte KOTTSOID = 61;
    static final byte KOTTSTZOID = 62;
    static final byte KOTIYMOID = 63;
    static final byte KOTIDSOID = 64;
    static final byte KOTTSIMPTZOID = 65;
    static final byte KOTTBXOID = 66;
    static final byte KOTADXOID = 67;
    static final byte KOTOIDBFLT = 68;
    static final byte KOTOIDBDBL = 69;
    static final byte KOTURDOID = 70;
    static final byte KOTLASTOID = 71;
    static final byte[] KOTTDEXTOID;
    static final byte[] KOTTBEXTOID;
    static final byte[] KOTADEXTOID;
    static final byte[] KOTMDEXTOID;
    static final byte[] KOTTBXEXTOID;
    static final byte[] KOTADXEXTOID;
    static final byte[] KOTTDTOID;
    static final byte[] KOTTBTOID;
    static final byte[] KOTADTOID;
    static final byte[] KOTMDTOID;
    static final byte[] KOTMITOID;
    static final byte[] KOTEXTOID;
    static final byte[] KOTEX1TOID;
    static final byte[] KOTTBXTOID;
    static final byte[] KOTADXTOID;
    public static final byte[] RAWTOID;
    public static final byte[] ANYTYPETOID;
    public static final byte[] ANYDATATOID;
    public static final byte[] ANYDATASETTOID;
    public static final byte[] XMLTYPETOID;
    static final short SQLT_NONE = 0;
    static final short SQLT_CHR = 1;
    static final short SQLT_NUM = 2;
    static final short SQLT_INT = 3;
    static final short SQLT_FLT = 4;
    static final short SQLT_STR = 5;
    static final short SQLT_VNU = 6;
    static final short SQLT_PDN = 7;
    static final short SQLT_LNG = 8;
    static final short SQLT_VCS = 9;
    static final short SQLT_NON = 10;
    static final short SQLT_RID = 11;
    static final short SQLT_DAT = 12;
    static final short SQLT_VBI = 15;
    static final short SQLT_BFLOAT = 21;
    static final short SQLT_BDOUBLE = 22;
    static final short SQLT_BIN = 23;
    static final short SQLT_LBI = 24;
    static final short SQLT_UIN = 68;
    static final short SQLT_SLS = 91;
    static final short SQLT_LVC = 94;
    static final short SQLT_LVB = 95;
    static final short SQLT_AFC = 96;
    static final short SQLT_AVC = 97;
    static final short SQLT_IBFLOAT = 100;
    static final short SQLT_IBDOUBLE = 101;
    static final short SQLT_CUR = 102;
    static final short SQLT_RDD = 104;
    static final short SQLT_LAB = 105;
    static final short SQLT_OSL = 106;
    static final short SQLT_NTY = 108;
    static final short SQLT_REF = 110;
    static final short SQLT_CLOB = 112;
    static final short SQLT_BLOB = 113;
    static final short SQLT_BFILEE = 114;
    static final short SQLT_FILE = 114;
    static final short SQLT_CFILEE = 115;
    static final short SQLT_RSET = 116;
    static final short SQLT_SVT = 118;
    static final short SQLT_NCO = 122;
    static final short SQLT_DTR = 152;
    static final short SQLT_DUN = 153;
    static final short SQLT_DOP = 154;
    static final short SQLT_VST = 155;
    static final short SQLT_ODT = 156;
    static final short SQLT_DOL = 172;
    static final short SQLT_DATE = 184;
    static final short SQLT_TIME = 185;
    static final short SQLT_TIME_TZ = 186;
    static final short SQLT_TIMESTAMP = 187;
    static final short SQLT_TIMESTAMP_TZ = 188;
    static final short SQLT_INTERVAL_YM = 189;
    static final short SQLT_INTERVAL_DS = 190;
    static final short SQLT_TIMESTAMP_LTZ = 232;
    static final short SQLT_PNTY = 241;
    static final short SQLT_CFILE = 115;
    static final short SQLT_BFILE = 114;
    static final short SQLT_REC = 250;
    static final short SQLT_TAB = 251;
    static final short SQLT_BOL = 252;
    static final short SQLCS_IMPLICIT = 1;
    static final short SQLCS_NCHAR = 2;
    static final short SQLCS_EXPLICIT = 3;
    static final short SQLCS_FLEXIBLE = 4;
    static final short SQLCS_LIT_NULL = 5;
    static final short SQLT_XDP = 103;
    static final short SQLT_OKO = 107;
    static final short SQLT_INTY = 109;
    static final short SQLT_IREF = 111;
    static final short SQLT_DCLOB = 195;
    public static final short TYPECODE_REF = 110;
    public static final short TYPECODE_DATE = 12;
    public static final short TYPECODE_SIGNED8 = 27;
    public static final short TYPECODE_SIGNED16 = 28;
    public static final short TYPECODE_SIGNED32 = 29;
    public static final short TYPECODE_REAL = 21;
    public static final short TYPECODE_DOUBLE = 22;
    public static final short TYPECODE_BFLOAT = 100;
    public static final short TYPECODE_BDOUBLE = 101;
    public static final short TYPECODE_FLOAT = 4;
    public static final short TYPECODE_NUMBER = 2;
    public static final short TYPECODE_DECIMAL = 7;
    public static final short TYPECODE_UNSIGNED8 = 23;
    public static final short TYPECODE_UNSIGNED16 = 25;
    public static final short TYPECODE_UNSIGNED32 = 26;
    public static final short TYPECODE_OCTET = 245;
    public static final short TYPECODE_SMALLINT = 246;
    public static final short TYPECODE_INTEGER = 3;
    public static final short TYPECODE_RAW = 95;
    public static final short TYPECODE_PTR = 32;
    public static final short TYPECODE_VARCHAR2 = 9;
    public static final short TYPECODE_CHAR = 96;
    public static final short TYPECODE_VARCHAR = 1;
    public static final short TYPECODE_MLSLABEL = 105;
    public static final short TYPECODE_VARRAY = 247;
    public static final short TYPECODE_TABLE = 248;
    public static final short TYPECODE_OBJECT = 108;
    public static final short TYPECODE_OPAQUE = 58;
    public static final short TYPECODE_NAMEDCOLLECTION = 122;
    public static final short TYPECODE_BLOB = 113;
    public static final short TYPECODE_BFILE = 114;
    public static final short TYPECODE_CLOB = 112;
    public static final short TYPECODE_CFILE = 115;
    public static final short TYPECODE_TIME = 185;
    public static final short TYPECODE_TIME_TZ = 186;
    public static final short TYPECODE_TIMESTAMP = 187;
    public static final short TYPECODE_TIMESTAMP_TZ = 188;
    public static final short TYPECODE_TIMESTAMP_LTZ = 232;
    public static final short TYPECODE_INTERVAL_YM = 189;
    public static final short TYPECODE_INTERVAL_DS = 190;
    public static final short TYPECODE_UROWID = 104;
    public static final short TYPECODE_OTMFIRST = 228;
    public static final short TYPECODE_OTMLAST = 320;
    public static final short TYPECODE_SYSFIRST = 228;
    public static final short TYPECODE_SYSLAST = 235;
    public static final short TYPECODE_PLS_INTEGER = 266;
    public static final short TYPECODE_ITABLE = 251;
    public static final short TYPECODE_RECORD = 250;
    public static final short TYPECODE_BOOLEAN = 252;
    public static final short TYPECODE_NCHAR = 286;
    public static final short TYPECODE_NVARCHAR2 = 287;
    public static final short TYPECODE_NCLOB = 288;
    public static final short TYPECODE_NONE = 0;
    public static final short TYPECODE_ERRHP = 283;
    public static final short TYPECODE_JDBC_JOBJECT = 2000;
    public static final short TYPECODE_JDBC_STRUCT = 2002;
    public static final short TYPECODE_JDBC_ARRAY = 2003;
    public static final short TYPECODE_JDBC_JOPAQUE = 2000;
    public static final short TYPECODE_JDBC_REF = 2006;
    public static final short TYPECODE_JDBC_JSTRUCT = 2008;
    private static final short TYPECODE_MAXVALUE = 2008;
    static final short[] OID_TO_TYPECODE;
    SQLName sqlName;
    OracleNamedType pickler;
    transient OracleConnection connection;
    short internalTypeCode;
    boolean isTransient;
    byte[] toid;
    int toidVersion;
    long precision;
    byte scale;
    byte[] transientImage;
    AttributeDescriptor[] attributesDescriptor;
    transient Boolean isInstanciable;
    transient String supertype;
    transient int numLocalAttrs;
    transient String[] subtypes;
    transient String[] attrJavaNames;
    private static String[] typeCodeTypeNameMap;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    void copyDescriptor(final TypeDescriptor typeDescriptor) {
        this.sqlName = typeDescriptor.sqlName;
        this.pickler = typeDescriptor.pickler;
        this.connection = typeDescriptor.connection;
        this.internalTypeCode = typeDescriptor.internalTypeCode;
        this.isTransient = typeDescriptor.isTransient;
        this.toid = typeDescriptor.toid;
        this.toidVersion = typeDescriptor.toidVersion;
        this.precision = typeDescriptor.precision;
        this.scale = typeDescriptor.scale;
        this.transientImage = typeDescriptor.transientImage;
        this.attributesDescriptor = typeDescriptor.attributesDescriptor;
        this.isInstanciable = typeDescriptor.isInstanciable;
        this.supertype = typeDescriptor.supertype;
        this.numLocalAttrs = typeDescriptor.numLocalAttrs;
        this.subtypes = typeDescriptor.subtypes;
        this.attrJavaNames = typeDescriptor.attrJavaNames;
    }
    
    protected TypeDescriptor(final short internalTypeCode) {
        this.isTransient = false;
        this.toid = null;
        this.toidVersion = 1;
        this.transientImage = null;
        this.attributesDescriptor = null;
        this.isInstanciable = null;
        this.supertype = null;
        this.numLocalAttrs = -1;
        this.subtypes = null;
        this.attrJavaNames = null;
        this.internalTypeCode = internalTypeCode;
    }
    
    protected TypeDescriptor(final short internalTypeCode, final String s, final Connection physicalConnectionOf) throws SQLException {
        this.isTransient = false;
        this.toid = null;
        this.toidVersion = 1;
        this.transientImage = null;
        this.attributesDescriptor = null;
        this.isInstanciable = null;
        this.supertype = null;
        this.numLocalAttrs = -1;
        this.subtypes = null;
        this.attrJavaNames = null;
        this.internalTypeCode = internalTypeCode;
        if (s == null || physicalConnectionOf == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.sqlName = new SQLName(s, this.getInternalConnection());
    }
    
    protected TypeDescriptor(final short internalTypeCode, final SQLName sqlName, final Connection physicalConnectionOf) throws SQLException {
        this.isTransient = false;
        this.toid = null;
        this.toidVersion = 1;
        this.transientImage = null;
        this.attributesDescriptor = null;
        this.isInstanciable = null;
        this.supertype = null;
        this.numLocalAttrs = -1;
        this.subtypes = null;
        this.attrJavaNames = null;
        this.internalTypeCode = internalTypeCode;
        if (sqlName == null || physicalConnectionOf == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.sqlName = sqlName;
        this.setPhysicalConnectionOf(physicalConnectionOf);
    }
    
    protected TypeDescriptor(final short internalTypeCode, final SQLName sqlName, final OracleTypeADT pickler, final Connection physicalConnectionOf) throws SQLException {
        this.isTransient = false;
        this.toid = null;
        this.toidVersion = 1;
        this.transientImage = null;
        this.attributesDescriptor = null;
        this.isInstanciable = null;
        this.supertype = null;
        this.numLocalAttrs = -1;
        this.subtypes = null;
        this.attrJavaNames = null;
        this.internalTypeCode = internalTypeCode;
        if (sqlName == null || pickler == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.sqlName = sqlName;
        if (physicalConnectionOf != null) {
            this.setPhysicalConnectionOf(physicalConnectionOf);
        }
        (this.pickler = pickler).setDescriptor(this);
    }
    
    protected TypeDescriptor(final short internalTypeCode, final OracleTypeADT pickler, final Connection physicalConnectionOf) throws SQLException {
        this.isTransient = false;
        this.toid = null;
        this.toidVersion = 1;
        this.transientImage = null;
        this.attributesDescriptor = null;
        this.isInstanciable = null;
        this.supertype = null;
        this.numLocalAttrs = -1;
        this.subtypes = null;
        this.attrJavaNames = null;
        this.internalTypeCode = internalTypeCode;
        if (pickler == null || physicalConnectionOf == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.sqlName = null;
        (this.pickler = pickler).setDescriptor(this);
    }
    
    public String getName() throws SQLException {
        synchronized (this.connection) {
            if (this.sqlName == null) {
                this.initSQLName();
            }
            String name = null;
            if (this.sqlName != null) {
                name = this.sqlName.getName();
            }
            return name;
        }
    }
    
    public SQLName getSQLName() throws SQLException {
        synchronized (this.connection) {
            if (this.sqlName == null) {
                this.initSQLName();
            }
            return this.sqlName;
        }
    }
    
    void initSQLName() throws SQLException {
        if (!this.isTransient) {
            if (this.connection == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.pickler != null) {
                this.sqlName = new SQLName(this.pickler.getFullName(), this.connection);
            }
            else if (this.toid != null) {
                this.sqlName = new SQLName(OracleTypeADT.toid2typename(this.connection, this.toid), this.connection);
                final TypeDescriptor typeDescriptor = (TypeDescriptor)this.connection.getDescriptor(this.sqlName.getName());
                if (typeDescriptor != null) {
                    this.copyDescriptor(typeDescriptor);
                }
            }
            else if (this.internalTypeCode == 108 || this.internalTypeCode == 122) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    public String getSchemaName() throws SQLException {
        String schema = null;
        if (this.sqlName == null) {
            this.initSQLName();
        }
        if (this.sqlName != null) {
            schema = this.sqlName.getSchema();
        }
        return schema;
    }
    
    public String getTypeName() throws SQLException {
        String simpleName = null;
        if (this.sqlName == null) {
            this.initSQLName();
        }
        if (this.sqlName != null) {
            simpleName = this.sqlName.getSimpleName();
        }
        return simpleName;
    }
    
    public OracleNamedType getPickler() {
        return this.pickler;
    }
    
    public OracleConnection getInternalConnection() {
        return this.connection;
    }
    
    public void setPhysicalConnectionOf(final Connection connection) {
        this.connection = ((oracle.jdbc.OracleConnection)connection).physicalConnectionWithin();
    }
    
    public int getTypeCode() throws SQLException {
        return this.internalTypeCode;
    }
    
    public String getTypeCodeName() throws SQLException {
        return getTypeCodeTypeNameMap()[this.getTypeCode()];
    }
    
    private static String[] getTypeCodeTypeNameMap() throws SQLException {
        if (TypeDescriptor.typeCodeTypeNameMap == null) {
            final String[] typeCodeTypeNameMap = new String[2009];
            Class<?> forName;
            try {
                forName = Class.forName("oracle.sql.TypeDescriptor");
            }
            catch (ClassNotFoundException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(null, 1, "TypeDescriptor.getTypeCodeName: got a ClassNotFoundException: " + ex.getMessage());
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final Field[] fields = forName.getFields();
            for (int i = 0; i < fields.length; ++i) {
                if (fields[i].getName().startsWith("TYPECODE_")) {
                    try {
                        typeCodeTypeNameMap[fields[i].getInt(null)] = fields[i].getName();
                    }
                    catch (Exception ex2) {
                        final SQLException sqlException2 = DatabaseError.createSqlException(null, 1, "TypeDescriptor.getTypeCodeName: " + ex2.getMessage());
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                }
            }
            TypeDescriptor.typeCodeTypeNameMap = typeCodeTypeNameMap;
        }
        return TypeDescriptor.typeCodeTypeNameMap;
    }
    
    public short getInternalTypeCode() throws SQLException {
        return this.internalTypeCode;
    }
    
    public static TypeDescriptor getTypeDescriptor(final String s, final oracle.jdbc.OracleConnection oracleConnection) throws SQLException {
        TypeDescriptor descriptor;
        try {
            final SQLName sqlName = new SQLName(s, oracleConnection);
            final String name = sqlName.getName();
            descriptor = (TypeDescriptor)oracleConnection.getDescriptor(name);
            if (descriptor == null) {
                final OracleTypeADT oracleTypeADT = new OracleTypeADT(name, oracleConnection);
                oracleTypeADT.init((OracleConnection)oracleConnection);
                final OracleNamedType cleanup = oracleTypeADT.cleanup();
                switch (cleanup.getTypeCode()) {
                    case 2002:
                    case 2008: {
                        descriptor = new StructDescriptor(sqlName, (OracleTypeADT)cleanup, oracleConnection);
                        break;
                    }
                    case 2003: {
                        descriptor = new ArrayDescriptor(sqlName, (OracleTypeCOLLECTION)cleanup, oracleConnection);
                        break;
                    }
                    case 2007: {
                        descriptor = new OpaqueDescriptor(sqlName, (OracleTypeOPAQUE)cleanup, oracleConnection);
                        break;
                    }
                    default: {
                        final SQLException sqlException = DatabaseError.createSqlException(null, 1);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                }
                oracleConnection.putDescriptor(name, descriptor);
                cleanup.setDescriptor(descriptor);
            }
        }
        catch (Exception ex) {
            if (ex instanceof SQLException) {
                final SQLException sqlException2 = DatabaseError.createSqlException(null, (SQLException)ex, 60, "Unable to resolve type \"" + s + "\"");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final SQLException sqlException3 = DatabaseError.createSqlException(null, 60, "Unable to resolve type \"" + s + "\"");
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        return descriptor;
    }
    
    public static TypeDescriptor getTypeDescriptor(final String s, final oracle.jdbc.OracleConnection oracleConnection, final byte[] array, final long n) throws SQLException {
        String subtypeName = getSubtypeName(oracleConnection, array, n);
        if (subtypeName == null) {
            subtypeName = s;
        }
        TypeDescriptor typeDescriptor = (TypeDescriptor)oracleConnection.getDescriptor(subtypeName);
        if (typeDescriptor == null) {
            final SQLName sqlName = new SQLName(subtypeName, oracleConnection);
            final OracleTypeADT oracleTypeADT = new OracleTypeADT(subtypeName, oracleConnection);
            oracleTypeADT.init((OracleConnection)oracleConnection);
            final OracleNamedType cleanup = oracleTypeADT.cleanup();
            switch (cleanup.getTypeCode()) {
                case 2002:
                case 2008: {
                    typeDescriptor = new StructDescriptor(sqlName, (OracleTypeADT)cleanup, oracleConnection);
                    break;
                }
                case 2003: {
                    typeDescriptor = new ArrayDescriptor(sqlName, (OracleTypeCOLLECTION)cleanup, oracleConnection);
                    break;
                }
                case 2007: {
                    typeDescriptor = new OpaqueDescriptor(sqlName, (OracleTypeOPAQUE)cleanup, oracleConnection);
                    break;
                }
                default: {
                    final SQLException sqlException = DatabaseError.createSqlException(null, 1);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            oracleConnection.putDescriptor(subtypeName, typeDescriptor);
        }
        return typeDescriptor;
    }
    
    @Override
    public Datum toDatum(final Connection connection) throws SQLException {
        this.connection = (OracleConnection)connection;
        final OpaqueDescriptor descriptor = OpaqueDescriptor.createDescriptor("SYS.ANYTYPE", connection);
        final byte[] array = new byte[this.getOpaqueImageTypeSize()];
        this.pickleOpaqueTypeImage(array, 0, false);
        final OPAQUE opaque = new OPAQUE(descriptor, this.connection, array);
        opaque.setShareBytes(opaque.toBytes());
        return opaque;
    }
    
    static TypeDescriptor unpickleOpaqueTypeImage(final PickleContext pickleContext, final Connection connection, final short[] array) throws SQLException {
        final int offset = pickleContext.offset();
        final byte[] image = pickleContext.image();
        pickleContext.skipBytes(1);
        final short n = (short)pickleContext.readUB2();
        array[0] = (short)pickleContext.readUB2();
        if ((n & 0x20) != 0x0) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 178);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        TypeDescriptor unpickleTypeDescriptorImage;
        if ((n & 0x1) == 0x0) {
            if ((n & 0x2) == 0x0 || array[0] == 110) {
                final byte[] dataValue = pickleContext.readDataValue(16);
                final int ub2 = pickleContext.readUB2();
                unpickleTypeDescriptorImage = (TypeDescriptor)((OracleConnection)connection).getDescriptor((String)((OracleConnection)connection).getDescriptor(dataValue));
                if (unpickleTypeDescriptorImage == null) {
                    if (array[0] == 122) {
                        unpickleTypeDescriptorImage = new ArrayDescriptor(dataValue, ub2, connection);
                    }
                    else if (array[0] == 108 || array[0] == 110) {
                        unpickleTypeDescriptorImage = new StructDescriptor(dataValue, ub2, connection);
                    }
                    else {
                        if (array[0] != 58) {
                            final SQLException sqlException2 = DatabaseError.createSqlException(null, 178);
                            sqlException2.fillInStackTrace();
                            throw sqlException2;
                        }
                        unpickleTypeDescriptorImage = new OpaqueDescriptor(dataValue, ub2, connection);
                    }
                }
            }
            else {
                unpickleTypeDescriptorImage = new TypeDescriptor(array[0]);
            }
            unpickleTypeDescriptorImage.setTransient(false);
        }
        else {
            final int n2 = (int)pickleContext.readUB4();
            if (array[0] == 108) {
                AttributeDescriptor[] array2 = null;
                if (n2 > 0) {
                    array2 = new AttributeDescriptor[n2];
                    for (int i = 0; i < n2; ++i) {
                        final byte byte1 = pickleContext.readByte();
                        array2[i] = Kotad.unpickleAttributeImage(byte1 == 2, pickleContext);
                        if (byte1 != 2) {
                            array2[i].setTypeDescriptor(unpickleOpaqueTypeImage(pickleContext, connection, new short[1]));
                        }
                    }
                }
                unpickleTypeDescriptorImage = new StructDescriptor(array2, connection);
            }
            else {
                if (n2 != 1) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(null, 178);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                pickleContext.readByte();
                unpickleTypeDescriptorImage = Kotad.unpickleTypeDescriptorImage(pickleContext);
            }
            unpickleTypeDescriptorImage.setTransient(true);
        }
        if (unpickleTypeDescriptorImage.isTransient()) {
            final byte[] transientImage = new byte[pickleContext.offset() - offset];
            System.arraycopy(image, offset, transientImage, 0, transientImage.length);
            unpickleTypeDescriptorImage.setTransientImage(transientImage);
        }
        return unpickleTypeDescriptorImage;
    }
    
    void setTransientImage(final byte[] transientImage) {
        this.transientImage = transientImage;
    }
    
    void setTransient(final boolean isTransient) {
        this.isTransient = isTransient;
    }
    
    public boolean isTransient() {
        return this.isTransient;
    }
    
    int getOpaqueImageTypeSize() {
        int length;
        if (this.isTransient) {
            length = this.transientImage.length;
        }
        else {
            length = 5;
            if (this.toid != null && this.toid.length == 16) {
                length = 23;
            }
        }
        return length;
    }
    
    int pickleOpaqueTypeImage(final byte[] array, int n, final boolean b) {
        if (this.isTransient) {
            System.arraycopy(this.transientImage, 0, array, n, this.transientImage.length);
            n += this.transientImage.length;
        }
        else {
            boolean b2 = false;
            if (this.toid != null && this.toid.length == 16) {
                b2 = true;
            }
            array[n++] = 1;
            int internalTypeCode = this.internalTypeCode;
            if (b) {
                internalTypeCode = 110;
            }
            int n2 = 512;
            if (internalTypeCode != 108 && internalTypeCode != 122) {
                n2 |= 0x2;
            }
            if (b2 && internalTypeCode != 110) {
                n2 |= 0x4;
            }
            array[n++] = (byte)((n2 & 0xFF00) >> 8 & 0xFF);
            array[n++] = (byte)(n2 & 0xFF);
            array[n++] = (byte)((internalTypeCode & 0xFF00) >> 8 & 0xFF);
            array[n++] = (byte)(internalTypeCode & 0xFF);
            if (b2) {
                System.arraycopy(this.toid, 0, array, n, this.toid.length);
                n += this.toid.length;
                array[n++] = (byte)((this.toidVersion & 0xFF00) >> 8 & 0xFF);
                array[n++] = (byte)(this.toidVersion & 0xFF);
            }
        }
        return n;
    }
    
    public void setPrecision(final long precision) {
        this.precision = precision;
    }
    
    public long getPrecision() {
        return this.precision;
    }
    
    public void setScale(final byte scale) {
        this.scale = scale;
    }
    
    public byte getScale() {
        return this.scale;
    }
    
    public boolean isInHierarchyOf(final String s) throws SQLException {
        return false;
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        try {
            if (this.sqlName == null) {
                this.initSQLName();
            }
        }
        catch (SQLException ex) {
            throw new IOException(ex.getMessage());
        }
        objectOutputStream.writeObject(this.sqlName);
        objectOutputStream.writeObject(this.pickler);
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        this.sqlName = (SQLName)objectInputStream.readObject();
        this.pickler = (OracleNamedType)objectInputStream.readObject();
    }
    
    public void setConnection(final Connection physicalConnectionOf) throws SQLException {
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.pickler.setConnection(this.getInternalConnection());
    }
    
    public static String getSubtypeName(final oracle.jdbc.OracleConnection oracleConnection, final byte[] array, final long n) throws SQLException {
        if (array == null || array.length == 0 || oracleConnection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 68, " 'image' should not be empty and 'conn' should not be null. ");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return OracleTypeADT.getSubtypeName(oracleConnection, array, n);
    }
    
    public void initMetadataRecursively() throws SQLException {
        if (this.pickler != null) {
            this.pickler.initMetadataRecursively();
        }
    }
    
    public void initNamesRecursively() throws SQLException {
        if (this.pickler != null) {
            this.pickler.initNamesRecursively();
        }
    }
    
    public void fixupConnection(final OracleConnection connection) throws SQLException {
        if (this.connection == null) {
            this.connection = connection;
        }
        if (this.pickler != null) {
            this.pickler.fixupConnection(connection);
        }
    }
    
    public String toXMLString() throws SQLException {
        return this.toXMLString(false);
    }
    
    public String toXMLString(final boolean b) throws SQLException {
        final StringWriter out = new StringWriter();
        final PrintWriter printWriter = new PrintWriter(out);
        this.printXMLHeader(printWriter);
        this.printXML(printWriter, 0, b);
        return out.getBuffer().substring(0);
    }
    
    public void printXML(final PrintStream printStream) throws SQLException {
        this.printXML(printStream, false);
    }
    
    public void printXML(final PrintStream out, final boolean b) throws SQLException {
        final PrintWriter printWriter = new PrintWriter(out, true);
        this.printXMLHeader(printWriter);
        this.printXML(printWriter, 0, b);
    }
    
    void printXML(final PrintWriter printWriter, final int n, final boolean b) throws SQLException {
        final String tagName = this.tagName();
        printWriter.println("<" + tagName + " sqlName=\"" + this.sqlName + "\" >");
        if (this.pickler != null) {
            this.pickler.printXML(printWriter, n + 1, b);
        }
        printWriter.println("</" + tagName + ">");
    }
    
    String tagName() {
        return "TypeDescriptor";
    }
    
    void printXMLHeader(final PrintWriter printWriter) throws SQLException {
        printWriter.println("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        TypeDescriptor.DEBUG_SERIALIZATION = false;
        KOTTDEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1 };
        KOTTBEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2 };
        KOTADEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3 };
        KOTMDEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 4 };
        KOTTBXEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 66 };
        KOTADXEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 67 };
        KOTTDTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
        KOTTBTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2 };
        KOTADTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 };
        KOTMDTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5 };
        KOTMITOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6 };
        KOTEXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7 };
        KOTEX1TOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 57 };
        KOTTBXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 66 };
        KOTADXTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67 };
        RAWTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23 };
        ANYTYPETOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 16 };
        ANYDATATOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 17 };
        ANYDATASETTOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 18 };
        XMLTYPETOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0 };
        (OID_TO_TYPECODE = new short[71])[8] = 12;
        TypeDescriptor.OID_TO_TYPECODE[9] = 27;
        TypeDescriptor.OID_TO_TYPECODE[10] = 28;
        TypeDescriptor.OID_TO_TYPECODE[11] = 29;
        TypeDescriptor.OID_TO_TYPECODE[12] = 21;
        TypeDescriptor.OID_TO_TYPECODE[13] = 22;
        TypeDescriptor.OID_TO_TYPECODE[14] = 4;
        TypeDescriptor.OID_TO_TYPECODE[15] = 2;
        TypeDescriptor.OID_TO_TYPECODE[16] = 7;
        TypeDescriptor.OID_TO_TYPECODE[17] = 23;
        TypeDescriptor.OID_TO_TYPECODE[18] = 25;
        TypeDescriptor.OID_TO_TYPECODE[19] = 26;
        TypeDescriptor.OID_TO_TYPECODE[20] = 245;
        TypeDescriptor.OID_TO_TYPECODE[21] = 246;
        TypeDescriptor.OID_TO_TYPECODE[22] = 3;
        TypeDescriptor.OID_TO_TYPECODE[23] = 95;
        TypeDescriptor.OID_TO_TYPECODE[24] = 32;
        TypeDescriptor.OID_TO_TYPECODE[25] = 9;
        TypeDescriptor.OID_TO_TYPECODE[26] = 96;
        TypeDescriptor.OID_TO_TYPECODE[27] = 1;
        TypeDescriptor.OID_TO_TYPECODE[28] = 105;
        TypeDescriptor.OID_TO_TYPECODE[29] = 247;
        TypeDescriptor.OID_TO_TYPECODE[30] = 248;
        TypeDescriptor.OID_TO_TYPECODE[31] = 108;
        TypeDescriptor.OID_TO_TYPECODE[32] = 0;
        TypeDescriptor.OID_TO_TYPECODE[33] = 0;
        TypeDescriptor.OID_TO_TYPECODE[34] = 112;
        TypeDescriptor.OID_TO_TYPECODE[35] = 113;
        TypeDescriptor.OID_TO_TYPECODE[36] = 115;
        TypeDescriptor.OID_TO_TYPECODE[37] = 114;
        TypeDescriptor.OID_TO_TYPECODE[38] = 0;
        TypeDescriptor.OID_TO_TYPECODE[39] = 0;
        TypeDescriptor.OID_TO_TYPECODE[40] = 0;
        TypeDescriptor.OID_TO_TYPECODE[41] = 0;
        TypeDescriptor.OID_TO_TYPECODE[42] = 0;
        TypeDescriptor.OID_TO_TYPECODE[43] = 0;
        TypeDescriptor.OID_TO_TYPECODE[44] = 0;
        TypeDescriptor.OID_TO_TYPECODE[45] = 0;
        TypeDescriptor.OID_TO_TYPECODE[46] = 0;
        TypeDescriptor.OID_TO_TYPECODE[47] = 0;
        TypeDescriptor.OID_TO_TYPECODE[48] = 0;
        TypeDescriptor.OID_TO_TYPECODE[49] = 0;
        TypeDescriptor.OID_TO_TYPECODE[50] = 0;
        TypeDescriptor.OID_TO_TYPECODE[51] = 0;
        TypeDescriptor.OID_TO_TYPECODE[52] = 0;
        TypeDescriptor.OID_TO_TYPECODE[53] = 0;
        TypeDescriptor.OID_TO_TYPECODE[54] = 0;
        TypeDescriptor.OID_TO_TYPECODE[55] = 0;
        TypeDescriptor.OID_TO_TYPECODE[56] = 0;
        TypeDescriptor.OID_TO_TYPECODE[57] = 0;
        TypeDescriptor.OID_TO_TYPECODE[58] = 58;
        TypeDescriptor.OID_TO_TYPECODE[59] = 185;
        TypeDescriptor.OID_TO_TYPECODE[60] = 186;
        TypeDescriptor.OID_TO_TYPECODE[61] = 187;
        TypeDescriptor.OID_TO_TYPECODE[62] = 188;
        TypeDescriptor.OID_TO_TYPECODE[63] = 189;
        TypeDescriptor.OID_TO_TYPECODE[64] = 190;
        TypeDescriptor.OID_TO_TYPECODE[65] = 232;
        TypeDescriptor.OID_TO_TYPECODE[66] = 0;
        TypeDescriptor.OID_TO_TYPECODE[67] = 0;
        TypeDescriptor.OID_TO_TYPECODE[68] = 100;
        TypeDescriptor.OID_TO_TYPECODE[69] = 101;
        TypeDescriptor.OID_TO_TYPECODE[70] = 104;
        TypeDescriptor.typeCodeTypeNameMap = null;
        try {
            getTypeCodeTypeNameMap();
        }
        catch (Exception ex) {}
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
