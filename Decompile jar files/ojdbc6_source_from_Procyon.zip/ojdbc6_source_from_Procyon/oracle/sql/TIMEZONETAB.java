// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.Connection;
import java.util.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.HashMap;

public class TIMEZONETAB
{
    private static HashMap<Integer, TIMEZONETAB> instanceCache;
    private int instanceCount;
    private int versionNumber;
    private Hashtable zonetab;
    private static int OFFSET_HOUR;
    private static int OFFSET_MINUTE;
    private static int HOUR_MILLISECOND;
    private static int MINUTE_MILLISECOND;
    private static int BYTE_SIZE;
    
    private TIMEZONETAB(final int versionNumber) throws SQLException {
        this.instanceCount = 0;
        this.versionNumber = 0;
        this.zonetab = new Hashtable();
        this.versionNumber = versionNumber;
    }
    
    public static TIMEZONETAB getInstance(final int n) throws SQLException {
        if (TIMEZONETAB.instanceCache == null) {
            synchronized (TIMEZONETAB.class) {
                if (TIMEZONETAB.instanceCache == null) {
                    TIMEZONETAB.instanceCache = new HashMap<Integer, TIMEZONETAB>(5);
                }
            }
        }
        TIMEZONETAB timezonetab = TIMEZONETAB.instanceCache.get(n);
        if (timezonetab == null) {
            synchronized (TIMEZONETAB.class) {
                timezonetab = TIMEZONETAB.instanceCache.get(n);
                if (timezonetab == null) {
                    timezonetab = new TIMEZONETAB(n);
                }
            }
        }
        return timezonetab.returnInstance();
    }
    
    private synchronized TIMEZONETAB returnInstance() {
        ++this.instanceCount;
        TIMEZONETAB.instanceCache.put(this.versionNumber, this);
        return this;
    }
    
    public synchronized void freeInstance() throws SQLException {
        --this.instanceCount;
        if (this.instanceCount < 1) {
            TIMEZONETAB.instanceCache.remove(this.versionNumber);
        }
    }
    
    public void addTrans(final byte[] array, final int n) {
        final int[] array2 = new int[TIMEZONETAB.BYTE_SIZE];
        final int n2 = array[0] & 0xFF;
        final OffsetDST[] value = new OffsetDST[n2];
        int n3 = 0;
        for (int i = 1; i < n2 * TIMEZONETAB.BYTE_SIZE; i += TIMEZONETAB.BYTE_SIZE) {
            for (int j = 0; j < TIMEZONETAB.BYTE_SIZE; ++j) {
                array2[j] = (array[j + i] & 0xFF);
            }
            final int value2 = (array2[0] - 100) * 100 + (array2[1] - 100);
            final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
            instance.set(1, value2);
            instance.set(2, array2[2] - 1);
            instance.set(5, array2[3]);
            instance.set(11, array2[4] - 1);
            instance.set(12, array2[5] - 1);
            instance.set(13, array2[6] - 1);
            instance.set(14, 0);
            value[n3++] = new OffsetDST(new Timestamp(instance.getTime().getTime()), (array2[7] - TIMEZONETAB.OFFSET_HOUR) * TIMEZONETAB.HOUR_MILLISECOND + (array2[8] - TIMEZONETAB.OFFSET_MINUTE) * TIMEZONETAB.MINUTE_MILLISECOND, (byte)array2[9]);
        }
        this.zonetab.put(n & 0x1FF, value);
    }
    
    public byte getLocalOffset(final Calendar calendar, final int n, final OffsetDST offsetDST) throws SQLException {
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        final Calendar instance2 = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        final Calendar instance3 = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        instance3.set(1, calendar.get(1));
        instance3.set(2, calendar.get(2));
        instance3.set(5, calendar.get(5));
        instance3.set(11, calendar.get(11));
        instance3.set(12, calendar.get(12));
        instance3.set(13, calendar.get(13));
        instance3.set(14, calendar.get(14));
        final Calendar instance4 = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        instance4.set(1, instance3.get(1));
        instance4.set(2, instance3.get(2));
        instance4.set(5, 1);
        instance4.set(11, 0);
        instance4.set(12, 0);
        instance4.set(13, 0);
        instance4.set(14, 0);
        final OffsetDST[] array = this.zonetab.get(n & 0x1FF);
        int closeMatch = this.findCloseMatch(array, instance4.getTimeInMillis());
        byte dstflag;
        while (true) {
            instance.setTime(array[closeMatch].getTimestamp());
            final int offset = array[closeMatch].getOFFSET();
            instance.add(10, offset / TIMEZONETAB.HOUR_MILLISECOND);
            instance.add(12, offset % TIMEZONETAB.HOUR_MILLISECOND / TIMEZONETAB.MINUTE_MILLISECOND);
            dstflag = array[closeMatch].getDSTFLAG();
            if (instance3.equals(instance)) {
                offsetDST.setOFFSET(array[closeMatch].getOFFSET());
                offsetDST.setDSTFLAG(array[closeMatch].getDSTFLAG());
                byte b = 0;
                if (closeMatch <= 0) {
                    return b;
                }
                final byte dstflag2 = array[closeMatch - 1].getDSTFLAG();
                if (dstflag == 0 && dstflag2 == 1) {
                    b = 1;
                    return b;
                }
                return b;
            }
            else if (instance3.before(instance)) {
                if (closeMatch == 0) {
                    offsetDST.setOFFSET(0);
                    offsetDST.setDSTFLAG((byte)0);
                    final byte b = 0;
                    if (dstflag != 1) {
                        return b;
                    }
                    instance.add(10, -1);
                    if (!instance3.before(instance)) {
                        throw new SQLException("Illegal local time.");
                    }
                    return b;
                }
                else {
                    --closeMatch;
                    if (closeMatch < 0) {
                        continue;
                    }
                    final byte dstflag3 = array[closeMatch].getDSTFLAG();
                    if (dstflag != 1 || dstflag3 != 0) {
                        continue;
                    }
                    instance.add(10, -1);
                    if (!instance3.before(instance)) {
                        throw new SQLException("Illegal local time.");
                    }
                    continue;
                }
            }
            else {
                if (closeMatch == array.length - 1) {
                    break;
                }
                instance2.setTime(array[closeMatch + 1].getTimestamp());
                final int offset2 = array[closeMatch + 1].getOFFSET();
                instance2.add(10, offset2 / TIMEZONETAB.HOUR_MILLISECOND);
                instance2.add(12, offset2 % TIMEZONETAB.HOUR_MILLISECOND / TIMEZONETAB.MINUTE_MILLISECOND);
                if (instance3.before(instance2)) {
                    break;
                }
                ++closeMatch;
            }
        }
        offsetDST.setOFFSET(array[closeMatch].getOFFSET());
        offsetDST.setDSTFLAG(array[closeMatch].getDSTFLAG());
        byte b = 0;
        if (dstflag == 0) {
            if (closeMatch > 0 && array[closeMatch - 1].getDSTFLAG() == 1) {
                instance.add(10, 1);
                if (instance3.before(instance)) {
                    b = 1;
                }
            }
            if (closeMatch != array.length - 1 && array[closeMatch + 1].getDSTFLAG() == 1) {
                instance2.add(10, -1);
                if (!instance3.before(instance2)) {
                    throw new SQLException("Illegal local time.");
                }
            }
        }
        return b;
    }
    
    public int getOffset(final Calendar calendar, final int n) throws SQLException {
        return this.getOffset(calendar, this.zonetab.get(n & 0x1FF));
    }
    
    public int getOffset(final Calendar calendar, final OffsetDST[] array) throws SQLException {
        return array[this.findCloseMatch(array, new Timestamp(calendar.getTime().getTime()).getTime())].getOFFSET();
    }
    
    public boolean isDST(final Calendar calendar, final OffsetDST[] array) throws SQLException {
        return array[this.findCloseMatch(array, new Timestamp(calendar.getTime().getTime()).getTime())].getDSTFLAG() == 1;
    }
    
    public OffsetDST[] getOffsetDST(final int n) {
        return this.zonetab.get(n & 0x1FF);
    }
    
    final int findCloseMatch(final OffsetDST[] array, final long n) {
        int length = array.length;
        int n2 = 0;
        int n3;
        int i = n3 = length / 2;
        if (n < array[n2].getTime()) {
            int n4;
            for (n4 = 0; array[n4].getDSTFLAG() == 1 && n4 < array.length; ++n4) {}
            return (n4 < array.length) ? n4 : false;
        }
        while (i > 0) {
            if (n > array[i].getTime()) {
                n2 = i;
            }
            else if (n < array[i].getTime()) {
                length = i;
            }
            else if (i == n2) {
                break;
            }
            i = n2 + (length - n2) / 2;
            if (n3 == i) {
                break;
            }
            n3 = i;
        }
        return i;
    }
    
    public void displayTable(final int i) {
        final OffsetDST[] array = this.zonetab.get(i);
        for (int j = 0; j < array.length; ++j) {
            System.out.print(array[j].getTimestamp().toString());
            System.out.print("    " + array[j].getOFFSET());
            System.out.println("    " + array[j].getDSTFLAG());
        }
    }
    
    public boolean checkID(final int n) {
        return this.zonetab.get(n & 0x1FF) == null;
    }
    
    public void updateTable(final Connection connection, final int n) throws SQLException, NullPointerException {
        final byte[] transitions = TRANSDUMP.getTransitions(connection, n);
        if (transitions == null) {
            throw new NullPointerException();
        }
        this.addTrans(transitions, n);
    }
    
    static {
        TIMEZONETAB.instanceCache = null;
        TIMEZONETAB.OFFSET_HOUR = 20;
        TIMEZONETAB.OFFSET_MINUTE = 60;
        TIMEZONETAB.HOUR_MILLISECOND = 3600000;
        TIMEZONETAB.MINUTE_MILLISECOND = 60000;
        TIMEZONETAB.BYTE_SIZE = 10;
    }
}
