// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

class CharacterSetUTF extends CharacterSet implements CharacterRepConstants
{
    private static int[] m_byteLen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetUTF(final int n) {
        super(n);
        this.rep = 2;
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return !set.isUnicode();
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.rep <= 1024;
    }
    
    @Override
    public boolean isUnicode() {
        return true;
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        try {
            final char[] value = new char[array.length];
            return new String(value, 0, CharacterSet.convertUTFBytesToJavaChars(array, n, value, 0, new int[] { n2 }, true));
        }
        catch (SQLException ex) {
            return "";
        }
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        try {
            final char[] value = new char[array.length];
            return new String(value, 0, CharacterSet.convertUTFBytesToJavaChars(array, n, value, 0, new int[] { n2 }, false));
        }
        catch (SQLException ex) {
            failUTFConversion();
            return "";
        }
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        return CharacterSet.stringToUTF(s);
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        return CharacterSet.stringToUTF(s);
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        byte[] array2;
        if (set.rep == 2) {
            array2 = CharacterSet.useOrCopy(array, n, n2);
        }
        else {
            array2 = CharacterSet.stringToUTF(set.toString(array, n, n2));
        }
        return array2;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        final byte[] bytes = characterWalker.bytes;
        final int next = characterWalker.next;
        final int end = characterWalker.end;
        if (next >= end) {
            failUTFConversion();
        }
        final byte b = bytes[next];
        int utfByteLength = getUTFByteLength(b);
        if (utfByteLength == 0 || next + (utfByteLength - 1) >= end) {
            failUTFConversion();
        }
        if (utfByteLength == 3 && isHiSurrogate(b, bytes[next + 1]) && next + 5 < end) {
            utfByteLength = 6;
        }
        try {
            final char[] array = new char[2];
            final int convertUTFBytesToJavaChars = CharacterSet.convertUTFBytesToJavaChars(bytes, next, array, 0, new int[] { utfByteLength }, false);
            characterWalker.next += utfByteLength;
            if (convertUTFBytesToJavaChars == 1) {
                return array[0];
            }
            return array[0] << 16 | array[1];
        }
        catch (SQLException ex) {
            failUTFConversion();
            return 0;
        }
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        int n2;
        if ((n & 0xFFFF0000) != 0x0) {
            CharacterSet.need(characterBuffer, 6);
            n2 = CharacterSet.convertJavaCharsToUTFBytes(new char[] { (char)(n >>> 16), (char)n }, 0, characterBuffer.bytes, characterBuffer.next, 2);
        }
        else {
            CharacterSet.need(characterBuffer, 3);
            n2 = CharacterSet.convertJavaCharsToUTFBytes(new char[] { (char)n }, 0, characterBuffer.bytes, characterBuffer.next, 1);
        }
        characterBuffer.next += n2;
    }
    
    private static int getUTFByteLength(final byte b) {
        return CharacterSetUTF.m_byteLen[b >>> 4 & 0xF];
    }
    
    private static boolean isHiSurrogate(final byte b, final byte b2) {
        return b == -19 && b2 >= -96;
    }
    
    @Override
    public int encodedByteLength(final String s) {
        return CharacterSet.stringUTFLength(s);
    }
    
    @Override
    public int encodedByteLength(final char[] array) {
        return CharacterSet.charArrayUTF8Length(array);
    }
    
    static {
        CharacterSetUTF.m_byteLen = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 2, 3, 0 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
