// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.converter.JdbcCharacterConverters;

class CharacterSetSJIS extends CharacterSetWithConverter
{
    static final String CHAR_CONV_SUPERCLASS_NAME = "oracle.sql.converter.CharacterConverterSJIS";
    static final short MAX_7BIT = 127;
    static final short MIN_8BIT_SB = 161;
    static final short MAX_8BIT_SB = 223;
    static Class m_charConvSuperclass;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetSJIS(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        super(n, jdbcCharacterConverters);
    }
    
    static CharacterSetSJIS getInstance(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        if (jdbcCharacterConverters.getGroupId() == 4) {
            return new CharacterSetSJIS(n, jdbcCharacterConverters);
        }
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        int n = characterWalker.bytes[characterWalker.next] & 0xFF;
        ++characterWalker.next;
        if (n > 223 || (n > 127 && n < 161)) {
            if (characterWalker.bytes.length <= characterWalker.next) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182, "destination too small");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            n = (n << 8 | characterWalker.bytes[characterWalker.next]);
            ++characterWalker.next;
        }
        return n;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        int i;
        int n2;
        for (i = 0, n2 = 1; n >> i != 0; i = (short)(i + 8), n2 = (short)(n2 + 1)) {}
        CharacterSet.need(characterBuffer, n2);
        while (i >= 0) {
            characterBuffer.bytes[characterBuffer.next++] = (byte)(n >> i & 0xFF);
            i = (short)(i - 8);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
