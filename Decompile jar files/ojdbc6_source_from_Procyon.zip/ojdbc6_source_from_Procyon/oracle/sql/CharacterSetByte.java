// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import java.io.UnsupportedEncodingException;
import oracle.jdbc.driver.DatabaseError;

class CharacterSetByte extends CharacterSet implements CharacterRepConstants
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetByte(final int n) {
        super(n);
        this.rep = 1;
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return set.rep != 1;
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.rep <= 1024;
    }
    
    private String toString(final byte[] bytes, final int offset, final int length, final char c) throws SQLException {
        try {
            return new String(bytes, offset, length, "ASCII");
        }
        catch (UnsupportedEncodingException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 183);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        try {
            return this.toString(array, n, n2, '?');
        }
        catch (SQLException ex) {
            throw new Error("CharacterSetByte.toString");
        }
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        return this.toString(array, n, n2, '\0');
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        final int length = s.length();
        final char[] dst = new char[s.length()];
        s.getChars(0, length, dst, 0);
        return charsToBytes(dst, (byte)0);
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        final int length = s.length();
        final char[] dst = new char[s.length()];
        s.getChars(0, length, dst, 0);
        try {
            return charsToBytes(dst, (byte)63);
        }
        catch (SQLException ex) {
            return new byte[0];
        }
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        byte[] array2;
        if (set.rep == 1) {
            array2 = CharacterSet.useOrCopy(array, n, n2);
        }
        else if (set.rep == 2) {
            array2 = charsToBytes(CharacterSet.UTFToJavaChar(array, n, n2), (byte)0);
        }
        else {
            array2 = charsToBytes(set.toString(array, n, n2).toCharArray(), (byte)0);
        }
        return array2;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) {
        final int n = characterWalker.bytes[characterWalker.next] & 0xFF;
        ++characterWalker.next;
        return n;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        CharacterSet.need(characterBuffer, 1);
        if (n < 256) {
            characterBuffer.bytes[characterBuffer.next] = (byte)n;
            ++characterBuffer.next;
        }
    }
    
    static byte[] charsToBytes(final char[] array, final byte b) throws SQLException {
        final byte[] array2 = new byte[array.length];
        for (int i = 0; i < array.length; ++i) {
            if (array[i] > '\u00ff') {
                if ((array2[i] = b) == 0) {
                    CharacterSet.failCharacterConversion(CharacterSet.make(31));
                }
            }
            else {
                array2[i] = (byte)array[i];
            }
        }
        return array2;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
