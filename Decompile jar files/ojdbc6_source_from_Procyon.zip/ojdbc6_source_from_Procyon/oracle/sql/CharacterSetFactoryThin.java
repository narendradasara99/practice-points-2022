// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

class CharacterSetFactoryThin extends CharacterSetFactory
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    public CharacterSet make(int n) {
        if (n == -1) {
            n = 31;
        }
        if (n == 2000) {
            return new CharacterSetAL16UTF16(n);
        }
        if (n == 870 || n == 871) {
            return new CharacterSetUTF(n);
        }
        if (n == 873) {
            return new CharacterSetAL32UTF8(n);
        }
        if (n == 872) {
            return new CharacterSetUTFE(n);
        }
        if (n == 2002) {
            return new CharacterSetAL16UTF16LE(n);
        }
        final CharacterSet instance = CharacterSetWithConverter.getInstance(n);
        if (instance != null) {
            return instance;
        }
        return new CharacterSetUnknown(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
