// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.Reader;
import java.io.OutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;

public interface BlobDBAccess
{
    long length(final BLOB p0) throws SQLException;
    
    long position(final BLOB p0, final byte[] p1, final long p2) throws SQLException;
    
    long position(final BLOB p0, final BLOB p1, final long p2) throws SQLException;
    
    int getBytes(final BLOB p0, final long p1, final int p2, final byte[] p3) throws SQLException;
    
    int putBytes(final BLOB p0, final long p1, final byte[] p2, final int p3, final int p4) throws SQLException;
    
    int getChunkSize(final BLOB p0) throws SQLException;
    
    void trim(final BLOB p0, final long p1) throws SQLException;
    
    BLOB createTemporaryBlob(final Connection p0, final boolean p1, final int p2) throws SQLException;
    
    void freeTemporary(final BLOB p0, final boolean p1) throws SQLException;
    
    boolean isTemporary(final BLOB p0) throws SQLException;
    
    void open(final BLOB p0, final int p1) throws SQLException;
    
    void close(final BLOB p0) throws SQLException;
    
    boolean isOpen(final BLOB p0) throws SQLException;
    
    InputStream newInputStream(final BLOB p0, final int p1, final long p2) throws SQLException;
    
    InputStream newInputStream(final BLOB p0, final int p1, final long p2, final long p3) throws SQLException;
    
    OutputStream newOutputStream(final BLOB p0, final int p1, final long p2, final boolean p3) throws SQLException;
    
    InputStream newConversionInputStream(final BLOB p0, final int p1) throws SQLException;
    
    Reader newConversionReader(final BLOB p0, final int p1) throws SQLException;
}
