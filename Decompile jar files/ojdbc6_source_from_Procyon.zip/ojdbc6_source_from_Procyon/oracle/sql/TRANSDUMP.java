// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.OracleCallableStatement;
import java.sql.Connection;

public class TRANSDUMP
{
    private static byte[] GMT_TRANSITIONS;
    
    public static byte[] getTransitions(final Connection connection, final int n) throws SQLException {
        byte[] array = null;
        if (n == ZONEIDMAP.getID("GMT")) {
            array = TRANSDUMP.GMT_TRANSITIONS;
        }
        else {
            final OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)connection.prepareCall("begin dbms_utility.get_tz_transitions(:1,:2); end;");
            oracleCallableStatement.setInt(1, n);
            oracleCallableStatement.registerOutParameter(2, -2);
            try {
                oracleCallableStatement.execute();
                array = oracleCallableStatement.getBytes(2);
            }
            finally {
                try {
                    oracleCallableStatement.close();
                }
                catch (Exception ex) {}
            }
        }
        return array;
    }
    
    static {
        TRANSDUMP.GMT_TRANSITIONS = new byte[] { 1, 118, 100, 1, 1, 1, 1, 1, 20, 60, 0 };
    }
}
