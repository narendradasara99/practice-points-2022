// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class LxMetaData
{
    private static final String DEFAULT_ES_ORA_LANGUAGE = "LATIN AMERICAN SPANISH";
    private static final int WIDTH_SIZE = 8;
    private static final short WIDTH_MASK = 255;
    public static final int ST_BADCODESET = 0;
    private static final Locale EN_LOCALE;
    private static Map ORACLE_LANG_2_ISO_A2_LANG;
    private static Map ORACLE_TERR_2_ISO_A2_TERR;
    private static Map ORACLE_LANG_2_TERR;
    private static Map ISO_A2_LANG_2_ORACLE_LANG;
    private static Map ISO_LANGUAGE_DEFAULT_TERRITORY;
    private static Map ISO_LOCALE_2_ORACLE_LOCALE;
    private static Map ISO_A2_TERR_2_ORACLE_TERR;
    private static Map CHARSET_RATIO;
    
    static Locale getJavaLocale(final String s, final String s2) {
        if (s == null) {
            return null;
        }
        String anObject = s;
        String language = LxMetaData.EN_LOCALE.getLanguage();
        if (!"".equals(anObject)) {
            if (LxMetaData.ORACLE_LANG_2_ISO_A2_LANG == null) {
                LxMetaData.ORACLE_LANG_2_ISO_A2_LANG = getLang2IsoLangMap();
            }
            language = LxMetaData.ORACLE_LANG_2_ISO_A2_LANG.get(anObject.toUpperCase(Locale.US));
            if (language == null) {
                return null;
            }
        }
        else {
            anObject = "AMERICAN";
        }
        String upperCase;
        if (s2 == null || (upperCase = s2.toUpperCase(Locale.US)) == null || "".equals(upperCase)) {
            if (LxMetaData.ORACLE_LANG_2_TERR == null) {
                LxMetaData.ORACLE_LANG_2_TERR = getLang2Terr();
            }
            upperCase = LxMetaData.ORACLE_LANG_2_TERR.get(anObject);
        }
        if (LxMetaData.ORACLE_TERR_2_ISO_A2_TERR == null) {
            LxMetaData.ORACLE_TERR_2_ISO_A2_TERR = getTerr2IsoTerrMap();
        }
        final String country = LxMetaData.ORACLE_TERR_2_ISO_A2_TERR.get(upperCase);
        if (country == null) {
            return null;
        }
        return new Locale(language, country);
    }
    
    public static String getNLSLanguage(final Locale locale) {
        final String oraLocale = getOraLocale(locale);
        if (oraLocale == null) {
            return null;
        }
        final int index = oraLocale.indexOf(95);
        return (index < 0) ? oraLocale : oraLocale.substring(0, index);
    }
    
    public static String getNLSTerritory(final Locale locale) {
        final String oraLocale = getOraLocale(locale);
        if (oraLocale == null) {
            return null;
        }
        final int index = oraLocale.indexOf(95);
        return (index < 0) ? null : oraLocale.substring(index + 1);
    }
    
    private static String getOraLocale(final Locale locale) {
        if (locale == null) {
            return null;
        }
        final String s = locale.getLanguage().equals("") ? LxMetaData.EN_LOCALE.getLanguage() : locale.getLanguage();
        if (LxMetaData.ISO_A2_LANG_2_ORACLE_LANG == null) {
            LxMetaData.ISO_A2_LANG_2_ORACLE_LANG = getIsoLangToOracleMap();
        }
        String str = LxMetaData.ISO_A2_LANG_2_ORACLE_LANG.get(s);
        if (str == null) {
            return null;
        }
        String country = locale.getCountry();
        if (country.equals("")) {
            if (LxMetaData.ISO_LANGUAGE_DEFAULT_TERRITORY == null) {
                LxMetaData.ISO_LANGUAGE_DEFAULT_TERRITORY = getIsoLangDefaultTerrMap();
            }
            country = LxMetaData.ISO_LANGUAGE_DEFAULT_TERRITORY.get(s);
            if (country == null) {
                return null;
            }
        }
        final Locale locale2 = new Locale(s, country);
        if (LxMetaData.ISO_LOCALE_2_ORACLE_LOCALE == null) {
            LxMetaData.ISO_LOCALE_2_ORACLE_LOCALE = getIsoLocToOracleMap();
        }
        final String s2 = LxMetaData.ISO_LOCALE_2_ORACLE_LOCALE.get(locale2.toString());
        if (s2 != null) {
            return s2;
        }
        if ("es".equals(s)) {
            str = "LATIN AMERICAN SPANISH";
        }
        if (LxMetaData.ISO_A2_TERR_2_ORACLE_TERR == null) {
            LxMetaData.ISO_A2_TERR_2_ORACLE_TERR = getIsoTerrToOracleMap();
        }
        final String str2 = LxMetaData.ISO_A2_TERR_2_ORACLE_TERR.get(country);
        return (str2 != null) ? (str + "_" + str2) : null;
    }
    
    public static int getRatio(final int i, final int j) {
        if (j == i) {
            return 1;
        }
        if (LxMetaData.CHARSET_RATIO == null) {
            LxMetaData.CHARSET_RATIO = getCharsetRatio();
        }
        final String value = LxMetaData.CHARSET_RATIO.get(Integer.toString(i));
        if (value == null) {
            return 0;
        }
        final int int1 = Integer.parseInt(value);
        final String value2 = LxMetaData.CHARSET_RATIO.get(Integer.toString(j));
        if (value2 == null) {
            return 0;
        }
        final int int2 = Integer.parseInt(value2);
        final int n = int1 & 0xFF;
        if (n == 1) {
            return 1;
        }
        if (int2 >>> 8 == 0) {
            return n;
        }
        final int n2 = int2 & 0xFF;
        int n3 = n / n2;
        if (n % n2 != 0) {
            ++n3;
        }
        return n3;
    }
    
    private static synchronized Map getLang2IsoLangMap() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ALBANIAN", "sq");
        hashMap.put("AMERICAN", "en");
        hashMap.put("ARABIC", "ar");
        hashMap.put("ASSAMESE", "as");
        hashMap.put("AZERBAIJANI", "az");
        hashMap.put("BANGLA", "bn");
        hashMap.put("BELARUSIAN", "be");
        hashMap.put("BENGALI", "bn");
        hashMap.put("BRAZILIAN PORTUGUESE", "pt");
        hashMap.put("BULGARIAN", "bg");
        hashMap.put("CANADIAN FRENCH", "fr");
        hashMap.put("CATALAN", "ca");
        hashMap.put("CROATIAN", "hr");
        hashMap.put("CYRILLIC KAZAKH", "kk");
        hashMap.put("CYRILLIC SERBIAN", "sr");
        hashMap.put("CYRILLIC UZBEK", "uz");
        hashMap.put("CZECH", "cs");
        hashMap.put("DANISH", "da");
        hashMap.put("DUTCH", "nl");
        hashMap.put("EGYPTIAN", "ar");
        hashMap.put("ENGLISH", "en");
        hashMap.put("ESTONIAN", "et");
        hashMap.put("FINNISH", "fi");
        hashMap.put("FRENCH", "fr");
        hashMap.put("GERMAN", "de");
        hashMap.put("GERMAN DIN", "de");
        hashMap.put("GREEK", "el");
        hashMap.put("GUJARATI", "gu");
        hashMap.put("HEBREW", "iw");
        hashMap.put("HINDI", "hi");
        hashMap.put("HUNGARIAN", "hu");
        hashMap.put("ICELANDIC", "is");
        hashMap.put("INDONESIAN", "in");
        hashMap.put("IRISH", "ga");
        hashMap.put("ITALIAN", "it");
        hashMap.put("JAPANESE", "ja");
        hashMap.put("KANNADA", "kn");
        hashMap.put("KOREAN", "ko");
        hashMap.put("LATIN AMERICAN SPANISH", "es");
        hashMap.put("LATIN SERBIAN", "sr");
        hashMap.put("LATIN UZBEK", "uz");
        hashMap.put("LATVIAN", "lv");
        hashMap.put("LITHUANIAN", "lt");
        hashMap.put("MACEDONIAN", "mk");
        hashMap.put("MALAY", "ms");
        hashMap.put("MALAYALAM", "ml");
        hashMap.put("MARATHI", "mr");
        hashMap.put("MEXICAN SPANISH", "es");
        hashMap.put("NORWEGIAN", "no");
        hashMap.put("NUMERIC DATE LANGUAGE", "en");
        hashMap.put("ORIYA", "or");
        hashMap.put("POLISH", "pl");
        hashMap.put("PORTUGUESE", "pt");
        hashMap.put("PUNJABI", "pa");
        hashMap.put("ROMANIAN", "ro");
        hashMap.put("RUSSIAN", "ru");
        hashMap.put("SIMPLIFIED CHINESE", "zh");
        hashMap.put("SLOVAK", "sk");
        hashMap.put("SLOVENIAN", "sl");
        hashMap.put("SPANISH", "es");
        hashMap.put("SWEDISH", "sv");
        hashMap.put("TAMIL", "ta");
        hashMap.put("TELUGU", "te");
        hashMap.put("THAI", "th");
        hashMap.put("TRADITIONAL CHINESE", "zh");
        hashMap.put("TURKISH", "tr");
        hashMap.put("UKRAINIAN", "uk");
        hashMap.put("VIETNAMESE", "vi");
        return hashMap;
    }
    
    private static synchronized Map getTerr2IsoTerrMap() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ALBANIA", "AL");
        hashMap.put("ALGERIA", "DZ");
        hashMap.put("AMERICA", "US");
        hashMap.put("ARGENTINA", "AR");
        hashMap.put("AUSTRALIA", "AU");
        hashMap.put("AUSTRIA", "AT");
        hashMap.put("AZERBAIJAN", "AZ");
        hashMap.put("BAHRAIN", "BH");
        hashMap.put("BANGLADESH", "BD");
        hashMap.put("BELARUS", "BY");
        hashMap.put("BELGIUM", "BE");
        hashMap.put("BRAZIL", "BR");
        hashMap.put("BULGARIA", "BG");
        hashMap.put("CANADA", "CA");
        hashMap.put("CATALONIA", "ES");
        hashMap.put("CHILE", "CL");
        hashMap.put("CHINA", "CN");
        hashMap.put("CIS", "RU");
        hashMap.put("COLOMBIA", "CO");
        hashMap.put("COSTA RICA", "CR");
        hashMap.put("CROATIA", "HR");
        hashMap.put("CYPRUS", "CY");
        hashMap.put("CZECH REPUBLIC", "CZ");
        hashMap.put("CZECHOSLOVAKIA", "CZ");
        hashMap.put("DENMARK", "DK");
        hashMap.put("DJIBOUTI", "DJ");
        hashMap.put("ECUADOR", "EC");
        hashMap.put("EGYPT", "EG");
        hashMap.put("EL SALVADOR", "SV");
        hashMap.put("ESTONIA", "EE");
        hashMap.put("FINLAND", "FI");
        hashMap.put("FRANCE", "FR");
        hashMap.put("FYR MACEDONIA", "MK");
        hashMap.put("GERMANY", "DE");
        hashMap.put("GREECE", "GR");
        hashMap.put("GUATEMALA", "GT");
        hashMap.put("HONG KONG", "HK");
        hashMap.put("HUNGARY", "HU");
        hashMap.put("ICELAND", "IS");
        hashMap.put("INDIA", "IN");
        hashMap.put("INDONESIA", "ID");
        hashMap.put("IRAQ", "IQ");
        hashMap.put("IRELAND", "IE");
        hashMap.put("ISRAEL", "IL");
        hashMap.put("ITALY", "IT");
        hashMap.put("JAPAN", "JP");
        hashMap.put("JORDAN", "JO");
        hashMap.put("KAZAKHSTAN", "KZ");
        hashMap.put("KOREA", "KR");
        hashMap.put("KUWAIT", "KW");
        hashMap.put("LATVIA", "LV");
        hashMap.put("LEBANON", "LB");
        hashMap.put("LIBYA", "LY");
        hashMap.put("LITHUANIA", "LT");
        hashMap.put("LUXEMBOURG", "LU");
        hashMap.put("MACEDONIA", "MK");
        hashMap.put("MALAYSIA", "MY");
        hashMap.put("MAURITANIA", "MR");
        hashMap.put("MEXICO", "MX");
        hashMap.put("MOROCCO", "MA");
        hashMap.put("NEW ZEALAND", "NZ");
        hashMap.put("NICARAGUA", "NI");
        hashMap.put("NORWAY", "NO");
        hashMap.put("OMAN", "OM");
        hashMap.put("PANAMA", "PA");
        hashMap.put("PERU", "PE");
        hashMap.put("PHILIPPINES", "PH");
        hashMap.put("POLAND", "PL");
        hashMap.put("PORTUGAL", "PT");
        hashMap.put("PUERTO RICO", "PR");
        hashMap.put("QATAR", "QA");
        hashMap.put("ROMANIA", "RO");
        hashMap.put("RUSSIA", "RU");
        hashMap.put("SAUDI ARABIA", "SA");
        hashMap.put("SERBIA AND MONTENEGRO", "CS");
        hashMap.put("SINGAPORE", "SG");
        hashMap.put("SLOVAKIA", "SK");
        hashMap.put("SLOVENIA", "SI");
        hashMap.put("SOMALIA", "SO");
        hashMap.put("SOUTH AFRICA", "ZA");
        hashMap.put("SPAIN", "ES");
        hashMap.put("SUDAN", "SD");
        hashMap.put("SWEDEN", "SE");
        hashMap.put("SWITZERLAND", "CH");
        hashMap.put("SYRIA", "SY");
        hashMap.put("TAIWAN", "TW");
        hashMap.put("THAILAND", "TH");
        hashMap.put("THE NETHERLANDS", "NL");
        hashMap.put("TUNISIA", "TN");
        hashMap.put("TURKEY", "TR");
        hashMap.put("UKRAINE", "UA");
        hashMap.put("UNITED ARAB EMIRATES", "AE");
        hashMap.put("UNITED KINGDOM", "GB");
        hashMap.put("UZBEKISTAN", "UZ");
        hashMap.put("VENEZUELA", "VE");
        hashMap.put("VIETNAM", "VN");
        hashMap.put("YEMEN", "YE");
        hashMap.put("YUGOSLAVIA", "YU");
        return hashMap;
    }
    
    private static synchronized Map getLang2Terr() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ALBANIAN", "ALBANIA");
        hashMap.put("AMERICAN", "AMERICA");
        hashMap.put("ARABIC", "UNITED ARAB EMIRATES");
        hashMap.put("ASSAMESE", "INDIA");
        hashMap.put("AZERBAIJANI", "AZERBAIJAN");
        hashMap.put("BANGLA", "INDIA");
        hashMap.put("BELARUSIAN", "BELARUS");
        hashMap.put("BRAZILIAN PORTUGUESE", "BRAZIL");
        hashMap.put("BULGARIAN", "BULGARIA");
        hashMap.put("CANADIAN FRENCH", "CANADA");
        hashMap.put("CATALAN", "CATALONIA");
        hashMap.put("CROATIAN", "CROATIA");
        hashMap.put("CYRILLIC KAZAKH", "KAZAKHSTAN");
        hashMap.put("CYRILLIC SERBIAN", "SERBIA AND MONTENEGRO");
        hashMap.put("CYRILLIC UZBEK", "UZBEKISTAN");
        hashMap.put("CZECH", "CZECH REPUBLIC");
        hashMap.put("DANISH", "DENMARK");
        hashMap.put("DUTCH", "THE NETHERLANDS");
        hashMap.put("EGYPTIAN", "EGYPT");
        hashMap.put("ENGLISH", "UNITED KINGDOM");
        hashMap.put("ESTONIAN", "ESTONIA");
        hashMap.put("FINNISH", "FINLAND");
        hashMap.put("FRENCH", "FRANCE");
        hashMap.put("GERMAN", "GERMANY");
        hashMap.put("GERMAN DIN", "GERMANY");
        hashMap.put("GREEK", "GREECE");
        hashMap.put("GUJARATI", "INDIA");
        hashMap.put("HEBREW", "ISRAEL");
        hashMap.put("HINDI", "INDIA");
        hashMap.put("HUNGARIAN", "HUNGARY");
        hashMap.put("ICELANDIC", "ICELAND");
        hashMap.put("INDONESIAN", "INDONESIA");
        hashMap.put("IRISH", "IRELAND");
        hashMap.put("ITALIAN", "ITALY");
        hashMap.put("JAPANESE", "JAPAN");
        hashMap.put("KANNADA", "INDIA");
        hashMap.put("KOREAN", "KOREA");
        hashMap.put("LATIN AMERICAN SPANISH", "AMERICA");
        hashMap.put("LATIN SERBIAN", "SERBIA AND MONTENEGRO");
        hashMap.put("LATIN UZBEK", "UZBEKISTAN");
        hashMap.put("LATVIAN", "LATVIA");
        hashMap.put("LITHUANIAN", "LITHUANIA");
        hashMap.put("MACEDONIAN", "FYR MACEDONIA");
        hashMap.put("MALAY", "MALAYSIA");
        hashMap.put("MALAYALAM", "INDIA");
        hashMap.put("MARATHI", "INDIA");
        hashMap.put("MEXICAN SPANISH", "MEXICO");
        hashMap.put("NORWEGIAN", "NORWAY");
        hashMap.put("ORIYA", "INDIA");
        hashMap.put("POLISH", "POLAND");
        hashMap.put("PORTUGUESE", "PORTUGAL");
        hashMap.put("PUNJABI", "INDIA");
        hashMap.put("ROMANIAN", "ROMANIA");
        hashMap.put("RUSSIAN", "RUSSIA");
        hashMap.put("SIMPLIFIED CHINESE", "CHINA");
        hashMap.put("SLOVAK", "SLOVAKIA");
        hashMap.put("SLOVENIAN", "SLOVENIA");
        hashMap.put("SPANISH", "SPAIN");
        hashMap.put("SWEDISH", "SWEDEN");
        hashMap.put("TAMIL", "INDIA");
        hashMap.put("TELUGU", "INDIA");
        hashMap.put("THAI", "THAILAND");
        hashMap.put("TRADITIONAL CHINESE", "TAIWAN");
        hashMap.put("TURKISH", "TURKEY");
        hashMap.put("UKRAINIAN", "UKRAINE");
        hashMap.put("VIETNAMESE", "VIETNAM");
        return hashMap;
    }
    
    private static synchronized Map getIsoLangToOracleMap() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ar", "ARABIC");
        hashMap.put("as", "ASSAMESE");
        hashMap.put("az", "AZERBAIJANI");
        hashMap.put("be", "BELARUSIAN");
        hashMap.put("bg", "BULGARIAN");
        hashMap.put("bn", "BANGLA");
        hashMap.put("ca", "CATALAN");
        hashMap.put("cs", "CZECH");
        hashMap.put("da", "DANISH");
        hashMap.put("de", "GERMAN");
        hashMap.put("el", "GREEK");
        hashMap.put("en", "ENGLISH");
        hashMap.put("es", "SPANISH");
        hashMap.put("et", "ESTONIAN");
        hashMap.put("fi", "FINNISH");
        hashMap.put("fr", "FRENCH");
        hashMap.put("ga", "IRISH");
        hashMap.put("gu", "GUJARATI");
        hashMap.put("he", "HEBREW");
        hashMap.put("hi", "HINDI");
        hashMap.put("hr", "CROATIAN");
        hashMap.put("hu", "HUNGARIAN");
        hashMap.put("id", "INDONESIAN");
        hashMap.put("in", "INDONESIAN");
        hashMap.put("is", "ICELANDIC");
        hashMap.put("it", "ITALIAN");
        hashMap.put("iw", "HEBREW");
        hashMap.put("ja", "JAPANESE");
        hashMap.put("kk", "CYRILLIC KAZAKH");
        hashMap.put("kn", "KANNADA");
        hashMap.put("ko", "KOREAN");
        hashMap.put("lt", "LITHUANIAN");
        hashMap.put("lv", "LATVIAN");
        hashMap.put("mk", "MACEDONIAN");
        hashMap.put("ml", "MALAYALAM");
        hashMap.put("mr", "MARATHI");
        hashMap.put("ms", "MALAY");
        hashMap.put("nb", "NORWEGIAN");
        hashMap.put("nl", "DUTCH");
        hashMap.put("nn", "NORWEGIAN");
        hashMap.put("no", "NORWEGIAN");
        hashMap.put("or", "ORIYA");
        hashMap.put("pa", "PUNJABI");
        hashMap.put("pl", "POLISH");
        hashMap.put("pt", "PORTUGUESE");
        hashMap.put("ro", "ROMANIAN");
        hashMap.put("ru", "RUSSIAN");
        hashMap.put("sk", "SLOVAK");
        hashMap.put("sl", "SLOVENIAN");
        hashMap.put("sq", "ALBANIAN");
        hashMap.put("sr", "CYRILLIC SERBIAN");
        hashMap.put("sv", "SWEDISH");
        hashMap.put("ta", "TAMIL");
        hashMap.put("te", "TELUGU");
        hashMap.put("th", "THAI");
        hashMap.put("tr", "TURKISH");
        hashMap.put("uk", "UKRAINIAN");
        hashMap.put("uz", "LATIN UZBEK");
        hashMap.put("vi", "VIETNAMESE");
        hashMap.put("zh", "SIMPLIFIED CHINESE");
        return hashMap;
    }
    
    private static synchronized Map getIsoLangDefaultTerrMap() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ar", "AE");
        hashMap.put("as", "IN");
        hashMap.put("az", "AZ");
        hashMap.put("be", "BY");
        hashMap.put("bg", "BG");
        hashMap.put("bn", "BD");
        hashMap.put("ca", "ES");
        hashMap.put("cs", "CZ");
        hashMap.put("da", "DK");
        hashMap.put("de", "DE");
        hashMap.put("el", "GR");
        hashMap.put("en", "US");
        hashMap.put("es", "ES");
        hashMap.put("et", "EE");
        hashMap.put("fi", "FI");
        hashMap.put("fr", "FR");
        hashMap.put("ga", "IE");
        hashMap.put("gu", "IN");
        hashMap.put("he", "IL");
        hashMap.put("hi", "IN");
        hashMap.put("hr", "HR");
        hashMap.put("hu", "HU");
        hashMap.put("id", "ID");
        hashMap.put("in", "ID");
        hashMap.put("is", "IS");
        hashMap.put("it", "IT");
        hashMap.put("iw", "IL");
        hashMap.put("ja", "JP");
        hashMap.put("kk", "KZ");
        hashMap.put("kn", "IN");
        hashMap.put("ko", "KR");
        hashMap.put("lt", "LT");
        hashMap.put("lv", "LV");
        hashMap.put("mk", "MK");
        hashMap.put("ml", "IN");
        hashMap.put("mr", "IN");
        hashMap.put("ms", "MY");
        hashMap.put("nb", "NO");
        hashMap.put("nl", "NL");
        hashMap.put("nn", "NO");
        hashMap.put("no", "NO");
        hashMap.put("or", "IN");
        hashMap.put("pa", "IN");
        hashMap.put("pl", "PL");
        hashMap.put("pt", "PT");
        hashMap.put("ro", "RO");
        hashMap.put("ru", "RU");
        hashMap.put("sk", "SK");
        hashMap.put("sl", "SI");
        hashMap.put("sq", "AL");
        hashMap.put("sr", "CS");
        hashMap.put("sv", "SE");
        hashMap.put("ta", "IN");
        hashMap.put("te", "IN");
        hashMap.put("th", "TH");
        hashMap.put("tr", "TR");
        hashMap.put("uk", "UA");
        hashMap.put("uz", "UZ");
        hashMap.put("vi", "VN");
        hashMap.put("zh", "CN");
        return hashMap;
    }
    
    private static synchronized Map getIsoLocToOracleMap() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ar_EG", "EGYPTIAN_EGYPT");
        hashMap.put("ca_ES", "CATALAN_CATALONIA");
        hashMap.put("en_US", "AMERICAN_AMERICA");
        hashMap.put("es_ES", "SPANISH_SPAIN");
        hashMap.put("es_MX", "MEXICAN SPANISH_MEXICO");
        hashMap.put("fr_CA", "CANADIAN FRENCH_CANADA");
        hashMap.put("pt_BR", "BRAZILIAN PORTUGUESE_BRAZIL");
        hashMap.put("zh_HK", "TRADITIONAL CHINESE_HONG KONG");
        hashMap.put("zh_TW", "TRADITIONAL CHINESE_TAIWAN");
        return hashMap;
    }
    
    private static synchronized Map getIsoTerrToOracleMap() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("AE", "UNITED ARAB EMIRATES");
        hashMap.put("AL", "ALBANIA");
        hashMap.put("AR", "ARGENTINA");
        hashMap.put("AT", "AUSTRIA");
        hashMap.put("AU", "AUSTRALIA");
        hashMap.put("AZ", "AZERBAIJAN");
        hashMap.put("BD", "BANGLADESH");
        hashMap.put("BE", "BELGIUM");
        hashMap.put("BG", "BULGARIA");
        hashMap.put("BH", "BAHRAIN");
        hashMap.put("BR", "BRAZIL");
        hashMap.put("BY", "BELARUS");
        hashMap.put("CA", "CANADA");
        hashMap.put("CH", "SWITZERLAND");
        hashMap.put("CL", "CHILE");
        hashMap.put("CN", "CHINA");
        hashMap.put("CO", "COLOMBIA");
        hashMap.put("CR", "COSTA RICA");
        hashMap.put("CS", "SERBIA AND MONTENEGRO");
        hashMap.put("CY", "CYPRUS");
        hashMap.put("CZ", "CZECH REPUBLIC");
        hashMap.put("DE", "GERMANY");
        hashMap.put("DJ", "DJIBOUTI");
        hashMap.put("DK", "DENMARK");
        hashMap.put("DZ", "ALGERIA");
        hashMap.put("EC", "ECUADOR");
        hashMap.put("EE", "ESTONIA");
        hashMap.put("EG", "EGYPT");
        hashMap.put("ES", "SPAIN");
        hashMap.put("FI", "FINLAND");
        hashMap.put("FR", "FRANCE");
        hashMap.put("GB", "UNITED KINGDOM");
        hashMap.put("GR", "GREECE");
        hashMap.put("GT", "GUATEMALA");
        hashMap.put("HK", "HONG KONG");
        hashMap.put("HR", "CROATIA");
        hashMap.put("HU", "HUNGARY");
        hashMap.put("ID", "INDONESIA");
        hashMap.put("IE", "IRELAND");
        hashMap.put("IL", "ISRAEL");
        hashMap.put("IN", "INDIA");
        hashMap.put("IQ", "IRAQ");
        hashMap.put("IS", "ICELAND");
        hashMap.put("IT", "ITALY");
        hashMap.put("JO", "JORDAN");
        hashMap.put("JP", "JAPAN");
        hashMap.put("KR", "KOREA");
        hashMap.put("KW", "KUWAIT");
        hashMap.put("KZ", "KAZAKHSTAN");
        hashMap.put("LB", "LEBANON");
        hashMap.put("LT", "LITHUANIA");
        hashMap.put("LU", "LUXEMBOURG");
        hashMap.put("LV", "LATVIA");
        hashMap.put("LY", "LIBYA");
        hashMap.put("MA", "MOROCCO");
        hashMap.put("MK", "FYR MACEDONIA");
        hashMap.put("MR", "MAURITANIA");
        hashMap.put("MX", "MEXICO");
        hashMap.put("MY", "MALAYSIA");
        hashMap.put("NI", "NICARAGUA");
        hashMap.put("NL", "THE NETHERLANDS");
        hashMap.put("NO", "NORWAY");
        hashMap.put("NZ", "NEW ZEALAND");
        hashMap.put("OM", "OMAN");
        hashMap.put("PA", "PANAMA");
        hashMap.put("PE", "PERU");
        hashMap.put("PH", "PHILIPPINES");
        hashMap.put("PL", "POLAND");
        hashMap.put("PR", "PUERTO RICO");
        hashMap.put("PT", "PORTUGAL");
        hashMap.put("QA", "QATAR");
        hashMap.put("RO", "ROMANIA");
        hashMap.put("RU", "RUSSIA");
        hashMap.put("SA", "SAUDI ARABIA");
        hashMap.put("SD", "SUDAN");
        hashMap.put("SE", "SWEDEN");
        hashMap.put("SG", "SINGAPORE");
        hashMap.put("SI", "SLOVENIA");
        hashMap.put("SK", "SLOVAKIA");
        hashMap.put("SO", "SOMALIA");
        hashMap.put("SV", "EL SALVADOR");
        hashMap.put("SY", "SYRIA");
        hashMap.put("TH", "THAILAND");
        hashMap.put("TN", "TUNISIA");
        hashMap.put("TR", "TURKEY");
        hashMap.put("TW", "TAIWAN");
        hashMap.put("UA", "UKRAINE");
        hashMap.put("US", "AMERICA");
        hashMap.put("UZ", "UZBEKISTAN");
        hashMap.put("VE", "VENEZUELA");
        hashMap.put("VN", "VIETNAM");
        hashMap.put("YE", "YEMEN");
        hashMap.put("YU", "YUGOSLAVIA");
        hashMap.put("ZA", "SOUTH AFRICA");
        return hashMap;
    }
    
    private static synchronized Map getCharsetRatio() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("2000", "258");
        hashMap.put("873", "4");
        hashMap.put("557", "1");
        hashMap.put("558", "1");
        hashMap.put("559", "1");
        hashMap.put("565", "1");
        hashMap.put("566", "1");
        hashMap.put("500", "1");
        hashMap.put("320", "1");
        hashMap.put("70", "1");
        hashMap.put("36", "1");
        hashMap.put("560", "1");
        hashMap.put("556", "1");
        hashMap.put("554", "1");
        hashMap.put("561", "1");
        hashMap.put("563", "1");
        hashMap.put("555", "1");
        hashMap.put("52", "1");
        hashMap.put("173", "1");
        hashMap.put("140", "1");
        hashMap.put("191", "1");
        hashMap.put("194", "1");
        hashMap.put("314", "1");
        hashMap.put("47", "1");
        hashMap.put("179", "1");
        hashMap.put("197", "1");
        hashMap.put("43", "1");
        hashMap.put("390", "1");
        hashMap.put("233", "1");
        hashMap.put("48", "1");
        hashMap.put("19", "1");
        hashMap.put("235", "1");
        hashMap.put("185", "1");
        hashMap.put("322", "1");
        hashMap.put("323", "1");
        hashMap.put("317", "1");
        hashMap.put("188", "1");
        hashMap.put("325", "1");
        hashMap.put("326", "1");
        hashMap.put("35", "1");
        hashMap.put("49", "1");
        hashMap.put("196", "1");
        hashMap.put("51", "1");
        hashMap.put("158", "1");
        hashMap.put("159", "1");
        hashMap.put("171", "1");
        hashMap.put("11", "1");
        hashMap.put("207", "1");
        hashMap.put("222", "1");
        hashMap.put("189", "1");
        hashMap.put("180", "1");
        hashMap.put("204", "1");
        hashMap.put("225", "1");
        hashMap.put("198", "1");
        hashMap.put("182", "1");
        hashMap.put("14", "1");
        hashMap.put("202", "1");
        hashMap.put("224", "1");
        hashMap.put("232", "1");
        hashMap.put("184", "1");
        hashMap.put("301", "1");
        hashMap.put("316", "1");
        hashMap.put("32", "1");
        hashMap.put("262", "1");
        hashMap.put("162", "1");
        hashMap.put("263", "1");
        hashMap.put("163", "1");
        hashMap.put("170", "1");
        hashMap.put("150", "1");
        hashMap.put("110", "1");
        hashMap.put("113", "1");
        hashMap.put("81", "1");
        hashMap.put("327", "1");
        hashMap.put("381", "1");
        hashMap.put("324", "1");
        hashMap.put("211", "1");
        hashMap.put("37", "1");
        hashMap.put("266", "1");
        hashMap.put("166", "1");
        hashMap.put("174", "1");
        hashMap.put("380", "1");
        hashMap.put("382", "1");
        hashMap.put("386", "1");
        hashMap.put("385", "1");
        hashMap.put("172", "1");
        hashMap.put("12", "1");
        hashMap.put("201", "1");
        hashMap.put("223", "1");
        hashMap.put("208", "1");
        hashMap.put("186", "1");
        hashMap.put("401", "1");
        hashMap.put("368", "1");
        hashMap.put("17", "1");
        hashMap.put("206", "1");
        hashMap.put("200", "1");
        hashMap.put("181", "1");
        hashMap.put("25", "1");
        hashMap.put("265", "1");
        hashMap.put("165", "1");
        hashMap.put("161", "1");
        hashMap.put("23", "1");
        hashMap.put("187", "1");
        hashMap.put("92", "1");
        hashMap.put("315", "1");
        hashMap.put("38", "1");
        hashMap.put("267", "1");
        hashMap.put("167", "1");
        hashMap.put("175", "1");
        hashMap.put("154", "1");
        hashMap.put("833", "2");
        hashMap.put("835", "2");
        hashMap.put("830", "3");
        hashMap.put("837", "3");
        hashMap.put("831", "3");
        hashMap.put("836", "2");
        hashMap.put("832", "2");
        hashMap.put("838", "2");
        hashMap.put("834", "2");
        hashMap.put("829", "2");
        hashMap.put("842", "2");
        hashMap.put("840", "2");
        hashMap.put("845", "2");
        hashMap.put("846", "2");
        hashMap.put("590", "1");
        hashMap.put("114", "1");
        hashMap.put("176", "1");
        hashMap.put("383", "1");
        hashMap.put("384", "1");
        hashMap.put("192", "1");
        hashMap.put("193", "1");
        hashMap.put("195", "1");
        hashMap.put("205", "1");
        hashMap.put("190", "1");
        hashMap.put("16", "1");
        hashMap.put("40", "1");
        hashMap.put("34", "1");
        hashMap.put("18", "1");
        hashMap.put("153", "1");
        hashMap.put("155", "1");
        hashMap.put("152", "1");
        hashMap.put("13", "1");
        hashMap.put("203", "1");
        hashMap.put("226", "1");
        hashMap.put("199", "1");
        hashMap.put("183", "1");
        hashMap.put("33", "1");
        hashMap.put("15", "1");
        hashMap.put("21", "1");
        hashMap.put("353", "1");
        hashMap.put("354", "1");
        hashMap.put("41", "1");
        hashMap.put("42", "1");
        hashMap.put("319", "1");
        hashMap.put("22", "1");
        hashMap.put("82", "1");
        hashMap.put("93", "1");
        hashMap.put("312", "1");
        hashMap.put("264", "1");
        hashMap.put("164", "1");
        hashMap.put("177", "1");
        hashMap.put("156", "1");
        hashMap.put("1", "1");
        hashMap.put("221", "1");
        hashMap.put("277", "1");
        hashMap.put("4", "1");
        hashMap.put("871", "3");
        hashMap.put("872", "4");
        hashMap.put("45", "1");
        hashMap.put("44", "1");
        hashMap.put("231", "1");
        hashMap.put("230", "1");
        hashMap.put("239", "1");
        hashMap.put("2", "1");
        hashMap.put("241", "1");
        hashMap.put("96", "1");
        hashMap.put("100", "1");
        hashMap.put("7", "1");
        hashMap.put("97", "1");
        hashMap.put("98", "1");
        hashMap.put("9", "1");
        hashMap.put("27", "1");
        hashMap.put("99", "1");
        hashMap.put("95", "1");
        hashMap.put("8", "1");
        hashMap.put("5", "1");
        hashMap.put("90", "1");
        hashMap.put("6", "1");
        hashMap.put("91", "1");
        hashMap.put("94", "1");
        hashMap.put("101", "1");
        hashMap.put("210", "1");
        hashMap.put("3", "1");
        hashMap.put("278", "1");
        hashMap.put("31", "1");
        hashMap.put("46", "1");
        hashMap.put("39", "1");
        hashMap.put("279", "1");
        hashMap.put("351", "1");
        hashMap.put("352", "1");
        hashMap.put("178", "1");
        hashMap.put("251", "1");
        hashMap.put("50", "1");
        hashMap.put("10", "1");
        hashMap.put("28", "1");
        hashMap.put("160", "1");
        hashMap.put("261", "1");
        hashMap.put("20", "1");
        hashMap.put("850", "2");
        hashMap.put("853", "2");
        hashMap.put("852", "2");
        hashMap.put("851", "2");
        hashMap.put("854", "260");
        hashMap.put("865", "2");
        hashMap.put("866", "2");
        hashMap.put("864", "2");
        hashMap.put("862", "1");
        hashMap.put("868", "2");
        hashMap.put("992", "2");
        hashMap.put("867", "2");
        hashMap.put("860", "4");
        hashMap.put("861", "2");
        hashMap.put("863", "4");
        return hashMap;
    }
    
    private LxMetaData() {
    }
    
    static {
        EN_LOCALE = new Locale("en", "US");
        LxMetaData.ORACLE_LANG_2_ISO_A2_LANG = null;
        LxMetaData.ORACLE_TERR_2_ISO_A2_TERR = null;
        LxMetaData.ORACLE_LANG_2_TERR = null;
        LxMetaData.ISO_A2_LANG_2_ORACLE_LANG = null;
        LxMetaData.ISO_LANGUAGE_DEFAULT_TERRITORY = null;
        LxMetaData.ISO_LOCALE_2_ORACLE_LOCALE = null;
        LxMetaData.ISO_A2_TERR_2_ORACLE_TERR = null;
        LxMetaData.CHARSET_RATIO = null;
    }
}
