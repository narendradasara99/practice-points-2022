// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.Writer;
import java.io.Reader;
import java.io.OutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;

public interface ClobDBAccess
{
    long length(final CLOB p0) throws SQLException;
    
    long position(final CLOB p0, final String p1, final long p2) throws SQLException;
    
    long position(final CLOB p0, final CLOB p1, final long p2) throws SQLException;
    
    int getChars(final CLOB p0, final long p1, final int p2, final char[] p3) throws SQLException;
    
    int putChars(final CLOB p0, final long p1, final char[] p2, final int p3, final int p4) throws SQLException;
    
    int getChunkSize(final CLOB p0) throws SQLException;
    
    void trim(final CLOB p0, final long p1) throws SQLException;
    
    CLOB createTemporaryClob(final Connection p0, final boolean p1, final int p2, final short p3) throws SQLException;
    
    void freeTemporary(final CLOB p0, final boolean p1) throws SQLException;
    
    boolean isTemporary(final CLOB p0) throws SQLException;
    
    void open(final CLOB p0, final int p1) throws SQLException;
    
    void close(final CLOB p0) throws SQLException;
    
    boolean isOpen(final CLOB p0) throws SQLException;
    
    InputStream newInputStream(final CLOB p0, final int p1, final long p2) throws SQLException;
    
    OutputStream newOutputStream(final CLOB p0, final int p1, final long p2, final boolean p3) throws SQLException;
    
    Reader newReader(final CLOB p0, final int p1, final long p2) throws SQLException;
    
    Reader newReader(final CLOB p0, final int p1, final long p2, final long p3) throws SQLException;
    
    Writer newWriter(final CLOB p0, final int p1, final long p2, final boolean p3) throws SQLException;
    
    char[] getCharBufferSync(final int p0);
    
    void cacheBufferSync(final char[] p0);
}
