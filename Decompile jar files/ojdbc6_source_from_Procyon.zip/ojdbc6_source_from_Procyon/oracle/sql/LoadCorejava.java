// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

class LoadCorejava
{
    static void init() {
    }
    
    static {
        System.loadLibrary("corejava");
    }
}
