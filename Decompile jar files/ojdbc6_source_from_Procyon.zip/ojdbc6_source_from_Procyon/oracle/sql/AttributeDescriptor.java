// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

public class AttributeDescriptor
{
    String attributeName;
    short attributeIdentifier;
    int attributeFlag;
    TypeDescriptor td;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    AttributeDescriptor(final String attributeName, final short attributeIdentifier, final int attributeFlag, final TypeDescriptor td) {
        this.attributeName = attributeName;
        this.attributeIdentifier = attributeIdentifier;
        this.attributeFlag = attributeFlag;
        this.td = td;
    }
    
    void setTypeDescriptor(final TypeDescriptor td) {
        this.td = td;
    }
    
    public TypeDescriptor getTypeDescriptor() {
        return this.td;
    }
    
    public String getAttributeName() {
        return this.attributeName;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
