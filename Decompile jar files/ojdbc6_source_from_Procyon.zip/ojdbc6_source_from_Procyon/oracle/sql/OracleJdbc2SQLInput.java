// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.RowId;
import java.sql.SQLXML;
import java.sql.NClob;
import java.net.URL;
import java.sql.Struct;
import java.sql.Array;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Ref;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import java.util.Map;
import java.sql.SQLInput;

public class OracleJdbc2SQLInput implements SQLInput
{
    private int index;
    private Datum[] attributes;
    private Map map;
    private OracleConnection conn;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleJdbc2SQLInput(final Datum[] attributes, final Map map, final OracleConnection conn) {
        this.attributes = attributes;
        this.map = map;
        this.conn = conn;
        this.index = 0;
    }
    
    @Override
    public String readString() throws SQLException {
        String stringValue = null;
        try {
            if (this.attributes[this.index] != null) {
                stringValue = this.attributes[this.index].stringValue();
            }
        }
        finally {
            ++this.index;
        }
        return stringValue;
    }
    
    @Override
    public boolean readBoolean() throws SQLException {
        boolean booleanValue = false;
        try {
            if (this.attributes[this.index] != null) {
                booleanValue = this.attributes[this.index].booleanValue();
            }
        }
        finally {
            ++this.index;
        }
        return booleanValue;
    }
    
    @Override
    public byte readByte() throws SQLException {
        byte byteValue = 0;
        try {
            if (this.attributes[this.index] != null) {
                byteValue = this.attributes[this.index].byteValue();
            }
        }
        finally {
            ++this.index;
        }
        return byteValue;
    }
    
    @Override
    public short readShort() throws SQLException {
        final long long1 = this.readLong();
        if (long1 > 65537L || long1 < -65538L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26, "readShort");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (short)long1;
    }
    
    @Override
    public int readInt() throws SQLException {
        int intValue = 0;
        try {
            if (this.attributes[this.index] != null) {
                intValue = this.attributes[this.index].intValue();
            }
        }
        finally {
            ++this.index;
        }
        return intValue;
    }
    
    @Override
    public long readLong() throws SQLException {
        long longValue = 0L;
        try {
            if (this.attributes[this.index] != null) {
                longValue = this.attributes[this.index].longValue();
            }
        }
        finally {
            ++this.index;
        }
        return longValue;
    }
    
    @Override
    public float readFloat() throws SQLException {
        float floatValue = 0.0f;
        try {
            if (this.attributes[this.index] != null) {
                floatValue = this.attributes[this.index].floatValue();
            }
        }
        finally {
            ++this.index;
        }
        return floatValue;
    }
    
    @Override
    public double readDouble() throws SQLException {
        double doubleValue = 0.0;
        try {
            if (this.attributes[this.index] != null) {
                doubleValue = this.attributes[this.index].doubleValue();
            }
        }
        finally {
            ++this.index;
        }
        return doubleValue;
    }
    
    @Override
    public BigDecimal readBigDecimal() throws SQLException {
        BigDecimal bigDecimalValue = null;
        try {
            if (this.attributes[this.index] != null) {
                bigDecimalValue = this.attributes[this.index].bigDecimalValue();
            }
        }
        finally {
            ++this.index;
        }
        return bigDecimalValue;
    }
    
    @Override
    public byte[] readBytes() throws SQLException {
        byte[] shareBytes = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof RAW)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                shareBytes = ((RAW)this.attributes[this.index]).shareBytes();
            }
        }
        finally {
            ++this.index;
        }
        return shareBytes;
    }
    
    @Override
    public Date readDate() throws SQLException {
        Date dateValue = null;
        try {
            if (this.attributes[this.index] != null) {
                dateValue = this.attributes[this.index].dateValue();
            }
        }
        finally {
            ++this.index;
        }
        return dateValue;
    }
    
    @Override
    public Time readTime() throws SQLException {
        Time timeValue = null;
        try {
            if (this.attributes[this.index] != null) {
                timeValue = this.attributes[this.index].timeValue();
            }
        }
        finally {
            ++this.index;
        }
        return timeValue;
    }
    
    @Override
    public Timestamp readTimestamp() throws SQLException {
        Timestamp timestampValue = null;
        try {
            if (this.attributes[this.index] != null) {
                timestampValue = this.attributes[this.index].timestampValue();
            }
        }
        finally {
            ++this.index;
        }
        return timestampValue;
    }
    
    @Override
    public Reader readCharacterStream() throws SQLException {
        Reader characterStreamValue = null;
        try {
            final Datum datum = this.attributes[this.index];
            if (datum != null) {
                characterStreamValue = datum.characterStreamValue();
            }
        }
        finally {
            ++this.index;
        }
        return characterStreamValue;
    }
    
    @Override
    public InputStream readAsciiStream() throws SQLException {
        InputStream asciiStreamValue = null;
        try {
            final Datum datum = this.attributes[this.index];
            if (datum != null) {
                asciiStreamValue = datum.asciiStreamValue();
            }
        }
        finally {
            ++this.index;
        }
        return asciiStreamValue;
    }
    
    @Override
    public InputStream readBinaryStream() throws SQLException {
        InputStream binaryStreamValue = null;
        try {
            final Datum datum = this.attributes[this.index];
            if (datum != null) {
                binaryStreamValue = datum.binaryStreamValue();
            }
        }
        finally {
            ++this.index;
        }
        return binaryStreamValue;
    }
    
    @Override
    public Object readObject() throws SQLException {
        final Datum datum = (Datum)this.readOracleObject();
        Object o = null;
        if (datum != null) {
            if (datum instanceof STRUCT) {
                o = ((STRUCT)datum).toJdbc(this.map);
            }
            else {
                o = datum.toJdbc();
            }
        }
        return o;
    }
    
    @Override
    public Ref readRef() throws SQLException {
        return this.readREF();
    }
    
    @Override
    public Blob readBlob() throws SQLException {
        return this.readBLOB();
    }
    
    @Override
    public Clob readClob() throws SQLException {
        return this.readCLOB();
    }
    
    @Override
    public Array readArray() throws SQLException {
        return this.readARRAY();
    }
    
    public Struct readStruct() throws SQLException {
        return this.readSTRUCT();
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        if (this.index == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 24);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.attributes[this.index - 1] == null;
    }
    
    public Object readOracleObject() throws SQLException {
        return this.attributes[this.index++];
    }
    
    public NUMBER readNUMBER() throws SQLException {
        NUMBER number = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof NUMBER)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                number = (NUMBER)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return number;
    }
    
    public CHAR readCHAR() throws SQLException {
        CHAR char1 = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof CHAR)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                char1 = (CHAR)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return char1;
    }
    
    public DATE readDATE() throws SQLException {
        DATE date = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof DATE)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                date = (DATE)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return date;
    }
    
    public BFILE readBFILE() throws SQLException {
        BFILE bfile = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof BFILE)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                bfile = (BFILE)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return bfile;
    }
    
    public BLOB readBLOB() throws SQLException {
        BLOB blob = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof BLOB)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                blob = (BLOB)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return blob;
    }
    
    public CLOB readCLOB() throws SQLException {
        CLOB clob = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof CLOB)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                clob = (CLOB)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return clob;
    }
    
    public RAW readRAW() throws SQLException {
        RAW raw = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof RAW)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                raw = (RAW)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return raw;
    }
    
    public REF readREF() throws SQLException {
        REF ref = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof REF)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                ref = (REF)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return ref;
    }
    
    public ROWID readROWID() throws SQLException {
        ROWID rowid = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof ROWID)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                rowid = (ROWID)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return rowid;
    }
    
    public ARRAY readARRAY() throws SQLException {
        ARRAY array = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof ARRAY)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                array = (ARRAY)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return array;
    }
    
    public STRUCT readSTRUCT() throws SQLException {
        STRUCT struct = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof STRUCT)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                struct = (STRUCT)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return struct;
    }
    
    @Override
    public URL readURL() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public NClob readNClob() throws SQLException {
        NClob nClob = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof NCLOB)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                nClob = (NCLOB)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return nClob;
    }
    
    @Override
    public String readNString() throws SQLException {
        return this.readString();
    }
    
    @Override
    public SQLXML readSQLXML() throws SQLException {
        SQLXML sqlxml = null;
        try {
            if (this.attributes[this.index] != null) {
                if (!(this.attributes[this.index] instanceof SQLXML)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, null);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                sqlxml = (SQLXML)this.attributes[this.index];
            }
        }
        finally {
            ++this.index;
        }
        return sqlxml;
    }
    
    @Override
    public RowId readRowId() throws SQLException {
        return this.readROWID();
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
