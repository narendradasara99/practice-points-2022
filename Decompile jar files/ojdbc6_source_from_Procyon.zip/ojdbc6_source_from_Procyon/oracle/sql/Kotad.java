// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.oracore.PickleContext;
import java.sql.SQLException;

class Kotad
{
    static final int KOTADSIG = -1365573631;
    static final int KOTPDSIG = -1365442559;
    static final int KOTRDSIG = -1365377023;
    static final int KOTCDSIG = -1365311487;
    static final int KOTODSIG = -1365307391;
    static final int KOTADXSIG = -1365303295;
    static final int KOTADPRV = 1;
    static final int KOTADPUB = 2;
    static final int KOTADCNT = 4;
    static final int KOTADCFM = 248;
    static final int KOTADSUB = 256;
    static final int KOTADPTR = 16384;
    static final int KOTADREF = 32768;
    static final int KOTADCNN = 65536;
    static final int KOTADCFN = 131072;
    static final int KOTADCVN = 262144;
    static final int KOTADTRN = 512;
    static final int KOTADCPT = 4096;
    static final int KOTADIN = 256;
    static final int KOTADOUT = 512;
    static final int KOTADCBR = 1024;
    static final int KOTADREQ = 2048;
    static final int KOTADNCP = 1048576;
    private int kotadkvn;
    private byte[] kotadnam;
    private byte[] kotadtrf;
    private short kotadtvn;
    private short kotadid;
    private byte[] kotadprf;
    private short kotadpvn;
    private int kotadflg;
    private long kotadpre;
    private int kotadcid;
    private byte kotadscl;
    private int kotadcne;
    private byte[] kotaddft;
    private long kotadtyp;
    private byte[] kotadadd;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    private Kotad() throws SQLException {
    }
    
    private static Kotad unpickleKotad(final PickleContext pickleContext) throws SQLException {
        final Kotad kotad = new Kotad();
        pickleContext.skipBytes(2);
        final long n = pickleContext.readLength(true) - 2;
        pickleContext.skipBytes(1);
        kotad.kotadkvn = (int)pickleContext.readUB4();
        kotad.kotadnam = pickleContext.readDataValue();
        kotad.kotadtrf = pickleContext.readDataValue();
        pickleContext.skipBytes(1);
        kotad.kotadtvn = (short)pickleContext.readUB2();
        pickleContext.skipBytes(1);
        kotad.kotadid = (short)pickleContext.readUB2();
        kotad.kotadprf = pickleContext.readDataValue();
        pickleContext.skipBytes(1);
        kotad.kotadpvn = (short)pickleContext.readUB2();
        pickleContext.skipBytes(1);
        kotad.kotadflg = (int)pickleContext.readUB4();
        pickleContext.skipBytes(1);
        kotad.kotadpre = pickleContext.readUB4();
        pickleContext.skipBytes(1);
        kotad.kotadcid = pickleContext.readUB2();
        pickleContext.skipBytes(1);
        kotad.kotadscl = pickleContext.readByte();
        pickleContext.skipBytes(1);
        kotad.kotadcne = (int)pickleContext.readUB4();
        kotad.kotaddft = pickleContext.readDataValue();
        pickleContext.skipBytes(1);
        kotad.kotadtyp = pickleContext.readUB4();
        kotad.kotadadd = pickleContext.readDataValue();
        return kotad;
    }
    
    static final TypeDescriptor unpickleTypeDescriptorImage(final PickleContext pickleContext) throws SQLException {
        final Kotad unpickleKotad = unpickleKotad(pickleContext);
        if (unpickleKotad.kotadkvn != -1365311487) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 179);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return constructPredefinedTypeDescriptor(unpickleKotad);
    }
    
    static final AttributeDescriptor unpickleAttributeImage(final boolean b, final PickleContext pickleContext) throws SQLException {
        final Kotad unpickleKotad = unpickleKotad(pickleContext);
        if (unpickleKotad.kotadkvn != -1365573631) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 179);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        TypeDescriptor constructPredefinedTypeDescriptor = null;
        if (b) {
            constructPredefinedTypeDescriptor = constructPredefinedTypeDescriptor(unpickleKotad);
        }
        return new AttributeDescriptor(new String(unpickleKotad.kotadnam), unpickleKotad.kotadid, unpickleKotad.kotadflg, constructPredefinedTypeDescriptor);
    }
    
    private static final TypeDescriptor constructPredefinedTypeDescriptor(final Kotad kotad) throws SQLException {
        if (kotad.kotadtrf.length != 36) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 180);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        for (int i = 4; i < 18; ++i) {
            if (kotad.kotadtrf[i] != 0) {
                final SQLException sqlException2 = DatabaseError.createSqlException(null, 180);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        final TypeDescriptor typeDescriptor = new TypeDescriptor(TypeDescriptor.OID_TO_TYPECODE[kotad.kotadtrf[19]]);
        typeDescriptor.setPrecision(kotad.kotadpre);
        typeDescriptor.setScale(kotad.kotadscl);
        return typeDescriptor;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
