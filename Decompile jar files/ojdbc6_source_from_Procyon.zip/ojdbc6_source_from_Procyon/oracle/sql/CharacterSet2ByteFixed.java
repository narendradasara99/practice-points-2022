// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.converter.JdbcCharacterConverters;

class CharacterSet2ByteFixed extends CharacterSetWithConverter
{
    static final String CHAR_CONV_SUPERCLASS_NAME = "oracle.sql.converter.CharacterConverter2ByteFixed";
    static final short MAX_7BIT = 127;
    static final short MIN_8BIT_SB = 161;
    static final short MAX_8BIT_SB = 223;
    static final short CHARLENGTH = 2;
    static Class m_charConvSuperclass;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSet2ByteFixed(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        super(n, jdbcCharacterConverters);
    }
    
    static CharacterSet2ByteFixed getInstance(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        if (jdbcCharacterConverters.getGroupId() == 6) {
            return new CharacterSet2ByteFixed(n, jdbcCharacterConverters);
        }
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        final int n = characterWalker.bytes[characterWalker.next] & 0xFF;
        ++characterWalker.next;
        if (characterWalker.bytes.length > characterWalker.next) {
            final int n2 = n << 8 | characterWalker.bytes[characterWalker.next];
            ++characterWalker.next;
            return n2;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        CharacterSet.need(characterBuffer, 2);
        characterBuffer.bytes[characterBuffer.next++] = (byte)(n >> 8 & 0xFF);
        characterBuffer.bytes[characterBuffer.next++] = (byte)(n & 0xFF);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
