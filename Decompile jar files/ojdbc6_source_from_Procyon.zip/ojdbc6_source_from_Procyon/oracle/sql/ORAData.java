// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.internal.ObjectData;

public interface ORAData extends ObjectData
{
    Datum toDatum(final Connection p0) throws SQLException;
}
