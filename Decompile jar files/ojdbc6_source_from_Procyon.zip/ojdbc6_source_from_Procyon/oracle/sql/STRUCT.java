// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.ResultSetMetaData;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Hashtable;
import java.sql.SQLOutput;
import java.sql.SQLData;
import java.util.Map;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.OracleConnection;
import java.sql.Connection;
import java.sql.Struct;

public class STRUCT extends DatumWithConnection implements Struct
{
    StructDescriptor descriptor;
    Datum[] datumArray;
    Object[] objectArray;
    boolean enableLocalCache;
    long imageOffset;
    long imageLength;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public STRUCT(final StructDescriptor descriptor, final Connection connection, final Object[] array) throws SQLException {
        this.enableLocalCache = false;
        DatumWithConnection.assertNotNull(descriptor);
        this.descriptor = descriptor;
        DatumWithConnection.assertNotNull(connection);
        if (!descriptor.getInternalConnection().isDescriptorSharable(((OracleConnection)connection).physicalConnectionWithin())) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct STRUCT instance,invalid connection");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        descriptor.setConnection(connection);
        if (!this.descriptor.isInstantiable()) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct STRUCT instance for a non-instantiable object type");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.setPhysicalConnectionOf(connection);
        if (array != null) {
            this.datumArray = this.descriptor.toArray(array);
        }
        else {
            this.datumArray = new Datum[this.descriptor.getLength()];
        }
    }
    
    public STRUCT(final StructDescriptor descriptor, final Connection connection, final Map map) throws SQLException {
        this.enableLocalCache = false;
        DatumWithConnection.assertNotNull(descriptor);
        this.descriptor = descriptor;
        DatumWithConnection.assertNotNull(connection);
        if (!descriptor.getInternalConnection().isDescriptorSharable(((OracleConnection)connection).physicalConnectionWithin())) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct STRUCT instance,invalid connection");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        descriptor.setConnection(connection);
        if (!this.descriptor.isInstantiable()) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct STRUCT instance for a non-instantiable object type");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.setPhysicalConnectionOf(connection);
        this.datumArray = this.descriptor.toOracleArray(map);
    }
    
    public STRUCT(final StructDescriptor descriptor, final byte[] array, final Connection connection) throws SQLException {
        super(array);
        this.enableLocalCache = false;
        DatumWithConnection.assertNotNull(descriptor);
        this.descriptor = descriptor;
        DatumWithConnection.assertNotNull(connection);
        if (!descriptor.getInternalConnection().isDescriptorSharable(((OracleConnection)connection).physicalConnectionWithin())) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct STRUCT instance,invalid connection");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        descriptor.setConnection(connection);
        this.setPhysicalConnectionOf(connection);
        this.datumArray = null;
    }
    
    @Override
    public String getSQLTypeName() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.getName();
        }
    }
    
    @Override
    public Object[] getAttributes() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.getAttributes(this.getMap());
        }
    }
    
    @Override
    public Object[] getAttributes(final Map map) throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toArray(this, map, this.enableLocalCache);
        }
    }
    
    public StructDescriptor getDescriptor() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor;
        }
    }
    
    public void setDescriptor(final StructDescriptor descriptor) {
        this.descriptor = descriptor;
    }
    
    public Datum[] getOracleAttributes() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toOracleArray(this, this.enableLocalCache);
        }
    }
    
    public Map getMap() {
        Map typeMap = null;
        try {
            typeMap = this.getInternalConnection().getTypeMap();
        }
        catch (SQLException ex) {}
        return typeMap;
    }
    
    public byte[] toBytes() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.descriptor.toBytes(this, this.enableLocalCache);
        }
    }
    
    public void setDatumArray(final Datum[] array) {
        try {
            this.datumArray = ((array == null) ? new Datum[this.descriptor.getLength()] : array);
        }
        catch (SQLException ex) {}
    }
    
    public void setObjArray(final Object[] array) throws SQLException {
        synchronized (this.getInternalConnection()) {
            this.objectArray = ((array == null) ? new Object[0] : array);
        }
    }
    
    public static STRUCT toSTRUCT(final Object o, final OracleConnection oracleConnection) throws SQLException {
        STRUCT struct = null;
        if (o != null) {
            if (o instanceof STRUCT) {
                struct = (STRUCT)o;
            }
            else if (o instanceof ORAData) {
                struct = (STRUCT)((ORAData)o).toDatum(oracleConnection);
            }
            else if (o instanceof CustomDatum) {
                struct = (STRUCT)((oracle.jdbc.internal.OracleConnection)oracleConnection).toDatum((CustomDatum)o);
            }
            else {
                if (!(o instanceof SQLData)) {
                    final SQLException sqlException = DatabaseError.createSqlException(null, 59, o);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                final SQLData sqlData = (SQLData)o;
                final SQLOutput jdbc2SQLOutput = StructDescriptor.createDescriptor(sqlData.getSQLTypeName(), oracleConnection).toJdbc2SQLOutput();
                sqlData.writeSQL(jdbc2SQLOutput);
                struct = ((OracleSQLOutput)jdbc2SQLOutput).getSTRUCT();
            }
        }
        return struct;
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this.toJdbc(this.getMap());
    }
    
    public Object toJdbc(final Map map) throws SQLException {
        Object class1 = this;
        if (map != null) {
            final Class class2 = this.descriptor.getClass(map);
            if (class2 != null) {
                class1 = this.toClass(class2, map);
            }
        }
        return class1;
    }
    
    public Object toClass(final Class clazz) throws SQLException {
        return this.toClass(clazz, this.getMap());
    }
    
    public Object toClass(final Class clazz, final Map map) throws SQLException {
        Object o;
        try {
            if (clazz == null || clazz == STRUCT.class || clazz == Struct.class) {
                o = this;
            }
            else {
                final STRUCT instance = clazz.newInstance();
                if (instance instanceof SQLData) {
                    ((SQLData)instance).readSQL(this.descriptor.toJdbc2SQLInput(this, map), this.descriptor.getName());
                    o = instance;
                }
                else if (instance instanceof ORADataFactory) {
                    o = ((ORADataFactory)instance).create(this, 2002);
                }
                else {
                    if (!(instance instanceof CustomDatumFactory)) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, this.descriptor.getName());
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    o = ((CustomDatumFactory)instance).create(this, 2002);
                }
            }
        }
        catch (InstantiationException ex) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, "InstantiationException: " + ex.getMessage());
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        catch (IllegalAccessException ex2) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 49, "IllegalAccessException: " + ex2.getMessage());
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        return o;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return false;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new Object[n];
    }
    
    public void setAutoBuffering(final boolean enableLocalCache) throws SQLException {
        synchronized (this.getInternalConnection()) {
            this.enableLocalCache = enableLocalCache;
        }
    }
    
    public boolean getAutoBuffering() throws SQLException {
        synchronized (this.getInternalConnection()) {
            return this.enableLocalCache;
        }
    }
    
    public void setImage(final byte[] shareBytes, final long imageOffset, final long imageLength) throws SQLException {
        this.setShareBytes(shareBytes);
        this.imageOffset = imageOffset;
        this.imageLength = imageLength;
    }
    
    public void setImageLength(final long imageLength) throws SQLException {
        this.imageLength = imageLength;
    }
    
    public long getImageOffset() {
        return this.imageOffset;
    }
    
    public long getImageLength() {
        return this.imageLength;
    }
    
    public CustomDatumFactory getFactory(final Hashtable hashtable, final String s) throws SQLException {
        final String sqlTypeName = this.getSQLTypeName();
        final CustomDatumFactory value = hashtable.get(sqlTypeName);
        if (value == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Unable to convert a \"" + sqlTypeName + "\" to a \"" + s + "\" or a subclass of \"" + s + "\"");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return value;
    }
    
    public ORADataFactory getORADataFactory(final Hashtable hashtable, final String s) throws SQLException {
        final String sqlTypeName = this.getSQLTypeName();
        final ORADataFactory value = hashtable.get(sqlTypeName);
        if (value == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Unable to convert a \"" + sqlTypeName + "\" to a \"" + s + "\" or a subclass of \"" + s + "\"");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return value;
    }
    
    public String debugString() {
        final StringWriter stringWriter = new StringWriter();
        String string;
        try {
            final StructDescriptor descriptor = this.getDescriptor();
            stringWriter.write("name = " + descriptor.getName());
            final int length;
            stringWriter.write(" length = " + (length = descriptor.getLength()));
            final Object[] attributes = this.getAttributes();
            for (int i = 0; i < length; ++i) {
                stringWriter.write(" attribute[" + i + "] = " + attributes[i]);
            }
            string = stringWriter.toString();
        }
        catch (SQLException ex) {
            string = "StructDescriptor missing or bad";
        }
        return string;
    }
    
    public boolean isInHierarchyOf(final String s) throws SQLException {
        return this.getDescriptor().isInHierarchyOf(s);
    }
    
    @Override
    public Connection getJavaSqlConnection() throws SQLException {
        return super.getJavaSqlConnection();
    }
    
    public String dump() throws SQLException {
        return dump(this);
    }
    
    public static String dump(final Object o) throws SQLException {
        final StringWriter out = new StringWriter();
        dump(o, new PrintWriter(out));
        return out.getBuffer().substring(0);
    }
    
    public static void dump(final Object o, final PrintStream out) throws SQLException {
        dump(o, new PrintWriter(out, true));
    }
    
    public static void dump(final Object o, final PrintWriter printWriter) throws SQLException {
        dump(o, printWriter, 0);
    }
    
    static void dump(final Object o, final PrintWriter printWriter, final int n) throws SQLException {
        if (o instanceof STRUCT) {
            dump((STRUCT)o, printWriter, n);
            return;
        }
        if (o instanceof ARRAY) {
            ARRAY.dump((ARRAY)o, printWriter, n);
            return;
        }
        if (o == null) {
            printWriter.println("null");
        }
        else {
            printWriter.println(o.toString());
        }
    }
    
    static void dump(final STRUCT struct, final PrintWriter printWriter, final int n) throws SQLException {
        final StructDescriptor descriptor = struct.getDescriptor();
        final ResultSetMetaData metaData = descriptor.getMetaData();
        for (int i = 0; i < n; ++i) {
            printWriter.print(' ');
        }
        printWriter.println("name = " + descriptor.getName());
        for (int j = 0; j < n; ++j) {
            printWriter.print(' ');
        }
        final int length;
        printWriter.println("length = " + (length = descriptor.getLength()));
        final Object[] attributes = struct.getAttributes();
        for (int k = 0; k < length; ++k) {
            for (int l = 0; l < n; ++l) {
                printWriter.print(' ');
            }
            printWriter.print(metaData.getColumnName(k + 1) + " = ");
            dump(attributes[k], printWriter, n + 1);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
