// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.internal.OracleConnection;

public class SQLUtil
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static Object SQLToJava(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final Class clazz, final Map map) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.SQLToJava(oracleConnection, array, n, s, clazz, map);
    }
    
    public static CustomDatum SQLToJava(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final CustomDatumFactory customDatumFactory) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.SQLToJava(oracleConnection, array, n, s, customDatumFactory);
    }
    
    public static ORAData SQLToJava(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final ORADataFactory oraDataFactory) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.SQLToJava(oracleConnection, array, n, s, oraDataFactory);
    }
    
    public static Object SQLToJava(final OracleConnection oracleConnection, final Datum datum, final Class clazz, final Map map) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.SQLToJava(oracleConnection, datum, clazz, map);
    }
    
    public static byte[] JavaToSQL(final OracleConnection oracleConnection, final Object o, final int n, final String s) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.JavaToSQL(oracleConnection, o, n, s);
    }
    
    public static Datum makeDatum(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final int n2) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.makeDatum(oracleConnection, array, n, s, n2);
    }
    
    public static Datum makeDatum(final OracleConnection oracleConnection, final Object o, final int n, final String s) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.makeDatum(oracleConnection, o, n, s);
    }
    
    public static Object getTypeDescriptor(final String s, final OracleConnection oracleConnection) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.getTypeDescriptor(s, oracleConnection);
    }
    
    public static boolean checkDatumType(final Datum datum, final int n, final String s) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.checkDatumType(datum, n, s);
    }
    
    public static boolean implementsInterface(final Class clazz, final Class clazz2) {
        return oracle.jdbc.driver.SQLUtil.implementsInterface(clazz, clazz2);
    }
    
    public static Datum makeOracleDatum(final OracleConnection oracleConnection, final Object o, final int n, final String s) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.makeOracleDatum(oracleConnection, o, n, s);
    }
    
    public static int getInternalType(final int n) throws SQLException {
        return oracle.jdbc.driver.SQLUtil.getInternalType(n);
    }
    
    @Deprecated
    public static int get_internal_type(final int n) throws SQLException {
        return getInternalType(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
