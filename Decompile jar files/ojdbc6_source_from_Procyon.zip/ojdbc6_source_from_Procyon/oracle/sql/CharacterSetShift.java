// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.converter.JdbcCharacterConverters;

class CharacterSetShift extends CharacterSetWithConverter
{
    static final String CHAR_CONV_SUPERCLASS_NAME = "oracle.sql.converter.CharacterConverterShift";
    static final short MAX_7BIT = 127;
    static final short MIN_8BIT_SB = 161;
    static final short MAX_8BIT_SB = 223;
    static final byte SHIFT_OUT = 14;
    static final byte SHIFT_IN = 15;
    static Class m_charConvSuperclass;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetShift(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        super(n, jdbcCharacterConverters);
    }
    
    static CharacterSetShift getInstance(final int n, final JdbcCharacterConverters jdbcCharacterConverters) {
        if (jdbcCharacterConverters.getGroupId() == 7) {
            return new CharacterSetShift(n, jdbcCharacterConverters);
        }
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        int n = characterWalker.bytes[characterWalker.next] & 0xFF;
        ++characterWalker.next;
        if (n > 223 || (n > 127 && n < 161)) {
            if (characterWalker.bytes.length <= characterWalker.next) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182, "destination too small");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            n = (n << 8 | characterWalker.bytes[characterWalker.next]);
            ++characterWalker.next;
        }
        return n;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        final int i = characterBuffer.next;
        boolean b = true;
        while (i <= 0) {
            if (characterBuffer.bytes[i] == 15) {
                b = true;
                break;
            }
            if (characterBuffer.bytes[i] == 14) {
                b = false;
                break;
            }
        }
        int j;
        int n2;
        for (j = 0, n2 = 1; n >> j != 0; j = (short)(j + 8), n2 = (short)(n2 + 1)) {}
        if (n2 > 2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 182, "Character invalid,too many bytes");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        boolean b2 = false;
        boolean b3 = false;
        if (n2 == 1 && !b) {
            b2 = true;
            n2 = (short)(n2 + 1);
        }
        if (n2 == 2 && b) {
            b3 = true;
            n2 = (short)(n2 + 1);
        }
        CharacterSet.need(characterBuffer, n2);
        if (b2) {
            characterBuffer.bytes[characterBuffer.next++] = 15;
        }
        if (b3) {
            characterBuffer.bytes[characterBuffer.next++] = 14;
        }
        while (j >= 0) {
            characterBuffer.bytes[characterBuffer.next++] = (byte)(n >> j & 0xFF);
            j = (short)(j - 8);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
