// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.sql.SQLException;

class CharacterSetAL16UTF16LE extends CharacterSet implements CharacterRepConstants
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetAL16UTF16LE(final int n) {
        super(n);
        this.rep = 5;
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return !set.isUnicode();
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.rep <= 1024;
    }
    
    @Override
    public boolean isUnicode() {
        return true;
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        try {
            final char[] value = new char[Math.min(array.length - n >>> 1, n2 >>> 1)];
            return new String(value, 0, CharacterSet.convertAL16UTF16LEBytesToJavaChars(array, n, value, 0, n2, true));
        }
        catch (SQLException ex) {
            return "";
        }
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        try {
            final char[] value = new char[Math.min(array.length - n >>> 1, n2 >>> 1)];
            return new String(value, 0, CharacterSet.convertAL16UTF16LEBytesToJavaChars(array, n, value, 0, n2, false));
        }
        catch (SQLException ex) {
            failUTFConversion();
            return "";
        }
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        return CharacterSet.stringToAL16UTF16LEBytes(s);
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        return CharacterSet.stringToAL16UTF16LEBytes(s);
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        byte[] array2;
        if (set.rep == 5) {
            array2 = CharacterSet.useOrCopy(array, n, n2);
        }
        else {
            array2 = CharacterSet.stringToAL16UTF16LEBytes(set.toString(array, n, n2));
        }
        return array2;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        final byte[] bytes = characterWalker.bytes;
        int next = characterWalker.next;
        if (next + 2 >= characterWalker.end) {
            failUTFConversion();
        }
        final int n = (bytes[next++] << 8 & 0xFF00) | bytes[next++];
        characterWalker.next = next;
        return n;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        if (n > 65535) {
            failUTFConversion();
        }
        else {
            CharacterSet.need(characterBuffer, 2);
            characterBuffer.bytes[characterBuffer.next++] = (byte)(n >> 8 & 0xFF);
            characterBuffer.bytes[characterBuffer.next++] = (byte)(n & 0xFF);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
