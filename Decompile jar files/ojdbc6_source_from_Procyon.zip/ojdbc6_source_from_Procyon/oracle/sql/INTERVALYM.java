// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

public class INTERVALYM extends Datum
{
    private static int MASKVAL;
    private static int INTYMYEAROFFSET;
    private static int INTYMMONTHOFFSET;
    private static int INTERVALYMMAXLENGTH;
    private static int MAXYEARPREC;
    private static int MAXMONTH;
    
    public INTERVALYM() {
        super(_initIntervalYM());
    }
    
    public INTERVALYM(final byte[] array) {
        super(array);
    }
    
    public INTERVALYM(final String s) {
        super(toBytes(s));
    }
    
    public byte[] toBytes() {
        return this.getBytes();
    }
    
    public static byte[] toBytes(final String s) {
        final byte[] array = new byte[INTERVALYM.INTERVALYMMAXLENGTH];
        final String trim = s.trim();
        final char char1 = trim.charAt(0);
        int beginIndex;
        if (char1 != '-' && char1 != '+') {
            beginIndex = 0;
        }
        else {
            beginIndex = 1;
        }
        final String substring = trim.substring(beginIndex);
        final int index = substring.indexOf(45);
        final String substring2 = substring.substring(0, index);
        if (substring2.length() > INTERVALYM.MAXYEARPREC) {
            throw new NumberFormatException();
        }
        int intValue = Integer.valueOf(substring2);
        int intValue2 = Integer.valueOf(substring.substring(index + 1));
        if (intValue2 >= INTERVALYM.MAXMONTH) {
            throw new NumberFormatException();
        }
        if (char1 == '-') {
            intValue *= -1;
            intValue2 *= -1;
        }
        final int n = intValue + INTERVALYM.INTYMYEAROFFSET;
        array[0] = utilpack.RIGHTSHIFTFIRSTNIBBLE(n);
        array[1] = utilpack.RIGHTSHIFTSECONDNIBBLE(n);
        array[2] = utilpack.RIGHTSHIFTTHIRDNIBBLE(n);
        array[3] = utilpack.RIGHTSHIFTFOURTHNIBBLE(n);
        array[4] = (byte)(intValue2 + INTERVALYM.INTYMMONTHOFFSET);
        return array;
    }
    
    public static String toString(final byte[] array) {
        boolean b = true;
        int n = (utilpack.LEFTSHIFTFIRSTNIBBLE(array[0]) | utilpack.LEFTSHIFTSECONDNIBBLE(array[1]) | utilpack.LEFTSHIFTTHIRDNIBBLE(array[2]) | (array[3] & 0xFF)) - INTERVALYM.INTYMYEAROFFSET;
        int n2 = array[4] - INTERVALYM.INTYMMONTHOFFSET;
        if (n < 0) {
            b = false;
            n = -n;
        }
        if (n2 < 0) {
            b = false;
            n2 = -n2;
        }
        String s;
        if (b) {
            s = n + "-" + n2;
        }
        else {
            s = "-" + n + "-" + n2;
        }
        return s;
    }
    
    @Override
    public Object toJdbc() {
        return this;
    }
    
    @Override
    public String stringValue() {
        return toString(this.getBytes());
    }
    
    @Override
    public String toString() {
        return toString(this.getBytes());
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return new INTERVALYM[n];
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return clazz.getName().compareTo("java.lang.String") == 0;
    }
    
    private static byte[] _initIntervalYM() {
        final byte[] array = new byte[INTERVALYM.INTERVALYMMAXLENGTH];
        final int n = 0;
        final int n2 = 0;
        final int n3 = n + INTERVALYM.INTYMYEAROFFSET;
        array[0] = utilpack.RIGHTSHIFTFIRSTNIBBLE(n3);
        array[1] = utilpack.RIGHTSHIFTSECONDNIBBLE(n3);
        array[2] = utilpack.RIGHTSHIFTTHIRDNIBBLE(n3);
        array[3] = utilpack.RIGHTSHIFTFOURTHNIBBLE(n3);
        array[4] = (byte)(n2 + INTERVALYM.INTYMMONTHOFFSET);
        return array;
    }
    
    static {
        INTERVALYM.MASKVAL = 255;
        INTERVALYM.INTYMYEAROFFSET = Integer.MIN_VALUE;
        INTERVALYM.INTYMMONTHOFFSET = 60;
        INTERVALYM.INTERVALYMMAXLENGTH = 5;
        INTERVALYM.MAXYEARPREC = 9;
        INTERVALYM.MAXMONTH = 12;
    }
}
