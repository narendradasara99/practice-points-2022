// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLException;

class CharacterSetUnknown extends CharacterSet implements CharacterRepConstants
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharacterSetUnknown(final int n) {
        super(n);
        this.rep = 1024 + n;
    }
    
    @Override
    public boolean isLossyFrom(final CharacterSet set) {
        return set.getOracleId() != this.getOracleId();
    }
    
    @Override
    public boolean isConvertibleFrom(final CharacterSet set) {
        return set.getOracleId() == this.getOracleId();
    }
    
    @Override
    public String toStringWithReplacement(final byte[] array, final int n, final int n2) {
        return "???";
    }
    
    @Override
    public String toString(final byte[] array, final int n, final int n2) throws SQLException {
        failCharsetUnknown(this);
        return null;
    }
    
    @Override
    public byte[] convert(final String s) throws SQLException {
        failCharsetUnknown(this);
        return null;
    }
    
    @Override
    public byte[] convertWithReplacement(final String s) {
        return new byte[0];
    }
    
    @Override
    public byte[] convert(final CharacterSet set, final byte[] array, final int n, final int n2) throws SQLException {
        if (set.getOracleId() == this.getOracleId()) {
            return CharacterSet.useOrCopy(array, n, n2);
        }
        failCharsetUnknown(this);
        return null;
    }
    
    @Override
    int decode(final CharacterWalker characterWalker) throws SQLException {
        failCharsetUnknown(this);
        return 0;
    }
    
    @Override
    void encode(final CharacterBuffer characterBuffer, final int n) throws SQLException {
        failCharsetUnknown(this);
    }
    
    static void failCharsetUnknown(final CharacterSet set) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(null, 56, set);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean isUnknown() {
        return true;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
