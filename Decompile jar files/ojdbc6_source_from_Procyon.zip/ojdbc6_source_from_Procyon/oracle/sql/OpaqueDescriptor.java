// 
// Decompiled by Procyon v0.5.36
// 

package oracle.sql;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeOPAQUE;
import java.sql.SQLException;
import java.sql.Connection;
import java.io.Serializable;

public class OpaqueDescriptor extends TypeDescriptor implements Serializable
{
    static final boolean DEBUG = false;
    static final long serialVersionUID = 1013921343538311063L;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OpaqueDescriptor(final String s, final Connection connection) throws SQLException {
        super((short)58, s, connection);
        this.initPickler();
    }
    
    public OpaqueDescriptor(final SQLName sqlName, final Connection connection) throws SQLException {
        super((short)58, sqlName, connection);
        this.initPickler();
    }
    
    public OpaqueDescriptor(final SQLName sqlName, final OracleTypeOPAQUE oracleTypeOPAQUE, final Connection connection) throws SQLException {
        super((short)58, sqlName, oracleTypeOPAQUE, connection);
    }
    
    public OpaqueDescriptor(final OracleTypeADT oracleTypeADT, final Connection connection) throws SQLException {
        super((short)58, oracleTypeADT, connection);
    }
    
    OpaqueDescriptor(final byte[] toid, final int toidVersion, final Connection physicalConnectionOf) throws SQLException {
        super((short)108);
        this.toid = toid;
        this.toidVersion = toidVersion;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.initPickler();
    }
    
    public static OpaqueDescriptor createDescriptor(final String s, final Connection connection) throws SQLException {
        if (s == null || s.length() == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 60, "Invalid argument,'name' shouldn't be null nor an empty string and 'conn' should not be null");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return createDescriptor(new SQLName(s, (oracle.jdbc.OracleConnection)connection), connection);
    }
    
    public static OpaqueDescriptor createDescriptor(final SQLName sqlName, final Connection connection) throws SQLException {
        final String name = sqlName.getName();
        Object o = null;
        if (connection != null) {
            o = ((oracle.jdbc.OracleConnection)connection).getDescriptor(name);
        }
        if (o == null) {
            if (name.equals("SYS.ANYTYPE")) {
                o = new OpaqueDescriptor(sqlName, new OracleTypeOPAQUE(TypeDescriptor.ANYTYPETOID, 1, 0, (short)0, name, 7L), connection);
            }
            else if (name.equals("SYS.ANYDATA")) {
                o = new OpaqueDescriptor(sqlName, new OracleTypeOPAQUE(TypeDescriptor.ANYDATATOID, 1, 0, (short)0, name, 7L), connection);
            }
            else {
                o = new OpaqueDescriptor(sqlName, connection);
            }
            if (connection != null) {
                ((oracle.jdbc.OracleConnection)connection).putDescriptor(name, o);
            }
        }
        return (OpaqueDescriptor)o;
    }
    
    private void initPickler() throws SQLException {
        try {
            this.pickler = new OracleTypeADT(this.getName(), (Connection)this.connection);
            ((OracleTypeADT)this.pickler).init(this.connection);
            (this.pickler = ((OracleTypeADT)this.pickler).cleanup()).setDescriptor(this);
        }
        catch (Exception ex) {
            if (ex instanceof SQLException) {
                throw (SQLException)ex;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"" + this.getName() + "\"");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    byte[] toBytes(final OPAQUE opaque, final boolean b) throws SQLException {
        byte[] array = null;
        if (opaque.shareBytes() != null) {
            array = opaque.shareBytes();
        }
        else {
            try {
                array = this.pickler.linearize(opaque);
            }
            finally {
                if (!b) {
                    opaque.setShareBytes(null);
                }
            }
        }
        return array;
    }
    
    byte[] toValue(final OPAQUE opaque, final boolean b) throws SQLException {
        byte[] array = null;
        if (opaque.value != null) {
            array = opaque.value;
        }
        else {
            try {
                this.pickler.unlinearize(opaque.shareBytes(), 0L, opaque, 1, null);
                array = opaque.value;
            }
            finally {
                if (!b) {
                    opaque.value = null;
                }
            }
        }
        return array;
    }
    
    @Override
    public int getTypeCode() throws SQLException {
        if (this.connection.isGetObjectReturnsXMLType() && "SYS.XMLTYPE".equalsIgnoreCase(this.sqlName.getName())) {
            return 2009;
        }
        return 2007;
    }
    
    @Override
    public boolean isInHierarchyOf(final String s) throws SQLException {
        return s.equals(this.getName());
    }
    
    public long getMaxLength() throws SQLException {
        return this.hasUnboundedSize() ? 0L : ((OracleTypeOPAQUE)this.pickler).getMaxLength();
    }
    
    public boolean isTrustedLibrary() throws SQLException {
        return ((OracleTypeOPAQUE)this.pickler).isTrustedLibrary();
    }
    
    public boolean isModeledInC() throws SQLException {
        return ((OracleTypeOPAQUE)this.pickler).isModeledInC();
    }
    
    public boolean hasUnboundedSize() throws SQLException {
        return ((OracleTypeOPAQUE)this.pickler).isUnboundedSized();
    }
    
    public boolean hasFixedSize() throws SQLException {
        return ((OracleTypeOPAQUE)this.pickler).isFixedSized();
    }
    
    public String descType() throws SQLException {
        return this.descType(new StringBuffer(), 0);
    }
    
    String descType(final StringBuffer sb, final int n) throws SQLException {
        String string = "";
        for (int i = 0; i < n; ++i) {
            string += "  ";
        }
        new StringBuilder().append(string).append("  ").toString();
        sb.append(string);
        sb.append(this.getTypeName());
        sb.append(" maxLen=" + this.getMaxLength() + " isTrusted=" + this.isTrustedLibrary() + " hasUnboundedSize=" + this.hasUnboundedSize() + " hasFixedSize=" + this.hasFixedSize());
        sb.append("\n");
        return sb.toString();
    }
    
    public Class getClass(final Map map) throws SQLException {
        Class classForType = this.connection.getClassForType(this.getName(), map);
        final String schemaName = this.getSchemaName();
        final String typeName = this.getTypeName();
        if (classForType == null && this.connection.getDefaultSchemaNameForNamedTypes().equals(schemaName)) {
            classForType = map.get(typeName);
        }
        Class clazz;
        if (!SQLName.s_parseAllFormat) {
            clazz = classForType;
        }
        else {
            if (classForType == null && this.connection.getDefaultSchemaNameForNamedTypes().equals(schemaName)) {
                classForType = map.get("\"" + typeName + "\"");
            }
            if (classForType == null) {
                classForType = map.get("\"" + schemaName + "\"" + "." + "\"" + typeName + "\"");
            }
            if (classForType == null) {
                classForType = map.get("\"" + schemaName + "\"" + "." + typeName);
            }
            if (classForType == null) {
                classForType = map.get(schemaName + "." + "\"" + typeName + "\"");
            }
            clazz = classForType;
        }
        return clazz;
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
