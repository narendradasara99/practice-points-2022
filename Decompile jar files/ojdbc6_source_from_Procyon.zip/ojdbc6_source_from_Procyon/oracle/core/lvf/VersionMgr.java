// 
// Decompiled by Procyon v0.5.36
// 

package oracle.core.lvf;

public final class VersionMgr
{
    public static final byte ALPHA = 1;
    public static final byte BETA = 2;
    public static final byte PROD = 3;
    public static final byte NONE = 4;
    private final byte MAX_LEN = 64;
    private final byte MAX_PRODLEN = 30;
    private final byte MAX_VERLEN = 15;
    private final byte MAX_DISTLEN = 5;
    private final String alpha = "Alpha";
    private final String beta = "Beta";
    private final String prod = "Production";
    private String version;
    
    public void setVersion(final String s, byte b, byte b2, byte b3, byte b4, byte b5, final char c, final String s2, final byte b6, final int n) {
        final char[] value = new char[64];
        String s3 = "";
        int n2;
        if ((n2 = (byte)s.length()) > 30) {
            n2 = 30;
        }
        int index = 0;
        while (true) {
            final int n3 = 0;
            final int n4 = n2;
            n2 = (byte)(n2 - 1);
            if (n3 >= n4) {
                break;
            }
            value[index] = s.charAt(index);
            index = (byte)(index + 1);
        }
        final char[] array = value;
        final int n5 = index;
        byte count = (byte)(index + 1);
        array[n5] = '\t';
        if (b < 0) {
            b = 0;
        }
        if (b2 < 0) {
            b2 = 0;
        }
        if (b3 < 0) {
            b3 = 0;
        }
        if (b4 < 0) {
            b4 = 0;
        }
        if (b5 < 0) {
            b5 = 0;
        }
        if (b > 99) {
            b = 99;
        }
        if (b2 > 99) {
            b2 = 99;
        }
        if (b3 > 99) {
            b3 = 99;
        }
        if (b4 > 99) {
            b4 = 99;
        }
        if (b5 > 99) {
            b5 = 99;
        }
        String s4;
        if (c != '\0') {
            s4 = b + "." + b2 + "." + b3 + "." + b4 + "." + b5 + c;
        }
        else {
            s4 = b + "." + b2 + "." + b3 + "." + b4 + "." + b5;
        }
        byte b7 = (byte)s4.length();
        int n6 = 0;
        while (true) {
            final byte b8 = 0;
            final byte b9 = b7;
            --b7;
            if (b8 >= b9) {
                break;
            }
            final char[] array2 = value;
            final byte b10 = count;
            ++count;
            final String s5 = s4;
            final int index2 = n6;
            n6 = (byte)(n6 + 1);
            array2[b10] = s5.charAt(index2);
        }
        if (b6 != 4) {
            final char[] array3 = value;
            final byte b11 = count;
            ++count;
            array3[b11] = '\t';
            if (s2 != null) {
                int n7;
                if ((n7 = (byte)s2.length()) > 5) {
                    n7 = 5;
                }
                int n8 = 0;
                while (true) {
                    final int n9 = 0;
                    final int n10 = n7;
                    n7 = (byte)(n7 - 1);
                    if (n9 >= n10) {
                        break;
                    }
                    final char[] array4 = value;
                    final byte b12 = count;
                    ++count;
                    final int index3 = n8;
                    n8 = (byte)(n8 + 1);
                    array4[b12] = s2.charAt(index3);
                }
                final char[] array5 = value;
                final byte b13 = count;
                ++count;
                array5[b13] = '\t';
            }
            switch (b6) {
                case 1: {
                    s3 = "Alpha";
                    break;
                }
                case 2: {
                    s3 = "Beta";
                    break;
                }
                case 3: {
                    s3 = "Production";
                    break;
                }
            }
            int n11 = 0;
            byte b14 = (byte)s3.length();
            while (true) {
                final byte b15 = 0;
                final byte b16 = b14;
                --b14;
                if (b15 >= b16) {
                    break;
                }
                final char[] array6 = value;
                final byte b17 = count;
                ++count;
                final String s6 = s3;
                final int index4 = n11;
                n11 = (byte)(n11 + 1);
                array6[b17] = s6.charAt(index4);
            }
        }
        this.version = new String(value, 0, count);
    }
    
    public String getVersion() {
        return this.version;
    }
}
