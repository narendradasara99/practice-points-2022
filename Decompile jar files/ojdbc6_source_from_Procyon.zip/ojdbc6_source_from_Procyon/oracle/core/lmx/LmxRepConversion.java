// 
// Decompiled by Procyon v0.5.36
// 

package oracle.core.lmx;

public class LmxRepConversion
{
    public static void printInHex(final byte b) {
        System.out.print((char)nibbleToHex((byte)((b & 0xF0) >> 4)));
        System.out.print((char)nibbleToHex((byte)(b & 0xF)));
    }
    
    public static byte nibbleToHex(final byte b) {
        final byte b2 = (byte)(b & 0xF);
        return (byte)((b2 < 10) ? (b2 + 48) : (b2 - 10 + 65));
    }
    
    public static byte asciiHexToNibble(final byte b) {
        byte b2;
        if (b >= 97 && b <= 102) {
            b2 = (byte)(b - 97 + 10);
        }
        else if (b >= 65 && b <= 70) {
            b2 = (byte)(b - 65 + 10);
        }
        else if (b >= 48 && b <= 57) {
            b2 = (byte)(b - 48);
        }
        else {
            b2 = b;
        }
        return b2;
    }
    
    public static void bArray2nibbles(final byte[] array, final byte[] array2) {
        for (int i = 0; i < array.length; ++i) {
            array2[i * 2] = nibbleToHex((byte)((array[i] & 0xF0) >> 4));
            array2[i * 2 + 1] = nibbleToHex((byte)(array[i] & 0xF));
        }
    }
    
    public static String bArray2String(final byte[] array) {
        final StringBuffer sb = new StringBuffer(array.length * 2);
        for (int i = 0; i < array.length; ++i) {
            sb.append((char)nibbleToHex((byte)((array[i] & 0xF0) >> 4)));
            sb.append((char)nibbleToHex((byte)(array[i] & 0xF)));
        }
        return sb.toString();
    }
    
    public static byte[] nibbles2bArray(final byte[] array) {
        final byte[] array2 = new byte[array.length / 2];
        for (int i = 0; i < array2.length; ++i) {
            array2[i] = (byte)(asciiHexToNibble(array[i * 2]) << 4);
            final byte[] array3 = array2;
            final int n = i;
            array3[n] |= asciiHexToNibble(array[i * 2 + 1]);
        }
        return array2;
    }
    
    public static void printInHex(final long n) {
        System.out.print(new String(toHex(n), 0));
    }
    
    public static void printInHex(final int n) {
        System.out.print(new String(toHex(n), 0));
    }
    
    public static void printInHex(final short n) {
        System.out.print(new String(toHex(n), 0));
    }
    
    public static byte[] toHex(long n) {
        final int n2 = 16;
        final byte[] array = new byte[n2];
        for (int i = n2 - 1; i >= 0; --i) {
            array[i] = nibbleToHex((byte)(n & 0xFL));
            n >>= 4;
        }
        return array;
    }
    
    public static byte[] toHex(int n) {
        final int n2 = 8;
        final byte[] array = new byte[n2];
        for (int i = n2 - 1; i >= 0; --i) {
            array[i] = nibbleToHex((byte)(n & 0xF));
            n >>= 4;
        }
        return array;
    }
    
    public static byte[] toHex(short n) {
        final int n2 = 4;
        final byte[] array = new byte[n2];
        for (int i = n2 - 1; i >= 0; --i) {
            array[i] = nibbleToHex((byte)(n & 0xF));
            n >>= 4;
        }
        return array;
    }
}
