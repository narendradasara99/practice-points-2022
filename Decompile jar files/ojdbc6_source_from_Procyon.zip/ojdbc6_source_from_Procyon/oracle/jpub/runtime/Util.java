// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jpub.runtime;

import oracle.sql.CLOB;
import oracle.sql.BLOB;
import oracle.sql.BFILE;
import oracle.sql.RAW;
import oracle.sql.DATE;
import java.sql.Date;
import oracle.sql.TIMESTAMP;
import java.sql.Timestamp;
import java.math.BigInteger;
import java.math.BigDecimal;
import oracle.sql.CHAR;
import oracle.sql.CustomDatum;
import oracle.sql.ORAData;
import java.sql.Connection;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ARRAY;
import oracle.sql.REF;
import oracle.sql.CustomDatumFactory;
import oracle.sql.ORADataFactory;
import oracle.sql.STRUCT;
import java.sql.SQLException;
import oracle.sql.Datum;
import oracle.sql.CharacterSet;

public class Util
{
    static short lastCsId;
    static CharacterSet lastCS;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static Object convertToObject(final Datum datum, final int n, final Object o) throws SQLException {
        return _convertToObject(datum, n, o);
    }
    
    public static Object _convertToObject(final Datum datum, final int i, final Object o) throws SQLException {
        if (datum == null) {
            return null;
        }
        if (datum instanceof STRUCT) {
            if (o instanceof ORADataFactory) {
                return ((ORADataFactory)o).create(datum, 2002);
            }
            return ((CustomDatumFactory)o).create(datum, 2002);
        }
        else if (datum instanceof REF) {
            if (o instanceof ORADataFactory) {
                return ((ORADataFactory)o).create(datum, 2006);
            }
            return ((CustomDatumFactory)o).create(datum, 2006);
        }
        else if (datum instanceof ARRAY) {
            if (o instanceof ORADataFactory) {
                return ((ORADataFactory)o).create(datum, 2003);
            }
            return ((CustomDatumFactory)o).create(datum, 2003);
        }
        else if (datum instanceof OPAQUE) {
            if (o instanceof ORADataFactory) {
                return ((ORADataFactory)o).create(datum, 2007);
            }
            return ((CustomDatumFactory)o).create(datum, 2007);
        }
        else if (o != null) {
            if (o instanceof ORADataFactory) {
                return ((ORADataFactory)o).create(datum, i);
            }
            return ((CustomDatumFactory)o).create(datum, i);
        }
        else {
            if (!(datum instanceof NUMBER)) {
                return datum.toJdbc();
            }
            if (i == 2 || i == 3) {
                return ((NUMBER)datum).bigDecimalValue();
            }
            if (i == 8 || i == 6) {
                return ((NUMBER)datum).doubleValue();
            }
            if (i == 4 || i == 5) {
                return ((NUMBER)datum).intValue();
            }
            if (i == 7) {
                return ((NUMBER)datum).floatValue();
            }
            if (i == 16) {
                return ((NUMBER)datum).booleanValue();
            }
            final SQLException sqlException = DatabaseError.createSqlException(null, 48, " type: " + i);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public static Datum convertToOracle(final Object o, final Connection connection) throws SQLException {
        return convertToOracle(o, connection, false);
    }
    
    public static Datum convertToOracle(final Object o, final Connection connection, final boolean b) throws SQLException {
        return _convertToOracle(o, connection, b);
    }
    
    private static Datum _convertToOracle(final Object o, final Connection connection, final boolean b) throws SQLException {
        if (o == null) {
            return null;
        }
        if (o instanceof ORAData) {
            return ((ORAData)o).toDatum(connection);
        }
        if (o instanceof CustomDatum) {
            return ((CustomDatum)o).toDatum((oracle.jdbc.driver.OracleConnection)connection);
        }
        if (o instanceof String) {
            final short lastCsId = (short)((connection == null || !(connection instanceof OracleConnection)) ? 870 : (b ? ((OracleConnection)connection).getNCharSet() : ((OracleConnection)connection).getDbCsId()));
            if (lastCsId != Util.lastCsId) {
                Util.lastCsId = lastCsId;
                Util.lastCS = CharacterSet.make(Util.lastCsId);
            }
            return new CHAR((String)o, Util.lastCS);
        }
        if (o instanceof Character) {
            final short lastCsId2 = (short)((connection == null || !(connection instanceof OracleConnection)) ? 870 : ((OracleConnection)connection).getDbCsId());
            if (lastCsId2 != Util.lastCsId) {
                Util.lastCsId = lastCsId2;
                Util.lastCS = CharacterSet.make(Util.lastCsId);
            }
            return new CHAR(((Character)o).toString(), Util.lastCS);
        }
        if (o instanceof BigDecimal) {
            return new NUMBER((BigDecimal)o);
        }
        if (o instanceof BigInteger) {
            return new NUMBER((BigInteger)o);
        }
        if (o instanceof Double) {
            return new NUMBER((double)o);
        }
        if (o instanceof Float) {
            return new NUMBER((float)o);
        }
        if (o instanceof Integer) {
            return new NUMBER((int)o);
        }
        if (o instanceof Boolean) {
            return new NUMBER((boolean)o);
        }
        if (o instanceof Short) {
            return new NUMBER((short)o);
        }
        if (o instanceof Byte) {
            return new NUMBER((byte)o);
        }
        if (o instanceof Long) {
            return new NUMBER((long)o);
        }
        if (o instanceof Timestamp) {
            return new TIMESTAMP((Timestamp)o);
        }
        if (o instanceof Date) {
            return new DATE((Date)o);
        }
        if (o instanceof java.util.Date) {
            return new DATE(new Date(((java.util.Date)o).getTime()));
        }
        if (o instanceof byte[]) {
            return new RAW((byte[])o);
        }
        if (o instanceof Datum) {
            return (Datum)o;
        }
        final SQLException sqlException = DatabaseError.createSqlException(null, 48);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static boolean isMutable(final Datum datum, final ORADataFactory oraDataFactory) {
        return datum != null && (datum instanceof BFILE || datum instanceof BLOB || datum instanceof CLOB || (oraDataFactory != null && (datum instanceof STRUCT || datum instanceof OPAQUE || datum instanceof ARRAY)));
    }
    
    static boolean isMutable(final Datum datum, final CustomDatumFactory customDatumFactory) {
        return datum != null && (datum instanceof BFILE || datum instanceof BLOB || datum instanceof CLOB || (customDatumFactory != null && (datum instanceof STRUCT || datum instanceof OPAQUE || datum instanceof ARRAY)));
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        Util.lastCsId = 870;
        Util.lastCS = CharacterSet.make(870);
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
