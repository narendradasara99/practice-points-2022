// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jpub.runtime;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Date;
import oracle.jdbc.driver.DatabaseError;
import oracle.sql.CustomDatum;
import oracle.sql.ORAData;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.RAW;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.DATE;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BFILE;
import oracle.jdbc.OracleConnection;
import java.sql.SQLException;
import oracle.sql.ArrayDescriptor;
import java.sql.Connection;
import oracle.sql.CustomDatumFactory;
import oracle.sql.ORADataFactory;
import oracle.sql.ARRAY;
import oracle.sql.Datum;

public class MutableArray
{
    int length;
    Object[] elements;
    Datum[] datums;
    ARRAY pickled;
    boolean pickledCorrect;
    int sqlType;
    ORADataFactory factory;
    CustomDatumFactory old_factory;
    boolean isNChar;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public MutableArray(final int sqlType, final ARRAY pickled, final ORADataFactory factory) {
        this.length = -1;
        this.elements = null;
        this.datums = null;
        this.pickled = pickled;
        this.pickledCorrect = true;
        this.isNChar = false;
        this.sqlType = sqlType;
        this.factory = factory;
    }
    
    public MutableArray(final int sqlType, final Datum[] datumArray, final ORADataFactory factory) {
        this.sqlType = sqlType;
        this.factory = factory;
        this.isNChar = false;
        this.setDatumArray(datumArray);
    }
    
    public MutableArray(final int sqlType, final Object[] objectArray, final ORADataFactory factory) {
        this.sqlType = sqlType;
        this.factory = factory;
        this.isNChar = false;
        this.setObjectArray(objectArray);
    }
    
    public MutableArray(final int sqlType, final double[] array, final ORADataFactory factory) {
        this.sqlType = sqlType;
        this.factory = factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final int sqlType, final int[] array, final ORADataFactory factory) {
        this.sqlType = sqlType;
        this.factory = factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final int sqlType, final float[] array, final ORADataFactory factory) {
        this.sqlType = sqlType;
        this.factory = factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final int sqlType, final short[] array, final ORADataFactory factory) {
        this.sqlType = sqlType;
        this.factory = factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final ARRAY pickled, final int sqlType, final CustomDatumFactory old_factory) {
        this.length = -1;
        this.elements = null;
        this.datums = null;
        this.pickled = pickled;
        this.pickledCorrect = true;
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
    }
    
    public MutableArray(final Datum[] datumArray, final int sqlType, final CustomDatumFactory old_factory) {
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
        this.setDatumArray(datumArray);
    }
    
    public MutableArray(final Object[] objectArray, final int sqlType, final CustomDatumFactory old_factory) {
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
        this.setObjectArray(objectArray);
    }
    
    public MutableArray(final double[] array, final int sqlType, final CustomDatumFactory old_factory) {
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final int[] array, final int sqlType, final CustomDatumFactory old_factory) {
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final float[] array, final int sqlType, final CustomDatumFactory old_factory) {
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public MutableArray(final short[] array, final int sqlType, final CustomDatumFactory old_factory) {
        this.sqlType = sqlType;
        this.old_factory = old_factory;
        this.isNChar = false;
        this.setArray(array);
    }
    
    public Datum toDatum(final Connection connection, final String s) throws SQLException {
        if (!this.pickledCorrect) {
            this.pickled = new ARRAY(ArrayDescriptor.createDescriptor(s, connection), connection, this.getDatumArray(connection));
            this.pickledCorrect = true;
        }
        return this.pickled;
    }
    
    public Datum toDatum(final OracleConnection oracleConnection, final String s) throws SQLException {
        return this.toDatum((Connection)oracleConnection, s);
    }
    
    @Deprecated
    public Datum toDatum(final oracle.jdbc.driver.OracleConnection oracleConnection, final String s) throws SQLException {
        return this.toDatum((Connection)oracleConnection, s);
    }
    
    public Object[] getOracleArray() throws SQLException {
        return this.getOracleArray(0L, Integer.MAX_VALUE);
    }
    
    public Object[] getOracleArray(final long n, final int n2) throws SQLException {
        final int sliceLength = this.sliceLength(n, n2);
        if (sliceLength < 0) {
            return null;
        }
        Object[] array = null;
        switch (this.sqlType) {
            case -13: {
                array = new BFILE[sliceLength];
                break;
            }
            case 2004: {
                array = new BLOB[sliceLength];
                break;
            }
            case 1:
            case 12: {
                array = new CHAR[sliceLength];
                break;
            }
            case 2005: {
                array = new CLOB[sliceLength];
                break;
            }
            case 91: {
                array = new DATE[sliceLength];
                break;
            }
            case 93: {
                array = new TIMESTAMP[sliceLength];
                break;
            }
            case -101: {
                array = new TIMESTAMPTZ[sliceLength];
                break;
            }
            case -102: {
                array = new TIMESTAMPLTZ[sliceLength];
                break;
            }
            case -104: {
                array = new INTERVALDS[sliceLength];
                break;
            }
            case -103: {
                array = new INTERVALYM[sliceLength];
                break;
            }
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8: {
                array = new NUMBER[sliceLength];
                break;
            }
            case -2: {
                array = new RAW[sliceLength];
                break;
            }
            case 100: {
                array = new BINARY_FLOAT[sliceLength];
                break;
            }
            case 101: {
                array = new BINARY_DOUBLE[sliceLength];
                break;
            }
            case 0:
            case 2002:
            case 2003:
            case 2006:
            case 2007: {
                if (this.old_factory == null) {
                    array = new ORAData[sliceLength];
                    break;
                }
                array = new CustomDatum[sliceLength];
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 48);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return this.getOracleArray(n, array);
    }
    
    public Object[] getOracleArray(final long n, final Object[] array) throws SQLException {
        if (array == null) {
            return null;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        if (sliceLength != array.length) {
            return null;
        }
        if (this.sqlType == 2002 || this.sqlType == 2007 || this.sqlType == 2003 || this.sqlType == 2006 || this.sqlType == 0) {
            if (this.old_factory == null) {
                for (int i = 0; i < sliceLength; ++i) {
                    array[i] = this.factory.create(this.getDatumElement(n2++, null), this.sqlType);
                }
            }
            else {
                for (int j = 0; j < sliceLength; ++j) {
                    array[j] = this.old_factory.create(this.getDatumElement(n2++, null), this.sqlType);
                }
            }
        }
        else {
            for (int k = 0; k < sliceLength; ++k) {
                array[k] = this.getDatumElement(n2++, null);
            }
        }
        return array;
    }
    
    public Object[] getOracleArray(final Object[] array) throws SQLException {
        return this.getOracleArray(0L, array);
    }
    
    public Object[] getObjectArray() throws SQLException {
        return this.getObjectArray(0L, Integer.MAX_VALUE);
    }
    
    public Object[] getObjectArray(final long n, final int n2) throws SQLException {
        final int sliceLength = this.sliceLength(n, n2);
        if (sliceLength < 0) {
            return null;
        }
        Object o = null;
        switch (this.sqlType) {
            case 1:
            case 12: {
                o = new String[sliceLength];
                break;
            }
            case 91: {
                o = new Date[sliceLength];
                break;
            }
            case 93: {
                o = new Timestamp[sliceLength];
                break;
            }
            case 2:
            case 3: {
                o = new BigDecimal[sliceLength];
                break;
            }
            case 6:
            case 8: {
                o = new Double[sliceLength];
                break;
            }
            case 4:
            case 5: {
                o = new Integer[sliceLength];
                break;
            }
            case 7: {
                o = new Float[sliceLength];
                break;
            }
            case -2: {
                o = new byte[sliceLength][];
                break;
            }
            default: {
                return this.getOracleArray(n, n2);
            }
        }
        return this.getObjectArray(n, (Object[])o);
    }
    
    public Object[] getObjectArray(final long n, final Object[] array) throws SQLException {
        if (array == null) {
            return null;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        if (sliceLength != array.length) {
            return null;
        }
        switch (this.sqlType) {
            case -2:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 12:
            case 91:
            case 93: {
                for (int i = 0; i < sliceLength; ++i) {
                    array[i] = this.getObjectElement(n2++);
                }
                return array;
            }
            default: {
                return this.getOracleArray(n, array);
            }
        }
    }
    
    public Object[] getObjectArray(final Object[] array) throws SQLException {
        return this.getObjectArray(0L, array);
    }
    
    public Object getArray() throws SQLException {
        return this.getArray(0L, Integer.MAX_VALUE);
    }
    
    public Object getArray(final long n, final int n2) throws SQLException {
        final int sliceLength = this.sliceLength(n, n2);
        int n3 = (int)n;
        if (sliceLength < 0) {
            return null;
        }
        switch (this.sqlType) {
            case 6:
            case 8:
            case 101: {
                final double[] array = new double[sliceLength];
                for (int i = 0; i < sliceLength; ++i) {
                    array[i] = (double)this.getObjectElement(n3++);
                }
                return array;
            }
            case 100: {
                final float[] array2 = new float[sliceLength];
                for (int j = 0; j < sliceLength; ++j) {
                    array2[j] = (float)this.getObjectElement(n3++);
                }
                return array2;
            }
            case 4: {
                final int[] array3 = new int[sliceLength];
                for (int k = 0; k < sliceLength; ++k) {
                    array3[k] = (int)this.getObjectElement(n3++);
                }
                return array3;
            }
            case 5: {
                final short[] array4 = new short[sliceLength];
                for (int l = 0; l < sliceLength; ++l) {
                    array4[l] = (short)(int)this.getObjectElement(n3++);
                }
                return array4;
            }
            case 7: {
                final float[] array5 = new float[sliceLength];
                for (int n4 = 0; n4 < sliceLength; ++n4) {
                    array5[n4] = (float)this.getObjectElement(n3++);
                }
                return array5;
            }
            default: {
                return this.getObjectArray(n, n2);
            }
        }
    }
    
    public void setOracleArray(final Object[] objectArray) {
        if (this.factory == null && this.old_factory == null) {
            this.setDatumArray((Datum[])objectArray);
        }
        else {
            this.setObjectArray(objectArray);
        }
    }
    
    public void setOracleArray(final Object[] array, final long n) throws SQLException {
        if (this.factory == null && this.old_factory == null) {
            this.setDatumArray((Datum[])array, n);
        }
        else {
            this.setObjectArray(array, n);
        }
    }
    
    public void setObjectArray(final Object[] array) {
        if (array == null) {
            this.setNullArray();
        }
        else {
            this.setArrayGeneric(array.length);
            this.elements = new Object[this.length];
            for (int i = 0; i < this.length; ++i) {
                this.elements[i] = array[i];
            }
        }
    }
    
    public void setObjectArray(final Object[] array, final long n) throws SQLException {
        if (array == null) {
            return;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        for (int i = 0; i < sliceLength; ++i) {
            this.setObjectElement(array[i], n2++);
        }
    }
    
    public void setArray(final double[] array) {
        if (array == null) {
            this.setNullArray();
        }
        else {
            this.setArrayGeneric(array.length);
            this.elements = new Object[this.length];
            for (int i = 0; i < this.length; ++i) {
                this.elements[i] = array[i];
            }
        }
    }
    
    public void setArray(final double[] array, final long n) throws SQLException {
        if (array == null) {
            return;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        for (int i = 0; i < sliceLength; ++i) {
            this.setObjectElement(array[i], n2++);
        }
    }
    
    public void setArray(final int[] array) {
        if (array == null) {
            this.setNullArray();
        }
        else {
            this.setArrayGeneric(array.length);
            this.elements = new Object[this.length];
            for (int i = 0; i < this.length; ++i) {
                this.elements[i] = array[i];
            }
        }
    }
    
    public void setArray(final int[] array, final long n) throws SQLException {
        if (array == null) {
            return;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        for (int i = 0; i < sliceLength; ++i) {
            this.setObjectElement(array[i], n2++);
        }
    }
    
    public void setArray(final float[] array) {
        if (array == null) {
            this.setNullArray();
        }
        else {
            this.setArrayGeneric(array.length);
            this.elements = new Object[this.length];
            for (int i = 0; i < this.length; ++i) {
                this.elements[i] = array[i];
            }
        }
    }
    
    public void setArray(final float[] array, final long n) throws SQLException {
        if (array == null) {
            return;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        for (int i = 0; i < sliceLength; ++i) {
            this.setObjectElement(array[i], n2++);
        }
    }
    
    public void setArray(final short[] array) {
        if (array == null) {
            this.setNullArray();
        }
        else {
            this.setArrayGeneric(array.length);
            this.elements = new Object[this.length];
            for (int i = 0; i < this.length; ++i) {
                this.elements[i] = array[i];
            }
        }
    }
    
    public void setArray(final short[] array, final long n) throws SQLException {
        if (array == null) {
            return;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        for (int i = 0; i < sliceLength; ++i) {
            this.setObjectElement((int)array[i], n2++);
        }
    }
    
    public Object getObjectElement(final long n) throws SQLException {
        Object o = this.getLazyArray()[(int)n];
        if (o == null) {
            if (this.old_factory == null) {
                final Datum datum = this.getLazyOracleArray()[(int)n];
                o = Util.convertToObject(datum, this.sqlType, this.factory);
                this.elements[(int)n] = o;
                if (Util.isMutable(datum, this.factory)) {
                    this.resetOracleElement(n);
                }
            }
            else {
                final Datum datum2 = this.getLazyOracleArray()[(int)n];
                o = Util.convertToObject(datum2, this.sqlType, this.old_factory);
                this.elements[(int)n] = o;
                if (Util.isMutable(datum2, this.old_factory)) {
                    this.resetOracleElement(n);
                }
            }
        }
        return o;
    }
    
    public Object getOracleElement(final long n) throws SQLException {
        if (this.factory == null && this.old_factory == null) {
            final Datum datumElement = this.getDatumElement(n, null);
            if (Util.isMutable(datumElement, this.factory)) {
                this.pickledCorrect = false;
            }
            return datumElement;
        }
        return this.getObjectElement(n);
    }
    
    public void setObjectElement(final Object o, final long n) throws SQLException {
        if (o == null) {
            this.getLazyOracleArray();
        }
        this.resetOracleElement(n);
        this.getLazyArray()[(int)n] = o;
    }
    
    public void setOracleElement(final Object o, final long n) throws SQLException {
        if (this.factory == null && this.old_factory == null) {
            this.setDatumElement((Datum)o, n);
        }
        else {
            this.setObjectElement(o, n);
        }
    }
    
    public String getBaseTypeName() throws SQLException {
        return this.pickled.getBaseTypeName();
    }
    
    public int getBaseType() throws SQLException {
        return this.pickled.getBaseType();
    }
    
    public ArrayDescriptor getDescriptor() throws SQLException {
        return this.pickled.getDescriptor();
    }
    
    Datum[] getDatumArray(final Connection connection) throws SQLException {
        if (this.length < 0) {
            this.getLazyOracleArray();
        }
        if (this.datums == null) {
            return null;
        }
        final Datum[] array = new Datum[this.length];
        for (int i = 0; i < this.length; ++i) {
            array[i] = this.getDatumElement(i, connection);
        }
        return array;
    }
    
    void setDatumArray(final Datum[] array) {
        if (array == null) {
            this.setNullArray();
        }
        else {
            this.length = array.length;
            this.elements = null;
            this.datums = array.clone();
            this.pickled = null;
            this.pickledCorrect = false;
        }
    }
    
    void setDatumArray(final Datum[] array, final long n) throws SQLException {
        if (array == null) {
            return;
        }
        final int sliceLength = this.sliceLength(n, array.length);
        int n2 = (int)n;
        for (int i = 0; i < sliceLength; ++i) {
            this.setDatumElement(array[i], n2++);
        }
    }
    
    Datum getDatumElement(final long n, final Connection connection) throws SQLException {
        Datum convertToOracle = this.getLazyOracleArray()[(int)n];
        if (convertToOracle == null) {
            convertToOracle = Util.convertToOracle(this.getLazyArray()[(int)n], connection, this.isNChar);
            this.datums[(int)n] = convertToOracle;
        }
        return convertToOracle;
    }
    
    void setDatumElement(final Datum datum, final long n) throws SQLException {
        this.resetElement(n);
        this.getLazyOracleArray()[(int)n] = datum;
        this.pickledCorrect = false;
    }
    
    void resetElement(final long n) throws SQLException {
        if (this.elements != null) {
            this.elements[(int)n] = null;
        }
    }
    
    void setNullArray() {
        this.length = -1;
        this.elements = null;
        this.datums = null;
        this.pickled = null;
        this.pickledCorrect = false;
    }
    
    void setArrayGeneric(final int length) {
        this.length = length;
        this.datums = new Datum[length];
        this.pickled = null;
        this.pickledCorrect = false;
    }
    
    public int length() throws SQLException {
        if (this.length < 0) {
            this.getLazyOracleArray();
        }
        return this.length;
    }
    
    public int sliceLength(final long n, final int b) throws SQLException {
        if (this.length < 0) {
            this.getLazyOracleArray();
        }
        if (n < 0L) {
            return (int)n;
        }
        return Math.min(this.length - (int)n, b);
    }
    
    void resetOracleElement(final long n) throws SQLException {
        if (this.datums != null) {
            this.datums[(int)n] = null;
        }
        this.pickledCorrect = false;
    }
    
    Object[] getLazyArray() throws SQLException {
        if (this.length == -1) {
            this.getLazyOracleArray();
        }
        if (this.elements == null) {
            this.elements = new Object[this.length];
        }
        return this.elements;
    }
    
    Datum[] getLazyOracleArray() throws SQLException {
        if (this.datums == null) {
            if (this.pickled != null) {
                this.datums = this.pickled.getOracleArray();
                this.length = this.datums.length;
                this.pickledCorrect = true;
                if (this.elements != null) {
                    for (int i = 0; i < this.length; ++i) {
                        if (this.elements[i] != null) {
                            this.datums[i] = null;
                            this.pickledCorrect = false;
                        }
                    }
                }
            }
            else if (this.length >= 0) {
                this.datums = new Datum[this.length];
            }
        }
        return this.datums;
    }
    
    public void setNChar() {
        this.isNChar = true;
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
