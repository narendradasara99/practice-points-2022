// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jpub.runtime;

import oracle.jdbc.OracleConnection;
import java.sql.SQLException;
import oracle.sql.StructDescriptor;
import java.sql.Connection;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;

public class MutableStruct
{
    int length;
    STRUCT pickled;
    Datum[] datums;
    Object[] attributes;
    CustomDatumFactory[] old_factories;
    ORADataFactory[] factories;
    int[] sqlTypes;
    boolean pickledCorrect;
    boolean[] isNChar;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public MutableStruct(final STRUCT pickled, final int[] sqlTypes, final ORADataFactory[] factories) {
        this.length = factories.length;
        this.pickled = pickled;
        this.factories = factories;
        this.sqlTypes = sqlTypes;
        this.initNChar(sqlTypes.length);
        this.pickledCorrect = true;
    }
    
    public MutableStruct(final Object[] attributes, final int[] sqlTypes, final ORADataFactory[] factories) {
        this.length = factories.length;
        this.attributes = attributes;
        this.factories = factories;
        this.sqlTypes = sqlTypes;
        this.initNChar(sqlTypes.length);
        this.pickledCorrect = false;
    }
    
    public MutableStruct(final STRUCT pickled, final int[] sqlTypes, final CustomDatumFactory[] old_factories) {
        this.length = old_factories.length;
        this.pickled = pickled;
        this.old_factories = old_factories;
        this.sqlTypes = sqlTypes;
        this.initNChar(sqlTypes.length);
        this.pickledCorrect = true;
    }
    
    public MutableStruct(final Object[] attributes, final int[] sqlTypes, final CustomDatumFactory[] old_factories) {
        this.length = old_factories.length;
        this.attributes = attributes;
        this.old_factories = old_factories;
        this.sqlTypes = sqlTypes;
        this.initNChar(sqlTypes.length);
        this.pickledCorrect = false;
    }
    
    public Datum toDatum(final Connection connection, final String s) throws SQLException {
        if (!this.pickledCorrect) {
            this.pickled = new STRUCT(StructDescriptor.createDescriptor(s, connection), connection, this.getDatumAttributes(connection));
            this.pickledCorrect = true;
        }
        return this.pickled;
    }
    
    public Datum toDatum(final OracleConnection oracleConnection, final String s) throws SQLException {
        return this.toDatum((Connection)oracleConnection, s);
    }
    
    @Deprecated
    public Datum toDatum(final oracle.jdbc.driver.OracleConnection oracleConnection, final String s) throws SQLException {
        return this.toDatum((Connection)oracleConnection, s);
    }
    
    public Object getAttribute(final int n) throws SQLException {
        Object o = this.getLazyAttributes()[n];
        if (o == null) {
            final Datum datum = this.getLazyDatums()[n];
            if (this.old_factories == null) {
                o = Util.convertToObject(datum, this.sqlTypes[n], this.factories[n]);
                this.attributes[n] = o;
                if (Util.isMutable(datum, this.factories[n])) {
                    this.resetDatum(n);
                }
            }
            else {
                o = Util.convertToObject(datum, this.sqlTypes[n], this.old_factories[n]);
                this.attributes[n] = o;
                if (Util.isMutable(datum, this.old_factories[n])) {
                    this.resetDatum(n);
                }
            }
        }
        return o;
    }
    
    public Object getOracleAttribute(final int n) throws SQLException {
        Object o;
        if (this.old_factories == null) {
            if (this.factories[n] == null) {
                o = this.getDatumAttribute(n, null);
                if (Util.isMutable(this.getLazyDatums()[n], this.factories[n])) {
                    this.pickledCorrect = false;
                }
            }
            else {
                o = this.getAttribute(n);
            }
        }
        else if (this.old_factories[n] == null) {
            o = this.getDatumAttribute(n, null);
            if (Util.isMutable(this.getLazyDatums()[n], this.old_factories[n])) {
                this.pickledCorrect = false;
            }
        }
        else {
            o = this.getAttribute(n);
        }
        return o;
    }
    
    public Object[] getAttributes() throws SQLException {
        for (int i = 0; i < this.length; ++i) {
            this.getAttribute(i);
        }
        return this.attributes;
    }
    
    public Object[] getOracleAttributes() throws SQLException {
        final Object[] array = new Object[this.length];
        for (int i = 0; i < this.length; ++i) {
            array[i] = this.getOracleAttribute(i);
        }
        return array;
    }
    
    public void setAttribute(final int n, final Object o) throws SQLException {
        if (o == null) {
            this.getLazyDatums();
        }
        this.resetDatum(n);
        this.getLazyAttributes()[n] = o;
    }
    
    public void setDoubleAttribute(final int n, final double d) throws SQLException {
        this.setAttribute(n, d);
    }
    
    public void setFloatAttribute(final int n, final float f) throws SQLException {
        this.setAttribute(n, f);
    }
    
    public void setIntAttribute(final int n, final int i) throws SQLException {
        this.setAttribute(n, i);
    }
    
    public void setOracleAttribute(final int n, final Object o) throws SQLException {
        if (this.old_factories == null) {
            if (this.factories[n] == null) {
                this.setDatumAttribute(n, (Datum)o);
            }
            else {
                this.setAttribute(n, o);
            }
        }
        else if (this.old_factories[n] == null) {
            this.setDatumAttribute(n, (Datum)o);
        }
        else {
            this.setAttribute(n, o);
        }
    }
    
    Datum getDatumAttribute(final int n, final Connection connection) throws SQLException {
        Datum convertToOracle = this.getLazyDatums()[n];
        if (convertToOracle == null) {
            convertToOracle = Util.convertToOracle(this.getLazyAttributes()[n], connection, this.isNChar(n));
            this.datums[n] = convertToOracle;
        }
        return convertToOracle;
    }
    
    void setDatumAttribute(final int n, final Datum datum) throws SQLException {
        this.resetAttribute(n);
        this.getLazyDatums()[n] = datum;
        this.pickledCorrect = false;
    }
    
    Datum[] getDatumAttributes(final Connection connection) throws SQLException {
        for (int i = 0; i < this.length; ++i) {
            this.getDatumAttribute(i, connection);
        }
        return this.datums.clone();
    }
    
    void resetAttribute(final int n) throws SQLException {
        if (this.attributes != null) {
            this.attributes[n] = null;
        }
    }
    
    void resetDatum(final int n) throws SQLException {
        if (this.datums != null) {
            this.datums[n] = null;
        }
        this.pickledCorrect = false;
    }
    
    Object[] getLazyAttributes() {
        if (this.attributes == null) {
            this.attributes = new Object[this.length];
        }
        return this.attributes;
    }
    
    Datum[] getLazyDatums() throws SQLException {
        if (this.datums == null) {
            if (this.pickled != null) {
                this.datums = this.pickled.getOracleAttributes();
                this.pickledCorrect = true;
                if (this.attributes != null) {
                    for (int i = 0; i < this.length; ++i) {
                        if (this.attributes[i] != null) {
                            this.datums[i] = null;
                            this.pickledCorrect = false;
                        }
                    }
                }
            }
            else {
                this.datums = new Datum[this.length];
            }
        }
        return this.datums;
    }
    
    private void initNChar(final int n) {
        this.isNChar = new boolean[n];
        for (int i = 0; i < n; ++i) {
            this.isNChar[i] = false;
        }
    }
    
    public void setNChar(final int n) throws SQLException {
        this.isNChar[n] = true;
    }
    
    public boolean isNChar(final int n) throws SQLException {
        return this.isNChar[n];
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
