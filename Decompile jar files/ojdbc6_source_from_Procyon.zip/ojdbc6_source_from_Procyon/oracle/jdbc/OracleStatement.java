// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import oracle.jdbc.dcn.DatabaseChangeRegistration;
import java.sql.SQLException;
import java.sql.Statement;

public interface OracleStatement extends Statement
{
    public static final int NEW = 0;
    public static final int IMPLICIT = 1;
    public static final int EXPLICIT = 2;
    
    void clearDefines() throws SQLException;
    
    void defineColumnType(final int p0, final int p1) throws SQLException;
    
    void defineColumnType(final int p0, final int p1, final int p2) throws SQLException;
    
    void defineColumnType(final int p0, final int p1, final int p2, final short p3) throws SQLException;
    
    void defineColumnTypeBytes(final int p0, final int p1, final int p2) throws SQLException;
    
    void defineColumnTypeChars(final int p0, final int p1, final int p2) throws SQLException;
    
    void defineColumnType(final int p0, final int p1, final String p2) throws SQLException;
    
    int getRowPrefetch();
    
    void setResultSetCache(final OracleResultSetCache p0) throws SQLException;
    
    void setRowPrefetch(final int p0) throws SQLException;
    
    int getLobPrefetchSize();
    
    void setLobPrefetchSize(final int p0) throws SQLException;
    
    void closeWithKey(final String p0) throws SQLException;
    
    @Deprecated
    int creationState();
    
    boolean isNCHAR(final int p0) throws SQLException;
    
    void setDatabaseChangeRegistration(final DatabaseChangeRegistration p0) throws SQLException;
    
    String[] getRegisteredTableNames() throws SQLException;
    
    long getRegisteredQueryId() throws SQLException;
}
