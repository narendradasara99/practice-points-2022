// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import java.sql.SQLException;

public interface StructMetaData extends OracleResultSetMetaData
{
    String getAttributeJavaName(final int p0) throws SQLException;
    
    String getOracleColumnClassName(final int p0) throws SQLException;
    
    boolean isInherited(final int p0) throws SQLException;
    
    int getLocalColumnCount() throws SQLException;
}
