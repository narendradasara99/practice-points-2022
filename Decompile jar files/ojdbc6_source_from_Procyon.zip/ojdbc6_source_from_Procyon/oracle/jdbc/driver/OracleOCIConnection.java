// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import oracle.jdbc.pool.OracleOCIConnectionPool;

public abstract class OracleOCIConnection extends T2CConnection
{
    OracleOCIConnectionPool ociConnectionPool;
    boolean isPool;
    boolean aliasing;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleOCIConnection(final String s, final Properties properties, final Object o) throws SQLException {
        this(s, properties, (OracleDriverExtension)o);
    }
    
    OracleOCIConnection(final String s, final Properties properties, final OracleDriverExtension oracleDriverExtension) throws SQLException {
        super(s, properties, oracleDriverExtension);
        this.ociConnectionPool = null;
        this.isPool = false;
        this.aliasing = false;
    }
    
    public synchronized byte[] getConnectionId() throws SQLException {
        final byte[] t2cGetConnectionId = this.t2cGetConnectionId(this.m_nativeState);
        if (t2cGetConnectionId == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 254, "Cannot create a ByteArray for the connectionId");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.aliasing = true;
        return t2cGetConnectionId;
    }
    
    public synchronized void passwordChange(final String s, final String s2, final String s3) throws SQLException, IOException {
        this.ociPasswordChange(s, s2, s3);
    }
    
    @Override
    public synchronized void close() throws SQLException {
        if (this.lifecycle == 2 || this.lifecycle == 4 || this.aliasing) {
            return;
        }
        super.close();
        this.ociConnectionPool.connectionClosed((oracle.jdbc.oci.OracleOCIConnection)this);
    }
    
    public synchronized void setConnectionPool(final OracleOCIConnectionPool ociConnectionPool) {
        this.ociConnectionPool = ociConnectionPool;
    }
    
    @Override
    public synchronized void setStmtCacheSize(final int n, final boolean b) throws SQLException {
        super.setStmtCacheSize(n, b);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
