// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.math.BigInteger;
import oracle.sql.NUMBER;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.Datum;
import java.util.Map;
import java.sql.SQLException;

class BinaryDoubleAccessor extends Accessor
{
    static final int MAXLENGTH = 8;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    BinaryDoubleAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 101, 101, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    BinaryDoubleAccessor(final OracleStatement oracleStatement, int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 101, 101, n7, false);
        this.initForDescribe(101, n, b, n2, n3, n4, n5, n6, n7, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n == 0 || maxFieldSize < n)) {
            n = maxFieldSize;
        }
        this.initForDataAccess(0, n, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, final int n3, final short n4, final int n5) throws SQLException {
        this.init(oracleStatement, n, n2, n4, false);
        this.initForDataAccess(n5, n3, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, int n3, final boolean b, final int n4, final int n5, final int n6, final int n7, final int n8, final short n9) throws SQLException {
        this.init(oracleStatement, n, n2, n9, false);
        this.initForDescribe(n, n3, b, n4, n5, n6, n7, n8, n9, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n3 == 0 || maxFieldSize < n3)) {
            n3 = maxFieldSize;
        }
        this.initForDataAccess(0, n3, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 8;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    double getDouble(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0.0;
        }
        final int n2 = this.columnIndex + this.byteLength * n;
        final byte b = this.rowSpaceByte[n2];
        final byte b2 = this.rowSpaceByte[n2 + 1];
        final byte b3 = this.rowSpaceByte[n2 + 2];
        final byte b4 = this.rowSpaceByte[n2 + 3];
        final byte b5 = this.rowSpaceByte[n2 + 4];
        final byte b6 = this.rowSpaceByte[n2 + 5];
        final byte b7 = this.rowSpaceByte[n2 + 6];
        final byte b8 = this.rowSpaceByte[n2 + 7];
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        if ((b & 0x80) != 0x0) {
            n3 = (b & 0x7F);
            n4 = (b2 & 0xFF);
            n5 = (b3 & 0xFF);
            n6 = (b4 & 0xFF);
            n7 = (b5 & 0xFF);
            n8 = (b6 & 0xFF);
            n9 = (b7 & 0xFF);
            n10 = (b8 & 0xFF);
        }
        else {
            n3 = (~b & 0xFF);
            n4 = (~b2 & 0xFF);
            n5 = (~b3 & 0xFF);
            n6 = (~b4 & 0xFF);
            n7 = (~b5 & 0xFF);
            n8 = (~b6 & 0xFF);
            n9 = (~b7 & 0xFF);
            n10 = (~b8 & 0xFF);
        }
        return Double.longBitsToDouble((long)(n3 << 24 | n4 << 16 | n5 << 8 | n6) << 32 | ((long)(n7 << 24 | n8 << 16 | n9 << 8 | n10) & 0xFFFFFFFFL));
    }
    
    @Override
    String getString(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return Double.toString(this.getDouble(n));
        }
        return null;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new Double(this.getDouble(n));
        }
        return null;
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return new Double(this.getDouble(n));
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getBINARY_DOUBLE(n);
    }
    
    BINARY_DOUBLE getBINARY_DOUBLE(final int n) throws SQLException {
        BINARY_DOUBLE binary_DOUBLE = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            final byte[] array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
            binary_DOUBLE = new BINARY_DOUBLE(array);
        }
        return binary_DOUBLE;
    }
    
    @Override
    NUMBER getNUMBER(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new NUMBER(this.getDouble(n));
        }
        return null;
    }
    
    BigInteger getBigInteger(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new BigInteger(this.getString(n));
        }
        return null;
    }
    
    @Override
    BigDecimal getBigDecimal(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new BigDecimal(this.getString(n));
        }
        return null;
    }
    
    @Override
    byte getByte(final int n) throws SQLException {
        return (byte)this.getDouble(n);
    }
    
    @Override
    short getShort(final int n) throws SQLException {
        return (short)this.getDouble(n);
    }
    
    @Override
    int getInt(final int n) throws SQLException {
        return (int)this.getDouble(n);
    }
    
    @Override
    long getLong(final int n) throws SQLException {
        return (long)this.getDouble(n);
    }
    
    @Override
    float getFloat(final int n) throws SQLException {
        return (float)this.getDouble(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
