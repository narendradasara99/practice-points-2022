// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

public interface OracleResultSetCache extends oracle.jdbc.internal.OracleResultSetCache
{
}
