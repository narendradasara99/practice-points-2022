// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CBfileAccessor extends BfileAccessor
{
    static final int maxLength = 530;
    T4CMAREngine mare;
    final int[] meta;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CBfileAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, 530, n2, n3, b);
        this.meta = new int[1];
        this.mare = mare;
    }
    
    T4CBfileAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, 530, b, n2, n3, n4, n5, n6, n7);
        this.meta = new int[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        if (this.rowSpaceIndicator == null) {
            if ((int)this.mare.unmarshalUB4() == 0) {
                this.meta[0] = -1;
                this.processIndicator(0);
                ++this.lastRowProcessed;
                return false;
            }
            this.mare.unmarshalCLR(new byte[16000], 0, this.meta);
            this.processIndicator(this.meta[0]);
            ++this.lastRowProcessed;
            return false;
        }
        else {
            final int n = this.columnIndex + this.lastRowProcessed * this.byteLength;
            final int n2 = this.indicatorIndex + this.lastRowProcessed;
            final int n3 = this.lengthIndex + this.lastRowProcessed;
            if (this.isNullByDescribe) {
                this.rowSpaceIndicator[n2] = -1;
                this.rowSpaceIndicator[n3] = 0;
                ++this.lastRowProcessed;
                if (this.statement.connection.versionNumber < 9200) {
                    this.processIndicator(0);
                }
                return false;
            }
            if ((int)this.mare.unmarshalUB4() == 0) {
                this.meta[0] = -1;
                this.processIndicator(0);
                this.rowSpaceIndicator[n2] = -1;
                this.rowSpaceIndicator[n3] = 0;
                ++this.lastRowProcessed;
                return false;
            }
            if (this.lobPrefetchSizeForThisColumn != -1) {
                this.handlePrefetch();
            }
            this.mare.unmarshalCLR(this.rowSpaceByte, n, this.meta, this.byteLength);
            this.processIndicator(this.meta[0]);
            if (this.meta[0] == 0) {
                this.rowSpaceIndicator[n2] = -1;
                this.rowSpaceIndicator[n3] = 0;
            }
            else {
                this.rowSpaceIndicator[n3] = (short)this.meta[0];
                this.rowSpaceIndicator[n2] = 0;
            }
            ++this.lastRowProcessed;
            return false;
        }
    }
    
    @Override
    void copyRow() throws SQLException, IOException {
        int n;
        if (this.lastRowProcessed == 0) {
            n = this.statement.rowPrefetchInLastFetch - 1;
        }
        else {
            n = this.lastRowProcessed - 1;
        }
        final int n2 = this.columnIndex + this.lastRowProcessed * this.byteLength;
        final int n3 = this.columnIndex + n * this.byteLength;
        final int n4 = this.indicatorIndex + this.lastRowProcessed;
        final int n5 = this.indicatorIndex + n;
        final int n6 = this.lengthIndex + this.lastRowProcessed;
        final short n7 = this.rowSpaceIndicator[this.lengthIndex + n];
        final int n8 = this.metaDataIndex + this.lastRowProcessed * 1;
        final int n9 = this.metaDataIndex + n * 1;
        this.rowSpaceIndicator[n6] = n7;
        this.rowSpaceIndicator[n4] = this.rowSpaceIndicator[n5];
        if (!this.isNullByDescribe) {
            System.arraycopy(this.rowSpaceByte, n3, this.rowSpaceByte, n2, n7);
        }
        System.arraycopy(this.rowSpaceMetaData, n9, this.rowSpaceMetaData, n8, 1);
        ++this.lastRowProcessed;
    }
    
    @Override
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
        final int n3 = this.columnIndex + (n2 - 1) * this.byteLength;
        final int n4 = this.columnIndexLastRow + (n - 1) * this.byteLength;
        final int n5 = this.indicatorIndex + n2 - 1;
        final int n6 = this.indicatorIndexLastRow + n - 1;
        final int n7 = this.lengthIndex + n2 - 1;
        final short n8 = array3[this.lengthIndexLastRow + n - 1];
        this.rowSpaceIndicator[n7] = n8;
        this.rowSpaceIndicator[n5] = array3[n6];
        if (n8 != 0) {
            System.arraycopy(array, n4, this.rowSpaceByte, n3, n8);
        }
    }
    
    byte[][] checkAndAllocateLobPrefetchMemory(final byte[][] array, final int a, final int n, final int n2) {
        byte[][] array2 = array;
        if (array2 == null) {
            array2 = new byte[Math.max(a, n + 1)][];
            array2[n] = new byte[n2];
        }
        else {
            if (array2.length < n + 1) {
                final byte[][] array3 = new byte[(n + 1) * 2][];
                System.arraycopy(array2, 0, array3, 0, array2.length);
                array2 = array3;
            }
            if (array2[n] == null || array2[n].length < n2) {
                array2[n] = new byte[n2];
            }
        }
        return array2;
    }
    
    char[][] checkAndAllocateLobPrefetchMemory(final char[][] array, final int a, final int n, final int n2) {
        char[][] array2 = array;
        if (array2 == null) {
            array2 = new char[Math.max(a, n + 1)][];
            array2[n] = new char[n2];
        }
        else {
            if (array2.length < n + 1) {
                final char[][] array3 = new char[(n + 1) * 2][];
                System.arraycopy(array2, 0, array3, 0, array2.length);
                array2 = array3;
            }
            if (array2[n] == null || array2[n].length < n2) {
                array2[n] = new char[n2];
            }
        }
        return array2;
    }
    
    long[] checkAndAllocateLobPrefetchMemory(final long[] array, final int a, final int n) {
        long[] array2 = array;
        if (array2 == null) {
            array2 = new long[Math.max(a, n + 1)];
        }
        else if (array2.length < n + 1) {
            final long[] array3 = new long[(n + 1) * 2];
            System.arraycopy(array2, 0, array3, 0, array2.length);
            array2 = array3;
        }
        return array2;
    }
    
    int[] checkAndAllocateLobPrefetchMemory(final int[] array, final int a, final int n) {
        int[] array2 = array;
        if (array2 == null) {
            array2 = new int[Math.max(a, n + 1)];
        }
        else if (array2.length < n + 1) {
            final int[] array3 = new int[(n + 1) * 2];
            System.arraycopy(array2, 0, array3, 0, array2.length);
            array2 = array3;
        }
        return array2;
    }
    
    short[] checkAndAllocateLobPrefetchMemory(final short[] array, final int a, final int n) {
        short[] array2 = array;
        if (array2 == null) {
            array2 = new short[Math.max(a, n + 1)];
        }
        else if (array2.length < n + 1) {
            final short[] array3 = new short[(n + 1) * 2];
            System.arraycopy(array2, 0, array3, 0, array2.length);
            array2 = array3;
        }
        return array2;
    }
    
    byte[] checkAndAllocateLobPrefetchMemory(final byte[] array, final int a, final int n) {
        byte[] array2 = array;
        if (array2 == null) {
            array2 = new byte[Math.max(a, n + 1)];
        }
        else if (array2.length < n + 1) {
            final byte[] array3 = new byte[(n + 1) * 2];
            System.arraycopy(array2, 0, array3, 0, array2.length);
            array2 = array3;
        }
        return array2;
    }
    
    boolean[] checkAndAllocateLobPrefetchMemory(final boolean[] array, final int a, final int n) {
        boolean[] array2 = array;
        if (array2 == null) {
            array2 = new boolean[Math.max(a, n + 1)];
        }
        else if (array2.length < n + 1) {
            final boolean[] array3 = new boolean[(n + 1) * 2];
            System.arraycopy(array2, 0, array3, 0, array2.length);
            array2 = array3;
        }
        return array2;
    }
    
    void handlePrefetch() throws SQLException, IOException {
        (this.prefetchedLobSize = this.checkAndAllocateLobPrefetchMemory(this.prefetchedLobSize, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed))[this.lastRowProcessed] = (int)this.mare.unmarshalSB8();
        if (this.lobPrefetchSizeForThisColumn > 0) {
            this.mare.unmarshalUB1();
        }
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getObject(n);
        }
        final Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return o;
        }
        switch (this.definedColumnType) {
            case -13: {
                return this.getBFILE(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
