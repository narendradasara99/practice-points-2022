// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.dcn.TableChangeDescription;
import java.nio.ByteBuffer;
import oracle.jdbc.dcn.QueryChangeDescription;

class NTFDCNQueryChanges implements QueryChangeDescription
{
    private final long queryId;
    private final QueryChangeEventType queryopflags;
    private final int numberOfTables;
    private final NTFDCNTableChanges[] tcdesc;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFDCNQueryChanges(final ByteBuffer byteBuffer, final int n) {
        this.queryId = ((long)(byteBuffer.getInt() & -1) | (long)(byteBuffer.getInt() & -1) << 32);
        this.queryopflags = QueryChangeEventType.getQueryChangeEventType(byteBuffer.getInt());
        this.numberOfTables = byteBuffer.getShort();
        this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
        for (int i = 0; i < this.tcdesc.length; ++i) {
            this.tcdesc[i] = new NTFDCNTableChanges(byteBuffer, n);
        }
    }
    
    @Override
    public long getQueryId() {
        return this.queryId;
    }
    
    @Override
    public QueryChangeEventType getQueryChangeEventType() {
        return this.queryopflags;
    }
    
    @Override
    public TableChangeDescription[] getTableChangeDescription() {
        return this.tcdesc;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("  query ID=" + this.queryId + ", query change event type=" + this.queryopflags + "\n");
        final TableChangeDescription[] tableChangeDescription = this.getTableChangeDescription();
        if (tableChangeDescription != null) {
            sb.append("  Table Change Description (length=" + tableChangeDescription.length + "):");
            for (int i = 0; i < tableChangeDescription.length; ++i) {
                sb.append(tableChangeDescription[i].toString());
            }
        }
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
