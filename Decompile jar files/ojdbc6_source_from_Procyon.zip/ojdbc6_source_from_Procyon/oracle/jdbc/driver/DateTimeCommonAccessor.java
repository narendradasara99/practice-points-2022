// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.DATE;
import java.sql.Timestamp;
import java.util.Calendar;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.TimeZone;

abstract class DateTimeCommonAccessor extends Accessor
{
    static final int GREGORIAN_CUTOVER_YEAR = 1582;
    static final long GREGORIAN_CUTOVER = -12219292800000L;
    static final int JAN_1_1_JULIAN_DAY = 1721426;
    static final int EPOCH_JULIAN_DAY = 2440588;
    static final int ONE_SECOND = 1000;
    static final int ONE_MINUTE = 60000;
    static final int ONE_HOUR = 3600000;
    static final long ONE_DAY = 86400000L;
    static final int[] NUM_DAYS;
    static final int[] LEAP_NUM_DAYS;
    static final int ORACLE_CENTURY = 0;
    static final int ORACLE_YEAR = 1;
    static final int ORACLE_MONTH = 2;
    static final int ORACLE_DAY = 3;
    static final int ORACLE_HOUR = 4;
    static final int ORACLE_MIN = 5;
    static final int ORACLE_SEC = 6;
    static final int ORACLE_NANO1 = 7;
    static final int ORACLE_NANO2 = 8;
    static final int ORACLE_NANO3 = 9;
    static final int ORACLE_NANO4 = 10;
    static final int ORACLE_TZ1 = 11;
    static final int ORACLE_TZ2 = 12;
    static final int SIZE_DATE = 7;
    static final int MAX_TIMESTAMP_LENGTH = 11;
    static TimeZone epochTimeZone;
    static long epochTimeZoneOffset;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    Time getTime(final int n) throws SQLException {
        Time time = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final TimeZone defaultTimeZone = this.statement.getDefaultTimeZone();
            if (defaultTimeZone != DateTimeCommonAccessor.epochTimeZone) {
                DateTimeCommonAccessor.epochTimeZoneOffset = calculateEpochOffset(defaultTimeZone);
                DateTimeCommonAccessor.epochTimeZone = defaultTimeZone;
            }
            time = new Time(this.oracleTime(n2) - DateTimeCommonAccessor.epochTimeZoneOffset);
        }
        return time;
    }
    
    @Override
    Date getDate(final int n) throws SQLException {
        return this.getDate(n, this.statement.getDefaultCalendar());
    }
    
    @Override
    Date getDate(final int n, final Calendar calendar) throws SQLException {
        if (calendar == null) {
            return this.getDate(n);
        }
        Date date = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final int year = ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100;
            calendar.set(year, this.oracleMonth(n2), this.oracleDay(n2), 0, 0, 0);
            calendar.set(14, 0);
            if (year > 0 && calendar.isSet(0)) {
                calendar.set(0, 1);
            }
            date = new Date(calendar.getTimeInMillis());
        }
        return date;
    }
    
    @Override
    Time getTime(final int n, final Calendar calendar) throws SQLException {
        if (calendar == null) {
            return this.getTime(n);
        }
        Time time = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final int n3 = ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100;
            calendar.set(1, 1970);
            calendar.set(2, 0);
            calendar.set(5, 1);
            calendar.set(11, this.oracleHour(n2));
            calendar.set(12, this.oracleMin(n2));
            calendar.set(13, this.oracleSec(n2));
            calendar.set(14, 0);
            if (n3 > 0 && calendar.isSet(0)) {
                calendar.set(0, 1);
            }
            time = new Time(calendar.getTimeInMillis());
        }
        return time;
    }
    
    @Override
    Timestamp getTimestamp(final int n) throws SQLException {
        return this.getTimestamp(n, this.statement.getDefaultCalendar());
    }
    
    @Override
    Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        if (calendar == null) {
            return this.getTimestamp(n);
        }
        Timestamp timestamp = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final int year = ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100;
            calendar.set(year, this.oracleMonth(n2), this.oracleDay(n2), this.oracleHour(n2), this.oracleMin(n2), this.oracleSec(n2));
            calendar.set(14, 0);
            if (year > 0 && calendar.isSet(0)) {
                calendar.set(0, 1);
            }
            timestamp = new Timestamp(calendar.getTimeInMillis());
            if (this.rowSpaceIndicator[this.lengthIndex + n] >= 11) {
                timestamp.setNanos(this.oracleNanos(n2));
            }
        }
        return timestamp;
    }
    
    @Override
    DATE getDATE(final int n) throws SQLException {
        DATE date = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final byte[] array = new byte[7];
            System.arraycopy(this.rowSpaceByte, n2, array, 0, 7);
            date = new DATE(array);
        }
        return date;
    }
    
    @Override
    TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        TIMESTAMP timestamp = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            final byte[] array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
            timestamp = new TIMESTAMP(array);
        }
        return timestamp;
    }
    
    final int oracleYear(final int n) {
        final int n2 = ((this.rowSpaceByte[0 + n] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n] & 0xFF) - 100;
        return (n2 <= 0) ? (n2 + 1) : n2;
    }
    
    final int oracleMonth(final int n) {
        return this.rowSpaceByte[2 + n] - 1;
    }
    
    final int oracleDay(final int n) {
        return this.rowSpaceByte[3 + n];
    }
    
    final int oracleHour(final int n) {
        return this.rowSpaceByte[4 + n] - 1;
    }
    
    final int oracleMin(final int n) {
        return this.rowSpaceByte[5 + n] - 1;
    }
    
    final int oracleSec(final int n) {
        return this.rowSpaceByte[6 + n] - 1;
    }
    
    final int oracleTZ1(final int n) {
        return this.rowSpaceByte[11 + n];
    }
    
    final int oracleTZ2(final int n) {
        return this.rowSpaceByte[12 + n];
    }
    
    final int oracleTime(final int n) {
        return ((this.oracleHour(n) * 60 + this.oracleMin(n)) * 60 + this.oracleSec(n)) * 1000;
    }
    
    final int oracleNanos(final int n) {
        return (this.rowSpaceByte[7 + n] & 0xFF) << 24 | (this.rowSpaceByte[8 + n] & 0xFF) << 16 | (this.rowSpaceByte[9 + n] & 0xFF) << 8 | (this.rowSpaceByte[10 + n] & 0xFF & 0xFF);
    }
    
    static final long computeJulianDay(final boolean b, final int n, final int n2, final int n3) {
        boolean b2 = n % 4 == 0;
        final int n4 = n - 1;
        long n5 = 365L * n4 + floorDivide(n4, 4L) + 1721423L;
        if (b) {
            b2 = (b2 && (n % 100 != 0 || n % 400 == 0));
            n5 += floorDivide(n4, 400L) - floorDivide(n4, 100L) + 2L;
        }
        return n5 + n3 + (b2 ? DateTimeCommonAccessor.LEAP_NUM_DAYS[n2] : DateTimeCommonAccessor.NUM_DAYS[n2]);
    }
    
    static final long floorDivide(final long n, final long n2) {
        return (n >= 0L) ? (n / n2) : ((n + 1L) / n2 - 1L);
    }
    
    static final long julianDayToMillis(final long n) {
        return (n - 2440588L) * 86400000L;
    }
    
    static final long zoneOffset(final TimeZone timeZone, final int n, final int n2, final int n3, final int n4, final int n5) {
        return timeZone.getOffset((n >= 0) ? 1 : 0, n, n2, n3, n4, n5);
    }
    
    static long getMillis(final int n, final int n2, final int n3, final int n4, final TimeZone timeZone) {
        final boolean b = n >= 1582;
        long n5 = computeJulianDay(b, n, n2, n3);
        long n6 = (n5 - 2440588L) * 86400000L;
        if (b != n6 >= -12219292800000L) {
            n5 = computeJulianDay(!b, n, n2, n3);
            n6 = (n5 - 2440588L) * 86400000L;
        }
        return n6 + n4 - zoneOffset(timeZone, n, n2, n3, julianDayToDayOfWeek(n5), n4);
    }
    
    static final int julianDayToDayOfWeek(final long n) {
        final int n2 = (int)((n + 1L) % 7L);
        return n2 + ((n2 < 0) ? 8 : 1);
    }
    
    static long calculateEpochOffset(final TimeZone timeZone) {
        return zoneOffset(timeZone, 1970, 0, 1, 5, 0);
    }
    
    String toText(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final boolean b, final String s) throws SQLException {
        return oracle.sql.TIMESTAMPTZ.toString(n, n2, n3, n4, n5, n6, n7, s);
    }
    
    static {
        NUM_DAYS = new int[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
        LEAP_NUM_DAYS = new int[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
