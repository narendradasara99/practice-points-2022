// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.ParameterMetaData;
import java.sql.ResultSetMetaData;
import oracle.jdbc.OracleParameterMetaData;
import oracle.sql.StructDescriptor;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.ORAData;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.DATE;
import oracle.sql.CustomDatum;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.Ref;
import java.sql.NClob;
import java.util.Calendar;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.Array;
import oracle.jdbc.internal.OracleCallableStatement;
import java.sql.SQLException;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.internal.OraclePreparedStatement;

class OraclePreparedStatementWrapper extends OracleStatementWrapper implements OraclePreparedStatement
{
    protected OraclePreparedStatement preparedStatement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OraclePreparedStatementWrapper(final oracle.jdbc.OraclePreparedStatement oraclePreparedStatement) throws SQLException {
        super(oraclePreparedStatement);
        this.preparedStatement = null;
        this.preparedStatement = (OraclePreparedStatement)oraclePreparedStatement;
    }
    
    @Override
    public void close() throws SQLException {
        super.close();
        this.preparedStatement = OracleStatementWrapper.closedStatement;
    }
    
    @Override
    public void closeWithKey(final String s) throws SQLException {
        this.preparedStatement.closeWithKey(s);
        final OracleCallableStatement closedStatement = OraclePreparedStatementWrapper.closedStatement;
        this.preparedStatement = closedStatement;
        this.statement = closedStatement;
    }
    
    @Override
    public void setArray(final int n, final Array array) throws SQLException {
        this.preparedStatement.setArray(n, array);
    }
    
    @Override
    public void setBigDecimal(final int n, final BigDecimal bigDecimal) throws SQLException {
        this.preparedStatement.setBigDecimal(n, bigDecimal);
    }
    
    @Override
    public void setBlob(final int n, final Blob blob) throws SQLException {
        this.preparedStatement.setBlob(n, blob);
    }
    
    @Override
    public void setBoolean(final int n, final boolean b) throws SQLException {
        this.preparedStatement.setBoolean(n, b);
    }
    
    @Override
    public void setByte(final int n, final byte b) throws SQLException {
        this.preparedStatement.setByte(n, b);
    }
    
    @Override
    public void setBytes(final int n, final byte[] array) throws SQLException {
        this.preparedStatement.setBytes(n, array);
    }
    
    @Override
    public void setClob(final int n, final Clob clob) throws SQLException {
        this.preparedStatement.setClob(n, clob);
    }
    
    @Override
    public void setDate(final int n, final Date date) throws SQLException {
        this.preparedStatement.setDate(n, date);
    }
    
    @Override
    public void setDate(final int n, final Date date, final Calendar calendar) throws SQLException {
        this.preparedStatement.setDate(n, date, calendar);
    }
    
    @Override
    public void setDouble(final int n, final double n2) throws SQLException {
        this.preparedStatement.setDouble(n, n2);
    }
    
    @Override
    public void setFloat(final int n, final float n2) throws SQLException {
        this.preparedStatement.setFloat(n, n2);
    }
    
    @Override
    public void setInt(final int n, final int n2) throws SQLException {
        this.preparedStatement.setInt(n, n2);
    }
    
    @Override
    public void setLong(final int n, final long n2) throws SQLException {
        this.preparedStatement.setLong(n, n2);
    }
    
    @Override
    public void setNClob(final int n, final NClob nClob) throws SQLException {
        this.preparedStatement.setNClob(n, nClob);
    }
    
    @Override
    public void setNString(final int n, final String s) throws SQLException {
        this.preparedStatement.setNString(n, s);
    }
    
    @Override
    public void setObject(final int n, final Object o) throws SQLException {
        this.preparedStatement.setObject(n, o);
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2) throws SQLException {
        this.preparedStatement.setObject(n, o, n2);
    }
    
    @Override
    public void setRef(final int n, final Ref ref) throws SQLException {
        this.preparedStatement.setRef(n, ref);
    }
    
    @Override
    public void setRowId(final int n, final RowId rowId) throws SQLException {
        this.preparedStatement.setRowId(n, rowId);
    }
    
    @Override
    public void setShort(final int n, final short n2) throws SQLException {
        this.preparedStatement.setShort(n, n2);
    }
    
    @Override
    public void setSQLXML(final int n, final SQLXML sqlxml) throws SQLException {
        this.preparedStatement.setSQLXML(n, sqlxml);
    }
    
    @Override
    public void setString(final int n, final String s) throws SQLException {
        this.preparedStatement.setString(n, s);
    }
    
    @Override
    public void setTime(final int n, final Time time) throws SQLException {
        this.preparedStatement.setTime(n, time);
    }
    
    @Override
    public void setTime(final int n, final Time time, final Calendar calendar) throws SQLException {
        this.preparedStatement.setTime(n, time, calendar);
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp) throws SQLException {
        this.preparedStatement.setTimestamp(n, timestamp);
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.preparedStatement.setTimestamp(n, timestamp, calendar);
    }
    
    @Override
    public void setURL(final int n, final URL url) throws SQLException {
        this.preparedStatement.setURL(n, url);
    }
    
    @Override
    public void setARRAY(final int n, final ARRAY array) throws SQLException {
        this.preparedStatement.setARRAY(n, array);
    }
    
    @Override
    public void setBFILE(final int n, final BFILE bfile) throws SQLException {
        this.preparedStatement.setBFILE(n, bfile);
    }
    
    @Override
    public void setBfile(final int n, final BFILE bfile) throws SQLException {
        this.preparedStatement.setBfile(n, bfile);
    }
    
    @Override
    public void setBinaryFloat(final int n, final float n2) throws SQLException {
        this.preparedStatement.setBinaryFloat(n, n2);
    }
    
    @Override
    public void setBinaryFloat(final int n, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        this.preparedStatement.setBinaryFloat(n, binary_FLOAT);
    }
    
    @Override
    public void setBinaryDouble(final int n, final double n2) throws SQLException {
        this.preparedStatement.setBinaryDouble(n, n2);
    }
    
    @Override
    public void setBinaryDouble(final int n, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        this.preparedStatement.setBinaryDouble(n, binary_DOUBLE);
    }
    
    @Override
    public void setBLOB(final int n, final BLOB blob) throws SQLException {
        this.preparedStatement.setBLOB(n, blob);
    }
    
    @Override
    public void setCHAR(final int n, final CHAR char1) throws SQLException {
        this.preparedStatement.setCHAR(n, char1);
    }
    
    @Override
    public void setCLOB(final int n, final CLOB clob) throws SQLException {
        this.preparedStatement.setCLOB(n, clob);
    }
    
    @Override
    public void setCursor(final int n, final ResultSet set) throws SQLException {
        this.preparedStatement.setCursor(n, set);
    }
    
    @Override
    public void setCustomDatum(final int n, final CustomDatum customDatum) throws SQLException {
        this.preparedStatement.setCustomDatum(n, customDatum);
    }
    
    @Override
    public void setDATE(final int n, final DATE date) throws SQLException {
        this.preparedStatement.setDATE(n, date);
    }
    
    @Override
    public void setFixedCHAR(final int n, final String s) throws SQLException {
        this.preparedStatement.setFixedCHAR(n, s);
    }
    
    @Override
    public void setINTERVALDS(final int n, final INTERVALDS intervalds) throws SQLException {
        this.preparedStatement.setINTERVALDS(n, intervalds);
    }
    
    @Override
    public void setINTERVALYM(final int n, final INTERVALYM intervalym) throws SQLException {
        this.preparedStatement.setINTERVALYM(n, intervalym);
    }
    
    @Override
    public void setNUMBER(final int n, final NUMBER number) throws SQLException {
        this.preparedStatement.setNUMBER(n, number);
    }
    
    @Override
    public void setOPAQUE(final int n, final OPAQUE opaque) throws SQLException {
        this.preparedStatement.setOPAQUE(n, opaque);
    }
    
    @Override
    public void setOracleObject(final int n, final Datum datum) throws SQLException {
        this.preparedStatement.setOracleObject(n, datum);
    }
    
    @Override
    public void setORAData(final int n, final ORAData oraData) throws SQLException {
        this.preparedStatement.setORAData(n, oraData);
    }
    
    @Override
    public void setRAW(final int n, final RAW raw) throws SQLException {
        this.preparedStatement.setRAW(n, raw);
    }
    
    @Override
    public void setREF(final int n, final REF ref) throws SQLException {
        this.preparedStatement.setREF(n, ref);
    }
    
    @Override
    public void setRefType(final int n, final REF ref) throws SQLException {
        this.preparedStatement.setRefType(n, ref);
    }
    
    @Override
    public void setROWID(final int n, final ROWID rowid) throws SQLException {
        this.preparedStatement.setROWID(n, rowid);
    }
    
    @Override
    public void setSTRUCT(final int n, final STRUCT struct) throws SQLException {
        this.preparedStatement.setSTRUCT(n, struct);
    }
    
    @Override
    public void setTIMESTAMPLTZ(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        this.preparedStatement.setTIMESTAMPLTZ(n, timestampltz);
    }
    
    @Override
    public void setTIMESTAMPTZ(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        this.preparedStatement.setTIMESTAMPTZ(n, timestamptz);
    }
    
    @Override
    public void setTIMESTAMP(final int n, final TIMESTAMP timestamp) throws SQLException {
        this.preparedStatement.setTIMESTAMP(n, timestamp);
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream) throws SQLException {
        this.preparedStatement.setBlob(n, inputStream);
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.preparedStatement.setBlob(n, inputStream, n2);
    }
    
    @Override
    public void setClob(final int n, final Reader reader) throws SQLException {
        this.preparedStatement.setClob(n, reader);
    }
    
    @Override
    public void setClob(final int n, final Reader reader, final long n2) throws SQLException {
        this.preparedStatement.setClob(n, reader, n2);
    }
    
    @Override
    public void setNClob(final int n, final Reader reader) throws SQLException {
        this.preparedStatement.setNClob(n, reader);
    }
    
    @Override
    public void setNClob(final int n, final Reader reader, final long n2) throws SQLException {
        this.preparedStatement.setNClob(n, reader, n2);
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream) throws SQLException {
        this.preparedStatement.setAsciiStream(n, inputStream);
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.preparedStatement.setAsciiStream(n, inputStream, n2);
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.preparedStatement.setAsciiStream(n, inputStream, n2);
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream) throws SQLException {
        this.preparedStatement.setBinaryStream(n, inputStream);
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.preparedStatement.setBinaryStream(n, inputStream, n2);
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.preparedStatement.setBinaryStream(n, inputStream, n2);
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader) throws SQLException {
        this.preparedStatement.setCharacterStream(n, reader);
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final int n2) throws SQLException {
        this.preparedStatement.setCharacterStream(n, reader, n2);
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        this.preparedStatement.setCharacterStream(n, reader, n2);
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader) throws SQLException {
        this.preparedStatement.setNCharacterStream(n, reader);
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        this.preparedStatement.setNCharacterStream(n, reader, n2);
    }
    
    @Override
    public void setUnicodeStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.preparedStatement.setUnicodeStream(n, inputStream, n2);
    }
    
    @Override
    public void setArrayAtName(final String s, final Array array) throws SQLException {
        this.preparedStatement.setArrayAtName(s, array);
    }
    
    @Override
    public void setBigDecimalAtName(final String s, final BigDecimal bigDecimal) throws SQLException {
        this.preparedStatement.setBigDecimalAtName(s, bigDecimal);
    }
    
    @Override
    public void setBlobAtName(final String s, final Blob blob) throws SQLException {
        this.preparedStatement.setBlobAtName(s, blob);
    }
    
    @Override
    public void setBooleanAtName(final String s, final boolean b) throws SQLException {
        this.preparedStatement.setBooleanAtName(s, b);
    }
    
    @Override
    public void setByteAtName(final String s, final byte b) throws SQLException {
        this.preparedStatement.setByteAtName(s, b);
    }
    
    @Override
    public void setBytesAtName(final String s, final byte[] array) throws SQLException {
        this.preparedStatement.setBytesAtName(s, array);
    }
    
    @Override
    public void setClobAtName(final String s, final Clob clob) throws SQLException {
        this.preparedStatement.setClobAtName(s, clob);
    }
    
    @Override
    public void setDateAtName(final String s, final Date date) throws SQLException {
        this.preparedStatement.setDateAtName(s, date);
    }
    
    @Override
    public void setDateAtName(final String s, final Date date, final Calendar calendar) throws SQLException {
        this.preparedStatement.setDateAtName(s, date, calendar);
    }
    
    @Override
    public void setDoubleAtName(final String s, final double n) throws SQLException {
        this.preparedStatement.setDoubleAtName(s, n);
    }
    
    @Override
    public void setFloatAtName(final String s, final float n) throws SQLException {
        this.preparedStatement.setFloatAtName(s, n);
    }
    
    @Override
    public void setIntAtName(final String s, final int n) throws SQLException {
        this.preparedStatement.setIntAtName(s, n);
    }
    
    @Override
    public void setLongAtName(final String s, final long n) throws SQLException {
        this.preparedStatement.setLongAtName(s, n);
    }
    
    @Override
    public void setNClobAtName(final String s, final NClob nClob) throws SQLException {
        this.preparedStatement.setNClobAtName(s, nClob);
    }
    
    @Override
    public void setNStringAtName(final String s, final String s2) throws SQLException {
        this.preparedStatement.setNStringAtName(s, s2);
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o) throws SQLException {
        this.preparedStatement.setObjectAtName(s, o);
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o, final int n) throws SQLException {
        this.preparedStatement.setObjectAtName(s, o, n);
    }
    
    @Override
    public void setRefAtName(final String s, final Ref ref) throws SQLException {
        this.preparedStatement.setRefAtName(s, ref);
    }
    
    @Override
    public void setRowIdAtName(final String s, final RowId rowId) throws SQLException {
        this.preparedStatement.setRowIdAtName(s, rowId);
    }
    
    @Override
    public void setShortAtName(final String s, final short n) throws SQLException {
        this.preparedStatement.setShortAtName(s, n);
    }
    
    @Override
    public void setSQLXMLAtName(final String s, final SQLXML sqlxml) throws SQLException {
        this.preparedStatement.setSQLXMLAtName(s, sqlxml);
    }
    
    @Override
    public void setStringAtName(final String s, final String s2) throws SQLException {
        this.preparedStatement.setStringAtName(s, s2);
    }
    
    @Override
    public void setTimeAtName(final String s, final Time time) throws SQLException {
        this.preparedStatement.setTimeAtName(s, time);
    }
    
    @Override
    public void setTimeAtName(final String s, final Time time, final Calendar calendar) throws SQLException {
        this.preparedStatement.setTimeAtName(s, time, calendar);
    }
    
    @Override
    public void setTimestampAtName(final String s, final Timestamp timestamp) throws SQLException {
        this.preparedStatement.setTimestampAtName(s, timestamp);
    }
    
    @Override
    public void setTimestampAtName(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.preparedStatement.setTimestampAtName(s, timestamp, calendar);
    }
    
    @Override
    public void setURLAtName(final String s, final URL url) throws SQLException {
        this.preparedStatement.setURLAtName(s, url);
    }
    
    @Override
    public void setARRAYAtName(final String s, final ARRAY array) throws SQLException {
        this.preparedStatement.setARRAYAtName(s, array);
    }
    
    @Override
    public void setBFILEAtName(final String s, final BFILE bfile) throws SQLException {
        this.preparedStatement.setBFILEAtName(s, bfile);
    }
    
    @Override
    public void setBfileAtName(final String s, final BFILE bfile) throws SQLException {
        this.preparedStatement.setBfileAtName(s, bfile);
    }
    
    @Override
    public void setBinaryFloatAtName(final String s, final float n) throws SQLException {
        this.preparedStatement.setBinaryFloatAtName(s, n);
    }
    
    @Override
    public void setBinaryFloatAtName(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        this.preparedStatement.setBinaryFloatAtName(s, binary_FLOAT);
    }
    
    @Override
    public void setBinaryDoubleAtName(final String s, final double n) throws SQLException {
        this.preparedStatement.setBinaryDoubleAtName(s, n);
    }
    
    @Override
    public void setBinaryDoubleAtName(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        this.preparedStatement.setBinaryDoubleAtName(s, binary_DOUBLE);
    }
    
    @Override
    public void setBLOBAtName(final String s, final BLOB blob) throws SQLException {
        this.preparedStatement.setBLOBAtName(s, blob);
    }
    
    @Override
    public void setCHARAtName(final String s, final CHAR char1) throws SQLException {
        this.preparedStatement.setCHARAtName(s, char1);
    }
    
    @Override
    public void setCLOBAtName(final String s, final CLOB clob) throws SQLException {
        this.preparedStatement.setCLOBAtName(s, clob);
    }
    
    @Override
    public void setCursorAtName(final String s, final ResultSet set) throws SQLException {
        this.preparedStatement.setCursorAtName(s, set);
    }
    
    @Override
    public void setCustomDatumAtName(final String s, final CustomDatum customDatum) throws SQLException {
        this.preparedStatement.setCustomDatumAtName(s, customDatum);
    }
    
    @Override
    public void setDATEAtName(final String s, final DATE date) throws SQLException {
        this.preparedStatement.setDATEAtName(s, date);
    }
    
    @Override
    public void setFixedCHARAtName(final String s, final String s2) throws SQLException {
        this.preparedStatement.setFixedCHARAtName(s, s2);
    }
    
    @Override
    public void setINTERVALDSAtName(final String s, final INTERVALDS intervalds) throws SQLException {
        this.preparedStatement.setINTERVALDSAtName(s, intervalds);
    }
    
    @Override
    public void setINTERVALYMAtName(final String s, final INTERVALYM intervalym) throws SQLException {
        this.preparedStatement.setINTERVALYMAtName(s, intervalym);
    }
    
    @Override
    public void setNUMBERAtName(final String s, final NUMBER number) throws SQLException {
        this.preparedStatement.setNUMBERAtName(s, number);
    }
    
    @Override
    public void setOPAQUEAtName(final String s, final OPAQUE opaque) throws SQLException {
        this.preparedStatement.setOPAQUEAtName(s, opaque);
    }
    
    @Override
    public void setOracleObjectAtName(final String s, final Datum datum) throws SQLException {
        this.preparedStatement.setOracleObjectAtName(s, datum);
    }
    
    @Override
    public void setORADataAtName(final String s, final ORAData oraData) throws SQLException {
        this.preparedStatement.setORADataAtName(s, oraData);
    }
    
    @Override
    public void setRAWAtName(final String s, final RAW raw) throws SQLException {
        this.preparedStatement.setRAWAtName(s, raw);
    }
    
    @Override
    public void setREFAtName(final String s, final REF ref) throws SQLException {
        this.preparedStatement.setREFAtName(s, ref);
    }
    
    @Override
    public void setRefTypeAtName(final String s, final REF ref) throws SQLException {
        this.preparedStatement.setRefTypeAtName(s, ref);
    }
    
    @Override
    public void setROWIDAtName(final String s, final ROWID rowid) throws SQLException {
        this.preparedStatement.setROWIDAtName(s, rowid);
    }
    
    @Override
    public void setSTRUCTAtName(final String s, final STRUCT struct) throws SQLException {
        this.preparedStatement.setSTRUCTAtName(s, struct);
    }
    
    @Override
    public void setTIMESTAMPLTZAtName(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        this.preparedStatement.setTIMESTAMPLTZAtName(s, timestampltz);
    }
    
    @Override
    public void setTIMESTAMPTZAtName(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        this.preparedStatement.setTIMESTAMPTZAtName(s, timestamptz);
    }
    
    @Override
    public void setTIMESTAMPAtName(final String s, final TIMESTAMP timestamp) throws SQLException {
        this.preparedStatement.setTIMESTAMPAtName(s, timestamp);
    }
    
    @Override
    public void setBlobAtName(final String s, final InputStream inputStream) throws SQLException {
        this.preparedStatement.setBlobAtName(s, inputStream);
    }
    
    @Override
    public void setBlobAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.preparedStatement.setBlobAtName(s, inputStream, n);
    }
    
    @Override
    public void setClobAtName(final String s, final Reader reader) throws SQLException {
        this.preparedStatement.setClobAtName(s, reader);
    }
    
    @Override
    public void setClobAtName(final String s, final Reader reader, final long n) throws SQLException {
        this.preparedStatement.setClobAtName(s, reader, n);
    }
    
    @Override
    public void setNClobAtName(final String s, final Reader reader) throws SQLException {
        this.preparedStatement.setNClobAtName(s, reader);
    }
    
    @Override
    public void setNClobAtName(final String s, final Reader reader, final long n) throws SQLException {
        this.preparedStatement.setNClobAtName(s, reader, n);
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream) throws SQLException {
        this.preparedStatement.setAsciiStreamAtName(s, inputStream);
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.preparedStatement.setAsciiStreamAtName(s, inputStream, n);
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.preparedStatement.setAsciiStreamAtName(s, inputStream, n);
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream) throws SQLException {
        this.preparedStatement.setBinaryStreamAtName(s, inputStream);
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.preparedStatement.setBinaryStreamAtName(s, inputStream, n);
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.preparedStatement.setBinaryStreamAtName(s, inputStream, n);
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader) throws SQLException {
        this.preparedStatement.setCharacterStreamAtName(s, reader);
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader, final int n) throws SQLException {
        this.preparedStatement.setCharacterStreamAtName(s, reader, n);
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader, final long n) throws SQLException {
        this.preparedStatement.setCharacterStreamAtName(s, reader, n);
    }
    
    @Override
    public void setNCharacterStreamAtName(final String s, final Reader reader) throws SQLException {
        this.preparedStatement.setNCharacterStreamAtName(s, reader);
    }
    
    @Override
    public void setNCharacterStreamAtName(final String s, final Reader reader, final long n) throws SQLException {
        this.preparedStatement.setNCharacterStreamAtName(s, reader, n);
    }
    
    @Override
    public void setUnicodeStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.preparedStatement.setUnicodeStreamAtName(s, inputStream, n);
    }
    
    @Override
    public void setNull(final int n, final int n2) throws SQLException {
        this.preparedStatement.setNull(n, n2);
    }
    
    @Override
    public void setNull(final int n, final int n2, final String s) throws SQLException {
        this.preparedStatement.setNull(n, n2, s);
    }
    
    @Override
    public void setNullAtName(final String s, final int n) throws SQLException {
        this.preparedStatement.setNullAtName(s, n);
    }
    
    @Override
    public void setNullAtName(final String s, final int n, final String s2) throws SQLException {
        this.preparedStatement.setNullAtName(s, n, s2);
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2, final int n3) throws SQLException {
        this.preparedStatement.setObject(n, o, n2, n3);
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o, final int n, final int n2) throws SQLException {
        this.preparedStatement.setObjectAtName(s, o, n, n2);
    }
    
    @Override
    public void setStructDescriptor(final int n, final StructDescriptor structDescriptor) throws SQLException {
        this.preparedStatement.setStructDescriptor(n, structDescriptor);
    }
    
    @Override
    public void setStructDescriptorAtName(final String s, final StructDescriptor structDescriptor) throws SQLException {
        this.preparedStatement.setStructDescriptorAtName(s, structDescriptor);
    }
    
    @Override
    public int executeUpdate() throws SQLException {
        return this.preparedStatement.executeUpdate();
    }
    
    @Override
    public void addBatch() throws SQLException {
        this.preparedStatement.addBatch();
    }
    
    @Override
    public void clearParameters() throws SQLException {
        this.preparedStatement.clearParameters();
    }
    
    @Override
    public boolean execute() throws SQLException {
        return this.preparedStatement.execute();
    }
    
    @Override
    public void setCheckBindTypes(final boolean checkBindTypes) {
        this.preparedStatement.setCheckBindTypes(checkBindTypes);
    }
    
    @Override
    public ResultSet getReturnResultSet() throws SQLException {
        return this.preparedStatement.getReturnResultSet();
    }
    
    @Override
    public void defineParameterTypeBytes(final int n, final int n2, final int n3) throws SQLException {
        this.preparedStatement.defineParameterTypeBytes(n, n2, n3);
    }
    
    @Override
    public void defineParameterTypeChars(final int n, final int n2, final int n3) throws SQLException {
        this.preparedStatement.defineParameterTypeChars(n, n2, n3);
    }
    
    @Override
    public void defineParameterType(final int n, final int n2, final int n3) throws SQLException {
        this.preparedStatement.defineParameterType(n, n2, n3);
    }
    
    @Override
    public int getExecuteBatch() {
        return this.preparedStatement.getExecuteBatch();
    }
    
    @Override
    public int sendBatch() throws SQLException {
        return this.preparedStatement.sendBatch();
    }
    
    @Override
    public void setPlsqlIndexTable(final int n, final Object o, final int n2, final int n3, final int n4, final int n5) throws SQLException {
        this.preparedStatement.setPlsqlIndexTable(n, o, n2, n3, n4, n5);
    }
    
    @Override
    public void setFormOfUse(final int n, final short n2) {
        this.preparedStatement.setFormOfUse(n, n2);
    }
    
    @Override
    public void setDisableStmtCaching(final boolean disableStmtCaching) {
        this.preparedStatement.setDisableStmtCaching(disableStmtCaching);
    }
    
    @Override
    public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
        return this.preparedStatement.OracleGetParameterMetaData();
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2) throws SQLException {
        this.preparedStatement.registerReturnParameter(n, n2);
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2, final int n3) throws SQLException {
        this.preparedStatement.registerReturnParameter(n, n2, n3);
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2, final String s) throws SQLException {
        this.preparedStatement.registerReturnParameter(n, n2, s);
    }
    
    @Override
    public ResultSet executeQuery() throws SQLException {
        return this.preparedStatement.executeQuery();
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        return this.preparedStatement.getMetaData();
    }
    
    @Override
    public void setBytesForBlob(final int n, final byte[] array) throws SQLException {
        this.preparedStatement.setBytesForBlob(n, array);
    }
    
    @Override
    public void setBytesForBlobAtName(final String s, final byte[] array) throws SQLException {
        this.preparedStatement.setBytesForBlobAtName(s, array);
    }
    
    @Override
    public void setStringForClob(final int n, final String s) throws SQLException {
        this.preparedStatement.setStringForClob(n, s);
    }
    
    @Override
    public void setStringForClobAtName(final String s, final String s2) throws SQLException {
        this.preparedStatement.setStringForClobAtName(s, s2);
    }
    
    @Override
    public ParameterMetaData getParameterMetaData() throws SQLException {
        return this.preparedStatement.getParameterMetaData();
    }
    
    @Override
    public void setExecuteBatch(final int executeBatch) throws SQLException {
        this.preparedStatement.setExecuteBatch(executeBatch);
    }
    
    @Override
    public boolean isPoolable() throws SQLException {
        return this.preparedStatement.isPoolable();
    }
    
    @Override
    public void setPoolable(final boolean poolable) throws SQLException {
        this.preparedStatement.setPoolable(poolable);
    }
    
    @Override
    public void setInternalBytes(final int n, final byte[] array, final int n2) throws SQLException {
        this.preparedStatement.setInternalBytes(n, array, n2);
    }
    
    @Override
    public void enterImplicitCache() throws SQLException {
        this.preparedStatement.enterImplicitCache();
    }
    
    @Override
    public void enterExplicitCache() throws SQLException {
        this.preparedStatement.enterExplicitCache();
    }
    
    @Override
    public void exitImplicitCacheToActive() throws SQLException {
        this.preparedStatement.exitImplicitCacheToActive();
    }
    
    @Override
    public void exitExplicitCacheToActive() throws SQLException {
        this.preparedStatement.exitExplicitCacheToActive();
    }
    
    @Override
    public void exitImplicitCacheToClose() throws SQLException {
        this.preparedStatement.exitImplicitCacheToClose();
    }
    
    @Override
    public void exitExplicitCacheToClose() throws SQLException {
        this.preparedStatement.exitExplicitCacheToClose();
    }
    
    @Override
    public String getOriginalSql() throws SQLException {
        return this.preparedStatement.getOriginalSql();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
