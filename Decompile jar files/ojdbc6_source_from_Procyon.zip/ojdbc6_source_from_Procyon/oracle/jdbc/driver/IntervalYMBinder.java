// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class IntervalYMBinder extends DatumBinder
{
    Binder theIntervalYMCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 182;
        binder.bytelen = 5;
    }
    
    IntervalYMBinder() {
        this.theIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theIntervalYMCopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
