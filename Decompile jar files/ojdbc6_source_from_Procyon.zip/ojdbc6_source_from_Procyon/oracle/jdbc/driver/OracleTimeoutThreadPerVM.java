// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;

class OracleTimeoutThreadPerVM extends OracleTimeout
{
    private static final OracleTimeoutPollingThread watchdog;
    private OracleStatement statement;
    private long interruptAfter;
    private String name;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleTimeoutThreadPerVM(final String name) {
        this.name = name;
        this.interruptAfter = Long.MAX_VALUE;
        OracleTimeoutThreadPerVM.watchdog.addTimeout(this);
    }
    
    @Override
    void close() {
        OracleTimeoutThreadPerVM.watchdog.removeTimeout(this);
    }
    
    @Override
    synchronized void setTimeout(final long n, final OracleStatement statement) throws SQLException {
        if (this.interruptAfter != Long.MAX_VALUE) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 131);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.statement = statement;
        this.interruptAfter = System.currentTimeMillis() + n;
    }
    
    @Override
    synchronized void cancelTimeout() throws SQLException {
        this.statement = null;
        this.interruptAfter = Long.MAX_VALUE;
    }
    
    void interruptIfAppropriate(final long n) {
        if (n > this.interruptAfter) {
            synchronized (this) {
                if (n > this.interruptAfter) {
                    if (this.statement.connection.spawnNewThreadToCancel) {
                        final Thread thread = new Thread(new Runnable() {
                            final /* synthetic */ OracleStatement val$s = OracleTimeoutThreadPerVM.this.statement;
                            
                            @Override
                            public void run() {
                                try {
                                    this.val$s.cancel();
                                }
                                catch (Throwable t) {}
                            }
                        });
                        thread.setName("interruptIfAppropriate_" + this);
                        thread.setDaemon(true);
                        thread.setPriority(10);
                        thread.start();
                    }
                    else {
                        try {
                            this.statement.cancel();
                        }
                        catch (Throwable t) {}
                    }
                    this.statement = null;
                    this.interruptAfter = Long.MAX_VALUE;
                }
            }
        }
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        watchdog = new OracleTimeoutPollingThread();
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
