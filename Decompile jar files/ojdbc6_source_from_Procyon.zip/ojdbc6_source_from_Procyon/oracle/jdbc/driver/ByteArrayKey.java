// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class ByteArrayKey
{
    private byte[] theBytes;
    private int cachedHashCode;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public ByteArrayKey(final byte[] theBytes) {
        this.cachedHashCode = -1;
        this.theBytes = theBytes;
        final byte[] theBytes2 = this.theBytes;
        for (int length = theBytes2.length, i = 0; i < length; ++i) {
            this.cachedHashCode = ((this.cachedHashCode << 1 & ((this.cachedHashCode < 0) ? 1 : 0)) ^ theBytes2[i]);
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof ByteArrayKey)) {
            return false;
        }
        final byte[] theBytes = ((ByteArrayKey)o).theBytes;
        if (this.theBytes.length != theBytes.length) {
            return false;
        }
        for (int i = 0; i < this.theBytes.length; ++i) {
            if (this.theBytes[i] != theBytes[i]) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int hashCode() {
        return this.cachedHashCode;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
