// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

abstract class OracleTimeout
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static OracleTimeout newTimeout(final String s) throws SQLException {
        return new OracleTimeoutThreadPerVM(s);
    }
    
    abstract void setTimeout(final long p0, final OracleStatement p1) throws SQLException;
    
    abstract void cancelTimeout() throws SQLException;
    
    abstract void close() throws SQLException;
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
