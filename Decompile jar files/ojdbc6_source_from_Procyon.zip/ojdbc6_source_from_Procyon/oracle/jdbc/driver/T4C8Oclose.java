// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;

final class T4C8Oclose extends T4CTTIfun
{
    private int[] cursorId;
    private int offset;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8Oclose(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)17);
        this.cursorId = null;
        this.offset = 0;
    }
    
    void doOCANA(final int[] cursorId, final int offset) throws IOException {
        this.setFunCode((short)120);
        this.cursorId = cursorId;
        this.offset = offset;
        this.doPigRPC();
    }
    
    void doOCCA(final int[] cursorId, final int offset) throws IOException {
        this.setFunCode((short)105);
        this.cursorId = cursorId;
        this.offset = offset;
        this.doPigRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalPTR();
        this.meg.marshalUB4(this.offset);
        for (int i = 0; i < this.offset; ++i) {
            this.meg.marshalUB4(this.cursorId[i]);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
