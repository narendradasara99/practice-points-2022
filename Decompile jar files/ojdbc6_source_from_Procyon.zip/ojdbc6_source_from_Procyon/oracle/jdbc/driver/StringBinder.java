// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class StringBinder extends VarcharBinder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] dst, final short[] array2, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        final String[] array3 = oraclePreparedStatement.parameterString[n3];
        final String s = array3[n];
        if (b) {
            array3[n] = null;
        }
        if (s == null) {
            array2[n9] = -1;
        }
        else {
            array2[n9] = 0;
            final int length = s.length();
            s.getChars(0, length, dst, n7 + 1);
            final int n10 = length << 1;
            dst[n7] = (char)n10;
            if (n10 > 65532) {
                array2[n8] = -2;
            }
            else {
                array2[n8] = (short)(n10 + 2);
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
