// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.oracore.OracleType;

abstract class TypeAccessor extends Accessor
{
    byte[][] pickledBytes;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    abstract OracleType otypeFromName(final String p0) throws SQLException;
    
    @Override
    void initForDescribe(final int n, final int n2, final boolean b, final int n3, final int n4, final int n5, final int n6, final int n7, final short n8, final String describeTypeName) throws SQLException {
        this.describeTypeName = describeTypeName;
        this.initForDescribe(n, n2, b, n4, n5, n3, n6, n7, n8);
    }
    
    @Override
    void setOffsets(final int n) {
        if (!this.outBind) {
            this.columnIndex = this.statement.defineByteSubRange;
            this.statement.defineByteSubRange = this.columnIndex + n * this.byteLength;
        }
        if (this.pickledBytes == null || this.pickledBytes.length < n) {
            this.pickledBytes = new byte[n][];
        }
    }
    
    byte[] pickledBytes(final int n) {
        return this.pickledBytes[n];
    }
    
    @Override
    void initForDataAccess(final int externalType, final int n, final String internalTypeName) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 0;
        this.internalTypeName = internalTypeName;
    }
    
    @Override
    void initMetadata() throws SQLException {
        if (this.describeOtype == null && this.describeTypeName != null) {
            this.describeOtype = this.otypeFromName(this.describeTypeName);
        }
        if (this.internalOtype == null && this.internalTypeName != null) {
            this.internalOtype = this.otypeFromName(this.internalTypeName);
        }
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] pickledBytes = this.pickledBytes(n);
            final int length = pickledBytes.length;
            o = new byte[length];
            System.arraycopy(pickledBytes, 0, o, 0, length);
        }
        return (byte[])o;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
