// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Connection;

interface ScrollRsetStatement
{
    Connection getConnection() throws SQLException;
    
    void notifyCloseRset() throws SQLException;
    
    int copyBinds(final Statement p0, final int p1) throws SQLException;
    
    String getOriginalSql() throws SQLException;
    
    OracleResultSetCache getResultSetCache() throws SQLException;
    
    int getMaxFieldSize() throws SQLException;
}
