// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.Reader;
import java.io.InputStream;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.ORAData;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.DATE;
import oracle.sql.CustomDatum;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.Ref;
import java.sql.NClob;
import java.util.Calendar;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.SQLException;
import java.sql.SQLWarning;

abstract class BaseResultSet extends OracleResultSet
{
    SQLWarning sqlWarning;
    boolean autoRefetch;
    boolean closed;
    boolean close_statement_on_close;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    BaseResultSet() {
        this.sqlWarning = null;
        this.autoRefetch = true;
        this.closed = false;
        this.close_statement_on_close = false;
    }
    
    @Override
    public void closeStatementOnClose() {
        this.close_statement_on_close = true;
    }
    
    @Override
    public void beforeFirst() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "beforeFirst");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void afterLast() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "afterLast");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean first() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "first");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean last() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "last");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean absolute(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "absolute");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean relative(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "relative");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean previous() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "previous");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFetchDirection(final int n) throws SQLException {
        if (n == 1000) {
            return;
        }
        if (n == 1001 || n == 1002) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "setFetchDirection(FETCH_REVERSE, FETCH_UNKNOWN)");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
        sqlException2.fillInStackTrace();
        throw sqlException2;
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        return 1000;
    }
    
    @Override
    public int getType() throws SQLException {
        return 1003;
    }
    
    @Override
    public int getConcurrency() throws SQLException {
        return 1007;
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return this.sqlWarning;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        this.sqlWarning = null;
    }
    
    @Override
    public void updateArray(final int n, final Array array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateArray");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBigDecimal(final int n, final BigDecimal bigDecimal) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBigDecimal");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBlob(final int n, final Blob blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBlob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBoolean(final int n, final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBoolean");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateByte(final int n, final byte b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateByte");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBytes(final int n, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBytes");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateClob(final int n, final Clob clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateClob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateDate(final int n, final Date date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateDate");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateDate(final int n, final Date date, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateDate");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateDouble(final int n, final double n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateDouble");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateFloat(final int n, final float n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateFloat");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateInt(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateInt");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateLong(final int n, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateLong");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNClob(final int n, final NClob nClob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNClob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNString(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNString");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateObject(final int n, final Object o) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateObject");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateObject(final int n, final Object o, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateObject");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateRef(final int n, final Ref ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateRef");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateRowId(final int n, final RowId rowId) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateRowId");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateShort(final int n, final short n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateShort");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateSQLXML(final int n, final SQLXML sqlxml) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateSQLXML");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateString(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateString");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTime(final int n, final Time time) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTime");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTime(final int n, final Time time, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTime");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTimestamp(final int n, final Timestamp timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTimestamp(final int n, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateURL(final int n, final URL url) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateURL");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateARRAY(final int n, final ARRAY array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateARRAY");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBFILE(final int n, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBFILE");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBfile(final int n, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBfile");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryFloat(final int n, final float n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryFloat(final int n, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryDouble(final int n, final double n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryDouble(final int n, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBLOB(final int n, final BLOB blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBLOB");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCHAR(final int n, final CHAR char1) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCHAR");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCLOB(final int n, final CLOB clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCLOB");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCursor(final int n, final ResultSet set) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCursor");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCustomDatum(final int n, final CustomDatum customDatum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCustomDatum");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateDATE(final int n, final DATE date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateDATE");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateFixedCHAR(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateFixedCHAR");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateINTERVALDS(final int n, final INTERVALDS intervalds) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateINTERVALDS");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateINTERVALYM(final int n, final INTERVALYM intervalym) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateINTERVALYM");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNUMBER(final int n, final NUMBER number) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNUMBER");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateOPAQUE(final int n, final OPAQUE opaque) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateOPAQUE");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateOracleObject(final int n, final Datum datum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateOracleObject");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateORAData(final int n, final ORAData oraData) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateORAData");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateRAW(final int n, final RAW raw) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateRAW");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateREF(final int n, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateREF");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateRefType(final int n, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateRefType");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateROWID(final int n, final ROWID rowid) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateROWID");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateSTRUCT(final int n, final STRUCT struct) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateSTRUCT");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTIMESTAMPLTZ(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPLTZ");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTIMESTAMPTZ(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPTZ");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateTIMESTAMP(final int n, final TIMESTAMP timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMP");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBlob(final int n, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBlob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBlob(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBlob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateClob(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateClob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateClob(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateClob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNClob(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNClob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNClob(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNClob");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateAsciiStream(final int n, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateAsciiStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryStream(final int n, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateBinaryStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCharacterStream(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCharacterStream(final int n, final Reader reader, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNCharacterStream(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNCharacterStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNCharacterStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateUnicodeStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateUnicodeStream");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateNull(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateNull");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean rowUpdated() throws SQLException {
        return false;
    }
    
    @Override
    public boolean rowInserted() throws SQLException {
        return false;
    }
    
    @Override
    public boolean rowDeleted() throws SQLException {
        return false;
    }
    
    @Override
    public void insertRow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "insertRow");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void updateRow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "updateRow");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void deleteRow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "deleteRow");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void refreshRow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, null);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void cancelRowUpdates() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "cancelRowUpdates");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void moveToInsertRow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "moveToInsertRow");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void moveToCurrentRow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 76, "moveToCurrentRow");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAutoRefetch(final boolean autoRefetch) throws SQLException {
        this.autoRefetch = autoRefetch;
    }
    
    @Override
    public boolean getAutoRefetch() throws SQLException {
        return this.autoRefetch;
    }
    
    @Override
    public void close() throws SQLException {
        this.closed = true;
    }
    
    @Override
    OracleStatement getOracleStatement() throws SQLException {
        return null;
    }
    
    @Override
    public int getHoldability() throws SQLException {
        return 1;
    }
    
    @Override
    public boolean isClosed() throws SQLException {
        return this.closed;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
