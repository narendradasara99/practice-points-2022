// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class OutRawAccessor extends RawCommonAccessor
{
    static final int MAXLENGTH_NEW = 32767;
    static final int MAXLENGTH_OLD = 32767;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OutRawAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3) throws SQLException {
        this.init(oracleStatement, 23, 23, n2, true);
        this.initForDataAccess(n3, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        if (this.statement.connection.getVersionNumber() >= 8000) {
            this.internalTypeMaxLength = 32767;
        }
        else {
            this.internalTypeMaxLength = 32767;
        }
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        byte[] array = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
        }
        return array;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
