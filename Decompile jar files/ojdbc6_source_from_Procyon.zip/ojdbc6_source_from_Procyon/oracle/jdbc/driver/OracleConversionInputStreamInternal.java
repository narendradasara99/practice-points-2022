// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.Reader;
import java.io.InputStream;

class OracleConversionInputStreamInternal extends OracleConversionInputStream
{
    boolean needReset;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConversionInputStreamInternal(final DBConversion dbConversion, final InputStream inputStream, final int n, final int n2) {
        super(dbConversion, inputStream, n, n2);
        this.needReset = false;
    }
    
    public OracleConversionInputStreamInternal(final DBConversion dbConversion, final Reader reader, final int n, final int n2, final short n3) {
        super(dbConversion, reader, n, n2, n3);
        this.needReset = false;
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) throws IOException {
        if (this.needReset) {
            if (this.istream != null && this.istream.markSupported()) {
                this.istream.reset();
                this.endOfStream = false;
                this.totalSize = 0;
                this.needReset = false;
            }
            else if (this.reader != null && this.reader.markSupported()) {
                this.reader.reset();
                this.endOfStream = false;
                this.totalSize = 0;
                this.needReset = false;
            }
        }
        final int read = super.read(array, n, n2);
        if (read == -1) {
            this.needReset = true;
        }
        return read;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
