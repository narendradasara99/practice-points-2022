// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Map;
import oracle.sql.Datum;
import java.sql.SQLException;

class DateAccessor extends DateTimeCommonAccessor
{
    static final int maxLength = 7;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    DateAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 12, 12, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    DateAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 12, 12, n7, false);
        this.initForDescribe(12, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 7;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String text = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final int n3 = ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100;
            final byte b = this.rowSpaceByte[2 + n2];
            final byte b2 = this.rowSpaceByte[3 + n2];
            final int n4 = this.rowSpaceByte[4 + n2] - 1;
            text = this.toText(n3, b, b2, n4, this.rowSpaceByte[5 + n2] - 1, this.rowSpaceByte[6 + n2] - 1, -1, n4 < 12, null);
        }
        return text;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            if (this.externalType == 0) {
                if (this.statement.connection.mapDateToTimestamp) {
                    o = this.getTimestamp(n);
                }
                else {
                    o = this.getDate(n);
                }
            }
            else {
                switch (this.externalType) {
                    case 91: {
                        return this.getDate(n);
                    }
                    case 92: {
                        return this.getTime(n);
                    }
                    case 93: {
                        return this.getTimestamp(n);
                    }
                    default: {
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                }
            }
        }
        return o;
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getDATE(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getObject(n);
    }
    
    static String toStr(final int n) {
        return (n < 10) ? ("0" + n) : Integer.toString(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
