// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class OracleTimeoutPollingThread extends Thread
{
    protected static final String threadName = "OracleTimeoutPollingThread";
    public static final String pollIntervalProperty = "oracle.jdbc.TimeoutPollInterval";
    public static final String pollIntervalDefault = "1000";
    private OracleTimeoutThreadPerVM[] knownTimeouts;
    private int count;
    private long sleepMillis;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleTimeoutPollingThread() {
        super("OracleTimeoutPollingThread");
        this.setDaemon(true);
        this.setPriority(10);
        this.knownTimeouts = new OracleTimeoutThreadPerVM[2];
        this.count = 0;
        this.sleepMillis = Long.parseLong(PhysicalConnection.getSystemPropertyPollInterval());
        this.start();
    }
    
    public synchronized void addTimeout(final OracleTimeoutThreadPerVM oracleTimeoutThreadPerVM) {
        int i = 0;
        if (this.count >= this.knownTimeouts.length) {
            final OracleTimeoutThreadPerVM[] knownTimeouts = new OracleTimeoutThreadPerVM[this.knownTimeouts.length * 4];
            System.arraycopy(this.knownTimeouts, 0, knownTimeouts, 0, this.knownTimeouts.length);
            i = this.knownTimeouts.length;
            this.knownTimeouts = knownTimeouts;
        }
        while (i < this.knownTimeouts.length) {
            if (this.knownTimeouts[i] == null) {
                this.knownTimeouts[i] = oracleTimeoutThreadPerVM;
                ++this.count;
                break;
            }
            ++i;
        }
    }
    
    public synchronized void removeTimeout(final OracleTimeoutThreadPerVM oracleTimeoutThreadPerVM) {
        for (int i = 0; i < this.knownTimeouts.length; ++i) {
            if (this.knownTimeouts[i] == oracleTimeoutThreadPerVM) {
                this.knownTimeouts[i] = null;
                --this.count;
                break;
            }
        }
    }
    
    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(this.sleepMillis);
            }
            catch (InterruptedException ex) {}
            this.pollOnce();
        }
    }
    
    private void pollOnce() {
        if (this.count > 0) {
            final long currentTimeMillis = System.currentTimeMillis();
            for (int i = 0; i < this.knownTimeouts.length; ++i) {
                try {
                    if (this.knownTimeouts[i] != null) {
                        this.knownTimeouts[i].interruptIfAppropriate(currentTimeMillis);
                    }
                }
                catch (NullPointerException ex) {}
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
