// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.BLOB;
import oracle.jdbc.OracleConnection;
import oracle.sql.Datum;
import java.sql.Connection;

final class T4C8TTIBlob extends T4C8TTILob
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8TTIBlob(final T4CConnection t4CConnection) {
        super(t4CConnection);
    }
    
    @Override
    Datum createTemporaryLob(final Connection connection, final boolean b, final int n) throws SQLException, IOException {
        if (n == 12) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 158);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        Datum datum = null;
        this.initializeLobdef();
        this.lobops = 272L;
        (this.sourceLobLocator = new byte[86])[1] = 84;
        this.characterSet = 1;
        this.lobamt = n;
        this.sendLobamt = true;
        this.destinationOffset = 113L;
        this.nullO2U = true;
        if (this.connection.versionNumber >= 9000) {
            (this.lobscn = new int[1])[0] = (b ? 1 : 0);
            this.lobscnl = 1;
        }
        this.doRPC();
        if (this.sourceLobLocator != null) {
            datum = new BLOB((OracleConnection)connection, this.sourceLobLocator);
        }
        return datum;
    }
    
    @Override
    boolean open(final byte[] array, final int n) throws SQLException, IOException {
        int n2 = 2;
        if (n == 0) {
            n2 = 1;
        }
        return this._open(array, n2, 32768);
    }
    
    @Override
    boolean close(final byte[] array) throws SQLException, IOException {
        return this._close(array, 65536);
    }
    
    @Override
    boolean isOpen(final byte[] array) throws SQLException, IOException {
        return this._isOpen(array, 69632);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
