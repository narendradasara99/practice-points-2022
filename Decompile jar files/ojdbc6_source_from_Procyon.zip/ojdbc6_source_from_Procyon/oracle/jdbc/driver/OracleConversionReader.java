// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;
import java.io.InputStream;
import java.io.Reader;

class OracleConversionReader extends Reader
{
    static final int CHUNK_SIZE = 4096;
    DBConversion dbConversion;
    int conversion;
    InputStream istream;
    char[] buf;
    byte[] byteBuf;
    int pos;
    int count;
    int numUnconvertedBytes;
    boolean isClosed;
    boolean endOfStream;
    private short csform;
    int[] nbytes;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConversionReader(final DBConversion dbConversion, final InputStream istream, final int conversion) throws SQLException {
        if (dbConversion == null || istream == null || (conversion != 8 && conversion != 9)) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.dbConversion = dbConversion;
        this.conversion = conversion;
        this.istream = istream;
        final int n = 0;
        this.count = n;
        this.pos = n;
        this.numUnconvertedBytes = 0;
        this.isClosed = false;
        this.nbytes = new int[1];
        if (conversion == 8) {
            this.byteBuf = new byte[2048];
            this.buf = new char[4096];
        }
        else if (conversion == 9) {
            this.byteBuf = new byte[4096];
            this.buf = new char[4096];
        }
    }
    
    public void setFormOfUse(final short csform) {
        this.csform = csform;
    }
    
    @Override
    public int read(final char[] array, final int n, final int a) throws IOException {
        this.ensureOpen();
        if (!this.needChars()) {
            return -1;
        }
        int n2;
        int n3;
        for (n2 = n + Math.min(a, array.length - n), n3 = n + this.writeChars(array, n, n2 - n); n3 < n2 && this.needChars(); n3 += this.writeChars(array, n3, n2 - n3)) {}
        return n3 - n;
    }
    
    protected boolean needChars() throws IOException {
        this.ensureOpen();
        if (this.pos >= this.count) {
            if (!this.endOfStream) {
                try {
                    final int read = this.istream.read(this.byteBuf, this.numUnconvertedBytes, this.byteBuf.length - this.numUnconvertedBytes);
                    if (read == -1) {
                        this.endOfStream = true;
                        this.istream.close();
                        if (this.numUnconvertedBytes != 0) {
                            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 55);
                            sqlException.fillInStackTrace();
                            throw sqlException;
                        }
                    }
                    final int n = read + this.numUnconvertedBytes;
                    if (n > 0) {
                        switch (this.conversion) {
                            case 8: {
                                final DBConversion dbConversion = this.dbConversion;
                                this.count = DBConversion.RAWBytesToHexChars(this.byteBuf, n, this.buf);
                                break;
                            }
                            case 9: {
                                this.nbytes[0] = n;
                                if (this.csform == 2) {
                                    this.count = this.dbConversion.NCHARBytesToJavaChars(this.byteBuf, 0, this.buf, 0, this.nbytes, this.buf.length);
                                }
                                else {
                                    this.count = this.dbConversion.CHARBytesToJavaChars(this.byteBuf, 0, this.buf, 0, this.nbytes, this.buf.length);
                                }
                                this.numUnconvertedBytes = this.nbytes[0];
                                for (int i = 0; i < this.numUnconvertedBytes; ++i) {
                                    this.byteBuf[i] = this.byteBuf[n - this.numUnconvertedBytes + i];
                                }
                                break;
                            }
                            default: {
                                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23);
                                sqlException2.fillInStackTrace();
                                throw sqlException2;
                            }
                        }
                        if (this.count > 0) {
                            this.pos = 0;
                            return true;
                        }
                    }
                }
                catch (SQLException ex) {
                    final IOException ioException = DatabaseError.createIOException(ex);
                    ioException.fillInStackTrace();
                    throw ioException;
                }
            }
            return false;
        }
        return true;
    }
    
    protected int writeChars(final char[] array, final int n, final int a) {
        final int min = Math.min(a, this.count - this.pos);
        System.arraycopy(this.buf, this.pos, array, n, min);
        this.pos += min;
        return min;
    }
    
    @Override
    public boolean ready() throws IOException {
        this.ensureOpen();
        return this.pos < this.count;
    }
    
    @Override
    public void close() throws IOException {
        if (!this.isClosed) {
            this.isClosed = true;
            this.istream.close();
        }
    }
    
    void ensureOpen() throws IOException {
        try {
            if (this.isClosed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 57, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
