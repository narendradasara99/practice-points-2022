// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import oracle.jdbc.internal.XSAttribute;
import oracle.sql.TIMESTAMPTZ;
import java.sql.SQLException;
import oracle.jdbc.internal.XSNamespace;

class XSNamespaceI extends XSNamespace
{
    String namespaceName;
    byte[] namespaceNameBytes;
    XSAttributeI[] attributes;
    byte[] timestampBytes;
    long flag;
    byte[][] aclList;
    
    XSNamespaceI() {
        this.namespaceName = null;
        this.attributes = null;
        this.timestampBytes = null;
        this.flag = 0L;
        this.aclList = null;
    }
    
    @Override
    public void setNamespaceName(final String namespaceName) throws SQLException {
        this.namespaceName = namespaceName;
    }
    
    @Override
    public void setTimestamp(final TIMESTAMPTZ timestamptz) throws SQLException {
        this.timestampBytes = timestamptz.toBytes();
    }
    
    private void setTimestamp(final byte[] timestampBytes) throws SQLException {
        this.timestampBytes = timestampBytes;
    }
    
    @Override
    public void setACLIdList(final byte[][] aclList) throws SQLException {
        this.aclList = aclList;
    }
    
    @Override
    public void setFlag(final long flag) throws SQLException {
        this.flag = flag;
    }
    
    @Override
    public void setAttributes(final XSAttribute[] array) throws SQLException {
        if (array != null) {
            final XSAttributeI[] attributes = new XSAttributeI[array.length];
            for (int i = 0; i < array.length; ++i) {
                attributes[i] = (XSAttributeI)array[i];
            }
            this.attributes = attributes;
        }
    }
    
    void doCharConversion(final DBConversion dbConversion) throws SQLException {
        if (this.namespaceName != null) {
            this.namespaceNameBytes = dbConversion.StringToCharBytes(this.namespaceName);
        }
        else {
            this.namespaceNameBytes = null;
        }
        if (this.attributes != null) {
            for (int i = 0; i < this.attributes.length; ++i) {
                this.attributes[i].doCharConversion(dbConversion);
            }
        }
    }
    
    @Override
    public String getNamespaceName() {
        return this.namespaceName;
    }
    
    @Override
    public TIMESTAMPTZ getTimestamp() {
        return new TIMESTAMPTZ(this.timestampBytes);
    }
    
    @Override
    public long getFlag() {
        return this.flag;
    }
    
    @Override
    public XSAttribute[] getAttributes() {
        return this.attributes;
    }
    
    @Override
    public byte[][] getACLIdList() {
        return this.aclList;
    }
    
    void marshal(final T4CMAREngine t4CMAREngine) throws IOException {
        if (this.namespaceNameBytes != null) {
            t4CMAREngine.marshalUB4(this.namespaceNameBytes.length);
            t4CMAREngine.marshalCLR(this.namespaceNameBytes, this.namespaceNameBytes.length);
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
        if (this.timestampBytes != null) {
            t4CMAREngine.marshalUB4(this.timestampBytes.length);
            t4CMAREngine.marshalCLR(this.timestampBytes, this.timestampBytes.length);
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
        t4CMAREngine.marshalUB4(this.flag);
        if (this.attributes != null) {
            t4CMAREngine.marshalUB4(this.attributes.length);
            t4CMAREngine.marshalUB1((short)28);
            for (int i = 0; i < this.attributes.length; ++i) {
                this.attributes[i].marshal(t4CMAREngine);
            }
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
        if (this.aclList != null) {
            final byte[] array = new byte[this.aclList.length * 16];
            for (int j = 0; j < this.aclList.length; ++j) {
                System.arraycopy(this.aclList[j], 0, array, 16 * j, 16);
            }
            t4CMAREngine.marshalUB4(array.length);
            t4CMAREngine.marshalCLR(array, array.length);
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
    }
    
    static XSNamespaceI unmarshal(final T4CMAREngine t4CMAREngine) throws SQLException, IOException {
        final int[] array = { 0 };
        String charBytesToString = null;
        final int n = (int)t4CMAREngine.unmarshalUB4();
        if (n > 0) {
            final byte[] array2 = new byte[n];
            t4CMAREngine.unmarshalCLR(array2, 0, array);
            charBytesToString = t4CMAREngine.conv.CharBytesToString(array2, array[0]);
        }
        byte[] unmarshalNBytes = null;
        final int n2 = (int)t4CMAREngine.unmarshalUB4();
        if (n2 > 0) {
            unmarshalNBytes = t4CMAREngine.unmarshalNBytes(n2);
        }
        final long unmarshalUB4 = t4CMAREngine.unmarshalUB4();
        final int n3 = (int)t4CMAREngine.unmarshalUB4();
        final XSAttribute[] attributes = new XSAttribute[n3];
        if (n3 > 0) {
            t4CMAREngine.unmarshalUB1();
        }
        for (int i = 0; i < n3; ++i) {
            attributes[i] = XSAttributeI.unmarshal(t4CMAREngine);
        }
        final int n4 = (int)t4CMAREngine.unmarshalUB4();
        byte[][] aclIdList = null;
        if (n4 > 0) {
            final byte[] array3 = new byte[n4];
            t4CMAREngine.unmarshalCLR(array3, 0, array);
            final int n5 = n4 / 16;
            aclIdList = new byte[n5][];
            for (int j = 0; j < n5; ++j) {
                System.arraycopy(array3, j * 16, aclIdList[j] = new byte[16], 0, 16);
            }
        }
        final XSNamespaceI xsNamespaceI = new XSNamespaceI();
        xsNamespaceI.setNamespaceName(charBytesToString);
        xsNamespaceI.setTimestamp(unmarshalNBytes);
        xsNamespaceI.setFlag(unmarshalUB4);
        xsNamespaceI.setAttributes(attributes);
        xsNamespaceI.setACLIdList(aclIdList);
        return xsNamespaceI;
    }
}
