// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CPreparedStatement extends OraclePreparedStatement
{
    static final byte[] EMPTY_BYTE;
    T4CConnection t4Connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CPreparedStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        super(physicalConnection, s, physicalConnection.defaultExecuteBatch, physicalConnection.defaultRowPrefetch, n, n2);
        (this.nbPostPonedColumns = new int[1])[0] = 0;
        this.indexOfPostPonedColumn = new int[1][3];
        this.t4Connection = (T4CConnection)physicalConnection;
        this.theRowidBinder = T4CPreparedStatement.theStaticT4CRowidBinder;
        this.theRowidNullBinder = T4CPreparedStatement.theStaticT4CRowidNullBinder;
        this.theURowidBinder = T4CPreparedStatement.theStaticT4CURowidBinder;
        this.theURowidNullBinder = T4CPreparedStatement.theStaticT4CURowidNullBinder;
    }
    
    void doOall8(final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5) throws SQLException, IOException {
        if (b || b4 || !b2) {
            this.oacdefSent = null;
        }
        this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
        if ((this.sqlKind & -1) == 0x0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (b3) {
            this.rowPrefetchInLastFetch = this.rowPrefetch;
        }
        int numberOfDefinePositions = this.numberOfDefinePositions;
        if ((this.sqlKind & 0x1E) != 0x0) {
            numberOfDefinePositions = 0;
        }
        if (this.accessors != null) {
            for (int i = 0; i < this.accessors.length; ++i) {
                if (this.accessors[i] != null) {
                    this.accessors[i].lastRowProcessed = 0;
                }
            }
        }
        if (this.outBindAccessors != null) {
            for (int j = 0; j < this.outBindAccessors.length; ++j) {
                if (this.outBindAccessors[j] != null) {
                    this.outBindAccessors[j].lastRowProcessed = 0;
                }
            }
        }
        if (this.returnParamAccessors != null) {
            for (int k = 0; k < this.returnParamAccessors.length; ++k) {
                if (this.returnParamAccessors[k] != null) {
                    this.returnParamAccessors[k].lastRowProcessed = 0;
                }
            }
        }
        if (this.bindIndicators != null) {
            final int n = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
            int n2 = 0;
            if (this.ibtBindChars != null) {
                n2 = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
            }
            for (int l = 0; l < this.numberOfBindPositions; ++l) {
                final int n3 = this.bindIndicatorSubRange + 5 + 10 * l;
                final int n4 = this.bindIndicators[n3 + 2] & 0xFFFF;
                if (n4 != 0) {
                    if ((this.bindIndicators[n3 + 9] & 0xFFFF) == 0x2) {
                        n2 = Math.max(n4 * this.connection.conversion.maxNCharSize, n2);
                    }
                    else {
                        n2 = Math.max(n4 * this.connection.conversion.cMaxCharSize, n2);
                    }
                }
            }
            if (this.tmpBindsByteArray == null) {
                this.tmpBindsByteArray = new byte[n2];
            }
            else if (this.tmpBindsByteArray.length < n2) {
                this.tmpBindsByteArray = null;
                this.tmpBindsByteArray = new byte[n2];
            }
        }
        else {
            this.tmpBindsByteArray = null;
        }
        int[] definedColumnType = this.definedColumnType;
        int[] definedColumnSize = this.definedColumnSize;
        int[] definedColumnFormOfUse = this.definedColumnFormOfUse;
        if (b5 && b4 && this.sqlObject.includeRowid) {
            definedColumnType = new int[this.definedColumnType.length + 1];
            System.arraycopy(this.definedColumnType, 0, definedColumnType, 1, this.definedColumnType.length);
            definedColumnType[0] = -8;
            definedColumnSize = new int[this.definedColumnSize.length + 1];
            System.arraycopy(this.definedColumnSize, 0, definedColumnSize, 1, this.definedColumnSize.length);
            definedColumnFormOfUse = new int[this.definedColumnFormOfUse.length + 1];
            System.arraycopy(this.definedColumnFormOfUse, 0, definedColumnFormOfUse, 1, this.definedColumnFormOfUse.length);
        }
        this.allocateTmpByteArray();
        final T4C8Oall all8 = this.t4Connection.all8;
        this.t4Connection.sendPiggyBackedMessages();
        try {
            all8.doOALL(b, b2, b3, b4, b5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, numberOfDefinePositions, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, definedColumnType, definedColumnSize, definedColumnFormOfUse, this.registration);
            this.cursorId = all8.getCursorId();
            this.oacdefSent = all8.oacdefBindsSent;
        }
        catch (SQLException ex) {
            this.cursorId = all8.getCursorId();
            if (ex.getErrorCode() != DatabaseError.getVendorCode(110)) {
                throw ex;
            }
            this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
        }
    }
    
    @Override
    void allocateTmpByteArray() {
        if (this.tmpByteArray == null) {
            this.tmpByteArray = new byte[this.sizeTmpByteArray];
        }
        else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
            this.tmpByteArray = new byte[this.sizeTmpByteArray];
        }
    }
    
    @Override
    void releaseBuffers() {
        super.releaseBuffers();
        this.tmpByteArray = null;
        this.tmpBindsByteArray = null;
        this.t4Connection.all8.bindChars = null;
        this.t4Connection.all8.bindBytes = null;
        this.t4Connection.all8.tmpBindsByteArray = null;
    }
    
    @Override
    void allocateRowidAccessor() throws SQLException {
        this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
    }
    
    @Override
    void reparseOnRedefineIfNeeded() throws SQLException {
        this.needToParse = true;
    }
    
    protected void defineColumnTypeInternal(final int n, final int n2, final int definedColumnSize, final short n3, final boolean b, final String s) throws SQLException {
        if (this.connection.disableDefinecolumntype) {
            return;
        }
        if (n < 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (b) {
            if (n2 == 1 || n2 == 12) {
                this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
            }
        }
        else if (definedColumnSize < 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 53);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.currentResultSet != null && !this.currentResultSet.closed) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 28);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        final int n4 = n - 1;
        if (this.definedColumnType == null || this.definedColumnType.length <= n4) {
            if (this.definedColumnType == null) {
                this.definedColumnType = new int[(n4 + 1) * 4];
            }
            else {
                final int[] definedColumnType = new int[(n4 + 1) * 4];
                System.arraycopy(this.definedColumnType, 0, definedColumnType, 0, this.definedColumnType.length);
                this.definedColumnType = definedColumnType;
            }
        }
        this.definedColumnType[n4] = n2;
        if (this.definedColumnSize == null || this.definedColumnSize.length <= n4) {
            if (this.definedColumnSize == null) {
                this.definedColumnSize = new int[(n4 + 1) * 4];
            }
            else {
                final int[] definedColumnSize2 = new int[(n4 + 1) * 4];
                System.arraycopy(this.definedColumnSize, 0, definedColumnSize2, 0, this.definedColumnSize.length);
                this.definedColumnSize = definedColumnSize2;
            }
        }
        this.definedColumnSize[n4] = definedColumnSize;
        if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= n4) {
            if (this.definedColumnFormOfUse == null) {
                this.definedColumnFormOfUse = new int[(n4 + 1) * 4];
            }
            else {
                final int[] definedColumnFormOfUse = new int[(n4 + 1) * 4];
                System.arraycopy(this.definedColumnFormOfUse, 0, definedColumnFormOfUse, 0, this.definedColumnFormOfUse.length);
                this.definedColumnFormOfUse = definedColumnFormOfUse;
            }
        }
        this.definedColumnFormOfUse[n4] = n3;
        if (this.accessors != null && n4 < this.accessors.length && this.accessors[n4] != null) {
            this.accessors[n4].definedColumnSize = definedColumnSize;
            if ((this.accessors[n4].internalType == 96 || this.accessors[n4].internalType == 1) && (n2 == 1 || n2 == 12) && definedColumnSize <= this.accessors[n4].oacmxl) {
                this.needToPrepareDefineBuffer = true;
                this.columnsDefinedByUser = true;
                this.accessors[n4].initForDataAccess(n2, definedColumnSize, null);
                this.accessors[n4].calculateSizeTmpByteArray();
            }
        }
    }
    
    @Override
    public void clearDefines() throws SQLException {
        synchronized (this.connection) {
            super.clearDefines();
            this.definedColumnType = null;
            this.definedColumnSize = null;
            this.definedColumnFormOfUse = null;
        }
    }
    
    @Override
    void saveDefineBuffersIfRequired(final char[] array, final byte[] array2, short[] array3, final boolean b) throws SQLException {
        final boolean b2 = this.rowPrefetchInLastFetch < this.rowPrefetch;
        if (b) {
            array3 = new short[this.defineIndicators.length];
            final int lengthIndexLastRow = this.accessors[0].lengthIndexLastRow;
            final int indicatorIndexLastRow = this.accessors[0].indicatorIndexLastRow;
            int n = b2 ? this.accessors.length : 1;
            while (true) {
                if (b2) {
                    if (n < 1) {
                        break;
                    }
                }
                else if (n > this.accessors.length) {
                    break;
                }
                final int n2 = lengthIndexLastRow + this.rowPrefetchInLastFetch * n - 1;
                final int n3 = indicatorIndexLastRow + this.rowPrefetchInLastFetch * n - 1;
                array3[n3] = this.defineIndicators[n3];
                array3[n2] = this.defineIndicators[n2];
                n += (b2 ? -1 : 1);
            }
        }
        int n4 = b2 ? (this.accessors.length - 1) : 0;
        while (true) {
            if (b2) {
                if (n4 <= -1) {
                    break;
                }
            }
            else if (n4 >= this.accessors.length) {
                break;
            }
            this.accessors[n4].saveDataFromOldDefineBuffers(array2, array, array3, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
            n4 += (b2 ? -1 : 1);
        }
        super.saveDefineBuffersIfRequired(array, array2, array3, b);
    }
    
    @Override
    Accessor allocateAccessor(final int n, final int i, final int n2, final int n3, final short n4, final String s, final boolean b) throws SQLException {
        Accessor accessor = null;
        switch (n) {
            case 96: {
                accessor = new T4CCharAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 8: {
                if (!b) {
                    accessor = new T4CLongAccessor(this, n2, n3, n4, i, this.t4Connection.mare);
                    break;
                }
            }
            case 1: {
                accessor = new T4CVarcharAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 2: {
                accessor = new T4CNumberAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 6: {
                accessor = new T4CVarnumAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 24: {
                if (!b) {
                    accessor = new T4CLongRawAccessor(this, n2, n3, n4, i, this.t4Connection.mare);
                    break;
                }
            }
            case 23: {
                if (b && s != null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + i);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                if (b) {
                    accessor = new T4COutRawAccessor(this, n3, n4, i, this.t4Connection.mare);
                    break;
                }
                accessor = new T4CRawAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 100: {
                accessor = new T4CBinaryFloatAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 101: {
                accessor = new T4CBinaryDoubleAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 104: {
                if (this.sqlKind == 64) {
                    accessor = new T4CVarcharAccessor(this, 18, n4, i, b, this.t4Connection.mare);
                    accessor.definedColumnType = -8;
                    break;
                }
                accessor = new T4CRowidAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 102: {
                accessor = new T4CResultSetAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 12: {
                accessor = new T4CDateAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 113: {
                accessor = new T4CBlobAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 112: {
                accessor = new T4CClobAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 114: {
                accessor = new T4CBfileAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 109: {
                accessor = new T4CNamedTypeAccessor(this, s, n4, i, b, this.t4Connection.mare);
                accessor.initMetadata();
                break;
            }
            case 111: {
                accessor = new T4CRefTypeAccessor(this, s, n4, i, b, this.t4Connection.mare);
                accessor.initMetadata();
                break;
            }
            case 180: {
                accessor = new T4CTimestampAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 181: {
                accessor = new T4CTimestamptzAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 231: {
                accessor = new T4CTimestampltzAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 182: {
                accessor = new T4CIntervalymAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 183: {
                accessor = new T4CIntervaldsAccessor(this, n3, n4, i, b, this.t4Connection.mare);
                break;
            }
            case 995: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return accessor;
    }
    
    @Override
    void doDescribe(final boolean b) throws SQLException {
        if (!this.isOpen) {
            this.connection.open(this);
            this.isOpen = true;
        }
        try {
            this.t4Connection.needLine();
            this.t4Connection.sendPiggyBackedMessages();
            this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
            this.accessors = this.t4Connection.describe.getAccessors();
            this.numberOfDefinePositions = this.t4Connection.describe.numuds;
            for (int i = 0; i < this.numberOfDefinePositions; ++i) {
                this.accessors[i].initMetadata();
            }
        }
        catch (IOException ex) {
            ((T4CConnection)this.connection).handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.describedWithNames = true;
        this.described = true;
    }
    
    @Override
    void executeForDescribe() throws SQLException {
        this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
        this.cleanOldTempLobs();
        try {
            if (this.t4Connection.useFetchSizeWithLongColumn) {
                this.doOall8(true, true, true, true, false);
            }
            else {
                this.doOall8(true, true, false, true, this.definedColumnType != null);
            }
        }
        catch (SQLException ex) {
            throw ex;
        }
        catch (IOException ex2) {
            ((T4CConnection)this.connection).handleIOException(ex2);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        finally {
            this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
            this.validRows = this.t4Connection.all8.getNumRows();
        }
        this.needToParse = false;
        this.implicitDefineForLobPrefetchDone = false;
        this.aFetchWasDoneDuringDescribe = false;
        if (this.t4Connection.all8.aFetchWasDone) {
            this.aFetchWasDoneDuringDescribe = true;
            this.rowPrefetchInLastFetch = this.rowPrefetch;
        }
        for (int i = 0; i < this.numberOfDefinePositions; ++i) {
            this.accessors[i].initMetadata();
        }
        this.needToPrepareDefineBuffer = false;
    }
    
    @Override
    void executeForRows(final boolean b) throws SQLException {
        try {
            try {
                boolean b2 = false;
                if (this.columnsDefinedByUser) {
                    this.needToPrepareDefineBuffer = false;
                }
                else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
                    boolean b3 = false;
                    final int[] definedColumnType = new int[this.accessors.length];
                    final int[] definedColumnSize = new int[this.accessors.length];
                    for (int i = 0; i < this.accessors.length; ++i) {
                        definedColumnType[i] = this.getJDBCType(this.accessors[i].internalType);
                        if (this.accessors[i].internalType == 113 || this.accessors[i].internalType == 112 || this.accessors[i].internalType == 114) {
                            b3 = true;
                            this.accessors[i].lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
                            definedColumnSize[i] = this.defaultLobPrefetchSize;
                        }
                    }
                    if (b3) {
                        this.definedColumnType = definedColumnType;
                        this.definedColumnSize = definedColumnSize;
                        b2 = true;
                    }
                }
                this.doOall8(this.needToParse, !b, true, false, b2);
                this.needToParse = false;
                if (b2) {
                    this.implicitDefineForLobPrefetchDone = true;
                }
            }
            finally {
                this.validRows = this.t4Connection.all8.getNumRows();
            }
        }
        catch (SQLException ex) {
            throw ex;
        }
        catch (IOException ex2) {
            ((T4CConnection)this.connection).handleIOException(ex2);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    void fetch() throws SQLException {
        if (this.streamList != null) {
            while (this.nextStream != null) {
                try {
                    this.nextStream.close();
                }
                catch (IOException ex) {
                    ((T4CConnection)this.connection).handleIOException(ex);
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.nextStream = this.nextStream.nextStream;
            }
        }
        try {
            this.doOall8(false, false, true, false, false);
            this.validRows = this.t4Connection.all8.getNumRows();
        }
        catch (IOException ex2) {
            ((T4CConnection)this.connection).handleIOException(ex2);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    void continueReadRow(final int n) throws SQLException {
        try {
            if (!this.connection.useFetchSizeWithLongColumn) {
                this.t4Connection.all8.continueReadRow(n, this);
            }
        }
        catch (IOException ex) {
            ((T4CConnection)this.connection).handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (SQLException ex2) {
            if (ex2.getErrorCode() != DatabaseError.getVendorCode(110)) {
                throw ex2;
            }
            this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
        }
    }
    
    @Override
    void doClose() throws SQLException {
        this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
        try {
            if (this.cursorId != 0) {
                this.t4Connection.cursorToClose[this.t4Connection.cursorToCloseOffset++] = this.cursorId;
                if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length) {
                    this.t4Connection.sendPiggyBackedMessages();
                }
            }
        }
        catch (IOException ex) {
            ((T4CConnection)this.connection).handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.tmpByteArray = null;
        this.tmpBindsByteArray = null;
        this.definedColumnType = null;
        this.definedColumnSize = null;
        this.definedColumnFormOfUse = null;
        this.oacdefSent = null;
    }
    
    @Override
    void closeQuery() throws SQLException {
        this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
        if (this.streamList != null) {
            while (this.nextStream != null) {
                try {
                    this.nextStream.close();
                }
                catch (IOException ex) {
                    ((T4CConnection)this.connection).handleIOException(ex);
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.nextStream = this.nextStream.nextStream;
            }
        }
    }
    
    @Override
    Binder getRowidNullBinder(final int n) {
        if (this.sqlKind == 64) {
            this.currentRowCharLens[n] = 1;
            return this.theVarcharNullBinder;
        }
        return this.theRowidNullBinder;
    }
    
    @Override
    void doLocalInitialization() {
        super.doLocalInitialization();
        this.t4Connection.all8.bindChars = this.bindChars;
        this.t4Connection.all8.bindBytes = this.bindBytes;
    }
    
    static {
        EMPTY_BYTE = new byte[0];
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
