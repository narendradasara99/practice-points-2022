// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class NumberAccessor extends NumberCommonAccessor
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NumberAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, n, n2, n3, b);
    }
    
    NumberAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 2, n, b, n2, n3, n4, n5, n6, n7);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
