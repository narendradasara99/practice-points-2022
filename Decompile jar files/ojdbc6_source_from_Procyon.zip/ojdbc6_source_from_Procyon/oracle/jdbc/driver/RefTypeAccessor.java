// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Map;
import oracle.sql.Datum;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.REF;
import java.sql.Connection;
import oracle.sql.StructDescriptor;
import oracle.jdbc.OracleConnection;
import oracle.sql.TypeDescriptor;
import oracle.jdbc.oracore.OracleType;
import java.sql.SQLException;

class RefTypeAccessor extends TypeAccessor
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    RefTypeAccessor(final OracleStatement oracleStatement, final String s, final short n, final int n2, final boolean b) throws SQLException {
        this.init(oracleStatement, 111, 111, n, b);
        this.initForDataAccess(n2, 0, s);
    }
    
    RefTypeAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final String s) throws SQLException {
        this.init(oracleStatement, 111, 111, n7, false);
        this.initForDescribe(111, n, b, n2, n3, n4, n5, n6, n7, s);
        this.initForDataAccess(0, n, s);
    }
    
    RefTypeAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final String s, final OracleType oracleType) throws SQLException {
        this.init(oracleStatement, 111, 111, n7, false);
        this.describeOtype = oracleType;
        this.initForDescribe(111, n, b, n2, n3, n4, n5, n6, n7, s);
        this.internalOtype = oracleType;
        this.initForDataAccess(0, n, s);
    }
    
    @Override
    OracleType otypeFromName(final String s) throws SQLException {
        if (!this.outBind) {
            return TypeDescriptor.getTypeDescriptor(s, this.statement.connection).getPickler();
        }
        return StructDescriptor.createDescriptor(s, this.statement.connection).getOracleTypeADT();
    }
    
    @Override
    void initForDataAccess(final int n, final int n2, final String s) throws SQLException {
        super.initForDataAccess(n, n2, s);
        this.byteLength = this.statement.connection.refTypeAccessorByteLen;
    }
    
    @Override
    REF getREF(final int n) throws SQLException {
        REF ref = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            ref = new REF(((OracleTypeADT)this.internalOtype).getFullName(), this.statement.connection, this.pickledBytes(n));
        }
        return ref;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getREF(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getREF(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getREF(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
