// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.ROWID;
import oracle.jdbc.dcn.RowChangeDescription;

class NTFDCNRowChanges implements RowChangeDescription
{
    RowOperation opcode;
    int rowidLength;
    byte[] rowid;
    ROWID rowidObj;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFDCNRowChanges(final RowOperation opcode, final int rowidLength, final byte[] rowid) {
        this.opcode = opcode;
        this.rowidLength = rowidLength;
        this.rowid = rowid;
        this.rowidObj = null;
    }
    
    @Override
    public ROWID getRowid() {
        if (this.rowidObj == null) {
            this.rowidObj = new ROWID(this.rowid);
        }
        return this.rowidObj;
    }
    
    @Override
    public RowOperation getRowOperation() {
        return this.opcode;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("      ROW:  operation=" + this.getRowOperation() + ", ROWID=" + new String(this.rowid) + "\n");
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
