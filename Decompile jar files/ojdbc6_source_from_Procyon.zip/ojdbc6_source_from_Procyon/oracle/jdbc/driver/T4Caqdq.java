// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.aq.AQAgent;
import oracle.jdbc.aq.AQMessageProperties;
import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.aq.AQDequeueOptions;

final class T4Caqdq extends T4CTTIfun
{
    T4CTTIaqm aqm;
    T4Ctoh toh;
    private String queueName;
    private AQDequeueOptions dequeueOptions;
    private byte[] payloadToid;
    private byte[] queueNameBytes;
    private byte[] consumerNameBytes;
    private byte[] correlationBytes;
    private byte[] conditionBytes;
    private int nbExtensions;
    private byte[][] extensionTextValues;
    private byte[][] extensionBinaryValues;
    private int[] extensionKeywords;
    private byte[] payload;
    private boolean hasAMessageBeenDequeued;
    private byte[] dequeuedMessageId;
    private boolean isRawQueue;
    private AQMessagePropertiesI properties;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4Caqdq(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.dequeueOptions = null;
        this.payloadToid = null;
        this.queueNameBytes = null;
        this.consumerNameBytes = null;
        this.correlationBytes = null;
        this.conditionBytes = null;
        this.nbExtensions = 0;
        this.extensionTextValues = null;
        this.extensionBinaryValues = null;
        this.extensionKeywords = null;
        this.payload = null;
        this.hasAMessageBeenDequeued = false;
        this.dequeuedMessageId = null;
        this.isRawQueue = false;
        this.properties = null;
        this.setFunCode((short)122);
        this.toh = new T4Ctoh();
        this.aqm = new T4CTTIaqm(this.connection, this.toh);
    }
    
    void doOAQDQ(final String queueName, final AQDequeueOptions dequeueOptions, final byte[] payloadToid, final boolean isRawQueue, final AQMessagePropertiesI properties) throws SQLException, IOException {
        this.queueName = queueName;
        this.dequeueOptions = dequeueOptions;
        this.payloadToid = payloadToid;
        this.isRawQueue = isRawQueue;
        this.properties = properties;
        if (this.queueName != null && this.queueName.length() != 0) {
            this.queueNameBytes = this.meg.conv.StringToCharBytes(this.queueName);
        }
        else {
            this.queueNameBytes = null;
        }
        final String consumerName = this.dequeueOptions.getConsumerName();
        if (consumerName != null && consumerName.length() > 0) {
            this.consumerNameBytes = this.meg.conv.StringToCharBytes(consumerName);
        }
        else {
            this.consumerNameBytes = null;
        }
        final String correlation = this.dequeueOptions.getCorrelation();
        if (correlation != null && correlation.length() != 0) {
            this.correlationBytes = this.meg.conv.StringToCharBytes(correlation);
        }
        else {
            this.correlationBytes = null;
        }
        final String condition = this.dequeueOptions.getCondition();
        if (condition != null && condition.length() > 0) {
            this.conditionBytes = this.meg.conv.StringToCharBytes(condition);
        }
        else {
            this.conditionBytes = null;
        }
        final String transformation = this.dequeueOptions.getTransformation();
        if (transformation != null && transformation.length() > 0) {
            this.nbExtensions = 1;
            this.extensionTextValues = new byte[this.nbExtensions][];
            this.extensionBinaryValues = new byte[this.nbExtensions][];
            this.extensionKeywords = new int[this.nbExtensions];
            this.extensionTextValues[0] = this.meg.conv.StringToCharBytes(transformation);
            this.extensionBinaryValues[0] = null;
            this.extensionKeywords[0] = 196;
        }
        else {
            this.nbExtensions = 0;
        }
        this.hasAMessageBeenDequeued = false;
        this.dequeuedMessageId = null;
        this.payload = null;
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.queueNameBytes.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        if (this.consumerNameBytes != null && this.consumerNameBytes.length != 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.consumerNameBytes.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalSB4(this.dequeueOptions.getDequeueMode().getCode());
        this.meg.marshalSB4(this.dequeueOptions.getNavigation().getCode());
        this.meg.marshalSB4(this.dequeueOptions.getVisibility().getCode());
        this.meg.marshalSB4(this.dequeueOptions.getWait());
        final byte[] dequeueMessageId = this.dequeueOptions.getDequeueMessageId();
        boolean b = false;
        if (dequeueMessageId != null && dequeueMessageId.length > 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(dequeueMessageId.length);
            b = true;
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        if (this.correlationBytes != null && this.correlationBytes.length != 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.correlationBytes.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalPTR();
        this.meg.marshalSWORD(this.payloadToid.length);
        this.meg.marshalUB2(1);
        this.meg.marshalPTR();
        if (this.dequeueOptions.getRetrieveMessageId()) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(16);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        int n = 0;
        if (this.connection.autocommit) {
            n = 32;
        }
        if (this.dequeueOptions.getDeliveryFilter() == AQDequeueOptions.DeliveryFilter.BUFFERED) {
            n |= 0x2;
        }
        else if (this.dequeueOptions.getDeliveryFilter() == AQDequeueOptions.DeliveryFilter.PERSISTENT_OR_BUFFERED) {
            n |= 0x10;
        }
        this.meg.marshalUB4(n);
        if (this.conditionBytes != null && this.conditionBytes.length > 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.conditionBytes.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        if (this.nbExtensions > 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.nbExtensions);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
            this.meg.marshalCHR(this.queueNameBytes);
        }
        if (this.consumerNameBytes != null && this.consumerNameBytes.length != 0) {
            this.meg.marshalCHR(this.consumerNameBytes);
        }
        if (b) {
            this.meg.marshalB1Array(dequeueMessageId);
        }
        if (this.correlationBytes != null && this.correlationBytes.length != 0) {
            this.meg.marshalCHR(this.correlationBytes);
        }
        this.meg.marshalB1Array(this.payloadToid);
        if (this.conditionBytes != null && this.conditionBytes.length > 0) {
            this.meg.marshalCHR(this.conditionBytes);
        }
        if (this.nbExtensions > 0) {
            this.meg.marshalKPDKV(this.extensionTextValues, this.extensionBinaryValues, this.extensionKeywords);
        }
    }
    
    byte[] getPayload() {
        return this.payload;
    }
    
    boolean hasAMessageBeenDequeued() {
        return this.hasAMessageBeenDequeued;
    }
    
    byte[] getDequeuedMessageId() {
        return this.dequeuedMessageId;
    }
    
    @Override
    void readRPA() throws SQLException, IOException {
        this.hasAMessageBeenDequeued = true;
        if ((int)this.meg.unmarshalUB4() > 0) {
            this.aqm.initToDefaultValues();
            this.aqm.receive();
            this.properties.setPriority(this.aqm.aqmpri);
            this.properties.setDelay(this.aqm.aqmdel);
            this.properties.setExpiration(this.aqm.aqmexp);
            if (this.aqm.aqmcorBytes != null) {
                this.properties.setCorrelation(this.meg.conv.CharBytesToString(this.aqm.aqmcorBytes, this.aqm.aqmcorBytesLength, true));
            }
            this.properties.setAttempts(this.aqm.aqmatt);
            if (this.aqm.aqmeqnBytes != null) {
                this.properties.setExceptionQueue(this.meg.conv.CharBytesToString(this.aqm.aqmeqnBytes, this.aqm.aqmeqnBytesLength, true));
            }
            this.properties.setMessageState(AQMessageProperties.MessageState.getMessageState(this.aqm.aqmsta));
            this.properties.setEnqueueTime(this.aqm.aqmeqt.timestampValue());
            final AQAgentI sender = new AQAgentI();
            if (this.aqm.senderAgentName != null) {
                sender.setName(this.meg.conv.CharBytesToString(this.aqm.senderAgentName, this.aqm.senderAgentNameLength, true));
            }
            if (this.aqm.senderAgentAddress != null) {
                sender.setAddress(this.meg.conv.CharBytesToString(this.aqm.senderAgentAddress, this.aqm.senderAgentAddressLength, true));
            }
            sender.setProtocol(this.aqm.senderAgentProtocol);
            this.properties.setSender(sender);
            this.properties.setPreviousQueueMessageId(this.aqm.originalMsgId);
            this.properties.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(this.aqm.aqmflg));
            if (this.aqm.aqmetiBytes != null) {
                this.properties.setTransactionGroup(this.meg.conv.CharBytesToString(this.aqm.aqmetiBytes, this.aqm.aqmetiBytes.length, true));
            }
        }
        final int n = (int)this.meg.unmarshalUB4();
        this.toh.unmarshal(this.meg);
        final int imageLength = this.toh.imageLength;
        if (imageLength > 0) {
            int a = imageLength;
            if (this.isRawQueue) {
                if (imageLength > 4) {
                    a -= 4;
                }
                final byte[] payload = new byte[Math.min(a, this.dequeueOptions.getMaximumBufferLength())];
                final int[] array = { 0 };
                if (imageLength > 4) {
                    this.meg.unmarshalCLR(payload, 0, array, payload.length, 4);
                }
                else {
                    this.meg.unmarshalCLR(payload, 0, array, payload.length);
                }
                this.payload = payload;
            }
            else {
                final byte[] payload2 = new byte[a];
                this.meg.unmarshalCLR(payload2, 0, new int[1], payload2.length);
                this.payload = payload2;
            }
        }
        if (this.dequeueOptions.getRetrieveMessageId()) {
            final byte[] dequeuedMessageId = new byte[16];
            this.meg.unmarshalBuffer(dequeuedMessageId, 0, 16);
            this.dequeuedMessageId = dequeuedMessageId;
        }
    }
    
    @Override
    void processError() throws SQLException {
        if (this.oer.retCode != 25228) {
            this.oer.processError();
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
