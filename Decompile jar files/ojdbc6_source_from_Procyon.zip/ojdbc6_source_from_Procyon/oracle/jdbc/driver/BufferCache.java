// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.lang.reflect.Array;
import java.lang.ref.SoftReference;

class BufferCache<T>
{
    private static final double ln2;
    private static final int BUFFERS_PER_BUCKET = 8;
    private static final int MIN_INDEX = 12;
    private final InternalStatistics stats;
    private final int[] bufferSize;
    private final SoftReference<T>[][] buckets;
    private final int[] top;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    BufferCache(final int n) {
        int n2;
        if (n < 31) {
            n2 = n;
        }
        else {
            n2 = (int)Math.ceil(Math.log(n) / BufferCache.ln2);
        }
        final int max = Math.max(0, n2 - 12 + 1);
        this.buckets = (SoftReference<T>[][])new SoftReference[max][8];
        this.top = new int[max];
        this.bufferSize = new int[max];
        int n3 = 4096;
        for (int i = 0; i < this.bufferSize.length; ++i) {
            this.bufferSize[i] = n3;
            n3 <<= 1;
        }
        this.stats = new InternalStatistics(this.bufferSize);
    }
    
    T get(final Class<?> clazz, final int length) {
        final int bufferIndex = this.bufferIndex(length);
        if (bufferIndex >= this.buckets.length) {
            this.stats.requestTooBig();
            return (T)Array.newInstance(clazz, length);
        }
        while (this.top[bufferIndex] > 0) {
            final SoftReference<T>[] array = this.buckets[bufferIndex];
            final int[] top = this.top;
            final int n = bufferIndex;
            final int n2 = top[n] - 1;
            top[n] = n2;
            final SoftReference<T> softReference = array[n2];
            this.buckets[bufferIndex][this.top[bufferIndex]] = null;
            final T value = softReference.get();
            if (value != null) {
                this.stats.cacheHit(bufferIndex);
                return value;
            }
        }
        this.stats.cacheMiss(bufferIndex);
        return (T)Array.newInstance(clazz, this.bufferSize[bufferIndex]);
    }
    
    void put(final T t) {
        final int length = Array.getLength(t);
        final int bufferIndex = this.bufferIndex(length);
        if (bufferIndex >= this.buckets.length || length != this.bufferSize[bufferIndex]) {
            this.stats.cacheTooBig();
            return;
        }
        if (this.top[bufferIndex] < 8) {
            this.stats.bufferCached(bufferIndex);
            this.buckets[bufferIndex][this.top[bufferIndex]++] = new SoftReference<T>(t);
        }
        else {
            int i = this.top[bufferIndex];
            while (i > 0) {
                if (this.buckets[bufferIndex][--i].get() == null) {
                    this.stats.refCleared(bufferIndex);
                    this.buckets[bufferIndex][i] = new SoftReference<T>(t);
                    return;
                }
            }
            this.stats.bucketFull(bufferIndex);
        }
    }
    
    OracleConnection.BufferCacheStatistics getStatistics() {
        return this.stats;
    }
    
    private int bufferIndex(final int n) {
        for (int i = 0; i < this.bufferSize.length; ++i) {
            if (n <= this.bufferSize[i]) {
                return i;
            }
        }
        return Integer.MAX_VALUE;
    }
    
    static {
        ln2 = Math.log(2.0);
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    private static final class InternalStatistics implements OracleConnection.BufferCacheStatistics
    {
        private static int CACHE_COUNT;
        private final int cacheId;
        private final int[] sizes;
        private final int[] nCacheHit;
        private final int[] nCacheMiss;
        private int nRequestTooBig;
        private final int[] nBufferCached;
        private final int[] nBucketFull;
        private final int[] nRefCleared;
        private int nCacheTooBig;
        
        InternalStatistics(final int[] sizes) {
            this.cacheId = ++InternalStatistics.CACHE_COUNT;
            this.sizes = sizes;
            final int length = sizes.length;
            this.nCacheHit = new int[length];
            this.nCacheMiss = new int[length];
            this.nRequestTooBig = 0;
            this.nBufferCached = new int[length];
            this.nBucketFull = new int[length];
            this.nRefCleared = new int[length];
            this.nCacheTooBig = 0;
        }
        
        void cacheHit(final int n) {
            final int[] nCacheHit = this.nCacheHit;
            ++nCacheHit[n];
        }
        
        void cacheMiss(final int n) {
            final int[] nCacheMiss = this.nCacheMiss;
            ++nCacheMiss[n];
        }
        
        void requestTooBig() {
            ++this.nRequestTooBig;
        }
        
        void bufferCached(final int n) {
            final int[] nBufferCached = this.nBufferCached;
            ++nBufferCached[n];
        }
        
        void bucketFull(final int n) {
            final int[] nBucketFull = this.nBucketFull;
            ++nBucketFull[n];
        }
        
        void refCleared(final int n) {
            final int[] nRefCleared = this.nRefCleared;
            ++nRefCleared[n];
        }
        
        void cacheTooBig() {
            ++this.nCacheTooBig;
        }
        
        @Override
        public int getId() {
            return this.cacheId;
        }
        
        @Override
        public int[] getBufferSizes() {
            final int[] array = new int[this.sizes.length];
            System.arraycopy(this.sizes, 0, array, 0, this.sizes.length);
            return array;
        }
        
        @Override
        public int getCacheHits(final int n) {
            return this.nCacheHit[n];
        }
        
        @Override
        public int getCacheMisses(final int n) {
            return this.nCacheMiss[n];
        }
        
        public int getRequestsTooBig() {
            return this.nRequestTooBig;
        }
        
        @Override
        public int getBuffersCached(final int n) {
            return this.nBufferCached[n];
        }
        
        @Override
        public int getBucketsFull(final int n) {
            return this.nBucketFull[n];
        }
        
        @Override
        public int getReferencesCleared(final int n) {
            return this.nRefCleared[n];
        }
        
        @Override
        public int getTooBigToCache() {
            return this.nCacheTooBig;
        }
        
        @Override
        public String toString() {
            int i = 0;
            int n = 0;
            int j = 0;
            int n2 = 0;
            int k = 0;
            for (int l = 0; l < this.sizes.length; ++l) {
                i += this.nCacheHit[l];
                n += this.nCacheMiss[l];
                j += this.nBufferCached[l];
                n2 += this.nBucketFull[l];
                k += this.nRefCleared[l];
            }
            return "oracle.jdbc.driver.BufferCache<" + this.cacheId + ">\n" + "\tTotal Hits   :\t" + i + "\n" + "\tTotal Misses :\t" + (n + this.nRequestTooBig) + "\n" + "\tTotal Cached :\t" + j + "\n" + "\tTotal Dropped:\t" + (n2 + this.nCacheTooBig) + "\n" + "\tTotal Cleared:\t" + k + "\n";
        }
        
        static {
            InternalStatistics.CACHE_COUNT = 0;
        }
    }
}
