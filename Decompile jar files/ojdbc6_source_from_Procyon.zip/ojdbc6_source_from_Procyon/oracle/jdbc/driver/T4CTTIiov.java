// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.oracore.OracleTypeADT;
import java.io.InputStream;
import java.io.IOException;
import java.sql.SQLException;

class T4CTTIiov extends T4CTTIMsg
{
    T4C8TTIrxh rxh;
    T4CTTIrxd rxd;
    byte bindtype;
    byte[] iovector;
    int bindcnt;
    int inbinds;
    int outbinds;
    static final byte BV_IN_V = 32;
    static final byte BV_OUT_V = 16;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIiov(final T4CConnection t4CConnection, final T4C8TTIrxh rxh, final T4CTTIrxd rxd) throws SQLException, IOException {
        super(t4CConnection, (byte)0);
        this.bindtype = 0;
        this.bindcnt = 0;
        this.inbinds = 0;
        this.outbinds = 0;
        this.rxh = rxh;
        this.rxd = rxd;
    }
    
    void init() throws SQLException, IOException {
    }
    
    Accessor[] processRXD(Accessor[] array, final int n, final byte[] array2, final char[] array3, final short[] array4, final int n2, final DBConversion dbConversion, final byte[] array5, final byte[] array6, final InputStream[][] array7, final byte[][][] array8, final OracleTypeADT[][] array9, final OracleStatement oracleStatement, final byte[] array10, final char[] array11, final short[] array12) throws SQLException, IOException {
        if (array6 != null) {
            for (int i = 0; i < array6.length; ++i) {
                if ((array6[i] & 0x10) != 0x0 && (array == null || array.length <= i || array[i] == null)) {
                    int n3 = array4[n2 + 5 + 10 * i + 0] & 0xFFFF;
                    final int n4;
                    if ((n4 = n3) == 9) {
                        n3 = 1;
                    }
                    final Accessor allocateAccessor = oracleStatement.allocateAccessor(n3, n3, i, 0, (short)0, null, false);
                    allocateAccessor.rowSpaceIndicator = null;
                    if (allocateAccessor.defineType == 109 || allocateAccessor.defineType == 111) {
                        allocateAccessor.setOffsets(1);
                    }
                    if (array == null) {
                        array = new Accessor[i + 1];
                        array[i] = allocateAccessor;
                    }
                    else if (array.length <= i) {
                        final Accessor[] array13 = new Accessor[i + 1];
                        array13[i] = allocateAccessor;
                        for (int j = 0; j < array.length; ++j) {
                            if (array[j] != null) {
                                array13[j] = array[j];
                            }
                        }
                        array = array13;
                    }
                    else {
                        array[i] = allocateAccessor;
                    }
                }
                else if ((array6[i] & 0x10) == 0x0 && array != null && i < array.length && array[i] != null) {
                    array[i].isUseLess = true;
                }
            }
        }
        return array;
    }
    
    void unmarshalV10() throws IOException, SQLException {
        this.rxh.unmarshalV10(this.rxd);
        this.bindcnt = this.rxh.numRqsts;
        this.iovector = new byte[this.connection.all8.numberOfBindPositions];
        for (int i = 0; i < this.iovector.length; ++i) {
            if ((this.bindtype = this.meg.unmarshalSB1()) == 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if ((this.bindtype & 0x20) > 0) {
                final byte[] iovector = this.iovector;
                final int n = i;
                iovector[n] |= 0x20;
                ++this.inbinds;
            }
            if ((this.bindtype & 0x10) > 0) {
                final byte[] iovector2 = this.iovector;
                final int n2 = i;
                iovector2[n2] |= 0x10;
                ++this.outbinds;
            }
        }
    }
    
    byte[] getIOVector() {
        return this.iovector;
    }
    
    boolean isIOVectorEmpty() {
        return this.iovector.length == 0;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
