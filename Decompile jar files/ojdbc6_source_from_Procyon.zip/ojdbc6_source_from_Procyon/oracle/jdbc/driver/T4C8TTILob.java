// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.Datum;
import java.sql.Connection;
import java.io.IOException;
import java.sql.SQLException;

abstract class T4C8TTILob extends T4CTTIfun
{
    static final int KPLOB_READ = 2;
    static final int KPLOB_WRITE = 64;
    static final int KPLOB_WRITE_APPEND = 8192;
    static final int KPLOB_PAGE_SIZE = 16384;
    static final int KPLOB_FILE_OPEN = 256;
    static final int KPLOB_FILE_ISOPEN = 1024;
    static final int KPLOB_FILE_EXISTS = 2048;
    static final int KPLOB_FILE_CLOSE = 512;
    static final int KPLOB_OPEN = 32768;
    static final int KPLOB_CLOSE = 65536;
    static final int KPLOB_ISOPEN = 69632;
    static final int KPLOB_TMP_CREATE = 272;
    static final int KPLOB_TMP_FREE = 273;
    static final int KPLOB_GET_LEN = 1;
    static final int KPLOB_TRIM = 32;
    static final int KOKL_ORDONLY = 1;
    static final int KOKL_ORDWR = 2;
    static final int KOLF_ORDONLY = 11;
    static final int DTYCLOB = 112;
    static final int DTYBLOB = 113;
    byte[] sourceLobLocator;
    byte[] destinationLobLocator;
    long sourceOffset;
    long destinationOffset;
    int destinationLength;
    short characterSet;
    long lobamt;
    boolean lobnull;
    long lobops;
    int[] lobscn;
    int lobscnl;
    boolean nullO2U;
    boolean sendLobamt;
    byte[] inBuffer;
    long inBufferOffset;
    long inBufferNumBytes;
    byte[] outBuffer;
    int offsetInOutBuffer;
    int rowsProcessed;
    long lobBytesRead;
    boolean varWidthChar;
    boolean littleEndianClob;
    T4C8TTILobd lobd;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8TTILob(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.sourceLobLocator = null;
        this.destinationLobLocator = null;
        this.sourceOffset = 0L;
        this.destinationOffset = 0L;
        this.destinationLength = 0;
        this.characterSet = 0;
        this.lobamt = 0L;
        this.lobnull = false;
        this.lobops = 0L;
        this.lobscn = null;
        this.lobscnl = 0;
        this.nullO2U = false;
        this.sendLobamt = false;
        this.inBuffer = null;
        this.outBuffer = null;
        this.offsetInOutBuffer = 0;
        this.rowsProcessed = 0;
        this.lobBytesRead = 0L;
        this.varWidthChar = false;
        this.littleEndianClob = false;
        this.lobd = null;
        this.setFunCode((short)96);
        this.lobd = new T4C8TTILobd(t4CConnection);
    }
    
    long read(final byte[] sourceLobLocator, final long sourceOffset, final long lobamt, final byte[] outBuffer, final int offsetInOutBuffer) throws SQLException, IOException {
        this.initializeLobdef();
        this.lobops = 2L;
        this.sourceLobLocator = sourceLobLocator;
        this.sourceOffset = sourceOffset;
        this.lobamt = lobamt;
        this.sendLobamt = true;
        this.outBuffer = outBuffer;
        this.offsetInOutBuffer = offsetInOutBuffer;
        this.doRPC();
        return this.lobBytesRead;
    }
    
    long write(final byte[] sourceLobLocator, final long sourceOffset, final byte[] inBuffer, final long inBufferOffset, final long n) throws SQLException, IOException {
        this.initializeLobdef();
        this.lobops = 64L;
        this.sourceLobLocator = sourceLobLocator;
        this.sourceOffset = sourceOffset;
        this.lobamt = n;
        this.sendLobamt = true;
        this.inBuffer = inBuffer;
        this.inBufferOffset = inBufferOffset;
        this.inBufferNumBytes = n;
        this.doRPC();
        return this.lobamt;
    }
    
    long getLength(final byte[] sourceLobLocator) throws SQLException, IOException {
        this.initializeLobdef();
        this.lobops = 1L;
        this.sourceLobLocator = sourceLobLocator;
        this.sendLobamt = true;
        this.doRPC();
        return this.lobamt;
    }
    
    long getChunkSize(final byte[] sourceLobLocator) throws SQLException, IOException {
        this.initializeLobdef();
        this.lobops = 16384L;
        this.sourceLobLocator = sourceLobLocator;
        this.sendLobamt = true;
        this.doRPC();
        return this.lobamt;
    }
    
    long trim(final byte[] sourceLobLocator, final long lobamt) throws SQLException, IOException {
        this.initializeLobdef();
        this.lobops = 32L;
        this.sourceLobLocator = sourceLobLocator;
        this.lobamt = lobamt;
        this.sendLobamt = true;
        this.doRPC();
        return this.lobamt;
    }
    
    abstract Datum createTemporaryLob(final Connection p0, final boolean p1, final int p2) throws SQLException, IOException;
    
    void freeTemporaryLob(final byte[] sourceLobLocator) throws SQLException, IOException {
        this.initializeLobdef();
        this.lobops = 273L;
        this.sourceLobLocator = sourceLobLocator;
        this.doRPC();
    }
    
    abstract boolean open(final byte[] p0, final int p1) throws SQLException, IOException;
    
    boolean _open(final byte[] sourceLobLocator, final int n, final int n2) throws SQLException, IOException {
        boolean b = false;
        if ((sourceLobLocator[7] & 0x1) == 0x1 || (sourceLobLocator[4] & 0x40) == 0x40) {
            if ((sourceLobLocator[7] & 0x8) == 0x8) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 445);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int n3 = 7;
            sourceLobLocator[n3] |= 0x8;
            if (n == 2) {
                final int n4 = 7;
                sourceLobLocator[n4] |= 0x10;
            }
            b = true;
        }
        else {
            this.initializeLobdef();
            this.sourceLobLocator = sourceLobLocator;
            this.lobops = n2;
            this.lobamt = n;
            this.sendLobamt = true;
            this.doRPC();
            if (this.lobamt != 0L) {
                b = true;
            }
        }
        return b;
    }
    
    abstract boolean close(final byte[] p0) throws SQLException, IOException;
    
    boolean _close(final byte[] sourceLobLocator, final int n) throws SQLException, IOException {
        final boolean b = true;
        if ((sourceLobLocator[7] & 0x1) == 0x1 || (sourceLobLocator[4] & 0x40) == 0x40) {
            if ((sourceLobLocator[7] & 0x8) != 0x8) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 446);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int n2 = 7;
            sourceLobLocator[n2] &= 0xFFFFFFE7;
        }
        else {
            this.initializeLobdef();
            this.sourceLobLocator = sourceLobLocator;
            this.lobops = n;
            this.doRPC();
        }
        return b;
    }
    
    abstract boolean isOpen(final byte[] p0) throws SQLException, IOException;
    
    boolean _isOpen(final byte[] sourceLobLocator, final int n) throws SQLException, IOException {
        boolean lobnull = false;
        if ((sourceLobLocator[7] & 0x1) == 0x1 || (sourceLobLocator[4] & 0x40) == 0x40) {
            if ((sourceLobLocator[7] & 0x8) == 0x8) {
                lobnull = true;
            }
        }
        else {
            this.initializeLobdef();
            this.sourceLobLocator = sourceLobLocator;
            this.lobops = n;
            this.nullO2U = true;
            this.doRPC();
            lobnull = this.lobnull;
        }
        return lobnull;
    }
    
    void initializeLobdef() {
        this.sourceLobLocator = null;
        this.destinationLobLocator = null;
        this.sourceOffset = 0L;
        this.destinationOffset = 0L;
        this.destinationLength = 0;
        this.characterSet = 0;
        this.lobamt = 0L;
        this.lobnull = false;
        this.lobops = 0L;
        this.lobscn = null;
        this.lobscnl = 0;
        this.inBuffer = null;
        this.outBuffer = null;
        this.nullO2U = false;
        this.sendLobamt = false;
        this.varWidthChar = false;
        this.littleEndianClob = false;
        this.lobBytesRead = 0L;
    }
    
    @Override
    void marshal() throws IOException {
        int length = 0;
        if (this.sourceLobLocator != null) {
            length = this.sourceLobLocator.length;
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        this.meg.marshalSB4(length);
        if (this.destinationLobLocator != null) {
            this.destinationLength = this.destinationLobLocator.length;
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        this.meg.marshalSB4(this.destinationLength);
        if (this.connection.getTTCVersion() >= 3) {
            this.meg.marshalUB4(0L);
        }
        else {
            this.meg.marshalUB4(this.sourceOffset);
        }
        if (this.connection.getTTCVersion() >= 3) {
            this.meg.marshalUB4(0L);
        }
        else {
            this.meg.marshalUB4(this.destinationOffset);
        }
        if (this.characterSet != 0) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        if (this.sendLobamt && this.connection.getTTCVersion() < 3) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        if (this.nullO2U) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        this.meg.marshalUB4(this.lobops);
        if (this.lobscnl != 0) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        this.meg.marshalSB4(this.lobscnl);
        if (this.connection.getTTCVersion() >= 3) {
            this.meg.marshalSB8(this.sourceOffset);
            this.meg.marshalSB8(this.destinationOffset);
            if (this.sendLobamt) {
                this.meg.marshalPTR();
            }
            else {
                this.meg.marshalNULLPTR();
            }
            if (this.connection.getTTCVersion() >= 4) {
                this.meg.marshalNULLPTR();
                this.meg.marshalSWORD(0);
                this.meg.marshalNULLPTR();
                this.meg.marshalSWORD(0);
                this.meg.marshalNULLPTR();
                this.meg.marshalSWORD(0);
            }
        }
        if (this.sourceLobLocator != null) {
            this.meg.marshalB1Array(this.sourceLobLocator);
        }
        if (this.destinationLobLocator != null) {
            this.meg.marshalB1Array(this.destinationLobLocator);
        }
        if (this.characterSet != 0) {
            this.meg.marshalUB2(this.characterSet);
        }
        if (this.sendLobamt && this.connection.getTTCVersion() < 3) {
            this.meg.marshalUB4(this.lobamt);
        }
        if (this.lobscnl != 0) {
            for (int i = 0; i < this.lobscnl; ++i) {
                this.meg.marshalUB4(this.lobscn[i]);
            }
        }
        if (this.sendLobamt && this.connection.getTTCVersion() >= 3) {
            this.meg.marshalSB8(this.lobamt);
        }
        if (this.lobops == 64L) {
            this.marshalData();
        }
    }
    
    void marshalData() throws IOException {
        final boolean b = this.connection.isZeroCopyIOEnabled() & (this.sourceLobLocator[7] & 0xFFFFFF80) != 0x0;
        if (this.connection.versionNumber < 10101 && this.varWidthChar) {
            this.lobd.marshalClobUB2_For9iDB(this.inBuffer, this.inBufferOffset, this.inBufferNumBytes);
        }
        else {
            this.lobd.marshalLobData(this.inBuffer, this.inBufferOffset, this.inBufferNumBytes, b);
        }
    }
    
    @Override
    void readLOBD() throws IOException, SQLException {
        final boolean b = this.connection.isZeroCopyIOEnabled() & (this.sourceLobLocator[7] & 0xFFFFFF80) != 0x0;
        if (this.connection.versionNumber < 10101 && this.varWidthChar) {
            this.lobBytesRead = this.lobd.unmarshalClobUB2_For9iDB(this.outBuffer, this.offsetInOutBuffer);
        }
        else {
            this.lobBytesRead = this.lobd.unmarshalLobData(this.outBuffer, this.offsetInOutBuffer, b);
        }
    }
    
    @Override
    void processError() throws SQLException {
        this.rowsProcessed = this.oer.getCurRowNumber();
        if (this.oer.getRetCode() != 1403) {
            this.oer.processError();
        }
    }
    
    @Override
    void readRPA() throws SQLException, IOException {
        if (this.sourceLobLocator != null) {
            this.meg.getNBytes(this.sourceLobLocator, 0, this.sourceLobLocator.length);
        }
        if (this.destinationLobLocator != null) {
            this.destinationLobLocator = this.meg.unmarshalNBytes(this.meg.unmarshalSB2());
        }
        if (this.characterSet != 0) {
            this.characterSet = this.meg.unmarshalSB2();
        }
        if (this.sendLobamt) {
            if (this.connection.getTTCVersion() >= 3) {
                this.lobamt = this.meg.unmarshalSB8();
            }
            else {
                this.lobamt = this.meg.unmarshalUB4();
            }
        }
        if (this.nullO2U && this.meg.unmarshalSB2() != 0) {
            this.lobnull = true;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
