// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.net.ns.BreakNetException;
import oracle.net.ns.NetException;
import java.io.IOException;
import oracle.net.ns.NetOutputStream;
import java.io.OutputStream;

class T4CSocketOutputStreamWrapper extends OutputStream
{
    static final int MAX_BUFFER_SIZE = 2048;
    NetOutputStream os;
    byte[] buffer;
    int bIndex;
    
    T4CSocketOutputStreamWrapper(final NetOutputStream os) throws IOException {
        this.os = null;
        this.buffer = new byte[2048];
        this.bIndex = 0;
        this.os = os;
    }
    
    @Override
    public void write(final int n) throws IOException {
        if (this.bIndex + 1 >= 2048) {
            this.flush();
        }
        this.buffer[this.bIndex++] = (byte)(n & 0xFF);
    }
    
    @Override
    public void write(final byte[] array, final int n, final int n2) throws IOException {
        if (n2 > 2048) {
            this.flush();
            this.os.write(array, n, n2);
        }
        else if (this.bIndex + n2 < 2048) {
            System.arraycopy(array, n, this.buffer, this.bIndex, n2);
            this.bIndex += n2;
        }
        else {
            this.flush();
            System.arraycopy(array, n, this.buffer, this.bIndex, n2);
            this.bIndex += n2;
        }
    }
    
    @Override
    public void flush() throws IOException {
        this.flush(false);
    }
    
    public void flush(final boolean b) throws IOException {
        if (this.bIndex > 0) {
            this.os.write(this.buffer, 0, this.bIndex);
            this.bIndex = 0;
        }
        if (b) {
            this.os.flush();
        }
    }
    
    @Override
    public void close() throws IOException {
        this.os.close();
        super.close();
    }
    
    public void writeZeroCopyIO(final byte[] array, final int n, final int n2) throws IOException, NetException, BreakNetException {
        this.flush(true);
        this.os.writeZeroCopyIO(array, n, n2);
    }
}
