// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.CLOB;

class OracleClobInputStream extends OracleBufferedStream
{
    protected long lobOffset;
    protected CLOB clob;
    protected long markedByte;
    protected boolean endOfStream;
    protected char[] charBuf;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleClobInputStream(final CLOB clob) throws SQLException {
        this(clob, ((PhysicalConnection)clob.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
    }
    
    public OracleClobInputStream(final CLOB clob, final int n) throws SQLException {
        this(clob, n, 1L);
    }
    
    public OracleClobInputStream(final CLOB clob, final int n, final long lobOffset) throws SQLException {
        super(n);
        if (clob == null || n <= 0 || lobOffset < 1L) {
            throw new IllegalArgumentException();
        }
        this.lobOffset = lobOffset;
        this.clob = clob;
        this.markedByte = -1L;
        this.endOfStream = false;
    }
    
    @Override
    public boolean needBytes(final int a) throws IOException {
        this.ensureOpen();
        if (this.pos >= this.count) {
            if (!this.endOfStream) {
                try {
                    if (a > this.currentBufferSize) {
                        this.currentBufferSize = Math.max(a, this.initialBufferSize);
                        final PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
                        synchronized (physicalConnection) {
                            this.resizableBuffer = physicalConnection.getByteBuffer(this.currentBufferSize);
                            this.charBuf = physicalConnection.getCharBuffer(this.currentBufferSize);
                        }
                    }
                    this.count = this.clob.getChars(this.lobOffset, this.currentBufferSize, this.charBuf);
                    for (int i = 0; i < this.count; ++i) {
                        this.resizableBuffer[i] = (byte)this.charBuf[i];
                    }
                    if (this.count < this.currentBufferSize) {
                        this.endOfStream = true;
                    }
                    if (this.count > 0) {
                        this.pos = 0;
                        this.lobOffset += this.count;
                        return true;
                    }
                }
                catch (SQLException ex) {
                    final IOException ioException = DatabaseError.createIOException(ex);
                    ioException.fillInStackTrace();
                    throw ioException;
                }
            }
            return false;
        }
        return true;
    }
    
    protected void ensureOpen() throws IOException {
        try {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 57, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    @Override
    public void mark(final int n) {
        if (n < 0) {
            throw new IllegalArgumentException(DatabaseError.findMessage(196, null));
        }
        this.markedByte = this.lobOffset - this.count + this.pos;
    }
    
    public void markInternal(final int n) {
    }
    
    @Override
    public void reset() throws IOException {
        this.ensureOpen();
        if (this.markedByte < 0L) {
            throw new IOException(DatabaseError.findMessage(195, null));
        }
        this.lobOffset = this.markedByte;
        this.pos = this.count;
        this.endOfStream = false;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        this.ensureOpen();
        final long n2 = 0L;
        long n3;
        if (this.count - this.pos >= n) {
            this.pos += (int)n;
            n3 = n2 + n;
        }
        else {
            final long n4 = n2 + (this.count - this.pos);
            this.pos = this.count;
            try {
                final long n5 = this.clob.length() - this.lobOffset + 1L;
                if (n5 >= n - n4) {
                    this.lobOffset += n - n4;
                    n3 = n4 + (n - n4);
                }
                else {
                    this.lobOffset += n5;
                    n3 = n4 + n5;
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
        return n3;
    }
    
    @Override
    public void close() throws IOException {
        if (this.closed) {
            return;
        }
        try {
            super.close();
        }
        finally {
            try {
                final PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
                synchronized (physicalConnection) {
                    if (this.charBuf != null) {
                        physicalConnection.cacheBuffer(this.charBuf);
                        this.charBuf = null;
                    }
                    if (this.resizableBuffer != null) {
                        physicalConnection.cacheBuffer(this.resizableBuffer);
                        this.resizableBuffer = null;
                    }
                    this.currentBufferSize = 0;
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        try {
            return this.clob.getInternalConnection();
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
