// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Arrays;
import java.sql.ClientInfoStatus;
import java.util.HashMap;
import java.util.Iterator;
import java.sql.SQLClientInfoException;
import java.util.Properties;
import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.List;
import oracle.jdbc.internal.ClientDataSupport;
import oracle.jdbc.OracleConnectionWrapper;

public abstract class OracleConnection extends OracleConnectionWrapper implements oracle.jdbc.internal.OracleConnection, ClientDataSupport
{
    static int DEFAULT_ROW_PREFETCH;
    static final String svptPrefix = "ORACLE_SVPT_";
    static final int BINARYSTREAM = 0;
    static final int ASCIISTREAM = 1;
    static final int UNICODESTREAM = 2;
    static final int EOJ_NON = 0;
    static final int EOJ_B_TO_A = 1;
    static final int EOJ_B_TO_U = 2;
    static final int EOJ_A_TO_U = 3;
    static final int EOJ_8_TO_A = 4;
    static final int EOJ_8_TO_U = 5;
    static final int EOJ_U_TO_A = 6;
    static final int ASCII_CHARSET = 0;
    static final int NLS_CHARSET = 1;
    static final int CHAR_TO_ASCII = 0;
    static final int CHAR_TO_UNICODE = 1;
    static final int RAW_TO_ASCII = 2;
    static final int RAW_TO_UNICODE = 3;
    static final int UNICODE_TO_CHAR = 4;
    static final int ASCII_TO_CHAR = 5;
    static final int NONE = 6;
    static final int JAVACHAR_TO_CHAR = 7;
    static final int RAW_TO_JAVACHAR = 8;
    static final int CHAR_TO_JAVACHAR = 9;
    static final int JAVACHAR_TO_ASCII = 10;
    static final int JAVACHAR_TO_UNICODE = 11;
    static final int UNICODE_TO_ASCII = 12;
    public static final int KOLBLLENB = 0;
    public static final int KOLBLVSNB = 2;
    public static final byte KOLL1FLG = 4;
    public static final byte KOLL2FLG = 5;
    public static final byte KOLL3FLG = 6;
    public static final byte KOLL4FLG = 7;
    public static final int KOLBLCIDB = 32;
    static final byte ALLFLAGS = -1;
    public static final int KOLBLIMRLL = 86;
    public static final byte KOLBLBLOB = 1;
    public static final byte KOLBLCLOB = 2;
    public static final byte KOLBLNLOB = 4;
    public static final byte KOLBLBFIL = 8;
    public static final byte KOLBLCFIL = 16;
    public static final byte KOLBLNFIL = 32;
    public static final byte KOLBLABS = 64;
    public static final byte KOLBLPXY = Byte.MIN_VALUE;
    public static final byte KOLBLPKEY = 1;
    public static final byte KOLBLIMP = 2;
    public static final byte KOLBLIDX = 4;
    public static final byte KOLBLINI = 8;
    public static final byte KOLBLEMP = 16;
    public static final byte KOLBLVIEW = 32;
    public static final byte KOLBL0FRM = 64;
    public static final byte KOLBL1FRM = Byte.MIN_VALUE;
    public static final byte KOLBLRDO = 1;
    public static final byte KOLBLPART = 2;
    public static final byte KOLBLCPD = 4;
    public static final byte KOLBLDIL = 8;
    public static final byte KOLBLBUF = 16;
    public static final byte KOLBLBPS = 32;
    public static final byte KOLBLMOD = 64;
    public static final byte KOLBLVAR = Byte.MIN_VALUE;
    public static final byte KOLBLTMP = 1;
    public static final byte KOLBLCACHE = 2;
    public static final byte KOLBLOPEN = 8;
    public static final byte KOLBLRDWR = 16;
    public static final byte KOLBLCLI = 32;
    public static final byte KOLBLVLE = 64;
    public static final byte KOLBLLCL = Byte.MIN_VALUE;
    static final List<String> RESERVED_NAMESPACES;
    static final Pattern SUPPORTED_NAMESPACE_PATTERN;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static boolean containsKey(final Map map, final Object o) {
        return map.get(o) != null;
    }
    
    @Override
    public abstract Object getClientData(final Object p0);
    
    @Override
    public abstract Object setClientData(final Object p0, final Object p1);
    
    @Override
    public abstract Object removeClientData(final Object p0);
    
    @Deprecated
    public abstract void setClientIdentifier(final String p0) throws SQLException;
    
    @Deprecated
    public abstract void clearClientIdentifier(final String p0) throws SQLException;
    
    @Override
    public boolean isValid(final int n) throws SQLException {
        return this.pingDatabase(n) == 0;
    }
    
    @Override
    public void setClientInfo(final String s, final String s2) throws SQLClientInfoException {
        this.setClientInfoInternal(s, s2, null);
    }
    
    @Override
    public void setClientInfo(final Properties properties) throws SQLClientInfoException {
        final Properties properties2 = (Properties)properties.clone();
        for (final String s : properties.stringPropertyNames()) {
            this.setClientInfoInternal(s, properties.getProperty(s), properties2);
            properties2.remove(s);
        }
    }
    
    void setClientInfoInternal(final String s, final String s2, final Properties properties) throws SQLClientInfoException {
        final HashMap<String, ClientInfoStatus> hashMap = new HashMap<String, ClientInfoStatus>();
        if (properties != null) {
            final Iterator<String> iterator = properties.stringPropertyNames().iterator();
            while (iterator.hasNext()) {
                hashMap.put(iterator.next(), ClientInfoStatus.REASON_UNKNOWN);
            }
        }
        final SQLClientInfoException sqlClientInfoException = DatabaseError.createSQLClientInfoException(253, hashMap, null);
        sqlClientInfoException.fillInStackTrace();
        throw sqlClientInfoException;
    }
    
    @Override
    public String getClientInfo(final String s) throws SQLException {
        if (this.isClosed()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return null;
    }
    
    @Override
    public Properties getClientInfo() throws SQLException {
        if (this.isClosed()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new Properties();
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return this;
    }
    
    @Override
    public Class getClassForType(final String s, final Map<String, Class> map) {
        Class value = map.get(s);
        if (value == null) {
            final ClassRef classRef = OracleDriver.systemTypeMap.get(s);
            if (classRef != null) {
                value = classRef.get();
            }
        }
        return value;
    }
    
    static {
        OracleConnection.DEFAULT_ROW_PREFETCH = 10;
        RESERVED_NAMESPACES = Arrays.asList("SYS");
        SUPPORTED_NAMESPACE_PATTERN = Pattern.compile("CLIENTCONTEXT");
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
