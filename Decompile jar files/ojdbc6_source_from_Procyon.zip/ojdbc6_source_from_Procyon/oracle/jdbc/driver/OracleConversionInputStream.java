// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import java.io.IOException;
import java.io.Reader;
import java.io.InputStream;

class OracleConversionInputStream extends OracleBufferedStream
{
    static final int CHUNK_SIZE = 4096;
    DBConversion converter;
    int conversion;
    InputStream istream;
    Reader reader;
    byte[] convbuf;
    char[] javaChars;
    int maxSize;
    int totalSize;
    int numUnconvertedBytes;
    boolean endOfStream;
    private short csform;
    int[] nbytes;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConversionInputStream(final DBConversion dbConversion, final InputStream inputStream, final int n) {
        this(dbConversion, inputStream, n, (short)1);
    }
    
    public OracleConversionInputStream(final DBConversion converter, final InputStream istream, final int conversion, final short csform) {
        super(4096);
        this.istream = istream;
        this.conversion = conversion;
        this.converter = converter;
        this.maxSize = 0;
        this.totalSize = 0;
        this.numUnconvertedBytes = 0;
        this.endOfStream = false;
        this.nbytes = new int[1];
        this.csform = csform;
        this.currentBufferSize = this.initialBufferSize;
        this.resizableBuffer = new byte[this.currentBufferSize];
        switch (conversion) {
            case 0: {
                this.javaChars = new char[4096];
                this.convbuf = new byte[4096];
                break;
            }
            case 1: {
                this.convbuf = new byte[2048];
                this.javaChars = new char[2048];
                break;
            }
            case 2: {
                this.convbuf = new byte[2048];
                this.javaChars = new char[4096];
                break;
            }
            case 3: {
                this.convbuf = new byte[1024];
                this.javaChars = new char[2048];
                break;
            }
            case 4: {
                final int n = 4096 / this.converter.getMaxCharbyteSize();
                this.convbuf = new byte[n * 2];
                this.javaChars = new char[n];
                break;
            }
            case 5: {
                if (this.converter.isUcs2CharSet()) {
                    this.convbuf = new byte[2048];
                    this.javaChars = new char[2048];
                    break;
                }
                this.convbuf = new byte[4096];
                this.javaChars = new char[4096];
                break;
            }
            case 7: {
                this.javaChars = new char[4096 / ((csform == 2) ? this.converter.getMaxNCharbyteSize() : this.converter.getMaxCharbyteSize())];
                break;
            }
            default: {
                this.convbuf = new byte[4096];
                this.javaChars = new char[4096];
                break;
            }
        }
    }
    
    public OracleConversionInputStream(final DBConversion dbConversion, final InputStream inputStream, final int n, final int maxSize) {
        this(dbConversion, inputStream, n, (short)1);
        this.maxSize = maxSize;
        this.totalSize = 0;
    }
    
    public OracleConversionInputStream(final DBConversion dbConversion, final Reader reader, final int n, final int maxSize, final short n2) {
        this(dbConversion, null, n, n2);
        this.reader = reader;
        this.maxSize = maxSize;
        this.totalSize = 0;
    }
    
    public void setFormOfUse(final short csform) {
        this.csform = csform;
    }
    
    @Override
    public boolean needBytes(final int n) throws IOException {
        return this.needBytes();
    }
    
    @Override
    public boolean needBytes() throws IOException {
        if (this.closed) {
            return false;
        }
        if (this.pos < this.count) {
            return true;
        }
        if (this.istream != null) {
            return this.needBytesFromStream();
        }
        return this.reader != null && this.needBytesFromReader();
    }
    
    public boolean needBytesFromReader() throws IOException {
        try {
            int n;
            if (this.maxSize == 0) {
                n = this.javaChars.length;
            }
            else {
                n = Math.min(this.maxSize - this.totalSize, this.javaChars.length);
            }
            if (n <= 0) {
                return false;
            }
            final int read = this.reader.read(this.javaChars, 0, n);
            if (read == -1) {
                return false;
            }
            this.totalSize += read;
            switch (this.conversion) {
                case 7: {
                    if (this.csform == 2) {
                        this.count = this.converter.javaCharsToNCHARBytes(this.javaChars, read, this.resizableBuffer);
                        break;
                    }
                    this.count = this.converter.javaCharsToCHARBytes(this.javaChars, read, this.resizableBuffer);
                    break;
                }
                default: {
                    System.arraycopy(this.convbuf, 0, this.resizableBuffer, 0, read);
                    this.count = read;
                    break;
                }
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
        this.pos = 0;
        return true;
    }
    
    public boolean needBytesFromStream() throws IOException {
        if (!this.endOfStream) {
            try {
                int n;
                if (this.maxSize == 0) {
                    n = this.convbuf.length;
                }
                else {
                    n = Math.min(this.maxSize - this.totalSize, this.convbuf.length);
                }
                int read = 0;
                if (n <= 0) {
                    this.endOfStream = true;
                    this.istream.close();
                    if (this.numUnconvertedBytes != 0) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 55);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                }
                else {
                    read = this.istream.read(this.convbuf, this.numUnconvertedBytes, n - this.numUnconvertedBytes);
                }
                if (read == -1) {
                    this.endOfStream = true;
                    this.istream.close();
                    if (this.numUnconvertedBytes != 0) {
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 55);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                }
                else {
                    read += this.numUnconvertedBytes;
                    this.totalSize += read;
                }
                if (read <= 0) {
                    return false;
                }
                switch (this.conversion) {
                    case 0: {
                        this.nbytes[0] = read;
                        final int charBytesToJavaChars = this.converter.CHARBytesToJavaChars(this.convbuf, 0, this.javaChars, 0, this.nbytes, this.javaChars.length);
                        this.numUnconvertedBytes = this.nbytes[0];
                        for (int i = 0; i < this.numUnconvertedBytes; ++i) {
                            this.convbuf[i] = this.convbuf[read - this.numUnconvertedBytes];
                        }
                        final DBConversion converter = this.converter;
                        this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, charBytesToJavaChars, this.resizableBuffer);
                        break;
                    }
                    case 1: {
                        this.nbytes[0] = read;
                        final int charBytesToJavaChars2 = this.converter.CHARBytesToJavaChars(this.convbuf, 0, this.javaChars, 0, this.nbytes, this.javaChars.length);
                        this.numUnconvertedBytes = this.nbytes[0];
                        for (int j = 0; j < this.numUnconvertedBytes; ++j) {
                            this.convbuf[j] = this.convbuf[read - this.numUnconvertedBytes];
                        }
                        final DBConversion converter2 = this.converter;
                        this.count = DBConversion.javaCharsToUcs2Bytes(this.javaChars, charBytesToJavaChars2, this.resizableBuffer);
                        break;
                    }
                    case 2: {
                        final DBConversion converter3 = this.converter;
                        final int rawBytesToHexChars = DBConversion.RAWBytesToHexChars(this.convbuf, read, this.javaChars);
                        final DBConversion converter4 = this.converter;
                        this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, rawBytesToHexChars, this.resizableBuffer);
                        break;
                    }
                    case 3: {
                        final DBConversion converter5 = this.converter;
                        final int rawBytesToHexChars2 = DBConversion.RAWBytesToHexChars(this.convbuf, read, this.javaChars);
                        final DBConversion converter6 = this.converter;
                        this.count = DBConversion.javaCharsToUcs2Bytes(this.javaChars, rawBytesToHexChars2, this.resizableBuffer);
                        break;
                    }
                    case 4: {
                        final DBConversion converter7 = this.converter;
                        this.count = this.converter.javaCharsToCHARBytes(this.javaChars, DBConversion.ucs2BytesToJavaChars(this.convbuf, read, this.javaChars), this.resizableBuffer);
                        break;
                    }
                    case 12: {
                        final DBConversion converter8 = this.converter;
                        final int ucs2BytesToJavaChars = DBConversion.ucs2BytesToJavaChars(this.convbuf, read, this.javaChars);
                        final DBConversion converter9 = this.converter;
                        this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, ucs2BytesToJavaChars, this.resizableBuffer);
                        break;
                    }
                    case 5: {
                        final DBConversion converter10 = this.converter;
                        DBConversion.asciiBytesToJavaChars(this.convbuf, read, this.javaChars);
                        this.count = this.converter.javaCharsToCHARBytes(this.javaChars, read, this.resizableBuffer);
                        break;
                    }
                    default: {
                        System.arraycopy(this.convbuf, 0, this.resizableBuffer, 0, read);
                        this.count = read;
                        break;
                    }
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
            this.pos = 0;
            return true;
        }
        return false;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
