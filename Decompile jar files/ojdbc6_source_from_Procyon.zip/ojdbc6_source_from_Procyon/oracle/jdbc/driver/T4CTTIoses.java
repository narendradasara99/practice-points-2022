// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

final class T4CTTIoses extends T4CTTIfun
{
    static final int OSESSWS = 1;
    static final int OSESDET = 3;
    private int sididx;
    private int sidser;
    private int sidopc;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIoses(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)17);
        this.setFunCode((short)107);
    }
    
    void doO80SES(final int sididx, final int sidser, final int sidopc) throws IOException, SQLException {
        this.sididx = sididx;
        this.sidser = sidser;
        this.sidopc = sidopc;
        if (this.sidopc != 1 && this.sidopc != 3) {
            throw new SQLException("Wrong operation : can only do switch or detach");
        }
        this.doPigRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalUB4(this.sididx);
        this.meg.marshalUB4(this.sidser);
        this.meg.marshalUB4(this.sidopc);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
