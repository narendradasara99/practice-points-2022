// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.ByteArrayInputStream;
import oracle.net.ns.BreakNetException;
import java.sql.SQLException;
import oracle.net.ns.NetException;
import java.io.IOException;
import oracle.net.ns.NetInputStream;
import oracle.net.ns.NetOutputStream;
import java.util.ArrayList;
import oracle.jdbc.internal.OracleConnection;
import java.util.concurrent.atomic.AtomicReference;
import oracle.net.ns.Communication;

class T4CMAREngine
{
    static final int TTCC_MXL = 252;
    static final int TTCC_ESC = 253;
    static final int TTCC_LNG = 254;
    static final int TTCC_ERR = 255;
    static final int TTCC_MXIN = 64;
    static final byte TTCLXMULTI = 1;
    static final byte TTCLXMCONV = 2;
    T4CTypeRep types;
    Communication net;
    DBConversion conv;
    byte proSvrVer;
    T4CSocketInputStreamWrapper inStream;
    T4CSocketOutputStreamWrapper outStream;
    final byte[] ignored;
    final byte[] tmpBuffer1;
    final byte[] tmpBuffer2;
    final byte[] tmpBuffer3;
    final byte[] tmpBuffer4;
    final byte[] tmpBuffer5;
    final byte[] tmpBuffer6;
    final byte[] tmpBuffer7;
    final byte[] tmpBuffer8;
    final int[] retLen;
    AtomicReference<OracleConnection> connForException;
    ArrayList refVector;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static String toHex(final long n, final int n2) {
        String s = null;
        switch (n2) {
            case 1: {
                s = "00" + Long.toString(n & 0xFFL, 16);
                break;
            }
            case 2: {
                s = "0000" + Long.toString(n & 0xFFFFL, 16);
                break;
            }
            case 3: {
                s = "000000" + Long.toString(n & 0xFFFFFFL, 16);
                break;
            }
            case 4: {
                s = "00000000" + Long.toString(n & 0xFFFFFFFFL, 16);
                break;
            }
            case 5: {
                s = "0000000000" + Long.toString(n & 0xFFFFFFFFFFL, 16);
                break;
            }
            case 6: {
                s = "000000000000" + Long.toString(n & 0xFFFFFFFFFFFFL, 16);
                break;
            }
            case 7: {
                s = "00000000000000" + Long.toString(n & 0xFFFFFFFFFFFFFFL, 16);
                break;
            }
            case 8: {
                return toHex(n >> 32, 4) + toHex(n, 4).substring(2);
            }
            default: {
                return "more than 8 bytes";
            }
        }
        return "0x" + s.substring(s.length() - 2 * n2);
    }
    
    static String toHex(final byte b) {
        final String string = "00" + Integer.toHexString(b & 0xFF);
        return "0x" + string.substring(string.length() - 2);
    }
    
    static String toHex(final short n) {
        return toHex(n, 2);
    }
    
    static String toHex(final int n) {
        return toHex(n, 4);
    }
    
    static String toHex(final byte[] array, final int b) {
        if (array == null) {
            return "null";
        }
        if (b > array.length) {
            return "byte array not long enough";
        }
        String str = "[";
        final int min = Math.min(64, b);
        for (int i = 0; i < min; ++i) {
            str = str + toHex(array[i]) + " ";
        }
        if (min < b) {
            str += "...";
        }
        return str + "]";
    }
    
    static String toHex(final byte[] array) {
        if (array == null) {
            return "null";
        }
        return toHex(array, array.length);
    }
    
    T4CMAREngine(final Communication net) throws SQLException, IOException {
        this.ignored = new byte[255];
        this.tmpBuffer1 = new byte[1];
        this.tmpBuffer2 = new byte[2];
        this.tmpBuffer3 = new byte[3];
        this.tmpBuffer4 = new byte[4];
        this.tmpBuffer5 = new byte[5];
        this.tmpBuffer6 = new byte[6];
        this.tmpBuffer7 = new byte[7];
        this.tmpBuffer8 = new byte[8];
        this.retLen = new int[1];
        this.connForException = new AtomicReference<OracleConnection>();
        this.refVector = null;
        if (net == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 433);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.net = net;
        try {
            this.outStream = new T4CSocketOutputStreamWrapper((NetOutputStream)net.getOutputStream());
            this.inStream = new T4CSocketInputStreamWrapper((NetInputStream)net.getInputStream(), this.outStream);
        }
        catch (NetException ex) {
            throw new IOException(ex.getMessage());
        }
        (this.types = new T4CTypeRep()).setRep((byte)1, (byte)2);
    }
    
    void initBuffers() {
    }
    
    final void marshalSB1(final byte b) throws IOException {
        try {
            this.outStream.write(b);
        }
        finally {}
    }
    
    final void marshalUB1(final short n) throws IOException {
        try {
            this.outStream.write((byte)(n & 0xFF));
        }
        finally {}
    }
    
    final void marshalSB2(final short n) throws IOException {
        final byte value2Buffer = this.value2Buffer(n, this.tmpBuffer2, (byte)1);
        if (value2Buffer != 0) {
            try {
                this.outStream.write(this.tmpBuffer2, 0, value2Buffer);
            }
            finally {}
        }
    }
    
    final void marshalUB2(final int n) throws IOException {
        this.marshalSB2((short)(n & 0xFFFF));
    }
    
    final void marshalSB4(final int n) throws IOException {
        final byte value2Buffer = this.value2Buffer(n, this.tmpBuffer4, (byte)2);
        if (value2Buffer != 0) {
            try {
                this.outStream.write(this.tmpBuffer4, 0, value2Buffer);
            }
            finally {}
        }
    }
    
    final void marshalUB4(final long n) throws IOException {
        this.marshalSB4((int)(n & -1L));
    }
    
    final void marshalSB8(final long n) throws IOException {
        final byte value2Buffer = this.value2Buffer(n, this.tmpBuffer8, (byte)3);
        if (value2Buffer != 0) {
            try {
                this.outStream.write(this.tmpBuffer8, 0, value2Buffer);
            }
            finally {}
        }
    }
    
    final void marshalSWORD(final int n) throws IOException {
        this.marshalSB4(n);
    }
    
    final void marshalUWORD(final long n) throws IOException {
        this.marshalSB4((int)(n & -1L));
    }
    
    final void marshalB1Array(final byte[] b) throws IOException {
        if (b.length > 0) {
            try {
                this.outStream.write(b);
            }
            finally {}
        }
    }
    
    final void marshalB1Array(final byte[] array, final int n, final int n2) throws IOException {
        if (array.length > 0) {
            try {
                this.outStream.write(array, n, n2);
            }
            finally {}
        }
    }
    
    final void marshalUB4Array(final long[] array) throws IOException {
        for (int i = 0; i < array.length; ++i) {
            this.marshalSB4((int)(array[i] & -1L));
        }
    }
    
    final void marshalO2U(final boolean b) throws IOException {
        if (b) {
            this.addPtr((byte)1);
        }
        else {
            this.addPtr((byte)0);
        }
    }
    
    final void marshalNULLPTR() throws IOException {
        this.addPtr((byte)0);
    }
    
    final void marshalPTR() throws IOException {
        this.addPtr((byte)1);
    }
    
    final void marshalCHR(final byte[] array) throws IOException {
        this.marshalCHR(array, 0, array.length);
    }
    
    final void marshalCHR(final byte[] array, final int n, final int n2) throws IOException {
        if (n2 > 0) {
            if (this.types.isConvNeeded()) {
                this.marshalCLR(array, n, n2);
            }
            else {
                try {
                    this.outStream.write(array, n, n2);
                }
                finally {}
            }
        }
    }
    
    final void marshalCLR(final byte[] array, final int n) throws IOException {
        this.marshalCLR(array, 0, n);
    }
    
    final void marshalCLR(final byte[] array, final int n, final int n2) throws IOException {
        try {
            if (n2 > 64) {
                int i = 0;
                this.outStream.write(-2);
                do {
                    final int n3 = n2 - i;
                    final int n4 = (n3 > 64) ? 64 : n3;
                    this.outStream.write((byte)(n4 & 0xFF));
                    this.outStream.write(array, n + i, n4);
                    i += n4;
                } while (i < n2);
                this.outStream.write(0);
            }
            else {
                this.outStream.write((byte)(n2 & 0xFF));
                if (array.length != 0) {
                    this.outStream.write(array, n, n2);
                }
            }
        }
        finally {}
    }
    
    final void marshalKEYVAL(final byte[][] array, final int[] array2, final byte[][] array3, final int[] array4, final byte[] array5, final int n) throws IOException {
        for (int i = 0; i < n; ++i) {
            if (array[i] != null && array2[i] > 0) {
                this.marshalUB4(array2[i]);
                this.marshalCLR(array[i], 0, array2[i]);
            }
            else {
                this.marshalUB4(0L);
            }
            if (array3[i] != null && array4[i] > 0) {
                this.marshalUB4(array4[i]);
                this.marshalCLR(array3[i], 0, array4[i]);
            }
            else {
                this.marshalUB4(0L);
            }
            if (array5[i] != 0) {
                this.marshalUB4(1L);
            }
            else {
                this.marshalUB4(0L);
            }
        }
    }
    
    final void marshalKEYVAL(final byte[][] array, final byte[][] array2, final byte[] array3, final int n) throws IOException {
        final int[] array4 = new int[n];
        final int[] array5 = new int[n];
        for (int i = 0; i < n; ++i) {
            if (array[i] != null) {
                array4[i] = array[i].length;
            }
            if (array2[i] != null) {
                array5[i] = array2[i].length;
            }
        }
        this.marshalKEYVAL(array, array4, array2, array5, array3, n);
    }
    
    final void marshalDALC(final byte[] array) throws IOException {
        if (array != null) {
            if (array.length >= 1) {
                this.marshalSB4(-1 & array.length);
                this.marshalCLR(array, array.length);
                return;
            }
        }
        try {
            this.outStream.write(0);
        }
        finally {}
    }
    
    final void marshalKPDKV(final byte[][] array, final byte[][] array2, final int[] array3) throws IOException {
        for (int i = 0; i < array.length; ++i) {
            if (array[i] != null) {
                this.marshalUB4(array[i].length);
                this.marshalCLR(array[i], 0, array[i].length);
            }
            else {
                this.marshalUB4(0L);
            }
            if (array2[i] != null) {
                this.marshalUB4(array2[i].length);
                this.marshalCLR(array2[i], 0, array2[i].length);
            }
            else {
                this.marshalUB4(0L);
            }
            this.marshalUB2(array3[i]);
        }
    }
    
    final void unmarshalKPDKV(final byte[][] array, final int[] array2, final byte[][] array3, final int[] array4) throws IOException, SQLException {
        final int[] array5 = { 0 };
        for (int i = 0; i < array.length; ++i) {
            final int n = (int)this.unmarshalUB4();
            if (n > 0) {
                this.unmarshalCLR(array[i] = new byte[n], 0, array5, n);
                array2[i] = array5[0];
            }
            final int n2 = (int)this.unmarshalUB4();
            if (n2 > 0) {
                this.unmarshalCLR(array3[i] = new byte[n2], 0, array5, n2);
            }
            array4[i] = this.unmarshalUB2();
        }
    }
    
    final void addPtr(final byte b) throws IOException {
        try {
            if ((this.types.rep[4] & 0x1) > 0) {
                this.outStream.write(b);
            }
            else {
                final byte value2Buffer = this.value2Buffer(b, this.tmpBuffer4, (byte)4);
                if (value2Buffer != 0) {
                    this.outStream.write(this.tmpBuffer4, 0, value2Buffer);
                }
            }
        }
        finally {}
    }
    
    final byte value2Buffer(final int n, final byte[] array, final byte b) throws IOException {
        final boolean b2 = (this.types.rep[b] & 0x1) > 0;
        int n2 = 1;
        byte b3 = 0;
        for (int i = array.length - 1; i >= 0; --i) {
            array[b3] = (byte)(n >>> 8 * i & 0xFF);
            if (b2) {
                if (n2 == 0 || array[b3] != 0) {
                    n2 = 0;
                    ++b3;
                }
            }
            else {
                ++b3;
            }
        }
        if (b2) {
            try {
                this.outStream.write(b3);
            }
            finally {}
        }
        if ((this.types.rep[b] & 0x2) > 0) {
            this.reverseArray(array, b3);
        }
        return b3;
    }
    
    final byte value2Buffer(final long n, final byte[] array, final byte b) throws IOException {
        final boolean b2 = (this.types.rep[b] & 0x1) > 0;
        int n2 = 1;
        byte b3 = 0;
        for (int i = array.length - 1; i >= 0; --i) {
            array[b3] = (byte)(n >>> 8 * i & 0xFFL);
            if (b2) {
                if (n2 == 0 || array[b3] != 0) {
                    n2 = 0;
                    ++b3;
                }
            }
            else {
                ++b3;
            }
        }
        if (b2) {
            try {
                this.outStream.write(b3);
            }
            finally {}
        }
        if ((this.types.rep[b] & 0x2) > 0) {
            this.reverseArray(array, b3);
        }
        return b3;
    }
    
    final void reverseArray(final byte[] array, final byte b) {
        for (int n = b / 2, i = 0; i < n; ++i) {
            final byte b2 = array[i];
            array[i] = array[b - 1 - i];
            array[b - 1 - i] = b2;
        }
    }
    
    final byte unmarshalSB1() throws SQLException, IOException {
        return (byte)this.unmarshalUB1();
    }
    
    final short unmarshalUB1() throws SQLException, IOException {
        short n = 0;
        try {
            n = (short)this.inStream.read();
        }
        catch (BreakNetException ex) {
            this.net.sendReset();
            throw ex;
        }
        if (n < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return n;
    }
    
    final short unmarshalSB2() throws SQLException, IOException {
        return (short)this.unmarshalUB2();
    }
    
    final int unmarshalUB2() throws SQLException, IOException {
        return (int)this.buffer2Value((byte)1) & 0xFFFF;
    }
    
    final int unmarshalUCS2(final byte[] array, final long n) throws SQLException, IOException {
        final int unmarshalUB2 = this.unmarshalUB2();
        this.tmpBuffer2[0] = (byte)((unmarshalUB2 & 0xFF00) >> 8);
        this.tmpBuffer2[1] = (byte)(unmarshalUB2 & 0xFF);
        if (n + 1L < array.length) {
            array[(int)n] = this.tmpBuffer2[0];
            array[(int)n + 1] = this.tmpBuffer2[1];
        }
        return (this.tmpBuffer2[0] == 0) ? ((this.tmpBuffer2[1] == 0) ? 1 : 2) : 3;
    }
    
    final int unmarshalSB4() throws SQLException, IOException {
        return (int)this.unmarshalUB4();
    }
    
    final long unmarshalUB4() throws SQLException, IOException {
        return this.buffer2Value((byte)2);
    }
    
    final int unmarshalSB4(final byte[] buf) throws SQLException, IOException {
        return (int)this.buffer2Value((byte)2, new ByteArrayInputStream(buf));
    }
    
    final long unmarshalSB8() throws SQLException, IOException {
        return this.buffer2Value((byte)3);
    }
    
    final int unmarshalRefCursor(final byte[] array) throws SQLException, IOException {
        return this.unmarshalSB4(array);
    }
    
    int unmarshalSWORD() throws SQLException, IOException {
        return (int)this.unmarshalUB4();
    }
    
    long unmarshalUWORD() throws SQLException, IOException {
        return this.unmarshalUB4();
    }
    
    byte[] unmarshalNBytes(final int n) throws SQLException, IOException {
        final byte[] b = new byte[n];
        if (n > 0) {
            try {
                if (this.inStream.read(b) < 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            catch (BreakNetException ex) {
                this.net.sendReset();
                throw ex;
            }
        }
        return b;
    }
    
    int unmarshalNBytes(final byte[] array, final int n, final int n2) throws SQLException, IOException {
        int i;
        for (i = 0; i < n2; i += this.getNBytes(array, n + i, n2 - i)) {}
        return i;
    }
    
    int getNBytes(final byte[] array, final int n, final int n2) throws SQLException, IOException {
        int read = 0;
        try {
            if ((read = this.inStream.read(array, n, n2)) < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (BreakNetException ex) {
            this.net.sendReset();
            throw ex;
        }
        return read;
    }
    
    byte[] getNBytes(final int n) throws SQLException, IOException {
        final byte[] b = new byte[n];
        try {
            if (this.inStream.read(b) < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (BreakNetException ex) {
            this.net.sendReset();
            throw ex;
        }
        return b;
    }
    
    byte[] unmarshalTEXT(final int n) throws SQLException, IOException {
        int i = 0;
        final byte[] array = new byte[n];
        while (i < n) {
            try {
                if (this.inStream.read(array, i, 1) < 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            catch (BreakNetException ex) {
                this.net.sendReset();
                throw ex;
            }
            if (array[i++] == 0) {
                break;
            }
        }
        byte[] array2;
        if (array.length == --i) {
            array2 = array;
        }
        else {
            array2 = new byte[i];
            System.arraycopy(array, 0, array2, 0, i);
        }
        return array2;
    }
    
    byte[] unmarshalCHR(final int n) throws SQLException, IOException {
        byte[] array;
        if (this.types.isConvNeeded()) {
            array = this.unmarshalCLR(n, this.retLen);
            if (array.length != this.retLen[0]) {
                final byte[] array2 = new byte[this.retLen[0]];
                System.arraycopy(array, 0, array2, 0, this.retLen[0]);
                array = array2;
            }
        }
        else {
            array = this.getNBytes(n);
        }
        return array;
    }
    
    void unmarshalCLR(final byte[] array, final int n, final int[] array2) throws SQLException, IOException {
        this.unmarshalCLR(array, n, array2, Integer.MAX_VALUE);
    }
    
    void unmarshalCLR(final byte[] array, final int n, final int[] array2, final int n2) throws SQLException, IOException {
        this.unmarshalCLR(array, n, array2, n2, 0);
    }
    
    void unmarshalCLR(final byte[] array, final int n, final int[] array2, final int n2, final int n3) throws SQLException, IOException {
        int n4 = n;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int b = this.unmarshalUB1();
        if (b < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (b == 0) {
            array2[0] = 0;
            return;
        }
        if (this.escapeSequenceNull(b)) {
            array2[0] = 0;
            return;
        }
        if (b != 254) {
            if (n3 - n7 >= b) {
                this.unmarshalBuffer(this.ignored, 0, b);
                b = 0;
            }
            else if (n3 - n7 > 0) {
                this.unmarshalBuffer(this.ignored, 0, n3 - n7);
                b -= n3 - n7;
            }
            if (b > 0) {
                final int min = Math.min(n2 - n6, b);
                n4 = this.unmarshalBuffer(array, n4, min);
                n6 += min;
                final int n8 = b - min;
                if (n8 > 0) {
                    this.unmarshalBuffer(this.ignored, 0, n8);
                }
            }
        }
        else {
            int n9 = -1;
            while (true) {
                if (n9 != -1) {
                    b = this.unmarshalUB1();
                    if (b <= 0) {
                        break;
                    }
                }
                if (b == 254) {
                    switch (n9) {
                        case -1: {
                            n9 = 1;
                            continue;
                        }
                        case 0: {
                            if (n5 != 0) {
                                break;
                            }
                            n9 = 0;
                            continue;
                        }
                    }
                }
                if (n4 == -1) {
                    this.unmarshalBuffer(this.ignored, 0, b);
                }
                else {
                    int b2 = b;
                    if (n3 - n7 >= b2) {
                        this.unmarshalBuffer(this.ignored, 0, b2);
                        n7 += b2;
                        b2 = 0;
                    }
                    else if (n3 - n7 > 0) {
                        this.unmarshalBuffer(this.ignored, 0, n3 - n7);
                        b2 -= n3 - n7;
                        n7 += n3 - n7;
                    }
                    if (b2 > 0) {
                        final int min2 = Math.min(n2 - n6, b2);
                        n4 = this.unmarshalBuffer(array, n4, min2);
                        n6 += min2;
                        final int n10 = b2 - min2;
                        if (n10 > 0) {
                            this.unmarshalBuffer(this.ignored, 0, n10);
                        }
                    }
                }
                n9 = 0;
                if (b > 252) {
                    n5 = 1;
                }
            }
        }
        if (array2 != null) {
            if (n4 != -1) {
                array2[0] = n6;
            }
            else {
                array2[0] = array.length - n;
            }
        }
    }
    
    final byte[] unmarshalCLR(final int n, final int[] array) throws SQLException, IOException {
        final byte[] array2 = new byte[n * this.conv.c2sNlsRatio];
        this.unmarshalCLR(array2, 0, array, n);
        return array2;
    }
    
    final int[] unmarshalKEYVAL(final byte[][] array, final byte[][] array2, final int n) throws SQLException, IOException {
        final byte[] array3 = new byte[1000];
        final int[] array4 = { 0 };
        final int[] array5 = new int[n];
        for (int i = 0; i < n; ++i) {
            if (this.unmarshalSB4() > 0) {
                this.unmarshalCLR(array3, 0, array4);
                System.arraycopy(array3, 0, array[i] = new byte[array4[0]], 0, array4[0]);
            }
            if (this.unmarshalSB4() > 0) {
                this.unmarshalCLR(array3, 0, array4);
                System.arraycopy(array3, 0, array2[i] = new byte[array4[0]], 0, array4[0]);
            }
            array5[i] = this.unmarshalSB4();
        }
        return array5;
    }
    
    final int unmarshalBuffer(final byte[] array, int n, final int n2) throws SQLException, IOException {
        if (n2 <= 0) {
            return n;
        }
        if (array.length < n + n2) {
            this.unmarshalNBytes(array, n, array.length - n);
            this.unmarshalNBytes(this.ignored, 0, n + n2 - array.length);
            n = -1;
        }
        else {
            this.unmarshalNBytes(array, n, n2);
            n += n2;
        }
        return n;
    }
    
    final byte[] unmarshalCLRforREFS() throws SQLException, IOException {
        int n = 0;
        final short unmarshalUB1 = this.unmarshalUB1();
        if (unmarshalUB1 < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (unmarshalUB1 == 0) {
            return null;
        }
        final boolean escapeSequenceNull = this.escapeSequenceNull(unmarshalUB1);
        if (!escapeSequenceNull) {
            if (this.refVector == null) {
                this.refVector = new ArrayList(10);
            }
            else {
                this.refVector.clear();
            }
        }
        byte[] array;
        if (!escapeSequenceNull) {
            if (unmarshalUB1 == 254) {
                short unmarshalUB2;
                while ((unmarshalUB2 = this.unmarshalUB1()) > 0) {
                    if (unmarshalUB2 == 254 && this.types.isServerConversion()) {
                        continue;
                    }
                    n = (short)(n + unmarshalUB2);
                    final byte[] e = new byte[unmarshalUB2];
                    this.unmarshalBuffer(e, 0, unmarshalUB2);
                    this.refVector.add(e);
                }
            }
            else {
                n = unmarshalUB1;
                final byte[] e2 = new byte[unmarshalUB1];
                this.unmarshalBuffer(e2, 0, unmarshalUB1);
                this.refVector.add(e2);
            }
            array = new byte[n];
            int n2 = 0;
            while (this.refVector.size() > 0) {
                final int length = ((byte[])this.refVector.get(0)).length;
                System.arraycopy(this.refVector.get(0), 0, array, n2, length);
                n2 += length;
                this.refVector.remove(0);
            }
        }
        else {
            array = null;
        }
        return array;
    }
    
    final boolean escapeSequenceNull(final int n) throws SQLException {
        boolean b = false;
        switch (n) {
            case 0: {
                b = true;
                break;
            }
            case 253: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            case 255: {
                b = true;
            }
        }
        return b;
    }
    
    final int processIndicator(final boolean b, final int n) throws SQLException, IOException {
        final short unmarshalSB2 = this.unmarshalSB2();
        int n2 = 0;
        if (!b) {
            if (unmarshalSB2 == 0) {
                n2 = n;
            }
            else if (unmarshalSB2 == -2 || unmarshalSB2 > 0) {
                n2 = unmarshalSB2;
            }
            else {
                n2 = 65536 + unmarshalSB2;
            }
        }
        return n2;
    }
    
    final long unmarshalDALC(final byte[] array, final int n, final int[] array2) throws SQLException, IOException {
        final long unmarshalUB4 = this.unmarshalUB4();
        if (unmarshalUB4 > 0L) {
            this.unmarshalCLR(array, n, array2);
        }
        return unmarshalUB4;
    }
    
    final byte[] unmarshalDALC() throws SQLException, IOException {
        final byte[] array = new byte[(int)(-1L & this.unmarshalUB4())];
        byte[] unmarshalCLR;
        if (array.length > 0) {
            unmarshalCLR = this.unmarshalCLR(array.length, this.retLen);
            if (unmarshalCLR == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        else {
            unmarshalCLR = new byte[0];
        }
        return unmarshalCLR;
    }
    
    final byte[] unmarshalDALC(final int[] array) throws SQLException, IOException {
        final byte[] array2 = new byte[(int)(-1L & this.unmarshalUB4())];
        byte[] unmarshalCLR;
        if (array2.length > 0) {
            unmarshalCLR = this.unmarshalCLR(array2.length, array);
            if (unmarshalCLR == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        else {
            unmarshalCLR = new byte[0];
        }
        return unmarshalCLR;
    }
    
    final long buffer2Value(final byte b) throws SQLException, IOException {
        int b2 = 1;
        if ((this.types.rep[b] & 0x1) > 0) {
            b2 = this.inStream.readB1();
        }
        else {
            switch (b) {
                case 1: {
                    b2 = 2;
                    break;
                }
                case 2: {
                    b2 = 4;
                    break;
                }
                case 3: {
                    b2 = 8;
                    break;
                }
            }
        }
        long n;
        if ((this.types.rep[b] & 0x2) > 0) {
            n = this.inStream.readLongLSB(b2);
        }
        else {
            n = this.inStream.readLongMSB(b2);
        }
        return n;
    }
    
    final long buffer2Value(final byte b, final ByteArrayInputStream byteArrayInputStream) throws SQLException, IOException {
        int read = 0;
        long n = 0L;
        boolean b2 = false;
        if ((this.types.rep[b] & 0x1) > 0) {
            read = byteArrayInputStream.read();
            if ((read & 0x80) > 0) {
                read &= 0x7F;
                b2 = true;
            }
            if (read < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (read == 0) {
                return 0L;
            }
            if ((b == 1 && read > 2) || (b == 2 && read > 4)) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 412);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        else if (b == 1) {
            read = 2;
        }
        else if (b == 2) {
            read = 4;
        }
        final byte[] b3 = new byte[read];
        if (byteArrayInputStream.read(b3) < 0) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 410);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        for (int i = 0; i < b3.length; ++i) {
            short n2;
            if ((this.types.rep[b] & 0x2) > 0) {
                n2 = (short)(b3[b3.length - 1 - i] & 0xFF);
            }
            else {
                n2 = (short)(b3[i] & 0xFF);
            }
            n |= n2 << 8 * (b3.length - 1 - i);
        }
        long n3 = n & -1L;
        if (b2) {
            n3 = -n3;
        }
        return n3;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connForException.get();
    }
    
    protected void setConnectionDuringExceptionHandling(final OracleConnection newValue) {
        this.connForException.set(newValue);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
