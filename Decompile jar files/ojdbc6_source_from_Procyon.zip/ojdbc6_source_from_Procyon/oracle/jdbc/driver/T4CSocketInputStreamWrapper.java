// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.net.ns.BreakNetException;
import oracle.net.ns.NetException;
import java.io.IOException;
import oracle.net.ns.NetInputStream;
import java.io.InputStream;

class T4CSocketInputStreamWrapper extends InputStream
{
    static final int MAX_BUFFER_SIZE = 2048;
    NetInputStream is;
    T4CSocketOutputStreamWrapper os;
    boolean eof;
    byte[] buffer;
    int bIndex;
    int bytesAvailable;
    
    T4CSocketInputStreamWrapper(final NetInputStream is, final T4CSocketOutputStreamWrapper os) throws IOException {
        this.is = null;
        this.os = null;
        this.eof = false;
        this.buffer = new byte[2048];
        this.bIndex = 0;
        this.is = is;
        this.os = os;
    }
    
    @Override
    public final int read() throws IOException {
        if (this.eof) {
            return -1;
        }
        if (this.bytesAvailable < 1) {
            this.readNextPacket();
            if (this.eof) {
                return -1;
            }
        }
        --this.bytesAvailable;
        return this.buffer[this.bIndex++] & 0xFF;
    }
    
    @Override
    public final int read(final byte[] array, int n, final int n2) throws IOException {
        if (this.eof) {
            return 0;
        }
        if (this.bytesAvailable < n2) {
            final int bytesAvailable = this.bytesAvailable;
            System.arraycopy(this.buffer, this.bIndex, array, n, bytesAvailable);
            n += bytesAvailable;
            this.bIndex += bytesAvailable;
            this.bytesAvailable -= bytesAvailable;
            this.is.read(array, n, n2 - bytesAvailable);
        }
        else {
            System.arraycopy(this.buffer, this.bIndex, array, n, n2);
            this.bIndex += n2;
            this.bytesAvailable -= n2;
        }
        return n2;
    }
    
    void readNextPacket() throws IOException {
        this.os.flush();
        final int read = this.is.read();
        if (read == -1) {
            this.eof = true;
            return;
        }
        this.buffer[0] = (byte)read;
        this.bytesAvailable = this.is.available() + 1;
        this.bytesAvailable = ((this.bytesAvailable > 2048) ? 2048 : this.bytesAvailable);
        if (this.bytesAvailable > 1) {
            this.is.read(this.buffer, 1, this.bytesAvailable - 1);
        }
        this.bIndex = 0;
    }
    
    int readB1() throws IOException {
        return this.read();
    }
    
    long readLongLSB(int n) throws IOException {
        long n2 = 0L;
        boolean b = false;
        if ((n & 0x80) > 0) {
            n &= 0x7F;
            b = true;
        }
        for (int i = n, n3 = 0; i > 0; --i, ++n3) {
            if (this.bytesAvailable < 1) {
                this.readNextPacket();
            }
            n2 |= ((long)this.buffer[this.bIndex++] & 0xFFL) << 8 * n3;
            --this.bytesAvailable;
        }
        return (b ? -1 : 1) * n2;
    }
    
    long readLongMSB(int n) throws IOException {
        long n2 = 0L;
        boolean b = false;
        if ((n & 0x80) > 0) {
            n &= 0x7F;
            b = true;
        }
        for (int i = n; i > 0; --i) {
            if (this.bytesAvailable < 1) {
                this.readNextPacket();
            }
            n2 |= ((long)this.buffer[this.bIndex++] & 0xFFL) << 8 * (i - 1);
            --this.bytesAvailable;
        }
        return (b ? -1 : 1) * n2;
    }
    
    public boolean readZeroCopyIO(final byte[] array, final int n, final int[] array2) throws IOException, NetException, BreakNetException {
        this.os.flush();
        return this.is.readZeroCopyIO(array, n, array2);
    }
}
