// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class OracleStatementCacheEntry
{
    protected OracleStatementCacheEntry applicationNext;
    protected OracleStatementCacheEntry applicationPrev;
    protected OracleStatementCacheEntry explicitNext;
    protected OracleStatementCacheEntry explicitPrev;
    protected OracleStatementCacheEntry implicitNext;
    protected OracleStatementCacheEntry implicitPrev;
    boolean onImplicit;
    String sql;
    int statementType;
    int scrollType;
    OraclePreparedStatement statement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleStatementCacheEntry() {
        this.applicationNext = null;
        this.applicationPrev = null;
        this.explicitNext = null;
        this.explicitPrev = null;
        this.implicitNext = null;
        this.implicitPrev = null;
    }
    
    public void print() throws SQLException {
        System.out.println("Cache entry " + this);
        System.out.println("  Key: " + this.sql + "$$" + this.statementType + "$$" + this.scrollType);
        System.out.println("  Statement: " + this.statement);
        System.out.println("  onImplicit: " + this.onImplicit);
        System.out.println("  applicationNext: " + this.applicationNext + "  applicationPrev: " + this.applicationPrev);
        System.out.println("  implicitNext: " + this.implicitNext + "  implicitPrev: " + this.implicitPrev);
        System.out.println("  explicitNext: " + this.explicitNext + "  explicitPrev: " + this.explicitPrev);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
