// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class ClobBinder extends DatumBinder
{
    Binder theClobCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 112;
        binder.bytelen = 4000;
    }
    
    ClobBinder() {
        this.theClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theClobCopyingBinder;
    }
    
    @Override
    void lastBoundValueCleanup(final OraclePreparedStatement oraclePreparedStatement, final int n) {
        if (oraclePreparedStatement.lastBoundClobs != null) {
            oraclePreparedStatement.moveTempLobsToFree(oraclePreparedStatement.lastBoundClobs[n]);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
