// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class BINARY_DOUBLEBinder extends DatumBinder
{
    Binder theBINARY_DOUBLECopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 101;
        binder.bytelen = 8;
    }
    
    BINARY_DOUBLEBinder() {
        this.theBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theBINARY_DOUBLECopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
