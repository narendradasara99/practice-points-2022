// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.Datum;
import java.sql.Connection;

final class T4C8TTIBfile extends T4C8TTILob
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8TTIBfile(final T4CConnection t4CConnection) {
        super(t4CConnection);
    }
    
    @Override
    Datum createTemporaryLob(final Connection connection, final boolean b, final int n) throws SQLException, IOException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), "cannot create a temporary BFILE", -1);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    boolean open(final byte[] array, final int n) throws SQLException, IOException {
        return this._open(array, 11, 256);
    }
    
    @Override
    boolean close(final byte[] array) throws SQLException, IOException {
        return this._close(array, 512);
    }
    
    @Override
    boolean isOpen(final byte[] array) throws SQLException, IOException {
        return this._isOpen(array, 1024);
    }
    
    boolean doesExist(final byte[] sourceLobLocator) throws SQLException, IOException {
        this.initializeLobdef();
        this.sourceLobLocator = sourceLobLocator;
        this.lobops = 2048L;
        this.nullO2U = true;
        this.doRPC();
        return this.lobnull;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
