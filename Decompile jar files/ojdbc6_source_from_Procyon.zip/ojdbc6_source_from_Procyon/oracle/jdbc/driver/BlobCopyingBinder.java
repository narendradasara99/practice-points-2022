// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class BlobCopyingBinder extends ByteCopyingBinder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    BlobCopyingBinder() {
        BlobBinder.init(this);
    }
    
    @Override
    void lastBoundValueCleanup(final OraclePreparedStatement oraclePreparedStatement, final int n) {
        if (oraclePreparedStatement.lastBoundBlobs != null) {
            oraclePreparedStatement.moveTempLobsToFree(oraclePreparedStatement.lastBoundBlobs[n]);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
