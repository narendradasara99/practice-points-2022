// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.StructDescriptor;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatumFactory;
import java.util.Map;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.ORAData;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.DATE;
import oracle.sql.CustomDatum;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.Ref;
import java.sql.NClob;
import java.util.Calendar;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.SQLException;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.internal.OracleCallableStatement;

class OracleCallableStatementWrapper extends OraclePreparedStatementWrapper implements OracleCallableStatement
{
    protected OracleCallableStatement callableStatement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleCallableStatementWrapper(final oracle.jdbc.OracleCallableStatement oracleCallableStatement) throws SQLException {
        super(oracleCallableStatement);
        this.callableStatement = null;
        this.callableStatement = (OracleCallableStatement)oracleCallableStatement;
    }
    
    @Override
    public void setArray(final String s, final Array array) throws SQLException {
        this.callableStatement.setArray(s, array);
    }
    
    @Override
    public void setBigDecimal(final String s, final BigDecimal bigDecimal) throws SQLException {
        this.callableStatement.setBigDecimal(s, bigDecimal);
    }
    
    @Override
    public void setBlob(final String s, final Blob blob) throws SQLException {
        this.callableStatement.setBlob(s, blob);
    }
    
    @Override
    public void setBoolean(final String s, final boolean b) throws SQLException {
        this.callableStatement.setBoolean(s, b);
    }
    
    @Override
    public void setByte(final String s, final byte b) throws SQLException {
        this.callableStatement.setByte(s, b);
    }
    
    @Override
    public void setBytes(final String s, final byte[] array) throws SQLException {
        this.callableStatement.setBytes(s, array);
    }
    
    @Override
    public void setClob(final String s, final Clob clob) throws SQLException {
        this.callableStatement.setClob(s, clob);
    }
    
    @Override
    public void setDate(final String s, final Date date) throws SQLException {
        this.callableStatement.setDate(s, date);
    }
    
    @Override
    public void setDate(final String s, final Date date, final Calendar calendar) throws SQLException {
        this.callableStatement.setDate(s, date, calendar);
    }
    
    @Override
    public void setDouble(final String s, final double n) throws SQLException {
        this.callableStatement.setDouble(s, n);
    }
    
    @Override
    public void setFloat(final String s, final float n) throws SQLException {
        this.callableStatement.setFloat(s, n);
    }
    
    @Override
    public void setInt(final String s, final int n) throws SQLException {
        this.callableStatement.setInt(s, n);
    }
    
    @Override
    public void setLong(final String s, final long n) throws SQLException {
        this.callableStatement.setLong(s, n);
    }
    
    @Override
    public void setNClob(final String s, final NClob nClob) throws SQLException {
        this.callableStatement.setNClob(s, nClob);
    }
    
    @Override
    public void setNString(final String s, final String s2) throws SQLException {
        this.callableStatement.setNString(s, s2);
    }
    
    @Override
    public void setObject(final String s, final Object o) throws SQLException {
        this.callableStatement.setObject(s, o);
    }
    
    @Override
    public void setObject(final String s, final Object o, final int n) throws SQLException {
        this.callableStatement.setObject(s, o, n);
    }
    
    @Override
    public void setRef(final String s, final Ref ref) throws SQLException {
        this.callableStatement.setRef(s, ref);
    }
    
    @Override
    public void setRowId(final String s, final RowId rowId) throws SQLException {
        this.callableStatement.setRowId(s, rowId);
    }
    
    @Override
    public void setShort(final String s, final short n) throws SQLException {
        this.callableStatement.setShort(s, n);
    }
    
    @Override
    public void setSQLXML(final String s, final SQLXML sqlxml) throws SQLException {
        this.callableStatement.setSQLXML(s, sqlxml);
    }
    
    @Override
    public void setString(final String s, final String s2) throws SQLException {
        this.callableStatement.setString(s, s2);
    }
    
    @Override
    public void setTime(final String s, final Time time) throws SQLException {
        this.callableStatement.setTime(s, time);
    }
    
    @Override
    public void setTime(final String s, final Time time, final Calendar calendar) throws SQLException {
        this.callableStatement.setTime(s, time, calendar);
    }
    
    @Override
    public void setTimestamp(final String s, final Timestamp timestamp) throws SQLException {
        this.callableStatement.setTimestamp(s, timestamp);
    }
    
    @Override
    public void setTimestamp(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.callableStatement.setTimestamp(s, timestamp, calendar);
    }
    
    @Override
    public void setURL(final String s, final URL url) throws SQLException {
        this.callableStatement.setURL(s, url);
    }
    
    @Override
    public void setARRAY(final String s, final ARRAY array) throws SQLException {
        this.callableStatement.setARRAY(s, array);
    }
    
    @Override
    public void setBFILE(final String s, final BFILE bfile) throws SQLException {
        this.callableStatement.setBFILE(s, bfile);
    }
    
    @Override
    public void setBfile(final String s, final BFILE bfile) throws SQLException {
        this.callableStatement.setBfile(s, bfile);
    }
    
    @Override
    public void setBinaryFloat(final String s, final float n) throws SQLException {
        this.callableStatement.setBinaryFloat(s, n);
    }
    
    @Override
    public void setBinaryFloat(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        this.callableStatement.setBinaryFloat(s, binary_FLOAT);
    }
    
    @Override
    public void setBinaryDouble(final String s, final double n) throws SQLException {
        this.callableStatement.setBinaryDouble(s, n);
    }
    
    @Override
    public void setBinaryDouble(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        this.callableStatement.setBinaryDouble(s, binary_DOUBLE);
    }
    
    @Override
    public void setBLOB(final String s, final BLOB blob) throws SQLException {
        this.callableStatement.setBLOB(s, blob);
    }
    
    @Override
    public void setCHAR(final String s, final CHAR char1) throws SQLException {
        this.callableStatement.setCHAR(s, char1);
    }
    
    @Override
    public void setCLOB(final String s, final CLOB clob) throws SQLException {
        this.callableStatement.setCLOB(s, clob);
    }
    
    @Override
    public void setCursor(final String s, final ResultSet set) throws SQLException {
        this.callableStatement.setCursor(s, set);
    }
    
    @Override
    public void setCustomDatum(final String s, final CustomDatum customDatum) throws SQLException {
        this.callableStatement.setCustomDatum(s, customDatum);
    }
    
    @Override
    public void setDATE(final String s, final DATE date) throws SQLException {
        this.callableStatement.setDATE(s, date);
    }
    
    @Override
    public void setFixedCHAR(final String s, final String s2) throws SQLException {
        this.callableStatement.setFixedCHAR(s, s2);
    }
    
    @Override
    public void setINTERVALDS(final String s, final INTERVALDS intervalds) throws SQLException {
        this.callableStatement.setINTERVALDS(s, intervalds);
    }
    
    @Override
    public void setINTERVALYM(final String s, final INTERVALYM intervalym) throws SQLException {
        this.callableStatement.setINTERVALYM(s, intervalym);
    }
    
    @Override
    public void setNUMBER(final String s, final NUMBER number) throws SQLException {
        this.callableStatement.setNUMBER(s, number);
    }
    
    @Override
    public void setOPAQUE(final String s, final OPAQUE opaque) throws SQLException {
        this.callableStatement.setOPAQUE(s, opaque);
    }
    
    @Override
    public void setOracleObject(final String s, final Datum datum) throws SQLException {
        this.callableStatement.setOracleObject(s, datum);
    }
    
    @Override
    public void setORAData(final String s, final ORAData oraData) throws SQLException {
        this.callableStatement.setORAData(s, oraData);
    }
    
    @Override
    public void setRAW(final String s, final RAW raw) throws SQLException {
        this.callableStatement.setRAW(s, raw);
    }
    
    @Override
    public void setREF(final String s, final REF ref) throws SQLException {
        this.callableStatement.setREF(s, ref);
    }
    
    @Override
    public void setRefType(final String s, final REF ref) throws SQLException {
        this.callableStatement.setRefType(s, ref);
    }
    
    @Override
    public void setROWID(final String s, final ROWID rowid) throws SQLException {
        this.callableStatement.setROWID(s, rowid);
    }
    
    @Override
    public void setSTRUCT(final String s, final STRUCT struct) throws SQLException {
        this.callableStatement.setSTRUCT(s, struct);
    }
    
    @Override
    public void setTIMESTAMPLTZ(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        this.callableStatement.setTIMESTAMPLTZ(s, timestampltz);
    }
    
    @Override
    public void setTIMESTAMPTZ(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        this.callableStatement.setTIMESTAMPTZ(s, timestamptz);
    }
    
    @Override
    public void setTIMESTAMP(final String s, final TIMESTAMP timestamp) throws SQLException {
        this.callableStatement.setTIMESTAMP(s, timestamp);
    }
    
    @Override
    public void setBlob(final String s, final InputStream inputStream) throws SQLException {
        this.callableStatement.setBlob(s, inputStream);
    }
    
    @Override
    public void setBlob(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.callableStatement.setBlob(s, inputStream, n);
    }
    
    @Override
    public void setClob(final String s, final Reader reader) throws SQLException {
        this.callableStatement.setClob(s, reader);
    }
    
    @Override
    public void setClob(final String s, final Reader reader, final long n) throws SQLException {
        this.callableStatement.setClob(s, reader, n);
    }
    
    @Override
    public void setNClob(final String s, final Reader reader) throws SQLException {
        this.callableStatement.setNClob(s, reader);
    }
    
    @Override
    public void setNClob(final String s, final Reader reader, final long n) throws SQLException {
        this.callableStatement.setNClob(s, reader, n);
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream) throws SQLException {
        this.callableStatement.setAsciiStream(s, inputStream);
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.callableStatement.setAsciiStream(s, inputStream, n);
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.callableStatement.setAsciiStream(s, inputStream, n);
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream) throws SQLException {
        this.callableStatement.setBinaryStream(s, inputStream);
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.callableStatement.setBinaryStream(s, inputStream, n);
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.callableStatement.setBinaryStream(s, inputStream, n);
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader) throws SQLException {
        this.callableStatement.setCharacterStream(s, reader);
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader, final int n) throws SQLException {
        this.callableStatement.setCharacterStream(s, reader, n);
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        this.callableStatement.setCharacterStream(s, reader, n);
    }
    
    @Override
    public void setNCharacterStream(final String s, final Reader reader) throws SQLException {
        this.callableStatement.setNCharacterStream(s, reader);
    }
    
    @Override
    public void setNCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        this.callableStatement.setNCharacterStream(s, reader, n);
    }
    
    @Override
    public void setUnicodeStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.callableStatement.setUnicodeStream(s, inputStream, n);
    }
    
    @Override
    public void setNull(final String s, final int n, final String s2) throws SQLException {
        this.callableStatement.setNull(s, n, s2);
    }
    
    @Override
    public void setNull(final String s, final int n) throws SQLException {
        this.callableStatement.setNull(s, n);
    }
    
    @Override
    public Array getArray(final int n) throws SQLException {
        return this.callableStatement.getArray(n);
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n) throws SQLException {
        return this.callableStatement.getBigDecimal(n);
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n, final int n2) throws SQLException {
        return this.callableStatement.getBigDecimal(n, n2);
    }
    
    @Override
    public Blob getBlob(final int n) throws SQLException {
        return this.callableStatement.getBlob(n);
    }
    
    @Override
    public boolean getBoolean(final int n) throws SQLException {
        return this.callableStatement.getBoolean(n);
    }
    
    @Override
    public byte getByte(final int n) throws SQLException {
        return this.callableStatement.getByte(n);
    }
    
    @Override
    public byte[] getBytes(final int n) throws SQLException {
        return this.callableStatement.getBytes(n);
    }
    
    @Override
    public Clob getClob(final int n) throws SQLException {
        return this.callableStatement.getClob(n);
    }
    
    @Override
    public Date getDate(final int n) throws SQLException {
        return this.callableStatement.getDate(n);
    }
    
    @Override
    public Date getDate(final int n, final Calendar calendar) throws SQLException {
        return this.callableStatement.getDate(n, calendar);
    }
    
    @Override
    public double getDouble(final int n) throws SQLException {
        return this.callableStatement.getDouble(n);
    }
    
    @Override
    public float getFloat(final int n) throws SQLException {
        return this.callableStatement.getFloat(n);
    }
    
    @Override
    public int getInt(final int n) throws SQLException {
        return this.callableStatement.getInt(n);
    }
    
    @Override
    public long getLong(final int n) throws SQLException {
        return this.callableStatement.getLong(n);
    }
    
    @Override
    public NClob getNClob(final int n) throws SQLException {
        return this.callableStatement.getNClob(n);
    }
    
    @Override
    public String getNString(final int n) throws SQLException {
        return this.callableStatement.getNString(n);
    }
    
    @Override
    public Object getObject(final int n) throws SQLException {
        return this.callableStatement.getObject(n);
    }
    
    @Override
    public Object getObject(final int n, final Map map) throws SQLException {
        return this.callableStatement.getObject(n, map);
    }
    
    @Override
    public Ref getRef(final int n) throws SQLException {
        return this.callableStatement.getRef(n);
    }
    
    @Override
    public RowId getRowId(final int n) throws SQLException {
        return this.callableStatement.getRowId(n);
    }
    
    @Override
    public short getShort(final int n) throws SQLException {
        return this.callableStatement.getShort(n);
    }
    
    @Override
    public SQLXML getSQLXML(final int n) throws SQLException {
        return this.callableStatement.getSQLXML(n);
    }
    
    @Override
    public String getString(final int n) throws SQLException {
        return this.callableStatement.getString(n);
    }
    
    @Override
    public Time getTime(final int n) throws SQLException {
        return this.callableStatement.getTime(n);
    }
    
    @Override
    public Time getTime(final int n, final Calendar calendar) throws SQLException {
        return this.callableStatement.getTime(n, calendar);
    }
    
    @Override
    public Timestamp getTimestamp(final int n) throws SQLException {
        return this.callableStatement.getTimestamp(n);
    }
    
    @Override
    public Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        return this.callableStatement.getTimestamp(n, calendar);
    }
    
    @Override
    public URL getURL(final int n) throws SQLException {
        return this.callableStatement.getURL(n);
    }
    
    @Override
    public ARRAY getARRAY(final int n) throws SQLException {
        return this.callableStatement.getARRAY(n);
    }
    
    @Override
    public BFILE getBFILE(final int n) throws SQLException {
        return this.callableStatement.getBFILE(n);
    }
    
    @Override
    public BFILE getBfile(final int n) throws SQLException {
        return this.callableStatement.getBfile(n);
    }
    
    @Override
    public BLOB getBLOB(final int n) throws SQLException {
        return this.callableStatement.getBLOB(n);
    }
    
    @Override
    public CHAR getCHAR(final int n) throws SQLException {
        return this.callableStatement.getCHAR(n);
    }
    
    @Override
    public CLOB getCLOB(final int n) throws SQLException {
        return this.callableStatement.getCLOB(n);
    }
    
    @Override
    public ResultSet getCursor(final int n) throws SQLException {
        return this.callableStatement.getCursor(n);
    }
    
    @Override
    public Object getCustomDatum(final int n, final CustomDatumFactory customDatumFactory) throws SQLException {
        return this.callableStatement.getCustomDatum(n, customDatumFactory);
    }
    
    @Override
    public DATE getDATE(final int n) throws SQLException {
        return this.callableStatement.getDATE(n);
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int n) throws SQLException {
        return this.callableStatement.getINTERVALDS(n);
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int n) throws SQLException {
        return this.callableStatement.getINTERVALYM(n);
    }
    
    @Override
    public NUMBER getNUMBER(final int n) throws SQLException {
        return this.callableStatement.getNUMBER(n);
    }
    
    @Override
    public OPAQUE getOPAQUE(final int n) throws SQLException {
        return this.callableStatement.getOPAQUE(n);
    }
    
    @Override
    public Datum getOracleObject(final int n) throws SQLException {
        return this.callableStatement.getOracleObject(n);
    }
    
    @Override
    public Object getORAData(final int n, final ORADataFactory oraDataFactory) throws SQLException {
        return this.callableStatement.getORAData(n, oraDataFactory);
    }
    
    @Override
    public RAW getRAW(final int n) throws SQLException {
        return this.callableStatement.getRAW(n);
    }
    
    @Override
    public REF getREF(final int n) throws SQLException {
        return this.callableStatement.getREF(n);
    }
    
    @Override
    public ROWID getROWID(final int n) throws SQLException {
        return this.callableStatement.getROWID(n);
    }
    
    @Override
    public STRUCT getSTRUCT(final int n) throws SQLException {
        return this.callableStatement.getSTRUCT(n);
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        return this.callableStatement.getTIMESTAMPLTZ(n);
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        return this.callableStatement.getTIMESTAMPTZ(n);
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        return this.callableStatement.getTIMESTAMP(n);
    }
    
    @Override
    public InputStream getAsciiStream(final int n) throws SQLException {
        return this.callableStatement.getAsciiStream(n);
    }
    
    @Override
    public InputStream getBinaryStream(final int n) throws SQLException {
        return this.callableStatement.getBinaryStream(n);
    }
    
    @Override
    public Reader getCharacterStream(final int n) throws SQLException {
        return this.callableStatement.getCharacterStream(n);
    }
    
    @Override
    public Reader getNCharacterStream(final int n) throws SQLException {
        return this.callableStatement.getNCharacterStream(n);
    }
    
    @Override
    public InputStream getUnicodeStream(final int n) throws SQLException {
        return this.callableStatement.getUnicodeStream(n);
    }
    
    @Override
    public Array getArray(final String s) throws SQLException {
        return this.callableStatement.getArray(s);
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s) throws SQLException {
        return this.callableStatement.getBigDecimal(s);
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s, final int n) throws SQLException {
        return this.callableStatement.getBigDecimal(s, n);
    }
    
    @Override
    public Blob getBlob(final String s) throws SQLException {
        return this.callableStatement.getBlob(s);
    }
    
    @Override
    public boolean getBoolean(final String s) throws SQLException {
        return this.callableStatement.getBoolean(s);
    }
    
    @Override
    public byte getByte(final String s) throws SQLException {
        return this.callableStatement.getByte(s);
    }
    
    @Override
    public byte[] getBytes(final String s) throws SQLException {
        return this.callableStatement.getBytes(s);
    }
    
    @Override
    public Clob getClob(final String s) throws SQLException {
        return this.callableStatement.getClob(s);
    }
    
    @Override
    public Date getDate(final String s) throws SQLException {
        return this.callableStatement.getDate(s);
    }
    
    @Override
    public Date getDate(final String s, final Calendar calendar) throws SQLException {
        return this.callableStatement.getDate(s, calendar);
    }
    
    @Override
    public double getDouble(final String s) throws SQLException {
        return this.callableStatement.getDouble(s);
    }
    
    @Override
    public float getFloat(final String s) throws SQLException {
        return this.callableStatement.getFloat(s);
    }
    
    @Override
    public int getInt(final String s) throws SQLException {
        return this.callableStatement.getInt(s);
    }
    
    @Override
    public long getLong(final String s) throws SQLException {
        return this.callableStatement.getLong(s);
    }
    
    @Override
    public NClob getNClob(final String s) throws SQLException {
        return this.callableStatement.getNClob(s);
    }
    
    @Override
    public String getNString(final String s) throws SQLException {
        return this.callableStatement.getNString(s);
    }
    
    @Override
    public Object getObject(final String s) throws SQLException {
        return this.callableStatement.getObject(s);
    }
    
    @Override
    public Object getObject(final String s, final Map map) throws SQLException {
        return this.callableStatement.getObject(s, map);
    }
    
    @Override
    public Ref getRef(final String s) throws SQLException {
        return this.callableStatement.getRef(s);
    }
    
    @Override
    public RowId getRowId(final String s) throws SQLException {
        return this.callableStatement.getRowId(s);
    }
    
    @Override
    public short getShort(final String s) throws SQLException {
        return this.callableStatement.getShort(s);
    }
    
    @Override
    public SQLXML getSQLXML(final String s) throws SQLException {
        return this.callableStatement.getSQLXML(s);
    }
    
    @Override
    public String getString(final String s) throws SQLException {
        return this.callableStatement.getString(s);
    }
    
    @Override
    public Time getTime(final String s) throws SQLException {
        return this.callableStatement.getTime(s);
    }
    
    @Override
    public Time getTime(final String s, final Calendar calendar) throws SQLException {
        return this.callableStatement.getTime(s, calendar);
    }
    
    @Override
    public Timestamp getTimestamp(final String s) throws SQLException {
        return this.callableStatement.getTimestamp(s);
    }
    
    @Override
    public Timestamp getTimestamp(final String s, final Calendar calendar) throws SQLException {
        return this.callableStatement.getTimestamp(s, calendar);
    }
    
    @Override
    public URL getURL(final String s) throws SQLException {
        return this.callableStatement.getURL(s);
    }
    
    @Override
    public InputStream getAsciiStream(final String s) throws SQLException {
        return this.callableStatement.getAsciiStream(s);
    }
    
    @Override
    public InputStream getBinaryStream(final String s) throws SQLException {
        return this.callableStatement.getBinaryStream(s);
    }
    
    @Override
    public Reader getCharacterStream(final String s) throws SQLException {
        return this.callableStatement.getCharacterStream(s);
    }
    
    @Override
    public Reader getNCharacterStream(final String s) throws SQLException {
        return this.callableStatement.getNCharacterStream(s);
    }
    
    @Override
    public InputStream getUnicodeStream(final String s) throws SQLException {
        return this.callableStatement.getUnicodeStream(s);
    }
    
    @Override
    public void setObject(final String s, final Object o, final int n, final int n2) throws SQLException {
        this.callableStatement.setObject(s, o, n, n2);
    }
    
    @Override
    public Object getAnyDataEmbeddedObject(final int n) throws SQLException {
        return this.callableStatement.getAnyDataEmbeddedObject(n);
    }
    
    @Override
    public void setStructDescriptor(final int n, final StructDescriptor structDescriptor) throws SQLException {
        this.callableStatement.setStructDescriptor(n, structDescriptor);
    }
    
    @Override
    public void setStructDescriptor(final String s, final StructDescriptor structDescriptor) throws SQLException {
        this.callableStatement.setStructDescriptor(s, structDescriptor);
    }
    
    @Override
    public void close() throws SQLException {
        super.close();
    }
    
    @Override
    public void closeWithKey(final String s) throws SQLException {
        this.callableStatement.closeWithKey(s);
        final OracleCallableStatement closedStatement = OracleCallableStatementWrapper.closedStatement;
        this.callableStatement = closedStatement;
        this.preparedStatement = closedStatement;
        this.statement = closedStatement;
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final int n3, final int n4) throws SQLException {
        this.callableStatement.registerOutParameter(n, n2, n3, n4);
    }
    
    @Override
    public void registerOutParameterBytes(final int n, final int n2, final int n3, final int n4) throws SQLException {
        this.callableStatement.registerOutParameterBytes(n, n2, n3, n4);
    }
    
    @Override
    public void registerOutParameterChars(final int n, final int n2, final int n3, final int n4) throws SQLException {
        this.callableStatement.registerOutParameterChars(n, n2, n3, n4);
    }
    
    @Override
    public void registerIndexTableOutParameter(final int n, final int n2, final int n3, final int n4) throws SQLException {
        this.callableStatement.registerIndexTableOutParameter(n, n2, n3, n4);
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final int n2, final int n3) throws SQLException {
        this.callableStatement.registerOutParameter(s, n, n2, n3);
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final String s2) throws SQLException {
        this.callableStatement.registerOutParameter(s, n, s2);
    }
    
    @Override
    public int sendBatch() throws SQLException {
        return this.callableStatement.sendBatch();
    }
    
    @Override
    public void setExecuteBatch(final int executeBatch) throws SQLException {
        this.callableStatement.setExecuteBatch(executeBatch);
    }
    
    @Override
    public Object getPlsqlIndexTable(final int n) throws SQLException {
        return this.callableStatement.getPlsqlIndexTable(n);
    }
    
    @Override
    public Object getPlsqlIndexTable(final int n, final Class clazz) throws SQLException {
        return this.callableStatement.getPlsqlIndexTable(n, clazz);
    }
    
    @Override
    public Datum[] getOraclePlsqlIndexTable(final int n) throws SQLException {
        return this.callableStatement.getOraclePlsqlIndexTable(n);
    }
    
    @Override
    public void setStringForClob(final String s, final String s2) throws SQLException {
        this.callableStatement.setStringForClob(s, s2);
    }
    
    @Override
    public void setBytesForBlob(final String s, final byte[] array) throws SQLException {
        this.callableStatement.setBytesForBlob(s, array);
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        return this.callableStatement.wasNull();
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2) throws SQLException {
        this.callableStatement.registerOutParameter(n, n2);
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final int n3) throws SQLException {
        this.callableStatement.registerOutParameter(n, n2, n3);
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final String s) throws SQLException {
        this.callableStatement.registerOutParameter(n, n2, s);
    }
    
    @Override
    public void registerOutParameter(final String s, final int n) throws SQLException {
        this.callableStatement.registerOutParameter(s, n);
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final int n2) throws SQLException {
        this.callableStatement.registerOutParameter(s, n, n2);
    }
    
    @Override
    public byte[] privateGetBytes(final int n) throws SQLException {
        return ((oracle.jdbc.driver.OracleCallableStatement)this.callableStatement).privateGetBytes(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
