// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;

final class T4C7Ocommoncall extends T4CTTIfun
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C7Ocommoncall(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
    }
    
    void doOLOGOFF() throws SQLException, IOException {
        this.setFunCode((short)9);
        this.doRPC();
    }
    
    void doOROLLBACK() throws SQLException, IOException {
        this.setFunCode((short)15);
        this.doRPC();
    }
    
    void doOCOMMIT() throws SQLException, IOException {
        this.setFunCode((short)14);
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
    }
    
    @Override
    void processError() throws SQLException {
        if (this.oer.retCode != 2089) {
            this.oer.processError();
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
