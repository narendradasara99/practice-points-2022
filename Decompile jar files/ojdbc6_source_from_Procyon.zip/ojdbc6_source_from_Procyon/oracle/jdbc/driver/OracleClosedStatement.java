// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.sql.StructDescriptor;
import oracle.jdbc.OracleParameterMetaData;
import java.sql.ResultSetMetaData;
import java.sql.ParameterMetaData;
import oracle.jdbc.OracleResultSetCache;
import java.sql.SQLWarning;
import java.sql.Connection;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatumFactory;
import java.util.Map;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.ORAData;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.DATE;
import oracle.sql.CustomDatum;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.Ref;
import java.sql.NClob;
import java.util.Calendar;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Array;
import oracle.jdbc.internal.OracleCallableStatement;

class OracleClosedStatement implements OracleCallableStatement
{
    private OracleStatement wrapper;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleClosedStatement() {
    }
    
    @Override
    public void setArray(final int n, final Array array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setArrayAtName(final String s, final Array array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setArray(final String s, final Array array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBigDecimal(final int n, final BigDecimal bigDecimal) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBigDecimalAtName(final String s, final BigDecimal bigDecimal) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBigDecimal(final String s, final BigDecimal bigDecimal) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlob(final int n, final Blob blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlobAtName(final String s, final Blob blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlob(final String s, final Blob blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBoolean(final int n, final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBooleanAtName(final String s, final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBoolean(final String s, final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setByte(final int n, final byte b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setByteAtName(final String s, final byte b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setByte(final String s, final byte b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBytes(final int n, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBytesAtName(final String s, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBytes(final String s, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClob(final int n, final Clob clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClobAtName(final String s, final Clob clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClob(final String s, final Clob clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDate(final int n, final Date date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDateAtName(final String s, final Date date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDate(final String s, final Date date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDate(final int n, final Date date, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDateAtName(final String s, final Date date, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDate(final String s, final Date date, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDouble(final int n, final double n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDoubleAtName(final String s, final double n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDouble(final String s, final double n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFloat(final int n, final float n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFloatAtName(final String s, final float n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFloat(final String s, final float n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setInt(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setIntAtName(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setInt(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setLong(final int n, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setLongAtName(final String s, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setLong(final String s, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClob(final int n, final NClob nClob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClobAtName(final String s, final NClob nClob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClob(final String s, final NClob nClob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNString(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNStringAtName(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNString(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObject(final int n, final Object o) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObject(final String s, final Object o) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObject(final String s, final Object o, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRef(final int n, final Ref ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRefAtName(final String s, final Ref ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRef(final String s, final Ref ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRowId(final int n, final RowId rowId) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRowIdAtName(final String s, final RowId rowId) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRowId(final String s, final RowId rowId) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setShort(final int n, final short n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setShortAtName(final String s, final short n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setShort(final String s, final short n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setSQLXML(final int n, final SQLXML sqlxml) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setSQLXMLAtName(final String s, final SQLXML sqlxml) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setSQLXML(final String s, final SQLXML sqlxml) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setString(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStringAtName(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setString(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTime(final int n, final Time time) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimeAtName(final String s, final Time time) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTime(final String s, final Time time) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTime(final int n, final Time time, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimeAtName(final String s, final Time time, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTime(final String s, final Time time, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimestampAtName(final String s, final Timestamp timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimestamp(final String s, final Timestamp timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimestampAtName(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTimestamp(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setURL(final int n, final URL url) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setURLAtName(final String s, final URL url) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setURL(final String s, final URL url) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setARRAY(final int n, final ARRAY array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setARRAYAtName(final String s, final ARRAY array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setARRAY(final String s, final ARRAY array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBFILE(final int n, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBFILEAtName(final String s, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBFILE(final String s, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBfile(final int n, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBfileAtName(final String s, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBfile(final String s, final BFILE bfile) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryFloat(final int n, final float n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryFloatAtName(final String s, final float n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryFloat(final String s, final float n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryFloat(final int n, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryFloatAtName(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryFloat(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryDouble(final int n, final double n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryDoubleAtName(final String s, final double n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryDouble(final String s, final double n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryDouble(final int n, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryDoubleAtName(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryDouble(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBLOB(final int n, final BLOB blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBLOBAtName(final String s, final BLOB blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBLOB(final String s, final BLOB blob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCHAR(final int n, final CHAR char1) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCHARAtName(final String s, final CHAR char1) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCHAR(final String s, final CHAR char1) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCLOB(final int n, final CLOB clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCLOBAtName(final String s, final CLOB clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCLOB(final String s, final CLOB clob) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCursor(final int n, final ResultSet set) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCursorAtName(final String s, final ResultSet set) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCursor(final String s, final ResultSet set) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCustomDatum(final int n, final CustomDatum customDatum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCustomDatumAtName(final String s, final CustomDatum customDatum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCustomDatum(final String s, final CustomDatum customDatum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDATE(final int n, final DATE date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDATEAtName(final String s, final DATE date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDATE(final String s, final DATE date) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFixedCHAR(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFixedCHARAtName(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFixedCHAR(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setINTERVALDS(final int n, final INTERVALDS intervalds) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setINTERVALDSAtName(final String s, final INTERVALDS intervalds) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setINTERVALDS(final String s, final INTERVALDS intervalds) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setINTERVALYM(final int n, final INTERVALYM intervalym) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setINTERVALYMAtName(final String s, final INTERVALYM intervalym) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setINTERVALYM(final String s, final INTERVALYM intervalym) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNUMBER(final int n, final NUMBER number) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNUMBERAtName(final String s, final NUMBER number) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNUMBER(final String s, final NUMBER number) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setOPAQUE(final int n, final OPAQUE opaque) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setOPAQUEAtName(final String s, final OPAQUE opaque) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setOPAQUE(final String s, final OPAQUE opaque) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setOracleObject(final int n, final Datum datum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setOracleObjectAtName(final String s, final Datum datum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setOracleObject(final String s, final Datum datum) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setORAData(final int n, final ORAData oraData) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setORADataAtName(final String s, final ORAData oraData) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setORAData(final String s, final ORAData oraData) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRAW(final int n, final RAW raw) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRAWAtName(final String s, final RAW raw) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRAW(final String s, final RAW raw) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setREF(final int n, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setREFAtName(final String s, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setREF(final String s, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRefType(final int n, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRefTypeAtName(final String s, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRefType(final String s, final REF ref) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setROWID(final int n, final ROWID rowid) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setROWIDAtName(final String s, final ROWID rowid) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setROWID(final String s, final ROWID rowid) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setSTRUCT(final int n, final STRUCT struct) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setSTRUCTAtName(final String s, final STRUCT struct) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setSTRUCT(final String s, final STRUCT struct) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPLTZ(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPLTZAtName(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPLTZ(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPTZ(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPTZAtName(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPTZ(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMP(final int n, final TIMESTAMP timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMPAtName(final String s, final TIMESTAMP timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setTIMESTAMP(final String s, final TIMESTAMP timestamp) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlobAtName(final String s, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlob(final String s, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlobAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBlob(final String s, final InputStream inputStream, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClob(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClobAtName(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClob(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClob(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClobAtName(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setClob(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClob(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClobAtName(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClob(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClob(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClobAtName(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNClob(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNCharacterStreamAtName(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNCharacterStream(final String s, final Reader reader) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNCharacterStreamAtName(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setUnicodeStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setUnicodeStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setUnicodeStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Array getArray(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Array getArray(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Blob getBlob(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Blob getBlob(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean getBoolean(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean getBoolean(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public byte getByte(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public byte getByte(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public byte[] getBytes(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public byte[] getBytes(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Clob getClob(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Clob getClob(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Date getDate(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Date getDate(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Date getDate(final int n, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Date getDate(final String s, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public double getDouble(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public double getDouble(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public float getFloat(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public float getFloat(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getInt(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getInt(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public long getLong(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public long getLong(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public NClob getNClob(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public NClob getNClob(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public String getNString(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public String getNString(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getObject(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getObject(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getObject(final int n, final Map map) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getObject(final String s, final Map map) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Ref getRef(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Ref getRef(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public RowId getRowId(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public RowId getRowId(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public short getShort(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public short getShort(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public SQLXML getSQLXML(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public SQLXML getSQLXML(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public String getString(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public String getString(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Time getTime(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Time getTime(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Time getTime(final int n, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Time getTime(final String s, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Timestamp getTimestamp(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Timestamp getTimestamp(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Timestamp getTimestamp(final String s, final Calendar calendar) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public URL getURL(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public URL getURL(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ARRAY getARRAY(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public ARRAY getARRAY(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BFILE getBFILE(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public BFILE getBFILE(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BFILE getBfile(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public BFILE getBfile(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BLOB getBLOB(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public BLOB getBLOB(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public CHAR getCHAR(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public CHAR getCHAR(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public CLOB getCLOB(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public CLOB getCLOB(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSet getCursor(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public ResultSet getCursor(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public CustomDatum getCustomDatum(final int n, final CustomDatumFactory customDatumFactory) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public CustomDatum getCustomDatum(final String s, final CustomDatumFactory customDatumFactory) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public DATE getDATE(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public DATE getDATE(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public INTERVALDS getINTERVALDS(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public INTERVALYM getINTERVALYM(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public NUMBER getNUMBER(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public NUMBER getNUMBER(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public OPAQUE getOPAQUE(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public OPAQUE getOPAQUE(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Datum getOracleObject(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public Datum getOracleObject(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ORAData getORAData(final int n, final ORADataFactory oraDataFactory) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public ORAData getORAData(final String s, final ORADataFactory oraDataFactory) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public RAW getRAW(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public RAW getRAW(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public REF getREF(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public REF getREF(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ROWID getROWID(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public ROWID getROWID(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public STRUCT getSTRUCT(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public STRUCT getSTRUCT(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public TIMESTAMPTZ getTIMESTAMPTZ(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public TIMESTAMP getTIMESTAMP(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public InputStream getAsciiStream(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public InputStream getAsciiStream(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public InputStream getBinaryStream(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public InputStream getBinaryStream(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Reader getCharacterStream(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Reader getCharacterStream(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Reader getNCharacterStream(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Reader getNCharacterStream(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public InputStream getUnicodeStream(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public InputStream getUnicodeStream(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNull(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNull(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNull(final int n, final int n2, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNull(final String s, final int n, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNullAtName(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setNullAtName(final String s, final int n, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObject(final String s, final Object o, final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o, final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getMaxFieldSize() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getMaxRows() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getQueryTimeout() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getResultSetConcurrency() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getResultSetHoldability() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getResultSetType() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getUpdateCount() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void cancel() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void clearBatch() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void close() throws SQLException {
    }
    
    @Override
    public boolean getMoreResults() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int[] executeBatch() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFetchDirection(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFetchSize(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setMaxFieldSize(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setMaxRows(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setQueryTimeout(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean getMoreResults(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setEscapeProcessing(final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int executeUpdate(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void addBatch(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setCursorName(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean execute(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int executeUpdate(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean execute(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int executeUpdate(final String s, final int[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean execute(final String s, final int[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSet getResultSet() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int executeUpdate(final String s, final String[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean execute(final String s, final String[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSet executeQuery(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void clearDefines() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineColumnType(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final int n3, final short n4) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineColumnTypeBytes(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineColumnTypeChars(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getRowPrefetch() {
        return -1;
    }
    
    @Override
    public void setResultSetCache(final OracleResultSetCache oracleResultSetCache) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setRowPrefetch(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getLobPrefetchSize() {
        return -1;
    }
    
    @Override
    public void setLobPrefetchSize(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void closeWithKey(final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int creationState() {
        return -1;
    }
    
    @Override
    public boolean isNCHAR(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int executeUpdate() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void addBatch() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void clearParameters() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean execute() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ParameterMetaData getParameterMetaData() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSet executeQuery() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSet getReturnResultSet() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineParameterTypeBytes(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineParameterTypeChars(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void defineParameterType(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getExecuteBatch() {
        return -1;
    }
    
    @Override
    public int sendBatch() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setExecuteBatch(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setPlsqlIndexTable(final int n, final Object o, final int n2, final int n3, final int n4, final int n5) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFormOfUse(final int n, final short n2) {
    }
    
    @Override
    public void setDisableStmtCaching(final boolean b) {
    }
    
    @Override
    public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBytesForBlob(final int n, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBytesForBlobAtName(final String s, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStringForClob(final int n, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStringForClobAtName(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStructDescriptor(final int n, final StructDescriptor structDescriptor) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStructDescriptor(final String s, final StructDescriptor structDescriptor) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStructDescriptorAtName(final String s, final StructDescriptor structDescriptor) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getAnyDataEmbeddedObject(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final int n3, final int n4) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final String s) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameterBytes(final int n, final int n2, final int n3, final int n4) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameterChars(final int n, final int n2, final int n3, final int n4) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getPlsqlIndexTable(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getPlsqlIndexTable(final int n, final Class clazz) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Datum[] getOraclePlsqlIndexTable(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerIndexTableOutParameter(final int n, final int n2, final int n3, final int n4) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setStringForClob(final String s, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setBytesForBlob(final String s, final byte[] array) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final int n2, final int n3) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final String s, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final String s2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public byte[] privateGetBytes(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setDatabaseChangeRegistration(final DatabaseChangeRegistration databaseChangeRegistration) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean isClosed() throws SQLException {
        return true;
    }
    
    @Override
    public boolean isPoolable() throws SQLException {
        return false;
    }
    
    @Override
    public void setPoolable(final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFixedString(final boolean b) {
    }
    
    @Override
    public boolean getFixedString() {
        return false;
    }
    
    @Override
    public boolean getserverCursor() {
        return false;
    }
    
    @Override
    public int getcacheState() {
        return 0;
    }
    
    @Override
    public int getstatementType() {
        return 3;
    }
    
    @Override
    public void setCheckBindTypes(final boolean b) {
    }
    
    @Override
    public void setInternalBytes(final int n, final byte[] array, final int n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void enterImplicitCache() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void enterExplicitCache() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void exitImplicitCacheToActive() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void exitExplicitCacheToActive() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void exitImplicitCacheToClose() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void exitExplicitCacheToClose() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public String[] getRegisteredTableNames() throws SQLException {
        return null;
    }
    
    @Override
    public long getRegisteredQueryId() throws SQLException {
        return -1L;
    }
    
    @Override
    public String getOriginalSql() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
