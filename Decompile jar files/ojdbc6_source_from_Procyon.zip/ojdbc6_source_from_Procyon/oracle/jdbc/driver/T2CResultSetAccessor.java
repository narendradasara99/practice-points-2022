// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class T2CResultSetAccessor extends ResultSetAccessor
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T2CResultSetAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        super(oracleStatement, n * 2, n2, n3, b);
    }
    
    T2CResultSetAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        super(oracleStatement, n * 2, b, n2, n3, n4, n5, n6, n7);
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        byte[] array = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final byte byteAlign = ((T2CConnection)this.statement.connection).byteAlign;
            final int n3 = (this.columnIndex + (byteAlign - 1) & ~(byteAlign - 1)) + n2 * n;
            array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
        }
        return array;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
