// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.nio.ByteBuffer;
import oracle.sql.CharacterSet;
import oracle.jdbc.dcn.RowChangeDescription;
import java.util.EnumSet;
import oracle.jdbc.dcn.TableChangeDescription;

class NTFDCNTableChanges implements TableChangeDescription
{
    final EnumSet<TableOperation> opcode;
    String tableName;
    final int objectNumber;
    final int numberOfRows;
    final RowChangeDescription.RowOperation[] rowOpcode;
    final int[] rowIdLength;
    final byte[][] rowid;
    final CharacterSet charset;
    NTFDCNRowChanges[] rowsDescription;
    private static final byte OPERATION_ANY = 0;
    private static final byte OPERATION_UNKNOWN = 64;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFDCNTableChanges(final ByteBuffer byteBuffer, final int n) {
        this.rowsDescription = null;
        this.charset = CharacterSet.make(n);
        this.opcode = TableOperation.getTableOperations(byteBuffer.getInt());
        final short short1 = byteBuffer.getShort();
        final byte[] dst = new byte[short1];
        byteBuffer.get(dst, 0, short1);
        this.tableName = this.charset.toStringWithReplacement(dst, 0, short1);
        this.objectNumber = byteBuffer.getInt();
        if (!this.opcode.contains(TableOperation.ALL_ROWS)) {
            this.numberOfRows = byteBuffer.getShort();
            this.rowOpcode = new RowChangeDescription.RowOperation[this.numberOfRows];
            this.rowIdLength = new int[this.numberOfRows];
            this.rowid = new byte[this.numberOfRows][];
            for (int i = 0; i < this.numberOfRows; ++i) {
                this.rowOpcode[i] = RowChangeDescription.RowOperation.getRowOperation(byteBuffer.getInt());
                this.rowIdLength[i] = byteBuffer.getShort();
                byteBuffer.get(this.rowid[i] = new byte[this.rowIdLength[i]], 0, this.rowIdLength[i]);
            }
        }
        else {
            this.numberOfRows = 0;
            this.rowid = null;
            this.rowOpcode = null;
            this.rowIdLength = null;
        }
    }
    
    @Override
    public String getTableName() {
        return this.tableName;
    }
    
    @Override
    public int getObjectNumber() {
        return this.objectNumber;
    }
    
    @Override
    public RowChangeDescription[] getRowChangeDescription() {
        if (this.rowsDescription == null) {
            synchronized (this) {
                if (this.rowsDescription == null) {
                    this.rowsDescription = new NTFDCNRowChanges[this.numberOfRows];
                    for (int i = 0; i < this.rowsDescription.length; ++i) {
                        this.rowsDescription[i] = new NTFDCNRowChanges(this.rowOpcode[i], this.rowIdLength[i], this.rowid[i]);
                    }
                }
            }
        }
        return this.rowsDescription;
    }
    
    @Override
    public EnumSet<TableOperation> getTableOperations() {
        return this.opcode;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("    operation=" + this.getTableOperations() + ", tableName=" + this.tableName + ", objectNumber=" + this.objectNumber + "\n");
        final RowChangeDescription[] rowChangeDescription = this.getRowChangeDescription();
        if (rowChangeDescription != null && rowChangeDescription.length > 0) {
            sb.append("    Row Change Description (length=" + rowChangeDescription.length + "):\n");
            for (int i = 0; i < rowChangeDescription.length; ++i) {
                sb.append(rowChangeDescription[i].toString());
            }
        }
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
