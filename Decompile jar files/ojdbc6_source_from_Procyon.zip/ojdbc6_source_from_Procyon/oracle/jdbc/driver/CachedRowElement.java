// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.Datum;
import oracle.jdbc.OracleResultSet;

class CachedRowElement
{
    private final int row;
    private final int col;
    private final OracleResultSet.AuthorizationIndicator securityIndicator;
    private final byte[] data;
    private Datum dataAsDatum;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CachedRowElement(final int row, final int col, final OracleResultSet.AuthorizationIndicator securityIndicator, final byte[] data) {
        this.row = row;
        this.col = col;
        this.securityIndicator = securityIndicator;
        this.data = data;
        this.dataAsDatum = null;
    }
    
    OracleResultSet.AuthorizationIndicator getIndicator() {
        return this.securityIndicator;
    }
    
    void setData(final Datum dataAsDatum) {
        this.dataAsDatum = dataAsDatum;
    }
    
    byte[] getData() {
        return this.data;
    }
    
    Datum getDataAsDatum() {
        return this.dataAsDatum;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
