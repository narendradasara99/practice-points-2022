// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class T4CKvaldfList
{
    static final int INTIAL_CAPACITY = 30;
    private int capacity;
    private int offset;
    private byte[][] keys;
    private byte[][] values;
    private byte[] flags;
    DBConversion conv;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CKvaldfList(final DBConversion conv) {
        this.conv = conv;
        this.initializeList();
    }
    
    void initializeList() {
        this.capacity = 30;
        this.offset = 0;
        this.keys = new byte[this.capacity][];
        this.values = new byte[this.capacity][];
        this.flags = new byte[this.capacity];
    }
    
    void add(final byte[] array, final byte[] array2, final byte b) {
        if (this.offset == this.capacity) {
            final byte[][] keys = new byte[this.capacity * 2][];
            final byte[][] values = new byte[this.capacity * 2][];
            final byte[] flags = new byte[this.capacity * 2];
            System.arraycopy(this.keys, 0, keys, 0, this.capacity);
            System.arraycopy(this.values, 0, values, 0, this.capacity);
            System.arraycopy(this.flags, 0, flags, 0, this.capacity);
            this.keys = keys;
            this.values = values;
            this.flags = flags;
            this.capacity *= 2;
        }
        this.keys[this.offset] = array;
        this.values[this.offset] = array2;
        this.flags[this.offset++] = b;
    }
    
    void add(final byte[] array, final byte[] array2) {
        this.add(array, array2, (byte)0);
    }
    
    void add(final String s, final byte[] array) throws SQLException {
        this.add(this.conv.StringToCharBytes(s), array, (byte)0);
    }
    
    void add(final String s, final byte[] array, final byte b) throws SQLException {
        this.add(this.conv.StringToCharBytes(s), array, b);
    }
    
    int size() {
        return this.offset;
    }
    
    byte[][] getKeys() {
        return this.keys;
    }
    
    byte[][] getValues() {
        return this.values;
    }
    
    byte[] getFlags() {
        return this.flags;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
