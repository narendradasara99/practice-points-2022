// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.io.InputStream;

abstract class OracleBufferedStream extends InputStream
{
    byte[] resizableBuffer;
    int initialBufferSize;
    int currentBufferSize;
    int pos;
    int count;
    long maxPosition;
    boolean closed;
    OracleStatement statement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleBufferedStream(final int initialBufferSize) {
        this.maxPosition = 2147483647L;
        this.pos = 0;
        this.count = 0;
        this.closed = false;
        this.initialBufferSize = initialBufferSize;
        this.currentBufferSize = 0;
        this.resizableBuffer = null;
    }
    
    public OracleBufferedStream(final OracleStatement statement, final int n) {
        this(n);
        this.statement = statement;
    }
    
    @Override
    public void close() throws IOException {
        this.closed = true;
        this.resizableBuffer = null;
    }
    
    public boolean needBytes() throws IOException {
        return this.needBytes(Math.max(this.initialBufferSize, this.currentBufferSize));
    }
    
    public abstract boolean needBytes(final int p0) throws IOException;
    
    public int flushBytes(final int n) {
        final int n2 = (n > this.count - this.pos) ? (this.count - this.pos) : n;
        this.pos += n2;
        return n2;
    }
    
    public int writeBytes(final byte[] array, final int n, final int n2) {
        final int n3 = (n2 > this.count - this.pos) ? (this.count - this.pos) : n2;
        System.arraycopy(this.resizableBuffer, this.pos, array, n, n3);
        this.pos += n3;
        return n3;
    }
    
    @Override
    public int read() throws IOException {
        if (this.statement == null) {
            synchronized (this) {
                return this.readInternal();
            }
        }
        synchronized (this.statement.connection) {
            return this.readInternal();
        }
    }
    
    private final int readInternal() throws IOException {
        if (this.closed || this.isNull()) {
            return -1;
        }
        if (this.needBytes()) {
            return this.resizableBuffer[this.pos++] & 0xFF;
        }
        return -1;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) throws IOException {
        if (this.statement == null) {
            synchronized (this) {
                return this.readInternal(array, n, n2);
            }
        }
        synchronized (this.statement.connection) {
            return this.readInternal(array, n, n2);
        }
    }
    
    private final int readInternal(final byte[] array, final int n, final int n2) throws IOException {
        if (this.closed || this.isNull()) {
            return -1;
        }
        int n3;
        if (n2 > array.length) {
            n3 = n + array.length;
        }
        else {
            n3 = n + n2;
        }
        if (!this.needBytes(n2)) {
            return -1;
        }
        int n4;
        for (n4 = n + this.writeBytes(array, n, n3 - n); n4 < n3 && this.needBytes(n3 - n4); n4 += this.writeBytes(array, n4, n3 - n4)) {}
        return n4 - n;
    }
    
    @Override
    public int available() throws IOException {
        if (this.closed || this.isNull()) {
            return 0;
        }
        return this.count - this.pos;
    }
    
    public boolean isNull() throws IOException {
        return false;
    }
    
    @Override
    public void mark(final int n) {
    }
    
    @Override
    public void reset() throws IOException {
        synchronized (this.statement.connection) {
            throw new IOException(DatabaseError.findMessage(194, null));
        }
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
    
    public long skip(final int n) throws IOException {
        if (this.statement == null) {
            synchronized (this) {
                return this.skipInternal(n);
            }
        }
        synchronized (this.statement.connection) {
            return this.skipInternal(n);
        }
    }
    
    private final int skipInternal(final int n) throws IOException {
        int n2 = 0;
        if (this.closed || this.isNull()) {
            return -1;
        }
        if (!this.needBytes()) {
            return -1;
        }
        while (n2 < n && this.needBytes()) {
            n2 += this.flushBytes(n - n2);
        }
        return n2;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.statement.getConnectionDuringExceptionHandling();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
