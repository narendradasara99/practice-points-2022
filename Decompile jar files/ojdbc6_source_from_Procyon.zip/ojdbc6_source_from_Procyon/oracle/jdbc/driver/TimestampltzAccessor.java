// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.TIMEZONETAB;
import oracle.sql.ZONEIDMAP;
import oracle.sql.OffsetDST;
import oracle.sql.DATE;
import oracle.sql.TIMESTAMP;
import java.sql.Connection;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import java.util.Map;
import oracle.sql.Datum;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.util.Calendar;
import java.util.TimeZone;
import java.sql.SQLException;

class TimestampltzAccessor extends DateTimeCommonAccessor
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    TimestampltzAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 231, 231, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    TimestampltzAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 231, 231, n7, false);
        this.initForDescribe(231, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 11;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        final Calendar dbTzCalendar = this.statement.connection.getDbTzCalendar();
        final String sessionTimeZone = this.statement.connection.getSessionTimeZone();
        if (sessionTimeZone == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 198);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        final int n2 = this.columnIndex + this.byteLength * n;
        final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
        dbTzCalendar.set(1, ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100);
        dbTzCalendar.set(2, this.oracleMonth(n2));
        dbTzCalendar.set(5, this.oracleDay(n2));
        dbTzCalendar.set(11, this.oracleHour(n2));
        dbTzCalendar.set(12, this.oracleMin(n2));
        dbTzCalendar.set(13, this.oracleSec(n2));
        dbTzCalendar.set(14, 0);
        this.TimeZoneAdjust(dbTzCalendar, instance);
        final int value = instance.get(1);
        final int n4 = instance.get(2) + 1;
        final int value2 = instance.get(5);
        final int value3 = instance.get(11);
        final int value4 = instance.get(12);
        final int value5 = instance.get(13);
        int oracleNanos = 0;
        final boolean b = value3 < 12;
        String s = instance.getTimeZone().getID();
        if (s.length() > 3 && s.startsWith("GMT")) {
            s = s.substring(3);
        }
        if (n3 == 11) {
            oracleNanos = this.oracleNanos(n2);
        }
        return this.toText(value, n4, value2, value3, value4, value5, oracleNanos, b, s);
    }
    
    @Override
    Date getDate(final int n, final Calendar calendar) throws SQLException {
        return this.getDate(n);
    }
    
    @Override
    Date getDate(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        final Calendar dbTzCalendar = this.statement.connection.getDbTzCalendar();
        final String sessionTimeZone = this.statement.connection.getSessionTimeZone();
        if (sessionTimeZone == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 198);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        final int n2 = this.columnIndex + this.byteLength * n;
        dbTzCalendar.set(1, ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100);
        dbTzCalendar.set(2, this.oracleMonth(n2));
        dbTzCalendar.set(5, this.oracleDay(n2));
        dbTzCalendar.set(11, this.oracleHour(n2));
        dbTzCalendar.set(12, this.oracleMin(n2));
        dbTzCalendar.set(13, this.oracleSec(n2));
        dbTzCalendar.set(14, 0);
        return new Date(this.TimeZoneAdjustUTC(dbTzCalendar, instance));
    }
    
    @Override
    Time getTime(final int n, final Calendar calendar) throws SQLException {
        return this.getTime(n);
    }
    
    @Override
    Time getTime(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        final Calendar dbTzCalendar = this.statement.connection.getDbTzCalendar();
        final String sessionTimeZone = this.statement.connection.getSessionTimeZone();
        if (sessionTimeZone == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 198);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        final int n2 = this.columnIndex + this.byteLength * n;
        dbTzCalendar.set(1, ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100);
        dbTzCalendar.set(2, this.oracleMonth(n2));
        dbTzCalendar.set(5, this.oracleDay(n2));
        dbTzCalendar.set(11, this.oracleHour(n2));
        dbTzCalendar.set(12, this.oracleMin(n2));
        dbTzCalendar.set(13, this.oracleSec(n2));
        dbTzCalendar.set(14, 0);
        return new Time(this.TimeZoneAdjustUTC(dbTzCalendar, instance));
    }
    
    @Override
    Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        return this.getTimestamp(n);
    }
    
    @Override
    Timestamp getTimestamp(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        final Calendar dbTzCalendar = this.statement.connection.getDbTzCalendar();
        final String sessionTimeZone = this.statement.connection.getSessionTimeZone();
        if (sessionTimeZone == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 198);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone(sessionTimeZone));
        final int n2 = this.columnIndex + this.byteLength * n;
        final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
        dbTzCalendar.set(1, ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100);
        dbTzCalendar.set(2, this.oracleMonth(n2));
        dbTzCalendar.set(5, this.oracleDay(n2));
        dbTzCalendar.set(11, this.oracleHour(n2));
        dbTzCalendar.set(12, this.oracleMin(n2));
        dbTzCalendar.set(13, this.oracleSec(n2));
        dbTzCalendar.set(14, 0);
        final Timestamp timestamp = new Timestamp(this.TimeZoneAdjustUTC(dbTzCalendar, instance));
        if (n3 == 11) {
            timestamp.setNanos(this.oracleNanos(n2));
        }
        return timestamp;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getTIMESTAMPLTZ(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getTIMESTAMPLTZ(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getTIMESTAMPLTZ(n);
    }
    
    @Override
    TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        TIMESTAMPLTZ timestampltz = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            final byte[] array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
            timestampltz = new TIMESTAMPLTZ(array);
        }
        return timestampltz;
    }
    
    @Override
    TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        TIMESTAMPTZ timestamptz = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            final byte[] array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
            timestamptz = oracle.sql.TIMESTAMPLTZ.toTIMESTAMPTZ(this.statement.connection, array);
        }
        return timestamptz;
    }
    
    @Override
    TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        return oracle.sql.TIMESTAMPTZ.toTIMESTAMP(this.statement.connection, this.getTIMESTAMPTZ(n).getBytes());
    }
    
    @Override
    DATE getDATE(final int n) throws SQLException {
        return oracle.sql.TIMESTAMPTZ.toDATE(this.statement.connection, this.getTIMESTAMPTZ(n).getBytes());
    }
    
    void TimeZoneAdjust(final Calendar calendar, final Calendar calendar2) throws SQLException {
        final String id = calendar.getTimeZone().getID();
        final String id2 = calendar2.getTimeZone().getID();
        if (!id2.equals(id)) {
            final OffsetDST offsetDST = new OffsetDST();
            this.getZoneOffset(calendar, offsetDST);
            final int offset = offsetDST.getOFFSET();
            calendar.add(11, -(offset / 3600000));
            calendar.add(12, -(offset % 3600000) / 60000);
            int n;
            if (id2.equals("Custom") || (id2.startsWith("GMT") && id2.length() > 3)) {
                n = calendar2.getTimeZone().getRawOffset();
            }
            else {
                final int id3 = ZONEIDMAP.getID(id2);
                if (!ZONEIDMAP.isValidID(id3)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 199);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                final TIMEZONETAB timezonetab = this.statement.connection.getTIMEZONETAB();
                if (timezonetab.checkID(id3)) {
                    timezonetab.updateTable(this.statement.connection, id3);
                }
                final Calendar gmtCalendar = this.statement.getGMTCalendar();
                gmtCalendar.set(1, calendar.get(1));
                gmtCalendar.set(2, calendar.get(2));
                gmtCalendar.set(5, calendar.get(5));
                gmtCalendar.set(11, calendar.get(11));
                gmtCalendar.set(12, calendar.get(12));
                gmtCalendar.set(13, calendar.get(13));
                gmtCalendar.set(14, calendar.get(14));
                n = timezonetab.getOffset(gmtCalendar, id3);
            }
            calendar.add(11, n / 3600000);
            calendar.add(12, n % 3600000 / 60000);
        }
        if ((id2.equals("Custom") && id.equals("Custom")) || (id2.startsWith("GMT") && id2.length() > 3 && id.startsWith("GMT") && id.length() > 3)) {
            final int rawOffset = calendar.getTimeZone().getRawOffset();
            final int rawOffset2 = calendar2.getTimeZone().getRawOffset();
            int n2 = 0;
            if (rawOffset != rawOffset2) {
                final int n3 = rawOffset - rawOffset2;
                n2 = ((n3 > 0) ? n3 : (-n3));
            }
            if (rawOffset > rawOffset2) {
                n2 = -n2;
            }
            calendar.add(11, n2 / 3600000);
            calendar.add(12, n2 % 3600000 / 60000);
        }
        final int value = calendar.get(1);
        final int value2 = calendar.get(2);
        final int value3 = calendar.get(5);
        final int value4 = calendar.get(11);
        final int value5 = calendar.get(12);
        final int value6 = calendar.get(13);
        final int value7 = calendar.get(14);
        calendar2.set(1, value);
        calendar2.set(2, value2);
        calendar2.set(5, value3);
        calendar2.set(11, value4);
        calendar2.set(12, value5);
        calendar2.set(13, value6);
        calendar2.set(14, value7);
    }
    
    long TimeZoneAdjustUTC(final Calendar calendar, final Calendar calendar2) throws SQLException {
        final String id = calendar.getTimeZone().getID();
        final String id2 = calendar2.getTimeZone().getID();
        if (!id2.equals(id)) {
            final OffsetDST offsetDST = new OffsetDST();
            this.getZoneOffset(calendar, offsetDST);
            final int offset = offsetDST.getOFFSET();
            calendar.add(11, -(offset / 3600000));
            calendar.add(12, -(offset % 3600000) / 60000);
        }
        if ((id2.equals("Custom") && id.equals("Custom")) || (id2.startsWith("GMT") && id2.length() > 3 && id.startsWith("GMT") && id.length() > 3)) {
            final int rawOffset = calendar.getTimeZone().getRawOffset();
            if (rawOffset != calendar2.getTimeZone().getRawOffset()) {
                calendar.add(11, -(rawOffset / 3600000));
                calendar.add(12, -(rawOffset % 3600000) / 60000);
            }
        }
        final int value = calendar.get(1);
        final int value2 = calendar.get(2);
        final int value3 = calendar.get(5);
        final int value4 = calendar.get(11);
        final int value5 = calendar.get(12);
        final int value6 = calendar.get(13);
        final int value7 = calendar.get(14);
        final Calendar gmtCalendar = this.statement.getGMTCalendar();
        gmtCalendar.set(1, value);
        gmtCalendar.set(2, value2);
        gmtCalendar.set(5, value3);
        gmtCalendar.set(11, value4);
        gmtCalendar.set(12, value5);
        gmtCalendar.set(13, value6);
        gmtCalendar.set(14, value7);
        return gmtCalendar.getTimeInMillis();
    }
    
    byte getZoneOffset(final Calendar calendar, final OffsetDST offsetDST) throws SQLException {
        byte localOffset = 0;
        final String id = calendar.getTimeZone().getID();
        if (id == "Custom" || (id.startsWith("GMT") && id.length() > 3)) {
            offsetDST.setOFFSET(calendar.getTimeZone().getRawOffset());
        }
        else {
            final int id2 = ZONEIDMAP.getID(id);
            if (!ZONEIDMAP.isValidID(id2)) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 199);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final TIMEZONETAB timezonetab = this.statement.connection.getTIMEZONETAB();
            if (timezonetab.checkID(id2)) {
                timezonetab.updateTable(this.statement.connection, id2);
            }
            localOffset = timezonetab.getLocalOffset(calendar, id2, offsetDST);
        }
        return localOffset;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
