// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;

class LRUStatementCache
{
    private int cacheSize;
    private int numElements;
    private OracleStatementCacheEntry applicationCacheStart;
    private OracleStatementCacheEntry applicationCacheEnd;
    private OracleStatementCacheEntry implicitCacheStart;
    private OracleStatementCacheEntry explicitCacheStart;
    boolean implicitCacheEnabled;
    boolean explicitCacheEnabled;
    private boolean debug;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected LRUStatementCache(final int cacheSize) throws SQLException {
        this.debug = false;
        if (cacheSize < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 123);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.cacheSize = cacheSize;
        this.numElements = 0;
        this.implicitCacheStart = null;
        this.explicitCacheStart = null;
        this.implicitCacheEnabled = false;
        this.explicitCacheEnabled = false;
    }
    
    protected void resize(final int n) throws SQLException {
        if (n < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 123);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n >= this.cacheSize || n >= this.numElements) {
            this.cacheSize = n;
        }
        else {
            OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheEnd;
            while (this.numElements > n) {
                this.purgeCacheEntry(oracleStatementCacheEntry);
                oracleStatementCacheEntry = oracleStatementCacheEntry.applicationPrev;
            }
            this.cacheSize = n;
        }
    }
    
    public void setImplicitCachingEnabled(final boolean implicitCacheEnabled) throws SQLException {
        if (!implicitCacheEnabled) {
            this.purgeImplicitCache();
        }
        this.implicitCacheEnabled = implicitCacheEnabled;
    }
    
    public boolean getImplicitCachingEnabled() throws SQLException {
        return this.cacheSize != 0 && this.implicitCacheEnabled;
    }
    
    public void setExplicitCachingEnabled(final boolean explicitCacheEnabled) throws SQLException {
        if (!explicitCacheEnabled) {
            this.purgeExplicitCache();
        }
        this.explicitCacheEnabled = explicitCacheEnabled;
    }
    
    public boolean getExplicitCachingEnabled() throws SQLException {
        return this.cacheSize != 0 && this.explicitCacheEnabled;
    }
    
    protected void addToImplicitCache(final OraclePreparedStatement statement, final String sql, final int statementType, final int scrollType) throws SQLException {
        if (!this.implicitCacheEnabled || this.cacheSize == 0 || statement.cacheState == 2) {
            return;
        }
        if (this.numElements == this.cacheSize) {
            this.purgeCacheEntry(this.applicationCacheEnd);
        }
        statement.enterImplicitCache();
        final OracleStatementCacheEntry applicationCacheEnd = new OracleStatementCacheEntry();
        applicationCacheEnd.statement = statement;
        applicationCacheEnd.onImplicit = true;
        applicationCacheEnd.sql = sql;
        applicationCacheEnd.statementType = statementType;
        applicationCacheEnd.scrollType = scrollType;
        applicationCacheEnd.applicationNext = this.applicationCacheStart;
        applicationCacheEnd.applicationPrev = null;
        if (this.applicationCacheStart != null) {
            this.applicationCacheStart.applicationPrev = applicationCacheEnd;
        }
        this.applicationCacheStart = applicationCacheEnd;
        applicationCacheEnd.implicitNext = this.implicitCacheStart;
        applicationCacheEnd.implicitPrev = null;
        if (this.implicitCacheStart != null) {
            this.implicitCacheStart.implicitPrev = applicationCacheEnd;
        }
        this.implicitCacheStart = applicationCacheEnd;
        if (this.applicationCacheEnd == null) {
            this.applicationCacheEnd = applicationCacheEnd;
        }
        ++this.numElements;
    }
    
    protected void addToExplicitCache(final OraclePreparedStatement statement, final String sql) throws SQLException {
        if (!this.explicitCacheEnabled || this.cacheSize == 0 || statement.cacheState == 2) {
            return;
        }
        if (this.numElements == this.cacheSize) {
            this.purgeCacheEntry(this.applicationCacheEnd);
        }
        statement.enterExplicitCache();
        final OracleStatementCacheEntry applicationCacheEnd = new OracleStatementCacheEntry();
        applicationCacheEnd.statement = statement;
        applicationCacheEnd.sql = sql;
        applicationCacheEnd.onImplicit = false;
        applicationCacheEnd.applicationNext = this.applicationCacheStart;
        applicationCacheEnd.applicationPrev = null;
        if (this.applicationCacheStart != null) {
            this.applicationCacheStart.applicationPrev = applicationCacheEnd;
        }
        this.applicationCacheStart = applicationCacheEnd;
        applicationCacheEnd.explicitNext = this.explicitCacheStart;
        applicationCacheEnd.explicitPrev = null;
        if (this.explicitCacheStart != null) {
            this.explicitCacheStart.explicitPrev = applicationCacheEnd;
        }
        this.explicitCacheStart = applicationCacheEnd;
        if (this.applicationCacheEnd == null) {
            this.applicationCacheEnd = applicationCacheEnd;
        }
        ++this.numElements;
    }
    
    protected OracleStatement searchImplicitCache(final String anObject, final int n, final int n2) throws SQLException {
        if (!this.implicitCacheEnabled) {
            return null;
        }
        OracleStatementCacheEntry oracleStatementCacheEntry;
        for (oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null && (oracleStatementCacheEntry.statementType != n || oracleStatementCacheEntry.scrollType != n2 || !oracleStatementCacheEntry.sql.equals(anObject)); oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {}
        if (oracleStatementCacheEntry != null) {
            if (oracleStatementCacheEntry.applicationPrev != null) {
                oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
            }
            if (oracleStatementCacheEntry.applicationNext != null) {
                oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
            }
            if (this.applicationCacheStart == oracleStatementCacheEntry) {
                this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
            }
            if (this.applicationCacheEnd == oracleStatementCacheEntry) {
                this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
            }
            if (oracleStatementCacheEntry.implicitPrev != null) {
                oracleStatementCacheEntry.implicitPrev.implicitNext = oracleStatementCacheEntry.implicitNext;
            }
            if (oracleStatementCacheEntry.implicitNext != null) {
                oracleStatementCacheEntry.implicitNext.implicitPrev = oracleStatementCacheEntry.implicitPrev;
            }
            if (this.implicitCacheStart == oracleStatementCacheEntry) {
                this.implicitCacheStart = oracleStatementCacheEntry.implicitNext;
            }
            --this.numElements;
            oracleStatementCacheEntry.statement.exitImplicitCacheToActive();
            return oracleStatementCacheEntry.statement;
        }
        return null;
    }
    
    protected OracleStatement searchExplicitCache(final String anObject) throws SQLException {
        if (!this.explicitCacheEnabled) {
            return null;
        }
        OracleStatementCacheEntry oracleStatementCacheEntry;
        for (oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null && !oracleStatementCacheEntry.sql.equals(anObject); oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {}
        if (oracleStatementCacheEntry != null) {
            if (oracleStatementCacheEntry.applicationPrev != null) {
                oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
            }
            if (oracleStatementCacheEntry.applicationNext != null) {
                oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
            }
            if (this.applicationCacheStart == oracleStatementCacheEntry) {
                this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
            }
            if (this.applicationCacheEnd == oracleStatementCacheEntry) {
                this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
            }
            if (oracleStatementCacheEntry.explicitPrev != null) {
                oracleStatementCacheEntry.explicitPrev.explicitNext = oracleStatementCacheEntry.explicitNext;
            }
            if (oracleStatementCacheEntry.explicitNext != null) {
                oracleStatementCacheEntry.explicitNext.explicitPrev = oracleStatementCacheEntry.explicitPrev;
            }
            if (this.explicitCacheStart == oracleStatementCacheEntry) {
                this.explicitCacheStart = oracleStatementCacheEntry.explicitNext;
            }
            --this.numElements;
            oracleStatementCacheEntry.statement.exitExplicitCacheToActive();
            return oracleStatementCacheEntry.statement;
        }
        return null;
    }
    
    protected void purgeImplicitCache() throws SQLException {
        for (OracleStatementCacheEntry oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
            this.purgeCacheEntry(oracleStatementCacheEntry);
        }
        this.implicitCacheStart = null;
    }
    
    protected void purgeExplicitCache() throws SQLException {
        for (OracleStatementCacheEntry oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
            this.purgeCacheEntry(oracleStatementCacheEntry);
        }
        this.explicitCacheStart = null;
    }
    
    private void purgeCacheEntry(final OracleStatementCacheEntry oracleStatementCacheEntry) throws SQLException {
        if (oracleStatementCacheEntry.applicationNext != null) {
            oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
        }
        if (oracleStatementCacheEntry.applicationPrev != null) {
            oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
        }
        if (this.applicationCacheStart == oracleStatementCacheEntry) {
            this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
        }
        if (this.applicationCacheEnd == oracleStatementCacheEntry) {
            this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
        }
        if (oracleStatementCacheEntry.onImplicit) {
            if (oracleStatementCacheEntry.implicitNext != null) {
                oracleStatementCacheEntry.implicitNext.implicitPrev = oracleStatementCacheEntry.implicitPrev;
            }
            if (oracleStatementCacheEntry.implicitPrev != null) {
                oracleStatementCacheEntry.implicitPrev.implicitNext = oracleStatementCacheEntry.implicitNext;
            }
            if (this.implicitCacheStart == oracleStatementCacheEntry) {
                this.implicitCacheStart = oracleStatementCacheEntry.implicitNext;
            }
        }
        else {
            if (oracleStatementCacheEntry.explicitNext != null) {
                oracleStatementCacheEntry.explicitNext.explicitPrev = oracleStatementCacheEntry.explicitPrev;
            }
            if (oracleStatementCacheEntry.explicitPrev != null) {
                oracleStatementCacheEntry.explicitPrev.explicitNext = oracleStatementCacheEntry.explicitNext;
            }
            if (this.explicitCacheStart == oracleStatementCacheEntry) {
                this.explicitCacheStart = oracleStatementCacheEntry.explicitNext;
            }
        }
        --this.numElements;
        if (oracleStatementCacheEntry.onImplicit) {
            oracleStatementCacheEntry.statement.exitImplicitCacheToClose();
        }
        else {
            oracleStatementCacheEntry.statement.exitExplicitCacheToClose();
        }
    }
    
    public int getCacheSize() {
        return this.cacheSize;
    }
    
    public void printCache(final String s) throws SQLException {
        System.out.println("*** Start of Statement Cache Dump (" + s + ") ***");
        System.out.println("cache size: " + this.cacheSize + " num elements: " + this.numElements + " implicit enabled: " + this.implicitCacheEnabled + " explicit enabled: " + this.explicitCacheEnabled);
        System.out.println("applicationStart: " + this.applicationCacheStart + "  applicationEnd: " + this.applicationCacheEnd);
        for (OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationNext) {
            oracleStatementCacheEntry.print();
        }
        System.out.println("implicitStart: " + this.implicitCacheStart);
        for (OracleStatementCacheEntry oracleStatementCacheEntry2 = this.implicitCacheStart; oracleStatementCacheEntry2 != null; oracleStatementCacheEntry2 = oracleStatementCacheEntry2.implicitNext) {
            oracleStatementCacheEntry2.print();
        }
        System.out.println("explicitStart: " + this.explicitCacheStart);
        for (OracleStatementCacheEntry oracleStatementCacheEntry3 = this.explicitCacheStart; oracleStatementCacheEntry3 != null; oracleStatementCacheEntry3 = oracleStatementCacheEntry3.explicitNext) {
            oracleStatementCacheEntry3.print();
        }
        System.out.println("*** End of Statement Cache Dump (" + s + ") ***");
    }
    
    public void close() throws SQLException {
        for (OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationNext) {
            if (oracleStatementCacheEntry.onImplicit) {
                oracleStatementCacheEntry.statement.exitImplicitCacheToClose();
            }
            else {
                oracleStatementCacheEntry.statement.exitExplicitCacheToClose();
            }
        }
        this.applicationCacheStart = null;
        this.applicationCacheEnd = null;
        this.implicitCacheStart = null;
        this.explicitCacheStart = null;
        this.numElements = 0;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
