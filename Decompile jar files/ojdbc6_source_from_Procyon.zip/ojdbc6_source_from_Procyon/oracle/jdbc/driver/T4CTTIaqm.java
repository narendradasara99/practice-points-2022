// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;
import oracle.sql.TIMESTAMP;

class T4CTTIaqm
{
    static final int ATTR_ORIGINAL_MSGID = 69;
    static final byte ATTR_AGENT_NAME = 64;
    static final byte ATTR_AGENT_ADDRESS = 65;
    static final byte ATTR_AGENT_PROTOCOL = 66;
    static final int AQM_MSG_NO_DELAY = 0;
    static final int AQM_MSG_NO_EXPIRATION = -1;
    static final int AQM_MSGPROP_CORRID_SIZE = 128;
    int aqmpri;
    int aqmdel;
    int aqmexp;
    byte[] aqmcorBytes;
    int aqmcorBytesLength;
    int aqmatt;
    byte[] aqmeqnBytes;
    int aqmeqnBytesLength;
    int aqmsta;
    private byte[] aqmeqtBuffer;
    private int[] retInt;
    TIMESTAMP aqmeqt;
    byte[] aqmetiBytes;
    byte[] senderAgentName;
    int senderAgentNameLength;
    byte[] senderAgentAddress;
    int senderAgentAddressLength;
    byte senderAgentProtocol;
    byte[] originalMsgId;
    T4Ctoh toh;
    int aqmcsn;
    int aqmdsn;
    int aqmflg;
    T4CMAREngine mar;
    T4CConnection connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIaqm(final T4CConnection connection, final T4Ctoh toh) {
        this.aqmeqtBuffer = new byte[7];
        this.retInt = new int[1];
        this.senderAgentName = null;
        this.senderAgentNameLength = 0;
        this.senderAgentAddress = null;
        this.senderAgentAddressLength = 0;
        this.senderAgentProtocol = 0;
        this.toh = toh;
        this.connection = connection;
        this.mar = this.connection.mare;
    }
    
    void initToDefaultValues() {
        this.aqmpri = 0;
        this.aqmdel = 0;
        this.aqmexp = -1;
        this.aqmcorBytes = null;
        this.aqmcorBytesLength = 0;
        this.aqmatt = 0;
        this.aqmeqnBytes = null;
        this.aqmeqnBytesLength = 0;
        this.aqmsta = 0;
        this.aqmeqt = null;
        this.aqmetiBytes = null;
        this.senderAgentName = null;
        this.senderAgentNameLength = 0;
        this.senderAgentAddress = null;
        this.senderAgentAddressLength = 0;
        this.senderAgentProtocol = 0;
        this.originalMsgId = null;
        this.aqmcsn = 0;
        this.aqmdsn = 0;
        this.aqmflg = 0;
    }
    
    void marshal() throws IOException {
        this.mar.marshalSB4(this.aqmpri);
        this.mar.marshalSB4(this.aqmdel);
        this.mar.marshalSB4(this.aqmexp);
        if (this.aqmcorBytes != null && this.aqmcorBytes.length != 0) {
            this.mar.marshalSWORD(this.aqmcorBytes.length);
            this.mar.marshalCLR(this.aqmcorBytes, 0, this.aqmcorBytes.length);
        }
        else {
            this.mar.marshalSWORD(0);
        }
        this.mar.marshalSB4(0);
        if (this.aqmeqnBytes != null && this.aqmeqnBytes.length != 0) {
            this.mar.marshalSWORD(this.aqmeqnBytes.length);
            this.mar.marshalCLR(this.aqmeqnBytes, 0, this.aqmeqnBytes.length);
        }
        else {
            this.mar.marshalSWORD(0);
        }
        this.mar.marshalSB4(this.aqmsta);
        this.mar.marshalSWORD(0);
        if (this.connection.getTTCVersion() >= 3) {
            if (this.aqmetiBytes != null && this.aqmetiBytes.length > 0) {
                this.mar.marshalSWORD(this.aqmetiBytes.length);
                this.mar.marshalCLR(this.aqmetiBytes, 0, this.aqmetiBytes.length);
            }
            else {
                this.mar.marshalSWORD(0);
            }
        }
        final int n = 4;
        final byte[][] array = new byte[n][];
        final byte[][] array2 = new byte[n][];
        final int[] array3 = new int[n];
        array[0] = this.senderAgentName;
        array2[0] = null;
        array3[0] = 64;
        array[1] = this.senderAgentAddress;
        array2[1] = null;
        array3[1] = 65;
        array[2] = null;
        (array2[2] = new byte[1])[0] = this.senderAgentProtocol;
        array3[2] = 66;
        array[3] = null;
        array2[3] = this.originalMsgId;
        array3[3] = 69;
        this.mar.marshalSWORD(n);
        this.mar.marshalUB1((short)14);
        this.mar.marshalKPDKV(array, array2, array3);
        if (this.connection.getTTCVersion() >= 3) {
            this.mar.marshalUB4(1L);
            this.toh.init(T4Ctoh.ANYDATA_TOID, 0);
            this.toh.marshal(this.mar);
            this.mar.marshalUB4(0L);
            this.mar.marshalUB4(0L);
            if (this.connection.getTTCVersion() >= 4) {
                this.mar.marshalUB4(0L);
            }
        }
    }
    
    void receive() throws SQLException, IOException {
        this.aqmpri = this.mar.unmarshalSB4();
        this.aqmdel = this.mar.unmarshalSB4();
        this.aqmexp = this.mar.unmarshalSB4();
        final int unmarshalSWORD = this.mar.unmarshalSWORD();
        if (unmarshalSWORD > 0) {
            this.aqmcorBytes = new byte[unmarshalSWORD];
            final int[] array = { 0 };
            this.mar.unmarshalCLR(this.aqmcorBytes, 0, array, this.aqmcorBytes.length);
            this.aqmcorBytesLength = array[0];
        }
        else {
            this.aqmcorBytes = null;
        }
        this.aqmatt = this.mar.unmarshalSB4();
        final int unmarshalSWORD2 = this.mar.unmarshalSWORD();
        if (unmarshalSWORD2 > 0) {
            this.aqmeqnBytes = new byte[unmarshalSWORD2];
            final int[] array2 = { 0 };
            this.mar.unmarshalCLR(this.aqmeqnBytes, 0, array2, this.aqmeqnBytes.length);
            this.aqmeqnBytesLength = array2[0];
        }
        else {
            this.aqmeqnBytes = null;
        }
        this.aqmsta = this.mar.unmarshalSB4();
        if (this.mar.unmarshalSB4() > 0) {
            this.mar.unmarshalCLR(this.aqmeqtBuffer, 0, this.retInt, 7);
            this.aqmeqt = new TIMESTAMP(this.aqmeqtBuffer);
        }
        if (this.connection.getTTCVersion() >= 3) {
            final int unmarshalSWORD3 = this.mar.unmarshalSWORD();
            if (unmarshalSWORD3 > 0) {
                this.aqmetiBytes = new byte[unmarshalSWORD3];
                this.mar.unmarshalCLR(this.aqmetiBytes, 0, new int[1], this.aqmetiBytes.length);
            }
            else {
                this.aqmetiBytes = null;
            }
        }
        final int unmarshalSWORD4 = this.mar.unmarshalSWORD();
        this.mar.unmarshalUB1();
        if (unmarshalSWORD4 > 0) {
            final byte[][] array3 = new byte[unmarshalSWORD4][];
            final int[] array4 = new int[unmarshalSWORD4];
            final byte[][] array5 = new byte[unmarshalSWORD4][];
            final int[] array6 = new int[unmarshalSWORD4];
            this.mar.unmarshalKPDKV(array3, array4, array5, array6);
            for (int i = 0; i < unmarshalSWORD4; ++i) {
                if (array6[i] == 64 && array3[i] != null && array4[i] > 0) {
                    this.senderAgentName = array3[i];
                    this.senderAgentNameLength = array4[i];
                }
                if (array6[i] == 65 && array3[i] != null && array4[i] > 0) {
                    this.senderAgentAddress = array3[i];
                    this.senderAgentAddressLength = array4[i];
                }
                if (array6[i] == 66 && array5[i] != null && array5[i].length > 0) {
                    this.senderAgentProtocol = array5[i][0];
                }
                if (array6[i] == 69 && array5[i] != null && array5[i].length > 0) {
                    this.originalMsgId = array5[i];
                }
            }
        }
        if (this.connection.getTTCVersion() >= 3) {
            this.mar.unmarshalSWORD();
            this.aqmcsn = (int)this.mar.unmarshalUB4();
            this.aqmdsn = (int)this.mar.unmarshalUB4();
            if (this.connection.getTTCVersion() >= 4) {
                this.aqmflg = (int)this.mar.unmarshalUB4();
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
