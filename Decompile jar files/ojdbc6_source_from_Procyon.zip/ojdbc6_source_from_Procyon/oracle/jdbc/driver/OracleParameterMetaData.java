// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;

class OracleParameterMetaData implements oracle.jdbc.OracleParameterMetaData
{
    int parameterCount;
    int parameterNoNulls;
    int parameterNullable;
    int parameterNullableUnknown;
    int parameterModeUnknown;
    int parameterModeIn;
    int parameterModeInOut;
    int parameterModeOut;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleParameterMetaData(final int parameterCount) throws SQLException {
        this.parameterCount = 0;
        this.parameterNoNulls = 0;
        this.parameterNullable = 1;
        this.parameterNullableUnknown = 2;
        this.parameterModeUnknown = 0;
        this.parameterModeIn = 1;
        this.parameterModeInOut = 2;
        this.parameterModeOut = 4;
        this.parameterCount = parameterCount;
    }
    
    @Override
    public int getParameterCount() throws SQLException {
        return this.parameterCount;
    }
    
    @Override
    public int isNullable(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public boolean isSigned(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public int getPrecision(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public int getScale(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public int getParameterType(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public String getParameterTypeName(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public String getParameterClassName(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public int getParameterMode(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
