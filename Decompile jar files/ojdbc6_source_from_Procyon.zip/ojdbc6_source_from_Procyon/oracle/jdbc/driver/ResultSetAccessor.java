// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.ResultSet;
import java.sql.SQLException;

class ResultSetAccessor extends Accessor
{
    static final int maxLength = 16;
    OracleStatement currentStmt;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    ResultSetAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 102, 116, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    ResultSetAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 102, 116, n7, false);
        this.initForDescribe(102, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 16;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    ResultSet getCursor(final int n) throws SQLException {
        final OracleStatement refCursorBytesToStatement = this.statement.connection.RefCursorBytesToStatement(this.getBytes(n), this.statement);
        if (this.currentStmt != null && this.currentStmt.cursorId == refCursorBytesToStatement.cursorId && this.currentStmt.currentResultSet != null) {
            return this.currentStmt.currentResultSet;
        }
        refCursorBytesToStatement.doDescribe(false);
        refCursorBytesToStatement.prepareAccessors();
        final OracleResultSetImpl currentResultSet = new OracleResultSetImpl(refCursorBytesToStatement.connection, refCursorBytesToStatement);
        currentResultSet.close_statement_on_close = true;
        refCursorBytesToStatement.currentResultSet = currentResultSet;
        this.currentStmt = refCursorBytesToStatement;
        return currentResultSet;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getCursor(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
