// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValue;

class KeywordValueI extends KeywordValue
{
    private int keyword;
    private byte[] binaryValue;
    private String textValue;
    private byte[] textValueArr;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    KeywordValueI(final int keyword, final String textValue, final byte[] binaryValue) {
        this.keyword = keyword;
        this.textValue = textValue;
        this.binaryValue = binaryValue;
        this.textValueArr = null;
    }
    
    void doCharConversion(final DBConversion dbConversion) throws SQLException {
        if (this.textValue != null) {
            this.textValueArr = dbConversion.StringToCharBytes(this.textValue);
        }
        else {
            this.textValueArr = null;
        }
    }
    
    @Override
    public byte[] getBinaryValue() throws SQLException {
        return this.binaryValue;
    }
    
    @Override
    public String getTextValue() throws SQLException {
        return this.textValue;
    }
    
    @Override
    public int getKeyword() throws SQLException {
        return this.keyword;
    }
    
    void marshal(final T4CMAREngine t4CMAREngine) throws IOException {
        if (this.textValueArr != null) {
            t4CMAREngine.marshalUB2(this.textValueArr.length);
            t4CMAREngine.marshalCLR(this.textValueArr, this.textValueArr.length);
            t4CMAREngine.marshalUB2(0);
        }
        else {
            t4CMAREngine.marshalUB2(0);
            if (this.binaryValue != null) {
                t4CMAREngine.marshalUB2(this.binaryValue.length);
                t4CMAREngine.marshalCLR(this.binaryValue, this.binaryValue.length);
            }
            else {
                t4CMAREngine.marshalUB2(0);
            }
        }
        t4CMAREngine.marshalUB2(this.keyword);
    }
    
    static KeywordValueI unmarshal(final T4CMAREngine t4CMAREngine) throws SQLException, IOException {
        final int[] array = { 0 };
        String charBytesToString = null;
        byte[] array2 = null;
        final int unmarshalUB2 = t4CMAREngine.unmarshalUB2();
        if (unmarshalUB2 != 0) {
            final byte[] array3 = new byte[unmarshalUB2];
            t4CMAREngine.unmarshalCLR(array3, 0, array);
            charBytesToString = t4CMAREngine.conv.CharBytesToString(array3, array3.length);
        }
        final int unmarshalUB3 = t4CMAREngine.unmarshalUB2();
        if (unmarshalUB3 != 0) {
            array2 = new byte[unmarshalUB3];
            t4CMAREngine.unmarshalCLR(array2, 0, array);
        }
        return new KeywordValueI(t4CMAREngine.unmarshalUB2(), charBytesToString, array2);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
