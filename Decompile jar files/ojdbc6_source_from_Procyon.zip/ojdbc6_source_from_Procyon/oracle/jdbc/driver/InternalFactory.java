// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.aq.AQMessageProperties;
import java.sql.SQLException;

public abstract class InternalFactory
{
    public static KeywordValueI createKeywordValue(final int n, final String s, final byte[] array) throws SQLException {
        return new KeywordValueI(n, s, array);
    }
    
    public static KeywordValueLongI createKeywordValueLong(final int n, final String s, final byte[] array) throws SQLException {
        return new KeywordValueLongI(n, s, array);
    }
    
    public static XSAttributeI createXSAttribute() throws SQLException {
        return new XSAttributeI();
    }
    
    public static XSNamespaceI createXSNamespace() throws SQLException {
        return new XSNamespaceI();
    }
    
    public static AQMessagePropertiesI createAQMessageProperties() throws SQLException {
        return new AQMessagePropertiesI();
    }
    
    public static AQAgentI createAQAgent() throws SQLException {
        return new AQAgentI();
    }
    
    public static AQMessageI createAQMessage(final AQMessageProperties aqMessageProperties) throws SQLException {
        return new AQMessageI((AQMessagePropertiesI)aqMessageProperties);
    }
    
    public static byte[] urowid2rowid(final long[] array) {
        return T4CRowidAccessor.rowidToString(array);
    }
    
    public static long[] rowid2urowid(final byte[] array, final int n, final int n2) throws SQLException {
        return T4CRowidAccessor.stringToRowid(array, n, n2);
    }
}
