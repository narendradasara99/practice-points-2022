// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;

class T4CRowidAccessor extends RowidAccessor
{
    T4CMAREngine mare;
    static final int maxLength = 128;
    static final int EXTENDED_ROWID_MAX_LENGTH = 18;
    final int[] meta;
    static final int KGRD_EXTENDED_OBJECT = 6;
    static final int KGRD_EXTENDED_BLOCK = 6;
    static final int KGRD_EXTENDED_FILE = 3;
    static final int KGRD_EXTENDED_SLOT = 3;
    static final int kd4_ubridtype_physical = 1;
    static final int kd4_ubridtype_logical = 2;
    static final int kd4_ubridtype_remote = 3;
    static final int kd4_ubridtype_exttab = 4;
    static final int kd4_ubridtype_future2 = 5;
    static final int kd4_ubridtype_max = 5;
    static final int kd4_ubridlen_typeind = 1;
    static final byte[] kgrd_indbyte_char;
    static final byte[] kgrd_basis_64;
    static final byte[] kgrd_index_64;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CRowidAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, n3, b);
        this.meta = new int[1];
        this.mare = mare;
        this.defineType = 104;
    }
    
    T4CRowidAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, b, n2, n3, n4, n5, n6, n7);
        this.meta = new int[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
        this.defineType = 104;
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        if (this.rowSpaceIndicator == null) {
            if (this.mare.unmarshalUB1() > 0) {
                this.mare.unmarshalUB4();
                this.mare.unmarshalUB2();
                this.mare.unmarshalUB1();
                this.mare.unmarshalUB4();
                this.mare.unmarshalUB2();
            }
            this.processIndicator(this.meta[0]);
            ++this.lastRowProcessed;
            return false;
        }
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        if (this.isNullByDescribe) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
            ++this.lastRowProcessed;
            if (this.statement.connection.versionNumber < 9200) {
                this.processIndicator(0);
            }
            return false;
        }
        final int n3 = this.columnIndex + this.lastRowProcessed * this.byteLength;
        if (this.describeType != 208) {
            final short unmarshalUB1 = this.mare.unmarshalUB1();
            long unmarshalUB2 = 0L;
            int unmarshalUB3 = 0;
            short unmarshalUB4 = 0;
            long unmarshalUB5 = 0L;
            int unmarshalUB6 = 0;
            if (unmarshalUB1 > 0) {
                unmarshalUB2 = this.mare.unmarshalUB4();
                unmarshalUB3 = this.mare.unmarshalUB2();
                unmarshalUB4 = this.mare.unmarshalUB1();
                unmarshalUB5 = this.mare.unmarshalUB4();
                unmarshalUB6 = this.mare.unmarshalUB2();
            }
            if (unmarshalUB2 == 0L && unmarshalUB3 == 0 && unmarshalUB4 == 0 && unmarshalUB5 == 0L && unmarshalUB6 == 0) {
                this.meta[0] = 0;
            }
            else {
                final byte[] rowidToString = rowidToString(new long[] { unmarshalUB2, unmarshalUB3, unmarshalUB5, unmarshalUB6 });
                int n4 = 18;
                if (this.byteLength - 2 < 18) {
                    n4 = this.byteLength - 2;
                }
                System.arraycopy(rowidToString, 0, this.rowSpaceByte, n3 + 2, n4);
                this.meta[0] = n4;
            }
        }
        else if ((this.meta[0] = (int)this.mare.unmarshalUB4()) > 0) {
            final byte[] array = new byte[this.meta[0]];
            this.mare.unmarshalCLR(array, 0, this.meta);
            this.meta[0] = kgrdub2c(array, this.meta[0], 0, this.rowSpaceByte, n3 + 2);
        }
        this.rowSpaceByte[n3] = (byte)((this.meta[0] & 0xFF00) >> 8);
        this.rowSpaceByte[n3 + 1] = (byte)(this.meta[0] & 0xFF);
        this.processIndicator(this.meta[0]);
        if (this.meta[0] == 0) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
        }
        else {
            this.rowSpaceIndicator[n2] = (short)this.meta[0];
            this.rowSpaceIndicator[n] = 0;
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
            if (this.describeType != 208 || this.rowSpaceByte[n2] == 1) {
                final String s2 = new String(this.rowSpaceByte, n2 + 2, n3);
                s = new String(rowidToString(stringToRowid(s2.getBytes(), 0, s2.length())));
            }
            else {
                s = new String(this.rowSpaceByte, n2 + 2, n3);
            }
        }
        return s;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getObject(n);
        }
        final Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return o;
        }
        switch (this.definedColumnType) {
            case -1:
            case 1:
            case 12: {
                return this.getString(n);
            }
            case -8: {
                return this.getROWID(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    @Override
    void copyRow() throws SQLException, IOException {
        int n;
        if (this.lastRowProcessed == 0) {
            n = this.statement.rowPrefetchInLastFetch - 1;
        }
        else {
            n = this.lastRowProcessed - 1;
        }
        final int n2 = this.columnIndex + this.lastRowProcessed * this.byteLength;
        final int n3 = this.columnIndex + n * this.byteLength;
        final int n4 = this.indicatorIndex + this.lastRowProcessed;
        final int n5 = this.indicatorIndex + n;
        final int n6 = this.lengthIndex + this.lastRowProcessed;
        final short n7 = this.rowSpaceIndicator[this.lengthIndex + n];
        final int n8 = this.metaDataIndex + this.lastRowProcessed * 1;
        final int n9 = this.metaDataIndex + n * 1;
        this.rowSpaceIndicator[n6] = n7;
        this.rowSpaceIndicator[n4] = this.rowSpaceIndicator[n5];
        System.arraycopy(this.rowSpaceByte, n3, this.rowSpaceByte, n2, n7 + 2);
        System.arraycopy(this.rowSpaceMetaData, n9, this.rowSpaceMetaData, n8, 1);
        ++this.lastRowProcessed;
    }
    
    @Override
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
        final int n3 = this.columnIndex + (n2 - 1) * this.byteLength;
        final int n4 = this.columnIndexLastRow + (n - 1) * this.byteLength;
        final int n5 = this.indicatorIndex + n2 - 1;
        final int n6 = this.indicatorIndexLastRow + n - 1;
        final int n7 = this.lengthIndex + n2 - 1;
        final short n8 = array3[this.lengthIndexLastRow + n - 1];
        this.rowSpaceIndicator[n7] = n8;
        this.rowSpaceIndicator[n5] = array3[n6];
        if (n8 != 0) {
            System.arraycopy(array, n4, this.rowSpaceByte, n3, n8 + 2);
        }
    }
    
    static final byte[] rowidToString(final long[] array) {
        final long n = array[0];
        final long n2 = array[1];
        final long n3 = array[2];
        final long n4 = array[3];
        final byte[] array2 = new byte[18];
        kgrd42b(array2, n4, 3, kgrd42b(array2, n3, 6, kgrd42b(array2, n2, 3, kgrd42b(array2, n, 6, 0))));
        return array2;
    }
    
    static final long[] rcToRowid(final byte[] bytes, final int offset, final int length) throws SQLException {
        if (length != 18) {
            throw new SQLException("Rowid size incorrect.");
        }
        final long[] array = new long[3];
        final String s = new String(bytes, offset, length);
        final long long1 = Long.parseLong(s.substring(0, 8), 16);
        final long long2 = Long.parseLong(s.substring(9, 13), 16);
        array[0] = Long.parseLong(s.substring(14, 8), 16);
        array[1] = long1;
        array[2] = long2;
        return array;
    }
    
    static final void kgrdr2rc(final int n, final int n2, final int n3, final int n4, final int n5, final byte[] array, int n6) throws SQLException {
        n6 = lmx42h(array, n4, 8, n6);
        array[n6++] = 46;
        n6 = lmx42h(array, n5, 4, n6);
        array[n6++] = 46;
        n6 = lmx42h(array, n2, 4, n6);
    }
    
    static final int lmx42h(final byte[] array, final long i, int n, final int n2) {
        final String upperCase = Long.toHexString(i).toUpperCase();
        final int n3 = n;
        int n4 = 0;
        do {
            if (n4 < upperCase.length()) {
                array[n2 + n - 1] = (byte)upperCase.charAt(upperCase.length() - n4 - 1);
                ++n4;
            }
            else {
                array[n2 + n - 1] = 48;
            }
        } while (--n > 0);
        return n3 + n2;
    }
    
    static final int kgrdc2ub(final byte[] array, final int n, final byte[] array2, final int n2, final int n3) throws SQLException {
        final byte rowidType = getRowidType(array, n);
        int i = n3 - 1;
        final byte[] kgrd_index_64 = T4CRowidAccessor.kgrd_index_64;
        final int n4 = 1 + (3 * ((n3 - 1) / 4) + (((n3 - 1) % 4 != 0) ? ((n3 - 1) % 4 - 1) : 0));
        if (i == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 132);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array2[n2 + 0] = rowidType;
        for (int n5 = n + 1, n6 = 1; i > 0; i -= 4, ++n5, ++n6) {
            if (i == 1) {
                final SQLException sqlException2 = DatabaseError.createSqlException(null, 132);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final byte b = kgrd_index_64[array[n5]];
            if (b == -1) {
                final SQLException sqlException3 = DatabaseError.createSqlException(null, 132);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            ++n5;
            final byte b2 = kgrd_index_64[array[n5]];
            if (b2 == -1) {
                final SQLException sqlException4 = DatabaseError.createSqlException(null, 132);
                sqlException4.fillInStackTrace();
                throw sqlException4;
            }
            array2[n2 + n6] = (byte)((b & 0xFF) << 2 | (b2 & 0x30) >> 4);
            if (i == 2) {
                break;
            }
            ++n6;
            final byte b3 = b2;
            ++n5;
            final byte b4 = kgrd_index_64[array[n5]];
            if (b4 == -1) {
                final SQLException sqlException5 = DatabaseError.createSqlException(null, 132);
                sqlException5.fillInStackTrace();
                throw sqlException5;
            }
            array2[n2 + n6] = (byte)((b3 & 0xFF) << 4 | (b4 & 0x3C) >> 2);
            if (i == 3) {
                break;
            }
            ++n6;
            final byte b5 = b4;
            ++n5;
            final byte b6 = kgrd_index_64[array[n5]];
            if (b6 == -1) {
                final SQLException sqlException6 = DatabaseError.createSqlException(null, 132);
                sqlException6.fillInStackTrace();
                throw sqlException6;
            }
            array2[n2 + n6] = (byte)((b5 & 0x3) << 6 | b6);
        }
        return n4;
    }
    
    static final long[] stringToRowid(final byte[] array, int n, final int n2) throws SQLException {
        if (n2 != 18) {
            throw new SQLException("Rowid size incorrect.");
        }
        final long[] array2 = new long[4];
        try {
            array2[0] = kgrdb42(array, 6, n);
            n += 6;
            array2[1] = kgrdb42(array, 3, n);
            n += 3;
            array2[2] = kgrdb42(array, 6, n);
            n += 6;
            array2[3] = kgrdb42(array, 3, n);
            n += 3;
        }
        catch (Exception ex) {
            array2[1] = (array2[0] = 0L);
            array2[3] = (array2[2] = 0L);
        }
        return array2;
    }
    
    static final int kgrd42b(final byte[] array, final long n, int i, final int n2) {
        final int n3 = i;
        long n4 = n;
        while (i > 0) {
            array[n2 + i - 1] = T4CRowidAccessor.kgrd_basis_64[(int)n4 & 0x3F];
            n4 = (n4 >>> 6 & 0x3FFFFFFL);
            --i;
        }
        return n3 + n2;
    }
    
    static final long kgrdb42(final byte[] array, final int n, final int n2) throws SQLException {
        long n3 = 0L;
        for (int i = 0; i < n; ++i) {
            final byte b = T4CRowidAccessor.kgrd_index_64[array[n2 + i]];
            if (b == -1) {
                throw new SQLException("Char data to rowid conversion failed.");
            }
            n3 = (n3 << 6 | (long)b);
        }
        return n3;
    }
    
    static final void kgrdr2ec(final int n, final int n2, final int n3, final int n4, final int n5, final byte[] array, int n6) throws SQLException {
        n6 = kgrd42b(n, array, n6, 6);
        n6 = kgrd42b(n2, array, n6, 3);
        n6 = kgrd42b(n4, array, n6, 6);
        n6 = kgrd42b(n5, array, n6, 3);
    }
    
    static final int kgrd42b(int n, final byte[] array, final int n2, int i) throws SQLException {
        final int n3 = i;
        while (i > 0) {
            --i;
            array[n2 + i] = T4CRowidAccessor.kgrd_basis_64[n & 0x3F];
            n >>= 6;
        }
        return n2 + n3;
    }
    
    static final int kgrdub2c(final byte[] array, final int n, final int n2, final byte[] array2, final int n3) throws SQLException {
        final byte b = array[n2];
        int n13;
        if (b == 1) {
            final int[] array3 = new int[array.length];
            for (int i = 0; i < array.length; ++i) {
                array3[i] = (array[i] & 0xFF);
            }
            final int n4 = n2 + 1;
            final int n5 = (((array3[n4 + 0] << 8) + array3[n4 + 1] << 8) + array3[n4 + 2] << 8) + array3[n4 + 3];
            final int n6 = n2 + 5;
            final int n7 = (array3[n6 + 0] << 8) + array3[n6 + 1];
            final int n8 = 0;
            final int n9 = n2 + 7;
            final int n10 = (((array3[n9 + 0] << 8) + array3[n9 + 1] << 8) + array3[n9 + 2] << 8) + array3[n9 + 3];
            final int n11 = n2 + 11;
            final int n12 = (array3[n11 + 0] << 8) + array3[n11 + 1];
            if (n5 == 0) {
                kgrdr2rc(n5, n7, n8, n10, n12, array2, n3);
            }
            else {
                kgrdr2ec(n5, n7, n8, n10, n12, array2, n3);
            }
            n13 = 18;
        }
        else {
            int n14 = 0;
            int j = n - 1;
            if (1 + (4 * (n / 3) + ((n % 3 == 0) ? (n % 3 + 1) : 0)) - 1 != 0) {
                array2[n3 + 0] = T4CRowidAccessor.kgrd_indbyte_char[b - 1];
                for (int n15 = n2 + 1, n14 = 1; j > 0; j -= 3, ++n15, ++n14) {
                    array2[n3 + n14++] = T4CRowidAccessor.kgrd_basis_64[(array[n15] & 0xFF) >> 2];
                    if (j == 1) {
                        array2[n3 + n14++] = T4CRowidAccessor.kgrd_basis_64[(array[n15] & 0x3) << 4];
                        break;
                    }
                    final byte b2 = (byte)(array[n15 + 1] & 0xFF);
                    array2[n3 + n14++] = T4CRowidAccessor.kgrd_basis_64[(array[n15] & 0x3) << 4 | (b2 & 0xF0) >> 4];
                    if (j == 2) {
                        array2[n3 + n14++] = T4CRowidAccessor.kgrd_basis_64[(b2 & 0xF) << 2];
                        break;
                    }
                    n15 += 2;
                    array2[n3 + n14++] = T4CRowidAccessor.kgrd_basis_64[(b2 & 0xF) << 2 | (array[n15] & 0xC0) >> 6];
                    array2[n3 + n14] = T4CRowidAccessor.kgrd_basis_64[array[n15] & 0x3F];
                }
            }
            n13 = n14;
        }
        return n13;
    }
    
    static final boolean isUROWID(final byte[] array, final int n) {
        return getRowidType(array, n) == 2;
    }
    
    static final byte getRowidType(final byte[] array, final int n) {
        byte b = 5;
        switch (array[n]) {
            case 65: {
                b = 1;
                break;
            }
            case 42: {
                b = 2;
                break;
            }
            case 45: {
                b = 3;
                break;
            }
            case 40: {
                b = 4;
                break;
            }
            case 41: {
                b = 5;
                break;
            }
        }
        return b;
    }
    
    static {
        kgrd_indbyte_char = new byte[] { 65, 42, 45, 40, 41 };
        kgrd_basis_64 = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
        kgrd_index_64 = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
