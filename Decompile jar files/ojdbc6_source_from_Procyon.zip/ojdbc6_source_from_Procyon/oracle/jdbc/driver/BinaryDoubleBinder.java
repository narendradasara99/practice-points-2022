// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class BinaryDoubleBinder extends Binder
{
    Binder theBinaryDoubleCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 101;
        binder.bytelen = 8;
    }
    
    BinaryDoubleBinder() {
        this.theBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theBinaryDoubleCopyingBinder;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        double value = oraclePreparedStatement.parameterDouble[n3][n];
        if (value == 0.0) {
            value = 0.0;
        }
        else if (value != value) {
            value = Double.NaN;
        }
        final long doubleToLongBits = Double.doubleToLongBits(value);
        final int n10 = (int)doubleToLongBits;
        final int n11 = (int)(doubleToLongBits >> 32);
        int n12 = n10;
        int n15;
        int n14;
        int n13 = (n14 = (n15 = n10 >> 8) >> 8) >> 8;
        int n16 = n11;
        int n19;
        int n18;
        final int n17 = (n18 = (n19 = n11 >> 8) >> 8) >> 8;
        int n20;
        if ((n17 & 0x80) == 0x0) {
            n20 = (n17 | 0x80);
        }
        else {
            n20 = ~n17;
            n18 ^= -1;
            n19 ^= -1;
            n16 ^= -1;
            n13 ^= -1;
            n14 ^= -1;
            n15 ^= -1;
            n12 ^= -1;
        }
        array[n6 + 7] = (byte)n12;
        array[n6 + 6] = (byte)n15;
        array[n6 + 5] = (byte)n14;
        array[n6 + 4] = (byte)n13;
        array[n6 + 3] = (byte)n16;
        array[n6 + 2] = (byte)n19;
        array[n6 + 1] = (byte)n18;
        array[n6] = (byte)n20;
        array3[n9] = 0;
        array3[n8] = 8;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
