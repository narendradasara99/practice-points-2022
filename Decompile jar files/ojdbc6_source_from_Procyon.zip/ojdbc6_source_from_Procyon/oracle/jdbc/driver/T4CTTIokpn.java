// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import java.io.IOException;
import oracle.sql.TIMESTAMPTZ;

final class T4CTTIokpn extends T4CTTIfun
{
    static final int REGISTER_KPNDEF = 1;
    static final int UNREGISTER_KPNDEF = 2;
    static final int POST_KPNDEF = 3;
    static final int EXISTINGCLIENT_KPNDEF = 0;
    static final int NEWCLIENT_KPNDEF = 1;
    static final int KPUN_PRS_RAW = 1;
    static final int KPUN_VER_10200 = 2;
    static final int KPUN_VER_11100 = 3;
    static final int KPUN_VER_11200 = 4;
    static final int OCI_SUBSCR_NAMESPACE_ANONYMOUS = 0;
    static final int OCI_SUBSCR_NAMESPACE_AQ = 1;
    static final int OCI_SUBSCR_NAMESPACE_DBCHANGE = 2;
    static final int OCI_SUBSCR_NAMESPACE_MAX = 3;
    static final int KPD_CHNF_OPFILTER = 1;
    static final int KPD_CHNF_INSERT = 2;
    static final int KPD_CHNF_UPDATE = 4;
    static final int KPD_CHNF_DELETE = 8;
    static final int KPD_CHNF_ROWID = 16;
    static final int KPD_CQ_QUERYNF = 32;
    static final int KPD_CQ_BEST_EFFORT = 64;
    static final int KPD_CQ_CLQRYCACHE = 128;
    static final int KPD_CHNF_INVALID_REGID = 0;
    static final int SUBSCR_QOS_RELIABLE = 1;
    static final int SUBSCR_QOS_PAYLOAD = 2;
    static final int SUBSCR_QOS_REPLICATE = 4;
    static final int SUBSCR_QOS_SECURE = 8;
    static final int SUBSCR_QOS_PURGE_ON_NTFN = 16;
    static final int SUBSCR_QOS_MULTICBK = 32;
    static final byte SUBSCR_NTFN_GROUPING_CLASS_NONE = 0;
    static final byte SUBSCR_NTFN_GROUPING_CLASS_TIME = 1;
    static final byte SUBSCR_NTFN_GROUPING_TYPE_SUMMARY = 1;
    static final byte SUBSCR_NTFN_GROUPING_TYPE_LAST = 2;
    private int opcode;
    private int mode;
    private int nbOfRegistrationInfo;
    private String user;
    private String location;
    private int[] namespace;
    private int[] kpdnrgrpval;
    private int[] kpdnrgrprepcnt;
    private int[] payloadType;
    private int[] qosFlags;
    private int[] timeout;
    private int[] dbchangeOpFilter;
    private int[] dbchangeTxnLag;
    private byte[][] registeredAgentName;
    private byte[][] kpdnrcx;
    private byte[] kpdnrgrpcla;
    private byte[] kpdnrgrptyp;
    private TIMESTAMPTZ[] kpdnrgrpstatim;
    private long[] dbchangeRegistrationId;
    private byte[] userArr;
    private byte[] locationArr;
    private long regid;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIokpn(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.dbchangeTxnLag = null;
        this.registeredAgentName = null;
        this.kpdnrcx = null;
        this.kpdnrgrptyp = null;
        this.kpdnrgrpstatim = null;
        this.dbchangeRegistrationId = null;
        this.userArr = null;
        this.locationArr = null;
        this.regid = 0L;
        this.setFunCode((short)125);
    }
    
    void doOKPN(final int opcode, final int mode, final String user, final String location, final int nbOfRegistrationInfo, final int[] namespace, final String[] array, final byte[][] kpdnrcx, final int[] payloadType, final int[] qosFlags, final int[] timeout, final int[] dbchangeOpFilter, final int[] dbchangeTxnLag, final long[] dbchangeRegistrationId, final byte[] kpdnrgrpcla, final int[] kpdnrgrpval, final byte[] kpdnrgrptyp, final TIMESTAMPTZ[] kpdnrgrpstatim, final int[] kpdnrgrprepcnt) throws IOException, SQLException {
        this.opcode = opcode;
        this.mode = mode;
        this.user = user;
        this.location = location;
        this.nbOfRegistrationInfo = nbOfRegistrationInfo;
        this.namespace = namespace;
        this.kpdnrcx = kpdnrcx;
        this.payloadType = payloadType;
        this.qosFlags = qosFlags;
        this.timeout = timeout;
        this.dbchangeOpFilter = dbchangeOpFilter;
        this.dbchangeTxnLag = dbchangeTxnLag;
        this.dbchangeRegistrationId = dbchangeRegistrationId;
        this.kpdnrgrpcla = kpdnrgrpcla;
        this.kpdnrgrpval = kpdnrgrpval;
        this.kpdnrgrptyp = kpdnrgrptyp;
        this.kpdnrgrpstatim = kpdnrgrpstatim;
        this.kpdnrgrprepcnt = kpdnrgrprepcnt;
        this.registeredAgentName = new byte[this.nbOfRegistrationInfo][];
        for (int i = 0; i < this.nbOfRegistrationInfo; ++i) {
            if (array[i] != null) {
                this.registeredAgentName[i] = this.meg.conv.StringToCharBytes(array[i]);
            }
        }
        if (this.user != null) {
            this.userArr = this.meg.conv.StringToCharBytes(this.user);
        }
        else {
            this.userArr = null;
        }
        if (this.location != null) {
            this.locationArr = this.meg.conv.StringToCharBytes(this.location);
        }
        else {
            this.locationArr = null;
        }
        this.regid = 0L;
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        final int n = 1;
        final int n2 = 2;
        this.meg.marshalUB1((byte)this.opcode);
        this.meg.marshalUB4(this.mode);
        if (this.userArr != null) {
            this.meg.marshalPTR();
            this.meg.marshalUB4(this.userArr.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalUB4(0L);
        }
        if (this.locationArr != null) {
            this.meg.marshalPTR();
            this.meg.marshalUB4(this.locationArr.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalUB4(0L);
        }
        this.meg.marshalPTR();
        this.meg.marshalUB4(this.nbOfRegistrationInfo);
        this.meg.marshalUB2(n);
        this.meg.marshalUB2(n2);
        if (this.connection.getTTCVersion() >= 4) {
            this.meg.marshalNULLPTR();
            this.meg.marshalPTR();
            if (this.connection.getTTCVersion() >= 5) {
                this.meg.marshalNULLPTR();
                this.meg.marshalPTR();
            }
        }
        if (this.userArr != null) {
            this.meg.marshalCHR(this.userArr);
        }
        if (this.locationArr != null) {
            this.meg.marshalCHR(this.locationArr);
        }
        for (int i = 0; i < this.nbOfRegistrationInfo; ++i) {
            this.meg.marshalUB4(this.namespace[i]);
            final byte[] array = this.registeredAgentName[i];
            if (array != null && array.length > 0) {
                this.meg.marshalUB4(array.length);
                this.meg.marshalCLR(array, 0, array.length);
            }
            else {
                this.meg.marshalUB4(0L);
            }
            if (this.kpdnrcx[i] != null && this.kpdnrcx[i].length > 0) {
                this.meg.marshalUB4(this.kpdnrcx[i].length);
                this.meg.marshalCLR(this.kpdnrcx[i], 0, this.kpdnrcx[i].length);
            }
            else {
                this.meg.marshalUB4(0L);
            }
            this.meg.marshalUB4(this.payloadType[i]);
            if (this.connection.getTTCVersion() >= 4) {
                this.meg.marshalUB4(this.qosFlags[i]);
                final byte[] array2 = new byte[0];
                this.meg.marshalUB4(array2.length);
                if (array2.length > 0) {
                    this.meg.marshalCLR(array2, array2.length);
                }
                this.meg.marshalUB4(this.timeout[i]);
                this.meg.marshalUB4(0);
                this.meg.marshalUB4(this.dbchangeOpFilter[i]);
                this.meg.marshalUB4(this.dbchangeTxnLag[i]);
                this.meg.marshalUB4((int)this.dbchangeRegistrationId[i]);
                if (this.connection.getTTCVersion() >= 5) {
                    this.meg.marshalUB1(this.kpdnrgrpcla[i]);
                    this.meg.marshalUB4(this.kpdnrgrpval[i]);
                    this.meg.marshalUB1(this.kpdnrgrptyp[i]);
                    if (this.kpdnrgrpstatim[i] == null) {
                        this.meg.marshalDALC(null);
                    }
                    else {
                        this.meg.marshalDALC(this.kpdnrgrpstatim[i].shareBytes());
                    }
                    this.meg.marshalSB4(this.kpdnrgrprepcnt[i]);
                    this.meg.marshalSB8(this.dbchangeRegistrationId[i]);
                }
            }
        }
    }
    
    long getRegistrationId() {
        return this.regid;
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        final int n = (int)this.meg.unmarshalUB4();
        for (int i = 0; i < n; ++i) {
            this.meg.unmarshalUB4();
        }
        final int[] array = new int[n];
        for (int j = 0; j < n; ++j) {
            array[j] = (int)this.meg.unmarshalUB4();
        }
        this.regid = array[0];
        if (this.connection.getTTCVersion() >= 5) {
            final int n2 = (int)this.meg.unmarshalUB4();
            this.regid = this.meg.unmarshalSB8();
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
