// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.jdbc.aq.AQNotificationListener;
import java.util.concurrent.Executor;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.jdbc.dcn.DatabaseChangeListener;
import java.util.EventListener;
import java.sql.SQLException;
import oracle.jdbc.NotificationRegistration;
import java.util.Properties;

abstract class NTFRegistration
{
    private final boolean jdbcGetsNotification;
    private final String clientHost;
    private final int clientTCPPort;
    private final Properties options;
    private final boolean isPurgeOnNTF;
    private final String username;
    private final int namespace;
    private final int jdbcRegId;
    private final String dbName;
    private final short databaseVersion;
    private NotificationRegistration.RegistrationState state;
    private NTFEventListener[] listeners;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFRegistration(final int jdbcRegId, final int namespace, final boolean jdbcGetsNotification, final String dbName, final String clientHost, final int clientTCPPort, final Properties options, final String username, final short databaseVersion) {
        this.listeners = new NTFEventListener[0];
        this.namespace = namespace;
        this.clientHost = clientHost;
        this.clientTCPPort = clientTCPPort;
        this.options = options;
        this.jdbcRegId = jdbcRegId;
        this.username = username;
        this.jdbcGetsNotification = jdbcGetsNotification;
        this.dbName = dbName;
        this.state = NotificationRegistration.RegistrationState.ACTIVE;
        if (this.options.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0) {
            this.isPurgeOnNTF = true;
        }
        else {
            this.isPurgeOnNTF = false;
        }
        this.databaseVersion = databaseVersion;
    }
    
    short getDatabaseVersion() {
        return this.databaseVersion;
    }
    
    synchronized void addListener(final NTFEventListener ntfEventListener) throws SQLException {
        if (this.state == NotificationRegistration.RegistrationState.CLOSED) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 251);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (!this.jdbcGetsNotification) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 247);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final int length = this.listeners.length;
        for (int i = 0; i < length; ++i) {
            if (this.listeners[i].getListener() == ntfEventListener.getListener()) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 248);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        final NTFEventListener[] listeners = new NTFEventListener[length + 1];
        System.arraycopy(this.listeners, 0, listeners, 0, length);
        listeners[length] = ntfEventListener;
        this.listeners = listeners;
    }
    
    synchronized void removeListener(final EventListener eventListener) throws SQLException {
        int length;
        int n;
        for (length = this.listeners.length, n = 0; n < length && this.listeners[n].getListener() != eventListener; ++n) {}
        if (n == length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 249);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final NTFEventListener[] listeners = new NTFEventListener[length - 1];
        int n2 = 0;
        for (int i = 0; i < length; ++i) {
            if (this.listeners[i].getListener() != eventListener) {
                listeners[n2++] = this.listeners[i];
            }
        }
        this.listeners = listeners;
    }
    
    void notify(final NTFDCNEvent ntfdcnEvent) {
        final NTFEventListener[] listeners = this.listeners;
        for (int length = listeners.length, i = 0; i < length; ++i) {
            final Executor executor = listeners[i].getExecutor();
            if (executor != null) {
                executor.execute(new Runnable() {
                    final /* synthetic */ DatabaseChangeListener val$l = listeners[i].getDCNListener();
                    
                    @Override
                    public void run() {
                        this.val$l.onDatabaseChangeNotification(ntfdcnEvent);
                    }
                });
            }
            else {
                listeners[i].getDCNListener().onDatabaseChangeNotification(ntfdcnEvent);
            }
        }
        if (ntfdcnEvent.isDeregistrationEvent() || this.isPurgeOnNTF) {
            PhysicalConnection.ntfManager.removeRegistration(this);
            PhysicalConnection.ntfManager.freeJdbcRegId(this.getJdbcRegId());
            PhysicalConnection.ntfManager.cleanListenersT4C(this.getClientTCPPort());
            this.state = NotificationRegistration.RegistrationState.CLOSED;
        }
    }
    
    void notify(final NTFAQEvent ntfaqEvent) {
        final NTFEventListener[] listeners = this.listeners;
        for (int length = listeners.length, i = 0; i < length; ++i) {
            final Executor executor = listeners[i].getExecutor();
            if (executor != null) {
                executor.execute(new Runnable() {
                    final /* synthetic */ AQNotificationListener val$l = listeners[i].getAQListener();
                    
                    @Override
                    public void run() {
                        this.val$l.onAQNotification(ntfaqEvent);
                    }
                });
            }
            else {
                listeners[i].getAQListener().onAQNotification(ntfaqEvent);
            }
        }
        if (ntfaqEvent.getEventType() == AQNotificationEvent.EventType.DEREG || this.isPurgeOnNTF) {
            PhysicalConnection.ntfManager.removeRegistration(this);
            PhysicalConnection.ntfManager.freeJdbcRegId(this.getJdbcRegId());
            PhysicalConnection.ntfManager.cleanListenersT4C(this.getClientTCPPort());
            this.state = NotificationRegistration.RegistrationState.CLOSED;
        }
    }
    
    public Properties getRegistrationOptions() {
        return this.options;
    }
    
    int getJdbcRegId() {
        return this.jdbcRegId;
    }
    
    public String getUserName() {
        return this.username;
    }
    
    String getClientHost() {
        return this.clientHost;
    }
    
    int getClientTCPPort() {
        return this.clientTCPPort;
    }
    
    public String getDatabaseName() {
        return this.dbName;
    }
    
    public NotificationRegistration.RegistrationState getState() {
        return this.state;
    }
    
    protected void setState(final NotificationRegistration.RegistrationState state) {
        this.state = state;
    }
    
    int getNamespace() {
        return this.namespace;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
