// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Locale;
import java.sql.NClob;
import java.sql.RowId;
import java.sql.ParameterMetaData;
import java.net.URL;
import java.sql.Statement;
import java.sql.BatchUpdateException;
import oracle.jdbc.internal.ObjectData;
import java.sql.SQLData;
import java.io.Serializable;
import oracle.jdbc.oracore.OracleTypeNUMBER;
import java.sql.Ref;
import oracle.sql.REF;
import oracle.jdbc.OracleConnection;
import oracle.sql.ORAData;
import oracle.sql.Datum;
import oracle.sql.CustomDatum;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import java.io.ByteArrayInputStream;
import oracle.sql.BFILE;
import java.sql.Clob;
import java.sql.Blob;
import oracle.sql.NUMBER;
import oracle.sql.DATE;
import oracle.sql.CharacterSet;
import oracle.sql.CHAR;
import oracle.sql.RAW;
import oracle.sql.STRUCT;
import java.sql.SQLXML;
import oracle.sql.OPAQUE;
import oracle.jdbc.oracore.OracleTypeCOLLECTION;
import oracle.sql.ARRAY;
import java.sql.Array;
import oracle.sql.ROWID;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.ArrayDescriptor;
import java.sql.Connection;
import oracle.sql.StructDescriptor;
import java.sql.ResultSetMetaData;
import java.sql.ResultSet;
import oracle.jdbc.oracore.OracleType;
import java.sql.SQLException;
import java.io.InputStream;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import oracle.jdbc.oracore.OracleTypeADT;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.TimeZone;

abstract class OraclePreparedStatement extends OracleStatement implements oracle.jdbc.internal.OraclePreparedStatement, ScrollRsetStatement
{
    int numberOfBindRowsAllocated;
    static Binder theStaticVarnumCopyingBinder;
    static Binder theStaticVarnumNullBinder;
    Binder theVarnumNullBinder;
    static Binder theStaticBooleanBinder;
    Binder theBooleanBinder;
    static Binder theStaticByteBinder;
    Binder theByteBinder;
    static Binder theStaticShortBinder;
    Binder theShortBinder;
    static Binder theStaticIntBinder;
    Binder theIntBinder;
    static Binder theStaticLongBinder;
    Binder theLongBinder;
    static Binder theStaticFloatBinder;
    Binder theFloatBinder;
    static Binder theStaticDoubleBinder;
    Binder theDoubleBinder;
    static Binder theStaticBigDecimalBinder;
    Binder theBigDecimalBinder;
    static Binder theStaticVarcharCopyingBinder;
    static Binder theStaticVarcharNullBinder;
    Binder theVarcharNullBinder;
    static Binder theStaticStringBinder;
    Binder theStringBinder;
    static Binder theStaticSetCHARCopyingBinder;
    static Binder theStaticSetCHARBinder;
    static Binder theStaticLittleEndianSetCHARBinder;
    static Binder theStaticSetCHARNullBinder;
    Binder theSetCHARBinder;
    Binder theSetCHARNullBinder;
    static Binder theStaticFixedCHARCopyingBinder;
    static Binder theStaticFixedCHARBinder;
    static Binder theStaticFixedCHARNullBinder;
    Binder theFixedCHARBinder;
    Binder theFixedCHARNullBinder;
    static Binder theStaticDateCopyingBinder;
    static Binder theStaticDateBinder;
    static Binder theStaticDateNullBinder;
    Binder theDateBinder;
    Binder theDateNullBinder;
    static Binder theStaticTimeCopyingBinder;
    static Binder theStaticTimeBinder;
    Binder theTimeBinder;
    static Binder theStaticTimestampCopyingBinder;
    static Binder theStaticTimestampBinder;
    static Binder theStaticTimestampNullBinder;
    Binder theTimestampBinder;
    Binder theTimestampNullBinder;
    static Binder theStaticOracleNumberBinder;
    Binder theOracleNumberBinder;
    static Binder theStaticOracleDateBinder;
    Binder theOracleDateBinder;
    static Binder theStaticOracleTimestampBinder;
    Binder theOracleTimestampBinder;
    static Binder theStaticTSTZCopyingBinder;
    static Binder theStaticTSTZBinder;
    static Binder theStaticTSTZNullBinder;
    Binder theTSTZBinder;
    Binder theTSTZNullBinder;
    static Binder theStaticTSLTZCopyingBinder;
    static Binder theStaticTSLTZBinder;
    static Binder theStaticTSLTZNullBinder;
    Binder theTSLTZBinder;
    Binder theTSLTZNullBinder;
    static Binder theStaticRowidCopyingBinder;
    static Binder theStaticRowidBinder;
    static Binder theStaticLittleEndianRowidBinder;
    static Binder theStaticRowidNullBinder;
    static Binder theStaticURowidNullBinder;
    Binder theRowidBinder;
    Binder theRowidNullBinder;
    Binder theURowidBinder;
    Binder theURowidNullBinder;
    static Binder theStaticIntervalDSCopyingBinder;
    static Binder theStaticIntervalDSBinder;
    static Binder theStaticIntervalDSNullBinder;
    Binder theIntervalDSBinder;
    Binder theIntervalDSNullBinder;
    static Binder theStaticIntervalYMCopyingBinder;
    static Binder theStaticIntervalYMBinder;
    static Binder theStaticIntervalYMNullBinder;
    Binder theIntervalYMBinder;
    Binder theIntervalYMNullBinder;
    static Binder theStaticBfileCopyingBinder;
    static Binder theStaticBfileBinder;
    static Binder theStaticBfileNullBinder;
    Binder theBfileBinder;
    Binder theBfileNullBinder;
    static Binder theStaticBlobCopyingBinder;
    static Binder theStaticBlobBinder;
    static Binder theStaticBlobNullBinder;
    Binder theBlobBinder;
    Binder theBlobNullBinder;
    static Binder theStaticClobCopyingBinder;
    static Binder theStaticClobBinder;
    static Binder theStaticClobNullBinder;
    Binder theClobBinder;
    Binder theClobNullBinder;
    static Binder theStaticRawCopyingBinder;
    static Binder theStaticRawBinder;
    static Binder theStaticRawNullBinder;
    Binder theRawBinder;
    Binder theRawNullBinder;
    static Binder theStaticPlsqlRawCopyingBinder;
    static Binder theStaticPlsqlRawBinder;
    Binder thePlsqlRawBinder;
    static Binder theStaticBinaryFloatCopyingBinder;
    static Binder theStaticBinaryFloatBinder;
    static Binder theStaticBinaryFloatNullBinder;
    Binder theBinaryFloatBinder;
    Binder theBinaryFloatNullBinder;
    static Binder theStaticBINARY_FLOATCopyingBinder;
    static Binder theStaticBINARY_FLOATBinder;
    static Binder theStaticBINARY_FLOATNullBinder;
    Binder theBINARY_FLOATBinder;
    Binder theBINARY_FLOATNullBinder;
    static Binder theStaticBinaryDoubleCopyingBinder;
    static Binder theStaticBinaryDoubleBinder;
    static Binder theStaticBinaryDoubleNullBinder;
    Binder theBinaryDoubleBinder;
    Binder theBinaryDoubleNullBinder;
    static Binder theStaticBINARY_DOUBLECopyingBinder;
    static Binder theStaticBINARY_DOUBLEBinder;
    static Binder theStaticBINARY_DOUBLENullBinder;
    Binder theBINARY_DOUBLEBinder;
    Binder theBINARY_DOUBLENullBinder;
    static Binder theStaticLongStreamBinder;
    Binder theLongStreamBinder;
    static Binder theStaticLongStreamForStringBinder;
    Binder theLongStreamForStringBinder;
    static Binder theStaticLongStreamForStringCopyingBinder;
    static Binder theStaticLongRawStreamBinder;
    Binder theLongRawStreamBinder;
    static Binder theStaticLongRawStreamForBytesBinder;
    Binder theLongRawStreamForBytesBinder;
    static Binder theStaticLongRawStreamForBytesCopyingBinder;
    static Binder theStaticNamedTypeCopyingBinder;
    static Binder theStaticNamedTypeBinder;
    static Binder theStaticNamedTypeNullBinder;
    Binder theNamedTypeBinder;
    Binder theNamedTypeNullBinder;
    static Binder theStaticRefTypeCopyingBinder;
    static Binder theStaticRefTypeBinder;
    static Binder theStaticRefTypeNullBinder;
    Binder theRefTypeBinder;
    Binder theRefTypeNullBinder;
    static Binder theStaticPlsqlIbtCopyingBinder;
    static Binder theStaticPlsqlIbtBinder;
    static Binder theStaticPlsqlIbtNullBinder;
    Binder thePlsqlIbtBinder;
    Binder thePlsqlNullBinder;
    static Binder theStaticOutBinder;
    Binder theOutBinder;
    static Binder theStaticReturnParamBinder;
    Binder theReturnParamBinder;
    static Binder theStaticT4CRowidBinder;
    static Binder theStaticT4CURowidBinder;
    static Binder theStaticT4CRowidNullBinder;
    static Binder theStaticT4CURowidNullBinder;
    private static final TimeZone UTC_TIME_ZONE;
    private static final Calendar UTC_US_CALENDAR;
    protected Calendar cachedUTCUSCalendar;
    public static final int TypeBinder_BYTELEN = 24;
    char[] digits;
    Binder[][] binders;
    int[][] parameterInt;
    long[][] parameterLong;
    float[][] parameterFloat;
    double[][] parameterDouble;
    BigDecimal[][] parameterBigDecimal;
    String[][] parameterString;
    Date[][] parameterDate;
    Time[][] parameterTime;
    Timestamp[][] parameterTimestamp;
    byte[][][] parameterDatum;
    OracleTypeADT[][] parameterOtype;
    CLOB[] lastBoundClobs;
    BLOB[] lastBoundBlobs;
    PlsqlIbtBindInfo[][] parameterPlsqlIbt;
    Binder[] currentRowBinders;
    int[] currentRowCharLens;
    Accessor[] currentRowBindAccessors;
    short[] currentRowFormOfUse;
    boolean currentRowNeedToPrepareBinds;
    int[] currentBatchCharLens;
    Accessor[] currentBatchBindAccessors;
    short[] currentBatchFormOfUse;
    boolean currentBatchNeedToPrepareBinds;
    PushedBatch pushedBatches;
    PushedBatch pushedBatchesTail;
    int cachedBindByteSize;
    int cachedBindCharSize;
    int cachedBindIndicatorSize;
    int totalBindByteLength;
    int totalBindCharLength;
    int totalBindIndicatorLength;
    static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
    static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
    static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
    static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
    static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
    static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
    static final int BIND_METADATA_TYPE_OFFSET = 0;
    static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
    static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
    static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
    static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
    static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
    static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
    static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
    static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
    static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
    static final int BIND_METADATA_PER_POSITION_SIZE = 10;
    static final int SETLOB_NO_LENGTH = -1;
    int bindBufferCapacity;
    int numberOfBoundRows;
    int indicatorsOffset;
    int valueLengthsOffset;
    boolean preparedAllBinds;
    boolean preparedCharBinds;
    Binder[] lastBinders;
    byte[] lastBoundBytes;
    int lastBoundByteOffset;
    char[] lastBoundChars;
    int lastBoundCharOffset;
    int[] lastBoundByteOffsets;
    int[] lastBoundCharOffsets;
    int[] lastBoundByteLens;
    int[] lastBoundCharLens;
    short[] lastBoundInds;
    short[] lastBoundLens;
    boolean lastBoundNeeded;
    byte[][] lastBoundTypeBytes;
    OracleTypeADT[] lastBoundTypeOtypes;
    InputStream[] lastBoundStream;
    private static final int STREAM_MAX_BYTES_SQL = Integer.MAX_VALUE;
    int maxRawBytesSql;
    int maxRawBytesPlsql;
    int maxVcsCharsSql;
    int maxVcsNCharsSql;
    int maxVcsBytesPlsql;
    private int maxCharSize;
    private int maxNCharSize;
    private int charMaxCharsSql;
    private int charMaxNCharsSql;
    private int maxVcsCharsPlsql;
    private int maxVcsNCharsPlsql;
    int maxIbtVarcharElementLength;
    private int maxStreamCharsSql;
    private int maxStreamNCharsSql;
    protected boolean isServerCharSetFixedWidth;
    private boolean isServerNCharSetFixedWidth;
    int minVcsBindSize;
    int prematureBatchCount;
    boolean checkBindTypes;
    boolean scrollRsetTypeSolved;
    int SetBigStringTryClob;
    static final int BSTYLE_UNKNOWN = 0;
    static final int BSTYLE_ORACLE = 1;
    static final int BSTYLE_JDBC = 2;
    int m_batchStyle;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OraclePreparedStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        this(physicalConnection, s, n, n2, 1003, 1007);
        this.cacheState = 1;
    }
    
    OraclePreparedStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2, final int n3, final int n4) throws SQLException {
        super(physicalConnection, n, n2, n3, n4);
        this.theVarnumNullBinder = OraclePreparedStatement.theStaticVarnumNullBinder;
        this.theBooleanBinder = OraclePreparedStatement.theStaticBooleanBinder;
        this.theByteBinder = OraclePreparedStatement.theStaticByteBinder;
        this.theShortBinder = OraclePreparedStatement.theStaticShortBinder;
        this.theIntBinder = OraclePreparedStatement.theStaticIntBinder;
        this.theLongBinder = OraclePreparedStatement.theStaticLongBinder;
        this.theFloatBinder = null;
        this.theDoubleBinder = null;
        this.theBigDecimalBinder = OraclePreparedStatement.theStaticBigDecimalBinder;
        this.theVarcharNullBinder = OraclePreparedStatement.theStaticVarcharNullBinder;
        this.theStringBinder = OraclePreparedStatement.theStaticStringBinder;
        this.theSetCHARNullBinder = OraclePreparedStatement.theStaticSetCHARNullBinder;
        this.theFixedCHARBinder = OraclePreparedStatement.theStaticFixedCHARBinder;
        this.theFixedCHARNullBinder = OraclePreparedStatement.theStaticFixedCHARNullBinder;
        this.theDateBinder = OraclePreparedStatement.theStaticDateBinder;
        this.theDateNullBinder = OraclePreparedStatement.theStaticDateNullBinder;
        this.theTimeBinder = OraclePreparedStatement.theStaticTimeBinder;
        this.theTimestampBinder = OraclePreparedStatement.theStaticTimestampBinder;
        this.theTimestampNullBinder = OraclePreparedStatement.theStaticTimestampNullBinder;
        this.theOracleNumberBinder = OraclePreparedStatement.theStaticOracleNumberBinder;
        this.theOracleDateBinder = OraclePreparedStatement.theStaticOracleDateBinder;
        this.theOracleTimestampBinder = OraclePreparedStatement.theStaticOracleTimestampBinder;
        this.theTSTZBinder = OraclePreparedStatement.theStaticTSTZBinder;
        this.theTSTZNullBinder = OraclePreparedStatement.theStaticTSTZNullBinder;
        this.theTSLTZBinder = OraclePreparedStatement.theStaticTSLTZBinder;
        this.theTSLTZNullBinder = OraclePreparedStatement.theStaticTSLTZNullBinder;
        this.theRowidNullBinder = OraclePreparedStatement.theStaticRowidNullBinder;
        this.theURowidNullBinder = OraclePreparedStatement.theStaticURowidNullBinder;
        this.theIntervalDSBinder = OraclePreparedStatement.theStaticIntervalDSBinder;
        this.theIntervalDSNullBinder = OraclePreparedStatement.theStaticIntervalDSNullBinder;
        this.theIntervalYMBinder = OraclePreparedStatement.theStaticIntervalYMBinder;
        this.theIntervalYMNullBinder = OraclePreparedStatement.theStaticIntervalYMNullBinder;
        this.theBfileBinder = OraclePreparedStatement.theStaticBfileBinder;
        this.theBfileNullBinder = OraclePreparedStatement.theStaticBfileNullBinder;
        this.theBlobBinder = OraclePreparedStatement.theStaticBlobBinder;
        this.theBlobNullBinder = OraclePreparedStatement.theStaticBlobNullBinder;
        this.theClobBinder = OraclePreparedStatement.theStaticClobBinder;
        this.theClobNullBinder = OraclePreparedStatement.theStaticClobNullBinder;
        this.theRawBinder = OraclePreparedStatement.theStaticRawBinder;
        this.theRawNullBinder = OraclePreparedStatement.theStaticRawNullBinder;
        this.thePlsqlRawBinder = OraclePreparedStatement.theStaticPlsqlRawBinder;
        this.theBinaryFloatBinder = OraclePreparedStatement.theStaticBinaryFloatBinder;
        this.theBinaryFloatNullBinder = OraclePreparedStatement.theStaticBinaryFloatNullBinder;
        this.theBINARY_FLOATBinder = OraclePreparedStatement.theStaticBINARY_FLOATBinder;
        this.theBINARY_FLOATNullBinder = OraclePreparedStatement.theStaticBINARY_FLOATNullBinder;
        this.theBinaryDoubleBinder = OraclePreparedStatement.theStaticBinaryDoubleBinder;
        this.theBinaryDoubleNullBinder = OraclePreparedStatement.theStaticBinaryDoubleNullBinder;
        this.theBINARY_DOUBLEBinder = OraclePreparedStatement.theStaticBINARY_DOUBLEBinder;
        this.theBINARY_DOUBLENullBinder = OraclePreparedStatement.theStaticBINARY_DOUBLENullBinder;
        this.theLongStreamBinder = OraclePreparedStatement.theStaticLongStreamBinder;
        this.theLongStreamForStringBinder = OraclePreparedStatement.theStaticLongStreamForStringBinder;
        this.theLongRawStreamBinder = OraclePreparedStatement.theStaticLongRawStreamBinder;
        this.theLongRawStreamForBytesBinder = OraclePreparedStatement.theStaticLongRawStreamForBytesBinder;
        this.theNamedTypeBinder = OraclePreparedStatement.theStaticNamedTypeBinder;
        this.theNamedTypeNullBinder = OraclePreparedStatement.theStaticNamedTypeNullBinder;
        this.theRefTypeBinder = OraclePreparedStatement.theStaticRefTypeBinder;
        this.theRefTypeNullBinder = OraclePreparedStatement.theStaticRefTypeNullBinder;
        this.thePlsqlIbtBinder = OraclePreparedStatement.theStaticPlsqlIbtBinder;
        this.thePlsqlNullBinder = OraclePreparedStatement.theStaticPlsqlIbtNullBinder;
        this.theOutBinder = OraclePreparedStatement.theStaticOutBinder;
        this.theReturnParamBinder = OraclePreparedStatement.theStaticReturnParamBinder;
        this.cachedUTCUSCalendar = (Calendar)OraclePreparedStatement.UTC_US_CALENDAR.clone();
        this.digits = new char[20];
        this.currentRowNeedToPrepareBinds = true;
        this.cachedBindByteSize = 0;
        this.cachedBindCharSize = 0;
        this.cachedBindIndicatorSize = 0;
        this.lastBoundNeeded = false;
        this.maxCharSize = 0;
        this.maxNCharSize = 0;
        this.charMaxCharsSql = 0;
        this.charMaxNCharsSql = 0;
        this.maxVcsCharsPlsql = 0;
        this.maxVcsNCharsPlsql = 0;
        this.maxIbtVarcharElementLength = 0;
        this.maxStreamCharsSql = 0;
        this.maxStreamNCharsSql = 0;
        this.isServerCharSetFixedWidth = false;
        this.isServerNCharSetFixedWidth = false;
        this.checkBindTypes = true;
        this.SetBigStringTryClob = 0;
        this.m_batchStyle = 0;
        this.cacheState = 1;
        if (n > 1) {
            this.setOracleBatchStyle();
        }
        this.theSetCHARBinder = (physicalConnection.useLittleEndianSetCHARBinder() ? OraclePreparedStatement.theStaticLittleEndianSetCHARBinder : OraclePreparedStatement.theStaticSetCHARBinder);
        final Binder binder = physicalConnection.useLittleEndianSetCHARBinder() ? OraclePreparedStatement.theStaticLittleEndianRowidBinder : OraclePreparedStatement.theStaticRowidBinder;
        this.theRowidBinder = binder;
        this.theURowidBinder = binder;
        this.statementType = 1;
        this.currentRow = -1;
        this.needToParse = true;
        this.processEscapes = physicalConnection.processEscapes;
        this.sqlObject.initialize(s);
        this.sqlKind = this.sqlObject.getSqlKind();
        this.clearParameters = true;
        this.scrollRsetTypeSolved = false;
        this.prematureBatchCount = 0;
        this.initializeBinds();
        this.minVcsBindSize = physicalConnection.minVcsBindSize;
        this.maxRawBytesSql = physicalConnection.maxRawBytesSql;
        this.maxRawBytesPlsql = physicalConnection.maxRawBytesPlsql;
        this.maxVcsCharsSql = physicalConnection.maxVcsCharsSql;
        this.maxVcsNCharsSql = physicalConnection.maxVcsNCharsSql;
        this.maxVcsBytesPlsql = physicalConnection.maxVcsBytesPlsql;
        this.maxIbtVarcharElementLength = physicalConnection.maxIbtVarcharElementLength;
        this.maxCharSize = this.connection.conversion.sMaxCharSize;
        this.maxNCharSize = this.connection.conversion.maxNCharSize;
        this.maxVcsCharsPlsql = this.maxVcsBytesPlsql / this.maxCharSize;
        this.maxVcsNCharsPlsql = this.maxVcsBytesPlsql / this.maxNCharSize;
        this.maxStreamCharsSql = Integer.MAX_VALUE / this.maxCharSize;
        this.maxStreamNCharsSql = this.maxRawBytesSql / this.maxNCharSize;
        this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth;
        this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth;
    }
    
    void allocBinds(final int n) throws SQLException {
        final boolean b = n > this.numberOfBindRowsAllocated;
        this.initializeIndicatorSubRange();
        final int n2 = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10;
        final int n3 = n * this.numberOfBindPositions;
        final int totalBindIndicatorLength = n2 + 2 * n3;
        if (totalBindIndicatorLength > this.totalBindIndicatorLength) {
            final short[] bindIndicators = this.bindIndicators;
            final int bindIndicatorOffset = this.bindIndicatorOffset;
            this.bindIndicatorOffset = 0;
            this.bindIndicators = new short[totalBindIndicatorLength];
            this.totalBindIndicatorLength = totalBindIndicatorLength;
            if (bindIndicators != null && b) {
                System.arraycopy(bindIndicators, bindIndicatorOffset, this.bindIndicators, this.bindIndicatorOffset, n2);
            }
        }
        this.bindIndicatorSubRange += this.bindIndicatorOffset;
        this.bindIndicators[this.bindIndicatorSubRange + 0] = (short)this.numberOfBindPositions;
        this.indicatorsOffset = this.bindIndicatorOffset + n2;
        this.valueLengthsOffset = this.indicatorsOffset + n3;
        int indicatorsOffset = this.indicatorsOffset;
        int valueLengthsOffset = this.valueLengthsOffset;
        int n4 = this.bindIndicatorSubRange + 5;
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            this.bindIndicators[n4 + 5] = (short)(indicatorsOffset >> 16);
            this.bindIndicators[n4 + 6] = (short)(indicatorsOffset & 0xFFFF);
            this.bindIndicators[n4 + 7] = (short)(valueLengthsOffset >> 16);
            this.bindIndicators[n4 + 8] = (short)(valueLengthsOffset & 0xFFFF);
            indicatorsOffset += n;
            valueLengthsOffset += n;
            n4 += 10;
        }
    }
    
    void initializeBinds() throws SQLException {
        this.numberOfBindPositions = this.sqlObject.getParameterCount();
        this.numReturnParams = this.sqlObject.getReturnParameterCount();
        if (this.numberOfBindPositions == 0) {
            this.currentRowNeedToPrepareBinds = false;
            return;
        }
        this.numberOfBindRowsAllocated = this.batch;
        this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        this.currentRowBinders = this.binders[0];
        this.currentRowCharLens = new int[this.numberOfBindPositions];
        this.currentBatchCharLens = new int[this.numberOfBindPositions];
        this.currentRowFormOfUse = new short[this.numberOfBindPositions];
        this.currentBatchFormOfUse = new short[this.numberOfBindPositions];
        this.lastBoundClobs = new CLOB[this.numberOfBindPositions];
        this.lastBoundBlobs = new BLOB[this.numberOfBindPositions];
        short n = 1;
        if (this.connection.defaultnchar) {
            n = 2;
        }
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            this.currentRowFormOfUse[i] = n;
            this.currentBatchFormOfUse[i] = n;
        }
        this.lastBinders = new Binder[this.numberOfBindPositions];
        this.lastBoundCharLens = new int[this.numberOfBindPositions];
        this.lastBoundByteOffsets = new int[this.numberOfBindPositions];
        this.lastBoundCharOffsets = new int[this.numberOfBindPositions];
        this.lastBoundByteLens = new int[this.numberOfBindPositions];
        this.lastBoundInds = new short[this.numberOfBindPositions];
        this.lastBoundLens = new short[this.numberOfBindPositions];
        this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][];
        this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions];
        this.allocBinds(this.numberOfBindRowsAllocated);
    }
    
    void growBinds(final int numberOfBindRowsAllocated) throws SQLException {
        final Binder[][] binders = this.binders;
        this.binders = new Binder[numberOfBindRowsAllocated][];
        if (binders != null) {
            System.arraycopy(binders, 0, this.binders, 0, this.numberOfBindRowsAllocated);
        }
        for (int i = this.numberOfBindRowsAllocated; i < numberOfBindRowsAllocated; ++i) {
            this.binders[i] = new Binder[this.numberOfBindPositions];
        }
        this.allocBinds(numberOfBindRowsAllocated);
        if (this.parameterInt != null) {
            System.arraycopy(this.parameterInt, 0, this.parameterInt = new int[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int j = this.numberOfBindRowsAllocated; j < numberOfBindRowsAllocated; ++j) {
                this.parameterInt[j] = new int[this.numberOfBindPositions];
            }
        }
        if (this.parameterLong != null) {
            System.arraycopy(this.parameterLong, 0, this.parameterLong = new long[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int k = this.numberOfBindRowsAllocated; k < numberOfBindRowsAllocated; ++k) {
                this.parameterLong[k] = new long[this.numberOfBindPositions];
            }
        }
        if (this.parameterFloat != null) {
            System.arraycopy(this.parameterFloat, 0, this.parameterFloat = new float[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int l = this.numberOfBindRowsAllocated; l < numberOfBindRowsAllocated; ++l) {
                this.parameterFloat[l] = new float[this.numberOfBindPositions];
            }
        }
        if (this.parameterDouble != null) {
            System.arraycopy(this.parameterDouble, 0, this.parameterDouble = new double[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated2 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated2 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated2) {
                this.parameterDouble[numberOfBindRowsAllocated2] = new double[this.numberOfBindPositions];
            }
        }
        if (this.parameterBigDecimal != null) {
            System.arraycopy(this.parameterBigDecimal, 0, this.parameterBigDecimal = new BigDecimal[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated3 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated3 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated3) {
                this.parameterBigDecimal[numberOfBindRowsAllocated3] = new BigDecimal[this.numberOfBindPositions];
            }
        }
        if (this.parameterString != null) {
            System.arraycopy(this.parameterString, 0, this.parameterString = new String[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated4 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated4 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated4) {
                this.parameterString[numberOfBindRowsAllocated4] = new String[this.numberOfBindPositions];
            }
        }
        if (this.parameterDate != null) {
            System.arraycopy(this.parameterDate, 0, this.parameterDate = new Date[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated5 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated5 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated5) {
                this.parameterDate[numberOfBindRowsAllocated5] = new Date[this.numberOfBindPositions];
            }
        }
        if (this.parameterTime != null) {
            System.arraycopy(this.parameterTime, 0, this.parameterTime = new Time[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated6 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated6 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated6) {
                this.parameterTime[numberOfBindRowsAllocated6] = new Time[this.numberOfBindPositions];
            }
        }
        if (this.parameterTimestamp != null) {
            System.arraycopy(this.parameterTimestamp, 0, this.parameterTimestamp = new Timestamp[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated7 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated7 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated7) {
                this.parameterTimestamp[numberOfBindRowsAllocated7] = new Timestamp[this.numberOfBindPositions];
            }
        }
        if (this.parameterDatum != null) {
            System.arraycopy(this.parameterDatum, 0, this.parameterDatum = new byte[numberOfBindRowsAllocated][][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated8 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated8 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated8) {
                this.parameterDatum[numberOfBindRowsAllocated8] = new byte[this.numberOfBindPositions][];
            }
        }
        if (this.parameterOtype != null) {
            System.arraycopy(this.parameterOtype, 0, this.parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated9 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated9 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated9) {
                this.parameterOtype[numberOfBindRowsAllocated9] = new OracleTypeADT[this.numberOfBindPositions];
            }
        }
        if (this.parameterStream != null) {
            System.arraycopy(this.parameterStream, 0, this.parameterStream = new InputStream[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated10 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated10 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated10) {
                this.parameterStream[numberOfBindRowsAllocated10] = new InputStream[this.numberOfBindPositions];
            }
        }
        if (this.userStream != null) {
            System.arraycopy(this.userStream, 0, this.userStream = new Object[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated11 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated11 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated11) {
                this.userStream[numberOfBindRowsAllocated11] = new Object[this.numberOfBindPositions];
            }
        }
        if (this.parameterPlsqlIbt != null) {
            System.arraycopy(this.parameterPlsqlIbt, 0, this.parameterPlsqlIbt = new PlsqlIbtBindInfo[numberOfBindRowsAllocated][], 0, this.numberOfBindRowsAllocated);
            for (int numberOfBindRowsAllocated12 = this.numberOfBindRowsAllocated; numberOfBindRowsAllocated12 < numberOfBindRowsAllocated; ++numberOfBindRowsAllocated12) {
                this.parameterPlsqlIbt[numberOfBindRowsAllocated12] = new PlsqlIbtBindInfo[this.numberOfBindPositions];
            }
        }
        this.numberOfBindRowsAllocated = numberOfBindRowsAllocated;
        this.currentRowNeedToPrepareBinds = true;
    }
    
    void processCompletedBindRow(final int n, final boolean b) throws SQLException {
        if (this.numberOfBindPositions == 0) {
            return;
        }
        boolean b2 = false;
        int n2 = 0;
        boolean b3 = false;
        final boolean b4 = this.currentRank == this.firstRowInBatch;
        final Binder[] array = (Binder[])((this.currentRank == 0) ? ((this.lastBinders[0] == null) ? null : this.lastBinders) : this.binders[this.currentRank - 1]);
        if (this.currentRowBindAccessors == null) {
            int n3 = (this.isAutoGeneratedKey && this.clearParameters) ? 1 : 0;
            if (array == null) {
                for (int i = 0; i < this.numberOfBindPositions; ++i) {
                    if (this.currentRowBinders[i] == null) {
                        if (n3 == 0) {
                            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 41, i + 1);
                            sqlException.fillInStackTrace();
                            throw sqlException;
                        }
                        this.registerReturnParamsForAutoKey();
                        n3 = 0;
                    }
                }
            }
            else if (this.checkBindTypes) {
                final OracleTypeADT[] array2 = (OracleTypeADT[])((this.currentRank == 0) ? this.lastBoundTypeOtypes : ((this.parameterOtype == null) ? null : this.parameterOtype[this.currentRank - 1]));
                for (int j = 0; j < this.numberOfBindPositions; ++j) {
                    if (this.currentRowBinders[j] == null && n3 != 0) {
                        this.registerReturnParamsForAutoKey();
                        n3 = 0;
                    }
                    final Binder binder = this.currentRowBinders[j];
                    if (binder == null) {
                        if (this.clearParameters) {
                            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 41, j + 1);
                            sqlException2.fillInStackTrace();
                            throw sqlException2;
                        }
                        this.currentRowBinders[j] = array[j].copyingBinder();
                        if (this.currentRank == 0) {
                            this.currentRowBinders[j].lastBoundValueCleanup(this, j);
                        }
                        this.currentRowCharLens[j] = -1;
                        n2 = 1;
                    }
                    else {
                        final short type = binder.type;
                        if (type != array[j].type || ((type == 109 || type == 111) && !this.parameterOtype[this.currentRank][j].isInHierarchyOf(array2[j])) || (type == 9 && binder.bytelen == 0 != (array[j].bytelen == 0))) {
                            b2 = true;
                        }
                    }
                    if (this.currentBatchFormOfUse[j] != this.currentRowFormOfUse[j]) {
                        b2 = true;
                    }
                }
            }
            else {
                for (int k = 0; k < this.numberOfBindPositions; ++k) {
                    if (this.currentRowBinders[k] == null) {
                        if (this.clearParameters) {
                            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 41, k + 1);
                            sqlException3.fillInStackTrace();
                            throw sqlException3;
                        }
                        this.currentRowBinders[k] = array[k].copyingBinder();
                        if (this.currentRank == 0) {
                            this.currentRowBinders[k].lastBoundValueCleanup(this, k);
                        }
                        this.currentRowCharLens[k] = -1;
                        n2 = 1;
                    }
                }
            }
            if (n2 != 0 && (b4 || this.m_batchStyle == 2)) {
                this.lastBoundNeeded = true;
            }
        }
        else {
            if (array == null) {
                for (int l = 0; l < this.numberOfBindPositions; ++l) {
                    final Binder binder2 = this.currentRowBinders[l];
                    final Accessor accessor = this.currentRowBindAccessors[l];
                    if (binder2 == null) {
                        if (accessor == null) {
                            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 41, l + 1);
                            sqlException4.fillInStackTrace();
                            throw sqlException4;
                        }
                        this.currentRowBinders[l] = this.theOutBinder;
                    }
                    else if (accessor != null && accessor.defineType != binder2.type && (!this.connection.permitTimestampDateMismatch || binder2.type != 180 || accessor.defineType != 12)) {
                        b3 = true;
                    }
                }
            }
            else if (this.checkBindTypes) {
                final OracleTypeADT[] array3 = (OracleTypeADT[])((this.currentRank == 0) ? this.lastBoundTypeOtypes : ((this.parameterOtype == null) ? null : this.parameterOtype[this.currentRank - 1]));
                for (int n4 = 0; n4 < this.numberOfBindPositions; ++n4) {
                    Binder binder3 = this.currentRowBinders[n4];
                    Accessor accessor2 = this.currentRowBindAccessors[n4];
                    if (binder3 == null) {
                        if (this.clearParameters && array[n4] != this.theOutBinder) {
                            final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 41, n4 + 1);
                            sqlException5.fillInStackTrace();
                            throw sqlException5;
                        }
                        binder3 = array[n4];
                        this.currentRowBinders[n4] = binder3;
                        this.currentRowCharLens[n4] = -1;
                        if (binder3 != this.theOutBinder) {
                            n2 = 1;
                        }
                    }
                    else {
                        final short type2 = binder3.type;
                        if (type2 != array[n4].type || ((type2 == 109 || type2 == 111) && !this.parameterOtype[this.currentRank][n4].isInHierarchyOf(array3[n4])) || (type2 == 9 && binder3.bytelen == 0 != (array[n4].bytelen == 0))) {
                            b2 = true;
                        }
                    }
                    if (this.currentBatchFormOfUse[n4] != this.currentRowFormOfUse[n4]) {
                        b2 = true;
                    }
                    final Accessor accessor3 = this.currentBatchBindAccessors[n4];
                    if (accessor2 == null) {
                        accessor2 = accessor3;
                        this.currentRowBindAccessors[n4] = accessor2;
                    }
                    else if (accessor3 != null && accessor2.defineType != accessor3.defineType) {
                        b2 = true;
                    }
                    if (accessor2 != null && binder3 != this.theOutBinder && accessor2.defineType != binder3.type && (!this.connection.permitTimestampDateMismatch || binder3.type != 180 || accessor2.defineType != 12)) {
                        b3 = true;
                    }
                }
            }
            else {
                for (int n5 = 0; n5 < this.numberOfBindPositions; ++n5) {
                    if (this.currentRowBinders[n5] == null) {
                        if (this.clearParameters && array[n5] != this.theOutBinder) {
                            final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 41, n5 + 1);
                            sqlException6.fillInStackTrace();
                            throw sqlException6;
                        }
                        final Binder binder4 = array[n5];
                        this.currentRowBinders[n5] = binder4;
                        this.currentRowCharLens[n5] = -1;
                        if (binder4 != this.theOutBinder) {
                            n2 = 1;
                        }
                    }
                    if (this.currentRowBindAccessors[n5] == null) {
                        this.currentRowBindAccessors[n5] = this.currentBatchBindAccessors[n5];
                    }
                }
            }
            if (n2 != 0 && b4) {
                this.lastBoundNeeded = true;
            }
        }
        if (b2) {
            if (!b4) {
                if (this.m_batchStyle == 2) {
                    this.pushBatch(false);
                }
                else {
                    final int validRows = this.validRows;
                    this.prematureBatchCount = this.sendBatch();
                    this.validRows = validRows;
                    for (int n6 = 0; n6 < this.numberOfBindPositions; ++n6) {
                        this.currentRowBinders[n6].lastBoundValueCleanup(this, n6);
                    }
                    if (n2 != 0) {
                        this.lastBoundNeeded = true;
                    }
                }
            }
            this.needToParse = true;
            this.currentRowNeedToPrepareBinds = true;
            this.needToPrepareDefineBuffer = true;
        }
        else if (b) {
            this.pushBatch(false);
            this.needToParse = false;
            this.currentBatchNeedToPrepareBinds = false;
        }
        if (b3) {
            final SQLException sqlException7 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12);
            sqlException7.fillInStackTrace();
            throw sqlException7;
        }
        for (int n7 = 0; n7 < this.numberOfBindPositions; ++n7) {
            int n8 = this.currentRowCharLens[n7];
            if (n8 == -1 && this.currentRank == this.firstRowInBatch) {
                n8 = this.lastBoundCharLens[n7];
            }
            if (this.currentBatchCharLens[n7] < n8) {
                this.currentBatchCharLens[n7] = n8;
            }
            this.currentRowCharLens[n7] = 0;
            this.currentBatchFormOfUse[n7] = this.currentRowFormOfUse[n7];
        }
        if (this.currentRowNeedToPrepareBinds) {
            this.currentBatchNeedToPrepareBinds = true;
        }
        if (this.currentRowBindAccessors != null) {
            Accessor[] currentBatchBindAccessors = this.currentBatchBindAccessors;
            this.currentBatchBindAccessors = this.currentRowBindAccessors;
            if (currentBatchBindAccessors == null) {
                currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
            }
            else {
                for (int n9 = 0; n9 < this.numberOfBindPositions; ++n9) {
                    currentBatchBindAccessors[n9] = null;
                }
            }
            this.currentRowBindAccessors = currentBatchBindAccessors;
        }
        final int n10 = this.currentRank + 1;
        if (n10 < n) {
            if (n10 >= this.numberOfBindRowsAllocated) {
                int n11 = this.numberOfBindRowsAllocated << 1;
                if (n11 <= n10) {
                    n11 = n10 + 1;
                }
                this.growBinds(n11);
                this.currentBatchNeedToPrepareBinds = true;
                if (this.pushedBatches != null) {
                    this.pushedBatches.current_batch_need_to_prepare_binds = true;
                }
            }
            this.currentRowBinders = this.binders[n10];
        }
        else {
            this.setupBindBuffers(0, n);
            this.currentRowBinders = this.binders[0];
        }
        this.currentRowNeedToPrepareBinds = false;
        this.clearParameters = false;
    }
    
    void processPlsqlIndexTabBinds(final int n) throws SQLException {
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        final Binder[] array = this.binders[n];
        final PlsqlIbtBindInfo[] array2 = (PlsqlIbtBindInfo[])((this.parameterPlsqlIbt == null) ? null : this.parameterPlsqlIbt[n]);
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            final Binder binder = array[i];
            final Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[i];
            final PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : ((PlsqlIndexTableAccessor)accessor);
            if (binder.type == 998) {
                final PlsqlIbtBindInfo plsqlIbtBindInfo = array2[i];
                if (plsqlIndexTableAccessor != null) {
                    if (plsqlIbtBindInfo.element_internal_type != plsqlIndexTableAccessor.elementInternalType) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    if (plsqlIbtBindInfo.maxLen < plsqlIndexTableAccessor.maxNumberOfElements) {
                        plsqlIbtBindInfo.maxLen = plsqlIndexTableAccessor.maxNumberOfElements;
                    }
                    if (plsqlIbtBindInfo.elemMaxLen < plsqlIndexTableAccessor.elementMaxLen) {
                        plsqlIbtBindInfo.elemMaxLen = plsqlIndexTableAccessor.elementMaxLen;
                    }
                    if (plsqlIbtBindInfo.ibtByteLength > 0) {
                        plsqlIbtBindInfo.ibtByteLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen;
                    }
                    else {
                        plsqlIbtBindInfo.ibtCharLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen;
                    }
                }
                ++n2;
                n4 += plsqlIbtBindInfo.ibtByteLength;
                n5 += plsqlIbtBindInfo.ibtCharLength;
                n3 += plsqlIbtBindInfo.maxLen;
            }
            else if (plsqlIndexTableAccessor != null) {
                ++n2;
                n4 += plsqlIndexTableAccessor.ibtByteLength;
                n5 += plsqlIndexTableAccessor.ibtCharLength;
                n3 += plsqlIndexTableAccessor.maxNumberOfElements;
            }
        }
        if (n2 == 0) {
            return;
        }
        this.ibtBindIndicatorSize = 6 + n2 * 8 + n3 * 2;
        this.ibtBindIndicators = new short[this.ibtBindIndicatorSize];
        this.ibtBindIndicatorOffset = 0;
        if (n4 > 0) {
            this.ibtBindBytes = new byte[n4];
        }
        this.ibtBindByteOffset = 0;
        if (n5 > 0) {
            this.ibtBindChars = new char[n5];
        }
        this.ibtBindCharOffset = 0;
        int ibtBindByteOffset = this.ibtBindByteOffset;
        int ibtBindCharOffset = this.ibtBindCharOffset;
        int ibtBindIndicatorOffset = this.ibtBindIndicatorOffset;
        int n6 = ibtBindIndicatorOffset + 6 + n2 * 8;
        this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n2 >> 16);
        this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n2 & 0xFFFF);
        this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n4 >> 16);
        this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n4 & 0xFFFF);
        this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n5 >> 16);
        this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n5 & 0xFFFF);
        for (int j = 0; j < this.numberOfBindPositions; ++j) {
            final Binder binder2 = array[j];
            final Accessor accessor2 = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[j];
            final PlsqlIndexTableAccessor plsqlIndexTableAccessor2 = (accessor2 == null || accessor2.defineType != 998) ? null : ((PlsqlIndexTableAccessor)accessor2);
            if (binder2.type == 998) {
                final PlsqlIbtBindInfo plsqlIbtBindInfo2 = array2[j];
                final int maxLen = plsqlIbtBindInfo2.maxLen;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)plsqlIbtBindInfo2.element_internal_type;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)plsqlIbtBindInfo2.elemMaxLen;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(maxLen >> 16);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(maxLen & 0xFFFF);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(plsqlIbtBindInfo2.curLen >> 16);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(plsqlIbtBindInfo2.curLen & 0xFFFF);
                int n7;
                if (plsqlIbtBindInfo2.ibtByteLength > 0) {
                    n7 = ibtBindByteOffset;
                    ibtBindByteOffset += plsqlIbtBindInfo2.ibtByteLength;
                }
                else {
                    n7 = ibtBindCharOffset;
                    ibtBindCharOffset += plsqlIbtBindInfo2.ibtCharLength;
                }
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n7 >> 16);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(n7 & 0xFFFF);
                plsqlIbtBindInfo2.ibtValueIndex = n7;
                plsqlIbtBindInfo2.ibtIndicatorIndex = n6;
                plsqlIbtBindInfo2.ibtLengthIndex = n6 + maxLen;
                if (plsqlIndexTableAccessor2 != null) {
                    plsqlIndexTableAccessor2.ibtIndicatorIndex = plsqlIbtBindInfo2.ibtIndicatorIndex;
                    plsqlIndexTableAccessor2.ibtLengthIndex = plsqlIbtBindInfo2.ibtLengthIndex;
                    plsqlIndexTableAccessor2.ibtMetaIndex = ibtBindIndicatorOffset - 8;
                    plsqlIndexTableAccessor2.ibtValueIndex = n7;
                }
                n6 += 2 * maxLen;
            }
            else if (plsqlIndexTableAccessor2 != null) {
                final int maxNumberOfElements = plsqlIndexTableAccessor2.maxNumberOfElements;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)plsqlIndexTableAccessor2.elementInternalType;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)plsqlIndexTableAccessor2.elementMaxLen;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(maxNumberOfElements >> 16);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(maxNumberOfElements & 0xFFFF);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = 0;
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = 0;
                int ibtValueIndex;
                if (plsqlIndexTableAccessor2.ibtByteLength > 0) {
                    ibtValueIndex = ibtBindByteOffset;
                    ibtBindByteOffset += plsqlIndexTableAccessor2.ibtByteLength;
                }
                else {
                    ibtValueIndex = ibtBindCharOffset;
                    ibtBindCharOffset += plsqlIndexTableAccessor2.ibtCharLength;
                }
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(ibtValueIndex >> 16);
                this.ibtBindIndicators[ibtBindIndicatorOffset++] = (short)(ibtValueIndex & 0xFFFF);
                plsqlIndexTableAccessor2.ibtValueIndex = ibtValueIndex;
                plsqlIndexTableAccessor2.ibtIndicatorIndex = n6;
                plsqlIndexTableAccessor2.ibtLengthIndex = n6 + maxNumberOfElements;
                plsqlIndexTableAccessor2.ibtMetaIndex = ibtBindIndicatorOffset - 8;
                n6 += 2 * maxNumberOfElements;
            }
        }
    }
    
    void initializeBindSubRanges(final int n, final int n2) {
        this.bindByteSubRange = 0;
        this.bindCharSubRange = 0;
    }
    
    int calculateIndicatorSubRangeSize() {
        return 0;
    }
    
    short getInoutIndicator(final int n) {
        return 0;
    }
    
    @Override
    void initializeIndicatorSubRange() {
        this.bindIndicatorSubRange = this.calculateIndicatorSubRangeSize();
    }
    
    void prepareBindPreambles(final int n, final int n2) {
    }
    
    void setupBindBuffers(final int n, final int n2) throws SQLException {
        try {
            if (this.numberOfBindPositions == 0) {
                if (n2 != 0) {
                    if (this.bindIndicators == null) {
                        this.allocBinds(n2);
                    }
                    this.numberOfBoundRows = n2;
                    this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16);
                    this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF);
                }
                return;
            }
            this.preparedAllBinds = this.currentBatchNeedToPrepareBinds;
            this.preparedCharBinds = false;
            this.currentBatchNeedToPrepareBinds = false;
            this.numberOfBoundRows = n2;
            this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16);
            this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF);
            int bindBufferCapacity = this.bindBufferCapacity;
            if (this.numberOfBoundRows > this.bindBufferCapacity) {
                bindBufferCapacity = this.numberOfBoundRows;
                this.preparedAllBinds = true;
            }
            if (this.currentBatchBindAccessors != null) {
                if (this.outBindAccessors == null) {
                    this.outBindAccessors = new Accessor[this.numberOfBindPositions];
                }
                for (int i = 0; i < this.numberOfBindPositions; ++i) {
                    final Accessor accessor = this.currentBatchBindAccessors[i];
                    if ((this.outBindAccessors[i] = accessor) != null) {
                        final int charLength = accessor.charLength;
                        if (charLength == 0 || this.currentBatchCharLens[i] < charLength) {
                            this.currentBatchCharLens[i] = charLength;
                        }
                    }
                }
            }
            int n3 = 0;
            int n4 = 0;
            int n6;
            final int n5 = n6 = this.bindIndicatorSubRange + 5;
            if (this.preparedAllBinds) {
                this.preparedCharBinds = true;
                final Binder[] array = this.binders[n];
                for (int j = 0; j < this.numberOfBindPositions; ++j) {
                    final Binder binder = array[j];
                    final int n7 = this.currentBatchCharLens[j];
                    int n8;
                    short type;
                    if (binder == this.theOutBinder) {
                        final Accessor accessor2 = this.currentBatchBindAccessors[j];
                        n8 = accessor2.byteLength;
                        type = (short)accessor2.defineType;
                    }
                    else {
                        n8 = binder.bytelen;
                        type = binder.type;
                    }
                    n4 += n8;
                    n3 += n7;
                    this.bindIndicators[n6 + 0] = type;
                    this.bindIndicators[n6 + 1] = (short)n8;
                    this.bindIndicators[n6 + 2] = (short)n7;
                    this.bindIndicators[n6 + 9] = this.currentBatchFormOfUse[j];
                    n6 += 10;
                }
            }
            else if (this.preparedCharBinds) {
                for (int k = 0; k < this.numberOfBindPositions; ++k) {
                    final int n9 = this.currentBatchCharLens[k];
                    n3 += n9;
                    this.bindIndicators[n6 + 2] = (short)n9;
                    n6 += 10;
                }
            }
            else {
                for (int l = 0; l < this.numberOfBindPositions; ++l) {
                    final int n10 = n6 + 2;
                    final int n11 = this.currentBatchCharLens[l];
                    final short n12 = this.bindIndicators[n10];
                    if (this.bindIndicators[(this.bindIndicators[n6 + 5] << 16) + (this.bindIndicators[n6 + 6] & 0xFFFF)] == -1 && n11 > 1) {
                        this.preparedCharBinds = true;
                    }
                    if (n12 >= n11 && !this.preparedCharBinds) {
                        this.currentBatchCharLens[l] = n12;
                        n3 += n12;
                    }
                    else {
                        this.bindIndicators[n10] = (short)n11;
                        n3 += n11;
                        this.preparedCharBinds = true;
                    }
                    n6 += 10;
                }
            }
            if (this.preparedCharBinds) {
                this.initializeBindSubRanges(this.numberOfBoundRows, bindBufferCapacity);
            }
            if (this.preparedAllBinds) {
                final int totalBindByteLength = this.bindByteSubRange + n4 * bindBufferCapacity;
                if (this.lastBoundNeeded || totalBindByteLength > this.totalBindByteLength) {
                    this.bindByteOffset = 0;
                    this.bindBytes = this.connection.getByteBuffer(totalBindByteLength);
                    this.totalBindByteLength = totalBindByteLength;
                }
                this.bindBufferCapacity = bindBufferCapacity;
                this.bindIndicators[this.bindIndicatorSubRange + 1] = (short)((this.bindBufferCapacity & 0xFFFF0000) >> 16);
                this.bindIndicators[this.bindIndicatorSubRange + 2] = (short)(this.bindBufferCapacity & 0xFFFF);
            }
            if (this.preparedCharBinds) {
                final int totalBindCharLength = this.bindCharSubRange + n3 * this.bindBufferCapacity;
                if (this.lastBoundNeeded || totalBindCharLength > this.totalBindCharLength) {
                    this.bindCharOffset = 0;
                    this.bindChars = this.connection.getCharBuffer(totalBindCharLength);
                    this.totalBindCharLength = totalBindCharLength;
                }
                this.bindByteSubRange += this.bindByteOffset;
                this.bindCharSubRange += this.bindCharOffset;
            }
            int columnIndex = this.bindByteSubRange;
            int columnIndex2 = this.bindCharSubRange;
            int indicatorIndex = this.indicatorsOffset;
            int lengthIndex = this.valueLengthsOffset;
            int n13 = n5;
            if (this.preparedCharBinds) {
                if (this.currentBatchBindAccessors == null) {
                    for (int n14 = 0; n14 < this.numberOfBindPositions; ++n14) {
                        final short n15 = this.bindIndicators[n13 + 1];
                        final int n16 = this.currentBatchCharLens[n14];
                        final short n17 = (short)((n16 == 0) ? columnIndex : columnIndex2);
                        this.bindIndicators[n13 + 3] = (short)(n17 >> 16);
                        this.bindIndicators[n13 + 4] = (short)(n17 & 0xFFFF);
                        columnIndex += n15 * this.bindBufferCapacity;
                        columnIndex2 += n16 * this.bindBufferCapacity;
                        n13 += 10;
                    }
                }
                else {
                    for (int n18 = 0; n18 < this.numberOfBindPositions; ++n18) {
                        final short byteLength = this.bindIndicators[n13 + 1];
                        final int charLength2 = this.currentBatchCharLens[n18];
                        final short n19 = (short)((charLength2 == 0) ? columnIndex : columnIndex2);
                        this.bindIndicators[n13 + 3] = (short)(n19 >> 16);
                        this.bindIndicators[n13 + 4] = (short)(n19 & 0xFFFF);
                        final Accessor accessor3 = this.currentBatchBindAccessors[n18];
                        if (accessor3 != null) {
                            if (charLength2 > 0) {
                                accessor3.columnIndex = columnIndex2;
                                accessor3.charLength = charLength2;
                            }
                            else {
                                accessor3.columnIndex = columnIndex;
                                accessor3.byteLength = byteLength;
                            }
                            accessor3.lengthIndex = lengthIndex;
                            accessor3.indicatorIndex = indicatorIndex;
                            accessor3.rowSpaceByte = this.bindBytes;
                            accessor3.rowSpaceChar = this.bindChars;
                            accessor3.rowSpaceIndicator = this.bindIndicators;
                            if (accessor3.defineType == 109 || accessor3.defineType == 111) {
                                accessor3.setOffsets(this.bindBufferCapacity);
                            }
                        }
                        columnIndex += byteLength * this.bindBufferCapacity;
                        columnIndex2 += charLength2 * this.bindBufferCapacity;
                        indicatorIndex += this.numberOfBindRowsAllocated;
                        lengthIndex += this.numberOfBindRowsAllocated;
                        n13 += 10;
                    }
                }
                columnIndex = this.bindByteSubRange;
                columnIndex2 = this.bindCharSubRange;
                indicatorIndex = this.indicatorsOffset;
                lengthIndex = this.valueLengthsOffset;
                n13 = n5;
            }
            final int n20 = this.bindBufferCapacity - this.numberOfBoundRows;
            final int n21 = this.numberOfBoundRows - 1;
            final int n22 = n21 + n;
            final Binder[] array2 = this.binders[n22];
            if (this.parameterOtype != null) {
                System.arraycopy(this.parameterDatum[n22], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions);
                System.arraycopy(this.parameterOtype[n22], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions);
            }
            if (this.hasIbtBind) {
                this.processPlsqlIndexTabBinds(n);
            }
            if (this.numReturnParams > 0 && (this.returnParamAccessors == null || this.returnParamAccessors.length < this.numReturnParams)) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 173);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.returnParamAccessors != null) {
                this.processDmlReturningBind();
            }
            final boolean b = (this.sqlKind != 32 && this.sqlKind != 64) || this.currentRowBindAccessors == null;
            for (int n23 = 0; n23 < this.numberOfBindPositions; ++n23) {
                final short n24 = this.bindIndicators[n13 + 1];
                final int n25 = this.currentBatchCharLens[n23];
                this.lastBinders[n23] = array2[n23];
                this.lastBoundByteLens[n23] = n24;
                for (int n26 = 0; n26 < this.numberOfBoundRows; ++n26) {
                    final int n27 = n + n26;
                    this.binders[n27][n23].bind(this, n23, n26, n27, this.bindBytes, this.bindChars, this.bindIndicators, n24, n25, columnIndex, columnIndex2, lengthIndex + n26, indicatorIndex + n26, b);
                    this.binders[n27][n23] = null;
                    if (this.userStream != null) {
                        this.userStream[n26][n23] = null;
                    }
                    columnIndex += n24;
                    columnIndex2 += n25;
                }
                this.lastBoundByteOffsets[n23] = columnIndex - n24;
                this.lastBoundCharOffsets[n23] = columnIndex2 - n25;
                this.lastBoundInds[n23] = this.bindIndicators[indicatorIndex + n21];
                this.lastBoundLens[n23] = this.bindIndicators[lengthIndex + n21];
                this.lastBoundCharLens[n23] = 0;
                columnIndex += n20 * n24;
                columnIndex2 += n20 * n25;
                indicatorIndex += this.numberOfBindRowsAllocated;
                lengthIndex += this.numberOfBindRowsAllocated;
                n13 += 10;
            }
            this.lastBoundBytes = this.bindBytes;
            this.lastBoundByteOffset = this.bindByteOffset;
            this.lastBoundChars = this.bindChars;
            this.lastBoundCharOffset = this.bindCharOffset;
            if (this.parameterStream != null) {
                this.lastBoundStream = this.parameterStream[n + this.numberOfBoundRows - 1];
            }
            final int[] currentBatchCharLens = this.currentBatchCharLens;
            this.currentBatchCharLens = this.lastBoundCharLens;
            this.lastBoundCharLens = currentBatchCharLens;
            this.lastBoundNeeded = false;
            this.prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity);
        }
        catch (NullPointerException ex) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    void releaseBuffers() {
        this.cachedBindCharSize = ((this.bindChars != null) ? this.bindChars.length : 0);
        if (this.bindChars != this.lastBoundChars) {
            this.connection.cacheBuffer(this.lastBoundChars);
        }
        this.lastBoundChars = null;
        this.connection.cacheBuffer(this.bindChars);
        this.bindChars = null;
        this.cachedBindByteSize = ((this.bindBytes != null) ? this.bindBytes.length : 0);
        if (this.bindBytes != this.lastBoundBytes) {
            this.connection.cacheBuffer(this.lastBoundBytes);
        }
        this.lastBoundBytes = null;
        this.connection.cacheBuffer(this.bindBytes);
        this.bindBytes = null;
        super.releaseBuffers();
    }
    
    @Override
    public void enterImplicitCache() throws SQLException {
        this.alwaysOnClose();
        if (!this.connection.isClosed()) {
            this.cleanAllTempLobs();
        }
        if (this.connection.clearStatementMetaData) {
            this.lastBoundBytes = null;
            this.lastBoundChars = null;
        }
        this.clearParameters();
        this.cacheState = 2;
        this.creationState = 1;
        this.currentResultSet = null;
        this.lastIndex = 0;
        this.queryTimeout = 0;
        this.autoRollback = 2;
        this.rowPrefetchChanged = false;
        this.currentRank = 0;
        this.currentRow = -1;
        this.validRows = 0;
        this.maxRows = 0;
        this.totalRowsVisited = 0;
        this.maxFieldSize = 0;
        this.gotLastBatch = false;
        this.clearParameters = true;
        this.scrollRset = null;
        this.needToAddIdentifier = false;
        this.defaultFetchDirection = 1000;
        this.defaultTimeZone = null;
        this.defaultCalendar = null;
        if (this.sqlKind == -128) {
            this.needToParse = true;
            this.needToPrepareDefineBuffer = true;
            this.columnsDefinedByUser = false;
        }
        this.releaseBuffers();
        if (this.accessors != null) {
            for (int length = this.accessors.length, i = 0; i < length; ++i) {
                if (this.accessors[i] != null) {
                    this.accessors[i].rowSpaceByte = null;
                    this.accessors[i].rowSpaceChar = null;
                    this.accessors[i].rowSpaceIndicator = null;
                    if (this.columnsDefinedByUser) {
                        this.accessors[i].externalType = 0;
                    }
                }
            }
        }
        this.fixedString = this.connection.getDefaultFixedString();
        this.defaultRowPrefetch = this.rowPrefetch;
        this.rowPrefetchInLastFetch = -1;
        if (this.connection.clearStatementMetaData) {
            this.sqlStringChanged = true;
            this.needToParse = true;
            this.needToPrepareDefineBuffer = true;
            this.columnsDefinedByUser = false;
            if (this.userRsetType == 0) {
                this.userRsetType = 1;
                this.realRsetType = 1;
            }
            this.currentRowNeedToPrepareBinds = true;
        }
    }
    
    @Override
    public void enterExplicitCache() throws SQLException {
        this.cacheState = 2;
        this.creationState = 2;
        this.defaultTimeZone = null;
        this.alwaysOnClose();
    }
    
    @Override
    public void exitImplicitCacheToActive() throws SQLException {
        this.cacheState = 1;
        this.closed = false;
        if (this.rowPrefetch != this.connection.getDefaultRowPrefetch()) {
            if (this.streamList == null) {
                this.rowPrefetch = this.connection.getDefaultRowPrefetch();
                this.defaultRowPrefetch = this.rowPrefetch;
                this.rowPrefetchChanged = true;
            }
        }
        if (this.batch != this.connection.getDefaultExecuteBatch()) {
            this.resetBatch();
        }
        this.processEscapes = this.connection.processEscapes;
        if (this.cachedDefineIndicatorSize != 0) {
            this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
            this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
            this.defineIndicators = new short[this.cachedDefineIndicatorSize];
            if (this.accessors != null) {
                for (int length = this.accessors.length, i = 0; i < length; ++i) {
                    if (this.accessors[i] != null) {
                        this.accessors[i].rowSpaceByte = this.defineBytes;
                        this.accessors[i].rowSpaceChar = this.defineChars;
                        this.accessors[i].rowSpaceIndicator = this.defineIndicators;
                    }
                }
                this.doInitializationAfterDefineBufferRestore();
            }
        }
        if (this.cachedBindCharSize != 0 || this.cachedBindByteSize != 0) {
            if (this.cachedBindByteSize > 0) {
                this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);
            }
            if (this.cachedBindCharSize > 0) {
                this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);
            }
            this.doLocalInitialization();
        }
    }
    
    void doLocalInitialization() {
    }
    
    void doInitializationAfterDefineBufferRestore() {
    }
    
    @Override
    public void exitExplicitCacheToActive() throws SQLException {
        this.cacheState = 1;
        this.closed = false;
    }
    
    @Override
    public void exitImplicitCacheToClose() throws SQLException {
        this.cacheState = 0;
        this.closed = false;
        synchronized (this.connection) {
            this.hardClose();
        }
    }
    
    @Override
    public void exitExplicitCacheToClose() throws SQLException {
        this.cacheState = 0;
        this.closed = false;
        synchronized (this.connection) {
            this.hardClose();
        }
    }
    
    @Override
    public void closeWithKey(final String s) throws SQLException {
        synchronized (this.connection) {
            this.closeOrCache(s);
        }
    }
    
    int executeInternal() throws SQLException {
        this.noMoreUpdateCounts = false;
        this.ensureOpen();
        if (this.currentRank > 0 && this.m_batchStyle == 2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final boolean b = this.userRsetType == 1;
        this.prepareForNewResults(true, false);
        this.processCompletedBindRow((this.sqlKind == 1) ? 1 : this.batch, false);
        if (!b && !this.scrollRsetTypeSolved) {
            return this.doScrollPstmtExecuteUpdate() + this.prematureBatchCount;
        }
        this.doExecuteWithTimeout();
        boolean b2 = this.prematureBatchCount != 0 && this.validRows > 0;
        if (!b) {
            this.currentResultSet = new OracleResultSetImpl(this.connection, this);
            this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
            if (!this.connection.accumulateBatchResult) {
                b2 = false;
            }
        }
        if (b2) {
            this.validRows += this.prematureBatchCount;
            this.prematureBatchCount = 0;
        }
        if (this.sqlKind == -128) {
            this.needToParse = true;
        }
        return this.validRows;
    }
    
    @Override
    public ResultSet executeQuery() throws SQLException {
        synchronized (this.connection) {
            this.executionType = 1;
            this.executeInternal();
            if (this.userRsetType == 1) {
                return this.currentResultSet = new OracleResultSetImpl(this.connection, this);
            }
            if (this.scrollRset == null) {
                this.currentResultSet = new OracleResultSetImpl(this.connection, this);
                this.scrollRset = this.currentResultSet;
            }
            return this.scrollRset;
        }
    }
    
    @Override
    public int executeUpdate() throws SQLException {
        synchronized (this.connection) {
            this.executionType = 2;
            return this.executeInternal();
        }
    }
    
    @Override
    public boolean execute() throws SQLException {
        synchronized (this.connection) {
            this.executionType = 3;
            this.executeInternal();
            return this.sqlKind == 1;
        }
    }
    
    void slideDownCurrentRow(final int n) {
        if (this.binders != null) {
            this.binders[n] = this.binders[0];
            this.binders[0] = this.currentRowBinders;
        }
        if (this.parameterInt != null) {
            final int[] array = this.parameterInt[0];
            this.parameterInt[0] = this.parameterInt[n];
            this.parameterInt[n] = array;
        }
        if (this.parameterLong != null) {
            final long[] array2 = this.parameterLong[0];
            this.parameterLong[0] = this.parameterLong[n];
            this.parameterLong[n] = array2;
        }
        if (this.parameterFloat != null) {
            final float[] array3 = this.parameterFloat[0];
            this.parameterFloat[0] = this.parameterFloat[n];
            this.parameterFloat[n] = array3;
        }
        if (this.parameterDouble != null) {
            final double[] array4 = this.parameterDouble[0];
            this.parameterDouble[0] = this.parameterDouble[n];
            this.parameterDouble[n] = array4;
        }
        if (this.parameterBigDecimal != null) {
            final BigDecimal[] array5 = this.parameterBigDecimal[0];
            this.parameterBigDecimal[0] = this.parameterBigDecimal[n];
            this.parameterBigDecimal[n] = array5;
        }
        if (this.parameterString != null) {
            final String[] array6 = this.parameterString[0];
            this.parameterString[0] = this.parameterString[n];
            this.parameterString[n] = array6;
        }
        if (this.parameterDate != null) {
            final Date[] array7 = this.parameterDate[0];
            this.parameterDate[0] = this.parameterDate[n];
            this.parameterDate[n] = array7;
        }
        if (this.parameterTime != null) {
            final Time[] array8 = this.parameterTime[0];
            this.parameterTime[0] = this.parameterTime[n];
            this.parameterTime[n] = array8;
        }
        if (this.parameterTimestamp != null) {
            final Timestamp[] array9 = this.parameterTimestamp[0];
            this.parameterTimestamp[0] = this.parameterTimestamp[n];
            this.parameterTimestamp[n] = array9;
        }
        if (this.parameterDatum != null) {
            final byte[][] array10 = this.parameterDatum[0];
            this.parameterDatum[0] = this.parameterDatum[n];
            this.parameterDatum[n] = array10;
        }
        if (this.parameterOtype != null) {
            final OracleTypeADT[] array11 = this.parameterOtype[0];
            this.parameterOtype[0] = this.parameterOtype[n];
            this.parameterOtype[n] = array11;
        }
        if (this.parameterStream != null) {
            final InputStream[] array12 = this.parameterStream[0];
            this.parameterStream[0] = this.parameterStream[n];
            this.parameterStream[n] = array12;
        }
        if (this.userStream != null) {
            final Object[] array13 = this.userStream[0];
            this.userStream[0] = this.userStream[n];
            this.userStream[n] = array13;
        }
    }
    
    void resetBatch() {
        this.batch = this.connection.getDefaultExecuteBatch();
    }
    
    @Override
    public int sendBatch() throws SQLException {
        if (this.isJdbcBatchStyle()) {
            return 0;
        }
        synchronized (this.connection) {
            try {
                this.ensureOpen();
                if (this.currentRank <= 0) {
                    return this.connection.accumulateBatchResult ? 0 : this.validRows;
                }
                final int batch = this.batch;
                try {
                    final int currentRank = this.currentRank;
                    if (this.batch != this.currentRank) {
                        this.batch = this.currentRank;
                    }
                    this.setupBindBuffers(0, this.currentRank);
                    --this.currentRank;
                    this.doExecuteWithTimeout();
                    this.slideDownCurrentRow(currentRank);
                }
                finally {
                    if (this.batch != batch) {
                        this.batch = batch;
                    }
                }
                if (this.connection.accumulateBatchResult) {
                    this.validRows += this.prematureBatchCount;
                    this.prematureBatchCount = 0;
                }
                return this.validRows;
            }
            finally {
                this.currentRank = 0;
            }
        }
    }
    
    @Override
    public void setExecuteBatch(final int n) throws SQLException {
        synchronized (this.connection) {
            this.setOracleBatchStyle();
            this.set_execute_batch(n);
        }
    }
    
    void set_execute_batch(final int batch) throws SQLException {
        synchronized (this.connection) {
            if (batch <= 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 42);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (batch == this.batch) {
                return;
            }
            if (this.currentRank > 0) {
                final int validRows = this.validRows;
                this.prematureBatchCount = this.sendBatch();
                this.validRows = validRows;
            }
            final int batch2 = this.batch;
            this.batch = batch;
            if (this.numberOfBindRowsAllocated < this.batch) {
                this.growBinds(this.batch);
            }
        }
    }
    
    @Override
    public final int getExecuteBatch() {
        return this.batch;
    }
    
    @Override
    public void defineParameterTypeBytes(final int n, int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            if (n3 < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 53);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (n < 1) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            switch (n2) {
                case -7:
                case -6:
                case -5:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8: {
                    n2 = 6;
                    break;
                }
                case 1: {
                    n2 = 96;
                    break;
                }
                case 12: {
                    n2 = 1;
                    break;
                }
                case 91:
                case 92: {
                    n2 = 12;
                    break;
                }
                case -103: {
                    n2 = 182;
                    break;
                }
                case -104: {
                    n2 = 183;
                    break;
                }
                case -100:
                case 93: {
                    n2 = 180;
                    break;
                }
                case -101: {
                    n2 = 181;
                    break;
                }
                case -102: {
                    n2 = 231;
                    break;
                }
                case -3:
                case -2: {
                    n2 = 23;
                    break;
                }
                case 100: {
                    n2 = 100;
                    break;
                }
                case 101: {
                    n2 = 101;
                    break;
                }
                case -8: {
                    n2 = 104;
                    break;
                }
                case 2004: {
                    n2 = 113;
                    break;
                }
                case 2005: {
                    n2 = 112;
                    break;
                }
                case -13: {
                    n2 = 114;
                    break;
                }
                case -10: {
                    n2 = 102;
                    break;
                }
                case 0: {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                default: {
                    final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
                    unsupportedFeatureSqlException.fillInStackTrace();
                    throw unsupportedFeatureSqlException;
                }
            }
        }
    }
    
    @Override
    public void defineParameterTypeChars(final int n, final int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            final int nlsRatio = this.connection.getNlsRatio();
            if (n2 == 1 || n2 == 12) {
                this.defineParameterTypeBytes(n, n2, n3 * nlsRatio);
            }
            else {
                this.defineParameterTypeBytes(n, n2, n3);
            }
        }
    }
    
    @Override
    public void defineParameterType(final int n, final int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            this.defineParameterTypeBytes(n, n2, n3);
        }
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        if (this.sqlObject.getSqlKind() == 1) {
            return new OracleResultSetMetaData(this.connection, this);
        }
        return null;
    }
    
    @Override
    public void setNull(final int n, final int n2, final String s) throws SQLException {
        this.setNullInternal(n, n2, s);
    }
    
    void setNullInternal(final int n, final int n2, final String s) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n2 == 2002 || n2 == 2008 || n2 == 2003 || n2 == 2007 || n2 == 2006) {
            synchronized (this.connection) {
                this.setNullCritial(n3, n2, s);
                this.currentRowCharLens[n3] = 0;
            }
            return;
        }
        this.setNullInternal(n, n2);
    }
    
    void setNullInternal(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.setNullCritical(n, n2);
        }
    }
    
    void setNullCritial(final int n, final int n2, final String s) throws SQLException {
        OracleTypeADT oracleTypeADT = null;
        Binder binder = this.theNamedTypeNullBinder;
        switch (n2) {
            case 2006: {
                binder = this.theRefTypeNullBinder;
            }
            case 2002:
            case 2008: {
                oracleTypeADT = StructDescriptor.createDescriptor(s, this.connection).getOracleTypeADT();
                break;
            }
            case 2003: {
                oracleTypeADT = ArrayDescriptor.createDescriptor(s, this.connection).getOracleTypeCOLLECTION();
                break;
            }
            case 2007: {
                oracleTypeADT = (OracleTypeADT)OpaqueDescriptor.createDescriptor(s, this.connection).getPickler();
                break;
            }
        }
        this.currentRowBinders[n] = binder;
        if (this.parameterDatum == null) {
            this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
        }
        this.parameterDatum[this.currentRank][n] = null;
        if (oracleTypeADT != null) {
            oracleTypeADT.getTOID();
        }
        if (this.parameterOtype == null) {
            this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterOtype[this.currentRank][n] = oracleTypeADT;
    }
    
    @Override
    public void setNullAtName(final String s, final int n, final String s2) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setNullInternal(i + 1, n, s2);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setNull(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.setNullCritical(n, n2);
        }
    }
    
    void setNullCritical(final int n, final int n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        Binder binder = null;
        switch (this.getInternalType(n2)) {
            case 6: {
                binder = this.theVarnumNullBinder;
                break;
            }
            case 1:
            case 8:
            case 96:
            case 995: {
                binder = this.theVarcharNullBinder;
                this.currentRowCharLens[n3] = 1;
                break;
            }
            case 999: {
                binder = this.theFixedCHARNullBinder;
                break;
            }
            case 12: {
                binder = this.theDateNullBinder;
                break;
            }
            case 180: {
                binder = this.theTimestampNullBinder;
                break;
            }
            case 181: {
                binder = this.theTSTZNullBinder;
                break;
            }
            case 231: {
                binder = this.theTSLTZNullBinder;
                break;
            }
            case 104: {
                binder = this.getRowidNullBinder(n3);
                break;
            }
            case 183: {
                binder = this.theIntervalDSNullBinder;
                break;
            }
            case 182: {
                binder = this.theIntervalYMNullBinder;
                break;
            }
            case 23:
            case 24: {
                binder = this.theRawNullBinder;
                break;
            }
            case 100: {
                binder = this.theBinaryFloatNullBinder;
                break;
            }
            case 101: {
                binder = this.theBinaryDoubleNullBinder;
                break;
            }
            case 113: {
                binder = this.theBlobNullBinder;
                break;
            }
            case 112: {
                binder = this.theClobNullBinder;
                break;
            }
            case 114: {
                binder = this.theBfileNullBinder;
                break;
            }
            case 109:
            case 111: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "sqlType=" + n2);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            default: {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "sqlType=" + n2);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        this.currentRowBinders[n3] = binder;
    }
    
    Binder getRowidNullBinder(final int n) {
        return this.theRowidNullBinder;
    }
    
    @Override
    public void setNullAtName(final String s, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setNull(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBoolean(final int n, final boolean b) throws SQLException {
        synchronized (this.connection) {
            this.setBooleanInternal(n, b);
        }
    }
    
    void setBooleanInternal(final int n, final boolean b) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        this.currentRowBinders[n2] = this.theBooleanBinder;
        if (this.parameterInt == null) {
            this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterInt[this.currentRank][n2] = (b ? 1 : 0);
    }
    
    @Override
    public void setByte(final int n, final byte b) throws SQLException {
        synchronized (this.connection) {
            this.setByteInternal(n, b);
        }
    }
    
    void setByteInternal(final int n, final byte b) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        this.currentRowBinders[n2] = this.theByteBinder;
        if (this.parameterInt == null) {
            this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterInt[this.currentRank][n2] = b;
    }
    
    @Override
    public void setShort(final int n, final short n2) throws SQLException {
        synchronized (this.connection) {
            this.setShortInternal(n, n2);
        }
    }
    
    void setShortInternal(final int n, final short n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n3] = 0;
        this.currentRowBinders[n3] = this.theShortBinder;
        if (this.parameterInt == null) {
            this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterInt[this.currentRank][n3] = n2;
    }
    
    @Override
    public void setInt(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.setIntInternal(n, n2);
        }
    }
    
    void setIntInternal(final int n, final int n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n3] = 0;
        this.currentRowBinders[n3] = this.theIntBinder;
        if (this.parameterInt == null) {
            this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterInt[this.currentRank][n3] = n2;
    }
    
    @Override
    public void setLong(final int n, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.setLongInternal(n, n2);
        }
    }
    
    void setLongInternal(final int n, final long n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n3] = 0;
        this.currentRowBinders[n3] = this.theLongBinder;
        if (this.parameterLong == null) {
            this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterLong[this.currentRank][n3] = n2;
    }
    
    @Override
    public void setFloat(final int n, final float n2) throws SQLException {
        synchronized (this.connection) {
            this.setFloatInternal(n, n2);
        }
    }
    
    void setFloatInternal(final int n, final float n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.theFloatBinder == null) {
            this.theFloatBinder = OraclePreparedStatement.theStaticFloatBinder;
            if (this.connection.setFloatAndDoubleUseBinary) {
                this.theFloatBinder = OraclePreparedStatement.theStaticBinaryFloatBinder;
            }
        }
        this.currentRowCharLens[n3] = 0;
        this.currentRowBinders[n3] = this.theFloatBinder;
        if (this.theFloatBinder == OraclePreparedStatement.theStaticFloatBinder) {
            if (this.parameterDouble == null) {
                this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterDouble[this.currentRank][n3] = n2;
        }
        else {
            if (this.parameterFloat == null) {
                this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterFloat[this.currentRank][n3] = n2;
        }
    }
    
    @Override
    public void setBinaryFloat(final int n, final float n2) throws SQLException {
        synchronized (this.connection) {
            this.setBinaryFloatInternal(n, n2);
        }
    }
    
    void setBinaryFloatInternal(final int n, final float n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n3] = 0;
        this.currentRowBinders[n3] = this.theBinaryFloatBinder;
        if (this.parameterFloat == null) {
            this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterFloat[this.currentRank][n3] = n2;
    }
    
    @Override
    public void setBinaryFloat(final int n, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        synchronized (this.connection) {
            this.setBinaryFloatInternal(n, binary_FLOAT);
        }
    }
    
    void setBinaryFloatInternal(final int n, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (binary_FLOAT == null) {
            this.currentRowBinders[n2] = this.theBINARY_FLOATNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theBINARY_FLOATBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = binary_FLOAT.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setBinaryDouble(final int n, final double n2) throws SQLException {
        synchronized (this.connection) {
            this.setBinaryDoubleInternal(n, n2);
        }
    }
    
    void setBinaryDoubleInternal(final int n, final double n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowBinders[n3] = this.theBinaryDoubleBinder;
        if (this.parameterDouble == null) {
            this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.currentRowCharLens[n3] = 0;
        this.parameterDouble[this.currentRank][n3] = n2;
    }
    
    @Override
    public void setBinaryDouble(final int n, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        synchronized (this.connection) {
            this.setBinaryDoubleInternal(n, binary_DOUBLE);
        }
    }
    
    void setBinaryDoubleInternal(final int n, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (binary_DOUBLE == null) {
            this.currentRowBinders[n2] = this.theBINARY_DOUBLENullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theBINARY_DOUBLEBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = binary_DOUBLE.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setDouble(final int n, final double n2) throws SQLException {
        synchronized (this.connection) {
            this.setDoubleInternal(n, n2);
        }
    }
    
    void setDoubleInternal(final int n, final double n2) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.theDoubleBinder == null) {
            this.theDoubleBinder = OraclePreparedStatement.theStaticDoubleBinder;
            if (this.connection.setFloatAndDoubleUseBinary) {
                this.theDoubleBinder = OraclePreparedStatement.theStaticBinaryDoubleBinder;
            }
        }
        this.currentRowCharLens[n3] = 0;
        this.currentRowBinders[n3] = this.theDoubleBinder;
        if (this.parameterDouble == null) {
            this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterDouble[this.currentRank][n3] = n2;
    }
    
    @Override
    public void setBigDecimal(final int n, final BigDecimal bigDecimal) throws SQLException {
        synchronized (this.connection) {
            this.setBigDecimalInternal(n, bigDecimal);
        }
    }
    
    void setBigDecimalInternal(final int n, final BigDecimal bigDecimal) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (bigDecimal == null) {
            this.currentRowBinders[n2] = this.theVarnumNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theBigDecimalBinder;
            if (this.parameterBigDecimal == null) {
                this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterBigDecimal[this.currentRank][n2] = bigDecimal;
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setString(final int n, final String s) throws SQLException {
        this.setStringInternal(n, s);
    }
    
    void setStringInternal(final int n, final String s) throws SQLException {
        if (n - 1 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int n2 = (s != null) ? s.length() : 0;
        if (n2 == 0) {
            this.basicBindNullString(n);
        }
        else if (this.currentRowFormOfUse[n - 1] == 1) {
            if (this.sqlKind == 32 || this.sqlKind == 64) {
                if (n2 > this.maxVcsBytesPlsql || (n2 > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) {
                    this.setStringForClobCritical(n, s);
                }
                else if (n2 > this.maxVcsCharsPlsql) {
                    if (this.connection.conversion.encodedByteLength(s, false) > this.maxVcsBytesPlsql) {
                        this.setStringForClobCritical(n, s);
                    }
                    else {
                        this.basicBindString(n, s);
                    }
                }
                else {
                    this.basicBindString(n, s);
                }
            }
            else if (n2 <= this.maxVcsCharsSql) {
                this.basicBindString(n, s);
            }
            else if (n2 <= this.maxStreamCharsSql) {
                this.basicBindCharacterStream(n, new StringReader(s), n2, true);
            }
            else {
                this.setStringForClobCritical(n, s);
            }
        }
        else if (this.sqlKind == 32 || this.sqlKind == 64) {
            if (n2 > this.maxVcsBytesPlsql || (n2 > this.maxVcsNCharsPlsql && this.isServerNCharSetFixedWidth)) {
                this.setStringForClobCritical(n, s);
            }
            else if (n2 > this.maxVcsNCharsPlsql) {
                if (this.connection.conversion.encodedByteLength(s, true) > this.maxVcsBytesPlsql) {
                    this.setStringForClobCritical(n, s);
                }
                else {
                    this.basicBindString(n, s);
                }
            }
            else {
                this.basicBindString(n, s);
            }
        }
        else if (n2 <= this.maxVcsCharsSql) {
            this.basicBindString(n, s);
        }
        else if (n2 <= this.maxStreamNCharsSql) {
            this.setStringForClobCritical(n, s);
        }
        else {
            this.setStringForClobCritical(n, s);
        }
    }
    
    void basicBindNullString(final int n) throws SQLException {
        synchronized (this.connection) {
            final int n2 = n - 1;
            this.currentRowBinders[n2] = this.theVarcharNullBinder;
            if (this.sqlKind == 32 || this.sqlKind == 64) {
                this.currentRowCharLens[n2] = this.minVcsBindSize;
            }
            else {
                this.currentRowCharLens[n2] = 1;
            }
        }
    }
    
    void basicBindString(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            final int n2 = n - 1;
            this.currentRowBinders[n2] = this.theStringBinder;
            final int length = s.length();
            if (this.sqlKind == 32 || this.sqlKind == 64) {
                final int minVcsBindSize = this.connection.minVcsBindSize;
                final int n3 = length + 1;
                this.currentRowCharLens[n2] = ((n3 < minVcsBindSize) ? minVcsBindSize : n3);
            }
            else {
                this.currentRowCharLens[n2] = length + 1;
            }
            if (this.parameterString == null) {
                this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterString[this.currentRank][n2] = s;
        }
    }
    
    @Override
    public void setStringForClob(final int n, final String s) throws SQLException {
        if (s == null) {
            this.setNull(n, 1);
            return;
        }
        final int length = s.length();
        if (length == 0) {
            this.setNull(n, 1);
            return;
        }
        if (this.sqlKind == 32 || this.sqlKind == 64) {
            if (length <= this.maxVcsCharsPlsql) {
                this.setStringInternal(n, s);
            }
            else {
                this.setStringForClobCritical(n, s);
            }
        }
        else if (length <= this.maxVcsCharsSql) {
            this.setStringInternal(n, s);
        }
        else {
            this.setStringForClobCritical(n, s);
        }
    }
    
    void setStringForClobCritical(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            final CLOB temporary = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[n - 1]);
            temporary.setString(1L, s);
            this.addToTempLobsToFree(temporary);
            this.setCLOBInternal(n, this.lastBoundClobs[n - 1] = temporary);
        }
    }
    
    void setReaderContentsForClobCritical(final int n, Reader readerEmpty, final long lng, final boolean b) throws SQLException {
        synchronized (this.connection) {
            try {
                if ((readerEmpty = this.isReaderEmpty(readerEmpty)) == null) {
                    if (b) {
                        throw new IOException(lng + " char of CLOB data cannot be read");
                    }
                    this.setCLOBInternal(n, null);
                    return;
                }
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final CLOB temporary = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[n - 1]);
            final OracleClobWriter oracleClobWriter = (OracleClobWriter)temporary.setCharacterStream(1L);
            final int bufferSize = temporary.getBufferSize();
            final char[] cbuf = new char[bufferSize];
            long lng2 = b ? lng : Long.MAX_VALUE;
            try {
                while (lng2 > 0L) {
                    int n2;
                    if (lng2 >= bufferSize) {
                        n2 = readerEmpty.read(cbuf);
                    }
                    else {
                        n2 = readerEmpty.read(cbuf, 0, (int)lng2);
                    }
                    if (n2 == -1) {
                        if (b) {
                            throw new IOException(lng2 + " char of CLOB data cannot be read");
                        }
                        break;
                    }
                    else {
                        oracleClobWriter.write(cbuf, 0, n2);
                        lng2 -= n2;
                    }
                }
                oracleClobWriter.flush();
            }
            catch (IOException ex2) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            this.addToTempLobsToFree(temporary);
            this.setCLOBInternal(n, this.lastBoundClobs[n - 1] = temporary);
        }
    }
    
    void setAsciiStreamContentsForClobCritical(final int n, InputStream inputStreamEmpty, final long lng, final boolean b) throws SQLException {
        synchronized (this.connection) {
            try {
                if ((inputStreamEmpty = this.isInputStreamEmpty(inputStreamEmpty)) == null) {
                    if (b) {
                        throw new IOException(lng + " byte of CLOB data cannot be read");
                    }
                    this.setCLOBInternal(n, null);
                    return;
                }
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final CLOB temporary = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[n - 1]);
            final OracleClobWriter oracleClobWriter = (OracleClobWriter)temporary.setCharacterStream(1L);
            final int bufferSize = temporary.getBufferSize();
            final byte[] array = new byte[bufferSize];
            final char[] array2 = new char[bufferSize];
            long lng2 = b ? lng : Long.MAX_VALUE;
            try {
                while (lng2 > 0L) {
                    int n2;
                    if (lng2 >= bufferSize) {
                        n2 = inputStreamEmpty.read(array);
                    }
                    else {
                        n2 = inputStreamEmpty.read(array, 0, (int)lng2);
                    }
                    if (n2 == -1) {
                        if (b) {
                            throw new IOException(lng2 + " byte of CLOB data cannot be read");
                        }
                        break;
                    }
                    else {
                        final DBConversion conversion = this.connection.conversion;
                        DBConversion.asciiBytesToJavaChars(array, n2, array2);
                        oracleClobWriter.write(array2, 0, n2);
                        lng2 -= n2;
                    }
                }
                oracleClobWriter.flush();
            }
            catch (IOException ex2) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            this.addToTempLobsToFree(temporary);
            this.setCLOBInternal(n, this.lastBoundClobs[n - 1] = temporary);
        }
    }
    
    @Override
    public void setStringForClobAtName(final String s, final String s2) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setStringForClob(i + 1, s2);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setFixedCHAR(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            this.setFixedCHARInternal(n, s);
        }
    }
    
    void setFixedCHARInternal(final int n, final String s) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        int length = 0;
        if (s != null) {
            length = s.length();
        }
        if (length > 32766) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 157);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (s == null) {
            this.currentRowBinders[n2] = this.theFixedCHARNullBinder;
            this.currentRowCharLens[n2] = 1;
        }
        else {
            this.currentRowBinders[n2] = this.theFixedCHARBinder;
            this.currentRowCharLens[n2] = length + 1;
            if (this.parameterString == null) {
                this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterString[this.currentRank][n2] = s;
        }
    }
    
    @Override
    @Deprecated
    public void setCursor(final int n, final ResultSet set) throws SQLException {
        synchronized (this.connection) {
            this.setCursorInternal(n, set);
        }
    }
    
    void setCursorInternal(final int n, final ResultSet set) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void setROWID(final int n, final ROWID rowid) throws SQLException {
        synchronized (this.connection) {
            this.setROWIDInternal(n, rowid);
        }
    }
    
    void setROWIDInternal(final int n, final ROWID rowid) throws SQLException {
        if (this.sqlKind == 64) {
            if (rowid == null) {
                this.setNull(n, 12);
            }
            else {
                this.setStringInternal(n, rowid.stringValue());
            }
            return;
        }
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (rowid == null) {
            this.currentRowBinders[n2] = this.theRowidNullBinder;
        }
        else {
            this.currentRowBinders[n2] = (T4CRowidAccessor.isUROWID(rowid.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder);
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = rowid.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setArray(final int n, final Array array) throws SQLException {
        this.setARRAYInternal(n, (ARRAY)array);
    }
    
    void setArrayInternal(final int n, final Array array) throws SQLException {
        this.setARRAYInternal(n, (ARRAY)array);
    }
    
    @Override
    public void setARRAY(final int n, final ARRAY array) throws SQLException {
        this.setARRAYInternal(n, array);
    }
    
    void setARRAYInternal(final int n, final ARRAY array) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (array == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        synchronized (this.connection) {
            this.setArrayCritical(n2, array);
            this.currentRowCharLens[n2] = 0;
        }
    }
    
    void setArrayCritical(final int n, final ARRAY array) throws SQLException {
        final ArrayDescriptor descriptor = array.getDescriptor();
        if (descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 61);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowBinders[n] = this.theNamedTypeBinder;
        if (this.parameterDatum == null) {
            this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
        }
        this.parameterDatum[this.currentRank][n] = array.toBytes();
        final OracleTypeCOLLECTION oracleTypeCOLLECTION = descriptor.getOracleTypeCOLLECTION();
        oracleTypeCOLLECTION.getTOID();
        if (this.parameterOtype == null) {
            this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterOtype[this.currentRank][n] = oracleTypeCOLLECTION;
    }
    
    @Override
    public void setOPAQUE(final int n, final OPAQUE opaque) throws SQLException {
        this.setOPAQUEInternal(n, opaque);
    }
    
    void setOPAQUEInternal(final int n, final OPAQUE opaque) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (opaque == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        synchronized (this.connection) {
            this.setOPAQUECritical(n2, opaque);
            this.currentRowCharLens[n2] = 0;
        }
    }
    
    void setOPAQUECritical(final int n, final OPAQUE opaque) throws SQLException {
        final OpaqueDescriptor descriptor = opaque.getDescriptor();
        if (descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 61);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowBinders[n] = this.theNamedTypeBinder;
        if (this.parameterDatum == null) {
            this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
        }
        this.parameterDatum[this.currentRank][n] = opaque.toBytes();
        final OracleTypeADT oracleTypeADT = (OracleTypeADT)descriptor.getPickler();
        oracleTypeADT.getTOID();
        if (this.parameterOtype == null) {
            this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterOtype[this.currentRank][n] = oracleTypeADT;
    }
    
    void setSQLXMLInternal(final int n, final SQLXML sqlxml) throws SQLException {
        this.setOPAQUEInternal(n, ((Opaqueable)sqlxml).toOpaque());
    }
    
    @Override
    public void setStructDescriptor(final int n, final StructDescriptor structDescriptor) throws SQLException {
        this.setStructDescriptorInternal(n, structDescriptor);
    }
    
    void setStructDescriptorInternal(final int n, final StructDescriptor structDescriptor) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (structDescriptor == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        synchronized (this.connection) {
            this.setStructDescriptorCritical(n2, structDescriptor);
            this.currentRowCharLens[n2] = 0;
        }
    }
    
    void setStructDescriptorCritical(final int n, final StructDescriptor structDescriptor) throws SQLException {
        this.currentRowBinders[n] = this.theNamedTypeBinder;
        if (this.parameterDatum == null) {
            this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
        }
        final OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT();
        oracleTypeADT.getTOID();
        if (this.parameterOtype == null) {
            this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterOtype[this.currentRank][n] = oracleTypeADT;
    }
    
    @Override
    public void setStructDescriptorAtName(final String s, final StructDescriptor structDescriptor) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setStructDescriptorInternal(i + 1, structDescriptor);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void setPreBindsCompelete() throws SQLException {
    }
    
    @Override
    public void setSTRUCT(final int n, final STRUCT struct) throws SQLException {
        this.setSTRUCTInternal(n, struct);
    }
    
    void setSTRUCTInternal(final int n, final STRUCT struct) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (struct == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        synchronized (this.connection) {
            this.setSTRUCTCritical(n2, struct);
            this.currentRowCharLens[n2] = 0;
        }
    }
    
    void setSTRUCTCritical(final int n, final STRUCT struct) throws SQLException {
        final StructDescriptor descriptor = struct.getDescriptor();
        if (descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 61);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowBinders[n] = this.theNamedTypeBinder;
        if (this.parameterDatum == null) {
            this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
        }
        this.parameterDatum[this.currentRank][n] = struct.toBytes();
        final OracleTypeADT oracleTypeADT = descriptor.getOracleTypeADT();
        oracleTypeADT.getTOID();
        if (this.parameterOtype == null) {
            this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterOtype[this.currentRank][n] = oracleTypeADT;
    }
    
    @Override
    public void setRAW(final int n, final RAW raw) throws SQLException {
        this.setRAWInternal(n, raw);
    }
    
    void setRAWInternal(final int n, final RAW raw) throws SQLException {
        boolean b = false;
        synchronized (this.connection) {
            final int n2 = n - 1;
            if (n2 < 0 || n > this.numberOfBindPositions) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.currentRowCharLens[n2] = 0;
            if (raw == null) {
                this.currentRowBinders[n2] = this.theRawNullBinder;
            }
            else {
                b = true;
            }
        }
        if (b) {
            this.setBytesInternal(n, raw.getBytes());
        }
    }
    
    @Override
    public void setCHAR(final int n, final CHAR char1) throws SQLException {
        synchronized (this.connection) {
            this.setCHARInternal(n, char1);
        }
    }
    
    void setCHARInternal(final int n, final CHAR char1) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (char1 == null || char1.getLength() == 0L) {
            this.currentRowBinders[n2] = this.theSetCHARNullBinder;
            this.currentRowCharLens[n2] = 1;
        }
        else {
            final short n3 = (short)char1.oracleId();
            this.currentRowBinders[n2] = this.theSetCHARBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            final CharacterSet set = (this.currentRowFormOfUse[n2] == 2) ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj;
            byte[] array;
            if (set != null && set.getOracleId() != n3) {
                final byte[] shareBytes = char1.shareBytes();
                array = set.convert(char1.getCharacterSet(), shareBytes, 0, shareBytes.length);
            }
            else {
                array = char1.getBytes();
            }
            this.parameterDatum[this.currentRank][n2] = array;
            this.currentRowCharLens[n2] = (array.length + 1 >> 1) + 1;
        }
        if ((this.sqlKind == 32 || this.sqlKind == 64) && this.currentRowCharLens[n2] < this.minVcsBindSize) {
            this.currentRowCharLens[n2] = this.minVcsBindSize;
        }
    }
    
    @Override
    public void setDATE(final int n, final DATE date) throws SQLException {
        synchronized (this.connection) {
            this.setDATEInternal(n, date);
        }
    }
    
    void setDATEInternal(final int n, final DATE date) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        if (date == null) {
            this.currentRowBinders[n2] = this.theDateNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theOracleDateBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = date.getBytes();
        }
    }
    
    @Override
    public void setNUMBER(final int n, final NUMBER number) throws SQLException {
        synchronized (this.connection) {
            this.setNUMBERInternal(n, number);
        }
    }
    
    void setNUMBERInternal(final int n, final NUMBER number) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        if (number == null) {
            this.currentRowBinders[n2] = this.theVarnumNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theOracleNumberBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = number.getBytes();
        }
    }
    
    @Override
    public void setBLOB(final int n, final BLOB blob) throws SQLException {
        synchronized (this.connection) {
            this.setBLOBInternal(n, blob);
        }
    }
    
    void setBLOBInternal(final int n, final BLOB blob) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        if (blob == null) {
            this.currentRowBinders[n2] = this.theBlobNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theBlobBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = blob.getBytes();
        }
    }
    
    @Override
    public void setBlob(final int n, final Blob blob) throws SQLException {
        synchronized (this.connection) {
            this.setBLOBInternal(n, (BLOB)blob);
        }
    }
    
    void setBlobInternal(final int n, final Blob blob) throws SQLException {
        this.setBLOBInternal(n, (BLOB)blob);
    }
    
    @Override
    public void setCLOB(final int n, final CLOB clob) throws SQLException {
        synchronized (this.connection) {
            this.setCLOBInternal(n, clob);
        }
    }
    
    void setCLOBInternal(final int n, final CLOB clob) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        if (clob == null) {
            this.currentRowBinders[n2] = this.theClobNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theClobBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = clob.getBytes();
        }
    }
    
    @Override
    public void setClob(final int n, final Clob clob) throws SQLException {
        synchronized (this.connection) {
            this.setCLOBInternal(n, (CLOB)clob);
        }
    }
    
    void setClobInternal(final int n, final Clob clob) throws SQLException {
        this.setCLOBInternal(n, (CLOB)clob);
    }
    
    @Override
    public void setBFILE(final int n, final BFILE bfile) throws SQLException {
        synchronized (this.connection) {
            this.setBFILEInternal(n, bfile);
        }
    }
    
    void setBFILEInternal(final int n, final BFILE bfile) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowCharLens[n2] = 0;
        if (bfile == null) {
            this.currentRowBinders[n2] = this.theBfileNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theBfileBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = bfile.getBytes();
        }
    }
    
    @Override
    public void setBfile(final int n, final BFILE bfile) throws SQLException {
        synchronized (this.connection) {
            this.setBFILEInternal(n, bfile);
        }
    }
    
    void setBfileInternal(final int n, final BFILE bfile) throws SQLException {
        this.setBFILEInternal(n, bfile);
    }
    
    @Override
    public void setBytes(final int n, final byte[] array) throws SQLException {
        this.setBytesInternal(n, array);
    }
    
    void setBytesInternal(final int n, final byte[] array) throws SQLException {
        if (n - 1 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int n2 = (array != null) ? array.length : 0;
        if (n2 == 0) {
            this.setNullInternal(n, -2);
        }
        else if (this.sqlKind == 32) {
            if (n2 > this.maxRawBytesPlsql) {
                this.setBytesForBlobCritical(n, array);
            }
            else {
                this.basicBindBytes(n, array);
            }
        }
        else if (this.sqlKind == 64) {
            if (n2 > this.maxRawBytesPlsql) {
                this.setBytesForBlobCritical(n, array);
            }
            else {
                this.basicBindBytes(n, array);
            }
        }
        else if (n2 > this.maxRawBytesSql) {
            this.bindBytesAsStream(n, array);
        }
        else {
            this.basicBindBytes(n, array);
        }
    }
    
    void bindBytesAsStream(final int n, final byte[] array) throws SQLException {
        final int length = array.length;
        final byte[] buf = new byte[length];
        System.arraycopy(array, 0, buf, 0, length);
        this.set_execute_batch(1);
        this.basicBindBinaryStream(n, new ByteArrayInputStream(buf), length, true);
    }
    
    void basicBindBytes(final int n, final byte[] array) throws SQLException {
        synchronized (this.connection) {
            final int n2 = n - 1;
            this.currentRowBinders[n2] = ((this.sqlKind == 32 || this.sqlKind == 64) ? this.thePlsqlRawBinder : this.theRawBinder);
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = array;
            this.currentRowCharLens[n2] = 0;
        }
    }
    
    void basicBindBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.basicBindBinaryStream(n, inputStream, n2, false);
    }
    
    void basicBindBinaryStream(final int n, final InputStream inputStream, final int n2, final boolean b) throws SQLException {
        synchronized (this.connection) {
            final int n3 = n - 1;
            if (b) {
                this.currentRowBinders[n3] = this.theLongRawStreamForBytesBinder;
            }
            else {
                this.currentRowBinders[n3] = this.theLongRawStreamBinder;
            }
            if (this.parameterStream == null) {
                this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            final InputStream[] array = this.parameterStream[this.currentRank];
            final int n4 = n3;
            InputStream inputStream2;
            if (b) {
                final DBConversion conversion = this.connection.conversion;
                final PhysicalConnection connection = this.connection;
                inputStream2 = conversion.ConvertStreamInternal(inputStream, 6, n2);
            }
            else {
                final DBConversion conversion2 = this.connection.conversion;
                final PhysicalConnection connection2 = this.connection;
                inputStream2 = conversion2.ConvertStream(inputStream, 6, n2);
            }
            array[n4] = inputStream2;
            this.currentRowCharLens[n3] = 0;
        }
    }
    
    @Override
    public void setBytesForBlob(final int n, final byte[] array) throws SQLException {
        if (array == null) {
            this.setNull(n, -2);
            return;
        }
        final int length = array.length;
        if (length == 0) {
            this.setNull(n, -2);
            return;
        }
        if (this.sqlKind == 32 || this.sqlKind == 64) {
            if (length <= this.maxRawBytesPlsql) {
                this.setBytes(n, array);
            }
            else {
                this.setBytesForBlobCritical(n, array);
            }
        }
        else if (length <= this.maxRawBytesSql) {
            this.setBytes(n, array);
        }
        else {
            this.setBytesForBlobCritical(n, array);
        }
    }
    
    void setBytesForBlobCritical(final int n, final byte[] array) throws SQLException {
        final BLOB temporary = BLOB.createTemporary(this.connection, true, 10);
        temporary.putBytes(1L, array);
        this.addToTempLobsToFree(temporary);
        this.setBLOBInternal(n, this.lastBoundBlobs[n - 1] = temporary);
    }
    
    void setBinaryStreamContentsForBlobCritical(final int n, InputStream inputStreamEmpty, final long lng, final boolean b) throws SQLException {
        synchronized (this.connection) {
            try {
                if ((inputStreamEmpty = this.isInputStreamEmpty(inputStreamEmpty)) == null) {
                    if (b) {
                        throw new IOException(lng + " byte of BLOB data cannot be read");
                    }
                    this.setBLOBInternal(n, null);
                    return;
                }
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final BLOB temporary = BLOB.createTemporary(this.connection, true, 10);
            final OracleBlobOutputStream oracleBlobOutputStream = (OracleBlobOutputStream)temporary.setBinaryStream(1L);
            final int bufferSize = temporary.getBufferSize();
            final byte[] array = new byte[bufferSize];
            long lng2 = b ? lng : Long.MAX_VALUE;
            try {
                while (lng2 > 0L) {
                    int n2;
                    if (lng2 >= bufferSize) {
                        n2 = inputStreamEmpty.read(array);
                    }
                    else {
                        n2 = inputStreamEmpty.read(array, 0, (int)lng2);
                    }
                    if (n2 == -1) {
                        if (b) {
                            throw new IOException(lng2 + " byte of BLOB data cannot be read");
                        }
                        break;
                    }
                    else {
                        oracleBlobOutputStream.write(array, 0, n2);
                        lng2 -= n2;
                    }
                }
                oracleBlobOutputStream.flush();
            }
            catch (IOException ex2) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            this.addToTempLobsToFree(temporary);
            this.setBLOBInternal(n, this.lastBoundBlobs[n - 1] = temporary);
        }
    }
    
    @Override
    public void setBytesForBlobAtName(final String s, final byte[] array) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBytesForBlob(i + 1, array);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setInternalBytes(final int n, final byte[] array, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.setInternalBytesInternal(n, array, n2);
        }
    }
    
    void setInternalBytesInternal(final int n, final byte[] array, final int n2) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void setDate(final int n, final Date date) throws SQLException {
        synchronized (this.connection) {
            this.setDATEInternal(n, (date == null) ? null : new DATE(date, this.getDefaultCalendar()));
        }
    }
    
    void setDateInternal(final int n, final Date date) throws SQLException {
        this.setDATEInternal(n, (date == null) ? null : new DATE(date, this.getDefaultCalendar()));
    }
    
    @Override
    public void setTime(final int n, final Time time) throws SQLException {
        synchronized (this.connection) {
            this.setTimeInternal(n, time);
        }
    }
    
    void setTimeInternal(final int n, final Time time) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (time == null) {
            this.currentRowBinders[n2] = this.theDateNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theTimeBinder;
            if (this.parameterTime == null) {
                this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterTime[this.currentRank][n2] = time;
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp) throws SQLException {
        synchronized (this.connection) {
            this.setTimestampInternal(n, timestamp);
        }
    }
    
    void setTimestampInternal(final int n, final Timestamp timestamp) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (timestamp == null) {
            this.currentRowBinders[n2] = this.theTimestampNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theTimestampBinder;
            if (this.parameterTimestamp == null) {
                this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            this.parameterTimestamp[this.currentRank][n2] = timestamp;
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setINTERVALYM(final int n, final INTERVALYM intervalym) throws SQLException {
        synchronized (this.connection) {
            this.setINTERVALYMInternal(n, intervalym);
        }
    }
    
    void setINTERVALYMInternal(final int n, final INTERVALYM intervalym) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (intervalym == null) {
            this.currentRowBinders[n2] = this.theIntervalYMNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theIntervalYMBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = intervalym.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setINTERVALDS(final int n, final INTERVALDS intervalds) throws SQLException {
        synchronized (this.connection) {
            this.setINTERVALDSInternal(n, intervalds);
        }
    }
    
    void setINTERVALDSInternal(final int n, final INTERVALDS intervalds) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (intervalds == null) {
            this.currentRowBinders[n2] = this.theIntervalDSNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theIntervalDSBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = intervalds.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setTIMESTAMP(final int n, final TIMESTAMP timestamp) throws SQLException {
        synchronized (this.connection) {
            this.setTIMESTAMPInternal(n, timestamp);
        }
    }
    
    void setTIMESTAMPInternal(final int n, final TIMESTAMP timestamp) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (timestamp == null) {
            this.currentRowBinders[n2] = this.theTimestampNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theOracleTimestampBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = timestamp.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setTIMESTAMPTZ(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        synchronized (this.connection) {
            this.setTIMESTAMPTZInternal(n, timestamptz);
        }
    }
    
    void setTIMESTAMPTZInternal(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (timestamptz == null) {
            this.currentRowBinders[n2] = this.theTSTZNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theTSTZBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = timestamptz.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    @Override
    public void setTIMESTAMPLTZ(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        synchronized (this.connection) {
            this.setTIMESTAMPLTZInternal(n, timestampltz);
        }
    }
    
    void setTIMESTAMPLTZInternal(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        if (this.connection.getSessionTimeZone() == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 105);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (timestampltz == null) {
            this.currentRowBinders[n2] = this.theTSLTZNullBinder;
        }
        else {
            this.currentRowBinders[n2] = this.theTSLTZBinder;
            if (this.parameterDatum == null) {
                this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
            }
            this.parameterDatum[this.currentRank][n2] = timestampltz.getBytes();
        }
        this.currentRowCharLens[n2] = 0;
    }
    
    private Reader isReaderEmpty(Reader in) throws IOException {
        if (!in.markSupported()) {
            in = new BufferedReader(in, 5);
        }
        in.mark(100);
        if (in.read() == -1) {
            return null;
        }
        in.reset();
        return in;
    }
    
    private InputStream isInputStreamEmpty(InputStream in) throws IOException {
        if (!in.markSupported()) {
            in = new BufferedInputStream(in, 5);
        }
        in.mark(100);
        if (in.read() == -1) {
            return null;
        }
        in.reset();
        return in;
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.setAsciiStreamInternal(n, inputStream, n2);
        }
    }
    
    void setAsciiStreamInternal(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.setAsciiStreamInternal(n, inputStream, n2, true);
    }
    
    void setAsciiStreamInternal(final int n, final InputStream inputStream, final long n2, final boolean b) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.set_execute_batch(1);
        this.checkUserStreamForDuplicates(inputStream, n3);
        if (inputStream == null) {
            this.basicBindNullString(n);
        }
        else {
            if (this.userRsetType != 1 && (n2 > this.maxVcsCharsSql || !b)) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 169);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (!b) {
                this.setAsciiStreamContentsForClobCritical(n, inputStream, n2, b);
            }
            else if (this.currentRowFormOfUse[n3] == 1) {
                if (this.sqlKind == 32 || this.sqlKind == 64) {
                    if (n2 <= this.maxVcsCharsPlsql) {
                        this.setAsciiStreamContentsForStringInternal(n, inputStream, (int)n2);
                    }
                    else {
                        this.setAsciiStreamContentsForClobCritical(n, inputStream, n2, b);
                    }
                }
                else if (n2 <= this.maxVcsCharsSql) {
                    this.setAsciiStreamContentsForStringInternal(n, inputStream, (int)n2);
                }
                else if (n2 > 2147483647L) {
                    this.setAsciiStreamContentsForClobCritical(n, inputStream, n2, b);
                }
                else {
                    this.basicBindAsciiStream(n, inputStream, (int)n2);
                }
            }
            else if (this.sqlKind == 32 || this.sqlKind == 64) {
                if (n2 <= this.maxVcsNCharsPlsql) {
                    this.setAsciiStreamContentsForStringInternal(n, inputStream, (int)n2);
                }
                else {
                    this.setAsciiStreamContentsForClobCritical(n, inputStream, n2, b);
                }
            }
            else if (n2 <= this.maxVcsNCharsSql) {
                this.setAsciiStreamContentsForStringInternal(n, inputStream, (int)n2);
            }
            else {
                this.setAsciiStreamContentsForClobCritical(n, inputStream, n2, b);
            }
        }
    }
    
    void basicBindAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        synchronized (this.connection) {
            if (this.userRsetType != 1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 169);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int n3 = n - 1;
            this.currentRowBinders[n3] = this.theLongStreamBinder;
            if (this.parameterStream == null) {
                this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            final InputStream[] array = this.parameterStream[this.currentRank];
            final int n4 = n3;
            final DBConversion conversion = this.connection.conversion;
            final PhysicalConnection connection = this.connection;
            array[n4] = conversion.ConvertStream(inputStream, 5, n2);
            this.currentRowCharLens[n3] = 0;
        }
    }
    
    void setAsciiStreamContentsForStringInternal(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final byte[] b = new byte[n2];
        int off = 0;
        int len = n2;
        try {
            int read;
            while (len > 0 && (read = inputStream.read(b, off, len)) != -1) {
                off += read;
                len -= read;
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (off == 0) {
            this.basicBindNullString(n);
        }
        final char[] value = new char[n2];
        final DBConversion conversion = this.connection.conversion;
        DBConversion.asciiBytesToJavaChars(b, off, value);
        this.basicBindString(n, new String(value));
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.setBinaryStreamInternal(n, inputStream, n2);
    }
    
    void setBinaryStreamInternal(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.setBinaryStreamInternal(n, inputStream, n2, true);
    }
    
    void checkUserStreamForDuplicates(final Object o, final int n) throws SQLException {
        if (o == null) {
            return;
        }
        if (this.userStream != null) {
            for (final Object[] array : this.userStream) {
                for (int length2 = array.length, j = 0; j < length2; ++j) {
                    if (array[j] == o) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 270, n + 1);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                }
            }
        }
        else {
            this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.userStream[this.currentRank][n] = o;
    }
    
    void setBinaryStreamInternal(final int n, final InputStream inputStream, final long n2, final boolean b) throws SQLException {
        synchronized (this.connection) {
            final int n3 = n - 1;
            if (n3 < 0 || n > this.numberOfBindPositions) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.set_execute_batch(1);
            this.checkUserStreamForDuplicates(inputStream, n3);
            if (inputStream == null) {
                this.setRAWInternal(n, null);
            }
            else {
                if (this.userRsetType != 1 && (n2 > this.maxRawBytesSql || !b)) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 169);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                if (!b) {
                    this.setBinaryStreamContentsForBlobCritical(n, inputStream, n2, b);
                }
                else if (this.sqlKind == 32 || this.sqlKind == 64) {
                    if (n2 > this.maxRawBytesPlsql) {
                        this.setBinaryStreamContentsForBlobCritical(n, inputStream, n2, b);
                    }
                    else {
                        this.setBinaryStreamContentsForByteArrayInternal(n, inputStream, (int)n2);
                    }
                }
                else if (n2 > 2147483647L) {
                    this.setBinaryStreamContentsForBlobCritical(n, inputStream, n2, b);
                }
                else if (n2 > this.maxRawBytesSql) {
                    this.basicBindBinaryStream(n, inputStream, (int)n2);
                }
                else {
                    this.setBinaryStreamContentsForByteArrayInternal(n, inputStream, (int)n2);
                }
            }
        }
    }
    
    void setBinaryStreamContentsForByteArrayInternal(final int n, final InputStream inputStream, final int n2) throws SQLException {
        byte[] b = new byte[n2];
        int off = 0;
        int len = n2;
        try {
            int read;
            while (len > 0 && (read = inputStream.read(b, off, len)) != -1) {
                off += read;
                len -= read;
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (off != n2) {
            final byte[] array = new byte[off];
            System.arraycopy(b, 0, array, 0, off);
            b = array;
        }
        this.setBytesInternal(n, b);
    }
    
    @Override
    @Deprecated
    public void setUnicodeStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.setUnicodeStreamInternal(n, inputStream, n2);
    }
    
    void setUnicodeStreamInternal(final int n, final InputStream inputStream, final int n2) throws SQLException {
        synchronized (this.connection) {
            final int n3 = n - 1;
            if (n3 < 0 || n > this.numberOfBindPositions) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.set_execute_batch(1);
            this.checkUserStreamForDuplicates(inputStream, n3);
            if (inputStream == null) {
                this.setStringInternal(n, null);
            }
            else {
                if (this.userRsetType != 1 && n2 > this.maxVcsCharsSql) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 169);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                if (this.sqlKind == 32 || this.sqlKind == 64 || n2 <= this.maxVcsCharsSql) {
                    final byte[] b = new byte[n2];
                    int off = 0;
                    int len = n2;
                    try {
                        int read;
                        while (len > 0 && (read = inputStream.read(b, off, len)) != -1) {
                            off += read;
                            len -= read;
                        }
                    }
                    catch (IOException ex) {
                        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                        sqlException3.fillInStackTrace();
                        throw sqlException3;
                    }
                    final char[] value = new char[off >> 1];
                    final DBConversion conversion = this.connection.conversion;
                    DBConversion.ucs2BytesToJavaChars(b, off, value);
                    this.setStringInternal(n, new String(value));
                }
                else {
                    this.currentRowBinders[n3] = this.theLongStreamBinder;
                    if (this.parameterStream == null) {
                        this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
                    }
                    final InputStream[] array = this.parameterStream[this.currentRank];
                    final int n4 = n3;
                    final DBConversion conversion2 = this.connection.conversion;
                    final PhysicalConnection connection = this.connection;
                    array[n4] = conversion2.ConvertStream(inputStream, 4, n2);
                    this.currentRowCharLens[n3] = 0;
                }
            }
        }
    }
    
    @Override
    @Deprecated
    public void setCustomDatum(final int n, final CustomDatum customDatum) throws SQLException {
        synchronized (this.connection) {
            this.setObjectInternal(n, this.connection.toDatum(customDatum));
        }
    }
    
    void setCustomDatumInternal(final int n, final CustomDatum customDatum) throws SQLException {
        synchronized (this.connection) {
            final Datum datum = this.connection.toDatum(customDatum);
            this.setObjectCritical(n, datum, this.sqlTypeForObject(datum), 0);
        }
    }
    
    @Override
    public void setORAData(final int n, final ORAData oraData) throws SQLException {
        this.setORADataInternal(n, oraData);
    }
    
    void setORADataInternal(final int n, final ORAData oraData) throws SQLException {
        synchronized (this.connection) {
            final Datum datum = oraData.toDatum(this.connection);
            final int sqlTypeForObject = this.sqlTypeForObject(datum);
            this.setObjectCritical(n, datum, sqlTypeForObject, 0);
            if (sqlTypeForObject == 2002 || sqlTypeForObject == 2008 || sqlTypeForObject == 2003) {
                this.currentRowCharLens[n - 1] = 0;
            }
        }
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            this.setObjectInternal(n, o, n2, n3);
        }
    }
    
    void setObjectInternal(final int n, final Object o, final int n2, final int n3) throws SQLException {
        if (o == null && n2 != 2002 && n2 != 2008 && n2 != 2003 && n2 != 2007 && n2 != 2006 && n2 != 2009) {
            this.setNullInternal(n, n2);
        }
        else if (n2 == 2002 || n2 == 2008 || n2 == 2003 || n2 == 2009) {
            this.setObjectCritical(n, o, n2, n3);
            this.currentRowCharLens[n - 1] = 0;
        }
        else {
            this.setObjectCritical(n, o, n2, n3);
        }
    }
    
    void setObjectCritical(final int n, final Object anObject, final int n2, final int n3) throws SQLException {
        switch (n2) {
            case 1: {
                if (anObject instanceof CHAR) {
                    this.setCHARInternal(n, (CHAR)anObject);
                    break;
                }
                if (anObject instanceof String) {
                    this.setStringInternal(n, (String)anObject);
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setStringInternal(n, "" + (((boolean)anObject) ? 1 : 0));
                    break;
                }
                if (anObject instanceof Integer) {
                    this.setStringInternal(n, "" + (int)anObject);
                    break;
                }
                if (anObject instanceof Long) {
                    this.setStringInternal(n, "" + (long)anObject);
                    break;
                }
                if (anObject instanceof Float) {
                    this.setStringInternal(n, "" + (float)anObject);
                    break;
                }
                if (anObject instanceof Double) {
                    this.setStringInternal(n, "" + (double)anObject);
                    break;
                }
                if (anObject instanceof BigDecimal) {
                    this.setStringInternal(n, ((BigDecimal)anObject).toString());
                    break;
                }
                if (anObject instanceof Date) {
                    this.setStringInternal(n, "" + ((Date)anObject).toString());
                    break;
                }
                if (anObject instanceof Time) {
                    this.setStringInternal(n, "" + ((Time)anObject).toString());
                    break;
                }
                if (anObject instanceof Timestamp) {
                    this.setStringInternal(n, "" + ((Timestamp)anObject).toString());
                    break;
                }
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            case 12: {
                if (anObject instanceof String) {
                    this.setStringInternal(n, (String)anObject);
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setStringInternal(n, "" + (((boolean)anObject) ? 1 : 0));
                    break;
                }
                if (anObject instanceof Integer) {
                    this.setStringInternal(n, "" + (int)anObject);
                    break;
                }
                if (anObject instanceof Long) {
                    this.setStringInternal(n, "" + (long)anObject);
                    break;
                }
                if (anObject instanceof Float) {
                    this.setStringInternal(n, "" + (float)anObject);
                    break;
                }
                if (anObject instanceof Double) {
                    this.setStringInternal(n, "" + (double)anObject);
                    break;
                }
                if (anObject instanceof BigDecimal) {
                    this.setStringInternal(n, ((BigDecimal)anObject).toString());
                    break;
                }
                if (anObject instanceof Date) {
                    this.setStringInternal(n, "" + ((Date)anObject).toString());
                    break;
                }
                if (anObject instanceof Time) {
                    this.setStringInternal(n, "" + ((Time)anObject).toString());
                    break;
                }
                if (anObject instanceof Timestamp) {
                    this.setStringInternal(n, "" + ((Timestamp)anObject).toString());
                    break;
                }
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            case 999: {
                this.setFixedCHARInternal(n, (String)anObject);
                break;
            }
            case -1: {
                if (anObject instanceof String) {
                    this.setStringInternal(n, (String)anObject);
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setStringInternal(n, "" + (((boolean)anObject) ? 1 : 0));
                    break;
                }
                if (anObject instanceof Integer) {
                    this.setStringInternal(n, "" + (int)anObject);
                    break;
                }
                if (anObject instanceof Long) {
                    this.setStringInternal(n, "" + (long)anObject);
                    break;
                }
                if (anObject instanceof Float) {
                    this.setStringInternal(n, "" + (float)anObject);
                    break;
                }
                if (anObject instanceof Double) {
                    this.setStringInternal(n, "" + (double)anObject);
                    break;
                }
                if (anObject instanceof BigDecimal) {
                    this.setStringInternal(n, ((BigDecimal)anObject).toString());
                    break;
                }
                if (anObject instanceof Date) {
                    this.setStringInternal(n, "" + ((Date)anObject).toString());
                    break;
                }
                if (anObject instanceof Time) {
                    this.setStringInternal(n, "" + ((Time)anObject).toString());
                    break;
                }
                if (anObject instanceof Timestamp) {
                    this.setStringInternal(n, "" + ((Timestamp)anObject).toString());
                    break;
                }
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            case 2: {
                if (anObject instanceof NUMBER) {
                    this.setNUMBERInternal(n, (NUMBER)anObject);
                    break;
                }
                if (anObject instanceof Integer) {
                    this.setIntInternal(n, (int)anObject);
                    break;
                }
                if (anObject instanceof Long) {
                    this.setLongInternal(n, (long)anObject);
                    break;
                }
                if (anObject instanceof Float) {
                    this.setFloatInternal(n, (float)anObject);
                    break;
                }
                if (anObject instanceof Double) {
                    this.setDoubleInternal(n, (double)anObject);
                    break;
                }
                if (anObject instanceof BigDecimal) {
                    this.setBigDecimalInternal(n, (BigDecimal)anObject);
                    break;
                }
                if (anObject instanceof String) {
                    this.setNUMBERInternal(n, new NUMBER((String)anObject, n3));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setIntInternal(n, ((boolean)anObject) ? 1 : 0);
                    break;
                }
                if (anObject instanceof Short) {
                    this.setShortInternal(n, (short)anObject);
                    break;
                }
                if (anObject instanceof Byte) {
                    this.setByteInternal(n, (byte)anObject);
                    break;
                }
                final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException4.fillInStackTrace();
                throw sqlException4;
            }
            case 3: {
                if (anObject instanceof BigDecimal) {
                    this.setBigDecimalInternal(n, (BigDecimal)anObject);
                    break;
                }
                if (anObject instanceof Number) {
                    this.setBigDecimalInternal(n, new BigDecimal(((Number)anObject).doubleValue()));
                    break;
                }
                if (anObject instanceof NUMBER) {
                    this.setBigDecimalInternal(n, ((NUMBER)anObject).bigDecimalValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setBigDecimalInternal(n, new BigDecimal((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setBigDecimalInternal(n, new BigDecimal(anObject ? 1.0 : 0.0));
                    break;
                }
                final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException5.fillInStackTrace();
                throw sqlException5;
            }
            case -7: {
                if (anObject instanceof Boolean) {
                    this.setByteInternal(n, (byte)(((boolean)anObject) ? 1 : 0));
                    break;
                }
                if (anObject instanceof String) {
                    this.setByteInternal(n, (byte)(("true".equalsIgnoreCase((String)anObject) || "1".equals(anObject)) ? 1 : 0));
                    break;
                }
                if (anObject instanceof Number) {
                    this.setIntInternal(n, (((Number)anObject).byteValue() != 0) ? 1 : 0);
                    break;
                }
                final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException6.fillInStackTrace();
                throw sqlException6;
            }
            case -6: {
                if (anObject instanceof Number) {
                    this.setByteInternal(n, ((Number)anObject).byteValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setByteInternal(n, Byte.parseByte((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setByteInternal(n, (byte)(((boolean)anObject) ? 1 : 0));
                    break;
                }
                final SQLException sqlException7 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException7.fillInStackTrace();
                throw sqlException7;
            }
            case 5: {
                if (anObject instanceof Number) {
                    this.setShortInternal(n, ((Number)anObject).shortValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setShortInternal(n, Short.parseShort((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setShortInternal(n, (short)(((boolean)anObject) ? 1 : 0));
                    break;
                }
                final SQLException sqlException8 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException8.fillInStackTrace();
                throw sqlException8;
            }
            case 4: {
                if (anObject instanceof Number) {
                    this.setIntInternal(n, ((Number)anObject).intValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setIntInternal(n, Integer.parseInt((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setIntInternal(n, ((boolean)anObject) ? 1 : 0);
                    break;
                }
                final SQLException sqlException9 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException9.fillInStackTrace();
                throw sqlException9;
            }
            case -5: {
                if (anObject instanceof Number) {
                    this.setLongInternal(n, ((Number)anObject).longValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setLongInternal(n, Long.parseLong((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setLongInternal(n, ((boolean)anObject) ? 1 : 0);
                    break;
                }
                final SQLException sqlException10 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException10.fillInStackTrace();
                throw sqlException10;
            }
            case 7: {
                if (anObject instanceof Number) {
                    this.setFloatInternal(n, ((Number)anObject).floatValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setFloatInternal(n, Float.valueOf((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setFloatInternal(n, ((boolean)anObject) ? 1.0f : 0.0f);
                    break;
                }
                final SQLException sqlException11 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException11.fillInStackTrace();
                throw sqlException11;
            }
            case 6:
            case 8: {
                if (anObject instanceof Number) {
                    this.setDoubleInternal(n, ((Number)anObject).doubleValue());
                    break;
                }
                if (anObject instanceof String) {
                    this.setDoubleInternal(n, Double.valueOf((String)anObject));
                    break;
                }
                if (anObject instanceof Boolean) {
                    this.setDoubleInternal(n, ((boolean)anObject) ? 1.0 : 0.0);
                    break;
                }
                final SQLException sqlException12 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException12.fillInStackTrace();
                throw sqlException12;
            }
            case -2: {
                if (anObject instanceof RAW) {
                    this.setRAWInternal(n, (RAW)anObject);
                    break;
                }
                this.setBytesInternal(n, (byte[])anObject);
                break;
            }
            case -3: {
                this.setBytesInternal(n, (byte[])anObject);
                break;
            }
            case -4: {
                this.setBytesInternal(n, (byte[])anObject);
                break;
            }
            case 91: {
                if (anObject instanceof DATE) {
                    this.setDATEInternal(n, (DATE)anObject);
                    break;
                }
                if (anObject instanceof Date) {
                    this.setDATEInternal(n, new DATE(anObject, this.getDefaultCalendar()));
                    break;
                }
                if (anObject instanceof Timestamp) {
                    this.setDATEInternal(n, new DATE((Timestamp)anObject));
                    break;
                }
                if (anObject instanceof String) {
                    this.setDateInternal(n, Date.valueOf((String)anObject));
                    break;
                }
                final SQLException sqlException13 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException13.fillInStackTrace();
                throw sqlException13;
            }
            case 92: {
                if (anObject instanceof Time) {
                    this.setTimeInternal(n, (Time)anObject);
                    break;
                }
                if (anObject instanceof Timestamp) {
                    this.setTimeInternal(n, new Time(((Timestamp)anObject).getTime()));
                    break;
                }
                if (anObject instanceof Date) {
                    this.setTimeInternal(n, new Time(((Date)anObject).getTime()));
                    break;
                }
                if (anObject instanceof String) {
                    this.setTimeInternal(n, Time.valueOf((String)anObject));
                    break;
                }
                final SQLException sqlException14 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException14.fillInStackTrace();
                throw sqlException14;
            }
            case 93: {
                if (anObject instanceof TIMESTAMP) {
                    this.setTIMESTAMPInternal(n, (TIMESTAMP)anObject);
                    break;
                }
                if (anObject instanceof Timestamp) {
                    this.setTimestampInternal(n, (Timestamp)anObject);
                    break;
                }
                if (anObject instanceof Date) {
                    this.setTIMESTAMPInternal(n, new TIMESTAMP((Date)anObject));
                    break;
                }
                if (anObject instanceof DATE) {
                    this.setTIMESTAMPInternal(n, new TIMESTAMP(((DATE)anObject).timestampValue()));
                    break;
                }
                if (anObject instanceof String) {
                    this.setTimestampInternal(n, Timestamp.valueOf((String)anObject));
                    break;
                }
                final SQLException sqlException15 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 132);
                sqlException15.fillInStackTrace();
                throw sqlException15;
            }
            case -100: {
                this.setTIMESTAMPInternal(n, (TIMESTAMP)anObject);
                break;
            }
            case -101: {
                this.setTIMESTAMPTZInternal(n, (TIMESTAMPTZ)anObject);
                break;
            }
            case -102: {
                this.setTIMESTAMPLTZInternal(n, (TIMESTAMPLTZ)anObject);
                break;
            }
            case -103: {
                this.setINTERVALYMInternal(n, (INTERVALYM)anObject);
                break;
            }
            case -104: {
                this.setINTERVALDSInternal(n, (INTERVALDS)anObject);
                break;
            }
            case -8: {
                this.setROWIDInternal(n, (ROWID)anObject);
                break;
            }
            case 100: {
                this.setBinaryFloatInternal(n, (BINARY_FLOAT)anObject);
                break;
            }
            case 101: {
                this.setBinaryDoubleInternal(n, (BINARY_DOUBLE)anObject);
                break;
            }
            case 2004: {
                this.setBLOBInternal(n, (BLOB)anObject);
                break;
            }
            case 2011: {
                this.setFormOfUse(n, (short)2);
            }
            case 2005: {
                this.setCLOBInternal(n, (CLOB)anObject);
                break;
            }
            case -13: {
                this.setBFILEInternal(n, (BFILE)anObject);
                break;
            }
            case 2002:
            case 2008: {
                this.setSTRUCTInternal(n, STRUCT.toSTRUCT(anObject, this.connection));
                break;
            }
            case 2003: {
                this.setARRAYInternal(n, ARRAY.toARRAY(anObject, this.connection));
                break;
            }
            case 2007: {
                this.setOPAQUEInternal(n, (OPAQUE)anObject);
                break;
            }
            case 2006: {
                this.setREFInternal(n, (REF)anObject);
                break;
            }
            case 2009: {
                this.setSQLXMLInternal(n, (SQLXML)anObject);
                break;
            }
            default: {
                final SQLException sqlException16 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException16.fillInStackTrace();
                throw sqlException16;
            }
        }
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o, final int n, final int n2) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setObjectInternal(i + 1, o);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2) throws SQLException {
        this.setObjectInternal(n, o, n2, 0);
    }
    
    void setObjectInternal(final int n, final Object o, final int n2) throws SQLException {
        this.setObjectInternal(n, o, n2, 0);
    }
    
    @Override
    public void setRefType(final int n, final REF ref) throws SQLException {
        this.setREFInternal(n, ref);
    }
    
    void setRefTypeInternal(final int n, final REF ref) throws SQLException {
        this.setREFInternal(n, ref);
    }
    
    @Override
    public void setRef(final int n, final Ref ref) throws SQLException {
        this.setREFInternal(n, (REF)ref);
    }
    
    void setRefInternal(final int n, final Ref ref) throws SQLException {
        this.setREFInternal(n, (REF)ref);
    }
    
    @Override
    public void setREF(final int n, final REF ref) throws SQLException {
        this.setREFInternal(n, ref);
    }
    
    void setREFInternal(final int n, final REF ref) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (ref == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.setREFCritical(n2, ref);
        this.currentRowCharLens[n2] = 0;
    }
    
    void setREFCritical(final int n, final REF ref) throws SQLException {
        final StructDescriptor descriptor = ref.getDescriptor();
        if (descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 52);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.currentRowBinders[n] = this.theRefTypeBinder;
        if (this.parameterDatum == null) {
            this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
        }
        this.parameterDatum[this.currentRank][n] = ref.getBytes();
        final OracleTypeADT oracleTypeADT = descriptor.getOracleTypeADT();
        oracleTypeADT.getTOID();
        if (this.parameterOtype == null) {
            this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterOtype[this.currentRank][n] = oracleTypeADT;
    }
    
    @Override
    public void setObject(final int n, final Object o) throws SQLException {
        this.setObjectInternal(n, o);
    }
    
    void setObjectInternal(final int n, final Object o) throws SQLException {
        if (o instanceof ORAData) {
            this.setORADataInternal(n, (ORAData)o);
        }
        else if (o instanceof CustomDatum) {
            this.setCustomDatumInternal(n, (CustomDatum)o);
        }
        else {
            this.setObjectInternal(n, o, this.sqlTypeForObject(o), 0);
        }
    }
    
    @Override
    public void setOracleObject(final int n, final Datum datum) throws SQLException {
        this.setObjectInternal(n, datum);
    }
    
    void setOracleObjectInternal(final int n, final Datum datum) throws SQLException {
        this.setObjectInternal(n, datum);
    }
    
    @Override
    public void setPlsqlIndexTable(final int n, final Object o, final int n2, final int n3, final int n4, final int n5) throws SQLException {
        synchronized (this.connection) {
            this.setPlsqlIndexTableInternal(n, o, n2, n3, n4, n5);
        }
    }
    
    void setPlsqlIndexTableInternal(final int n, final Object o, final int n2, final int n3, final int n4, int length) throws SQLException {
        final int n5 = n - 1;
        if (n5 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (o == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 271);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final int internalType = this.getInternalType(n4);
        Serializable[] numberArray = null;
        switch (internalType) {
            case 1:
            case 96: {
                String[] array2;
                if (o instanceof CHAR[]) {
                    final CHAR[] array = (CHAR[])o;
                    final int n6 = array.length;
                    array2 = new String[n6];
                    for (int i = 0; i < n6; ++i) {
                        final CHAR char1 = array[i];
                        if (char1 != null) {
                            array2[i] = char1.getString();
                        }
                    }
                }
                else {
                    if (!(o instanceof String[])) {
                        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 97);
                        sqlException3.fillInStackTrace();
                        throw sqlException3;
                    }
                    array2 = (String[])o;
                    final int n6 = array2.length;
                }
                if (length == 0 && array2 != null) {
                    for (final String s : array2) {
                        if (s != null && length < s.length()) {
                            length = s.length();
                        }
                    }
                }
                numberArray = array2;
                break;
            }
            case 2:
            case 6: {
                numberArray = OracleTypeNUMBER.toNUMBERArray(o, this.connection, 1L, n3);
                if (length == 0 && numberArray != null) {
                    length = 22;
                }
                this.currentRowCharLens[n5] = 0;
                break;
            }
            default: {
                final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 97);
                sqlException4.fillInStackTrace();
                throw sqlException4;
            }
        }
        if (numberArray.length == 0) {
            final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 272);
            sqlException5.fillInStackTrace();
            throw sqlException5;
        }
        this.currentRowBinders[n5] = this.thePlsqlIbtBinder;
        if (this.parameterPlsqlIbt == null) {
            this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
        }
        this.parameterPlsqlIbt[this.currentRank][n5] = new PlsqlIbtBindInfo(numberArray, n2, n3, internalType, length);
        this.hasIbtBind = true;
    }
    
    public void setPlsqlIndexTableAtName(final String s, final Object o, final int n, final int n2, final int n3, final int n4) throws SQLException {
        synchronized (this.connection) {
            final String intern = s.intern();
            final String[] parameterList = this.sqlObject.getParameterList();
            boolean b = false;
            for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
                if (parameterList[i] == intern) {
                    this.setPlsqlIndexTableInternal(i + 1, o, n, n2, n3, n4);
                    b = true;
                }
            }
            if (!b) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
    }
    
    @Override
    void endOfResultSet(final boolean b) throws SQLException {
        if (!b) {
            this.prepareForNewResults(false, false);
        }
        this.rowPrefetchInLastFetch = -1;
    }
    
    int sqlTypeForObject(final Object o) {
        if (o == null) {
            return 0;
        }
        if (!(o instanceof Datum)) {
            if (o instanceof String) {
                return this.fixedString ? 999 : 12;
            }
            if (o instanceof BigDecimal) {
                return 2;
            }
            if (o instanceof Boolean) {
                return -7;
            }
            if (o instanceof Integer) {
                return 4;
            }
            if (o instanceof Long) {
                return -5;
            }
            if (o instanceof Float) {
                return 7;
            }
            if (o instanceof Double) {
                return 8;
            }
            if (o instanceof byte[]) {
                return -3;
            }
            if (o instanceof Short) {
                return 5;
            }
            if (o instanceof Byte) {
                return -6;
            }
            if (o instanceof Date) {
                return 91;
            }
            if (o instanceof Time) {
                return 92;
            }
            if (o instanceof Timestamp) {
                return 93;
            }
            if (o instanceof SQLData) {
                return 2002;
            }
            if (o instanceof ObjectData) {
                return 2002;
            }
        }
        else {
            if (o instanceof BINARY_FLOAT) {
                return 100;
            }
            if (o instanceof BINARY_DOUBLE) {
                return 101;
            }
            if (o instanceof BLOB) {
                return 2004;
            }
            if (o instanceof CLOB) {
                return 2005;
            }
            if (o instanceof BFILE) {
                return -13;
            }
            if (o instanceof ROWID) {
                return -8;
            }
            if (o instanceof NUMBER) {
                return 2;
            }
            if (o instanceof DATE) {
                return 91;
            }
            if (o instanceof TIMESTAMP) {
                return 93;
            }
            if (o instanceof TIMESTAMPTZ) {
                return -101;
            }
            if (o instanceof TIMESTAMPLTZ) {
                return -102;
            }
            if (o instanceof REF) {
                return 2006;
            }
            if (o instanceof CHAR) {
                return 1;
            }
            if (o instanceof RAW) {
                return -2;
            }
            if (o instanceof ARRAY) {
                return 2003;
            }
            if (o instanceof STRUCT) {
                return 2002;
            }
            if (o instanceof OPAQUE) {
                return 2007;
            }
            if (o instanceof INTERVALYM) {
                return -103;
            }
            if (o instanceof INTERVALDS) {
                return -104;
            }
            if (o instanceof OracleSQLXML) {
                return 2009;
            }
        }
        return 1111;
    }
    
    @Override
    public void clearParameters() throws SQLException {
        synchronized (this.connection) {
            this.clearParameters = true;
            for (int i = 0; i < this.numberOfBindPositions; ++i) {
                this.currentRowBinders[i] = null;
            }
        }
    }
    
    void printByteArray(final byte[] array) {
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if ((array[i] & 0xFF) < 16) {}
            }
        }
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final int n2) throws SQLException {
        this.setCharacterStreamInternal(n, reader, n2);
    }
    
    void setCharacterStreamInternal(final int n, final Reader reader, final int n2) throws SQLException {
        this.setCharacterStreamInternal(n, reader, n2, true);
    }
    
    void setCharacterStreamInternal(final int n, final Reader reader, final long n2, final boolean b) throws SQLException {
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.set_execute_batch(1);
        this.checkUserStreamForDuplicates(reader, n3);
        if (reader == null) {
            this.basicBindNullString(n);
        }
        else {
            if (this.userRsetType != 1 && (n2 > this.maxVcsCharsSql || !b)) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 169);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (!b) {
                this.setReaderContentsForClobCritical(n, reader, n2, b);
            }
            else if (this.currentRowFormOfUse[n3] == 1) {
                if (this.sqlKind == 32 || this.sqlKind == 64) {
                    if (n2 > this.maxVcsBytesPlsql || (n2 > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) {
                        this.setReaderContentsForClobCritical(n, reader, n2, b);
                    }
                    else if (n2 <= this.maxVcsCharsPlsql) {
                        this.setReaderContentsForStringInternal(n, reader, (int)n2);
                    }
                    else {
                        this.setReaderContentsForStringOrClobInVariableWidthCase(n, reader, (int)n2, false);
                    }
                }
                else if (n2 <= this.maxVcsCharsSql) {
                    this.setReaderContentsForStringInternal(n, reader, (int)n2);
                }
                else if (n2 > 2147483647L) {
                    this.setReaderContentsForClobCritical(n, reader, n2, b);
                }
                else {
                    this.basicBindCharacterStream(n, reader, (int)n2, false);
                }
            }
            else if (this.sqlKind == 32 || this.sqlKind == 64) {
                if (n2 > this.maxVcsBytesPlsql || (n2 > this.maxVcsNCharsPlsql && this.isServerCharSetFixedWidth)) {
                    this.setReaderContentsForClobCritical(n, reader, n2, b);
                }
                else if (n2 <= this.maxVcsNCharsPlsql) {
                    this.setReaderContentsForStringInternal(n, reader, (int)n2);
                }
                else {
                    this.setReaderContentsForStringOrClobInVariableWidthCase(n, reader, (int)n2, true);
                }
            }
            else if (n2 <= this.maxVcsNCharsSql) {
                this.setReaderContentsForStringInternal(n, reader, (int)n2);
            }
            else {
                this.setReaderContentsForClobCritical(n, reader, n2, b);
            }
        }
    }
    
    void basicBindCharacterStream(final int n, final Reader reader, final int n2, final boolean b) throws SQLException {
        synchronized (this.connection) {
            final int n3 = n - 1;
            if (b) {
                this.currentRowBinders[n3] = this.theLongStreamForStringBinder;
            }
            else {
                this.currentRowBinders[n3] = this.theLongStreamBinder;
            }
            if (this.parameterStream == null) {
                this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
            }
            final InputStream[] array = this.parameterStream[this.currentRank];
            final int n4 = n3;
            InputStream inputStream;
            if (b) {
                final DBConversion conversion = this.connection.conversion;
                final PhysicalConnection connection = this.connection;
                inputStream = conversion.ConvertStreamInternal(reader, 7, n2, this.currentRowFormOfUse[n3]);
            }
            else {
                final DBConversion conversion2 = this.connection.conversion;
                final PhysicalConnection connection2 = this.connection;
                inputStream = conversion2.ConvertStream(reader, 7, n2, this.currentRowFormOfUse[n3]);
            }
            array[n4] = inputStream;
            this.currentRowCharLens[n3] = 0;
        }
    }
    
    void setReaderContentsForStringOrClobInVariableWidthCase(final int n, final Reader reader, final int n2, final boolean b) throws SQLException {
        char[] array = new char[n2];
        int n3 = 0;
        int n4 = n2;
        try {
            int read;
            while (n4 > 0 && (read = reader.read(array, n3, n4)) != -1) {
                n3 += read;
                n4 -= read;
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n3 != n2) {
            final char[] array2 = new char[n3];
            System.arraycopy(array, 0, array2, 0, n3);
            array = array2;
        }
        if (this.connection.conversion.encodedByteLength(array, b) < this.maxVcsBytesPlsql) {
            this.setStringInternal(n, new String(array));
        }
        else {
            this.setStringForClobCritical(n, new String(array));
        }
    }
    
    void setReaderContentsForStringInternal(final int n, final Reader reader, final int n2) throws SQLException {
        char[] value = new char[n2];
        int n3 = 0;
        int n4 = n2;
        try {
            int read;
            while (n4 > 0 && (read = reader.read(value, n3, n4)) != -1) {
                n3 += read;
                n4 -= read;
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n3 != n2) {
            final char[] array = new char[n3];
            System.arraycopy(value, 0, array, 0, n3);
            value = array;
        }
        this.setStringInternal(n, new String(value));
    }
    
    @Override
    public void setDate(final int n, final Date date, final Calendar calendar) throws SQLException {
        this.setDATEInternal(n, (date == null) ? null : new DATE(date, calendar));
    }
    
    void setDateInternal(final int n, final Date date, final Calendar calendar) throws SQLException {
        this.setDATEInternal(n, (date == null) ? null : new DATE(date, calendar));
    }
    
    @Override
    public void setTime(final int n, final Time time, final Calendar calendar) throws SQLException {
        this.setDATEInternal(n, (time == null) ? null : new DATE(time, calendar));
    }
    
    void setTimeInternal(final int n, final Time time, final Calendar calendar) throws SQLException {
        this.setDATEInternal(n, (time == null) ? null : new DATE(time, calendar));
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.setTimestampInternal(n, timestamp, calendar);
    }
    
    void setTimestampInternal(final int n, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.setTIMESTAMPInternal(n, (timestamp == null) ? null : new TIMESTAMP(timestamp, calendar));
    }
    
    @Override
    public void setCheckBindTypes(final boolean checkBindTypes) {
        this.checkBindTypes = checkBindTypes;
    }
    
    final void setOracleBatchStyle() throws SQLException {
        if (this.m_batchStyle == 2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.m_batchStyle == 0) {}
        this.m_batchStyle = 1;
    }
    
    @Override
    boolean isOracleBatchStyle() {
        return this.m_batchStyle == 1;
    }
    
    final void setJdbcBatchStyle() throws SQLException {
        if (this.m_batchStyle == 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.m_batchStyle = 2;
    }
    
    @Override
    final void checkIfJdbcBatchExists() throws SQLException {
        if (this.doesJdbcBatchExist()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    boolean doesJdbcBatchExist() {
        return this.currentRank > 0 && this.m_batchStyle == 2;
    }
    
    boolean isJdbcBatchStyle() {
        return this.m_batchStyle == 2;
    }
    
    @Override
    public void addBatch() throws SQLException {
        synchronized (this.connection) {
            this.setJdbcBatchStyle();
            this.processCompletedBindRow(this.currentRank + 2, this.currentRank > 0 && (this.sqlKind == 32 || this.sqlKind == 64));
            ++this.currentRank;
        }
    }
    
    @Override
    public void addBatch(final String s) throws SQLException {
        synchronized (this.connection) {
            final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
            unsupportedFeatureSqlException.fillInStackTrace();
            throw unsupportedFeatureSqlException;
        }
    }
    
    @Override
    public void clearBatch() throws SQLException {
        synchronized (this.connection) {
            for (int i = this.currentRank - 1; i >= 0; --i) {
                for (int j = 0; j < this.numberOfBindPositions; ++j) {
                    this.binders[i][j] = null;
                }
            }
            this.currentRank = 0;
            if (this.binders != null) {
                this.currentRowBinders = this.binders[0];
            }
            this.pushedBatches = null;
            this.pushedBatchesTail = null;
            this.firstRowInBatch = 0;
            this.clearParameters = true;
        }
    }
    
    void executeForRowsWithTimeout(final boolean b) throws SQLException {
        if (this.queryTimeout > 0) {
            try {
                this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
                this.isExecuting = true;
                this.executeForRows(b);
            }
            finally {
                this.connection.getTimeout().cancelTimeout();
                this.isExecuting = false;
            }
        }
        else {
            try {
                this.isExecuting = true;
                this.executeForRows(b);
            }
            finally {
                this.isExecuting = false;
            }
        }
    }
    
    @Override
    public int[] executeBatch() throws SQLException {
        synchronized (this.connection) {
            int[] array = new int[this.currentRank];
            int i = 0;
            this.cleanOldTempLobs();
            this.setJdbcBatchStyle();
            if (this.currentRank > 0) {
                this.ensureOpen();
                this.prepareForNewResults(true, true);
                if (this.sqlKind == 1) {
                    final BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, 0, null);
                    batchUpdateException.fillInStackTrace();
                    throw batchUpdateException;
                }
                this.noMoreUpdateCounts = false;
                int validRows = 0;
                try {
                    this.connection.registerHeartbeat();
                    this.connection.needLine();
                    if (!this.isOpen) {
                        this.connection.open(this);
                        this.isOpen = true;
                    }
                    final int currentRank = this.currentRank;
                    if (this.pushedBatches == null) {
                        this.setupBindBuffers(0, this.currentRank);
                        this.executeForRowsWithTimeout(false);
                    }
                    else {
                        if (this.currentRank > this.firstRowInBatch) {
                            this.pushBatch(true);
                        }
                        final boolean needToParse = this.needToParse;
                        do {
                            final PushedBatch pushedBatches = this.pushedBatches;
                            this.currentBatchCharLens = pushedBatches.currentBatchCharLens;
                            this.lastBoundCharLens = pushedBatches.lastBoundCharLens;
                            this.lastBoundNeeded = pushedBatches.lastBoundNeeded;
                            this.currentBatchBindAccessors = pushedBatches.currentBatchBindAccessors;
                            this.needToParse = pushedBatches.need_to_parse;
                            this.currentBatchNeedToPrepareBinds = pushedBatches.current_batch_need_to_prepare_binds;
                            this.firstRowInBatch = pushedBatches.first_row_in_batch;
                            this.setupBindBuffers(pushedBatches.first_row_in_batch, pushedBatches.number_of_rows_to_be_bound);
                            this.currentRank = pushedBatches.number_of_rows_to_be_bound;
                            this.executeForRowsWithTimeout(false);
                            validRows += this.validRows;
                            if (this.sqlKind == 32 || this.sqlKind == 64) {
                                array[i++] = this.validRows;
                            }
                            this.pushedBatches = pushedBatches.next;
                        } while (this.pushedBatches != null);
                        this.pushedBatchesTail = null;
                        this.firstRowInBatch = 0;
                        this.needToParse = needToParse;
                    }
                    this.slideDownCurrentRow(currentRank);
                }
                catch (SQLException ex) {
                    final int currentRank2 = this.currentRank;
                    this.clearBatch();
                    this.needToParse = true;
                    if (this.sqlKind != 32 && this.sqlKind != 64) {
                        if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch != currentRank2) {
                            array = new int[this.numberOfExecutedElementsInBatch];
                            for (i = 0; i < this.numberOfExecutedElementsInBatch; ++i) {
                                array[i] = -2;
                            }
                        }
                        else {
                            for (i = 0; i < array.length; ++i) {
                                array[i] = -3;
                            }
                        }
                    }
                    this.resetCurrentRowBinders();
                    final BatchUpdateException batchUpdateException2 = DatabaseError.createBatchUpdateException(ex, (this.sqlKind == 32 || this.sqlKind == 64) ? i : array.length, array);
                    batchUpdateException2.fillInStackTrace();
                    throw batchUpdateException2;
                }
                finally {
                    if (this.sqlKind == 32 || this.sqlKind == 64 || validRows > this.validRows) {
                        this.validRows = validRows;
                    }
                    this.checkValidRowsStatus();
                    this.currentRank = 0;
                }
                if (this.validRows < 0) {
                    for (int j = 0; j < array.length; ++j) {
                        array[j] = -3;
                    }
                    final BatchUpdateException batchUpdateException3 = DatabaseError.createBatchUpdateException(81, 0, array);
                    batchUpdateException3.fillInStackTrace();
                    throw batchUpdateException3;
                }
                if (this.sqlKind != 32 && this.sqlKind != 64) {
                    for (int k = 0; k < array.length; ++k) {
                        array[k] = -2;
                    }
                }
            }
            this.connection.registerHeartbeat();
            return array;
        }
    }
    
    void pushBatch(final boolean b) {
        final PushedBatch pushedBatchesTail = new PushedBatch();
        pushedBatchesTail.currentBatchCharLens = new int[this.numberOfBindPositions];
        System.arraycopy(this.currentBatchCharLens, 0, pushedBatchesTail.currentBatchCharLens, 0, this.numberOfBindPositions);
        pushedBatchesTail.lastBoundCharLens = new int[this.numberOfBindPositions];
        System.arraycopy(this.lastBoundCharLens, 0, pushedBatchesTail.lastBoundCharLens, 0, this.numberOfBindPositions);
        if (this.currentBatchBindAccessors != null) {
            pushedBatchesTail.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
            System.arraycopy(this.currentBatchBindAccessors, 0, pushedBatchesTail.currentBatchBindAccessors, 0, this.numberOfBindPositions);
        }
        pushedBatchesTail.lastBoundNeeded = this.lastBoundNeeded;
        pushedBatchesTail.need_to_parse = this.needToParse;
        pushedBatchesTail.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
        pushedBatchesTail.first_row_in_batch = this.firstRowInBatch;
        pushedBatchesTail.number_of_rows_to_be_bound = this.currentRank - this.firstRowInBatch;
        if (this.pushedBatches == null) {
            this.pushedBatches = pushedBatchesTail;
        }
        else {
            this.pushedBatchesTail.next = pushedBatchesTail;
        }
        this.pushedBatchesTail = pushedBatchesTail;
        if (!b) {
            final int[] currentBatchCharLens = this.currentBatchCharLens;
            this.currentBatchCharLens = this.lastBoundCharLens;
            this.lastBoundCharLens = currentBatchCharLens;
            this.lastBoundNeeded = false;
            for (int i = 0; i < this.numberOfBindPositions; ++i) {
                this.currentBatchCharLens[i] = 0;
            }
            this.firstRowInBatch = this.currentRank;
        }
    }
    
    int doScrollPstmtExecuteUpdate() throws SQLException {
        this.doScrollExecuteCommon();
        if (this.sqlKind == 1) {
            this.scrollRsetTypeSolved = true;
        }
        return this.validRows;
    }
    
    @Override
    public int copyBinds(final Statement statement, final int n) throws SQLException {
        if (this.numberOfBindPositions > 0) {
            final OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)statement;
            int n2 = this.bindIndicatorSubRange + 5;
            int bindByteSubRange = this.bindByteSubRange;
            int bindCharSubRange = this.bindCharSubRange;
            int indicatorsOffset = this.indicatorsOffset;
            int valueLengthsOffset = this.valueLengthsOffset;
            for (int i = 0; i < this.numberOfBindPositions; ++i) {
                final short j = this.bindIndicators[n2 + 0];
                final short n3 = this.bindIndicators[n2 + 1];
                final short n4 = this.bindIndicators[n2 + 2];
                final int n5 = i + n;
                if (this.bindIndicators[indicatorsOffset] == -1) {
                    oraclePreparedStatement.currentRowBinders[n5] = this.copiedNullBinder(j, n3);
                    if (n4 > 0) {
                        oraclePreparedStatement.currentRowCharLens[n5] = 1;
                    }
                }
                else if (j == 109 || j == 111) {
                    oraclePreparedStatement.currentRowBinders[n5] = ((j == 109) ? this.theNamedTypeBinder : this.theRefTypeBinder);
                    final byte[] array = this.parameterDatum[0][i];
                    final int length = array.length;
                    System.arraycopy(array, 0, oraclePreparedStatement.parameterDatum[0][n5] = new byte[length], 0, length);
                    oraclePreparedStatement.parameterOtype[0][n5] = this.parameterOtype[0][i];
                }
                else if (n3 > 0) {
                    oraclePreparedStatement.currentRowBinders[n5] = this.copiedByteBinder(j, this.bindBytes, bindByteSubRange, n3, this.bindIndicators[valueLengthsOffset]);
                }
                else {
                    if (n4 <= 0) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + j);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    oraclePreparedStatement.currentRowBinders[n5] = this.copiedCharBinder(j, this.bindChars, bindCharSubRange, n4, this.bindIndicators[valueLengthsOffset], this.getInoutIndicator(i));
                    oraclePreparedStatement.currentRowCharLens[n5] = n4;
                }
                bindByteSubRange += this.bindBufferCapacity * n3;
                bindCharSubRange += this.bindBufferCapacity * n4;
                indicatorsOffset += this.numberOfBindRowsAllocated;
                valueLengthsOffset += this.numberOfBindRowsAllocated;
                n2 += 10;
            }
        }
        return this.numberOfBindPositions;
    }
    
    Binder copiedNullBinder(final short n, final int n2) throws SQLException {
        return new CopiedNullBinder(n, n2);
    }
    
    Binder copiedByteBinder(final short n, final byte[] array, final int n2, final int n3, final short n4) throws SQLException {
        final byte[] array2 = new byte[n3];
        System.arraycopy(array, n2, array2, 0, n3);
        return new CopiedByteBinder(n, n3, array2, n4);
    }
    
    Binder copiedCharBinder(final short n, final char[] array, final int n2, final int n3, final short n4, final short n5) throws SQLException {
        final char[] array2 = new char[n3];
        System.arraycopy(array, n2, array2, 0, n3);
        return new CopiedCharBinder(n, array2, n4, n5);
    }
    
    @Override
    protected void hardClose() throws SQLException {
        super.hardClose();
        this.connection.cacheBuffer(this.bindBytes);
        this.bindBytes = null;
        this.connection.cacheBuffer(this.bindChars);
        this.bindChars = null;
        this.bindIndicators = null;
        if (!this.connection.isClosed()) {
            this.cleanAllTempLobs();
        }
        this.lastBoundBytes = null;
        this.lastBoundChars = null;
        this.clearParameters();
    }
    
    @Override
    protected void alwaysOnClose() throws SQLException {
        if (this.currentRank > 0) {
            if (this.m_batchStyle == 2) {
                this.clearBatch();
            }
            else {
                final int validRows = this.validRows;
                this.prematureBatchCount = this.sendBatch();
                this.validRows = validRows;
            }
        }
        super.alwaysOnClose();
    }
    
    @Override
    public void setDisableStmtCaching(final boolean b) {
        synchronized (this.connection) {
            if (b) {
                this.cacheState = 3;
            }
        }
    }
    
    @Override
    public void setFormOfUse(final int n, final short n2) {
        synchronized (this.connection) {
            final int n3 = n - 1;
            if (this.currentRowFormOfUse[n3] != n2) {
                this.currentRowFormOfUse[n3] = n2;
                if (this.currentRowBindAccessors != null) {
                    final Accessor accessor = this.currentRowBindAccessors[n3];
                    if (accessor != null) {
                        accessor.setFormOfUse(n2);
                    }
                }
                if (this.returnParamAccessors != null) {
                    final Accessor accessor2 = this.returnParamAccessors[n3];
                    if (accessor2 != null) {
                        accessor2.setFormOfUse(n2);
                    }
                }
            }
        }
    }
    
    @Override
    public void setURL(final int n, final URL url) throws SQLException {
        this.setURLInternal(n, url);
    }
    
    void setURLInternal(final int n, final URL url) throws SQLException {
        this.setStringInternal(n, url.toString());
    }
    
    @Override
    public ParameterMetaData getParameterMetaData() throws SQLException {
        return new OracleParameterMetaData(this.sqlObject.getParameterCount());
    }
    
    @Override
    public oracle.jdbc.OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2) throws SQLException {
        if (this.numberOfBindPositions <= 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.numReturnParams <= 0) {
            this.numReturnParams = this.sqlObject.getReturnParameterCount();
            if (this.numReturnParams <= 0) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        final int n3 = n - 1;
        if (n3 < this.numberOfBindPositions - this.numReturnParams || n > this.numberOfBindPositions) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        final int internalTypeForDmlReturning = this.getInternalTypeForDmlReturning(n2);
        short n4 = 0;
        if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[n3] != 0) {
            n4 = this.currentRowFormOfUse[n3];
        }
        this.registerReturnParameterInternal(n3, internalTypeForDmlReturning, n2, -1, n4, null);
        this.currentRowBinders[n3] = this.theReturnParamBinder;
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2, final int n3) throws SQLException {
        if (this.numberOfBindPositions <= 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int n4 = n - 1;
        if (n4 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (n2 != 1 && n2 != 12 && n2 != -1 && n2 != -2 && n2 != -3 && n2 != -4 && n2 != 12) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        if (n3 <= 0) {
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        final int internalTypeForDmlReturning = this.getInternalTypeForDmlReturning(n2);
        short n5 = 0;
        if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[n4] != 0) {
            n5 = this.currentRowFormOfUse[n4];
        }
        this.registerReturnParameterInternal(n4, internalTypeForDmlReturning, n2, n3, n5, null);
        this.currentRowBinders[n4] = this.theReturnParamBinder;
    }
    
    @Override
    public void registerReturnParameter(final int n, final int n2, final String s) throws SQLException {
        if (this.numberOfBindPositions <= 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int n3 = n - 1;
        if (n3 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final int internalTypeForDmlReturning = this.getInternalTypeForDmlReturning(n2);
        if (internalTypeForDmlReturning != 111 && internalTypeForDmlReturning != 109) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.registerReturnParameterInternal(n3, internalTypeForDmlReturning, n2, -1, (short)0, s);
        this.currentRowBinders[n3] = this.theReturnParamBinder;
    }
    
    @Override
    public ResultSet getReturnResultSet() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.returnParamAccessors == null || this.numReturnParams == 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 144);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.returnResultSet == null || this.numReturnParams == 0 || !this.isOpen) {
            this.returnResultSet = new OracleReturnResultSet(this);
        }
        return this.returnResultSet;
    }
    
    int getInternalTypeForDmlReturning(final int n) throws SQLException {
        int n2 = 0;
        switch (n) {
            case -7:
            case -6:
            case -5:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8: {
                n2 = 6;
                break;
            }
            case 100: {
                n2 = 100;
                break;
            }
            case 101: {
                n2 = 101;
                break;
            }
            case -15:
            case 1: {
                n2 = 96;
                break;
            }
            case -9:
            case 12: {
                n2 = 1;
                break;
            }
            case -16:
            case -1: {
                n2 = 8;
                break;
            }
            case 91:
            case 92: {
                n2 = 12;
                break;
            }
            case 93: {
                n2 = 180;
                break;
            }
            case -101: {
                n2 = 181;
                break;
            }
            case -102: {
                n2 = 231;
                break;
            }
            case -103: {
                n2 = 182;
                break;
            }
            case -104: {
                n2 = 183;
                break;
            }
            case -3:
            case -2: {
                n2 = 23;
                break;
            }
            case -4: {
                n2 = 24;
                break;
            }
            case -8: {
                n2 = 104;
                break;
            }
            case 2004: {
                n2 = 113;
                break;
            }
            case 2005:
            case 2011: {
                n2 = 112;
                break;
            }
            case -13: {
                n2 = 114;
                break;
            }
            case 2002:
            case 2003:
            case 2007:
            case 2008:
            case 2009: {
                n2 = 109;
                break;
            }
            case 2006: {
                n2 = 111;
                break;
            }
            case 70: {
                n2 = 1;
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return n2;
    }
    
    void registerReturnParamsForAutoKey() throws SQLException {
        final int[] returnTypes = this.autoKeyInfo.returnTypes;
        final short[] tableFormOfUses = this.autoKeyInfo.tableFormOfUses;
        final int[] columnIndexes = this.autoKeyInfo.columnIndexes;
        final int length = returnTypes.length;
        final int n = this.numberOfBindPositions - length;
        for (int i = 0; i < length; ++i) {
            final int n2 = n + i;
            this.currentRowBinders[n2] = this.theReturnParamBinder;
            short n3 = (short)(this.connection.defaultnchar ? 2 : 1);
            if (tableFormOfUses != null && columnIndexes != null && tableFormOfUses[columnIndexes[i] - 1] == 2) {
                n3 = 2;
                this.setFormOfUse(n2 + 1, n3);
            }
            this.checkTypeForAutoKey(returnTypes[i]);
            String s = null;
            if (returnTypes[i] == 111) {
                s = this.autoKeyInfo.tableTypeNames[columnIndexes[i] - 1];
            }
            this.registerReturnParameterInternal(n2, returnTypes[i], returnTypes[i], -1, n3, s);
        }
    }
    
    @Override
    void cleanOldTempLobs() {
        if (this.m_batchStyle != 1 || this.currentRank == this.batch - 1) {
            super.cleanOldTempLobs();
        }
    }
    
    @Override
    void resetOnExceptionDuringExecute() {
        super.resetOnExceptionDuringExecute();
        this.currentRank = 0;
        this.currentBatchNeedToPrepareBinds = true;
    }
    
    @Override
    void resetCurrentRowBinders() {
        final Binder[] currentRowBinders = this.currentRowBinders;
        if (this.binders != null && this.currentRowBinders != null && currentRowBinders != this.binders[0]) {
            this.currentRowBinders = this.binders[0];
            this.binders[this.numberOfBoundRows] = currentRowBinders;
        }
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream) throws SQLException {
        this.setAsciiStreamInternal(n, inputStream);
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.setAsciiStreamInternal(n, inputStream, n2);
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream) throws SQLException {
        this.setBinaryStreamInternal(n, inputStream);
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.setBinaryStreamInternal(n, inputStream, n2);
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream) throws SQLException {
        this.setBlobInternal(n, inputStream);
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream, final long n2) throws SQLException {
        if (n2 < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.setBlobInternal(n, inputStream, n2);
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader) throws SQLException {
        this.setCharacterStreamInternal(n, reader);
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        this.setCharacterStreamInternal(n, reader, n2);
    }
    
    @Override
    public void setClob(final int n, final Reader reader, final long n2) throws SQLException {
        if (n2 < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.setClobInternal(n, reader, n2);
    }
    
    @Override
    public void setClob(final int n, final Reader reader) throws SQLException {
        this.setClobInternal(n, reader);
    }
    
    @Override
    public void setRowId(final int n, final RowId rowId) throws SQLException {
        this.setRowIdInternal(n, rowId);
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader) throws SQLException {
        this.setNCharacterStreamInternal(n, reader);
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        this.setNCharacterStreamInternal(n, reader, n2);
    }
    
    @Override
    public void setNClob(final int n, final NClob nClob) throws SQLException {
        this.setNClobInternal(n, nClob);
    }
    
    @Override
    public void setNClob(final int n, final Reader reader, final long n2) throws SQLException {
        this.setNClobInternal(n, reader, n2);
    }
    
    @Override
    public void setNClob(final int n, final Reader reader) throws SQLException {
        this.setNClobInternal(n, reader);
    }
    
    @Override
    public void setSQLXML(final int n, final SQLXML sqlxml) throws SQLException {
        this.setSQLXMLInternal(n, sqlxml);
    }
    
    @Override
    public void setNString(final int n, final String s) throws SQLException {
        this.setNStringInternal(n, s);
    }
    
    void setAsciiStreamInternal(final int n, final InputStream inputStream) throws SQLException {
        this.setAsciiStreamInternal(n, inputStream, 0L, false);
    }
    
    void setAsciiStreamInternal(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.setAsciiStreamInternal(n, inputStream, n2, true);
    }
    
    void setBinaryStreamInternal(final int n, final InputStream inputStream) throws SQLException {
        this.setBinaryStreamInternal(n, inputStream, 0L, false);
    }
    
    void setBinaryStreamInternal(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.setBinaryStreamInternal(n, inputStream, n2, true);
    }
    
    void setBlobInternal(final int n, final InputStream inputStream, final long n2) throws SQLException {
        if (n - 1 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (inputStream == null) {
            this.setNullInternal(n, 2004);
        }
        else {
            this.setBinaryStreamContentsForBlobCritical(n, inputStream, n2, n2 != -1L);
        }
    }
    
    void setBlobInternal(final int n, final InputStream inputStream) throws SQLException {
        this.setBlobInternal(n, inputStream, -1L);
    }
    
    void setCharacterStreamInternal(final int n, final Reader reader) throws SQLException {
        this.setCharacterStreamInternal(n, reader, 0L, false);
    }
    
    void setCharacterStreamInternal(final int n, final Reader reader, final long n2) throws SQLException {
        this.setCharacterStreamInternal(n, reader, n2, true);
    }
    
    void setClobInternal(final int n, final Reader reader) throws SQLException {
        this.setClobInternal(n, reader, -1L);
    }
    
    void setClobInternal(final int n, final Reader reader, final long n2) throws SQLException {
        if (n - 1 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (reader == null) {
            this.setNullInternal(n, 2005);
        }
        else {
            this.setReaderContentsForClobCritical(n, reader, n2, n2 != -1L);
        }
    }
    
    void setNCharacterStreamInternal(final int n, final Reader reader) throws SQLException {
        this.setFormOfUse(n, (short)2);
        this.setCharacterStreamInternal(n, reader, 0L, false);
    }
    
    void setNCharacterStreamInternal(final int n, final Reader reader, final long n2) throws SQLException {
        this.setFormOfUse(n, (short)2);
        this.setCharacterStreamInternal(n, reader, n2);
    }
    
    void setNClobInternal(final int n, final NClob nClob) throws SQLException {
        this.setFormOfUse(n, (short)2);
        this.setClobInternal(n, nClob);
    }
    
    void setNClobInternal(final int n, final Reader reader) throws SQLException {
        this.setFormOfUse(n, (short)2);
        this.setClobInternal(n, reader);
    }
    
    void setNClobInternal(final int n, final Reader reader, final long n2) throws SQLException {
        this.setFormOfUse(n, (short)2);
        this.setClobInternal(n, reader, n2);
    }
    
    void setNStringInternal(final int n, final String s) throws SQLException {
        this.setFormOfUse(n, (short)2);
        this.setStringInternal(n, s);
    }
    
    void setRowIdInternal(final int n, final RowId rowId) throws SQLException {
        this.setROWIDInternal(n, (ROWID)rowId);
    }
    
    @Override
    public void setArrayAtName(final String s, final Array array) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setArray(i + 1, array);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBigDecimalAtName(final String s, final BigDecimal bigDecimal) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBigDecimal(i + 1, bigDecimal);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBlobAtName(final String s, final Blob blob) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBlob(i + 1, blob);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBooleanAtName(final String s, final boolean b) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b2 = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBoolean(i + 1, b);
                b2 = true;
            }
        }
        if (!b2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setByteAtName(final String s, final byte b) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b2 = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setByte(i + 1, b);
                b2 = true;
            }
        }
        if (!b2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBytesAtName(final String s, final byte[] array) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBytes(i + 1, array);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setClobAtName(final String s, final Clob clob) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setClob(i + 1, clob);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setDateAtName(final String s, final Date date) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setDate(i + 1, date);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setDateAtName(final String s, final Date date, final Calendar calendar) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setDate(i + 1, date, calendar);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setDoubleAtName(final String s, final double n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setDouble(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setFloatAtName(final String s, final float n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setFloat(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setIntAtName(final String s, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setInt(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setLongAtName(final String s, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setLong(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setNClobAtName(final String s, final NClob nClob) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setNClob(i + 1, nClob);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setNStringAtName(final String s, final String s2) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setNString(i + 1, s2);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setObject(i + 1, o);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setObjectAtName(final String s, final Object o, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setObject(i + 1, o, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setRefAtName(final String s, final Ref ref) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setRef(i + 1, ref);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setRowIdAtName(final String s, final RowId rowId) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setRowId(i + 1, rowId);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setShortAtName(final String s, final short n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setShort(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setSQLXMLAtName(final String s, final SQLXML sqlxml) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setSQLXML(i + 1, sqlxml);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setStringAtName(final String s, final String s2) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setString(i + 1, s2);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTimeAtName(final String s, final Time time) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTime(i + 1, time);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTimeAtName(final String s, final Time time, final Calendar calendar) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTime(i + 1, time, calendar);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTimestampAtName(final String s, final Timestamp timestamp) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTimestamp(i + 1, timestamp);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTimestampAtName(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTimestamp(i + 1, timestamp, calendar);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setURLAtName(final String s, final URL url) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setURL(i + 1, url);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setARRAYAtName(final String s, final ARRAY array) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setARRAY(i + 1, array);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBFILEAtName(final String s, final BFILE bfile) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBFILE(i + 1, bfile);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBfileAtName(final String s, final BFILE bfile) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBfile(i + 1, bfile);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBinaryFloatAtName(final String s, final float n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBinaryFloat(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBinaryFloatAtName(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBinaryFloat(i + 1, binary_FLOAT);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBinaryDoubleAtName(final String s, final double n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBinaryDouble(i + 1, n);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBinaryDoubleAtName(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBinaryDouble(i + 1, binary_DOUBLE);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBLOBAtName(final String s, final BLOB blob) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setBLOB(i + 1, blob);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setCHARAtName(final String s, final CHAR char1) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setCHAR(i + 1, char1);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setCLOBAtName(final String s, final CLOB clob) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setCLOB(i + 1, clob);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setCursorAtName(final String s, final ResultSet set) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setCursor(i + 1, set);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setCustomDatumAtName(final String s, final CustomDatum customDatum) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setCustomDatum(i + 1, customDatum);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setDATEAtName(final String s, final DATE date) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setDATE(i + 1, date);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setFixedCHARAtName(final String s, final String s2) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setFixedCHAR(i + 1, s2);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setINTERVALDSAtName(final String s, final INTERVALDS intervalds) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setINTERVALDS(i + 1, intervalds);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setINTERVALYMAtName(final String s, final INTERVALYM intervalym) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setINTERVALYM(i + 1, intervalym);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setNUMBERAtName(final String s, final NUMBER number) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setNUMBER(i + 1, number);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setOPAQUEAtName(final String s, final OPAQUE opaque) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setOPAQUE(i + 1, opaque);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setOracleObjectAtName(final String s, final Datum datum) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setOracleObject(i + 1, datum);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setORADataAtName(final String s, final ORAData oraData) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setORAData(i + 1, oraData);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setRAWAtName(final String s, final RAW raw) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setRAW(i + 1, raw);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setREFAtName(final String s, final REF ref) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setREF(i + 1, ref);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setRefTypeAtName(final String s, final REF ref) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setRefType(i + 1, ref);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setROWIDAtName(final String s, final ROWID rowid) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setROWID(i + 1, rowid);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setSTRUCTAtName(final String s, final STRUCT struct) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setSTRUCT(i + 1, struct);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTIMESTAMPLTZAtName(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTIMESTAMPLTZ(i + 1, timestampltz);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTIMESTAMPTZAtName(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTIMESTAMPTZ(i + 1, timestamptz);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTIMESTAMPAtName(final String s, final TIMESTAMP timestamp) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        boolean b = false;
        for (int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length), i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                this.setTIMESTAMP(i + 1, timestamp);
                b = true;
            }
        }
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setBlobAtName(final String s, final InputStream inputStream) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setBlob(i + 1, inputStream);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setBlobAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setBlob(i + 1, inputStream, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setClobAtName(final String s, final Reader reader) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setClob(i + 1, reader);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setClobAtName(final String s, final Reader reader, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setClob(i + 1, reader, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setNClobAtName(final String s, final Reader reader) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setNClob(i + 1, reader);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setNClobAtName(final String s, final Reader reader, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setNClob(i + 1, reader, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setAsciiStream(i + 1, inputStream);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setAsciiStream(i + 1, inputStream, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setAsciiStreamAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setAsciiStream(i + 1, inputStream, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setBinaryStream(i + 1, inputStream);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setBinaryStream(i + 1, inputStream, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setBinaryStreamAtName(final String s, final InputStream inputStream, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setBinaryStream(i + 1, inputStream, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setCharacterStream(i + 1, reader);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setCharacterStream(i + 1, reader, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setCharacterStreamAtName(final String s, final Reader reader, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setCharacterStream(i + 1, reader, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setNCharacterStreamAtName(final String s, final Reader reader) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setNCharacterStream(i + 1, reader);
                n = 0;
            }
        }
        if (n != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setNCharacterStreamAtName(final String s, final Reader reader, final long n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setNCharacterStream(i + 1, reader, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void setUnicodeStreamAtName(final String s, final InputStream inputStream, final int n) throws SQLException {
        final String intern = s.intern();
        final String[] parameterList = this.sqlObject.getParameterList();
        final int min = Math.min(this.sqlObject.getParameterCount(), parameterList.length);
        int n2 = 1;
        for (int i = 0; i < min; ++i) {
            if (parameterList[i] == intern) {
                if (n2 == 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 135);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.setUnicodeStream(i + 1, inputStream, n);
                n2 = 0;
            }
        }
        if (n2 != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 147, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    static {
        OraclePreparedStatement.theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
        OraclePreparedStatement.theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
        OraclePreparedStatement.theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
        OraclePreparedStatement.theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
        OraclePreparedStatement.theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
        OraclePreparedStatement.theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
        OraclePreparedStatement.theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
        OraclePreparedStatement.theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
        OraclePreparedStatement.theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
        OraclePreparedStatement.theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
        OraclePreparedStatement.theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
        OraclePreparedStatement.theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
        OraclePreparedStatement.theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
        OraclePreparedStatement.theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
        OraclePreparedStatement.theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
        OraclePreparedStatement.theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
        OraclePreparedStatement.theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
        OraclePreparedStatement.theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
        OraclePreparedStatement.theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
        OraclePreparedStatement.theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
        OraclePreparedStatement.theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
        OraclePreparedStatement.theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
        OraclePreparedStatement.theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
        OraclePreparedStatement.theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
        OraclePreparedStatement.theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
        OraclePreparedStatement.theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
        OraclePreparedStatement.theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
        OraclePreparedStatement.theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
        OraclePreparedStatement.theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
        OraclePreparedStatement.theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
        OraclePreparedStatement.theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
        OraclePreparedStatement.theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
        OraclePreparedStatement.theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
        OraclePreparedStatement.theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
        OraclePreparedStatement.theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
        OraclePreparedStatement.theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
        OraclePreparedStatement.theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
        OraclePreparedStatement.theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
        OraclePreparedStatement.theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
        OraclePreparedStatement.theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
        OraclePreparedStatement.theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
        OraclePreparedStatement.theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
        OraclePreparedStatement.theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
        OraclePreparedStatement.theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
        OraclePreparedStatement.theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
        OraclePreparedStatement.theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
        OraclePreparedStatement.theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
        OraclePreparedStatement.theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
        OraclePreparedStatement.theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
        OraclePreparedStatement.theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
        OraclePreparedStatement.theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
        OraclePreparedStatement.theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
        OraclePreparedStatement.theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
        OraclePreparedStatement.theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
        OraclePreparedStatement.theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
        OraclePreparedStatement.theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
        OraclePreparedStatement.theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
        OraclePreparedStatement.theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
        OraclePreparedStatement.theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
        OraclePreparedStatement.theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
        OraclePreparedStatement.theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
        OraclePreparedStatement.theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
        OraclePreparedStatement.theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
        OraclePreparedStatement.theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
        OraclePreparedStatement.theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
        OraclePreparedStatement.theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
        OraclePreparedStatement.theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
        OraclePreparedStatement.theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
        OraclePreparedStatement.theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
        OraclePreparedStatement.theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
        OraclePreparedStatement.theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
        OraclePreparedStatement.theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
        OraclePreparedStatement.theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
        OraclePreparedStatement.theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
        OraclePreparedStatement.theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
        OraclePreparedStatement.theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
        OraclePreparedStatement.theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
        OraclePreparedStatement.theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
        OraclePreparedStatement.theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
        OraclePreparedStatement.theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
        OraclePreparedStatement.theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
        OraclePreparedStatement.theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
        OraclePreparedStatement.theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
        OraclePreparedStatement.theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
        OraclePreparedStatement.theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
        OraclePreparedStatement.theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
        OraclePreparedStatement.theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
        OraclePreparedStatement.theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
        OraclePreparedStatement.theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
        OraclePreparedStatement.theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
        OraclePreparedStatement.theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
        OraclePreparedStatement.theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
        OraclePreparedStatement.theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
        OraclePreparedStatement.theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
        OraclePreparedStatement.theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
        UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
        UTC_US_CALENDAR = Calendar.getInstance(OraclePreparedStatement.UTC_TIME_ZONE, Locale.US);
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    class PushedBatch
    {
        int[] currentBatchCharLens;
        int[] lastBoundCharLens;
        Accessor[] currentBatchBindAccessors;
        boolean lastBoundNeeded;
        boolean need_to_parse;
        boolean current_batch_need_to_prepare_binds;
        int first_row_in_batch;
        int number_of_rows_to_be_bound;
        PushedBatch next;
    }
}
