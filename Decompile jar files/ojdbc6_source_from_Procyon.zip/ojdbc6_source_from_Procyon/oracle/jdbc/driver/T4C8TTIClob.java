// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.NCLOB;
import oracle.sql.CLOB;
import oracle.jdbc.OracleConnection;
import oracle.sql.Datum;
import java.sql.Connection;
import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.CharacterSet;

final class T4C8TTIClob extends T4C8TTILob
{
    int[] nBytes;
    byte[] myBufferForReuse;
    boolean varChar;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8TTIClob(final T4CConnection t4CConnection) {
        super(t4CConnection);
        this.myBufferForReuse = null;
        this.varChar = false;
        this.nBytes = new int[1];
    }
    
    long read(final byte[] sourceLobLocator, final long sourceOffset, final long lobamt, final boolean b, final char[] array, final int n) throws SQLException, IOException {
        this.initializeLobdef();
        if ((sourceLobLocator[6] & 0x80) == 0x80) {
            this.varWidthChar = true;
        }
        int n2;
        if (this.varWidthChar) {
            n2 = (int)lobamt * 2;
        }
        else {
            n2 = (int)lobamt * 3;
        }
        byte[] myBufferForReuse;
        if (this.myBufferForReuse == null || n2 > this.myBufferForReuse.length) {
            myBufferForReuse = new byte[n2];
        }
        else {
            myBufferForReuse = this.myBufferForReuse;
        }
        if ((sourceLobLocator[7] & 0x40) > 0) {
            this.littleEndianClob = true;
        }
        this.lobops = 2L;
        this.sourceLobLocator = sourceLobLocator;
        this.sourceOffset = sourceOffset;
        this.lobamt = lobamt;
        this.sendLobamt = true;
        this.outBuffer = myBufferForReuse;
        this.doRPC();
        final long lobamt2 = this.lobamt;
        if (this.varWidthChar) {
            if (this.connection.versionNumber < 10101) {
                final DBConversion conv = this.meg.conv;
                DBConversion.ucs2BytesToJavaChars(this.outBuffer, (int)this.lobBytesRead, array);
            }
            else if (this.littleEndianClob) {
                CharacterSet.convertAL16UTF16LEBytesToJavaChars(this.outBuffer, 0, array, n, (int)this.lobBytesRead, true);
            }
            else {
                CharacterSet.convertAL16UTF16BytesToJavaChars(this.outBuffer, 0, array, n, (int)this.lobBytesRead, true);
            }
        }
        else if (!b) {
            this.nBytes[0] = (int)this.lobBytesRead;
            this.meg.conv.CHARBytesToJavaChars(this.outBuffer, 0, array, n, this.nBytes, array.length);
        }
        else {
            this.nBytes[0] = (int)this.lobBytesRead;
            this.meg.conv.NCHARBytesToJavaChars(this.outBuffer, 0, array, n, this.nBytes, array.length);
        }
        return lobamt2;
    }
    
    long write(final byte[] sourceLobLocator, final long sourceOffset, final boolean b, final char[] array, final long n, final long n2) throws SQLException, IOException {
        if ((sourceLobLocator[6] & 0x80) == 0x80) {
            this.varChar = true;
        }
        else {
            this.varChar = false;
        }
        if ((sourceLobLocator[7] & 0x40) == 0x40) {
            this.littleEndianClob = true;
        }
        long inBufferNumBytes = 0L;
        byte[] inBuffer;
        if (this.varChar) {
            inBuffer = new byte[(int)n2 * 2];
            if (this.connection.versionNumber < 10101) {
                final DBConversion conv = this.meg.conv;
                DBConversion.javaCharsToUcs2Bytes(array, (int)n, inBuffer, 0, (int)n2);
            }
            else if (this.littleEndianClob) {
                CharacterSet.convertJavaCharsToAL16UTF16LEBytes(array, (int)n, inBuffer, 0, (int)n2);
            }
            else {
                CharacterSet.convertJavaCharsToAL16UTF16Bytes(array, (int)n, inBuffer, 0, (int)n2);
            }
        }
        else {
            inBuffer = new byte[(int)n2 * 3];
            if (!b) {
                inBufferNumBytes = this.meg.conv.javaCharsToCHARBytes(array, (int)n, inBuffer, 0, (int)n2);
            }
            else {
                inBufferNumBytes = this.meg.conv.javaCharsToNCHARBytes(array, (int)n, inBuffer, 0, (int)n2);
            }
        }
        this.initializeLobdef();
        this.lobops = 64L;
        this.sourceLobLocator = sourceLobLocator;
        this.sourceOffset = sourceOffset;
        this.lobamt = n2;
        this.sendLobamt = true;
        this.inBuffer = inBuffer;
        this.inBufferOffset = 0L;
        if (this.varChar) {
            if (this.connection.versionNumber < 10101) {
                this.inBufferNumBytes = n2;
            }
            else {
                this.inBufferNumBytes = n2 * 2L;
            }
        }
        else {
            this.inBufferNumBytes = inBufferNumBytes;
        }
        this.doRPC();
        return this.lobamt;
    }
    
    @Override
    Datum createTemporaryLob(final Connection connection, final boolean b, final int n) throws SQLException, IOException {
        return this.createTemporaryLob(connection, b, n, (short)1);
    }
    
    Datum createTemporaryLob(final Connection connection, final boolean b, final int destinationLength, final short n) throws SQLException, IOException {
        if (destinationLength == 12) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 158);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        Datum datum = null;
        this.initializeLobdef();
        this.lobops = 272L;
        (this.sourceLobLocator = new byte[86])[1] = 84;
        this.lobamt = 10L;
        this.sendLobamt = true;
        if (n == 1) {
            this.sourceOffset = 1L;
        }
        else {
            this.sourceOffset = 2L;
        }
        this.destinationOffset = 112L;
        this.destinationLength = destinationLength;
        this.nullO2U = true;
        this.characterSet = ((n == 2) ? this.meg.conv.getNCharSetId() : this.meg.conv.getServerCharSetId());
        if (this.connection.versionNumber >= 9000) {
            (this.lobscn = new int[1])[0] = (b ? 1 : 0);
            this.lobscnl = 1;
        }
        this.doRPC();
        if (this.sourceLobLocator != null) {
            if (n == 1) {
                datum = new CLOB((OracleConnection)connection, this.sourceLobLocator);
            }
            else {
                datum = new NCLOB((OracleConnection)connection, this.sourceLobLocator);
            }
        }
        return datum;
    }
    
    @Override
    boolean open(final byte[] array, final int n) throws SQLException, IOException {
        int n2 = 2;
        if (n == 0) {
            n2 = 1;
        }
        return this._open(array, n2, 32768);
    }
    
    @Override
    boolean close(final byte[] array) throws SQLException, IOException {
        return this._close(array, 65536);
    }
    
    @Override
    boolean isOpen(final byte[] array) throws SQLException, IOException {
        return this._isOpen(array, 69632);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
