// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.nio.ShortBuffer;
import java.nio.CharBuffer;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.io.IOException;
import oracle.jdbc.oracore.OracleType;
import java.sql.Connection;
import oracle.jdbc.oracore.OracleTypeADT;
import java.sql.SQLException;

class T2CPreparedStatement extends OraclePreparedStatement
{
    T2CConnection connection;
    int userResultSetType;
    int userResultSetConcur;
    static int T2C_EXTEND_BUFFER;
    long[] t2cOutput;
    static final int T2C_OUTPUT_USE_NIO = 5;
    static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6;
    int extractedCharOffset;
    int extractedByteOffset;
    static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0;
    static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1;
    static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2;
    static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3;
    static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4;
    static int PREAMBLE_PER_POSITION;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T2CPreparedStatement(final T2CConnection connection, final String s, final int n, final int n2, final int userResultSetType, final int userResultSetConcur) throws SQLException {
        super(connection, s, n, n2, userResultSetType, userResultSetConcur);
        this.connection = null;
        this.userResultSetType = -1;
        this.userResultSetConcur = -1;
        this.t2cOutput = new long[10];
        this.userResultSetType = userResultSetType;
        this.userResultSetConcur = userResultSetConcur;
        this.connection = connection;
    }
    
    String bytes2String(final byte[] array, final int n, final int n2) throws SQLException {
        final byte[] array2 = new byte[n2];
        System.arraycopy(array, n, array2, 0, n2);
        return this.connection.conversion.CharBytesToString(array2, n2);
    }
    
    void processDescribeData() throws SQLException {
        this.described = true;
        this.describedWithNames = true;
        if (this.accessors == null || this.numberOfDefinePositions > this.accessors.length) {
            this.accessors = new Accessor[this.numberOfDefinePositions];
        }
        int queryMetaData1Offset = this.connection.queryMetaData1Offset;
        int queryMetaData2Offset = this.connection.queryMetaData2Offset;
        final short[] queryMetaData1 = this.connection.queryMetaData1;
        final byte[] queryMetaData2 = this.connection.queryMetaData2;
        for (int i = 0; i < this.numberOfDefinePositions; ++i, queryMetaData1Offset += 13) {
            final short[] array = queryMetaData1;
            final int n = queryMetaData1Offset;
            final T2CConnection connection = this.connection;
            final short j = array[n + 0];
            final short[] array2 = queryMetaData1;
            final int n2 = queryMetaData1Offset;
            final T2CConnection connection2 = this.connection;
            final short n3 = array2[n2 + 1];
            final short[] array3 = queryMetaData1;
            final int n4 = queryMetaData1Offset;
            final T2CConnection connection3 = this.connection;
            final short n5 = array3[n4 + 11];
            final short[] array4 = queryMetaData1;
            final int n6 = queryMetaData1Offset;
            final T2CConnection connection4 = this.connection;
            final boolean b = array4[n6 + 2] != 0;
            final short[] array5 = queryMetaData1;
            final int n7 = queryMetaData1Offset;
            final T2CConnection connection5 = this.connection;
            final short n8 = array5[n7 + 3];
            final short[] array6 = queryMetaData1;
            final int n9 = queryMetaData1Offset;
            final T2CConnection connection6 = this.connection;
            final short n10 = array6[n9 + 4];
            final int n11 = 0;
            final int n12 = 0;
            final int n13 = 0;
            final short[] array7 = queryMetaData1;
            final int n14 = queryMetaData1Offset;
            final T2CConnection connection7 = this.connection;
            final short n15 = array7[n14 + 5];
            final short[] array8 = queryMetaData1;
            final int n16 = queryMetaData1Offset;
            final T2CConnection connection8 = this.connection;
            final short n17 = array8[n16 + 6];
            final String bytes2String = this.bytes2String(queryMetaData2, queryMetaData2Offset, n17);
            final short[] array9 = queryMetaData1;
            final int n18 = queryMetaData1Offset;
            final T2CConnection connection9 = this.connection;
            final short n19 = array9[n18 + 12];
            String bytes2String2 = null;
            OracleType oracleType = null;
            queryMetaData2Offset += n17;
            if (n19 > 0) {
                bytes2String2 = this.bytes2String(queryMetaData2, queryMetaData2Offset, n19);
                queryMetaData2Offset += n19;
                final OracleTypeADT oracleTypeADT;
                oracleType = (oracleTypeADT = new OracleTypeADT(bytes2String2, (Connection)this.connection));
                final short[] array10 = queryMetaData1;
                final int n20 = queryMetaData1Offset;
                final T2CConnection connection10 = this.connection;
                final long n21 = ((long)array10[n20 + 7] & 0xFFFFL) << 48;
                final short[] array11 = queryMetaData1;
                final int n22 = queryMetaData1Offset;
                final T2CConnection connection11 = this.connection;
                final long n23 = n21 | ((long)array11[n22 + 8] & 0xFFFFL) << 32;
                final short[] array12 = queryMetaData1;
                final int n24 = queryMetaData1Offset;
                final T2CConnection connection12 = this.connection;
                final long n25 = n23 | ((long)array12[n24 + 9] & 0xFFFFL) << 16;
                final short[] array13 = queryMetaData1;
                final int n26 = queryMetaData1Offset;
                final T2CConnection connection13 = this.connection;
                oracleTypeADT.tdoCState = (n25 | ((long)array13[n26 + 10] & 0xFFFFL));
            }
            Accessor accessor = this.accessors[i];
            if (accessor != null && !accessor.useForDescribeIfPossible(j, n3, b, n11, n8, n10, n12, n13, n15, bytes2String2)) {
                accessor = null;
            }
            if (accessor == null) {
                switch (j) {
                    case 1: {
                        accessor = new VarcharAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        if (n5 > 0) {
                            accessor.setDisplaySize(n5);
                            break;
                        }
                        break;
                    }
                    case 96: {
                        accessor = new CharAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        if (n5 > 0) {
                            accessor.setDisplaySize(n5);
                            break;
                        }
                        break;
                    }
                    case 2: {
                        accessor = new NumberAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 23: {
                        accessor = new RawAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 100: {
                        accessor = new BinaryFloatAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 101: {
                        accessor = new BinaryDoubleAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 8: {
                        accessor = new LongAccessor(this, i + 1, n3, b, n11, n8, n10, n12, n13, n15);
                        this.rowPrefetch = 1;
                        break;
                    }
                    case 24: {
                        accessor = new LongRawAccessor(this, i + 1, n3, b, n11, n8, n10, n12, n13, n15);
                        this.rowPrefetch = 1;
                        break;
                    }
                    case 104: {
                        accessor = new RowidAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 102:
                    case 116: {
                        accessor = new T2CResultSetAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 12: {
                        accessor = new DateAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 180: {
                        accessor = new TimestampAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 181: {
                        accessor = new TimestamptzAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 231: {
                        accessor = new TimestampltzAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 182: {
                        accessor = new IntervalymAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 183: {
                        accessor = new IntervaldsAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 112: {
                        accessor = new ClobAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 113: {
                        accessor = new BlobAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 114: {
                        accessor = new BfileAccessor(this, n3, b, n11, n8, n10, n12, n13, n15);
                        break;
                    }
                    case 109: {
                        accessor = new NamedTypeAccessor(this, n3, b, n11, n8, n10, n12, n13, n15, bytes2String2, oracleType);
                        break;
                    }
                    case 111: {
                        accessor = new RefTypeAccessor(this, n3, b, n11, n8, n10, n12, n13, n15, bytes2String2, oracleType);
                        break;
                    }
                    default: {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Unknown or unimplemented accessor type: " + j);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                }
                this.accessors[i] = accessor;
            }
            else if (oracleType != null) {
                accessor.initMetadata();
            }
            accessor.columnName = bytes2String;
        }
    }
    
    @Override
    void executeForDescribe() throws SQLException {
        this.t2cOutput[0] = 0L;
        this.t2cOutput[2] = 0L;
        this.lobPrefetchMetaData = null;
        final boolean b = !this.described;
        boolean b2 = false;
        boolean b3;
        do {
            b3 = false;
            if (this.connection.endToEndAnyChanged) {
                this.pushEndToEndValues();
                this.connection.endToEndAnyChanged = false;
            }
            final byte[] sqlBytes = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
            int t2cParseExecuteDescribe;
            try {
                t2cParseExecuteDescribe = T2CStatement.t2cParseExecuteDescribe(this, this.c_state, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, false, this.needToParse, b, b2, sqlBytes, sqlBytes.length, this.sqlKind, this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, this.ibtBindIndicators, this.ibtBindIndicatorOffset, this.ibtBindIndicatorSize, this.ibtBindBytes, this.ibtBindChars, this.ibtBindByteOffset, this.ibtBindCharOffset, this.returnParamMeta, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, this.preparedAllBinds, this.preparedCharBinds, this.accessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.connection.plsqlCompilerWarnings);
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 266);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.validRows = (int)this.t2cOutput[1];
            if (t2cParseExecuteDescribe == -1 || t2cParseExecuteDescribe == -4) {
                this.connection.checkError(t2cParseExecuteDescribe);
            }
            else if (t2cParseExecuteDescribe == T2CPreparedStatement.T2C_EXTEND_BUFFER) {
                t2cParseExecuteDescribe = this.connection.queryMetaData1Size * 2;
            }
            if (this.t2cOutput[3] != 0L) {
                this.foundPlsqlCompilerWarning();
            }
            else if (this.t2cOutput[2] != 0L) {
                this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
            }
            this.connection.endToEndECIDSequenceNumber = (short)this.t2cOutput[4];
            this.needToParse = false;
            b2 = true;
            if (this.sqlKind == 1) {
                this.numberOfDefinePositions = t2cParseExecuteDescribe;
                if (this.numberOfDefinePositions <= this.connection.queryMetaData1Size) {
                    continue;
                }
                b3 = true;
                b2 = true;
                this.connection.reallocateQueryMetaData(this.numberOfDefinePositions, this.numberOfDefinePositions * 8);
            }
            else {
                this.numberOfDefinePositions = 0;
                this.validRows = t2cParseExecuteDescribe;
            }
        } while (b3);
        this.processDescribeData();
    }
    
    void pushEndToEndValues() throws SQLException {
        final T2CConnection connection = this.connection;
        byte[] stringToDriverCharBytes = new byte[0];
        byte[] stringToDriverCharBytes2 = new byte[0];
        byte[] stringToDriverCharBytes3 = new byte[0];
        byte[] stringToDriverCharBytes4 = new byte[0];
        if (connection.endToEndValues != null) {
            if (connection.endToEndHasChanged[0]) {
                final String s = connection.endToEndValues[0];
                if (s != null) {
                    stringToDriverCharBytes = DBConversion.stringToDriverCharBytes(s, connection.m_clientCharacterSet);
                }
                connection.endToEndHasChanged[0] = false;
            }
            if (connection.endToEndHasChanged[1]) {
                final String s2 = connection.endToEndValues[1];
                if (s2 != null) {
                    stringToDriverCharBytes2 = DBConversion.stringToDriverCharBytes(s2, connection.m_clientCharacterSet);
                }
                connection.endToEndHasChanged[1] = false;
            }
            if (connection.endToEndHasChanged[2]) {
                final String s3 = connection.endToEndValues[2];
                if (s3 != null) {
                    stringToDriverCharBytes3 = DBConversion.stringToDriverCharBytes(s3, connection.m_clientCharacterSet);
                }
                connection.endToEndHasChanged[2] = false;
            }
            if (connection.endToEndHasChanged[3]) {
                final String s4 = connection.endToEndValues[3];
                if (s4 != null) {
                    stringToDriverCharBytes4 = DBConversion.stringToDriverCharBytes(s4, connection.m_clientCharacterSet);
                }
                connection.endToEndHasChanged[3] = false;
            }
            T2CStatement.t2cEndToEndUpdate(this.c_state, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, stringToDriverCharBytes3, stringToDriverCharBytes3.length, stringToDriverCharBytes4, stringToDriverCharBytes4.length, connection.endToEndECIDSequenceNumber);
        }
    }
    
    @Override
    void executeForRows(final boolean b) throws SQLException {
        if (this.connection.endToEndAnyChanged) {
            this.pushEndToEndValues();
            this.connection.endToEndAnyChanged = false;
        }
        if (!b) {
            if (this.numberOfDefinePositions > 0) {
                this.doDefineExecuteFetch();
            }
            else {
                this.executeForDescribe();
            }
        }
        else if (this.numberOfDefinePositions > 0) {
            this.doDefineFetch();
        }
        this.needToPrepareDefineBuffer = false;
    }
    
    void setupForDefine() throws SQLException {
        if (this.numberOfDefinePositions > this.connection.queryMetaData1Size) {
            final int n = this.numberOfDefinePositions / 100 + 1;
            this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * n, this.connection.queryMetaData2Size * n * 8);
        }
        final short[] queryMetaData1 = this.connection.queryMetaData1;
        for (int queryMetaData1Offset = this.connection.queryMetaData1Offset, i = 0; i < this.numberOfDefinePositions; ++i, queryMetaData1Offset += 13) {
            final Accessor accessor = this.accessors[i];
            if (accessor == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final short[] array = queryMetaData1;
            final int n2 = queryMetaData1Offset;
            final T2CConnection connection = this.connection;
            array[n2 + 0] = (short)accessor.defineType;
            final short[] array2 = queryMetaData1;
            final int n3 = queryMetaData1Offset;
            final T2CConnection connection2 = this.connection;
            array2[n3 + 11] = (short)accessor.charLength;
            final short[] array3 = queryMetaData1;
            final int n4 = queryMetaData1Offset;
            final T2CConnection connection3 = this.connection;
            array3[n4 + 1] = (short)accessor.byteLength;
            final short[] array4 = queryMetaData1;
            final int n5 = queryMetaData1Offset;
            final T2CConnection connection4 = this.connection;
            array4[n5 + 5] = accessor.formOfUse;
            if (accessor.internalOtype != null) {
                final long tdoCState = ((OracleTypeADT)accessor.internalOtype).getTdoCState();
                final short[] array5 = queryMetaData1;
                final int n6 = queryMetaData1Offset;
                final T2CConnection connection5 = this.connection;
                array5[n6 + 7] = (short)((tdoCState & 0xFFFF000000000000L) >> 48);
                final short[] array6 = queryMetaData1;
                final int n7 = queryMetaData1Offset;
                final T2CConnection connection6 = this.connection;
                array6[n7 + 8] = (short)((tdoCState & 0xFFFF00000000L) >> 32);
                final short[] array7 = queryMetaData1;
                final int n8 = queryMetaData1Offset;
                final T2CConnection connection7 = this.connection;
                array7[n8 + 9] = (short)((tdoCState & 0xFFFF0000L) >> 16);
                final short[] array8 = queryMetaData1;
                final int n9 = queryMetaData1Offset;
                final T2CConnection connection8 = this.connection;
                array8[n9 + 10] = (short)(tdoCState & 0xFFFFL);
            }
            switch (accessor.internalType) {
                case 112:
                case 113: {
                    if (accessor.lobPrefetchSizeForThisColumn == -1) {
                        accessor.lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
                    }
                    queryMetaData1[queryMetaData1Offset + 7] = (short)accessor.lobPrefetchSizeForThisColumn;
                    break;
                }
            }
        }
    }
    
    Object[] getLobPrefetchMetaData() {
        Object[] array = null;
        Object o = null;
        int n = 0;
        int n2 = 0;
        if (this.accessors != null) {
            for (int i = 0; i < this.numberOfDefinePositions; ++i) {
                switch (this.accessors[i].internalType) {
                    case 8:
                    case 24: {
                        n2 = i;
                        break;
                    }
                    case 112:
                    case 113: {
                        if (o == null) {
                            o = new int[this.accessors.length];
                        }
                        if (this.accessors[i].lobPrefetchSizeForThisColumn != -1) {
                            ++n;
                            o[i] = this.accessors[i].lobPrefetchSizeForThisColumn;
                            break;
                        }
                        o[i] = -1;
                        break;
                    }
                }
            }
        }
        if (n > 0) {
            if (array == null) {
                array = new Object[] { null, new long[this.rowPrefetch * n], new byte[this.accessors.length], new int[this.accessors.length], new Object[this.rowPrefetch * n] };
            }
            for (int j = 0; j < n2; ++j) {
                switch (this.accessors[j].internalType) {
                    case 112:
                    case 113: {
                        o[j] = (this.accessors[j].lobPrefetchSizeForThisColumn = -1);
                        break;
                    }
                }
            }
            array[0] = o;
        }
        return array;
    }
    
    @Override
    void processLobPrefetchMetaData(final Object[] array) {
        int n = 0;
        final int n2 = (this.validRows == -2) ? 1 : this.validRows;
        final byte[] array2 = (byte[])array[2];
        final int[] array3 = (int[])array[3];
        final long[] array4 = (long[])array[1];
        final Object[] array5 = (Object[])array[4];
        final int[] array6 = (int[])array[0];
        if (this.accessors != null) {
            for (int i = 0; i < this.numberOfDefinePositions; ++i) {
                switch (this.accessors[i].internalType) {
                    case 112:
                    case 113: {
                        if (this.accessors[i].lobPrefetchSizeForThisColumn >= 0) {
                            final Accessor accessor = this.accessors[i];
                            if (accessor.prefetchedLobDataL == null || accessor.prefetchedLobDataL.length < this.rowPrefetch) {
                                if (accessor.internalType == 112) {
                                    accessor.prefetchedLobCharData = new char[this.rowPrefetch][];
                                }
                                else {
                                    accessor.prefetchedLobData = new byte[this.rowPrefetch][];
                                }
                                accessor.prefetchedLobChunkSize = new int[this.rowPrefetch];
                                accessor.prefetchedClobFormOfUse = new byte[this.rowPrefetch];
                                accessor.prefetchedLobDataL = new int[this.rowPrefetch];
                                accessor.prefetchedLobSize = new long[this.rowPrefetch];
                            }
                            final int n3 = n2 * n;
                            for (int j = 0; j < n2; ++j) {
                                accessor.prefetchedLobChunkSize[j] = array3[i];
                                accessor.prefetchedClobFormOfUse[j] = array2[i];
                                accessor.prefetchedLobSize[j] = array4[n3 + j];
                                accessor.prefetchedLobDataL[j] = 0;
                                if (array6[i] > 0 && array4[n3 + j] > 0L) {
                                    if (accessor.internalType == 112) {
                                        accessor.prefetchedLobCharData[j] = (char[])array5[n3 + j];
                                        if (accessor.prefetchedLobCharData[j] != null) {
                                            accessor.prefetchedLobDataL[j] = accessor.prefetchedLobCharData[j].length;
                                        }
                                    }
                                    else {
                                        accessor.prefetchedLobData[j] = (byte[])array5[n3 + j];
                                        if (accessor.prefetchedLobData[j] != null) {
                                            accessor.prefetchedLobDataL[j] = accessor.prefetchedLobData[j].length;
                                        }
                                    }
                                }
                            }
                            ++n;
                            break;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    void doDefineFetch() throws SQLException {
        if (!this.needToPrepareDefineBuffer) {
            throw new Error("doDefineFetch called when needToPrepareDefineBuffer=false " + this.sqlObject.getSql(this.processEscapes, this.convertNcharLiterals));
        }
        this.setupForDefine();
        this.t2cOutput[2] = 0L;
        this.t2cOutput[5] = (this.connection.useNio ? 1 : 0);
        this.t2cOutput[6] = this.defaultLobPrefetchSize;
        if (this.connection.useNio) {
            this.resetNioAttributesBeforeFetch();
            this.allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
        }
        if (this.lobPrefetchMetaData == null) {
            this.lobPrefetchMetaData = this.getLobPrefetchMetaData();
        }
        this.validRows = T2CStatement.t2cDefineFetch(this, this.c_state, this.rowPrefetch, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
        if (this.validRows == -1 || this.validRows == -4) {
            this.connection.checkError(this.validRows);
        }
        if (this.t2cOutput[2] != 0L) {
            this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
        }
        if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2)) {
            this.extractNioDefineBuffers(0);
        }
        if (this.lobPrefetchMetaData != null) {
            this.processLobPrefetchMetaData(this.lobPrefetchMetaData);
        }
    }
    
    void allocateNioBuffersIfRequired(int capacity, final int capacity2, int capacity3) throws SQLException {
        if (this.nioBuffers == null) {
            this.nioBuffers = new ByteBuffer[4];
        }
        if (capacity2 > 0) {
            if (this.nioBuffers[0] == null || this.nioBuffers[0].capacity() < capacity2) {
                this.nioBuffers[0] = ByteBuffer.allocateDirect(capacity2);
            }
            else if (this.nioBuffers[0] != null) {
                this.nioBuffers[0].rewind();
            }
        }
        capacity *= 2;
        if (capacity > 0) {
            if (this.nioBuffers[1] == null || this.nioBuffers[1].capacity() < capacity) {
                this.nioBuffers[1] = ByteBuffer.allocateDirect(capacity);
            }
            else if (this.nioBuffers[1] != null) {
                this.nioBuffers[1].rewind();
            }
        }
        capacity3 *= 2;
        if (capacity3 > 0) {
            if (this.nioBuffers[2] == null || this.nioBuffers[2].capacity() < capacity3) {
                this.nioBuffers[2] = ByteBuffer.allocateDirect(capacity3);
            }
            else if (this.nioBuffers[2] != null) {
                this.nioBuffers[2].rewind();
            }
        }
    }
    
    void doDefineExecuteFetch() throws SQLException {
        short[] queryMetaData1 = null;
        if (this.needToPrepareDefineBuffer || this.needToParse) {
            this.setupForDefine();
            queryMetaData1 = this.connection.queryMetaData1;
        }
        this.t2cOutput[0] = 0L;
        this.t2cOutput[2] = 0L;
        final byte[] sqlBytes = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
        this.t2cOutput[5] = (this.connection.useNio ? 1 : 0);
        this.t2cOutput[6] = this.defaultLobPrefetchSize;
        if (this.connection.useNio) {
            this.resetNioAttributesBeforeFetch();
            this.allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
        }
        if (this.lobPrefetchMetaData == null) {
            this.lobPrefetchMetaData = this.getLobPrefetchMetaData();
        }
        try {
            this.validRows = T2CStatement.t2cDefineExecuteFetch(this, this.c_state, this.numberOfDefinePositions, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, false, this.needToParse, sqlBytes, sqlBytes.length, this.sqlKind, this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.preparedAllBinds, this.preparedCharBinds, this.accessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.nioBuffers, this.lobPrefetchMetaData);
        }
        catch (IOException ex) {
            this.validRows = 0;
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.validRows == -1) {
            this.connection.checkError(this.validRows);
        }
        if (this.t2cOutput[2] != 0L) {
            this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
        }
        this.connection.endToEndECIDSequenceNumber = (short)this.t2cOutput[4];
        if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2)) {
            this.extractNioDefineBuffers(0);
        }
        if (this.lobPrefetchMetaData != null) {
            this.processLobPrefetchMetaData(this.lobPrefetchMetaData);
        }
        this.needToParse = false;
    }
    
    @Override
    void fetch() throws SQLException {
        if (this.numberOfDefinePositions > 0) {
            if (this.needToPrepareDefineBuffer) {
                this.doDefineFetch();
            }
            else {
                this.t2cOutput[2] = 0L;
                this.t2cOutput[5] = (this.connection.useNio ? 1 : 0);
                this.t2cOutput[6] = this.defaultLobPrefetchSize;
                if (this.connection.useNio) {
                    this.resetNioAttributesBeforeFetch();
                    this.allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
                }
                if (this.lobPrefetchMetaData == null) {
                    this.lobPrefetchMetaData = this.getLobPrefetchMetaData();
                }
                this.validRows = T2CStatement.t2cFetch(this.c_state, this.needToPrepareDefineBuffer, this.rowPrefetch, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
                if (this.validRows == -1 || this.validRows == -4) {
                    this.connection.checkError(this.validRows);
                }
                if (this.t2cOutput[2] != 0L) {
                    this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
                }
                if (this.lobPrefetchMetaData != null) {
                    this.processLobPrefetchMetaData(this.lobPrefetchMetaData);
                }
                if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2)) {
                    this.extractNioDefineBuffers(0);
                }
            }
        }
    }
    
    void resetNioAttributesBeforeFetch() {
        this.extractedCharOffset = 0;
        this.extractedByteOffset = 0;
    }
    
    @Override
    void extractNioDefineBuffers(final int n) throws SQLException {
        if (this.accessors == null || this.defineIndicators == null || n == this.numberOfDefinePositions) {
            return;
        }
        int length = 0;
        int length2 = 0;
        int length3 = 0;
        int lengthIndex = 0;
        int indicatorIndex = 0;
        Label_0202: {
            if (!this.hasStream) {
                length = ((this.defineBytes != null) ? this.defineBytes.length : 0);
                length2 = ((this.defineChars != null) ? this.defineChars.length : 0);
                length3 = this.defineIndicators.length;
            }
            else {
                if (this.numberOfDefinePositions > n) {
                    indicatorIndex = this.accessors[n].indicatorIndex;
                    lengthIndex = this.accessors[n].lengthIndex;
                }
                int i = n;
                while (i < this.numberOfDefinePositions) {
                    switch (this.accessors[i].internalType) {
                        case 8:
                        case 24: {
                            break Label_0202;
                        }
                        default: {
                            length += this.accessors[i].byteLength;
                            length2 += this.accessors[i].charLength;
                            ++length3;
                            ++i;
                            continue;
                        }
                    }
                }
            }
        }
        final ByteBuffer byteBuffer = this.nioBuffers[0];
        if (byteBuffer != null && this.defineBytes != null && length > 0) {
            byteBuffer.position(this.extractedByteOffset);
            byteBuffer.get(this.defineBytes, this.extractedByteOffset, length);
            this.extractedByteOffset += length;
        }
        if (this.nioBuffers[1] != null && this.defineChars != null) {
            final CharBuffer charBuffer = this.nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN).asCharBuffer();
            if (length2 > 0) {
                charBuffer.position(this.extractedCharOffset);
                charBuffer.get(this.defineChars, this.extractedCharOffset, length2);
                this.extractedCharOffset += length2;
            }
        }
        if (this.nioBuffers[2] != null) {
            final ShortBuffer shortBuffer = this.nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
            if (this.hasStream) {
                if (length3 > 0) {
                    shortBuffer.position(indicatorIndex);
                    shortBuffer.get(this.defineIndicators, indicatorIndex, length3);
                    shortBuffer.position(lengthIndex);
                    shortBuffer.get(this.defineIndicators, lengthIndex, length3);
                }
            }
            else {
                shortBuffer.get(this.defineIndicators);
            }
        }
    }
    
    @Override
    void doClose() throws SQLException {
        if (this.defineBytes != null) {
            this.defineBytes = null;
            this.accessorByteOffset = 0;
        }
        if (this.defineChars != null) {
            this.defineChars = null;
            this.accessorCharOffset = 0;
        }
        if (this.defineIndicators != null) {
            this.defineIndicators = null;
            this.accessorShortOffset = 0;
        }
        final int t2cCloseStatement = T2CStatement.t2cCloseStatement(this.c_state);
        this.nioBuffers = null;
        if (t2cCloseStatement != 0) {
            this.connection.checkError(t2cCloseStatement);
        }
        this.t2cOutput = null;
    }
    
    @Override
    void closeQuery() throws SQLException {
        if (this.streamList != null) {
            while (this.nextStream != null) {
                try {
                    this.nextStream.close();
                }
                catch (IOException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.nextStream = this.nextStream.nextStream;
            }
        }
    }
    
    @Override
    Accessor allocateAccessor(final int n, final int i, final int n2, final int n3, final short n4, final String s, final boolean b) throws SQLException {
        if (n != 116 && n != 102) {
            return super.allocateAccessor(n, i, n2, n3, n4, s, b);
        }
        if (b && s != null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + i);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new T2CResultSetAccessor(this, n3, n4, i, b);
    }
    
    @Override
    void closeUsedStreams(final int n) throws SQLException {
        while (this.nextStream != null && this.nextStream.columnIndex < n) {
            try {
                this.nextStream.close();
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.nextStream = this.nextStream.nextStream;
        }
        if (this.nextStream != null) {
            try {
                this.nextStream.needBytes();
            }
            catch (IOException ex2) {
                this.interalCloseOnIOException(ex2);
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    void interalCloseOnIOException(final IOException ex) throws SQLException {
        this.closed = true;
        if (this.currentResultSet != null) {
            this.currentResultSet.closed = true;
        }
        this.doClose();
    }
    
    @Override
    void fetchDmlReturnParams() throws SQLException {
        this.rowsDmlReturned = T2CStatement.t2cGetRowsDmlReturned(this.c_state);
        if (this.rowsDmlReturned != 0) {
            this.allocateDmlReturnStorage();
            final int t2cFetchDmlReturnParams = T2CStatement.t2cFetchDmlReturnParams(this.c_state, this.returnParamAccessors, this.returnParamBytes, this.returnParamChars, this.returnParamIndicators);
            if (t2cFetchDmlReturnParams == -1 || t2cFetchDmlReturnParams == -4) {
                this.connection.checkError(t2cFetchDmlReturnParams);
            }
            if (this.t2cOutput[2] != 0L) {
                this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
            }
            if (this.connection.useNio && (t2cFetchDmlReturnParams > 0 || t2cFetchDmlReturnParams == -2)) {
                this.extractNioDefineBuffers(0);
            }
        }
        this.returnParamsFetched = true;
    }
    
    @Override
    void initializeIndicatorSubRange() {
        this.bindIndicatorSubRange = this.numberOfBindPositions * T2CPreparedStatement.PREAMBLE_PER_POSITION;
    }
    
    @Override
    int calculateIndicatorSubRangeSize() {
        return this.numberOfBindPositions * T2CPreparedStatement.PREAMBLE_PER_POSITION;
    }
    
    @Override
    short getInoutIndicator(final int n) {
        return this.bindIndicators[n * T2CPreparedStatement.PREAMBLE_PER_POSITION];
    }
    
    @Override
    void prepareBindPreambles(final int n, final int n2) {
        int n3 = this.bindIndicatorSubRange - this.calculateIndicatorSubRangeSize();
        final OracleTypeADT[] array = (OracleTypeADT[])((this.parameterOtype == null) ? null : this.parameterOtype[this.firstRowInBatch]);
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            final Binder binder = this.lastBinders[i];
            OracleTypeADT oracleTypeADT;
            short updateInoutIndicatorValue;
            if (binder == this.theReturnParamBinder) {
                oracleTypeADT = (OracleTypeADT)this.returnParamAccessors[i].internalOtype;
                updateInoutIndicatorValue = 0;
            }
            else {
                oracleTypeADT = ((array == null) ? null : array[i]);
                short n4;
                if (this.outBindAccessors == null) {
                    n4 = 0;
                }
                else {
                    final Accessor accessor = this.outBindAccessors[i];
                    if (accessor == null) {
                        n4 = 0;
                    }
                    else if (binder == this.theOutBinder) {
                        n4 = 1;
                        if (oracleTypeADT == null) {
                            oracleTypeADT = (OracleTypeADT)accessor.internalOtype;
                        }
                    }
                    else {
                        n4 = 2;
                    }
                }
                updateInoutIndicatorValue = binder.updateInoutIndicatorValue(n4);
            }
            this.bindIndicators[n3++] = updateInoutIndicatorValue;
            if (oracleTypeADT != null) {
                final long tdoCState = oracleTypeADT.getTdoCState();
                this.bindIndicators[n3 + 0] = (short)(tdoCState >> 48 & 0xFFFFL);
                this.bindIndicators[n3 + 1] = (short)(tdoCState >> 32 & 0xFFFFL);
                this.bindIndicators[n3 + 2] = (short)(tdoCState >> 16 & 0xFFFFL);
                this.bindIndicators[n3 + 3] = (short)(tdoCState & 0xFFFFL);
            }
            n3 += 4;
        }
    }
    
    @Override
    void releaseBuffers() {
        super.releaseBuffers();
    }
    
    @Override
    void doDescribe(final boolean b) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.described) {
            return;
        }
        if (!this.isOpen) {
            this.connection.open(this);
            this.isOpen = true;
        }
        boolean b2;
        do {
            b2 = false;
            final boolean b3 = this.sqlKind == 1 && this.needToParse && (!this.described || !this.serverCursor);
            final byte[] array = b3 ? this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
            this.numberOfDefinePositions = T2CStatement.t2cDescribe(this.c_state, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, array, array.length, b3);
            if (!this.described) {
                this.described = true;
            }
            if (this.numberOfDefinePositions == -1) {
                this.connection.checkError(this.numberOfDefinePositions);
            }
            if (this.numberOfDefinePositions == T2CPreparedStatement.T2C_EXTEND_BUFFER) {
                b2 = true;
                this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * 2, this.connection.queryMetaData2Size * 2);
            }
        } while (b2);
        this.processDescribeData();
    }
    
    static {
        T2CPreparedStatement.T2C_EXTEND_BUFFER = -3;
        T2CPreparedStatement.PREAMBLE_PER_POSITION = 5;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
