// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import javax.xml.transform.stream.StreamResult;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.transform.stax.StAXResult;
import org.xml.sax.ContentHandler;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.Result;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.io.OutputStream;
import javax.xml.transform.stream.StreamSource;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.transform.stax.StAXSource;
import org.xml.sax.InputSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.Source;
import java.io.StringReader;
import java.io.Reader;
import org.w3c.dom.Node;
import oracle.xml.parser.v2.XMLDocument;
import org.w3c.dom.Document;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.OPAQUE;
import java.sql.SQLException;
import java.sql.Connection;
import java.io.ByteArrayOutputStream;
import oracle.xml.parser.v2.XMLSAXSerializer;
import javax.xml.transform.dom.DOMResult;
import oracle.xdb.XMLType;
import java.sql.SQLXML;
import oracle.sql.DatumWithConnection;

final class OracleSQLXML extends DatumWithConnection implements SQLXML, Opaqueable
{
    private XMLType xdb;
    private boolean isReadable;
    private boolean isWriteable;
    private DOMResult domResult;
    private XMLSAXSerializer serializer;
    private ByteArrayOutputStream oStream;
    static final int INITIAL_BUFFER_SIZE = 16384;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleSQLXML(final Connection physicalConnectionOf) throws SQLException {
        this.isReadable = false;
        this.isWriteable = false;
        this.domResult = null;
        this.serializer = null;
        this.oStream = null;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.isReadable = false;
        this.isWriteable = true;
    }
    
    OracleSQLXML(final Connection physicalConnectionOf, final OPAQUE opaque) throws SQLException {
        this.isReadable = false;
        this.isWriteable = false;
        this.domResult = null;
        this.serializer = null;
        this.oStream = null;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.isReadable = true;
        this.isWriteable = false;
        if (opaque instanceof XMLType) {
            this.xdb = (XMLType)opaque;
        }
        else {
            this.xdb = new XMLType(opaque.getDescriptor(), (Connection)this.getInternalConnection(), (Object)opaque.getBytesValue());
        }
    }
    
    OracleSQLXML(final OpaqueDescriptor opaqueDescriptor, final Connection connection, final byte[] array) throws SQLException {
        this(connection, new OPAQUE(opaqueDescriptor, array, connection));
    }
    
    OracleSQLXML(final Connection physicalConnectionOf, final InputStream inputStream) throws SQLException {
        this.isReadable = false;
        this.isWriteable = false;
        this.domResult = null;
        this.serializer = null;
        this.oStream = null;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.isReadable = true;
        this.isWriteable = false;
        this.xdb = new XMLType((Connection)this.getInternalConnection(), inputStream);
    }
    
    OracleSQLXML(final Connection physicalConnectionOf, final XMLType xdb) throws SQLException {
        this.isReadable = false;
        this.isWriteable = false;
        this.domResult = null;
        this.serializer = null;
        this.oStream = null;
        this.setPhysicalConnectionOf(physicalConnectionOf);
        this.isReadable = true;
        this.isWriteable = false;
        this.xdb = xdb;
    }
    
    @Override
    public OPAQUE toOpaque() throws SQLException {
        return (OPAQUE)this.getXMLTypeInternal();
    }
    
    XMLType getXMLTypeInternal() throws SQLException {
        if (this.isWriteable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 260);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.serializer != null) {
            try {
                this.serializer.flush();
            }
            catch (IOException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            finally {
                this.serializer = null;
            }
        }
        if (this.oStream != null) {
            try {
                this.oStream.close();
            }
            catch (IOException ex2) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.xdb = XMLType.createXML((Connection)this.getInternalConnection(), (InputStream)new ByteArrayInputStream(this.oStream.toByteArray()));
            this.oStream = null;
        }
        else if (this.domResult != null) {
            final Node node = this.domResult.getNode();
            Object o;
            if (node instanceof Document) {
                o = node;
            }
            else {
                o = new XMLDocument();
                ((Node)o).insertBefore(((Document)o).importNode(node, true), null);
            }
            this.xdb = XMLType.createXML((Connection)this.getInternalConnection(), (Document)o);
            this.domResult = null;
        }
        if (this.xdb == null) {
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 260);
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        return this.xdb;
    }
    
    @Override
    public byte[] getBytes() {
        return null;
    }
    
    @Override
    public boolean isConvertibleTo(final Class clazz) {
        return false;
    }
    
    @Override
    public Object toJdbc() throws SQLException {
        return this;
    }
    
    @Override
    public Object makeJdbcArray(final int n) {
        return null;
    }
    
    @Override
    public void free() throws SQLException {
        this.isReadable = false;
        this.isWriteable = false;
        this.oStream = null;
        this.domResult = null;
        if (this.xdb != null) {
            this.xdb.close();
        }
        this.xdb = null;
    }
    
    InputStream getInputStream() throws SQLException {
        return new ByteArrayInputStream(this.xdb.getStringVal().getBytes());
    }
    
    @Override
    public InputStream getBinaryStream() throws SQLException {
        if (!this.isReadable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 261);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isReadable = false;
        return this.getInputStream();
    }
    
    @Override
    public Reader getCharacterStream() throws SQLException {
        if (!this.isReadable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 261);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isReadable = false;
        return new StringReader(this.xdb.getStringVal());
    }
    
    @Override
    public <T extends Source> T getSource(final Class<T> clazz) throws SQLException {
        if (!this.isReadable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 261);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isReadable = false;
        if (clazz == DOMSource.class) {
            return (T)new DOMSource(this.xdb.getDocument());
        }
        if (clazz == SAXSource.class) {
            return (T)new SAXSource(new InputSource(this.getInputStream()));
        }
        if (clazz == StAXSource.class) {
            try {
                return (T)new StAXSource(XMLInputFactory.newInstance().createXMLStreamReader(this.getInputStream()));
            }
            catch (XMLStreamException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        if (clazz == StreamSource.class) {
            return (T)new StreamSource(this.getInputStream());
        }
        this.isReadable = true;
        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 264);
        sqlException3.fillInStackTrace();
        throw sqlException3;
    }
    
    @Override
    public String getString() throws SQLException {
        if (!this.isReadable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 261);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isReadable = false;
        return this.xdb.getStringVal();
    }
    
    protected OutputStream getOutputStream() throws SQLException {
        if (this.oStream != null) {
            throw new SQLException("Internal Error");
        }
        return this.oStream = new ByteArrayOutputStream(16384);
    }
    
    @Override
    public OutputStream setBinaryStream() throws SQLException {
        if (!this.isWriteable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 262);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isWriteable = false;
        return this.getOutputStream();
    }
    
    @Override
    public Writer setCharacterStream() throws SQLException {
        if (!this.isWriteable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 262);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isWriteable = false;
        return new OutputStreamWriter(this.getOutputStream());
    }
    
    @Override
    public <T extends Result> T setResult(final Class<T> clazz) throws SQLException {
        if (!this.isWriteable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 262);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isWriteable = false;
        if (clazz == DOMResult.class) {
            return (T)(this.domResult = new DOMResult());
        }
        if (clazz == SAXResult.class) {
            this.serializer = new XMLSAXSerializer(this.getOutputStream());
            return (T)new SAXResult((ContentHandler)this.serializer);
        }
        if (clazz == StAXResult.class) {
            try {
                return (T)new StAXResult(XMLOutputFactory.newInstance().createXMLStreamWriter(this.getOutputStream()));
            }
            catch (XMLStreamException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        if (clazz == StreamResult.class) {
            return (T)new StreamResult(this.getOutputStream());
        }
        this.isWriteable = true;
        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 263);
        sqlException3.fillInStackTrace();
        throw sqlException3;
    }
    
    @Override
    public void setString(final String s) throws SQLException {
        if (!this.isWriteable) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 262);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.isWriteable = false;
        this.xdb = new XMLType((Connection)this.getInternalConnection(), s);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
