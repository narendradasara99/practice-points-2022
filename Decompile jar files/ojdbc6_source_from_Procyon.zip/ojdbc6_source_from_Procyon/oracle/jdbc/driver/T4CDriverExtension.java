// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Connection;
import java.util.Properties;

class T4CDriverExtension extends OracleDriverExtension
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    Connection getConnection(final String s, final Properties properties) throws SQLException {
        return new T4CConnection(s, properties, this);
    }
    
    @Override
    OracleStatement allocateStatement(final PhysicalConnection physicalConnection, final int n, final int n2) throws SQLException {
        return new T4CStatement(physicalConnection, n, n2);
    }
    
    @Override
    OraclePreparedStatement allocatePreparedStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        return new T4CPreparedStatement(physicalConnection, s, n, n2);
    }
    
    @Override
    OracleCallableStatement allocateCallableStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        return new T4CCallableStatement(physicalConnection, s, n, n2);
    }
    
    @Override
    OracleInputStream createInputStream(final OracleStatement oracleStatement, final int n, final Accessor accessor) throws SQLException {
        return new T4CInputStream(oracleStatement, n, accessor);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
