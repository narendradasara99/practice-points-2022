// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class BINARY_DOUBLENullBinder extends BINARY_DOUBLEBinder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        array3[n9] = -1;
    }
    
    @Override
    Binder copyingBinder() {
        return this;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
