// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

public class OracleSQLException extends SQLException
{
    private Object[] m_parameters;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleSQLException() {
        this(null, null, 0);
    }
    
    public OracleSQLException(final String s) {
        this(s, null, 0);
    }
    
    public OracleSQLException(final String s, final String s2) {
        this(s, s2, 0);
    }
    
    public OracleSQLException(final String s, final String s2, final int n) {
        this(s, s2, n, (Object[])null);
    }
    
    public OracleSQLException(final String reason, final String sqlState, final int vendorCode, final Object[] parameters) {
        super(reason, sqlState, vendorCode);
        this.m_parameters = parameters;
    }
    
    public Object[] getParameters() {
        if (this.m_parameters == null) {
            this.m_parameters = new Object[0];
        }
        return this.m_parameters;
    }
    
    public int getNumParameters() {
        if (this.m_parameters == null) {
            this.m_parameters = new Object[0];
        }
        return this.m_parameters.length;
    }
    
    public void setParameters(final Object[] parameters) {
        this.m_parameters = parameters;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
