// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import oracle.sql.BFILE;
import java.sql.SQLException;
import oracle.sql.BLOB;
import oracle.sql.Datum;

class OracleBlobInputStream extends OracleBufferedStream
{
    long lobOffset;
    Datum lob;
    long markedByte;
    boolean endOfStream;
    long maxPosition;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleBlobInputStream(final BLOB blob) throws SQLException {
        this(blob, ((PhysicalConnection)blob.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
    }
    
    public OracleBlobInputStream(final BLOB blob, final int n) throws SQLException {
        this(blob, n, 1L);
    }
    
    public OracleBlobInputStream(final BLOB lob, final int n, final long lobOffset) throws SQLException {
        super(n);
        this.endOfStream = false;
        this.maxPosition = Long.MAX_VALUE;
        if (lob == null || n <= 0 || lobOffset < 1L) {
            throw new IllegalArgumentException("Illegal Arguments");
        }
        this.lob = lob;
        this.markedByte = -1L;
        this.lobOffset = lobOffset;
    }
    
    public OracleBlobInputStream(final BLOB blob, final int n, final long n2, final long n3) throws SQLException {
        this(blob, n, n2);
        this.maxPosition = n2 + n3;
    }
    
    public OracleBlobInputStream(final BFILE bfile) throws SQLException {
        this(bfile, ((PhysicalConnection)bfile.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
    }
    
    public OracleBlobInputStream(final BFILE bfile, final int n) throws SQLException {
        this(bfile, n, 1L);
    }
    
    public OracleBlobInputStream(final BFILE lob, final int n, final long lobOffset) throws SQLException {
        super(n);
        this.endOfStream = false;
        this.maxPosition = Long.MAX_VALUE;
        if (lob == null || n <= 0 || lobOffset < 1L) {
            throw new IllegalArgumentException("Illegal Arguments");
        }
        this.lob = lob;
        this.markedByte = -1L;
        this.lobOffset = lobOffset;
    }
    
    @Override
    public boolean needBytes(final int a) throws IOException {
        this.ensureOpen();
        if (this.pos >= this.count) {
            if (!this.endOfStream) {
                if (a > this.currentBufferSize) {
                    this.currentBufferSize = Math.max(a, this.initialBufferSize);
                    this.resizableBuffer = new byte[this.currentBufferSize];
                }
                try {
                    int currentBufferSize;
                    if (this.currentBufferSize < this.maxPosition - this.lobOffset) {
                        currentBufferSize = this.currentBufferSize;
                    }
                    else {
                        currentBufferSize = (int)(this.maxPosition - this.lobOffset);
                    }
                    if (this.lob instanceof BLOB) {
                        this.count = ((BLOB)this.lob).getBytes(this.lobOffset, currentBufferSize, this.resizableBuffer);
                    }
                    else {
                        this.count = ((BFILE)this.lob).getBytes(this.lobOffset, currentBufferSize, this.resizableBuffer);
                    }
                    if (this.count < this.currentBufferSize) {
                        this.endOfStream = true;
                    }
                    if (this.count > 0) {
                        this.pos = 0;
                        this.lobOffset += this.count;
                        if (this.lobOffset > this.maxPosition) {
                            this.endOfStream = true;
                        }
                        return true;
                    }
                }
                catch (SQLException ex) {
                    final IOException ioException = DatabaseError.createIOException(ex);
                    ioException.fillInStackTrace();
                    throw ioException;
                }
            }
            return false;
        }
        return true;
    }
    
    void ensureOpen() throws IOException {
        try {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 57, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    @Override
    public void mark(final int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Read-ahead limit < 0");
        }
        this.markedByte = this.lobOffset - this.count + this.pos;
    }
    
    public void markInternal(final int n) {
    }
    
    @Override
    public void reset() throws IOException {
        this.ensureOpen();
        if (this.markedByte < 0L) {
            throw new IOException("Mark invalid or stream not marked.");
        }
        this.lobOffset = this.markedByte;
        this.pos = this.count;
        this.endOfStream = false;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        this.ensureOpen();
        final long n2 = 0L;
        long n3;
        if (this.count - this.pos >= n) {
            this.pos += (int)n;
            n3 = n2 + n;
        }
        else {
            final long n4 = n2 + (this.count - this.pos);
            this.pos = this.count;
            try {
                long n5;
                if (this.lob instanceof BLOB) {
                    n5 = ((BLOB)this.lob).length() - this.lobOffset + 1L;
                }
                else {
                    n5 = ((BFILE)this.lob).length() - this.lobOffset + 1L;
                }
                if (n5 >= n - n4) {
                    this.lobOffset += n - n4;
                    n3 = n4 + (n - n4);
                }
                else {
                    this.lobOffset += n5;
                    n3 = n4 + n5;
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
        return n3;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        OracleConnection oracleConnection = null;
        if (this.lob != null) {
            try {
                if (this.lob instanceof BLOB) {
                    oracleConnection = ((BLOB)this.lob).getInternalConnection();
                }
                else {
                    oracleConnection = ((BFILE)this.lob).getInternalConnection();
                }
            }
            catch (Exception ex) {
                oracleConnection = null;
            }
        }
        return oracleConnection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
