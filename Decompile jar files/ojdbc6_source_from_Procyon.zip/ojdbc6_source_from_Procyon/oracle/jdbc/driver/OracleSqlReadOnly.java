// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class OracleSqlReadOnly
{
    private static final int BASE = 0;
    private static final int BASE_1 = 1;
    private static final int BASE_2 = 2;
    private static final int B_STRING = 3;
    private static final int B_NAME = 4;
    private static final int B_C_COMMENT = 5;
    private static final int B_C_COMMENT_1 = 6;
    private static final int B_COMMENT = 7;
    private static final int PARAMETER = 8;
    private static final int TOKEN = 9;
    private static final int B_EGIN = 10;
    private static final int BE_GIN = 11;
    private static final int BEG_IN = 12;
    private static final int BEGI_N = 13;
    private static final int BEGIN_ = 14;
    private static final int C_ALL = 15;
    private static final int CA_LL = 16;
    private static final int CAL_L = 17;
    private static final int CALL_ = 18;
    private static final int D_Eetc = 19;
    private static final int DE_etc = 20;
    private static final int DEC_LARE = 21;
    private static final int DECL_ARE = 22;
    private static final int DECLA_RE = 23;
    private static final int DECLAR_E = 24;
    private static final int DECLARE_ = 25;
    private static final int DEL_ETE = 26;
    private static final int DELE_TE = 27;
    private static final int DELET_E = 28;
    private static final int DELETE_ = 29;
    private static final int I_NSERT = 30;
    private static final int IN_SERT = 31;
    private static final int INS_ERT = 32;
    private static final int INSE_RT = 33;
    private static final int INSER_T = 34;
    private static final int INSERT_ = 35;
    private static final int S_ELECT = 36;
    private static final int SE_LECT = 37;
    private static final int SEL_ECT = 38;
    private static final int SELE_CT = 39;
    private static final int SELEC_T = 40;
    private static final int SELECT_ = 41;
    private static final int U_PDATE = 42;
    private static final int UP_DATE = 43;
    private static final int UPD_ATE = 44;
    private static final int UPDA_TE = 45;
    private static final int UPDAT_E = 46;
    private static final int UPDATE_ = 47;
    private static final int M_ERGE = 48;
    private static final int ME_RGE = 49;
    private static final int MER_GE = 50;
    private static final int MERG_E = 51;
    private static final int MERGE_ = 52;
    private static final int W_ITH = 53;
    private static final int WI_TH = 54;
    private static final int WIT_H = 55;
    private static final int WITH_ = 56;
    private static final int KNOW_KIND = 57;
    private static final int KNOW_KIND_1 = 58;
    private static final int KNOW_KIND_2 = 59;
    private static final int K_STRING = 60;
    private static final int K_NAME = 61;
    private static final int K_C_COMMENT = 62;
    private static final int K_C_COMMENT_1 = 63;
    private static final int K_COMMENT = 64;
    private static final int K_PARAMETER = 65;
    private static final int TOKEN_KK = 66;
    private static final int W_HERE = 67;
    private static final int WH_ERE = 68;
    private static final int WHE_RE = 69;
    private static final int WHER_E = 70;
    private static final int WHERE_ = 71;
    private static final int O_RDER_BY = 72;
    private static final int OR_DER_BY = 73;
    private static final int ORD_ER_BY = 74;
    private static final int ORDE_R_BY = 75;
    private static final int ORDER__BY = 76;
    private static final int ORDER_xBY = 77;
    private static final int ORDER_B_Y = 78;
    private static final int ORDER_BY_ = 79;
    private static final int ORDER_xBY_CC_1 = 80;
    private static final int ORDER_xBY_CC_2 = 81;
    private static final int ORDER_xBY_CC_3 = 82;
    private static final int ORDER_xBY_C_1 = 83;
    private static final int ORDER_xBY_C_2 = 84;
    private static final int F_OR_UPDATE = 85;
    private static final int FO_R_UPDATE = 86;
    private static final int FOR__UPDATE = 87;
    private static final int FOR_xUPDATE = 88;
    private static final int FOR_U_PDATE = 89;
    private static final int FOR_UP_DATE = 90;
    private static final int FOR_UPD_ATE = 91;
    private static final int FOR_UPDA_TE = 92;
    private static final int FOR_UPDAT_E = 93;
    private static final int FOR_UPDATE_ = 94;
    private static final int FOR_xUPDATE_CC_1 = 95;
    private static final int FOR_xUPDATE_CC_2 = 96;
    private static final int FOR_xUPDATE_CC_3 = 97;
    private static final int FOR_xUPDATE_C_1 = 98;
    private static final int FOR_xUPDATE_C_2 = 99;
    private static final int B_N_tick = 100;
    private static final int B_NCHAR = 101;
    private static final int K_N_tick = 102;
    private static final int K_NCHAR = 103;
    private static final int K_NCHAR_tick = 104;
    private static final int B_Q_tickDelimiterCharDelimiterTick = 105;
    private static final int B_QTick_delimiterCharDelimiterTick = 106;
    private static final int B_QTickDelimiter_charDelimiterTick = 107;
    private static final int B_QTickDelimiterChar_delimiterTick = 108;
    private static final int B_QTickDelimiterCharDelimiter_tick = 109;
    private static final int K_Q_tickDelimiterCharDelimiterTick = 110;
    private static final int K_QTick_delimiterCharDelimiterTick = 111;
    private static final int K_QTickDelimiter_charDelimiterTick = 112;
    private static final int K_QTickDelimiterChar_delimiterTick = 113;
    private static final int K_QTickDelimiterCharDelimiter_tick = 114;
    private static final int K_EscEtc = 115;
    private static final int K_EscQuestion = 116;
    private static final int K_EscC_ALL = 117;
    private static final int K_EscCA_LL = 118;
    private static final int K_EscCAL_L = 119;
    private static final int K_EscCALL_ = 120;
    private static final int K_EscT = 121;
    private static final int K_EscTS_ = 122;
    private static final int K_EscD_ = 123;
    private static final int K_EscE_SCAPE = 124;
    private static final int K_EscES_CAPE = 125;
    private static final int K_EscESC_APE = 126;
    private static final int K_EscESCA_PE = 127;
    private static final int K_EscESCAP_E = 128;
    private static final int K_EscESCAPE_ = 129;
    private static final int K_EscF_N = 130;
    private static final int K_EscFN_ = 131;
    private static final int K_EscO_J = 132;
    private static final int K_EscOJ_ = 133;
    private static final int SKIP_PARAMETER_WHITESPACE = 134;
    private static final int LAST_STATE = 135;
    private static final int EOKTSS_LAST_STATE = 135;
    public static final String[] PARSER_STATE_NAME;
    static final int[][] TRANSITION;
    static final int NO_ACTION = 0;
    static final int DELETE_ACTION = 1;
    static final int INSERT_ACTION = 2;
    static final int MERGE_ACTION = 3;
    static final int UPDATE_ACTION = 4;
    static final int PLSQL_ACTION = 5;
    static final int CALL_ACTION = 6;
    static final int SELECT_ACTION = 7;
    static final int OTHER_ACTION = 8;
    static final int WHERE_ACTION = 9;
    static final int ORDER_ACTION = 10;
    static final int ORDER_BY_ACTION = 11;
    static final int FOR_ACTION = 12;
    static final int FOR_UPDATE_ACTION = 13;
    static final int QUESTION_ACTION = 14;
    static final int PARAMETER_ACTION = 15;
    static final int END_PARAMETER_ACTION = 16;
    static final int START_NCHAR_LITERAL_ACTION = 17;
    static final int END_NCHAR_LITERAL_ACTION = 18;
    static final int SAVE_DELIMITER_ACTION = 19;
    static final int LOOK_FOR_DELIMITER_ACTION = 20;
    public static final String[] CBI_ACTION_NAME;
    static final int[][] ACTION;
    static final int INITIAL_STATE = 0;
    static final int RESTART_STATE = 66;
    static final ODBCAction[][] ODBC_ACTION;
    static final int cMax = 127;
    private static final int cMaxLength = 128;
    
    private static final int[] copy(final int[] array) {
        final int[] array2 = new int[array.length];
        System.arraycopy(array, 0, array2, 0, array.length);
        return array2;
    }
    
    private static final ODBCAction[] copy(final ODBCAction[] array) {
        final ODBCAction[] array2 = new ODBCAction[array.length];
        System.arraycopy(array, 0, array2, 0, array.length);
        return array2;
    }
    
    private static final int[] newArray(final int n, final int n2) {
        final int[] array = new int[n];
        for (int i = 0; i < n; ++i) {
            array[i] = n2;
        }
        return array;
    }
    
    private static final ODBCAction[] newArray(final int n, final ODBCAction odbcAction) {
        final ODBCAction[] array = new ODBCAction[n];
        for (int i = 0; i < n; ++i) {
            array[i] = odbcAction;
        }
        return array;
    }
    
    private static final int[] copyReplacing(final int[] array, final int n, final int n2) {
        final int[] array2 = new int[array.length];
        for (int i = 0; i < array2.length; ++i) {
            final int n3 = array[i];
            if (n3 == n) {
                array2[i] = n2;
            }
            else {
                array2[i] = n3;
            }
        }
        return array2;
    }
    
    private static final ODBCAction[] copyReplacing(final ODBCAction[] array, final ODBCAction odbcAction, final ODBCAction odbcAction2) {
        final ODBCAction[] array2 = new ODBCAction[array.length];
        for (int i = 0; i < array2.length; ++i) {
            final ODBCAction odbcAction3 = array[i];
            if (odbcAction3 == odbcAction) {
                array2[i] = odbcAction2;
            }
            else {
                array2[i] = odbcAction3;
            }
        }
        return array2;
    }
    
    static {
        PARSER_STATE_NAME = new String[] { "BASE", "BASE_1", "BASE_2", "B_STRING", "B_NAME", "B_C_COMMENT", "B_C_COMMENT_1", "B_COMMENT", "PARAMETER", "TOKEN", "B_EGIN", "BE_GIN", "BEG_IN", "BEGI_N", "BEGIN_", "C_ALL", "CA_LL", "CAL_L", "CALL_", "D_Eetc", "DE_etc", "DEC_LARE", "DECL_ARE", "DECLA_RE", "DECLAR_E", "DECLARE_", "DEL_ETE", "DELE_TE", "DELET_E", "DELETE_", "I_NSERT", "IN_SERT", "INS_ERT", "INSE_RT", "INSER_T", "INSERT_", "S_ELECT", "SE_LECT", "SEL_ECT", "SELE_CT", "SELEC_T", "SELECT_", "U_PDATE", "UP_DATE", "UPD_ATE", "UPDA_TE", "UPDAT_E", "UPDATE_", "M_ERGE", "ME_RGE", "MER_GE", "MERG_E", "MERGE_", "W_ITH", "WI_TH", "WIT_H", "WITH_", "KNOW_KIND", "KNOW_KIND_1", "KNOW_KIND_2", "K_STRING", "K_NAME", "K_C_COMMENT", "K_C_COMMENT_1", "K_COMMENT", "K_PARAMETER", "TOKEN_KK", "W_HERE", "WH_ERE", "WHE_RE", "WHER_E", "WHERE_", "O_RDER_BY", "OR_DER_BY", "ORD_ER_BY", "ORDE_R_BY", "ORDER__BY", "ORDER_xBY", "ORDER_B_Y", "ORDER_BY_", "ORDER_xBY_CC_1", "ORDER_xBY_CC_2", "ORDER_xBY_CC_3", "ORDER_xBY_C_1 ", "ORDER_xBY_C_2 ", "F_OR_UPDATE", "FO_R_UPDATE", "FOR__UPDATE", "FOR_xUPDATE", "FOR_U_PDATE", "FOR_UP_DATE", "FOR_UPD_ATE", "FOR_UPDA_TE", "FOR_UPDAT_E", "FOR_UPDATE_", "FOR_xUPDATE_CC_1", "FOR_xUPDATE_CC_2", "FOR_xUPDATE_CC_3", "FOR_xUPDATE_C_1 ", "FOR_xUPDATE_C_2 ", "B_N_tick", "B_NCHAR", "K_N_tick", "K_NCHAR", "K_NCHAR_tick", "B_Q_tickDelimiterCharDelimiterTick", "B_QTick_delimiterCharDelimiterTick", "B_QTickDelimiter_charDelimiterTick", "B_QTickDelimiterChar_delimiterTick", "B_QTickDelimiterCharDelimiter_tick", "K_Q_tickDelimiterCharDelimiterTick", "K_QTick_delimiterCharDelimiterTick", "K_QTickDelimiter_charDelimiterTick", "K_QTickDelimiterChar_delimiterTick", "K_QTickDelimiterCharDelimiter_tick", "K_EscEtc", "K_EscQuestion", "K_EscC_ALL", "K_EscCA_LL", "K_EscCAL_L", "K_EscCALL_", "K_EscT", "K_EscTS_", "K_EscD_", "K_EscE_SCAPE", "K_EscES_CAPE", "K_EscESC_APE", "K_EscESCA_PE", "K_EscESCAP_E", "K_EscESCAPE_", "K_EscF_N", "K_EscFN_", "K_EscO_J", "K_EscOJ_", "SKIP_PARAMETER_WHITESPACE", "LAST_STATE" };
        TRANSITION = new int[135][];
        CBI_ACTION_NAME = new String[] { "NO_ACTION", "DELETE_ACTION", "INSERT_ACTION", "MERGE_ACTION", "UPDATE_ACTION", "PLSQL_ACTION", "CALL_ACTION", "SELECT_ACTION", "OTHER_ACTION", "WHERE_ACTION", "ORDER_ACTION", "ORDER_BY_ACTION", "FOR_ACTION", "FOR_UPDATE_ACTION", "QUESTION_ACTION", "PARAMETER_ACTION", "END_PARAMETER_ACTION", "START_NCHAR_LITERAL_ACTION", "END_NCHAR_LITERAL_ACTION", "SAVE_DELIMITER_ACTION", "LOOK_FOR_DELIMITER_ACTION" };
        ACTION = new int[135][];
        ODBC_ACTION = new ODBCAction[135][];
        try {
            final int[] array = { 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 9, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57 };
            final int[] copy = copy(array);
            copy[34] = 4;
            copy[39] = 3;
            copy[45] = 2;
            copy[47] = 1;
            copy[58] = 8;
            copy[123] = 115;
            final int[] copyReplacing = copyReplacing(copy, 57, 0);
            copyReplacing[98] = (copyReplacing[66] = 10);
            copyReplacing[99] = (copyReplacing[67] = 15);
            copyReplacing[100] = (copyReplacing[68] = 19);
            copyReplacing[105] = (copyReplacing[73] = 30);
            copyReplacing[77] = (copyReplacing[109] = 48);
            copyReplacing[110] = (copyReplacing[78] = 100);
            copyReplacing[113] = (copyReplacing[81] = 105);
            copyReplacing[115] = (copyReplacing[83] = 36);
            copyReplacing[117] = (copyReplacing[85] = 42);
            copyReplacing[119] = (copyReplacing[87] = 53);
            final int[] copyReplacing2 = copyReplacing(copy, 9, 66);
            copyReplacing2[34] = 61;
            copyReplacing2[39] = 60;
            copyReplacing2[45] = 59;
            copyReplacing2[copyReplacing2[47] = 58] = 134;
            copyReplacing2[32] = (copyReplacing2[32] = 57);
            copyReplacing2[10] = (copyReplacing2[9] = 57);
            copyReplacing2[61] = (copyReplacing2[13] = 57);
            final int[] copyReplacing3 = copyReplacing(copyReplacing2, 9, 66);
            copyReplacing3[110] = (copyReplacing3[78] = 102);
            copyReplacing3[113] = (copyReplacing3[81] = 110);
            copyReplacing3[119] = (copyReplacing3[87] = 67);
            copyReplacing3[111] = (copyReplacing3[79] = 72);
            copyReplacing3[102] = (copyReplacing3[70] = 85);
            final int[] copyReplacing4 = copyReplacing(copyReplacing3, 57, 115);
            copyReplacing4[63] = 116;
            copyReplacing4[67] = (copyReplacing4[99] = 117);
            copyReplacing4[84] = (copyReplacing4[116] = 121);
            copyReplacing4[68] = (copyReplacing4[100] = 123);
            copyReplacing4[69] = (copyReplacing4[101] = 124);
            copyReplacing4[70] = (copyReplacing4[102] = 130);
            copyReplacing4[79] = (copyReplacing4[111] = 132);
            OracleSqlReadOnly.TRANSITION[0] = copyReplacing;
            (OracleSqlReadOnly.TRANSITION[1] = copy(copyReplacing))[42] = 5;
            (OracleSqlReadOnly.TRANSITION[2] = copy(copyReplacing))[45] = 7;
            (OracleSqlReadOnly.TRANSITION[3] = newArray(128, 3))[39] = 0;
            (OracleSqlReadOnly.TRANSITION[100] = copy(copy))[39] = 101;
            (OracleSqlReadOnly.TRANSITION[101] = newArray(128, 101))[39] = 0;
            (OracleSqlReadOnly.TRANSITION[105] = copy(copy))[39] = 106;
            OracleSqlReadOnly.TRANSITION[106] = newArray(128, 107);
            OracleSqlReadOnly.TRANSITION[107] = newArray(128, 107);
            OracleSqlReadOnly.TRANSITION[108] = newArray(128, 109);
            (OracleSqlReadOnly.TRANSITION[109] = newArray(128, 107))[39] = 0;
            (OracleSqlReadOnly.TRANSITION[4] = newArray(128, 4))[34] = 0;
            (OracleSqlReadOnly.TRANSITION[5] = newArray(128, 5))[42] = 6;
            (OracleSqlReadOnly.TRANSITION[6] = newArray(128, 5))[42] = 6;
            OracleSqlReadOnly.TRANSITION[6][47] = 0;
            (OracleSqlReadOnly.TRANSITION[7] = newArray(128, 7))[10] = 0;
            OracleSqlReadOnly.TRANSITION[8] = copyReplacing(copy, 9, 8);
            OracleSqlReadOnly.TRANSITION[9] = copy;
            (OracleSqlReadOnly.TRANSITION[10] = copy(copy))[69] = 11;
            OracleSqlReadOnly.TRANSITION[10][101] = 11;
            (OracleSqlReadOnly.TRANSITION[11] = copy(copy))[71] = 12;
            OracleSqlReadOnly.TRANSITION[11][103] = 12;
            (OracleSqlReadOnly.TRANSITION[12] = copy(copy))[73] = 13;
            OracleSqlReadOnly.TRANSITION[12][105] = 13;
            (OracleSqlReadOnly.TRANSITION[13] = copy(copy))[78] = 14;
            OracleSqlReadOnly.TRANSITION[13][110] = 14;
            OracleSqlReadOnly.TRANSITION[14] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[15] = copy(copy))[65] = 16;
            OracleSqlReadOnly.TRANSITION[15][97] = 16;
            (OracleSqlReadOnly.TRANSITION[16] = copy(copy))[76] = 17;
            OracleSqlReadOnly.TRANSITION[16][108] = 17;
            (OracleSqlReadOnly.TRANSITION[17] = copy(copy))[76] = 18;
            OracleSqlReadOnly.TRANSITION[17][108] = 18;
            OracleSqlReadOnly.TRANSITION[18] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[19] = copy(copy))[69] = 20;
            OracleSqlReadOnly.TRANSITION[19][101] = 20;
            (OracleSqlReadOnly.TRANSITION[20] = copy(copy))[67] = 21;
            OracleSqlReadOnly.TRANSITION[20][99] = 21;
            OracleSqlReadOnly.TRANSITION[20][76] = 26;
            OracleSqlReadOnly.TRANSITION[20][108] = 26;
            (OracleSqlReadOnly.TRANSITION[21] = copy(copy))[76] = 22;
            OracleSqlReadOnly.TRANSITION[21][108] = 22;
            (OracleSqlReadOnly.TRANSITION[22] = copy(copy))[65] = 23;
            OracleSqlReadOnly.TRANSITION[22][97] = 23;
            (OracleSqlReadOnly.TRANSITION[23] = copy(copy))[82] = 24;
            OracleSqlReadOnly.TRANSITION[23][114] = 24;
            (OracleSqlReadOnly.TRANSITION[24] = copy(copy))[69] = 25;
            OracleSqlReadOnly.TRANSITION[24][101] = 25;
            OracleSqlReadOnly.TRANSITION[25] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[26] = copy(copy))[69] = 27;
            OracleSqlReadOnly.TRANSITION[26][101] = 27;
            (OracleSqlReadOnly.TRANSITION[27] = copy(copy))[84] = 28;
            OracleSqlReadOnly.TRANSITION[27][116] = 28;
            (OracleSqlReadOnly.TRANSITION[28] = copy(copy))[69] = 29;
            OracleSqlReadOnly.TRANSITION[28][101] = 29;
            OracleSqlReadOnly.TRANSITION[29] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[30] = copy(copy))[78] = 31;
            OracleSqlReadOnly.TRANSITION[30][110] = 31;
            (OracleSqlReadOnly.TRANSITION[31] = copy(copy))[83] = 32;
            OracleSqlReadOnly.TRANSITION[31][115] = 32;
            (OracleSqlReadOnly.TRANSITION[32] = copy(copy))[69] = 33;
            OracleSqlReadOnly.TRANSITION[32][101] = 33;
            (OracleSqlReadOnly.TRANSITION[33] = copy(copy))[82] = 34;
            OracleSqlReadOnly.TRANSITION[33][114] = 34;
            (OracleSqlReadOnly.TRANSITION[34] = copy(copy))[84] = 35;
            OracleSqlReadOnly.TRANSITION[34][116] = 35;
            OracleSqlReadOnly.TRANSITION[35] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[36] = copy(copy))[69] = 37;
            OracleSqlReadOnly.TRANSITION[36][101] = 37;
            (OracleSqlReadOnly.TRANSITION[37] = copy(copy))[76] = 38;
            OracleSqlReadOnly.TRANSITION[37][108] = 38;
            (OracleSqlReadOnly.TRANSITION[38] = copy(copy))[69] = 39;
            OracleSqlReadOnly.TRANSITION[38][101] = 39;
            (OracleSqlReadOnly.TRANSITION[39] = copy(copy))[67] = 40;
            OracleSqlReadOnly.TRANSITION[39][99] = 40;
            (OracleSqlReadOnly.TRANSITION[40] = copy(copy))[84] = 41;
            OracleSqlReadOnly.TRANSITION[40][116] = 41;
            OracleSqlReadOnly.TRANSITION[41] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[42] = copy(copy))[80] = 43;
            OracleSqlReadOnly.TRANSITION[42][112] = 43;
            (OracleSqlReadOnly.TRANSITION[43] = copy(copy))[68] = 44;
            OracleSqlReadOnly.TRANSITION[43][100] = 44;
            (OracleSqlReadOnly.TRANSITION[44] = copy(copy))[65] = 45;
            OracleSqlReadOnly.TRANSITION[44][97] = 45;
            (OracleSqlReadOnly.TRANSITION[45] = copy(copy))[84] = 46;
            OracleSqlReadOnly.TRANSITION[45][116] = 46;
            (OracleSqlReadOnly.TRANSITION[46] = copy(copy))[69] = 47;
            OracleSqlReadOnly.TRANSITION[46][101] = 47;
            OracleSqlReadOnly.TRANSITION[47] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[48] = copy(copy))[69] = 49;
            OracleSqlReadOnly.TRANSITION[48][101] = 49;
            (OracleSqlReadOnly.TRANSITION[49] = copy(copy))[82] = 50;
            OracleSqlReadOnly.TRANSITION[49][114] = 50;
            (OracleSqlReadOnly.TRANSITION[50] = copy(copy))[71] = 51;
            OracleSqlReadOnly.TRANSITION[50][103] = 51;
            (OracleSqlReadOnly.TRANSITION[51] = copy(copy))[69] = 52;
            OracleSqlReadOnly.TRANSITION[51][101] = 52;
            OracleSqlReadOnly.TRANSITION[52] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[53] = copy(copy))[73] = 54;
            OracleSqlReadOnly.TRANSITION[53][105] = 54;
            (OracleSqlReadOnly.TRANSITION[54] = copy(copy))[84] = 55;
            OracleSqlReadOnly.TRANSITION[54][116] = 55;
            (OracleSqlReadOnly.TRANSITION[55] = copy(copy))[72] = 56;
            OracleSqlReadOnly.TRANSITION[55][104] = 56;
            OracleSqlReadOnly.TRANSITION[56] = copyReplacing3;
            OracleSqlReadOnly.TRANSITION[66] = copyReplacing2;
            (OracleSqlReadOnly.TRANSITION[58] = copy(copyReplacing3))[42] = 62;
            (OracleSqlReadOnly.TRANSITION[59] = copy(copyReplacing3))[45] = 64;
            (OracleSqlReadOnly.TRANSITION[62] = newArray(128, 62))[42] = 63;
            (OracleSqlReadOnly.TRANSITION[63] = newArray(128, 62))[42] = 63;
            OracleSqlReadOnly.TRANSITION[63][47] = 57;
            (OracleSqlReadOnly.TRANSITION[64] = newArray(128, 64))[10] = 57;
            (OracleSqlReadOnly.TRANSITION[61] = newArray(128, 61))[34] = 57;
            (OracleSqlReadOnly.TRANSITION[60] = newArray(128, 60))[39] = 57;
            OracleSqlReadOnly.TRANSITION[65] = copyReplacing(copyReplacing2, 66, 65);
            (OracleSqlReadOnly.TRANSITION[134] = copyReplacing(copyReplacing2, 66, 65))[32] = 134;
            OracleSqlReadOnly.TRANSITION[134][10] = 134;
            OracleSqlReadOnly.TRANSITION[134][13] = 134;
            OracleSqlReadOnly.TRANSITION[134][9] = 134;
            OracleSqlReadOnly.TRANSITION[57] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[67] = copy(copyReplacing2))[72] = 68;
            OracleSqlReadOnly.TRANSITION[67][104] = 68;
            (OracleSqlReadOnly.TRANSITION[68] = copy(copyReplacing2))[69] = 69;
            OracleSqlReadOnly.TRANSITION[68][101] = 69;
            (OracleSqlReadOnly.TRANSITION[69] = copy(copyReplacing2))[82] = 70;
            OracleSqlReadOnly.TRANSITION[69][114] = 70;
            (OracleSqlReadOnly.TRANSITION[70] = copy(copyReplacing2))[69] = 71;
            OracleSqlReadOnly.TRANSITION[70][101] = 71;
            OracleSqlReadOnly.TRANSITION[71] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[72] = copy(copyReplacing2))[82] = 73;
            OracleSqlReadOnly.TRANSITION[72][114] = 73;
            (OracleSqlReadOnly.TRANSITION[73] = copy(copyReplacing2))[68] = 74;
            OracleSqlReadOnly.TRANSITION[73][100] = 74;
            (OracleSqlReadOnly.TRANSITION[74] = copy(copyReplacing2))[69] = 75;
            OracleSqlReadOnly.TRANSITION[74][101] = 75;
            (OracleSqlReadOnly.TRANSITION[75] = copy(copyReplacing2))[82] = 76;
            OracleSqlReadOnly.TRANSITION[75][114] = 76;
            (OracleSqlReadOnly.TRANSITION[76] = copyReplacing(copyReplacing3, 57, 77))[47] = 80;
            OracleSqlReadOnly.TRANSITION[76][45] = 83;
            (OracleSqlReadOnly.TRANSITION[77] = copyReplacing(copyReplacing3, 57, 77))[47] = 80;
            (OracleSqlReadOnly.TRANSITION[80] = copy(copyReplacing3))[42] = 81;
            (OracleSqlReadOnly.TRANSITION[81] = newArray(128, 81))[42] = 82;
            (OracleSqlReadOnly.TRANSITION[82] = newArray(128, 81))[47] = 77;
            OracleSqlReadOnly.TRANSITION[77][45] = 83;
            (OracleSqlReadOnly.TRANSITION[83] = copy(copyReplacing3))[45] = 84;
            (OracleSqlReadOnly.TRANSITION[84] = newArray(128, 84))[10] = 77;
            OracleSqlReadOnly.TRANSITION[77][66] = 78;
            OracleSqlReadOnly.TRANSITION[77][98] = 78;
            (OracleSqlReadOnly.TRANSITION[78] = copy(copyReplacing2))[89] = 79;
            OracleSqlReadOnly.TRANSITION[78][121] = 79;
            OracleSqlReadOnly.TRANSITION[79] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[85] = copy(copyReplacing3))[79] = 86;
            OracleSqlReadOnly.TRANSITION[85][111] = 86;
            (OracleSqlReadOnly.TRANSITION[86] = copy(copyReplacing3))[82] = 87;
            OracleSqlReadOnly.TRANSITION[86][114] = 87;
            (OracleSqlReadOnly.TRANSITION[87] = copyReplacing(copyReplacing2, 57, 88))[47] = 95;
            OracleSqlReadOnly.TRANSITION[87][45] = 98;
            (OracleSqlReadOnly.TRANSITION[88] = copyReplacing(copyReplacing2, 57, 88))[47] = 95;
            (OracleSqlReadOnly.TRANSITION[95] = copy(copyReplacing3))[42] = 96;
            (OracleSqlReadOnly.TRANSITION[96] = newArray(128, 96))[42] = 97;
            (OracleSqlReadOnly.TRANSITION[97] = newArray(128, 96))[47] = 88;
            OracleSqlReadOnly.TRANSITION[88][45] = 98;
            (OracleSqlReadOnly.TRANSITION[98] = copy(copyReplacing3))[45] = 99;
            (OracleSqlReadOnly.TRANSITION[99] = newArray(128, 99))[10] = 88;
            OracleSqlReadOnly.TRANSITION[88][85] = 89;
            OracleSqlReadOnly.TRANSITION[88][117] = 89;
            (OracleSqlReadOnly.TRANSITION[89] = copy(copyReplacing3))[80] = 90;
            OracleSqlReadOnly.TRANSITION[89][112] = 90;
            (OracleSqlReadOnly.TRANSITION[90] = copy(copyReplacing3))[68] = 91;
            OracleSqlReadOnly.TRANSITION[90][100] = 91;
            (OracleSqlReadOnly.TRANSITION[91] = copy(copyReplacing3))[65] = 92;
            OracleSqlReadOnly.TRANSITION[91][97] = 92;
            (OracleSqlReadOnly.TRANSITION[92] = copy(copyReplacing3))[84] = 93;
            OracleSqlReadOnly.TRANSITION[92][116] = 93;
            (OracleSqlReadOnly.TRANSITION[93] = copy(copyReplacing3))[69] = 94;
            OracleSqlReadOnly.TRANSITION[93][101] = 94;
            OracleSqlReadOnly.TRANSITION[94] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[102] = copy(copyReplacing2))[39] = 103;
            (OracleSqlReadOnly.TRANSITION[103] = newArray(128, 103))[39] = 104;
            (OracleSqlReadOnly.TRANSITION[104] = newArray(128, 57))[39] = 103;
            (OracleSqlReadOnly.TRANSITION[110] = copy(copyReplacing3))[39] = 111;
            OracleSqlReadOnly.TRANSITION[111] = newArray(128, 112);
            OracleSqlReadOnly.TRANSITION[112] = newArray(128, 112);
            OracleSqlReadOnly.TRANSITION[113] = newArray(128, 114);
            (OracleSqlReadOnly.TRANSITION[114] = newArray(128, 112))[39] = 57;
            OracleSqlReadOnly.TRANSITION[115] = copyReplacing4;
            OracleSqlReadOnly.TRANSITION[116] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[117] = copy(copyReplacing3))[97] = 118;
            OracleSqlReadOnly.TRANSITION[117][65] = 118;
            (OracleSqlReadOnly.TRANSITION[118] = copy(copyReplacing3))[108] = 119;
            OracleSqlReadOnly.TRANSITION[118][76] = 119;
            (OracleSqlReadOnly.TRANSITION[119] = copy(copyReplacing3))[108] = 120;
            OracleSqlReadOnly.TRANSITION[119][76] = 120;
            OracleSqlReadOnly.TRANSITION[120] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[121] = copy(copyReplacing3))[115] = 122;
            OracleSqlReadOnly.TRANSITION[121][83] = 122;
            OracleSqlReadOnly.TRANSITION[122] = copyReplacing3;
            OracleSqlReadOnly.TRANSITION[123] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[124] = copy(copyReplacing3))[115] = 125;
            OracleSqlReadOnly.TRANSITION[124][83] = 125;
            (OracleSqlReadOnly.TRANSITION[125] = copy(copyReplacing3))[99] = 126;
            OracleSqlReadOnly.TRANSITION[125][67] = 126;
            (OracleSqlReadOnly.TRANSITION[126] = copy(copyReplacing3))[97] = 127;
            OracleSqlReadOnly.TRANSITION[126][65] = 127;
            (OracleSqlReadOnly.TRANSITION[127] = copy(copyReplacing3))[112] = 128;
            OracleSqlReadOnly.TRANSITION[127][80] = 128;
            (OracleSqlReadOnly.TRANSITION[128] = copy(copyReplacing3))[101] = 129;
            OracleSqlReadOnly.TRANSITION[128][69] = 129;
            OracleSqlReadOnly.TRANSITION[129] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[130] = copy(copyReplacing3))[110] = 131;
            OracleSqlReadOnly.TRANSITION[130][78] = 131;
            OracleSqlReadOnly.TRANSITION[131] = copyReplacing3;
            (OracleSqlReadOnly.TRANSITION[132] = copy(copyReplacing3))[106] = 133;
            OracleSqlReadOnly.TRANSITION[132][74] = 133;
            OracleSqlReadOnly.TRANSITION[133] = copyReplacing3;
            final int[] array2 = newArray(128, 0);
            final int[] copy2 = copy(array2);
            copy2[63] = 14;
            final int[] copy3 = copy(copy2);
            copy3[123] = 5;
            final int[] array3 = new int[128];
            for (int i = 0; i < array3.length; ++i) {
                if (OracleSqlReadOnly.TRANSITION[8][i] == 8) {
                    array3[i] = 15;
                }
                else {
                    array3[i] = 16;
                }
            }
            final int[] array4 = new int[128];
            for (int j = 0; j < array4.length; ++j) {
                if (OracleSqlReadOnly.TRANSITION[65][j] == 65) {
                    array4[j] = 15;
                }
                else {
                    array4[j] = 16;
                }
            }
            final int[] copy4 = copy(array4);
            copy4[10] = (copy4[32] = 0);
            copy4[13] = (copy4[9] = 0);
            final int[] copy5 = copy(array2);
            for (int k = 0; k < copy5.length; ++k) {
                if (copyReplacing3[k] != 66) {
                    copy5[k] = 5;
                }
            }
            final int[] copyReplacing5 = copyReplacing(copy5, 5, 6);
            final int[] copyReplacing6 = copyReplacing(copy5, 5, 1);
            final int[] copyReplacing7 = copyReplacing(copy5, 5, 2);
            final int[] copyReplacing8 = copyReplacing(copy5, 5, 3);
            final int[] copyReplacing9 = copyReplacing(copy5, 5, 4);
            final int[] copyReplacing10 = copyReplacing(copy5, 5, 7);
            final int[] copyReplacing11 = copyReplacing(copy5, 5, 8);
            copyReplacing11[123] = 6;
            final int[] copyReplacing12 = copyReplacing(copy5, 5, 10);
            for (int l = 0; l < copyReplacing12.length; ++l) {
                if (copyReplacing12[l] == 8) {
                    copyReplacing12[l] = 0;
                }
            }
            final int[] copyReplacing13 = copyReplacing(copyReplacing12, 10, 11);
            final int[] copyReplacing14 = copyReplacing(copyReplacing12, 10, 9);
            final int[] copyReplacing15 = copyReplacing(copyReplacing12, 10, 12);
            final int[] copyReplacing16 = copyReplacing(copyReplacing12, 10, 13);
            final int[] copy6 = copy(array2);
            copy6[39] = 17;
            final int[] copyReplacing17 = copyReplacing(array2, 0, 18);
            copyReplacing17[39] = 0;
            final int[] copyReplacing18 = copyReplacing(array2, 0, 19);
            final int[] copyReplacing19 = copyReplacing(array2, 0, 20);
            final int[] copy7 = copy(copyReplacing19);
            copy7[39] = 0;
            OracleSqlReadOnly.ACTION[0] = copy3;
            OracleSqlReadOnly.ACTION[1] = copy3;
            OracleSqlReadOnly.ACTION[2] = copy3;
            OracleSqlReadOnly.ACTION[3] = array2;
            OracleSqlReadOnly.ACTION[4] = array2;
            OracleSqlReadOnly.ACTION[5] = array2;
            OracleSqlReadOnly.ACTION[6] = array2;
            OracleSqlReadOnly.ACTION[7] = array2;
            OracleSqlReadOnly.ACTION[8] = array3;
            OracleSqlReadOnly.ACTION[134] = copy4;
            OracleSqlReadOnly.ACTION[100] = copy6;
            OracleSqlReadOnly.ACTION[101] = copyReplacing17;
            OracleSqlReadOnly.ACTION[105] = array2;
            OracleSqlReadOnly.ACTION[106] = copyReplacing18;
            OracleSqlReadOnly.ACTION[107] = copyReplacing19;
            OracleSqlReadOnly.ACTION[108] = null;
            OracleSqlReadOnly.ACTION[109] = copy7;
            OracleSqlReadOnly.ACTION[9] = copyReplacing11;
            OracleSqlReadOnly.ACTION[10] = copyReplacing11;
            OracleSqlReadOnly.ACTION[11] = copyReplacing11;
            OracleSqlReadOnly.ACTION[12] = copyReplacing11;
            OracleSqlReadOnly.ACTION[13] = copyReplacing11;
            OracleSqlReadOnly.ACTION[14] = copy5;
            OracleSqlReadOnly.ACTION[15] = copyReplacing11;
            OracleSqlReadOnly.ACTION[16] = copyReplacing11;
            OracleSqlReadOnly.ACTION[17] = copyReplacing11;
            OracleSqlReadOnly.ACTION[18] = copyReplacing5;
            OracleSqlReadOnly.ACTION[19] = copyReplacing11;
            OracleSqlReadOnly.ACTION[20] = copyReplacing11;
            OracleSqlReadOnly.ACTION[21] = copyReplacing11;
            OracleSqlReadOnly.ACTION[22] = copyReplacing11;
            OracleSqlReadOnly.ACTION[23] = copyReplacing11;
            OracleSqlReadOnly.ACTION[24] = copyReplacing11;
            OracleSqlReadOnly.ACTION[25] = copy5;
            OracleSqlReadOnly.ACTION[26] = copyReplacing11;
            OracleSqlReadOnly.ACTION[27] = copyReplacing11;
            OracleSqlReadOnly.ACTION[28] = copyReplacing11;
            OracleSqlReadOnly.ACTION[29] = copyReplacing6;
            OracleSqlReadOnly.ACTION[30] = copyReplacing11;
            OracleSqlReadOnly.ACTION[31] = copyReplacing11;
            OracleSqlReadOnly.ACTION[32] = copyReplacing11;
            OracleSqlReadOnly.ACTION[33] = copyReplacing11;
            OracleSqlReadOnly.ACTION[34] = copyReplacing11;
            OracleSqlReadOnly.ACTION[35] = copyReplacing7;
            OracleSqlReadOnly.ACTION[36] = copyReplacing11;
            OracleSqlReadOnly.ACTION[37] = copyReplacing11;
            OracleSqlReadOnly.ACTION[38] = copyReplacing11;
            OracleSqlReadOnly.ACTION[39] = copyReplacing11;
            OracleSqlReadOnly.ACTION[40] = copyReplacing11;
            OracleSqlReadOnly.ACTION[41] = copyReplacing10;
            OracleSqlReadOnly.ACTION[42] = copyReplacing11;
            OracleSqlReadOnly.ACTION[43] = copyReplacing11;
            OracleSqlReadOnly.ACTION[44] = copyReplacing11;
            OracleSqlReadOnly.ACTION[45] = copyReplacing11;
            OracleSqlReadOnly.ACTION[46] = copyReplacing11;
            OracleSqlReadOnly.ACTION[47] = copyReplacing9;
            OracleSqlReadOnly.ACTION[48] = copyReplacing11;
            OracleSqlReadOnly.ACTION[49] = copyReplacing11;
            OracleSqlReadOnly.ACTION[50] = copyReplacing11;
            OracleSqlReadOnly.ACTION[51] = copyReplacing11;
            OracleSqlReadOnly.ACTION[52] = copyReplacing8;
            OracleSqlReadOnly.ACTION[53] = copyReplacing11;
            OracleSqlReadOnly.ACTION[54] = copyReplacing11;
            OracleSqlReadOnly.ACTION[55] = copyReplacing11;
            OracleSqlReadOnly.ACTION[56] = copyReplacing10;
            OracleSqlReadOnly.ACTION[66] = copy2;
            OracleSqlReadOnly.ACTION[58] = copy2;
            OracleSqlReadOnly.ACTION[59] = copy2;
            OracleSqlReadOnly.ACTION[60] = array2;
            OracleSqlReadOnly.ACTION[61] = array2;
            OracleSqlReadOnly.ACTION[62] = array2;
            OracleSqlReadOnly.ACTION[63] = array2;
            OracleSqlReadOnly.ACTION[64] = array2;
            OracleSqlReadOnly.ACTION[65] = array4;
            OracleSqlReadOnly.ACTION[102] = copy6;
            OracleSqlReadOnly.ACTION[103] = array2;
            OracleSqlReadOnly.ACTION[104] = copyReplacing17;
            OracleSqlReadOnly.ACTION[110] = array2;
            OracleSqlReadOnly.ACTION[111] = copyReplacing18;
            OracleSqlReadOnly.ACTION[112] = copyReplacing19;
            OracleSqlReadOnly.ACTION[113] = null;
            OracleSqlReadOnly.ACTION[114] = copy7;
            OracleSqlReadOnly.ACTION[57] = copy2;
            OracleSqlReadOnly.ACTION[67] = array2;
            OracleSqlReadOnly.ACTION[68] = array2;
            OracleSqlReadOnly.ACTION[69] = array2;
            OracleSqlReadOnly.ACTION[70] = array2;
            OracleSqlReadOnly.ACTION[71] = copyReplacing14;
            OracleSqlReadOnly.ACTION[72] = array2;
            OracleSqlReadOnly.ACTION[73] = array2;
            OracleSqlReadOnly.ACTION[74] = array2;
            OracleSqlReadOnly.ACTION[75] = array2;
            OracleSqlReadOnly.ACTION[76] = copyReplacing12;
            OracleSqlReadOnly.ACTION[77] = array2;
            OracleSqlReadOnly.ACTION[78] = array2;
            OracleSqlReadOnly.ACTION[79] = copyReplacing13;
            OracleSqlReadOnly.ACTION[80] = array2;
            OracleSqlReadOnly.ACTION[81] = array2;
            OracleSqlReadOnly.ACTION[82] = array2;
            OracleSqlReadOnly.ACTION[83] = array2;
            OracleSqlReadOnly.ACTION[84] = array2;
            OracleSqlReadOnly.ACTION[85] = array2;
            OracleSqlReadOnly.ACTION[86] = array2;
            OracleSqlReadOnly.ACTION[87] = copyReplacing15;
            OracleSqlReadOnly.ACTION[88] = copy2;
            OracleSqlReadOnly.ACTION[89] = array2;
            OracleSqlReadOnly.ACTION[90] = array2;
            OracleSqlReadOnly.ACTION[91] = array2;
            OracleSqlReadOnly.ACTION[92] = array2;
            OracleSqlReadOnly.ACTION[93] = array2;
            OracleSqlReadOnly.ACTION[94] = copyReplacing16;
            OracleSqlReadOnly.ACTION[95] = array2;
            OracleSqlReadOnly.ACTION[96] = array2;
            OracleSqlReadOnly.ACTION[97] = array2;
            OracleSqlReadOnly.ACTION[98] = array2;
            OracleSqlReadOnly.ACTION[99] = array2;
            (OracleSqlReadOnly.ACTION[115] = copy(array2))[63] = 14;
            OracleSqlReadOnly.ACTION[116] = array2;
            OracleSqlReadOnly.ACTION[117] = array2;
            OracleSqlReadOnly.ACTION[118] = array2;
            OracleSqlReadOnly.ACTION[119] = array2;
            OracleSqlReadOnly.ACTION[120] = array2;
            OracleSqlReadOnly.ACTION[121] = array2;
            OracleSqlReadOnly.ACTION[122] = array2;
            OracleSqlReadOnly.ACTION[123] = array2;
            OracleSqlReadOnly.ACTION[124] = array2;
            OracleSqlReadOnly.ACTION[125] = array2;
            OracleSqlReadOnly.ACTION[126] = array2;
            OracleSqlReadOnly.ACTION[127] = array2;
            OracleSqlReadOnly.ACTION[128] = array2;
            OracleSqlReadOnly.ACTION[129] = array2;
            OracleSqlReadOnly.ACTION[130] = array2;
            OracleSqlReadOnly.ACTION[131] = array2;
            OracleSqlReadOnly.ACTION[132] = array2;
            OracleSqlReadOnly.ACTION[133] = array2;
            final ODBCAction[] array5 = newArray(128, ODBCAction.NONE);
            final ODBCAction[] array6 = newArray(128, ODBCAction.COPY);
            final ODBCAction[] copy8 = copy(array6);
            copy8[123] = ODBCAction.NONE;
            copy8[63] = ODBCAction.QUESTION;
            copy8[125] = ODBCAction.END_ODBC_ESCAPE;
            copy8[44] = ODBCAction.COMMA;
            copy8[40] = ODBCAction.OPEN_PAREN;
            copy8[41] = ODBCAction.CLOSE_PAREN;
            final ODBCAction[] copyReplacing20 = copyReplacing(array6, ODBCAction.COPY, ODBCAction.SAVE_DELIMITER);
            final ODBCAction[] copyReplacing21 = copyReplacing(array6, ODBCAction.COPY, ODBCAction.LOOK_FOR_DELIMITER);
            final ODBCAction[] copy9 = copy(copyReplacing21);
            copy9[39] = ODBCAction.COPY;
            final ODBCAction[] array7 = newArray(128, ODBCAction.UNKNOWN_ESCAPE);
            final ODBCAction[] copy10 = copy(array5);
            for (int n = 0; n < array.length; ++n) {
                if (array[n] == 9) {
                    array7[n] = ODBCAction.UNKNOWN_ESCAPE;
                }
            }
            OracleSqlReadOnly.ODBC_ACTION[0] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[1] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[2] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[3] = array6;
            OracleSqlReadOnly.ODBC_ACTION[4] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[5] = array6;
            OracleSqlReadOnly.ODBC_ACTION[6] = array6;
            OracleSqlReadOnly.ODBC_ACTION[7] = array6;
            OracleSqlReadOnly.ODBC_ACTION[8] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[134] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[100] = array6;
            OracleSqlReadOnly.ODBC_ACTION[101] = array6;
            OracleSqlReadOnly.ODBC_ACTION[105] = array6;
            OracleSqlReadOnly.ODBC_ACTION[106] = copyReplacing20;
            OracleSqlReadOnly.ODBC_ACTION[107] = copyReplacing21;
            OracleSqlReadOnly.ODBC_ACTION[108] = null;
            OracleSqlReadOnly.ODBC_ACTION[109] = copy9;
            OracleSqlReadOnly.ODBC_ACTION[9] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[10] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[11] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[12] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[13] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[14] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[15] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[16] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[17] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[18] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[19] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[20] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[21] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[22] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[23] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[24] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[25] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[26] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[27] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[28] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[29] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[30] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[31] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[32] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[33] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[34] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[35] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[36] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[37] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[38] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[39] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[40] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[41] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[42] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[43] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[44] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[45] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[46] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[47] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[48] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[49] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[50] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[51] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[52] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[53] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[54] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[55] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[56] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[66] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[58] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[59] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[60] = array6;
            OracleSqlReadOnly.ODBC_ACTION[61] = array6;
            OracleSqlReadOnly.ODBC_ACTION[62] = array6;
            OracleSqlReadOnly.ODBC_ACTION[63] = array6;
            OracleSqlReadOnly.ODBC_ACTION[64] = array6;
            OracleSqlReadOnly.ODBC_ACTION[65] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[102] = array6;
            OracleSqlReadOnly.ODBC_ACTION[103] = array6;
            OracleSqlReadOnly.ODBC_ACTION[104] = array6;
            OracleSqlReadOnly.ODBC_ACTION[110] = array6;
            OracleSqlReadOnly.ODBC_ACTION[111] = copyReplacing20;
            OracleSqlReadOnly.ODBC_ACTION[112] = copyReplacing21;
            OracleSqlReadOnly.ODBC_ACTION[113] = null;
            OracleSqlReadOnly.ODBC_ACTION[114] = copy9;
            OracleSqlReadOnly.ODBC_ACTION[57] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[67] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[68] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[69] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[70] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[71] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[72] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[73] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[74] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[75] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[76] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[77] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[78] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[79] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[80] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[81] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[82] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[83] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[84] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[85] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[86] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[87] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[88] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[89] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[90] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[91] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[92] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[93] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[94] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[95] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[96] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[97] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[98] = copy8;
            OracleSqlReadOnly.ODBC_ACTION[99] = copy8;
            (OracleSqlReadOnly.ODBC_ACTION[115] = copy(copy10))[63] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][99] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][67] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][116] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][84] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][100] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][68] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][101] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][69] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][102] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][70] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][111] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[115][79] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[116] = newArray(128, ODBCAction.FUNCTION);
            (OracleSqlReadOnly.ODBC_ACTION[117] = copy(array7))[97] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[117][65] = ODBCAction.NONE;
            (OracleSqlReadOnly.ODBC_ACTION[118] = copy(array7))[108] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[118][76] = ODBCAction.NONE;
            (OracleSqlReadOnly.ODBC_ACTION[119] = copy(array7))[108] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[119][76] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[120] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.CALL);
            (OracleSqlReadOnly.ODBC_ACTION[121] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.TIME))[115] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[121][83] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[122] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.TIMESTAMP);
            OracleSqlReadOnly.ODBC_ACTION[123] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.DATE);
            (OracleSqlReadOnly.ODBC_ACTION[124] = copy(array7))[115] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[124][83] = ODBCAction.NONE;
            (OracleSqlReadOnly.ODBC_ACTION[125] = copy(array7))[99] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[125][67] = ODBCAction.NONE;
            (OracleSqlReadOnly.ODBC_ACTION[126] = copy(array7))[97] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[126][65] = ODBCAction.NONE;
            (OracleSqlReadOnly.ODBC_ACTION[127] = copy(array7))[112] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[127][80] = ODBCAction.NONE;
            (OracleSqlReadOnly.ODBC_ACTION[128] = copy(array7))[101] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[128][69] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[129] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.ESCAPE);
            (OracleSqlReadOnly.ODBC_ACTION[130] = copy(array7))[110] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[130][78] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[131] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.SCALAR_FUNCTION);
            (OracleSqlReadOnly.ODBC_ACTION[132] = copy(array7))[106] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[132][74] = ODBCAction.NONE;
            OracleSqlReadOnly.ODBC_ACTION[133] = copyReplacing(copy10, ODBCAction.NONE, ODBCAction.OUTER_JOIN);
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }
    
    enum ODBCAction
    {
        NONE, 
        COPY, 
        QUESTION, 
        SAVE_DELIMITER, 
        LOOK_FOR_DELIMITER, 
        FUNCTION, 
        CALL, 
        TIME, 
        TIMESTAMP, 
        DATE, 
        ESCAPE, 
        SCALAR_FUNCTION, 
        OUTER_JOIN, 
        UNKNOWN_ESCAPE, 
        END_ODBC_ESCAPE, 
        COMMA, 
        OPEN_PAREN, 
        CLOSE_PAREN;
    }
}
