// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;

class T4CNamedTypeAccessor extends NamedTypeAccessor
{
    static final int maxLength = Integer.MAX_VALUE;
    final int[] meta;
    T4CMAREngine mare;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    T4CNamedTypeAccessor(final OracleStatement oracleStatement, final String s, final short n, final int n2, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, s, n, n2, b);
        this.meta = new int[1];
        this.mare = mare;
    }
    
    T4CNamedTypeAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final String s, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, b, n2, n3, n4, n5, n6, n7, s);
        this.meta = new int[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        this.mare.unmarshalDALC();
        this.mare.unmarshalDALC();
        this.mare.unmarshalDALC();
        this.mare.unmarshalUB2();
        final long unmarshalUB4 = this.mare.unmarshalUB4();
        this.mare.unmarshalUB2();
        byte[] unmarshalCLR;
        if (unmarshalUB4 > 0L) {
            unmarshalCLR = this.mare.unmarshalCLR((int)unmarshalUB4, this.meta);
        }
        else {
            unmarshalCLR = new byte[0];
        }
        this.pickledBytes[this.lastRowProcessed] = unmarshalCLR;
        this.processIndicator(this.meta[0]);
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        if (this.rowSpaceIndicator != null) {
            if (this.meta[0] == 0) {
                this.rowSpaceIndicator[n] = -1;
                this.rowSpaceIndicator[n2] = 0;
            }
            else {
                this.rowSpaceIndicator[n2] = (short)this.meta[0];
                this.rowSpaceIndicator[n] = 0;
            }
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
