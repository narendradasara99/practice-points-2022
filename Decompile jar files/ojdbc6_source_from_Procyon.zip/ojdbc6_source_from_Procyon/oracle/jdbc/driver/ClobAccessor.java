// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.NCLOB;
import oracle.jdbc.OracleConnection;
import oracle.sql.CLOB;
import oracle.sql.Datum;
import java.util.Map;
import java.sql.SQLException;

class ClobAccessor extends Accessor
{
    static final int maxLength = 4000;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    ClobAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 112, 112, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    ClobAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 112, 112, n7, false);
        this.initForDescribe(112, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 4000;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getCLOB(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getCLOB(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getCLOB(n);
    }
    
    @Override
    CLOB getCLOB(final int n) throws SQLException {
        CLOB clob = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
            final byte[] array = new byte[n3];
            System.arraycopy(this.rowSpaceByte, n2, array, 0, n3);
            if (this.formOfUse == 1) {
                clob = new CLOB(this.statement.connection, array, this.formOfUse);
            }
            else {
                clob = new NCLOB(this.statement.connection, array);
            }
            if (this.lobPrefetchSizeForThisColumn != -1 && this.prefetchedLobSize != null) {
                clob.setActivePrefetch(true);
                clob.setLength(this.prefetchedLobSize[n]);
                clob.setChunkSize(this.prefetchedLobChunkSize[n]);
                if (this.prefetchedLobDataL != null && this.prefetchedLobDataL[n] > 0) {
                    this.initializeClobForPrefetch(n, clob);
                }
                else {
                    clob.setPrefetchedData(null);
                }
            }
        }
        return clob;
    }
    
    void initializeClobForPrefetch(final int n, final CLOB clob) throws SQLException {
        clob.setPrefetchedData(this.prefetchedLobCharData[n]);
    }
    
    @Override
    InputStream getAsciiStream(final int n) throws SQLException {
        final CLOB clob = this.getCLOB(n);
        if (clob == null) {
            return null;
        }
        return clob.getAsciiStream();
    }
    
    @Override
    Reader getCharacterStream(final int n) throws SQLException {
        final CLOB clob = this.getCLOB(n);
        if (clob == null) {
            return null;
        }
        return clob.getCharacterStream();
    }
    
    @Override
    InputStream getBinaryStream(final int n) throws SQLException {
        final CLOB clob = this.getCLOB(n);
        if (clob == null) {
            return null;
        }
        return clob.getAsciiStream();
    }
    
    @Override
    String getString(final int n) throws SQLException {
        final CLOB clob = this.getCLOB(n);
        if (clob == null) {
            return null;
        }
        final Reader characterStream = clob.getCharacterStream();
        final int bufferSize = clob.getBufferSize();
        final StringWriter stringWriter = new StringWriter(bufferSize);
        final char[] array = new char[bufferSize];
        try {
            int read;
            while ((read = characterStream.read(array)) != -1) {
                stringWriter.write(array, 0, read);
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (IndexOutOfBoundsException ex2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 151);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (clob.isTemporary()) {
            this.statement.addToTempLobsToFree(clob);
        }
        return stringWriter.getBuffer().substring(0);
    }
    
    @Override
    byte[] privateGetBytes(final int n) throws SQLException {
        return super.getBytes(n);
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
