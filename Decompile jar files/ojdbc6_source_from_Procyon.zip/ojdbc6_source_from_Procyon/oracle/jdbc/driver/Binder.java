// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;

abstract class Binder
{
    short type;
    int bytelen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    abstract Binder copyingBinder();
    
    abstract void bind(final OraclePreparedStatement p0, final int p1, final int p2, final int p3, final byte[] p4, final char[] p5, final short[] p6, final int p7, final int p8, final int p9, final int p10, final int p11, final int p12, final boolean p13) throws SQLException;
    
    @Override
    public String toString() {
        return this.getClass() + " [type = " + this.type + ", bytelen = " + this.bytelen + "]";
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    short updateInoutIndicatorValue(final short n) {
        return n;
    }
    
    void lastBoundValueCleanup(final OraclePreparedStatement oraclePreparedStatement, final int n) {
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
