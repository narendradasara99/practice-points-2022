// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.OracleResultSet;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.DATE;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.Ref;
import java.util.Map;
import java.sql.NClob;
import java.util.Calendar;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.Array;
import java.io.IOException;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

class OracleResultSetImpl extends BaseResultSet
{
    PhysicalConnection connection;
    OracleStatement statement;
    boolean explicitly_closed;
    boolean m_emptyRset;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleResultSetImpl(final PhysicalConnection connection, final OracleStatement statement) throws SQLException {
        this.connection = connection;
        this.statement = statement;
        this.close_statement_on_close = false;
        this.explicitly_closed = false;
        this.m_emptyRset = false;
    }
    
    @Override
    public String getCursorName() throws SQLException {
        synchronized (this.connection) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "getCursorName");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void close() throws SQLException {
        synchronized (this.connection) {
            this.internal_close(false);
            this.statement.totalRowsVisited = 0;
            if (this.close_statement_on_close) {
                try {
                    this.statement.close();
                }
                catch (SQLException ex) {}
            }
            this.explicitly_closed = true;
        }
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        synchronized (this.connection) {
            return this.statement.wasNullValue();
        }
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        synchronized (this.connection) {
            if (this.explicitly_closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10, "getMetaData");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.statement.closed) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9, "getMetaData");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (!this.statement.isOpen) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 144, "getMetaData");
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            return new OracleResultSetMetaData(this.connection, this.statement);
        }
    }
    
    @Override
    public Statement getStatement() throws SQLException {
        synchronized (this.connection) {
            return (this.statement.wrapper == null) ? this.statement : this.statement.wrapper;
        }
    }
    
    @Override
    OracleStatement getOracleStatement() throws SQLException {
        synchronized (this.connection) {
            return this.statement;
        }
    }
    
    @Override
    public boolean next() throws SQLException {
        synchronized (this.connection) {
            boolean close_or_fetch_from_next = true;
            final PhysicalConnection connection = this.statement.connection;
            if (this.explicitly_closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10, "next");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (connection == null || connection.lifecycle != 1) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8, "next");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (this.statement.closed) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9, "next");
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64) {
                final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 166, "next");
                sqlException4.fillInStackTrace();
                throw sqlException4;
            }
            if (this.closed) {
                return false;
            }
            final OracleStatement statement = this.statement;
            ++statement.currentRow;
            final OracleStatement statement2 = this.statement;
            ++statement2.totalRowsVisited;
            if (this.statement.maxRows != 0 && this.statement.totalRowsVisited > this.statement.maxRows) {
                this.internal_close(false);
                final OracleStatement statement3 = this.statement;
                --statement3.currentRow;
                final OracleStatement statement4 = this.statement;
                --statement4.totalRowsVisited;
                return false;
            }
            if (this.statement.currentRow >= this.statement.validRows) {
                close_or_fetch_from_next = this.close_or_fetch_from_next(false);
            }
            if (close_or_fetch_from_next && connection.useFetchSizeWithLongColumn) {
                this.statement.reopenStreams();
            }
            if (!close_or_fetch_from_next) {
                final OracleStatement statement5 = this.statement;
                --statement5.currentRow;
                final OracleStatement statement6 = this.statement;
                --statement6.totalRowsVisited;
            }
            return close_or_fetch_from_next;
        }
    }
    
    private boolean close_or_fetch_from_next(final boolean b) throws SQLException {
        if (b) {
            this.internal_close(false);
            return false;
        }
        if (this.statement.gotLastBatch) {
            this.internal_close(false);
            return false;
        }
        this.statement.check_row_prefetch_changed();
        final PhysicalConnection connection = this.statement.connection;
        if (connection.protocolId == 3) {
            this.sqlWarning = null;
        }
        else {
            if (this.statement.streamList != null) {
                while (this.statement.nextStream != null) {
                    try {
                        this.statement.nextStream.close();
                    }
                    catch (IOException ex) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    this.statement.nextStream = this.statement.nextStream.nextStream;
                }
            }
            this.clearWarnings();
            connection.registerHeartbeat();
            connection.needLine();
        }
        synchronized (connection) {
            try {
                this.statement.isExecuting = true;
                this.statement.fetch();
            }
            finally {
                this.statement.isExecuting = false;
            }
        }
        if (this.statement.validRows == 0) {
            this.internal_close(false);
            return false;
        }
        this.statement.currentRow = 0;
        this.statement.checkValidRowsStatus();
        return true;
    }
    
    @Override
    public boolean isBeforeFirst() throws SQLException {
        if (this.explicitly_closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.statement != null && this.statement.connection.protocolId != 3 && !this.statement.closed && this.statement.serverCursor) {
            if (this.statement.validRows < 1) {
                this.close_or_fetch_from_next(false);
            }
            if (this.statement.validRows > 0) {
                this.statement.currentRow = -1;
            }
            else {
                this.m_emptyRset = true;
            }
        }
        if (this.statement.connection.protocolId == 3 && this.statement.serverCursor) {
            final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
            unsupportedFeatureSqlException.fillInStackTrace();
            throw unsupportedFeatureSqlException;
        }
        return !this.isEmptyResultSet() && this.statement.currentRow == -1 && !this.closed;
    }
    
    @Override
    public boolean isAfterLast() throws SQLException {
        if (this.explicitly_closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return !this.isEmptyResultSet() && this.closed;
    }
    
    @Override
    public boolean isFirst() throws SQLException {
        if (this.explicitly_closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getRow() == 1;
    }
    
    @Override
    public boolean isLast() throws SQLException {
        if (this.explicitly_closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 75, "isLast");
        sqlException2.fillInStackTrace();
        throw sqlException2;
    }
    
    @Override
    public int getRow() throws SQLException {
        if (this.explicitly_closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.statement.totalRowsVisited;
    }
    
    @Override
    public Array getArray(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getARRAY(n);
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBigDecimal(currentRow);
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int lastIndex, final int n) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBigDecimal(currentRow, n);
        }
    }
    
    @Override
    public Blob getBlob(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getBLOB(n);
        }
    }
    
    @Override
    public boolean getBoolean(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBoolean(currentRow);
        }
    }
    
    @Override
    public byte getByte(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getByte(currentRow);
        }
    }
    
    @Override
    public byte[] getBytes(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBytes(currentRow);
        }
    }
    
    @Override
    public Clob getClob(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getCLOB(n);
        }
    }
    
    @Override
    public Date getDate(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getDate(currentRow);
        }
    }
    
    @Override
    public Date getDate(final int lastIndex, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getDate(currentRow, calendar);
        }
    }
    
    @Override
    public double getDouble(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getDouble(currentRow);
        }
    }
    
    @Override
    public float getFloat(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getFloat(currentRow);
        }
    }
    
    @Override
    public int getInt(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getInt(currentRow);
        }
    }
    
    @Override
    public long getLong(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getLong(currentRow);
        }
    }
    
    @Override
    public NClob getNClob(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getNClob(currentRow);
        }
    }
    
    @Override
    public String getNString(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getNString(currentRow);
        }
    }
    
    @Override
    public Object getObject(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getObject(currentRow);
        }
    }
    
    @Override
    public Object getObject(final int lastIndex, final Map map) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getObject(currentRow, map);
        }
    }
    
    @Override
    public Ref getRef(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getREF(n);
        }
    }
    
    @Override
    public RowId getRowId(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getROWID(n);
        }
    }
    
    @Override
    public short getShort(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getShort(currentRow);
        }
    }
    
    @Override
    public SQLXML getSQLXML(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getSQLXML(currentRow);
        }
    }
    
    @Override
    public String getString(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getString(currentRow);
        }
    }
    
    @Override
    public Time getTime(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTime(currentRow);
        }
    }
    
    @Override
    public Time getTime(final int lastIndex, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTime(currentRow, calendar);
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTimestamp(currentRow);
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int lastIndex, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTimestamp(currentRow, calendar);
        }
    }
    
    @Override
    public URL getURL(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getURL(currentRow);
        }
    }
    
    @Override
    public ARRAY getARRAY(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getARRAY(currentRow);
        }
    }
    
    @Override
    public BFILE getBFILE(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBFILE(currentRow);
        }
    }
    
    @Override
    public BFILE getBfile(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getBFILE(n);
        }
    }
    
    @Override
    public BLOB getBLOB(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBLOB(currentRow);
        }
    }
    
    @Override
    public CHAR getCHAR(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getCHAR(currentRow);
        }
    }
    
    @Override
    public CLOB getCLOB(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getCLOB(currentRow);
        }
    }
    
    @Override
    public ResultSet getCursor(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getCursor(currentRow);
        }
    }
    
    @Override
    public CustomDatum getCustomDatum(final int lastIndex, final CustomDatumFactory customDatumFactory) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getCustomDatum(currentRow, customDatumFactory);
        }
    }
    
    @Override
    public DATE getDATE(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getDATE(currentRow);
        }
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getINTERVALDS(currentRow);
        }
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getINTERVALYM(currentRow);
        }
    }
    
    @Override
    public NUMBER getNUMBER(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getNUMBER(currentRow);
        }
    }
    
    @Override
    public OPAQUE getOPAQUE(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getOPAQUE(currentRow);
        }
    }
    
    @Override
    public Datum getOracleObject(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getOracleObject(currentRow);
        }
    }
    
    @Override
    public ORAData getORAData(final int lastIndex, final ORADataFactory oraDataFactory) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getORAData(currentRow, oraDataFactory);
        }
    }
    
    @Override
    public RAW getRAW(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getRAW(currentRow);
        }
    }
    
    @Override
    public REF getREF(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getREF(currentRow);
        }
    }
    
    @Override
    public ROWID getROWID(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getROWID(currentRow);
        }
    }
    
    @Override
    public STRUCT getSTRUCT(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getSTRUCT(currentRow);
        }
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTIMESTAMPLTZ(currentRow);
        }
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTIMESTAMPTZ(currentRow);
        }
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getTIMESTAMP(currentRow);
        }
    }
    
    @Override
    public InputStream getAsciiStream(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getAsciiStream(currentRow);
        }
    }
    
    @Override
    public InputStream getBinaryStream(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getBinaryStream(currentRow);
        }
    }
    
    @Override
    public Reader getCharacterStream(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getCharacterStream(currentRow);
        }
    }
    
    @Override
    public Reader getNCharacterStream(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getNCharacterStream(currentRow);
        }
    }
    
    @Override
    public InputStream getUnicodeStream(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getUnicodeStream(currentRow);
        }
    }
    
    @Override
    public AuthorizationIndicator getAuthorizationIndicator(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].getAuthorizationIndicator(currentRow);
        }
    }
    
    byte[] privateGetBytes(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.closed) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (lastIndex <= 0 || lastIndex > this.statement.numberOfDefinePositions) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            final int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14);
                sqlException4.fillInStackTrace();
                throw sqlException4;
            }
            this.statement.lastIndex = lastIndex;
            if (this.statement.streamList != null) {
                this.statement.closeUsedStreams(lastIndex);
            }
            return this.statement.accessors[lastIndex - 1].privateGetBytes(currentRow);
        }
    }
    
    @Override
    public void setFetchSize(final int n) throws SQLException {
        this.statement.setPrefetchInternal(n, false, false);
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        return this.statement.getPrefetchInternal(false);
    }
    
    void internal_close(final boolean b) throws SQLException {
        if (this.closed) {
            return;
        }
        super.close();
        if (this.statement.gotLastBatch && this.statement.validRows == 0) {
            this.m_emptyRset = true;
        }
        final PhysicalConnection connection = this.statement.connection;
        try {
            connection.registerHeartbeat();
            connection.needLine();
            synchronized (connection) {
                this.statement.closeQuery();
            }
        }
        catch (SQLException ex) {}
        this.statement.endOfResultSet(b);
    }
    
    @Override
    public int findColumn(final String s) throws SQLException {
        synchronized (this.connection) {
            return this.statement.getColumnIndex(s);
        }
    }
    
    boolean isEmptyResultSet() {
        return this.m_emptyRset || (!this.m_emptyRset && this.statement.gotLastBatch && this.statement.validRows == 0);
    }
    
    int getValidRows() {
        return this.statement.validRows;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
