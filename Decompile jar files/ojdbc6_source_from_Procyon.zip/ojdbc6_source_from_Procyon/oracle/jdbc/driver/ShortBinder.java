// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class ShortBinder extends VarnumBinder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        final int n10 = n6 + 1;
        final int n11 = oraclePreparedStatement.parameterInt[n3][n];
        int n12;
        if (n11 == 0) {
            array[n10] = -128;
            n12 = 1;
        }
        else if (n11 < 0) {
            if (-n11 < 100) {
                array[n10] = 62;
                array[n10 + 1] = (byte)(101 + n11);
                array[n10 + 2] = 102;
                n12 = 3;
            }
            else if (-n11 < 10000) {
                array[n10] = 61;
                array[n10 + 1] = (byte)(101 - -n11 / 100);
                final int n13 = -n11 % 100;
                if (n13 != 0) {
                    array[n10 + 2] = (byte)(101 - n13);
                    array[n10 + 3] = 102;
                    n12 = 4;
                }
                else {
                    array[n10 + 2] = 102;
                    n12 = 3;
                }
            }
            else {
                array[n10] = 60;
                array[n10 + 1] = (byte)(101 - -n11 / 10000);
                final int n14 = -n11 % 100;
                if (n14 != 0) {
                    array[n10 + 2] = (byte)(101 - -n11 % 10000 / 100);
                    array[n10 + 3] = (byte)(101 - n14);
                    array[n10 + 4] = 102;
                    n12 = 5;
                }
                else {
                    final int n15 = -n11 % 10000 / 100;
                    if (n15 != 0) {
                        array[n10 + 2] = (byte)(101 - n15);
                        array[n10 + 3] = 102;
                        n12 = 4;
                    }
                    else {
                        array[n10 + 2] = 102;
                        n12 = 3;
                    }
                }
            }
        }
        else if (n11 < 100) {
            array[n10] = -63;
            array[n10 + 1] = (byte)(n11 + 1);
            n12 = 2;
        }
        else if (n11 < 10000) {
            array[n10] = -62;
            array[n10 + 1] = (byte)(n11 / 100 + 1);
            final int n16 = n11 % 100;
            if (n16 != 0) {
                array[n10 + 2] = (byte)(n16 + 1);
                n12 = 3;
            }
            else {
                n12 = 2;
            }
        }
        else {
            array[n10] = -61;
            array[n10 + 1] = (byte)(n11 / 10000 + 1);
            final int n17 = n11 % 100;
            if (n17 != 0) {
                array[n10 + 2] = (byte)(n11 % 10000 / 100 + 1);
                array[n10 + 3] = (byte)(n17 + 1);
                n12 = 4;
            }
            else {
                final int n18 = n11 % 10000 / 100;
                if (n18 != 0) {
                    array[n10 + 2] = (byte)(n18 + 1);
                    n12 = 3;
                }
                else {
                    n12 = 2;
                }
            }
        }
        array[n6] = (byte)n12;
        array3[n9] = 0;
        array3[n8] = (short)(n12 + 1);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
