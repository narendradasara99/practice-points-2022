// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleTypeREF;
import oracle.jdbc.oracore.OracleTypeRAW;
import oracle.jdbc.oracore.OracleTypeCHAR;
import oracle.jdbc.oracore.OracleTypeFLOAT;
import oracle.jdbc.oracore.OracleTypeNUMBER;
import oracle.jdbc.OracleResultSetMetaData;
import java.sql.SQLException;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.StructDescriptor;

class StructMetaData implements oracle.jdbc.internal.StructMetaData
{
    StructDescriptor descriptor;
    OracleTypeADT otype;
    OracleType[] types;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public StructMetaData(final StructDescriptor descriptor) throws SQLException {
        if (descriptor == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "illegal operation: descriptor is null");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.descriptor = descriptor;
        this.otype = descriptor.getOracleTypeADT();
        this.types = this.otype.getAttrTypes();
    }
    
    @Override
    public int getColumnCount() throws SQLException {
        return this.types.length;
    }
    
    @Override
    public boolean isAutoIncrement(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public boolean isSearchable(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(final int n) throws SQLException {
        return OracleResultSetMetaData.SecurityAttribute.NONE;
    }
    
    @Override
    public boolean isCurrency(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        return this.types[validColumnIndex] instanceof OracleTypeNUMBER || this.types[validColumnIndex] instanceof OracleTypeFLOAT;
    }
    
    @Override
    public boolean isCaseSensitive(final int n) throws SQLException {
        return this.types[this.getValidColumnIndex(n)] instanceof OracleTypeCHAR;
    }
    
    @Override
    public int isNullable(final int n) throws SQLException {
        return 1;
    }
    
    @Override
    public boolean isSigned(final int n) throws SQLException {
        return true;
    }
    
    @Override
    public int getColumnDisplaySize(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        if (this.types[validColumnIndex] instanceof OracleTypeCHAR) {
            return ((OracleTypeCHAR)this.types[validColumnIndex]).getLength();
        }
        if (this.types[validColumnIndex] instanceof OracleTypeRAW) {
            return ((OracleTypeRAW)this.types[validColumnIndex]).getLength();
        }
        return 0;
    }
    
    @Override
    public String getColumnLabel(final int n) throws SQLException {
        return this.getColumnName(n);
    }
    
    @Override
    public String getColumnName(final int n) throws SQLException {
        return this.otype.getAttributeName(n);
    }
    
    @Override
    public String getSchemaName(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        if (this.types[validColumnIndex] instanceof OracleTypeADT) {
            return ((OracleTypeADT)this.types[validColumnIndex]).getSchemaName();
        }
        return "";
    }
    
    @Override
    public int getPrecision(final int n) throws SQLException {
        return this.types[this.getValidColumnIndex(n)].getPrecision();
    }
    
    @Override
    public int getScale(final int n) throws SQLException {
        return this.types[this.getValidColumnIndex(n)].getScale();
    }
    
    @Override
    public String getTableName(final int n) throws SQLException {
        return null;
    }
    
    @Override
    public String getCatalogName(final int n) throws SQLException {
        return null;
    }
    
    @Override
    public int getColumnType(final int n) throws SQLException {
        return this.types[this.getValidColumnIndex(n)].getTypeCode();
    }
    
    @Override
    public String getColumnTypeName(final int n) throws SQLException {
        final int columnType = this.getColumnType(n);
        final int validColumnIndex = this.getValidColumnIndex(n);
        switch (columnType) {
            case 12: {
                return "VARCHAR";
            }
            case 1: {
                return "CHAR";
            }
            case -2: {
                return "RAW";
            }
            case 6: {
                return "FLOAT";
            }
            case 2: {
                return "NUMBER";
            }
            case 8: {
                return "DOUBLE";
            }
            case 3: {
                return "DECIMAL";
            }
            case 100: {
                return "BINARY_FLOAT";
            }
            case 101: {
                return "BINARY_DOUBLE";
            }
            case 91: {
                return "DATE";
            }
            case -104: {
                return "INTERVALDS";
            }
            case -103: {
                return "INTERVALYM";
            }
            case 93: {
                return "TIMESTAMP";
            }
            case -101: {
                return "TIMESTAMP WITH TIME ZONE";
            }
            case -102: {
                return "TIMESTAMP WITH LOCAL TIME ZONE";
            }
            case 2004: {
                return "BLOB";
            }
            case 2005: {
                return "CLOB";
            }
            case -13: {
                return "BFILE";
            }
            case 2002:
            case 2003:
            case 2007:
            case 2008: {
                return ((OracleTypeADT)this.types[validColumnIndex]).getFullName();
            }
            case 2006: {
                return "REF " + ((OracleTypeREF)this.types[validColumnIndex]).getFullName();
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public boolean isReadOnly(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public boolean isWritable(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public boolean isDefinitelyWritable(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public String getColumnClassName(final int n) throws SQLException {
        switch (this.getColumnType(n)) {
            case 1:
            case 12: {
                return "java.lang.String";
            }
            case -2: {
                return "byte[]";
            }
            case 2:
            case 3:
            case 6:
            case 8: {
                return "java.math.BigDecimal";
            }
            case 91: {
                return "java.sql.Timestamp";
            }
            case -103: {
                return "oracle.sql.INTERVALYM";
            }
            case -104: {
                return "oracle.sql.INTERVALDS";
            }
            case 93: {
                return "oracle.sql.TIMESTAMP";
            }
            case -101: {
                return "oracle.sql.TIMESTAMPTZ";
            }
            case -102: {
                return "oracle.sql.TIMESTAMPLTZ";
            }
            case 2004: {
                return "oracle.sql.BLOB";
            }
            case 2005: {
                return "oracle.sql.CLOB";
            }
            case -13: {
                return "oracle.sql.BFILE";
            }
            case 2002:
            case 2008: {
                return "oracle.sql.STRUCT";
            }
            case 2007: {
                return "oracle.sql.OPAQUE";
            }
            case 2003: {
                return "oracle.sql.ARRAY";
            }
            case 2006: {
                return "oracle.sql.REF";
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public String getOracleColumnClassName(final int n) throws SQLException {
        switch (this.getColumnType(n)) {
            case 1:
            case 12: {
                return "CHAR";
            }
            case -2: {
                return "RAW";
            }
            case 2:
            case 3:
            case 6:
            case 8: {
                return "NUMBER";
            }
            case 91: {
                return "DATE";
            }
            case -103: {
                return "INTERVALYM";
            }
            case -104: {
                return "INTERVALDS";
            }
            case 93: {
                return "TIMESTAMP";
            }
            case -101: {
                return "TIMESTAMPTZ";
            }
            case -102: {
                return "TIMESTAMPLTZ";
            }
            case 2004: {
                return "BLOB";
            }
            case 2005: {
                return "CLOB";
            }
            case -13: {
                return "BFILE";
            }
            case 2002: {
                return "STRUCT";
            }
            case 2008: {
                return "JAVA_STRUCT";
            }
            case 2007: {
                return "OPAQUE";
            }
            case 2003: {
                return "ARRAY";
            }
            case 2006: {
                return "REF";
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public int getLocalColumnCount() throws SQLException {
        return this.descriptor.getLocalAttributeCount();
    }
    
    @Override
    public boolean isInherited(final int n) throws SQLException {
        return n <= this.getColumnCount() - this.getLocalColumnCount();
    }
    
    @Override
    public String getAttributeJavaName(final int n) throws SQLException {
        return this.descriptor.getAttributeJavaName(this.getValidColumnIndex(n));
    }
    
    private int getValidColumnIndex(final int n) throws SQLException {
        final int n2 = n - 1;
        if (n2 < 0 || n2 >= this.types.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3, "getValidColumnIndex");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return n2;
    }
    
    @Override
    public boolean isNCHAR(final int n) throws SQLException {
        return this.types[this.getValidColumnIndex(n)].isNCHAR();
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
