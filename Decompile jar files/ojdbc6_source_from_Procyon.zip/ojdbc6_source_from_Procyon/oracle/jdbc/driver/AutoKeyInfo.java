// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class AutoKeyInfo extends OracleResultSetMetaData
{
    String originalSql;
    String newSql;
    String tableName;
    byte sqlKind;
    int sqlParserParamCount;
    String[] sqlParserParamList;
    boolean useNamedParameter;
    int current_argument;
    String[] columnNames;
    int[] columnIndexes;
    int numColumns;
    String[] tableColumnNames;
    int[] tableColumnTypes;
    int[] tableMaxLengths;
    boolean[] tableNullables;
    short[] tableFormOfUses;
    int[] tablePrecisions;
    int[] tableScales;
    String[] tableTypeNames;
    int autoKeyType;
    static final int KEYFLAG = 0;
    static final int COLUMNAME = 1;
    static final int COLUMNINDEX = 2;
    static final char QMARK = '?';
    int[] returnTypes;
    Accessor[] returnAccessors;
    private static final ThreadLocal<OracleSql> SQL_PARSER;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    AutoKeyInfo(final String originalSql) {
        this.sqlKind = 0;
        this.originalSql = originalSql;
        this.autoKeyType = 0;
    }
    
    AutoKeyInfo(final String originalSql, final String[] columnNames) {
        this.sqlKind = 0;
        this.originalSql = originalSql;
        this.columnNames = columnNames;
        this.autoKeyType = 1;
    }
    
    AutoKeyInfo(final String originalSql, final int[] columnIndexes) {
        this.sqlKind = 0;
        this.originalSql = originalSql;
        this.columnIndexes = columnIndexes;
        this.autoKeyType = 2;
    }
    
    private void parseSql() throws SQLException {
        if (this.originalSql == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final OracleSql oracleSql = AutoKeyInfo.SQL_PARSER.get();
        oracleSql.initialize(this.originalSql);
        this.sqlKind = oracleSql.getSqlKind();
        if (this.sqlKind == 4) {
            this.sqlParserParamCount = oracleSql.getParameterCount();
            this.sqlParserParamList = oracleSql.getParameterList();
            if (this.sqlParserParamList == OracleSql.EMPTY_LIST) {
                this.useNamedParameter = false;
            }
            else {
                this.useNamedParameter = true;
                this.current_argument = this.sqlParserParamCount;
            }
        }
    }
    
    private String generateUniqueNamedParameter() {
        boolean b;
        String intern;
        do {
            b = false;
            intern = Integer.toString(++this.current_argument).intern();
            for (int i = 0; i < this.sqlParserParamCount; ++i) {
                if (this.sqlParserParamList[i] == intern) {
                    b = true;
                    break;
                }
            }
        } while (b);
        return ":" + intern;
    }
    
    String getNewSql() throws SQLException {
        try {
            if (this.newSql != null) {
                return this.newSql;
            }
            if (this.sqlKind == 0) {
                this.parseSql();
            }
            switch (this.autoKeyType) {
                case 0: {
                    this.newSql = this.originalSql + " RETURNING ROWID INTO " + (this.useNamedParameter ? this.generateUniqueNamedParameter() : Character.valueOf('?'));
                    (this.returnTypes = new int[1])[0] = 104;
                    break;
                }
                case 1: {
                    this.getNewSqlByColumnName();
                    break;
                }
                case 2: {
                    this.getNewSqlByColumnIndexes();
                    break;
                }
            }
            this.sqlKind = 0;
            this.sqlParserParamList = null;
            return this.newSql;
        }
        catch (Exception ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    private String getNewSqlByColumnName() throws SQLException {
        this.returnTypes = new int[this.columnNames.length];
        this.columnIndexes = new int[this.columnNames.length];
        final StringBuffer buffer = new StringBuffer(this.originalSql);
        buffer.append(" RETURNING ");
        for (int i = 0; i < this.columnNames.length; ++i) {
            this.returnTypes[i] = this.getReturnParamTypeCode(i, this.columnNames[i], this.columnIndexes);
            buffer.append(this.columnNames[i]);
            if (i < this.columnNames.length - 1) {
                buffer.append(", ");
            }
        }
        buffer.append(" INTO ");
        for (int j = 0; j < this.columnNames.length - 1; ++j) {
            buffer.append((this.useNamedParameter ? this.generateUniqueNamedParameter() : Character.valueOf('?')) + ", ");
        }
        buffer.append(this.useNamedParameter ? this.generateUniqueNamedParameter() : Character.valueOf('?'));
        return this.newSql = new String(buffer);
    }
    
    private String getNewSqlByColumnIndexes() throws SQLException {
        this.returnTypes = new int[this.columnIndexes.length];
        final StringBuffer buffer = new StringBuffer(this.originalSql);
        buffer.append(" RETURNING ");
        for (int i = 0; i < this.columnIndexes.length; ++i) {
            final int n = this.columnIndexes[i] - 1;
            if (n < 0 || n > this.tableColumnNames.length) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int n2 = this.tableColumnTypes[n];
            final String str = this.tableColumnNames[n];
            this.returnTypes[i] = n2;
            buffer.append(str);
            if (i < this.columnIndexes.length - 1) {
                buffer.append(", ");
            }
        }
        buffer.append(" INTO ");
        for (int j = 0; j < this.columnIndexes.length - 1; ++j) {
            buffer.append((this.useNamedParameter ? this.generateUniqueNamedParameter() : Character.valueOf('?')) + ", ");
        }
        buffer.append(this.useNamedParameter ? this.generateUniqueNamedParameter() : Character.valueOf('?'));
        return this.newSql = new String(buffer);
    }
    
    private final int getReturnParamTypeCode(final int n, final String s, final int[] array) throws SQLException {
        for (int i = 0; i < this.tableColumnNames.length; ++i) {
            if (s.equalsIgnoreCase(this.tableColumnNames[i])) {
                array[n] = i + 1;
                return this.tableColumnTypes[i];
            }
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    final boolean isInsertSqlStmt() throws SQLException {
        if (this.sqlKind == 0) {
            this.parseSql();
        }
        return this.sqlKind == 4;
    }
    
    String getTableName() throws SQLException {
        if (this.tableName != null) {
            return this.tableName;
        }
        final String upperCase = this.originalSql.trim().toUpperCase();
        final int index = upperCase.indexOf("INTO", upperCase.indexOf("INSERT"));
        if (index < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        int length;
        int n;
        for (length = upperCase.length(), n = index + 5; n < length && upperCase.charAt(n) == ' '; ++n) {}
        if (n >= length) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        int endIndex;
        for (endIndex = n + 1; endIndex < length && upperCase.charAt(endIndex) != ' ' && upperCase.charAt(endIndex) != '('; ++endIndex) {}
        if (n == endIndex - 1) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        return this.tableName = upperCase.substring(n, endIndex);
    }
    
    void allocateSpaceForDescribedData(final int numColumns) throws SQLException {
        this.numColumns = numColumns;
        this.tableColumnNames = new String[numColumns];
        this.tableColumnTypes = new int[numColumns];
        this.tableMaxLengths = new int[numColumns];
        this.tableNullables = new boolean[numColumns];
        this.tableFormOfUses = new short[numColumns];
        this.tablePrecisions = new int[numColumns];
        this.tableScales = new int[numColumns];
        this.tableTypeNames = new String[numColumns];
    }
    
    void fillDescribedData(final int n, final String s, final int n2, final int n3, final boolean b, final short n4, final int n5, final int n6, final String s2) throws SQLException {
        this.tableColumnNames[n] = s;
        this.tableColumnTypes[n] = n2;
        this.tableMaxLengths[n] = n3;
        this.tableNullables[n] = b;
        this.tableFormOfUses[n] = n4;
        this.tablePrecisions[n] = n5;
        this.tableScales[n] = n6;
        this.tableTypeNames[n] = s2;
    }
    
    void initMetaData(final OracleReturnResultSet set) throws SQLException {
        if (this.returnAccessors != null) {
            return;
        }
        this.returnAccessors = set.returnAccessors;
        switch (this.autoKeyType) {
            case 0: {
                this.initMetaDataKeyFlag();
                break;
            }
            case 1:
            case 2: {
                this.initMetaDataColumnIndexes();
                break;
            }
        }
    }
    
    void initMetaDataKeyFlag() throws SQLException {
        this.returnAccessors[0].columnName = "ROWID";
        this.returnAccessors[0].describeType = 104;
        this.returnAccessors[0].describeMaxLength = 4;
        this.returnAccessors[0].nullable = true;
        this.returnAccessors[0].precision = 0;
        this.returnAccessors[0].scale = 0;
        this.returnAccessors[0].formOfUse = 0;
    }
    
    void initMetaDataColumnIndexes() throws SQLException {
        for (int i = 0; i < this.returnAccessors.length; ++i) {
            final Accessor accessor = this.returnAccessors[i];
            final int n = this.columnIndexes[i] - 1;
            accessor.columnName = this.tableColumnNames[n];
            accessor.describeType = this.tableColumnTypes[n];
            accessor.describeMaxLength = this.tableMaxLengths[n];
            accessor.nullable = this.tableNullables[n];
            accessor.precision = this.tablePrecisions[n];
            accessor.scale = this.tablePrecisions[n];
            accessor.formOfUse = this.tableFormOfUses[n];
        }
    }
    
    @Override
    int getValidColumnIndex(final int n) throws SQLException {
        if (n <= 0 || n > this.returnAccessors.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return n - 1;
    }
    
    @Override
    public int getColumnCount() throws SQLException {
        return this.returnAccessors.length;
    }
    
    @Override
    public String getColumnName(final int n) throws SQLException {
        if (n <= 0 || n > this.returnAccessors.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.returnAccessors[n - 1].columnName;
    }
    
    @Override
    public String getTableName(final int n) throws SQLException {
        if (n <= 0 || n > this.returnAccessors.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.getTableName();
    }
    
    @Override
    Accessor[] getDescription() throws SQLException {
        return this.returnAccessors;
    }
    
    static {
        SQL_PARSER = new ThreadLocal() {
            @Override
            protected OracleSql initialValue() {
                return new OracleSql(null);
            }
        };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
