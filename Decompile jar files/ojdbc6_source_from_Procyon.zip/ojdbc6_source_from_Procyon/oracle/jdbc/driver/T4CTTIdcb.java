// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.oracore.OracleTypeADT;
import java.io.IOException;
import java.sql.SQLException;

class T4CTTIdcb extends T4CTTIMsg
{
    static final int DCBRXFR = 1;
    static final int DCBFIOT = 2;
    static final int DCBFHAVECOOKIE = 4;
    static final int DCBFNEWCOOKIE = 8;
    static final int DCBFREM = 16;
    int numuds;
    int colOffset;
    byte[] ignoreBuff;
    StringBuffer colNameSB;
    OracleStatement statement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIdcb(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)16);
        this.colNameSB = null;
        this.statement = null;
        this.ignoreBuff = new byte[40];
    }
    
    void init(final OracleStatement statement, final int colOffset) {
        this.statement = statement;
        this.colOffset = colOffset;
    }
    
    Accessor[] receive(Accessor[] receiveCommon) throws SQLException, IOException {
        final short unmarshalUB1 = this.meg.unmarshalUB1();
        if (this.ignoreBuff.length < unmarshalUB1) {
            this.ignoreBuff = new byte[unmarshalUB1];
        }
        this.meg.unmarshalNBytes(this.ignoreBuff, 0, unmarshalUB1);
        final int n = (int)this.meg.unmarshalUB4();
        receiveCommon = this.receiveCommon(receiveCommon, false);
        return receiveCommon;
    }
    
    Accessor[] receiveFromRefCursor(Accessor[] receiveCommon) throws SQLException, IOException {
        this.meg.unmarshalUB1();
        final int n = (int)this.meg.unmarshalUB4();
        receiveCommon = this.receiveCommon(receiveCommon, false);
        return receiveCommon;
    }
    
    Accessor[] receiveCommon(Accessor[] accessors, final boolean b) throws SQLException, IOException {
        if (b) {
            this.numuds = this.meg.unmarshalUB2();
        }
        else {
            this.numuds = (int)this.meg.unmarshalUB4();
            if (this.numuds > 0) {
                this.meg.unmarshalUB1();
            }
        }
        if (this.statement.needToPrepareDefineBuffer && (accessors == null || accessors.length != this.numuds + this.colOffset)) {
            final Accessor[] array = new Accessor[this.numuds + this.colOffset];
            if (accessors != null && accessors.length == this.colOffset) {
                System.arraycopy(accessors, 0, array, 0, this.colOffset);
            }
            accessors = array;
        }
        final T4C8TTIuds t4C8TTIuds = new T4C8TTIuds((T4CConnection)this.statement.connection);
        for (int i = 0; i < this.numuds; ++i) {
            t4C8TTIuds.unmarshal();
            final String charBytesToString = this.meg.conv.CharBytesToString(t4C8TTIuds.getColumName(), t4C8TTIuds.getColumNameByteLength());
            if (this.statement.needToPrepareDefineBuffer) {
                this.fillupAccessors(accessors, this.colOffset + i, t4C8TTIuds, charBytesToString);
            }
        }
        if (!b) {
            this.meg.unmarshalDALC();
            if (this.connection.getTTCVersion() >= 3) {
                final int n = (int)this.meg.unmarshalUB4();
                final int n2 = (int)this.meg.unmarshalUB4();
                if (this.connection.getTTCVersion() >= 4) {
                    final int n3 = (int)this.meg.unmarshalUB4();
                    final int n4 = (int)this.meg.unmarshalUB4();
                    if (this.connection.getTTCVersion() >= 5) {
                        this.meg.unmarshalDALC();
                    }
                }
            }
        }
        if (this.statement.needToPrepareDefineBuffer && !b) {
            this.statement.rowPrefetchInLastFetch = -1;
            this.statement.describedWithNames = true;
            this.statement.described = true;
            this.statement.numberOfDefinePositions = this.numuds;
            this.statement.accessors = accessors;
            this.statement.prepareAccessors();
            this.statement.allocateTmpByteArray();
        }
        return accessors;
    }
    
    void fillupAccessors(final Accessor[] array, final int n, final T4C8TTIuds t4C8TTIuds, final String columnName) throws SQLException {
        final int[] definedColumnType = this.statement.definedColumnType;
        final int[] definedColumnSize = this.statement.definedColumnSize;
        final int[] definedColumnFormOfUse = this.statement.definedColumnFormOfUse;
        final int includeRowid = this.statement.sqlObject.includeRowid ? 1 : 0;
        String str = null;
        String str2 = null;
        int n2 = 0;
        int lobPrefetchSizeForThisColumn = 0;
        int n3 = 0;
        if (n >= includeRowid) {
            final int n4 = n - includeRowid;
            if (definedColumnType != null && definedColumnType.length > n4 && definedColumnType[n4] != 0) {
                n2 = definedColumnType[n4];
            }
            if (definedColumnSize != null && definedColumnSize.length > n4 && definedColumnSize[n4] > 0) {
                lobPrefetchSizeForThisColumn = definedColumnSize[n4];
            }
            if (definedColumnFormOfUse != null && definedColumnFormOfUse.length > n4 && definedColumnFormOfUse[n4] > 0) {
                n3 = definedColumnFormOfUse[n4];
            }
        }
        int oacmxl = t4C8TTIuds.udsoac.oacmxl;
        switch (t4C8TTIuds.udsoac.oacdty) {
            case 96: {
                if (t4C8TTIuds.udsoac.oacmxlc != 0 && t4C8TTIuds.udsoac.oacmxlc < oacmxl) {
                    oacmxl = 2 * t4C8TTIuds.udsoac.oacmxlc;
                }
                int n5 = oacmxl;
                if ((n2 == 1 || n2 == 12) && lobPrefetchSizeForThisColumn > 0 && lobPrefetchSizeForThisColumn < oacmxl) {
                    n5 = lobPrefetchSizeForThisColumn;
                }
                array[n] = new T4CCharAccessor(this.statement, n5, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, oacmxl, n2, lobPrefetchSizeForThisColumn, this.meg);
                if ((t4C8TTIuds.udsoac.oacfl2 & 0x1000) == 0x1000 || t4C8TTIuds.udsoac.oacmxlc != 0) {
                    array[n].setDisplaySize(t4C8TTIuds.udsoac.oacmxlc);
                    break;
                }
                break;
            }
            case 2: {
                array[n] = new T4CNumberAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 1: {
                if (t4C8TTIuds.udsoac.oacmxlc != 0 && t4C8TTIuds.udsoac.oacmxlc < oacmxl) {
                    oacmxl = 2 * t4C8TTIuds.udsoac.oacmxlc;
                }
                int n6 = oacmxl;
                if ((n2 == 1 || n2 == 12) && lobPrefetchSizeForThisColumn > 0 && lobPrefetchSizeForThisColumn < oacmxl) {
                    n6 = lobPrefetchSizeForThisColumn;
                }
                array[n] = new T4CVarcharAccessor(this.statement, n6, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, oacmxl, n2, lobPrefetchSizeForThisColumn, this.meg);
                if ((t4C8TTIuds.udsoac.oacfl2 & 0x1000) == 0x1000 || t4C8TTIuds.udsoac.oacmxlc != 0) {
                    array[n].setDisplaySize(t4C8TTIuds.udsoac.oacmxlc);
                    break;
                }
                break;
            }
            case 8: {
                if ((n2 == 1 || n2 == 12) && this.connection.versionNumber >= 9000 && lobPrefetchSizeForThisColumn < 4001) {
                    int n7;
                    if (lobPrefetchSizeForThisColumn > 0) {
                        n7 = lobPrefetchSizeForThisColumn;
                    }
                    else {
                        n7 = 4000;
                    }
                    array[n] = new T4CVarcharAccessor(this.statement, n7, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, -1, n2, lobPrefetchSizeForThisColumn, this.meg);
                    array[n].describeType = 8;
                    break;
                }
                array[n] = new T4CLongAccessor(this.statement, n + 1, 0, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 6: {
                array[n] = new T4CVarnumAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 100: {
                array[n] = new T4CBinaryFloatAccessor(this.statement, 4, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 101: {
                array[n] = new T4CBinaryDoubleAccessor(this.statement, 8, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 23: {
                array[n] = new T4CRawAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 24: {
                if (n2 == -2 && lobPrefetchSizeForThisColumn < 2001 && this.connection.versionNumber >= 9000) {
                    array[n] = new T4CRawAccessor(this.statement, -1, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                    array[n].describeType = 24;
                    break;
                }
                array[n] = new T4CLongRawAccessor(this.statement, n + 1, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 11:
            case 104:
            case 208: {
                array[n] = new T4CRowidAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                if (t4C8TTIuds.udsoac.oacdty == 208) {
                    array[n].describeType = 208;
                    break;
                }
                break;
            }
            case 102: {
                array[n] = new T4CResultSetAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 12: {
                array[n] = new T4CDateAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 113: {
                if (n2 == -4 && this.connection.versionNumber >= 9000) {
                    array[n] = new T4CLongRawAccessor(this.statement, n + 1, Integer.MAX_VALUE, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                    array[n].describeType = 113;
                    break;
                }
                if (n2 == -3 && this.connection.versionNumber >= 9000) {
                    array[n] = new T4CRawAccessor(this.statement, 4000, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                    array[n].describeType = 113;
                    break;
                }
                array[n] = new T4CBlobAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                if (this.connection.useLobPrefetch && n2 == 2004) {
                    array[n].lobPrefetchSizeForThisColumn = lobPrefetchSizeForThisColumn;
                    break;
                }
                array[n].lobPrefetchSizeForThisColumn = -1;
                break;
            }
            case 112: {
                short n8 = 1;
                if (n3 != 0) {
                    n8 = (short)n3;
                }
                if (n2 == -1 && this.connection.versionNumber >= 9000) {
                    array[n] = new T4CLongAccessor(this.statement, n + 1, Integer.MAX_VALUE, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, n8, n2, lobPrefetchSizeForThisColumn, this.meg);
                    array[n].describeType = 112;
                    break;
                }
                if ((n2 == 12 || n2 == 1) && this.connection.versionNumber >= 9000) {
                    int n9 = 4000;
                    if (lobPrefetchSizeForThisColumn > 0 && lobPrefetchSizeForThisColumn < n9) {
                        n9 = lobPrefetchSizeForThisColumn;
                    }
                    array[n] = new T4CVarcharAccessor(this.statement, n9, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, n8, 4000, n2, lobPrefetchSizeForThisColumn, this.meg);
                    array[n].describeType = 112;
                    break;
                }
                array[n] = new T4CClobAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                if (this.connection.useLobPrefetch && (n2 == 2005 || n2 == 2011)) {
                    array[n].lobPrefetchSizeForThisColumn = lobPrefetchSizeForThisColumn;
                    break;
                }
                array[n].lobPrefetchSizeForThisColumn = -1;
                break;
            }
            case 114: {
                array[n] = new T4CBfileAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                if (this.connection.useLobPrefetch && n2 == -13) {
                    array[n].lobPrefetchSizeForThisColumn = lobPrefetchSizeForThisColumn;
                    break;
                }
                array[n].lobPrefetchSizeForThisColumn = -1;
                break;
            }
            case 109: {
                str = this.meg.conv.CharBytesToString(t4C8TTIuds.getTypeName(), t4C8TTIuds.getTypeCharLength());
                str2 = this.meg.conv.CharBytesToString(t4C8TTIuds.getSchemaName(), t4C8TTIuds.getSchemaCharLength());
                array[n] = new T4CNamedTypeAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, str2 + "." + str, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 111: {
                str = this.meg.conv.CharBytesToString(t4C8TTIuds.getTypeName(), t4C8TTIuds.getTypeCharLength());
                str2 = this.meg.conv.CharBytesToString(t4C8TTIuds.getSchemaName(), t4C8TTIuds.getSchemaCharLength());
                array[n] = new T4CRefTypeAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, str2 + "." + str, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 180: {
                array[n] = new T4CTimestampAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 181: {
                array[n] = new T4CTimestamptzAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 231: {
                array[n] = new T4CTimestampltzAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 182: {
                array[n] = new T4CIntervalymAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            case 183: {
                array[n] = new T4CIntervaldsAccessor(this.statement, oacmxl, t4C8TTIuds.udsnull, t4C8TTIuds.udsoac.oacflg, t4C8TTIuds.udsoac.oacpre, t4C8TTIuds.udsoac.oacscl, t4C8TTIuds.udsoac.oacfl2, t4C8TTIuds.udsoac.oacmal, t4C8TTIuds.udsoac.oaccsfrm, n2, lobPrefetchSizeForThisColumn, this.meg);
                break;
            }
            default: {
                array[n] = null;
                break;
            }
        }
        if (t4C8TTIuds.udsoac.oactoid.length > 0) {
            array[n].internalOtype = new OracleTypeADT(t4C8TTIuds.udsoac.oactoid, t4C8TTIuds.udsoac.oacvsn, t4C8TTIuds.udsoac.oaccsi, t4C8TTIuds.udsoac.oaccsfrm, str2 + "." + str);
        }
        else {
            array[n].internalOtype = null;
        }
        array[n].columnName = columnName;
        array[n].securityAttribute = OracleResultSetMetaData.SecurityAttribute.NONE;
        if ((t4C8TTIuds.udsflg & 0x1) != 0x0) {
            array[n].securityAttribute = OracleResultSetMetaData.SecurityAttribute.ENABLED;
        }
        else if ((t4C8TTIuds.udsflg & 0x2) != 0x0) {
            array[n].securityAttribute = OracleResultSetMetaData.SecurityAttribute.UNKNOWN;
        }
        if (t4C8TTIuds.udsoac.oacmxl == 0) {
            array[n].isNullByDescribe = true;
        }
        array[n].udskpos = t4C8TTIuds.getKernelPosition();
        this.colNameSB = null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
