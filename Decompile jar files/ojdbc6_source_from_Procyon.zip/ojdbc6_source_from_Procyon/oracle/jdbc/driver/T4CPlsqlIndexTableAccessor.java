// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CPlsqlIndexTableAccessor extends PlsqlIndexTableAccessor
{
    T4CMAREngine mare;
    final int[] meta;
    final int[] tmp;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CPlsqlIndexTableAccessor(final OracleStatement oracleStatement, final int n, final int n2, final int n3, final int n4, final short n5, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, n3, n4, n5, b);
        this.meta = new int[1];
        this.tmp = new int[1];
        this.calculateSizeTmpByteArray();
        this.mare = mare;
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        if (this.rowSpaceIndicator == null) {
            this.mare.unmarshalCLR(new byte[16000], 0, this.meta);
            this.processIndicator(this.meta[0]);
            ++this.lastRowProcessed;
            return false;
        }
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        final byte[] ibtBindBytes = this.statement.ibtBindBytes;
        final char[] ibtBindChars = this.statement.ibtBindChars;
        final short[] ibtBindIndicators = this.statement.ibtBindIndicators;
        if (this.isNullByDescribe) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
            ++this.lastRowProcessed;
            if (this.statement.connection.versionNumber < 9200) {
                this.processIndicator(0);
            }
            return false;
        }
        final int n3 = (int)this.mare.unmarshalUB4();
        ibtBindIndicators[this.ibtMetaIndex + 4] = (short)((n3 & 0xFFFF0000) >> 16 & 0xFFFF);
        ibtBindIndicators[this.ibtMetaIndex + 5] = (short)(n3 & 0xFFFF);
        if (this.elementInternalType == 9 || this.elementInternalType == 96 || this.elementInternalType == 1) {
            final byte[] tmpByteArray = this.statement.tmpByteArray;
            for (int i = 0; i < n3; ++i) {
                final int n4 = this.ibtValueIndex + this.elementMaxLen * i;
                this.mare.unmarshalCLR(tmpByteArray, 0, this.meta);
                this.tmp[0] = this.meta[0];
                ibtBindChars[n4] = (char)(this.statement.connection.conversion.CHARBytesToJavaChars(tmpByteArray, 0, ibtBindChars, n4 + 1, this.tmp, ibtBindChars.length - n4 - 1) * 2);
                this.processIndicator(this.meta[0]);
                if (this.meta[0] == 0) {
                    ibtBindIndicators[this.ibtIndicatorIndex + i] = -1;
                    ibtBindIndicators[this.ibtLengthIndex + i] = 0;
                }
                else {
                    ibtBindIndicators[this.ibtLengthIndex + i] = (short)(this.meta[0] * 2);
                    ibtBindIndicators[this.ibtIndicatorIndex + i] = 0;
                }
            }
        }
        else {
            for (int j = 0; j < n3; ++j) {
                final int n5 = this.ibtValueIndex + this.elementMaxLen * j;
                this.mare.unmarshalCLR(ibtBindBytes, n5 + 1, this.meta);
                ibtBindBytes[n5] = (byte)this.meta[0];
                this.processIndicator(this.meta[0]);
                if (this.meta[0] == 0) {
                    ibtBindIndicators[this.ibtIndicatorIndex + j] = -1;
                    ibtBindIndicators[this.ibtLengthIndex + j] = 0;
                }
                else {
                    ibtBindIndicators[this.ibtLengthIndex + j] = (short)this.meta[0];
                    ibtBindIndicators[this.ibtIndicatorIndex + j] = 0;
                }
            }
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    @Override
    void calculateSizeTmpByteArray() {
        if (this.elementInternalType == 9 || this.elementInternalType == 96 || this.elementInternalType == 1) {
            final int sizeTmpByteArray = this.ibtCharLength * this.statement.connection.conversion.cMaxCharSize / this.maxNumberOfElements;
            if (this.statement.sizeTmpByteArray < sizeTmpByteArray) {
                this.statement.sizeTmpByteArray = sizeTmpByteArray;
            }
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
