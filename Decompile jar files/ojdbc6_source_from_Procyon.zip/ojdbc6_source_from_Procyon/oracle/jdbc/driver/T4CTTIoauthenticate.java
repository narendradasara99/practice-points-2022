// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.sql.converter.CharacterSetMetaData;
import java.util.Locale;
import oracle.sql.ZONEIDMAP;
import java.util.TimeZone;
import java.net.InetAddress;
import oracle.net.ano.AuthenticationService;
import oracle.net.nt.TcpsNTAdapter;
import oracle.jdbc.util.RepConversion;
import oracle.security.o3logon.O3LoginClientHelper;
import oracle.security.o5logon.O5LoginClientHelper;
import java.util.Properties;
import java.io.IOException;
import java.sql.SQLException;

final class T4CTTIoauthenticate extends T4CTTIfun
{
    byte[] terminal;
    byte[] machine;
    byte[] sysUserName;
    byte[] processID;
    byte[] programName;
    byte[] encryptedSK;
    byte[] internalName;
    byte[] externalName;
    byte[] alterSession;
    byte[] aclValue;
    byte[] clientname;
    byte[] editionName;
    byte[] driverName;
    String ressourceManagerId;
    boolean bUseO5Logon;
    int verifierType;
    static final int ZTVT_ORCL_7 = 2361;
    static final int ZTVT_SSH1 = 6949;
    static final int ZTVT_NTV = 7809;
    byte[] salt;
    byte[] encryptedKB;
    boolean isSessionTZ;
    static final int SERVER_VERSION_81 = 8100;
    static final int KPZ_LOGON = 1;
    static final int KPZ_CPW = 2;
    static final int KPZ_SRVAUTH = 4;
    static final int KPZ_ENCRYPTED_PASSWD = 256;
    static final int KPZ_LOGON_MIGRATE = 16;
    static final int KPZ_LOGON_SYSDBA = 32;
    static final int KPZ_LOGON_SYSOPER = 64;
    static final int KPZ_LOGON_SYSASM = 4194304;
    static final int KPZ_LOGON_PRELIMAUTH = 128;
    static final int KPZ_PASSWD_ENCRYPTED = 256;
    static final int KPZ_LOGON_DBCONC = 512;
    static final int KPZ_PROXY_AUTH = 1024;
    static final int KPZ_SESSION_CACHE = 2048;
    static final int KPZ_PASSWD_IS_VFR = 4096;
    static final int KPZ_SESSION_QCACHE = 8388608;
    static final String AUTH_TERMINAL = "AUTH_TERMINAL";
    static final String AUTH_PROGRAM_NM = "AUTH_PROGRAM_NM";
    static final String AUTH_MACHINE = "AUTH_MACHINE";
    static final String AUTH_PID = "AUTH_PID";
    static final String AUTH_SID = "AUTH_SID";
    static final String AUTH_SESSKEY = "AUTH_SESSKEY";
    static final String AUTH_VFR_DATA = "AUTH_VFR_DATA";
    static final String AUTH_PASSWORD = "AUTH_PASSWORD";
    static final String AUTH_INTERNALNAME = "AUTH_INTERNALNAME_";
    static final String AUTH_EXTERNALNAME = "AUTH_EXTERNALNAME_";
    static final String AUTH_ACL = "AUTH_ACL";
    static final String AUTH_ALTER_SESSION = "AUTH_ALTER_SESSION";
    static final String AUTH_INITIAL_CLIENT_ROLE = "INITIAL_CLIENT_ROLE";
    static final String AUTH_VERSION_SQL = "AUTH_VERSION_SQL";
    static final String AUTH_VERSION_NO = "AUTH_VERSION_NO";
    static final String AUTH_XACTION_TRAITS = "AUTH_XACTION_TRAITS";
    static final String AUTH_VERSION_STATUS = "AUTH_VERSION_STATUS";
    static final String AUTH_SERIAL_NUM = "AUTH_SERIAL_NUM";
    static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
    static final String AUTH_CLIENT_CERTIFICATE = "AUTH_CLIENT_CERTIFICATE";
    static final String AUTH_PROXY_CLIENT_NAME = "PROXY_CLIENT_NAME";
    static final String AUTH_CLIENT_DN = "AUTH_CLIENT_DISTINGUISHED_NAME";
    static final String AUTH_INSTANCENAME = "AUTH_INSTANCENAME";
    static final String AUTH_DBNAME = "AUTH_DBNAME";
    static final String AUTH_INSTANCE_NO = "AUTH_INSTANCE_NO";
    static final String AUTH_SC_SERVER_HOST = "AUTH_SC_SERVER_HOST";
    static final String AUTH_SC_INSTANCE_NAME = "AUTH_SC_INSTANCE_NAME";
    static final String AUTH_SC_INSTANCE_ID = "AUTH_SC_INSTANCE_ID";
    static final String AUTH_SC_INSTANCE_START_TIME = "AUTH_SC_INSTANCE_START_TIME";
    static final String AUTH_SC_DBUNIQUE_NAME = "AUTH_SC_DBUNIQUE_NAME";
    static final String AUTH_SC_SERVICE_NAME = "AUTH_SC_SERVICE_NAME";
    static final String AUTH_SC_SVC_FLAGS = "AUTH_SC_SVC_FLAGS";
    static final String AUTH_SESSION_CLIENT_CSET = "SESSION_CLIENT_CHARSET";
    static final String AUTH_SESSION_CLIENT_LTYPE = "SESSION_CLIENT_LIB_TYPE";
    static final String AUTH_SESSION_CLIENT_DRVNM = "SESSION_CLIENT_DRIVER_NAME";
    static final String AUTH_SESSION_CLIENT_VSN = "SESSION_CLIENT_VERSION";
    static final String AUTH_NLS_LXLAN = "AUTH_NLS_LXLAN";
    static final String AUTH_NLS_LXCTERRITORY = "AUTH_NLS_LXCTERRITORY";
    static final String AUTH_NLS_LXCCURRENCY = "AUTH_NLS_LXCCURRENCY";
    static final String AUTH_NLS_LXCISOCURR = "AUTH_NLS_LXCISOCURR";
    static final String AUTH_NLS_LXCNUMERICS = "AUTH_NLS_LXCNUMERICS";
    static final String AUTH_NLS_LXCDATEFM = "AUTH_NLS_LXCDATEFM";
    static final String AUTH_NLS_LXCDATELANG = "AUTH_NLS_LXCDATELANG";
    static final String AUTH_NLS_LXCSORT = "AUTH_NLS_LXCSORT";
    static final String AUTH_NLS_LXCCALENDAR = "AUTH_NLS_LXCCALENDAR";
    static final String AUTH_NLS_LXCUNIONCUR = "AUTH_NLS_LXCUNIONCUR";
    static final String AUTH_NLS_LXCTIMEFM = "AUTH_NLS_LXCTIMEFM";
    static final String AUTH_NLS_LXCSTMPFM = "AUTH_NLS_LXCSTMPFM";
    static final String AUTH_NLS_LXCTTZNFM = "AUTH_NLS_LXCTTZNFM";
    static final String AUTH_NLS_LXCSTZNFM = "AUTH_NLS_LXCSTZNFM";
    static final String DRIVER_NAME_DEFAULT = "jdbcthin";
    static final int KPU_LIB_UNKN = 0;
    static final int KPU_LIB_DEF = 1;
    static final int KPU_LIB_EI = 2;
    static final int KPU_LIB_XE = 3;
    static final int KPU_LIB_ICUS = 4;
    static final int KPU_LIB_OCI = 5;
    static final int KPU_LIB_THIN = 10;
    static final String AUTH_ORA_EDITION = "AUTH_ORA_EDITION";
    static final String AUTH_COPYRIGHT = "AUTH_COPYRIGHT";
    static final String COPYRIGHT_STR = "\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.";
    static final String SESSION_TIME_ZONE = "SESSION_TIME_ZONE";
    static final String SESSION_NLS_LXCCHARSET = "SESSION_NLS_LXCCHARSET";
    static final String SESSION_NLS_LXCNLSLENSEM = "SESSION_NLS_LXCNLSLENSEM";
    static final String SESSION_NLS_LXCNCHAREXCP = "SESSION_NLS_LXCNCHAREXCP";
    static final String SESSION_NLS_LXCNCHARIMP = "SESSION_NLS_LXCNCHARIMP";
    String sessionTimeZone;
    private T4CKvaldfList keyValList;
    private byte[] user;
    private long logonMode;
    private byte[][] outKeys;
    private byte[][] outValues;
    private int[] outFlags;
    private int outNbPairs;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIoauthenticate(final T4CConnection sessionFields, final String ressourceManagerId) throws SQLException {
        super(sessionFields, (byte)3);
        this.editionName = null;
        this.isSessionTZ = true;
        this.sessionTimeZone = null;
        this.keyValList = null;
        this.user = null;
        this.outKeys = null;
        this.outValues = null;
        this.outFlags = new int[0];
        this.outNbPairs = 0;
        this.ressourceManagerId = ressourceManagerId;
        this.setSessionFields(sessionFields);
        this.isSessionTZ = true;
        this.bUseO5Logon = false;
    }
    
    @Override
    void marshal() throws IOException {
        if (this.user != null && this.user.length > 0) {
            this.meg.marshalPTR();
            this.meg.marshalSB4(this.user.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSB4(0);
        }
        this.meg.marshalUB4(this.logonMode);
        this.meg.marshalPTR();
        this.meg.marshalUB4(this.keyValList.size());
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        if (this.user != null && this.user.length > 0) {
            this.meg.marshalCHR(this.user);
        }
        this.meg.marshalKEYVAL(this.keyValList.getKeys(), this.keyValList.getValues(), this.keyValList.getFlags(), this.keyValList.size());
    }
    
    private void doOAUTH(final byte[] user, final byte[] array, final long n, final String s, final boolean b, final byte[] array2, final byte[] array3, final byte[][] array4, final int i, final int j) throws IOException, SQLException {
        this.setFunCode((short)115);
        this.user = user;
        this.logonMode = (n | 0x1L);
        if (b) {
            this.logonMode |= 0x400L;
        }
        if (user != null && user.length != 0 && array != null && s != "RADIUS") {
            this.logonMode |= 0x100L;
        }
        this.keyValList = new T4CKvaldfList(this.meg.conv);
        if (array != null) {
            this.keyValList.add("AUTH_PASSWORD", array);
        }
        if (array4 != null) {
            for (int k = 0; k < array4.length; ++k) {
                this.keyValList.add("INITIAL_CLIENT_ROLE", array4[k]);
            }
        }
        if (array2 != null) {
            this.keyValList.add("AUTH_CLIENT_DISTINGUISHED_NAME", array2);
        }
        if (array3 != null) {
            this.keyValList.add("AUTH_CLIENT_CERTIFICATE", array3);
        }
        this.keyValList.add("AUTH_TERMINAL", this.terminal);
        if (this.bUseO5Logon && this.encryptedKB != null) {
            this.keyValList.add("AUTH_SESSKEY", this.encryptedKB, (byte)1);
        }
        if (this.programName != null) {
            this.keyValList.add("AUTH_PROGRAM_NM", this.programName);
        }
        if (this.clientname != null) {
            this.keyValList.add("PROXY_CLIENT_NAME", this.clientname);
        }
        this.keyValList.add("AUTH_MACHINE", this.machine);
        this.keyValList.add("AUTH_PID", this.processID);
        if (!this.ressourceManagerId.equals("0000")) {
            final byte[] stringToCharBytes = this.meg.conv.StringToCharBytes("AUTH_INTERNALNAME_");
            stringToCharBytes[stringToCharBytes.length - 1] = 0;
            this.keyValList.add(stringToCharBytes, this.internalName);
            final byte[] stringToCharBytes2 = this.meg.conv.StringToCharBytes("AUTH_EXTERNALNAME_");
            stringToCharBytes2[stringToCharBytes2.length - 1] = 0;
            this.keyValList.add(stringToCharBytes2, this.externalName);
        }
        this.keyValList.add("AUTH_ACL", this.aclValue);
        this.keyValList.add("AUTH_ALTER_SESSION", this.alterSession, (byte)1);
        if (this.editionName != null) {
            this.keyValList.add("AUTH_ORA_EDITION", this.editionName);
        }
        this.keyValList.add("SESSION_CLIENT_DRIVER_NAME", this.driverName);
        this.keyValList.add("SESSION_CLIENT_VERSION", this.meg.conv.StringToCharBytes(Integer.toString(this.versionStringToInt(this.connection.getMetaData().getDriverVersion()), 10)));
        if (i != -1) {
            this.keyValList.add("AUTH_SESSION_ID", this.meg.conv.StringToCharBytes(Integer.toString(i)));
        }
        if (j != -1) {
            this.keyValList.add("AUTH_SERIAL_NUM", this.meg.conv.StringToCharBytes(Integer.toString(j)));
        }
        this.keyValList.add("AUTH_COPYRIGHT", this.meg.conv.StringToCharBytes("\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation."));
        this.outNbPairs = 0;
        this.outKeys = null;
        this.outValues = null;
        this.outFlags = new int[0];
        this.doRPC();
    }
    
    void doOSESSKEY(final String s, final long n) throws IOException, SQLException {
        this.setFunCode((short)118);
        this.user = this.meg.conv.StringToCharBytes(s);
        this.logonMode = (n | 0x1L);
        (this.keyValList = new T4CKvaldfList(this.meg.conv)).add("AUTH_TERMINAL", this.terminal);
        if (this.programName != null) {
            this.keyValList.add("AUTH_PROGRAM_NM", this.programName);
        }
        this.keyValList.add("AUTH_MACHINE", this.machine);
        this.keyValList.add("AUTH_PID", this.processID);
        this.keyValList.add("AUTH_SID", this.sysUserName);
        this.outNbPairs = 0;
        this.outKeys = null;
        this.outValues = null;
        this.outFlags = new int[0];
        this.doRPC();
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        this.outNbPairs = this.meg.unmarshalUB2();
        this.outKeys = new byte[this.outNbPairs][];
        this.outValues = new byte[this.outNbPairs][];
        this.outFlags = this.meg.unmarshalKEYVAL(this.outKeys, this.outValues, this.outNbPairs);
    }
    
    @Override
    void processError() throws SQLException {
        if (this.getFunCode() == 118) {
            if (this.oer.getRetCode() != 28035 || this.connection.net.getAuthenticationAdaptorName() != "RADIUS") {
                this.oer.processError();
            }
        }
        else {
            super.processError();
        }
    }
    
    protected void processRPA() throws SQLException {
        if (this.getFunCode() == 115) {
            final Properties sessionProperties = new Properties();
            for (int i = 0; i < this.outNbPairs; ++i) {
                final String trim = this.meg.conv.CharBytesToString(this.outKeys[i], this.outKeys[i].length).trim();
                String trim2 = "";
                if (this.outValues[i] != null) {
                    trim2 = this.meg.conv.CharBytesToString(this.outValues[i], this.outValues[i].length).trim();
                }
                sessionProperties.setProperty(trim, trim2);
            }
            final String property = sessionProperties.getProperty("AUTH_VERSION_NO");
            if (property != null) {
                try {
                    new Integer(property);
                }
                catch (NumberFormatException ex) {}
            }
            sessionProperties.setProperty("SERVER_HOST", sessionProperties.getProperty("AUTH_SC_SERVER_HOST", ""));
            sessionProperties.setProperty("INSTANCE_NAME", sessionProperties.getProperty("AUTH_SC_INSTANCE_NAME", ""));
            sessionProperties.setProperty("DATABASE_NAME", sessionProperties.getProperty("AUTH_SC_DBUNIQUE_NAME", ""));
            sessionProperties.setProperty("SERVICE_NAME", sessionProperties.getProperty("AUTH_SC_SERVICE_NAME", ""));
            sessionProperties.setProperty("SESSION_TIME_ZONE", this.sessionTimeZone);
            this.connection.sessionProperties = sessionProperties;
        }
        else if (this.getFunCode() == 118 && this.connection.net.getAuthenticationAdaptorName() != "RADIUS") {
            if (this.outKeys == null || this.outKeys.length < 1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 438);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            int n = -1;
            for (int j = 0; j < this.outKeys.length; ++j) {
                if (new String(this.outKeys[j]).equals("AUTH_SESSKEY")) {
                    n = j;
                    break;
                }
            }
            if (n == -1) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 438);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            this.encryptedSK = this.outValues[n];
            int n2 = -1;
            for (int k = 0; k < this.outKeys.length; ++k) {
                if (new String(this.outKeys[k]).equals("AUTH_VFR_DATA")) {
                    n2 = k;
                    break;
                }
            }
            if (n2 != -1) {
                this.bUseO5Logon = true;
                this.salt = this.outValues[n2];
                this.verifierType = this.outFlags[n2];
            }
            if (!this.bUseO5Logon && (this.encryptedSK == null || this.encryptedSK.length != 16)) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 438);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
    }
    
    void doOAUTH(final String s, final String s2, final long n) throws IOException, SQLException {
        byte[] stringToCharBytes = null;
        if (s != null && s.length() > 0) {
            stringToCharBytes = this.meg.conv.StringToCharBytes(s);
        }
        byte[] stringToCharBytes2 = null;
        byte[] array = null;
        final String authenticationAdaptorName = this.connection.net.getAuthenticationAdaptorName();
        if (s != null && s.length() != 0) {
            if (authenticationAdaptorName != "RADIUS" && this.encryptedSK.length > 16 && !this.bUseO5Logon) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 413);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.bUseO5Logon && (this.encryptedSK == null || (this.encryptedSK.length != 64 && this.encryptedSK.length != 96))) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 413);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final String trim = s.trim();
            String trim2 = null;
            if (s2 != null) {
                trim2 = s2.trim();
            }
            String removeQuotes = trim;
            String removeQuotes2 = trim2;
            if (trim.startsWith("\"") || trim.endsWith("\"")) {
                removeQuotes = this.removeQuotes(trim);
            }
            if (trim2 != null && (trim2.startsWith("\"") || trim2.endsWith("\""))) {
                removeQuotes2 = this.removeQuotes(trim2);
            }
            if (removeQuotes2 != null) {
                stringToCharBytes2 = this.meg.conv.StringToCharBytes(removeQuotes2);
            }
            if (authenticationAdaptorName != "RADIUS") {
                if (stringToCharBytes2 == null) {
                    array = null;
                }
                else if (this.bUseO5Logon) {
                    switch (this.verifierType) {
                        case 2361: {
                            this.encryptedKB = new byte[64];
                            for (int i = 0; i < 64; ++i) {
                                this.encryptedKB[i] = 1;
                            }
                            break;
                        }
                        case 6949: {
                            this.encryptedKB = new byte[96];
                            for (int j = 0; j < 96; ++j) {
                                this.encryptedKB[j] = 1;
                            }
                            break;
                        }
                        default: {
                            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 451);
                            sqlException3.fillInStackTrace();
                            throw sqlException3;
                        }
                    }
                    array = new byte[256];
                    for (int k = 0; k < 256; ++k) {
                        array[k] = 0;
                    }
                    if (!O5LoginClientHelper.generateOAuthResponse(this.verifierType, this.salt, removeQuotes, removeQuotes2, stringToCharBytes2, this.encryptedSK, this.encryptedKB, array, this.meg.conv.isServerCSMultiByte)) {
                        final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 452);
                        sqlException4.fillInStackTrace();
                        throw sqlException4;
                    }
                }
                else {
                    final O3LoginClientHelper o3LoginClientHelper = new O3LoginClientHelper(this.meg.conv.isServerCSMultiByte);
                    final byte[] sessionKey = o3LoginClientHelper.getSessionKey(removeQuotes, removeQuotes2, this.encryptedSK);
                    byte b;
                    if (stringToCharBytes2.length % 8 > 0) {
                        b = (byte)(8 - stringToCharBytes2.length % 8);
                    }
                    else {
                        b = 0;
                    }
                    final byte[] array2 = new byte[stringToCharBytes2.length + b];
                    System.arraycopy(stringToCharBytes2, 0, array2, 0, stringToCharBytes2.length);
                    final byte[] ePasswd = o3LoginClientHelper.getEPasswd(sessionKey, array2);
                    array = new byte[2 * array2.length + 1];
                    if (array.length < 2 * ePasswd.length) {
                        final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 413);
                        sqlException5.fillInStackTrace();
                        throw sqlException5;
                    }
                    RepConversion.bArray2Nibbles(ePasswd, array);
                    array[array.length - 1] = RepConversion.nibbleToHex(b);
                }
            }
            else if (stringToCharBytes2 != null) {
                if (this.connection.net.getSessionAttributes().getNTAdapter() instanceof TcpsNTAdapter) {
                    array = stringToCharBytes2;
                }
                else {
                    int n2;
                    if ((stringToCharBytes2.length + 1) % 8 > 0) {
                        n2 = (byte)(8 - (stringToCharBytes2.length + 1) % 8);
                    }
                    else {
                        n2 = 0;
                    }
                    final byte[] array3 = new byte[stringToCharBytes2.length + 1 + n2];
                    System.arraycopy(stringToCharBytes2, 0, array3, 0, stringToCharBytes2.length);
                    final byte[] obfuscatePasswordForRadius = AuthenticationService.obfuscatePasswordForRadius(array3);
                    array = new byte[obfuscatePasswordForRadius.length * 2];
                    for (int l = 0; l < obfuscatePasswordForRadius.length; ++l) {
                        final byte b2 = (byte)((obfuscatePasswordForRadius[l] & 0xF0) >> 4);
                        final byte b3 = (byte)(obfuscatePasswordForRadius[l] & 0xF);
                        array[l * 2] = (byte)((b2 < 10) ? (b2 + 48) : (b2 - 10 + 97));
                        array[l * 2 + 1] = (byte)((b3 < 10) ? (b3 + 48) : (b3 - 10 + 97));
                    }
                }
            }
        }
        this.doOAUTH(stringToCharBytes, array, n, authenticationAdaptorName, false, null, null, null, -1, -1);
    }
    
    void doOAUTH(final int n, final Properties properties, final int n2, final int n3) throws IOException, SQLException {
        byte[] stringToCharBytes = null;
        byte[] bytes = null;
        String[] array = null;
        byte[][] array2 = null;
        byte[] stringToCharBytes2 = null;
        if (n == 1) {
            String str = properties.getProperty("PROXY_USER_NAME");
            final String property = properties.getProperty("PROXY_USER_PASSWORD");
            if (property != null) {
                str = str + "/" + property;
            }
            stringToCharBytes2 = this.meg.conv.StringToCharBytes(str);
        }
        else if (n == 2) {
            stringToCharBytes = this.meg.conv.StringToCharBytes(properties.getProperty("PROXY_DISTINGUISHED_NAME"));
        }
        else {
            try {
                bytes = (byte[])properties.get("PROXY_CERTIFICATE");
                final StringBuffer sb = new StringBuffer();
                for (int i = 0; i < bytes.length; ++i) {
                    final String hexString = Integer.toHexString(0xFF & bytes[i]);
                    final int length = hexString.length();
                    if (length == 0) {
                        sb.append("00");
                    }
                    else if (length == 1) {
                        sb.append('0');
                        sb.append(hexString);
                    }
                    else {
                        sb.append(hexString);
                    }
                }
                bytes = sb.toString().getBytes();
            }
            catch (Exception ex) {}
        }
        try {
            array = (String[])properties.get("PROXY_ROLES");
        }
        catch (Exception ex2) {}
        if (array != null) {
            array2 = new byte[array.length][];
            for (int j = 0; j < array.length; ++j) {
                array2[j] = this.meg.conv.StringToCharBytes(array[j]);
            }
        }
        this.doOAUTH(stringToCharBytes2, null, 0L, null, true, stringToCharBytes, bytes, array2, n2, n3);
    }
    
    private void setSessionFields(final T4CConnection t4CConnection) throws SQLException {
        final String thinVsessionTerminal = this.connection.thinVsessionTerminal;
        String s = this.connection.thinVsessionMachine;
        final String thinVsessionOsuser = this.connection.thinVsessionOsuser;
        final String thinVsessionProgram = this.connection.thinVsessionProgram;
        final String thinVsessionProcess = this.connection.thinVsessionProcess;
        final String thinVsessionIname = this.connection.thinVsessionIname;
        String s2 = this.connection.thinVsessionEname;
        final String proxyClientName = this.connection.proxyClientName;
        String driverNameAttribute = this.connection.driverNameAttribute;
        final String editionName = this.connection.editionName;
        if (s == null) {
            try {
                s = InetAddress.getLocalHost().getHostName();
            }
            catch (Exception ex) {
                s = "jdbcclient";
            }
        }
        if (s2 == null) {
            s2 = "jdbc_" + this.ressourceManagerId;
        }
        if (driverNameAttribute == null) {
            driverNameAttribute = "jdbcthin";
        }
        this.terminal = this.meg.conv.StringToCharBytes(thinVsessionTerminal);
        this.machine = this.meg.conv.StringToCharBytes(s);
        this.sysUserName = this.meg.conv.StringToCharBytes(thinVsessionOsuser);
        this.programName = this.meg.conv.StringToCharBytes(thinVsessionProgram);
        this.processID = this.meg.conv.StringToCharBytes(thinVsessionProcess);
        this.internalName = this.meg.conv.StringToCharBytes(thinVsessionIname);
        this.externalName = this.meg.conv.StringToCharBytes(s2);
        if (proxyClientName != null) {
            this.clientname = this.meg.conv.StringToCharBytes(proxyClientName);
        }
        if (editionName != null) {
            this.editionName = this.meg.conv.StringToCharBytes(editionName);
        }
        this.driverName = this.meg.conv.StringToCharBytes(driverNameAttribute);
        final TimeZone default1 = TimeZone.getDefault();
        String s3 = default1.getID();
        if (!ZONEIDMAP.isValidRegion(s3) || !t4CConnection.timezoneAsRegion) {
            final int offset = default1.getOffset(System.currentTimeMillis());
            final int n = offset / 3600000;
            final int n2 = offset / 60000 % 60;
            s3 = ((n < 0) ? ("" + n) : ("+" + n)) + ((n2 < 10) ? (":0" + n2) : (":" + n2));
        }
        this.sessionTimeZone = s3;
        t4CConnection.sessionTimeZone = s3;
        final String nlsLanguage = CharacterSetMetaData.getNLSLanguage(Locale.getDefault());
        final String nlsTerritory = CharacterSetMetaData.getNLSTerritory(Locale.getDefault());
        if (nlsLanguage == null || nlsTerritory == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 176);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.alterSession = this.meg.conv.StringToCharBytes("ALTER SESSION SET " + (this.isSessionTZ ? ("TIME_ZONE='" + this.sessionTimeZone + "'") : "") + " NLS_LANGUAGE='" + nlsLanguage + "' NLS_TERRITORY='" + nlsTerritory + "' ");
        this.aclValue = this.meg.conv.StringToCharBytes("4400");
        this.alterSession[this.alterSession.length - 1] = 0;
    }
    
    String removeQuotes(final String s) {
        int beginIndex = 0;
        int n = s.length() - 1;
        for (int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) != '\"') {
                beginIndex = i;
                break;
            }
        }
        for (int j = s.length() - 1; j >= 0; --j) {
            if (s.charAt(j) != '\"') {
                n = j;
                break;
            }
        }
        return s.substring(beginIndex, n + 1);
    }
    
    private int versionStringToInt(final String s) throws SQLException {
        final String[] split = s.split("\\.");
        return Integer.parseInt(split[0].replaceAll("\\D", "")) << 24 | Integer.parseInt(split[1].replaceAll("\\D", "")) << 20 | Integer.parseInt(split[2].replaceAll("\\D", "")) << 12 | Integer.parseInt(split[3].replaceAll("\\D", "")) << 8 | Integer.parseInt(split[4].replaceAll("\\D", ""));
    }
    
    private String versionIntToString(final int n) throws SQLException {
        return "" + ((n & 0xFF000000) >> 24 & 0xFF) + "." + ((n & 0xF00000) >> 20 & 0xFF) + "." + ((n & 0xFF000) >> 12 & 0xFF) + "." + ((n & 0xF00) >> 8 & 0xFF) + "." + (n & 0xFF);
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
