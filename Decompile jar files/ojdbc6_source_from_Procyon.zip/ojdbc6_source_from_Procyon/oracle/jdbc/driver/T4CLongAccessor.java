// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.net.ns.BreakNetException;
import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;

class T4CLongAccessor extends LongAccessor
{
    T4CMAREngine mare;
    static final int t4MaxLength = Integer.MAX_VALUE;
    static final int t4PlsqlMaxLength = 32760;
    byte[][] data;
    int[] nbBytesRead;
    int[] bytesReadSoFar;
    final int[] escapeSequenceArr;
    final boolean[] readHeaderArr;
    final boolean[] readAsNonStreamArr;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CLongAccessor(final OracleStatement oracleStatement, final int n, final int n2, final short n3, final int n4, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, n3, n4);
        this.data = null;
        this.nbBytesRead = null;
        this.bytesReadSoFar = null;
        this.escapeSequenceArr = new int[1];
        this.readHeaderArr = new boolean[1];
        this.readAsNonStreamArr = new boolean[1];
        this.mare = mare;
        if (oracleStatement.connection.useFetchSizeWithLongColumn) {
            this.data = new byte[oracleStatement.rowPrefetch][];
            for (int i = 0; i < oracleStatement.rowPrefetch; ++i) {
                this.data[i] = new byte[4080];
            }
            this.nbBytesRead = new int[oracleStatement.rowPrefetch];
            this.bytesReadSoFar = new int[oracleStatement.rowPrefetch];
        }
    }
    
    T4CLongAccessor(final OracleStatement oracleStatement, final int n, final int n2, final boolean b, final int n3, final int n4, final int n5, final int n6, final int n7, final short n8, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, b, n3, n4, n5, n6, n7, n8);
        this.data = null;
        this.nbBytesRead = null;
        this.bytesReadSoFar = null;
        this.escapeSequenceArr = new int[1];
        this.readHeaderArr = new boolean[1];
        this.readAsNonStreamArr = new boolean[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
        if (oracleStatement.connection.useFetchSizeWithLongColumn) {
            this.data = new byte[oracleStatement.rowPrefetch][];
            for (int i = 0; i < oracleStatement.rowPrefetch; ++i) {
                this.data[i] = new byte[4080];
            }
            this.nbBytesRead = new int[oracleStatement.rowPrefetch];
            this.bytesReadSoFar = new int[oracleStatement.rowPrefetch];
        }
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        boolean b = false;
        final int n = this.indicatorIndex + this.lastRowProcessed;
        this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
        if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0])) {
            this.rowSpaceIndicator[n] = -1;
            this.mare.processIndicator(false, 0);
            final int n2 = (int)this.mare.unmarshalUB4();
            b = false;
            this.escapeSequenceArr[0] = 0;
            ++this.lastRowProcessed;
        }
        else {
            this.rowSpaceIndicator[n] = 0;
            this.readHeaderArr[0] = true;
            this.readAsNonStreamArr[0] = false;
            if (this.statement.connection.useFetchSizeWithLongColumn) {
                int i = 0;
                while (i != -1) {
                    if (this.data[this.lastRowProcessed].length < this.nbBytesRead[this.lastRowProcessed] + 255) {
                        final byte[] array = new byte[this.data[this.lastRowProcessed].length * 4];
                        System.arraycopy(this.data[this.lastRowProcessed], 0, array, 0, this.nbBytesRead[this.lastRowProcessed]);
                        this.data[this.lastRowProcessed] = array;
                    }
                    i = readStreamFromWire(this.data[this.lastRowProcessed], this.nbBytesRead[this.lastRowProcessed], 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
                    if (i != -1) {
                        final int[] nbBytesRead = this.nbBytesRead;
                        final int lastRowProcessed = this.lastRowProcessed;
                        nbBytesRead[lastRowProcessed] += i;
                    }
                }
                ++this.lastRowProcessed;
            }
            else {
                b = true;
            }
        }
        return b;
    }
    
    @Override
    void fetchNextColumns() throws SQLException {
        this.statement.continueReadRow(this.columnPosition);
    }
    
    @Override
    int readStream(final byte[] array, final int n) throws SQLException, IOException {
        final int currentRow = this.statement.currentRow;
        if (!this.statement.connection.useFetchSizeWithLongColumn) {
            return readStreamFromWire(array, 0, n, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
        }
        final byte[] array2 = this.data[currentRow];
        final int n2 = this.nbBytesRead[currentRow];
        final int n3 = this.bytesReadSoFar[currentRow];
        if (n3 == n2) {
            return -1;
        }
        int n4;
        if (n <= n2 - n3) {
            n4 = n;
        }
        else {
            n4 = n2 - n3;
        }
        System.arraycopy(array2, n3, array, 0, n4);
        final int[] bytesReadSoFar = this.bytesReadSoFar;
        final int n5 = currentRow;
        bytesReadSoFar[n5] += n4;
        return n4;
    }
    
    protected static final int readStreamFromWire(final byte[] array, final int n, final int n2, final int[] array2, final boolean[] array3, final boolean[] array4, final T4CMAREngine t4CMAREngine, final T4CTTIoer t4CTTIoer) throws SQLException, IOException {
        int n3 = -1;
        try {
            if (!array4[0]) {
                if (n2 > 255 || n2 < 0) {
                    final SQLException sqlException = DatabaseError.createSqlException(null, 433);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                if (array3[0]) {
                    if (array2[0] == 254) {
                        n3 = t4CMAREngine.unmarshalUB1();
                    }
                    else {
                        if (array2[0] == 0) {
                            t4CTTIoer.connection.internalClose();
                            final SQLException sqlException2 = DatabaseError.createSqlException(null, 401);
                            sqlException2.fillInStackTrace();
                            throw sqlException2;
                        }
                        array4[0] = true;
                        n3 = array2[0];
                    }
                    array3[0] = false;
                    array2[0] = 0;
                }
                else {
                    n3 = t4CMAREngine.unmarshalUB1();
                }
            }
            else {
                array4[0] = false;
            }
            if (n3 > 0) {
                t4CMAREngine.unmarshalNBytes(array, n, n3);
            }
            else {
                n3 = -1;
            }
        }
        catch (BreakNetException ex) {
            n3 = t4CMAREngine.unmarshalSB1();
            if (n3 == 4) {
                t4CTTIoer.init();
                t4CTTIoer.processError();
            }
        }
        if (n3 == -1) {
            array3[0] = true;
            t4CMAREngine.unmarshalUB2();
            t4CMAREngine.unmarshalUB2();
        }
        return n3;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
