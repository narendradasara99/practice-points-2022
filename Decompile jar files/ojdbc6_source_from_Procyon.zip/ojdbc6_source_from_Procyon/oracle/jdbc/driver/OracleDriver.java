// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.sql.Timestamp;
import java.security.AccessController;
import java.security.PrivilegedAction;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.OracleDatabaseMetaData;
import java.lang.reflect.Field;
import java.sql.DriverPropertyInfo;
import java.util.Enumeration;
import java.sql.SQLException;
import java.sql.DriverManager;
import javax.management.JMException;
import javax.management.InstanceAlreadyExistsException;
import javax.management.ObjectName;
import java.lang.reflect.InvocationTargetException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.lang.management.ManagementFactory;
import javax.management.MBeanServer;
import java.util.Map;
import java.sql.Connection;
import java.util.Properties;
import java.sql.Driver;

public class OracleDriver implements Driver
{
    public static final String oracle_string = "oracle";
    public static final String jdbc_string = "jdbc";
    public static final String protocol_string = "protocol";
    public static final String user_string = "user";
    public static final String password_string = "password";
    public static final String database_string = "database";
    public static final String server_string = "server";
    @Deprecated
    public static final String access_string = "access";
    @Deprecated
    public static final String protocolFullName_string = "protocolFullName";
    public static final String logon_as_internal_str = "internal_logon";
    public static final String proxy_client_name = "oracle.jdbc.proxyClientName";
    public static final String prefetch_string = "prefetch";
    public static final String row_prefetch_string = "rowPrefetch";
    public static final String default_row_prefetch_string = "defaultRowPrefetch";
    public static final String batch_string = "batch";
    public static final String execute_batch_string = "executeBatch";
    public static final String default_execute_batch_string = "defaultExecuteBatch";
    public static final String process_escapes_string = "processEscapes";
    public static final String accumulate_batch_result = "AccumulateBatchResult";
    public static final String j2ee_compliance = "oracle.jdbc.J2EE13Compliant";
    public static final String v8compatible_string = "V8Compatible";
    public static final String permit_timestamp_date_mismatch_string = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
    public static final String StreamChunkSize_string = "oracle.jdbc.StreamChunkSize";
    public static final String prelim_auth_string = "prelim_auth";
    public static final String SetFloatAndDoubleUseBinary_string = "SetFloatAndDoubleUseBinary";
    @Deprecated
    public static final String xa_trans_loose = "oracle.jdbc.XATransLoose";
    public static final String tcp_no_delay = "oracle.jdbc.TcpNoDelay";
    public static final String read_timeout = "oracle.jdbc.ReadTimeout";
    public static final String defaultnchar_string = "oracle.jdbc.defaultNChar";
    public static final String defaultncharprop_string = "defaultNChar";
    public static final String useFetchSizeWithLongColumn_prop_string = "useFetchSizeWithLongColumn";
    public static final String useFetchSizeWithLongColumn_string = "oracle.jdbc.useFetchSizeWithLongColumn";
    public static final String remarks_string = "remarks";
    public static final String report_remarks_string = "remarksReporting";
    public static final String synonyms_string = "synonyms";
    public static final String include_synonyms_string = "includeSynonyms";
    public static final String restrict_getTables_string = "restrictGetTables";
    public static final String fixed_string_string = "fixedString";
    public static final String dll_string = "oracle.jdbc.ocinativelibrary";
    public static final String nls_lang_backdoor = "oracle.jdbc.ociNlsLangBackwardCompatible";
    public static final String disable_defineColumnType_string = "disableDefineColumnType";
    public static final String convert_nchar_literals_string = "oracle.jdbc.convertNcharLiterals";
    public static final String dataSizeUnitsPropertyName = "";
    public static final String dataSizeBytes = "";
    public static final String dataSizeChars = "";
    public static final String set_new_password_string = "OCINewPassword";
    public static final String retain_v9_bind_behavior_string = "oracle.jdbc.RetainV9LongBindBehavior";
    public static final String no_caching_buffers = "oracle.jdbc.FreeMemoryOnEnterImplicitCache";
    static final int EXTENSION_TYPE_ORACLE_ERROR = -3;
    static final int EXTENSION_TYPE_GEN_ERROR = -2;
    static final int EXTENSION_TYPE_TYPE4_CLIENT = 0;
    static final int EXTENSION_TYPE_TYPE4_SERVER = 1;
    static final int EXTENSION_TYPE_TYPE2_CLIENT = 2;
    static final int EXTENSION_TYPE_TYPE2_SERVER = 3;
    private static final int NUMBER_OF_EXTENSION_TYPES = 4;
    private OracleDriverExtension[] driverExtensions;
    private static final String DRIVER_PACKAGE_STRING = "driver";
    private static final String[] driverExtensionClassNames;
    private static Properties driverAccess;
    protected static Connection defaultConn;
    private static OracleDriver defaultDriver;
    public static final Map<String, ClassRef> systemTypeMap;
    private static final String DEFAULT_CONNECTION_PROPERTIES_RESOURCE_NAME = "/oracle/jdbc/defaultConnectionProperties.properties";
    protected static final Properties DEFAULT_CONNECTION_PROPERTIES;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleDriver() {
        this.driverExtensions = new OracleDriverExtension[4];
    }
    
    public static void registerMBeans() {
        try {
            MBeanServer mBeanServer;
            try {
                final ClassRef instance = ClassRef.newInstance("oracle.as.jmx.framework.PortableMBeanFactory");
                mBeanServer = (MBeanServer)instance.get().getMethod("getMBeanServer", (Class[])new Class[0]).invoke(instance.get().getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]), new Object[0]);
            }
            catch (ClassNotFoundException ex) {
                mBeanServer = ManagementFactory.getPlatformMBeanServer();
            }
            catch (NoSuchMethodException thrown) {
                Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but not the getMBeanServer method.", thrown);
                mBeanServer = ManagementFactory.getPlatformMBeanServer();
            }
            catch (InstantiationException thrown2) {
                Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not create an instance.", thrown2);
                mBeanServer = ManagementFactory.getPlatformMBeanServer();
            }
            catch (IllegalAccessException thrown3) {
                Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not access the getMBeanServer method.", thrown3);
                mBeanServer = ManagementFactory.getPlatformMBeanServer();
            }
            catch (InvocationTargetException thrown4) {
                Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but the getMBeanServer method threw an exception.", thrown4);
                mBeanServer = ManagementFactory.getPlatformMBeanServer();
            }
            if (mBeanServer != null) {
                final ClassLoader classLoader = OracleDriver.class.getClassLoader();
                final String str = (classLoader == null) ? "nullLoader" : classLoader.getClass().getName();
                int n = 0;
                while (true) {
                    final ObjectName objectName = new ObjectName("com.oracle.jdbc:type=diagnosability,name=" + (str + "@" + Integer.toHexString(((classLoader == null) ? 0 : classLoader.hashCode()) + n++)));
                    try {
                        mBeanServer.registerMBean(new OracleDiagnosabilityMBean(), objectName);
                    }
                    catch (InstanceAlreadyExistsException ex2) {
                        continue;
                    }
                    break;
                }
            }
            else {
                Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBears are registered.");
            }
        }
        catch (JMException thrown5) {
            Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", thrown5);
        }
        catch (Throwable thrown6) {
            Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", thrown6);
        }
    }
    
    @Override
    public Connection connect(String s, Properties properties) throws SQLException {
        if (s.regionMatches(0, "jdbc:default:connection", 0, 23)) {
            final String s2 = "jdbc:oracle:kprb";
            if (s.length() > 23) {
                s = s2.concat(s.substring(23, s.length()));
            }
            else {
                s = s2.concat(":");
            }
        }
        final int oracleDriverExtensionTypeFromURL = oracleDriverExtensionTypeFromURL(s);
        if (oracleDriverExtensionTypeFromURL == -2) {
            return null;
        }
        if (oracleDriverExtensionTypeFromURL == -3) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        OracleDriverExtension oracleDriverExtension = this.driverExtensions[oracleDriverExtensionTypeFromURL];
        if (oracleDriverExtension == null) {
            try {
                synchronized (this) {
                    if (oracleDriverExtension == null) {
                        oracleDriverExtension = (OracleDriverExtension)Class.forName(OracleDriver.driverExtensionClassNames[oracleDriverExtensionTypeFromURL]).newInstance();
                        this.driverExtensions[oracleDriverExtensionTypeFromURL] = oracleDriverExtension;
                    }
                    else {
                        oracleDriverExtension = this.driverExtensions[oracleDriverExtensionTypeFromURL];
                    }
                }
            }
            catch (Exception ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        if (properties == null) {
            properties = new Properties();
        }
        final Enumeration<Driver> drivers = DriverManager.getDrivers();
        while (drivers.hasMoreElements()) {
            if (drivers.nextElement() instanceof OracleDriver) {
                break;
            }
        }
        while (drivers.hasMoreElements()) {
            final Driver driver = drivers.nextElement();
            if (driver instanceof OracleDriver) {
                DriverManager.deregisterDriver(driver);
            }
        }
        final PhysicalConnection physicalConnection = (PhysicalConnection)oracleDriverExtension.getConnection(s, properties);
        physicalConnection.protocolId = oracleDriverExtensionTypeFromURL;
        return physicalConnection;
    }
    
    public Connection defaultConnection() throws SQLException {
        if (OracleDriver.defaultConn == null || OracleDriver.defaultConn.isClosed()) {
            synchronized (OracleDriver.class) {
                if (OracleDriver.defaultConn == null || OracleDriver.defaultConn.isClosed()) {
                    OracleDriver.defaultConn = this.connect("jdbc:oracle:kprb:", new Properties());
                }
            }
        }
        return OracleDriver.defaultConn;
    }
    
    static final int oracleDriverExtensionTypeFromURL(final String s) {
        int index = s.indexOf(58);
        if (index == -1) {
            return -2;
        }
        if (!s.regionMatches(true, 0, "jdbc", 0, index)) {
            return -2;
        }
        ++index;
        int index2 = s.indexOf(58, index);
        if (index2 == -1) {
            return -2;
        }
        if (!s.regionMatches(true, index, "oracle", 0, index2 - index)) {
            return -2;
        }
        ++index2;
        final int index3 = s.indexOf(58, index2);
        if (index3 == -1) {
            return -3;
        }
        final String substring = s.substring(index2, index3);
        if (substring.equals("thin")) {
            return 0;
        }
        if (substring.equals("oci8") || substring.equals("oci")) {
            return 2;
        }
        return -3;
    }
    
    @Override
    public boolean acceptsURL(final String s) {
        return s.startsWith("jdbc:oracle:") && oracleDriverExtensionTypeFromURL(s) > -2;
    }
    
    @Override
    public DriverPropertyInfo[] getPropertyInfo(final String s, final Properties properties) throws SQLException {
        Class value = null;
        try {
            value = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
        }
        catch (ClassNotFoundException ex) {}
        int n = 0;
        String[] array = new String[150];
        String[] array2 = new String[150];
        final Field[] fields = value.getFields();
        for (int i = 0; i < fields.length; ++i) {
            if (fields[i].getName().startsWith("CONNECTION_PROPERTY_") && !fields[i].getName().endsWith("_DEFAULT") && !fields[i].getName().endsWith("_ACCESSMODE")) {
                try {
                    final String s2 = (String)fields[i].get(null);
                    final String s3 = (String)value.getField(fields[i].getName() + "_DEFAULT").get(null);
                    if (n == array.length) {
                        final String[] array3 = new String[array.length * 2];
                        final String[] array4 = new String[array.length * 2];
                        System.arraycopy(array, 0, array3, 0, array.length);
                        System.arraycopy(array2, 0, array4, 0, array.length);
                        array = array3;
                        array2 = array4;
                    }
                    array[n] = s2;
                    array2[n] = s3;
                    ++n;
                }
                catch (IllegalAccessException ex2) {}
                catch (NoSuchFieldException ex3) {}
            }
        }
        final DriverPropertyInfo[] array5 = new DriverPropertyInfo[n];
        for (int j = 0; j < n; ++j) {
            array5[j] = new DriverPropertyInfo(array[j], array2[j]);
        }
        return array5;
    }
    
    @Override
    public int getMajorVersion() {
        return OracleDatabaseMetaData.getDriverMajorVersionInfo();
    }
    
    @Override
    public int getMinorVersion() {
        return OracleDatabaseMetaData.getDriverMinorVersionInfo();
    }
    
    @Override
    public boolean jdbcCompliant() {
        return true;
    }
    
    public String processSqlEscapes(final String s) throws SQLException {
        final OracleSql oracleSql = new OracleSql(null);
        oracleSql.initialize(s);
        return oracleSql.parse(s);
    }
    
    public static String getCompileTime() {
        return "Thu_Aug_26_18:10:24_PDT_2010";
    }
    
    public static String getSystemPropertyFastConnectionFailover(final String s) {
        return PhysicalConnection.getSystemPropertyFastConnectionFailover(s);
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        driverExtensionClassNames = new String[] { "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T2CDriverExtension", "oracle.jdbc.driver.T2SDriverExtension" };
        OracleDriver.defaultConn = null;
        OracleDriver.defaultDriver = null;
        try {
            if (OracleDriver.defaultDriver == null) {
                DriverManager.registerDriver(OracleDriver.defaultDriver = new oracle.jdbc.OracleDriver());
            }
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
                @Override
                public Object run() {
                    OracleDriver.registerMBeans();
                    return null;
                }
            });
            Timestamp.valueOf("2000-01-01 00:00:00.0");
        }
        catch (SQLException thrown) {
            Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "SQLException in static block.", thrown);
        }
        catch (RuntimeException thrown2) {
            Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "RuntimeException in static block.", thrown2);
        }
        try {
            ClassRef.newInstance("oracle.security.pki.OraclePKIProvider").get().newInstance();
        }
        catch (Throwable t) {}
        systemTypeMap = new Hashtable<String, ClassRef>(3);
        try {
            OracleDriver.systemTypeMap.put("SYS.XMLTYPE", ClassRef.newInstance("oracle.xdb.XMLTypeFactory"));
        }
        catch (ClassNotFoundException ex) {}
        try {
            OracleDriver.systemTypeMap.put("SYS.ANYDATA", ClassRef.newInstance("oracle.sql.AnyDataFactory"));
            OracleDriver.systemTypeMap.put("SYS.ANYTYPE", ClassRef.newInstance("oracle.sql.TypeDescriptorFactory"));
        }
        catch (ClassNotFoundException ex2) {}
        DEFAULT_CONNECTION_PROPERTIES = new Properties();
        try {
            final InputStream resourceAsStream = PhysicalConnection.class.getResourceAsStream("/oracle/jdbc/defaultConnectionProperties.properties");
            if (resourceAsStream != null) {
                OracleDriver.DEFAULT_CONNECTION_PROPERTIES.load(resourceAsStream);
            }
        }
        catch (IOException ex3) {}
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
