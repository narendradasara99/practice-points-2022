// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLXML;
import java.sql.RowId;
import oracle.sql.NCLOB;
import java.sql.NClob;
import java.net.URL;
import java.util.Calendar;
import java.io.Reader;
import java.sql.Array;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Ref;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import oracle.jdbc.OracleResultSet;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.BFILE;
import oracle.sql.CLOB;
import oracle.sql.BLOB;
import oracle.sql.RAW;
import oracle.sql.CHAR;
import oracle.sql.REF;
import oracle.sql.OPAQUE;
import oracle.sql.STRUCT;
import oracle.sql.DATE;
import oracle.sql.ROWID;
import oracle.sql.NUMBER;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.sql.ARRAY;
import java.util.Map;
import oracle.sql.Datum;

class ArrayDataResultSet extends BaseResultSet
{
    Datum[] data;
    Map map;
    private int currentIndex;
    private int lastIndex;
    PhysicalConnection connection;
    private Boolean wasNull;
    private int fetchSize;
    ARRAY array;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public ArrayDataResultSet(final OracleConnection oracleConnection, final Datum[] data, final Map map) throws SQLException {
        this.connection = (PhysicalConnection)oracleConnection;
        this.data = data;
        this.map = map;
        this.currentIndex = 0;
        this.lastIndex = ((this.data == null) ? 0 : this.data.length);
        this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    }
    
    public ArrayDataResultSet(final OracleConnection oracleConnection, final Datum[] data, final long n, final int b, final Map map) throws SQLException {
        this.connection = (PhysicalConnection)oracleConnection;
        this.data = data;
        this.map = map;
        this.currentIndex = (int)n - 1;
        this.lastIndex = this.currentIndex + Math.min(((this.data == null) ? 0 : this.data.length) - this.currentIndex, b);
        this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    }
    
    public ArrayDataResultSet(final OracleConnection oracleConnection, final ARRAY array, final long n, final int b, final Map map) throws SQLException {
        this.connection = (PhysicalConnection)oracleConnection;
        this.array = array;
        this.map = map;
        this.currentIndex = (int)n - 1;
        final int n2 = (this.array == null) ? 0 : array.length();
        this.lastIndex = this.currentIndex + ((b == -1) ? (n2 - this.currentIndex) : Math.min(n2 - this.currentIndex, b));
        this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    }
    
    @Override
    public boolean next() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10, "next");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        ++this.currentIndex;
        return this.currentIndex <= this.lastIndex;
    }
    
    @Override
    public void close() throws SQLException {
        synchronized (this.connection) {
            super.close();
        }
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        synchronized (this.connection) {
            if (this.wasNull == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 24, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.wasNull;
        }
    }
    
    @Override
    public String getString(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.stringValue();
            }
            return null;
        }
    }
    
    @Override
    public ResultSet getCursor(final int n) throws SQLException {
        synchronized (this.connection) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCursor");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public Datum getOracleObject(final int n) throws SQLException {
        if (this.currentIndex <= 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 14, null);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n == 1) {
            this.wasNull = Boolean.FALSE;
            return new NUMBER(this.currentIndex);
        }
        if (n != 2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3, null);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.data != null) {
            this.wasNull = ((this.data[this.currentIndex - 1] == null) ? Boolean.TRUE : Boolean.FALSE);
            return this.data[this.currentIndex - 1];
        }
        if (this.array != null) {
            final Datum[] oracleArray = this.array.getOracleArray(this.currentIndex, 1);
            if (oracleArray != null && oracleArray.length >= 1) {
                this.wasNull = ((oracleArray[0] == null) ? Boolean.TRUE : Boolean.FALSE);
                return oracleArray[0];
            }
        }
        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Out of sync");
        sqlException3.fillInStackTrace();
        throw sqlException3;
    }
    
    @Override
    public ROWID getROWID(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof ROWID) {
                return (ROWID)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getROWID");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public NUMBER getNUMBER(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof NUMBER) {
                return (NUMBER)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getNUMBER");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public DATE getDATE(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof DATE) {
                return (DATE)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getDATE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public ARRAY getARRAY(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof ARRAY) {
                return (ARRAY)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getARRAY");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public STRUCT getSTRUCT(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof STRUCT) {
                return (STRUCT)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public OPAQUE getOPAQUE(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof OPAQUE) {
                return (OPAQUE)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public REF getREF(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof REF) {
                return (REF)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getREF");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public CHAR getCHAR(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof CHAR) {
                return (CHAR)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCHAR");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public RAW getRAW(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof RAW) {
                return (RAW)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getRAW");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public BLOB getBLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof BLOB) {
                return (BLOB)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBLOB");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public CLOB getCLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof CLOB) {
                return (CLOB)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCLOB");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public BFILE getBFILE(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof BFILE) {
                return (BFILE)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBFILE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof INTERVALDS) {
                return (INTERVALDS)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof INTERVALYM) {
                return (INTERVALYM)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public BFILE getBfile(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getBFILE(n);
        }
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof TIMESTAMP) {
                return (TIMESTAMP)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof TIMESTAMPTZ) {
                return (TIMESTAMPTZ)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof TIMESTAMPLTZ) {
                return (TIMESTAMPLTZ)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public boolean getBoolean(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            return oracleObject != null && oracleObject.booleanValue();
        }
    }
    
    @Override
    public AuthorizationIndicator getAuthorizationIndicator(final int n) throws SQLException {
        return null;
    }
    
    @Override
    public byte getByte(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.byteValue();
            }
            return 0;
        }
    }
    
    @Override
    public short getShort(final int n) throws SQLException {
        synchronized (this.connection) {
            final long long1 = this.getLong(n);
            if (long1 > 65537L || long1 < -65538L) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26, "getShort");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return (short)long1;
        }
    }
    
    @Override
    public int getInt(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.intValue();
            }
            return 0;
        }
    }
    
    @Override
    public long getLong(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.longValue();
            }
            return 0L;
        }
    }
    
    @Override
    public float getFloat(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.floatValue();
            }
            return 0.0f;
        }
    }
    
    @Override
    public double getDouble(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.doubleValue();
            }
            return 0.0;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.bigDecimalValue();
            }
            return null;
        }
    }
    
    @Override
    public byte[] getBytes(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof RAW) {
                return ((RAW)oracleObject).shareBytes();
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBytes");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public Date getDate(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.dateValue();
            }
            return null;
        }
    }
    
    @Override
    public Time getTime(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.timeValue();
            }
            return null;
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.timestampValue();
            }
            return null;
        }
    }
    
    @Override
    public InputStream getAsciiStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                oracleObject.asciiStreamValue();
            }
            return null;
        }
    }
    
    @Override
    public InputStream getUnicodeStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            final DBConversion conversion = this.connection.conversion;
            final byte[] shareBytes = oracleObject.shareBytes();
            if (oracleObject instanceof RAW) {
                final DBConversion dbConversion = conversion;
                final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(shareBytes);
                final PhysicalConnection connection = this.connection;
                return dbConversion.ConvertStream(byteArrayInputStream, 3);
            }
            if (oracleObject instanceof CHAR) {
                final DBConversion dbConversion2 = conversion;
                final ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(shareBytes);
                final PhysicalConnection connection2 = this.connection;
                return dbConversion2.ConvertStream(byteArrayInputStream2, 1);
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public InputStream getBinaryStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.binaryStreamValue();
            }
            return null;
        }
    }
    
    @Override
    public Object getObject(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getObject(n, this.map);
        }
    }
    
    @Override
    @Deprecated
    public CustomDatum getCustomDatum(final int n, final CustomDatumFactory customDatumFactory) throws SQLException {
        synchronized (this.connection) {
            return customDatumFactory.create(this.getOracleObject(n), 0);
        }
    }
    
    @Override
    public ORAData getORAData(final int n, final ORADataFactory oraDataFactory) throws SQLException {
        synchronized (this.connection) {
            return oraDataFactory.create(this.getOracleObject(n), 0);
        }
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10, "getMetaData");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "getMetaData");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public int findColumn(final String s) throws SQLException {
        synchronized (this.connection) {
            if (s.equalsIgnoreCase("index")) {
                return 1;
            }
            if (s.equalsIgnoreCase("value")) {
                return 2;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6, "get_column_index");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public Statement getStatement() throws SQLException {
        return null;
    }
    
    @Override
    public Object getObject(final int n, final Map map) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof STRUCT) {
                return ((STRUCT)oracleObject).toJdbc(map);
            }
            return oracleObject.toJdbc();
        }
    }
    
    @Override
    public Ref getRef(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getREF(n);
        }
    }
    
    @Override
    public Blob getBlob(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getBLOB(n);
        }
    }
    
    @Override
    public Clob getClob(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getCLOB(n);
        }
    }
    
    @Override
    public Array getArray(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getARRAY(n);
        }
    }
    
    @Override
    public Reader getCharacterStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.characterStreamValue();
            }
            return null;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.bigDecimalValue();
            }
            return null;
        }
    }
    
    @Override
    public Date getDate(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                DATE date;
                if (oracleObject instanceof DATE) {
                    date = (DATE)oracleObject;
                }
                else {
                    date = new DATE(oracleObject.stringValue());
                }
                if (date != null) {
                    return date.dateValue(calendar);
                }
            }
            return null;
        }
    }
    
    @Override
    public Time getTime(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                DATE date;
                if (oracleObject instanceof DATE) {
                    date = (DATE)oracleObject;
                }
                else {
                    date = new DATE(oracleObject.stringValue());
                }
                if (date != null) {
                    return date.timeValue(calendar);
                }
            }
            return null;
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                DATE date;
                if (oracleObject instanceof DATE) {
                    date = (DATE)oracleObject;
                }
                else {
                    date = new DATE(oracleObject.stringValue());
                }
                if (date != null) {
                    return date.timestampValue(calendar);
                }
            }
            return null;
        }
    }
    
    @Override
    public URL getURL(final int n) throws SQLException {
        synchronized (this.connection) {
            final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
            unsupportedFeatureSqlException.fillInStackTrace();
            throw unsupportedFeatureSqlException;
        }
    }
    
    @Override
    public String getCursorName() throws SQLException {
        synchronized (this.connection) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "getCursorName");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public NClob getNClob(final int n) throws SQLException {
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject == null) {
            return null;
        }
        if (oracleObject instanceof NCLOB) {
            return (NCLOB)oracleObject;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public String getNString(final int n) throws SQLException {
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject != null) {
            return oracleObject.stringValue();
        }
        return null;
    }
    
    @Override
    public Reader getNCharacterStream(final int n) throws SQLException {
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject != null) {
            return oracleObject.characterStreamValue();
        }
        return null;
    }
    
    @Override
    public RowId getRowId(final int n) throws SQLException {
        return this.getROWID(n);
    }
    
    @Override
    public SQLXML getSQLXML(final int n) throws SQLException {
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject == null) {
            return null;
        }
        if (oracleObject instanceof SQLXML) {
            return (SQLXML)oracleObject;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public boolean isBeforeFirst() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.currentIndex < 1;
    }
    
    @Override
    public boolean isAfterLast() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.currentIndex > this.lastIndex;
    }
    
    @Override
    public boolean isFirst() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.currentIndex == 1;
    }
    
    @Override
    public boolean isLast() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.currentIndex == this.lastIndex;
    }
    
    @Override
    public int getRow() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.currentIndex;
    }
    
    @Override
    public void setFetchSize(final int fetchSize) throws SQLException {
        if (fetchSize < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (fetchSize == 0) {
            this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
        }
        else {
            this.fetchSize = fetchSize;
        }
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        return this.fetchSize;
    }
    
    @Override
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
