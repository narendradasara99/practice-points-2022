// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

abstract class OracleInputStream extends OracleBufferedStream
{
    int columnIndex;
    Accessor accessor;
    OracleInputStream nextStream;
    boolean hasBeenOpen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected OracleInputStream(final OracleStatement statement, final int columnIndex, final Accessor accessor) {
        super(statement, statement.connection.getDefaultStreamChunkSize());
        this.hasBeenOpen = false;
        this.closed = true;
        this.statement = statement;
        this.columnIndex = columnIndex;
        this.accessor = accessor;
        this.nextStream = null;
        OracleInputStream oracleInputStream = this.statement.streamList;
        if (oracleInputStream == null || this.columnIndex < oracleInputStream.columnIndex) {
            this.nextStream = this.statement.streamList;
            this.statement.streamList = this;
        }
        else if (this.columnIndex == oracleInputStream.columnIndex) {
            this.nextStream = oracleInputStream.nextStream;
            oracleInputStream.nextStream = null;
            this.statement.streamList = this;
        }
        else {
            while (oracleInputStream.nextStream != null && this.columnIndex > oracleInputStream.nextStream.columnIndex) {
                oracleInputStream = oracleInputStream.nextStream;
            }
            if (oracleInputStream.nextStream != null && this.columnIndex == oracleInputStream.nextStream.columnIndex) {
                this.nextStream = oracleInputStream.nextStream.nextStream;
                oracleInputStream.nextStream.nextStream = null;
                oracleInputStream.nextStream = this;
            }
            else {
                this.nextStream = oracleInputStream.nextStream;
                oracleInputStream.nextStream = this;
            }
        }
    }
    
    @Override
    public String toString() {
        return "OIS@" + Integer.toHexString(this.hashCode()) + "{" + "statement = " + this.statement + ", accessor = " + this.accessor + ", nextStream = " + this.nextStream + ", columnIndex = " + this.columnIndex + ", hasBeenOpen = " + this.hasBeenOpen + "}";
    }
    
    @Override
    public boolean needBytes(final int a) throws IOException {
        if (this.closed) {
            return false;
        }
        if (this.pos >= this.count) {
            if (a > this.currentBufferSize) {
                this.currentBufferSize = Math.max(a, this.initialBufferSize);
                this.resizableBuffer = new byte[this.currentBufferSize];
            }
            try {
                final int bytes = this.getBytes(this.currentBufferSize);
                this.pos = 0;
                this.count = bytes;
                if (this.count == -1) {
                    if (this.nextStream == null) {
                        this.statement.connection.releaseLine();
                    }
                    this.closed = true;
                    this.accessor.fetchNextColumns();
                    return false;
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
        return true;
    }
    
    @Override
    public boolean isNull() throws IOException {
        boolean null;
        try {
            null = this.accessor.isNull(0);
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
        return null;
    }
    
    public boolean isClosed() {
        return this.closed;
    }
    
    @Override
    public void close() throws IOException {
        synchronized (this.statement.connection) {
            if (!this.closed && this.hasBeenOpen) {
                while (this.statement.nextStream != this) {
                    this.statement.nextStream.close();
                    this.statement.nextStream = this.statement.nextStream.nextStream;
                }
                if (!this.isNull()) {
                    while (this.needBytes(Math.max(this.initialBufferSize, this.currentBufferSize))) {
                        this.pos = this.count;
                    }
                }
                this.closed = true;
                this.resizableBuffer = null;
                this.currentBufferSize = 0;
            }
        }
    }
    
    public abstract int getBytes(final int p0) throws IOException;
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
