// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CTTIqcinv extends T4CTTIMsg
{
    long kpdqcqid;
    long kpdqcopflg;
    T4CTTIkscn kpdqcscn;
    
    T4CTTIqcinv(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)0);
        this.kpdqcscn = null;
    }
    
    void unmarshal() throws SQLException, IOException {
        this.kpdqcqid = this.meg.unmarshalSB8();
        this.kpdqcopflg = this.meg.unmarshalUB4();
        (this.kpdqcscn = new T4CTTIkscn(this.connection)).unmarshal();
    }
}
