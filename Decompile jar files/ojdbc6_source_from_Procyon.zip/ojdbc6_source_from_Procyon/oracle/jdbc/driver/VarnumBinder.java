// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

abstract class VarnumBinder extends Binder
{
    static final boolean DEBUG = false;
    static final boolean SLOW_CONVERSIONS = true;
    Binder theVarnumCopyingBinder;
    static final int LNXSGNBT = 128;
    static final byte LNXDIGS = 20;
    static final byte LNXEXPBS = 64;
    static final int LNXEXPMX = 127;
    static final double[] factorTable;
    static final int MANTISSA_SIZE = 53;
    static final int expShift = 52;
    static final long fractHOB = 4503599627370496L;
    static final long fractMask = 4503599627370495L;
    static final int expBias = 1023;
    static final int maxSmallBinExp = 62;
    static final int minSmallBinExp = -21;
    static final long expOne = 4607182418800017408L;
    static final long highbyte = -72057594037927936L;
    static final long highbit = Long.MIN_VALUE;
    static final long lowbytes = 72057594037927935L;
    static final int[] small5pow;
    static final long[] long5pow;
    static final int[] n5bits;
    static FDBigInt[] b5p;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 6;
        binder.bytelen = 22;
    }
    
    VarnumBinder() {
        this.theVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theVarnumCopyingBinder;
    }
    
    static int setLongInternal(final byte[] array, final int n, long n2) {
        if (n2 == 0L) {
            array[n] = -128;
            return 1;
        }
        if (n2 == Long.MIN_VALUE) {
            array[n] = 53;
            array[n + 1] = 92;
            array[n + 2] = 79;
            array[n + 3] = 68;
            array[n + 4] = 29;
            array[n + 5] = 98;
            array[n + 6] = 33;
            array[n + 7] = 47;
            array[n + 8] = 24;
            array[n + 9] = 43;
            array[n + 10] = 93;
            array[n + 11] = 102;
            return 12;
        }
        int n3 = 10;
        int n4 = 0;
        if (n2 / 1000000000000000000L == 0L) {
            --n3;
            if (n2 / 10000000000000000L == 0L) {
                --n3;
                if (n2 / 100000000000000L == 0L) {
                    --n3;
                    if (n2 / 1000000000000L == 0L) {
                        --n3;
                        if (n2 / 10000000000L == 0L) {
                            --n3;
                            if (n2 / 100000000L == 0L) {
                                --n3;
                                if (n2 / 1000000L == 0L) {
                                    --n3;
                                    if (n2 / 10000L == 0L) {
                                        --n3;
                                        if (n2 / 100L == 0L) {
                                            --n3;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        int n5 = n + n3;
        if (n2 < 0L) {
            n2 = -n2;
            array[n] = (byte)(63 - n3);
            while (true) {
                final int n6 = (int)(n2 % 100L);
                if (n4 == 0) {
                    if (n6 != 0) {
                        array[n5 + 1] = 102;
                        n4 = n5 + 2 - n;
                        array[n5] = (byte)(101 - n6);
                    }
                }
                else {
                    array[n5] = (byte)(101 - n6);
                }
                if (--n5 == n) {
                    break;
                }
                n2 /= 100L;
            }
        }
        else {
            array[n] = (byte)(192 + n3);
            while (true) {
                final int n7 = (int)(n2 % 100L);
                if (n4 == 0) {
                    if (n7 != 0) {
                        n4 = n5 + 1 - n;
                        array[n5] = (byte)(n7 + 1);
                    }
                }
                else {
                    array[n5] = (byte)(n7 + 1);
                }
                if (--n5 == n) {
                    break;
                }
                n2 /= 100L;
            }
        }
        return n4;
    }
    
    static int countBits(long n) {
        if (n == 0L) {
            return 0;
        }
        while ((n & 0xFF00000000000000L) == 0x0L) {
            n <<= 8;
        }
        while (n > 0L) {
            n <<= 1;
        }
        int n2;
        for (n2 = 0; (n & 0xFFFFFFFFFFFFFFL) != 0x0L; n <<= 8, n2 += 8) {}
        while (n != 0L) {
            n <<= 1;
            ++n2;
        }
        return n2;
    }
    
    boolean roundup(final char[] array, final int n) {
        int n2 = n - 1;
        char c = array[n2];
        if (c == '9') {
            while (c == '9' && n2 > 0) {
                array[n2] = '0';
                c = array[--n2];
            }
            if (c == '9') {
                array[0] = '1';
                return true;
            }
        }
        array[n2] = (char)(c + '\u0001');
        return false;
    }
    
    static FDBigInt big5pow(final int n) {
        if (n < 0) {
            throw new RuntimeException("Assertion botch: negative power of 5");
        }
        if (VarnumBinder.b5p == null) {
            VarnumBinder.b5p = new FDBigInt[n + 1];
        }
        else if (VarnumBinder.b5p.length <= n) {
            final FDBigInt[] b5p = new FDBigInt[n + 1];
            System.arraycopy(VarnumBinder.b5p, 0, b5p, 0, VarnumBinder.b5p.length);
            VarnumBinder.b5p = b5p;
        }
        if (VarnumBinder.b5p[n] != null) {
            return VarnumBinder.b5p[n];
        }
        if (n < VarnumBinder.small5pow.length) {
            return VarnumBinder.b5p[n] = new FDBigInt(VarnumBinder.small5pow[n]);
        }
        if (n < VarnumBinder.long5pow.length) {
            return VarnumBinder.b5p[n] = new FDBigInt(VarnumBinder.long5pow[n]);
        }
        final int n2 = n >> 1;
        final int n3 = n - n2;
        FDBigInt big5pow = VarnumBinder.b5p[n2];
        if (big5pow == null) {
            big5pow = big5pow(n2);
        }
        if (n3 < VarnumBinder.small5pow.length) {
            return VarnumBinder.b5p[n] = big5pow.mult(VarnumBinder.small5pow[n3]);
        }
        FDBigInt big5pow2 = VarnumBinder.b5p[n3];
        if (big5pow2 == null) {
            big5pow2 = big5pow(n3);
        }
        return VarnumBinder.b5p[n] = big5pow.mult(big5pow2);
    }
    
    static FDBigInt multPow52(FDBigInt fdBigInt, final int n, final int n2) {
        if (n != 0) {
            if (n < VarnumBinder.small5pow.length) {
                fdBigInt = fdBigInt.mult(VarnumBinder.small5pow[n]);
            }
            else {
                fdBigInt = fdBigInt.mult(big5pow(n));
            }
        }
        if (n2 != 0) {
            fdBigInt.lshiftMe(n2);
        }
        return fdBigInt;
    }
    
    static FDBigInt constructPow52(final int n, final int n2) {
        final FDBigInt fdBigInt = new FDBigInt(big5pow(n));
        if (n2 != 0) {
            fdBigInt.lshiftMe(n2);
        }
        return fdBigInt;
    }
    
    int dtoa(final byte[] array, final int n, final double n2, final boolean b, final boolean b2, final char[] array2, final int n3, long n4, final int n5) {
        int n6 = Integer.MAX_VALUE;
        int n7 = -1;
        final int countBits = countBits(n4);
        int n8 = countBits - n3 - 1;
        boolean b3 = false;
        if (n8 < 0) {
            n8 = 0;
        }
        if (n3 <= 62 && n3 >= -21 && n8 < VarnumBinder.long5pow.length && countBits + VarnumBinder.n5bits[n8] < 64 && n8 == 0) {
            long n9;
            if (n3 > n5) {
                n9 = 1L << n3 - n5 - 1;
            }
            else {
                n9 = 0L;
            }
            if (n3 >= 52) {
                n4 <<= n3 - 52;
            }
            else {
                n4 >>>= 52 - n3;
            }
            int n10 = 0;
            long n11 = n4;
            long n12;
            int n13;
            for (n12 = n9, n13 = 0; n12 >= 10L; n12 /= 10L, ++n13) {}
            if (n13 != 0) {
                final long n14 = VarnumBinder.long5pow[n13] << n13;
                final long n15 = n11 % n14;
                n11 /= n14;
                n10 += n13;
                if (n15 >= n14 >> 1) {
                    ++n11;
                }
            }
            int n17;
            int n18;
            if (n11 <= 2147483647L) {
                final int n16 = (int)n11;
                n17 = 10;
                n18 = n17 - 1;
                int i;
                int j;
                for (i = n16 % 10, j = n16 / 10; i == 0; i = j % 10, j /= 10) {
                    ++n10;
                }
                while (j != 0) {
                    array2[n18--] = (char)(i + 48);
                    ++n10;
                    i = j % 10;
                    j /= 10;
                }
                array2[n18] = (char)(i + 48);
            }
            else {
                n17 = 20;
                n18 = n17 - 1;
                int k;
                long n19;
                for (k = (int)(n11 % 10L), n19 = n11 / 10L; k == 0; k = (int)(n19 % 10L), n19 /= 10L) {
                    ++n10;
                }
                while (n19 != 0L) {
                    array2[n18--] = (char)(k + 48);
                    ++n10;
                    k = (int)(n19 % 10L);
                    n19 /= 10L;
                }
                array2[n18] = (char)(k + 48);
            }
            final int n20 = n17 - n18;
            if (n18 != 0) {
                System.arraycopy(array2, n18, array2, 0, n20);
            }
            n6 = n10 + 1;
            n7 = n20;
            b3 = true;
        }
        if (!b3) {
            int b4 = (int)Math.floor((Double.longBitsToDouble(0x3FF0000000000000L | (n4 & 0xFFEFFFFFFFFFFFFFL)) - 1.5) * 0.289529654 + 0.176091259 + n3 * 0.301029995663981);
            final int max = Math.max(0, -b4);
            final int n21 = max + n8 + n3;
            final int max2 = Math.max(0, b4);
            final int b5 = max2 + n8;
            final int n22 = max;
            final int n23 = n21 - n5;
            n4 >>>= 53 - countBits;
            final int a = n21 - (countBits - 1);
            final int min = Math.min(a, b5);
            int n24 = a - min;
            int n25 = b5 - min;
            int n26 = n23 - min;
            if (countBits == 1) {
                --n26;
            }
            if (n26 < 0) {
                n24 -= n26;
                n25 -= n26;
                n26 = 0;
            }
            final int n27 = countBits + n24 + ((max < VarnumBinder.n5bits.length) ? VarnumBinder.n5bits[max] : (max * 3));
            final int n28 = n25 + 1 + ((max2 + 1 < VarnumBinder.n5bits.length) ? VarnumBinder.n5bits[max2 + 1] : ((max2 + 1) * 3));
            int n33;
            int n37;
            int n38;
            long n40;
            if (n27 < 64 && n28 < 64) {
                if (n27 < 32 && n28 < 32) {
                    final int n29 = (int)n4 * VarnumBinder.small5pow[max] << n24;
                    final int n30 = VarnumBinder.small5pow[max2] << n25;
                    final int n31 = VarnumBinder.small5pow[n22] << n26;
                    final int n32 = n30 * 10;
                    n33 = 0;
                    final int n34 = n29 / n30;
                    int n35 = 10 * (n29 % n30);
                    int n36 = n31 * 10;
                    n37 = ((n35 < n36) ? 1 : 0);
                    n38 = ((n35 + n36 > n32) ? 1 : 0);
                    if (n34 == 0 && n38 == 0) {
                        --b4;
                    }
                    else {
                        array2[n33++] = (char)(48 + n34);
                    }
                    if (b4 <= -3 || b4 >= 8) {
                        n37 = (n38 = 0);
                    }
                    while (n37 == 0 && n38 == 0) {
                        final int n39 = n35 / n30;
                        n35 = 10 * (n35 % n30);
                        n36 *= 10;
                        if (n36 > 0L) {
                            n37 = ((n35 < n36) ? 1 : 0);
                            n38 = ((n35 + n36 > n32) ? 1 : 0);
                        }
                        else {
                            n37 = 1;
                            n38 = 1;
                        }
                        array2[n33++] = (char)(48 + n39);
                    }
                    n40 = (n35 << 1) - n32;
                }
                else {
                    final long n41 = n4 * VarnumBinder.long5pow[max] << n24;
                    final long n42 = VarnumBinder.long5pow[max2] << n25;
                    final long n43 = VarnumBinder.long5pow[n22] << n26;
                    final long n44 = n42 * 10L;
                    n33 = 0;
                    final int n45 = (int)(n41 / n42);
                    long n46 = 10L * (n41 % n42);
                    long n47 = n43 * 10L;
                    n37 = ((n46 < n47) ? 1 : 0);
                    n38 = ((n46 + n47 > n44) ? 1 : 0);
                    if (n45 == 0 && n38 == 0) {
                        --b4;
                    }
                    else {
                        array2[n33++] = (char)(48 + n45);
                    }
                    if (b4 <= -3 || b4 >= 8) {
                        n37 = (n38 = 0);
                    }
                    while (n37 == 0 && n38 == 0) {
                        final int n48 = (int)(n46 / n42);
                        n46 = 10L * (n46 % n42);
                        n47 *= 10L;
                        if (n47 > 0L) {
                            n37 = ((n46 < n47) ? 1 : 0);
                            n38 = ((n46 + n47 > n44) ? 1 : 0);
                        }
                        else {
                            n37 = 1;
                            n38 = 1;
                        }
                        array2[n33++] = (char)(48 + n48);
                    }
                    n40 = (n46 << 1) - n44;
                }
            }
            else {
                final FDBigInt multPow52 = multPow52(new FDBigInt(n4), max, n24);
                final FDBigInt constructPow52 = constructPow52(max2, n25);
                final FDBigInt constructPow53 = constructPow52(n22, n26);
                final int normalizeMe;
                multPow52.lshiftMe(normalizeMe = constructPow52.normalizeMe());
                constructPow53.lshiftMe(normalizeMe);
                final FDBigInt mult = constructPow52.mult(10);
                n33 = 0;
                final int quoRemIteration = multPow52.quoRemIteration(constructPow52);
                FDBigInt fdBigInt = constructPow53.mult(10);
                n37 = ((multPow52.cmp(fdBigInt) < 0) ? 1 : 0);
                n38 = ((multPow52.add(fdBigInt).cmp(mult) > 0) ? 1 : 0);
                if (quoRemIteration == 0 && n38 == 0) {
                    --b4;
                }
                else {
                    array2[n33++] = (char)(48 + quoRemIteration);
                }
                if (b4 <= -3 || b4 >= 8) {
                    n37 = (n38 = 0);
                }
                while (n37 == 0 && n38 == 0) {
                    final int quoRemIteration2 = multPow52.quoRemIteration(constructPow52);
                    fdBigInt = fdBigInt.mult(10);
                    n37 = ((multPow52.cmp(fdBigInt) < 0) ? 1 : 0);
                    n38 = ((multPow52.add(fdBigInt).cmp(mult) > 0) ? 1 : 0);
                    array2[n33++] = (char)(48 + quoRemIteration2);
                }
                if (n38 != 0 && n37 != 0) {
                    multPow52.lshiftMe(1);
                    n40 = multPow52.cmp(mult);
                }
                else {
                    n40 = 0L;
                }
            }
            n6 = b4 + 1;
            n7 = n33;
            if (n38 != 0) {
                if (n37 != 0) {
                    if (n40 == 0L) {
                        if ((array2[n7 - 1] & '\u0001') != 0x0 && this.roundup(array2, n7)) {
                            ++n6;
                        }
                    }
                    else if (n40 > 0L && this.roundup(array2, n7)) {
                        ++n6;
                    }
                }
                else if (this.roundup(array2, n7)) {
                    ++n6;
                }
            }
        }
        while (n7 - n6 > 0 && array2[n7 - 1] == '0') {
            --n7;
        }
        final boolean b6 = n6 % 2 != 0;
        int n49;
        if (b6) {
            if (n7 % 2 == 0) {
                array2[n7++] = '0';
            }
            n49 = (n6 - 1) / 2;
        }
        else {
            if (n7 % 2 == 1) {
                array2[n7++] = '0';
            }
            n49 = (n6 - 2) / 2;
        }
        int l = 0;
        int n50 = 1;
        if (b) {
            array[n] = (byte)(62 - n49);
            if (b6) {
                array[n + n50] = (byte)(101 - (array2[l++] - '0'));
                ++n50;
            }
            while (l < n7) {
                array[n + n50] = (byte)(101 - ((array2[l] - '0') * 10 + (array2[l + 1] - '0')));
                l += 2;
                ++n50;
            }
            array[n + n50++] = 102;
        }
        else {
            array[n] = (byte)(192 + (n49 + 1));
            if (b6) {
                array[n + n50] = (byte)(array2[l++] - '0' + 1);
                ++n50;
            }
            while (l < n7) {
                array[n + n50] = (byte)((array2[l] - '0') * 10 + (array2[l + 1] - '0') + 1);
                l += 2;
                ++n50;
            }
        }
        return n50;
    }
    
    static {
        factorTable = new double[] { 1.0E254, 1.0E252, 1.0E250, 1.0E248, 1.0E246, 1.0E244, 1.0E242, 1.0E240, 1.0E238, 1.0E236, 1.0E234, 1.0E232, 1.0E230, 1.0E228, 1.0E226, 1.0E224, 1.0E222, 1.0E220, 1.0E218, 1.0E216, 1.0E214, 1.0E212, 1.0E210, 1.0E208, 1.0E206, 1.0E204, 1.0E202, 1.0E200, 1.0E198, 1.0E196, 1.0E194, 1.0E192, 1.0E190, 1.0E188, 1.0E186, 1.0E184, 1.0E182, 1.0E180, 1.0E178, 1.0E176, 1.0E174, 1.0E172, 1.0E170, 1.0E168, 1.0E166, 1.0E164, 1.0E162, 1.0E160, 1.0E158, 1.0E156, 1.0E154, 1.0E152, 1.0E150, 1.0E148, 1.0E146, 1.0E144, 1.0E142, 1.0E140, 1.0E138, 1.0E136, 1.0E134, 1.0E132, 1.0E130, 1.0E128, 1.0E126, 1.0E124, 1.0E122, 1.0E120, 1.0E118, 1.0E116, 1.0E114, 1.0E112, 1.0E110, 1.0E108, 1.0E106, 1.0E104, 1.0E102, 1.0E100, 1.0E98, 1.0E96, 1.0E94, 1.0E92, 1.0E90, 1.0E88, 1.0E86, 1.0E84, 1.0E82, 1.0E80, 1.0E78, 1.0E76, 1.0E74, 1.0E72, 1.0E70, 1.0E68, 1.0E66, 1.0E64, 1.0E62, 1.0E60, 1.0E58, 1.0E56, 1.0E54, 1.0E52, 1.0E50, 1.0E48, 1.0E46, 1.0E44, 1.0E42, 1.0E40, 1.0E38, 1.0E36, 1.0E34, 1.0E32, 1.0E30, 1.0E28, 1.0E26, 1.0E24, 1.0E22, 1.0E20, 1.0E18, 1.0E16, 1.0E14, 1.0E12, 1.0E10, 1.0E8, 1000000.0, 10000.0, 100.0, 1.0, 0.01, 1.0E-4, 1.0E-6, 1.0E-8, 1.0E-10, 1.0E-12, 1.0E-14, 1.0E-16, 1.0E-18, 1.0E-20, 1.0E-22, 1.0E-24, 1.0E-26, 1.0E-28, 1.0E-30, 1.0E-32, 1.0E-34, 1.0E-36, 1.0E-38, 1.0E-40, 1.0E-42, 1.0E-44, 1.0E-46, 1.0E-48, 1.0E-50, 1.0E-52, 1.0E-54, 1.0E-56, 1.0E-58, 1.0E-60, 1.0E-62, 1.0E-64, 1.0E-66, 1.0E-68, 1.0E-70, 1.0E-72, 1.0E-74, 1.0E-76, 1.0E-78, 1.0E-80, 1.0E-82, 1.0E-84, 1.0E-86, 1.0E-88, 1.0E-90, 1.0E-92, 1.0E-94, 1.0E-96, 1.0E-98, 1.0E-100, 1.0E-102, 1.0E-104, 1.0E-106, 1.0E-108, 1.0E-110, 1.0E-112, 1.0E-114, 1.0E-116, 1.0E-118, 1.0E-120, 1.0E-122, 1.0E-124, 1.0E-126, 1.0E-128, 1.0E-130, 1.0E-132, 1.0E-134, 1.0E-136, 1.0E-138, 1.0E-140, 1.0E-142, 1.0E-144, 1.0E-146, 1.0E-148, 1.0E-150, 1.0E-152, 1.0E-154, 1.0E-156, 1.0E-158, 1.0E-160, 1.0E-162, 1.0E-164, 1.0E-166, 1.0E-168, 1.0E-170, 1.0E-172, 1.0E-174, 1.0E-176, 1.0E-178, 1.0E-180, 1.0E-182, 1.0E-184, 1.0E-186, 1.0E-188, 1.0E-190, 1.0E-192, 1.0E-194, 1.0E-196, 1.0E-198, 1.0E-200, 1.0E-202, 1.0E-204, 1.0E-206, 1.0E-208, 1.0E-210, 1.0E-212, 1.0E-214, 1.0E-216, 1.0E-218, 1.0E-220, 1.0E-222, 1.0E-224, 1.0E-226, 1.0E-228, 1.0E-230, 1.0E-232, 1.0E-234, 1.0E-236, 1.0E-238, 1.0E-240, 1.0E-242, 1.0E-244, 1.0E-246, 1.0E-248, 1.0E-250, 1.0E-252, 1.0E-254 };
        small5pow = new int[] { 1, 5, 25, 125, 625, 3125, 15625, 78125, 390625, 1953125, 9765625, 48828125, 244140625, 1220703125 };
        long5pow = new long[] { 1L, 5L, 25L, 125L, 625L, 3125L, 15625L, 78125L, 390625L, 1953125L, 9765625L, 48828125L, 244140625L, 1220703125L, 6103515625L, 30517578125L, 152587890625L, 762939453125L, 3814697265625L, 19073486328125L, 95367431640625L, 476837158203125L, 2384185791015625L, 11920928955078125L, 59604644775390625L, 298023223876953125L, 1490116119384765625L };
        n5bits = new int[] { 0, 3, 5, 7, 10, 12, 14, 17, 19, 21, 24, 26, 28, 31, 33, 35, 38, 40, 42, 45, 47, 49, 52, 54, 56, 59, 61 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
