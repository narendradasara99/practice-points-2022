// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.util.Collection;
import java.util.Properties;
import oracle.jdbc.internal.KeywordValue;
import java.sql.SQLException;
import oracle.jdbc.oracore.OracleTypeADT;
import java.io.InputStream;
import java.io.IOException;
import java.util.Vector;

final class T4C8Oall extends T4CTTIfun
{
    Vector<IOException> nonFatalIOExceptions;
    static final byte[] EMPTY_BYTES;
    static final int UOPF_PRS = 1;
    static final int UOPF_BND = 8;
    static final int UOPF_EXE = 32;
    static final int UOPF_FEX = 512;
    static final int UOPF_FCH = 64;
    static final int UOPF_CAN = 128;
    static final int UOPF_COM = 256;
    static final int UOPF_DSY = 8192;
    static final int UOPF_SIO = 1024;
    static final int UOPF_NPL = 32768;
    static final int UOPF_DFN = 16;
    static final int EXE_COMMIT_ON_SUCCESS = 1;
    static final int EXE_LEAVE_CUR_MAPPED = 2;
    static final int EXE_BATCH_DML_ERRORS = 4;
    static final int EXE_SCROL_READ_ONLY = 8;
    static final int AL8KW_MAXLANG = 63;
    static final int AL8KW_TIMEZONE = 163;
    static final int AL8KW_ERR_OVLAP = 164;
    static final int AL8KW_SESSION_ID = 165;
    static final int AL8KW_SERIAL_NUM = 166;
    static final int AL8KW_TAG_FOUND = 167;
    static final int AL8KW_SCHEMA_NAME = 168;
    static final int AL8KW_SCHEMA_ID = 169;
    static final int AL8KW_ENABLED_ROLES = 170;
    static final int AL8KW_AUX_SESSSTATE = 171;
    static final String[] NLS_KEYS;
    static final int LDIREGIDFLAG = 120;
    static final int LDIREGIDSET = 181;
    static final int LDIMAXTIMEFIELD = 60;
    int rowsProcessed;
    int numberOfDefinePositions;
    long options;
    int cursor;
    byte[] sqlStmt;
    final long[] al8i4;
    boolean plsql;
    Accessor[] definesAccessors;
    int definesLength;
    Accessor[] outBindAccessors;
    int numberOfBindPositions;
    InputStream[][] parameterStream;
    byte[][][] parameterDatum;
    OracleTypeADT[][] parameterOtype;
    short[] bindIndicators;
    byte[] bindBytes;
    char[] bindChars;
    int bindIndicatorSubRange;
    byte[] tmpBindsByteArray;
    DBConversion conversion;
    byte[] ibtBindBytes;
    char[] ibtBindChars;
    short[] ibtBindIndicators;
    boolean sendBindsDefinition;
    OracleStatement oracleStatement;
    short dbCharSet;
    short NCharSet;
    T4CTTIrxd rxd;
    T4C8TTIrxh rxh;
    T4CTTIdcb dcb;
    byte typeOfStatement;
    int defCols;
    int rowsToFetch;
    boolean aFetchWasDone;
    T4CTTIoac[] oacdefBindsSent;
    T4CTTIoac[] oacdefDefines;
    int[] definedColumnSize;
    int[] definedColumnType;
    int[] definedColumnFormOfUse;
    NTFDCNRegistration registration;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8Oall(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.nonFatalIOExceptions = null;
        this.sqlStmt = new byte[0];
        this.al8i4 = new long[13];
        this.plsql = false;
        this.sendBindsDefinition = false;
        this.defCols = 0;
        this.aFetchWasDone = false;
        this.registration = null;
        this.setFunCode((short)94);
        this.rxh = new T4C8TTIrxh(t4CConnection);
        this.rxd = new T4CTTIrxd(t4CConnection);
        this.dcb = new T4CTTIdcb(t4CConnection);
    }
    
    void doOALL(final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final byte typeOfStatement, final int cursor, final byte[] array, final int rowsToFetch, final Accessor[] outBindAccessors, final int numberOfBindPositions, final Accessor[] definesAccessors, final int definesLength, final byte[] bindBytes, final char[] bindChars, final short[] bindIndicators, final int bindIndicatorSubRange, final DBConversion conversion, final byte[] tmpBindsByteArray, final InputStream[][] parameterStream, final byte[][][] parameterDatum, final OracleTypeADT[][] parameterOtype, final OracleStatement oracleStatement, final byte[] ibtBindBytes, final char[] ibtBindChars, final short[] ibtBindIndicators, final T4CTTIoac[] oacdefBindsSent, final int[] definedColumnType, final int[] definedColumnSize, final int[] definedColumnFormOfUse, final NTFDCNRegistration registration) throws SQLException, IOException {
        this.typeOfStatement = typeOfStatement;
        this.cursor = cursor;
        this.sqlStmt = (b ? array : T4C8Oall.EMPTY_BYTES);
        this.rowsToFetch = rowsToFetch;
        this.outBindAccessors = outBindAccessors;
        this.numberOfBindPositions = numberOfBindPositions;
        this.definesAccessors = definesAccessors;
        this.definesLength = definesLength;
        this.bindBytes = bindBytes;
        this.bindChars = bindChars;
        this.bindIndicators = bindIndicators;
        this.bindIndicatorSubRange = bindIndicatorSubRange;
        this.conversion = conversion;
        this.tmpBindsByteArray = tmpBindsByteArray;
        this.parameterStream = parameterStream;
        this.parameterDatum = parameterDatum;
        this.parameterOtype = parameterOtype;
        this.oracleStatement = oracleStatement;
        this.ibtBindBytes = ibtBindBytes;
        this.ibtBindChars = ibtBindChars;
        this.ibtBindIndicators = ibtBindIndicators;
        this.oacdefBindsSent = oacdefBindsSent;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
        this.definedColumnFormOfUse = definedColumnFormOfUse;
        this.registration = registration;
        this.dbCharSet = conversion.getServerCharSetId();
        this.NCharSet = conversion.getNCharSetId();
        int n = 0;
        if (this.bindIndicators != null) {
            n = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
        }
        if (array == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 431);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if ((this.typeOfStatement & 0x1E) == 0x0 && n > 1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 433);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.rowsProcessed = 0;
        this.options = 0L;
        this.plsql = ((this.typeOfStatement & 0x60) != 0x0);
        this.sendBindsDefinition = false;
        if (this.receiveState != 0) {
            this.receiveState = 0;
        }
        this.rxh.init();
        this.rxd.init();
        this.oer.init();
        if (b5) {
            this.initDefinesDefinition();
        }
        if (this.numberOfBindPositions > 0 && this.bindIndicators != null) {
            if (this.oacdefBindsSent == null) {
                this.oacdefBindsSent = new T4CTTIoac[this.numberOfBindPositions];
            }
            this.sendBindsDefinition = this.initBindsDefinition(this.oacdefBindsSent);
        }
        this.options = this.setOptions(b, b2, b3, b5);
        if ((this.options & 0x1L) > 0L) {
            this.al8i4[0] = 1L;
        }
        else {
            this.al8i4[0] = 0L;
        }
        if (this.plsql || this.typeOfStatement == -128) {
            this.al8i4[1] = 1L;
        }
        else if (b4) {
            if (b3 && this.oracleStatement.connection.useFetchSizeWithLongColumn) {
                this.al8i4[1] = this.rowsToFetch;
            }
            else {
                this.al8i4[1] = 0L;
            }
        }
        else if ((this.typeOfStatement & 0x1E) != 0x0) {
            this.al8i4[1] = ((n == 0) ? this.oracleStatement.batch : ((long)n));
        }
        else if (b3 && !b4) {
            this.al8i4[1] = this.rowsToFetch;
        }
        else {
            this.al8i4[1] = 0L;
        }
        if (this.typeOfStatement == 1) {
            this.al8i4[7] = 1L;
        }
        else {
            this.al8i4[7] = 0L;
        }
        this.rowsProcessed = 0;
        this.aFetchWasDone = false;
        this.rxd.setNumberOfColumns(this.definesLength);
        if ((this.options & 0x40L) != 0x0L && (this.options & 0x20L) == 0x0L && (this.options & 0x1L) == 0x0L && (this.options & 0x8L) == 0x0L && (this.options & 0x10L) == 0x0L && !this.oracleStatement.needToSendOalToFetch) {
            this.setFunCode((short)5);
        }
        else {
            this.setFunCode((short)94);
        }
        this.nonFatalIOExceptions = null;
        this.doRPC();
        this.ibtBindIndicators = null;
        this.ibtBindChars = null;
        this.ibtBindBytes = null;
        this.tmpBindsByteArray = null;
        this.outBindAccessors = null;
        this.bindBytes = null;
        this.bindChars = null;
        this.bindIndicators = null;
        this.oracleStatement = null;
        if (this.nonFatalIOExceptions != null) {
            final IOException cause = this.nonFatalIOExceptions.get(0);
            try {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 266);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            catch (SQLException ex) {
                ex.initCause(cause);
                throw ex;
            }
        }
    }
    
    @Override
    void readBVC() throws IOException, SQLException {
        this.rxd.unmarshalBVC(this.meg.unmarshalUB2());
    }
    
    @Override
    void readIOV() throws IOException, SQLException {
        final T4CTTIiov t4CTTIiov = new T4CTTIiov(this.connection, this.rxh, this.rxd);
        t4CTTIiov.init();
        t4CTTIiov.unmarshalV10();
        if (this.oracleStatement.returnParamAccessors == null && !t4CTTIiov.isIOVectorEmpty()) {
            this.outBindAccessors = t4CTTIiov.processRXD(this.outBindAccessors, this.numberOfBindPositions, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.conversion, this.tmpBindsByteArray, t4CTTIiov.getIOVector(), this.parameterStream, this.parameterDatum, this.parameterOtype, this.oracleStatement, null, null, null);
        }
    }
    
    @Override
    void readRXH() throws IOException, SQLException {
        this.rxh.init();
        this.rxh.unmarshalV10(this.rxd);
        if (this.rxh.uacBufLength > 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 405);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if ((this.rxh.rxhflg & 0x8) == 0x8) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 449);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if ((this.rxh.rxhflg & 0x10) == 0x10) {
            for (short n = 0; n < this.definesAccessors.length; ++n) {
                if (this.definesAccessors[n].udskpos >= 0 && this.definesAccessors[n].udskpos != n) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 450);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
            }
        }
    }
    
    @Override
    boolean readRXD() throws IOException, SQLException {
        this.aFetchWasDone = true;
        if (this.oracleStatement.returnParamAccessors != null && this.numberOfBindPositions > 0) {
            int n = 0;
            for (int i = 0; i < this.oracleStatement.numberOfBindPositions; ++i) {
                final Accessor accessor = this.oracleStatement.returnParamAccessors[i];
                if (accessor != null) {
                    final int rowsDmlReturned = (int)this.meg.unmarshalUB4();
                    if (n == 0) {
                        this.oracleStatement.rowsDmlReturned = rowsDmlReturned;
                        this.oracleStatement.allocateDmlReturnStorage();
                        this.oracleStatement.setupReturnParamAccessors();
                        n = 1;
                    }
                    for (int j = 0; j < rowsDmlReturned; ++j) {
                        accessor.unmarshalOneRow();
                    }
                }
            }
            this.oracleStatement.returnParamsFetched = true;
        }
        else if (this.iovProcessed || (this.outBindAccessors != null && this.definesAccessors == null)) {
            if (this.rxd.unmarshal(this.outBindAccessors, this.numberOfBindPositions)) {
                return true;
            }
        }
        else if (this.rxd.unmarshal(this.definesAccessors, this.definesLength)) {
            return true;
        }
        return false;
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        final int unmarshalUB2 = this.meg.unmarshalUB2();
        final int[] array = new int[unmarshalUB2];
        for (int i = 0; i < unmarshalUB2; ++i) {
            array[i] = (int)this.meg.unmarshalUB4();
        }
        this.cursor = array[2];
        final int unmarshalUB3 = this.meg.unmarshalUB2();
        if (unmarshalUB3 > 0) {
            this.meg.unmarshalNBytes(unmarshalUB3);
        }
        final int unmarshalUB4 = this.meg.unmarshalUB2();
        final KeywordValue[] array2 = new KeywordValue[unmarshalUB4];
        for (int j = 0; j < unmarshalUB4; ++j) {
            array2[j] = KeywordValueI.unmarshal(this.meg);
        }
        this.connection.updateSessionProperties(array2);
        this.oracleStatement.dcnQueryId = -1L;
        this.oracleStatement.dcnTableName = null;
        if (this.connection.getTTCVersion() >= 4) {
            final int n = (int)this.meg.unmarshalUB4();
            final byte[] unmarshalNBytes = this.meg.unmarshalNBytes(n);
            if (n > 0 && this.registration != null) {
                boolean b = false;
                final Properties registrationOptions = this.registration.getRegistrationOptions();
                if (registrationOptions != null) {
                    final String property = registrationOptions.getProperty("DCN_QUERY_CHANGE_NOTIFICATION");
                    if (property != null && property.compareToIgnoreCase("true") == 0) {
                        b = true;
                    }
                }
                int length = n;
                if (b) {
                    length = n - 8;
                }
                final String[] split = new String(unmarshalNBytes, 0, length).split(new String(new char[] { '\0' }));
                this.registration.addTablesName(split, split.length);
                this.oracleStatement.dcnTableName = split;
                if (b) {
                    this.oracleStatement.dcnQueryId = (((long)(unmarshalNBytes[n - 5] | unmarshalNBytes[n - 6] << 8 | unmarshalNBytes[n - 7] << 16 | unmarshalNBytes[n - 8] << 24) & -1L) | (long)(unmarshalNBytes[n - 1] | unmarshalNBytes[n - 2] << 8 | unmarshalNBytes[n - 3] << 16 | unmarshalNBytes[n - 4] << 24) << 32);
                }
            }
        }
    }
    
    @Override
    void readDCB() throws IOException, SQLException {
        this.dcb.init(this.oracleStatement, 0);
        this.definesAccessors = this.dcb.receive(this.definesAccessors);
        this.numberOfDefinePositions = this.dcb.numuds;
        this.definesLength = this.numberOfDefinePositions;
        this.rxd.setNumberOfColumns(this.numberOfDefinePositions);
    }
    
    @Override
    void processError() throws SQLException {
        this.cursor = this.oer.currCursorID;
        this.rowsProcessed = this.oer.getCurRowNumber();
        if (this.typeOfStatement == 1 && this.oer.retCode == 1403) {
            this.aFetchWasDone = true;
        }
        if (this.typeOfStatement != 1 || (this.typeOfStatement == 1 && this.oer.retCode != 1403)) {
            this.oer.processError(this.oracleStatement);
        }
    }
    
    int getCursorId() {
        return this.cursor;
    }
    
    void continueReadRow(final int n, final OracleStatement oracleStatement) throws SQLException, IOException {
        try {
            this.oracleStatement = oracleStatement;
            this.receiveState = 2;
            if (this.rxd.unmarshal(this.definesAccessors, n, this.definesLength)) {
                this.receiveState = 3;
                return;
            }
            this.resumeReceive();
        }
        finally {
            this.oracleStatement = null;
        }
    }
    
    int getNumRows() {
        int rowsProcessed = 0;
        if (this.receiveState == 3) {
            rowsProcessed = -2;
        }
        else {
            switch (this.typeOfStatement) {
                case Byte.MIN_VALUE:
                case 2:
                case 4:
                case 8:
                case 16:
                case 32:
                case 64: {
                    rowsProcessed = this.rowsProcessed;
                    break;
                }
                case 1: {
                    rowsProcessed = ((this.definesAccessors != null && this.definesLength > 0) ? this.definesAccessors[0].lastRowProcessed : 0);
                    break;
                }
            }
        }
        return rowsProcessed;
    }
    
    @Override
    void marshal() throws IOException {
        if (this.getFunCode() == 5) {
            this.meg.marshalSWORD(this.cursor);
            this.meg.marshalSWORD((int)this.al8i4[1]);
        }
        else {
            if (this.oracleStatement.needToSendOalToFetch) {
                this.oracleStatement.needToSendOalToFetch = false;
            }
            this.marshalPisdef();
            this.meg.marshalCHR(this.sqlStmt);
            this.meg.marshalUB4Array(this.al8i4);
            final int[] array = new int[this.numberOfBindPositions];
            for (int i = 0; i < this.numberOfBindPositions; ++i) {
                array[i] = this.oacdefBindsSent[i].oacmxl;
            }
            if ((this.options & 0x8L) != 0x0L && this.numberOfBindPositions > 0 && this.bindIndicators != null && this.sendBindsDefinition) {
                this.marshalBindsTypes(this.oacdefBindsSent);
            }
            if (this.connection.getTTCVersion() >= 2 && (this.options & 0x10L) != 0x0L) {
                for (int j = 0; j < this.defCols; ++j) {
                    this.oacdefDefines[j].marshal();
                }
            }
            if ((this.options & 0x20L) != 0x0L && this.numberOfBindPositions > 0 && this.bindIndicators != null) {
                this.nonFatalIOExceptions = this.marshalBinds(array);
            }
        }
    }
    
    void marshalPisdef() throws IOException {
        this.meg.marshalUB4(this.options);
        this.meg.marshalSWORD(this.cursor);
        if (this.sqlStmt.length == 0) {
            this.meg.marshalNULLPTR();
        }
        else {
            this.meg.marshalPTR();
        }
        this.meg.marshalSWORD(this.sqlStmt.length);
        if (this.al8i4.length == 0) {
            this.meg.marshalNULLPTR();
        }
        else {
            this.meg.marshalPTR();
        }
        this.meg.marshalSWORD(this.al8i4.length);
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        if ((this.options & 0x40L) == 0x0L && (this.options & 0x20L) != 0x0L && (this.options & 0x1L) != 0x0L && this.typeOfStatement == 1) {
            this.meg.marshalUB4(Long.MAX_VALUE);
            this.meg.marshalUB4(this.rowsToFetch);
        }
        else {
            this.meg.marshalUB4(0L);
            this.meg.marshalUB4(0L);
        }
        if ((this.typeOfStatement & 0x60) == 0x0) {
            this.meg.marshalUB4(2147483647L);
        }
        else {
            this.meg.marshalUB4(32760L);
        }
        if ((this.options & 0x8L) != 0x0L && this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.numberOfBindPositions);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        if (this.connection.getTTCVersion() >= 2) {
            if (this.defCols > 0 && (this.options & 0x10L) != 0x0L) {
                this.meg.marshalPTR();
                this.meg.marshalSWORD(this.defCols);
            }
            else {
                this.meg.marshalNULLPTR();
                this.meg.marshalSWORD(0);
            }
        }
        if (this.connection.getTTCVersion() >= 4) {
            int n = 0;
            int n2 = 0;
            if (this.registration != null) {
                final long regId = this.registration.getRegId();
                n = (int)(regId & -1L);
                n2 = (int)((regId & 0xFFFFFFFF00000000L) >> 32);
            }
            this.meg.marshalUB4(n);
            this.meg.marshalNULLPTR();
            this.meg.marshalPTR();
            if (this.connection.getTTCVersion() >= 5) {
                this.meg.marshalNULLPTR();
                this.meg.marshalUB4(0L);
                this.meg.marshalNULLPTR();
                this.meg.marshalUB4(0L);
                this.meg.marshalUB4(n2);
            }
        }
    }
    
    boolean initBindsDefinition(T4CTTIoac[] array) throws SQLException, IOException {
        boolean b = false;
        if (array.length != this.numberOfBindPositions) {
            b = true;
            array = new T4CTTIoac[this.numberOfBindPositions];
        }
        final short[] bindIndicators = this.bindIndicators;
        int n = 0;
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            final T4CTTIoac t4CTTIoac = new T4CTTIoac(this.connection);
            final int n2 = this.bindIndicatorSubRange + 5 + 10 * i;
            final short formOfUse = bindIndicators[n2 + 9];
            final int n3 = bindIndicators[n2 + 0] & 0xFFFF;
            switch (n3) {
                case 8:
                case 24: {
                    int n4;
                    if (this.plsql) {
                        n4 = 32760;
                    }
                    else {
                        n4 = Integer.MAX_VALUE;
                    }
                    t4CTTIoac.init((short)n3, n4);
                    t4CTTIoac.setFormOfUse(formOfUse);
                    t4CTTIoac.setCharset((formOfUse == 2) ? this.NCharSet : this.dbCharSet);
                    break;
                }
                case 998: {
                    if (this.outBindAccessors != null && this.outBindAccessors[i] != null) {
                        final PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[i];
                        t4CTTIoac.init((short)plsqlIndexTableAccessor.elementInternalType, plsqlIndexTableAccessor.elementMaxLen);
                        t4CTTIoac.setMal(plsqlIndexTableAccessor.maxNumberOfElements);
                        t4CTTIoac.addFlg((short)64);
                        ++n;
                        break;
                    }
                    if (this.ibtBindIndicators[6 + n * 8] != 0) {
                        final short n5 = this.ibtBindIndicators[6 + n * 8];
                        final int mal = (this.ibtBindIndicators[6 + n * 8 + 2] << 16 & 0xFFFF000) | this.ibtBindIndicators[6 + n * 8 + 3];
                        t4CTTIoac.init(n5, this.ibtBindIndicators[6 + n * 8 + 1] * this.conversion.sMaxCharSize);
                        t4CTTIoac.setMal(mal);
                        t4CTTIoac.addFlg((short)64);
                        ++n;
                        break;
                    }
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding PLSQL index-by table but no type defined", -1);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                case 109:
                case 111: {
                    if (this.outBindAccessors != null && this.outBindAccessors[i] != null) {
                        if (this.outBindAccessors[i].internalOtype != null) {
                            t4CTTIoac.init((short)n3, (n3 == 109) ? 11 : 4000);
                            t4CTTIoac.setADT((OracleTypeADT)((TypeAccessor)this.outBindAccessors[i]).internalOtype);
                            break;
                        }
                        break;
                    }
                    else {
                        if (this.parameterOtype != null && this.parameterOtype[this.oracleStatement.firstRowInBatch] != null) {
                            t4CTTIoac.init((short)n3, (n3 == 109) ? 11 : 4000);
                            t4CTTIoac.setADT(this.parameterOtype[this.oracleStatement.firstRowInBatch][i]);
                            break;
                        }
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding NAMED_TYPE but no type defined", -1);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                    break;
                }
                case 994: {
                    final int[] returnParamMeta = this.oracleStatement.returnParamMeta;
                    final int n6 = returnParamMeta[3 + i * 3 + 0];
                    final int n7 = returnParamMeta[3 + i * 3 + 2];
                    if (n6 == 109 || n6 == 111) {
                        final TypeAccessor typeAccessor = (TypeAccessor)this.oracleStatement.returnParamAccessors[i];
                        t4CTTIoac.init((short)n6, (n6 == 109) ? 11 : 4000);
                        t4CTTIoac.setADT((OracleTypeADT)typeAccessor.internalOtype);
                    }
                    else {
                        t4CTTIoac.init((short)n6, n7);
                        t4CTTIoac.setFormOfUse(formOfUse);
                        t4CTTIoac.setCharset((formOfUse == 2) ? this.NCharSet : this.dbCharSet);
                    }
                    break;
                }
                case 180: {
                    t4CTTIoac.init((short)n3, bindIndicators[n2 + 1] & 0xFFFF);
                    t4CTTIoac.addFlg2(134217728);
                    t4CTTIoac.setTimestampFractionalSecondsPrecision((short)9);
                    if (((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF) == 1 && bindIndicators[((bindIndicators[n2 + 7] & 0xFFFF) << 16) + (bindIndicators[n2 + 8] & 0xFFFF)] == 7) {
                        t4CTTIoac.setTimestampFractionalSecondsPrecision((short)0);
                    }
                    break;
                }
                default: {
                    int min = bindIndicators[n2 + 1] & 0xFFFF;
                    if (min == 0) {
                        min = (bindIndicators[n2 + 2] & 0xFFFF);
                        if (n3 == 996) {
                            min *= 2;
                        }
                        else if (min > 1) {
                            --min;
                        }
                        if (formOfUse == 2) {
                            min *= this.conversion.maxNCharSize;
                        }
                        if (this.typeOfStatement == 32 || (this.connection.versionNumber >= 10200 && this.typeOfStatement == 64)) {
                            if (min == 0) {
                                min = 32766;
                            }
                            else {
                                min *= this.conversion.sMaxCharSize;
                            }
                        }
                        else if (this.typeOfStatement == 64) {
                            if (min < 4001) {
                                min = 4001;
                            }
                        }
                        else if (formOfUse != 2) {
                            if (((T4CConnection)this.oracleStatement.connection).retainV9BindBehavior && min <= 4000) {
                                min = Math.min(min * this.conversion.sMaxCharSize, 4000);
                            }
                            else {
                                min *= this.conversion.sMaxCharSize;
                            }
                        }
                        if (min == 0) {
                            min = 32;
                        }
                    }
                    t4CTTIoac.init((short)n3, min);
                    t4CTTIoac.setFormOfUse(formOfUse);
                    t4CTTIoac.setCharset((formOfUse == 2) ? this.NCharSet : this.dbCharSet);
                    break;
                }
            }
            if (array[i] == null || !t4CTTIoac.isOldSufficient(array[i])) {
                array[i] = t4CTTIoac;
                b = true;
            }
        }
        if (b) {
            this.oracleStatement.nbPostPonedColumns[0] = 0;
        }
        return b;
    }
    
    void initDefinesDefinition() throws SQLException, IOException {
        this.defCols = 0;
        for (int n = 0; n < this.definedColumnType.length && this.definedColumnType[n] != 0; ++n) {
            ++this.defCols;
        }
        this.oacdefDefines = new T4CTTIoac[this.defCols];
        for (int i = 0; i < this.oacdefDefines.length; ++i) {
            this.oacdefDefines[i] = new T4CTTIoac(this.connection);
            short n2 = (short)this.oracleStatement.getInternalType(this.definedColumnType[i]);
            int n3 = Integer.MAX_VALUE;
            int n4 = 0;
            int mxlc = 0;
            short formOfUse = 1;
            if (this.definedColumnFormOfUse != null && this.definedColumnFormOfUse.length > i && this.definedColumnFormOfUse[i] == 2) {
                formOfUse = 2;
            }
            if (n2 == 8) {
                n2 = 1;
            }
            else if (n2 == 24) {
                n2 = 23;
            }
            else if (n2 == 1 || n2 == 96) {
                n2 = 1;
                n3 = 4000 * this.conversion.sMaxCharSize;
                if (this.definedColumnSize != null && this.definedColumnSize.length > i && this.definedColumnSize[i] > 0) {
                    n3 = this.definedColumnSize[i] * this.conversion.sMaxCharSize;
                }
            }
            else if (n2 == 113 || n2 == 112 || n2 == 114) {
                n3 = 0;
                n4 = 33554432;
                if (this.definedColumnSize != null && this.definedColumnSize.length > i && this.definedColumnSize[i] > 0) {
                    mxlc = this.definedColumnSize[i];
                }
            }
            else if (n2 == 23) {
                n3 = 4000;
            }
            this.oacdefDefines[i].init(n2, n3);
            this.oacdefDefines[i].addFlg2(n4);
            this.oacdefDefines[i].setMxlc(mxlc);
            this.oacdefDefines[i].setFormOfUse(formOfUse);
            this.oacdefDefines[i].setCharset((formOfUse == 2) ? this.NCharSet : this.dbCharSet);
        }
    }
    
    void marshalBindsTypes(final T4CTTIoac[] array) throws IOException {
        if (array == null) {
            return;
        }
        for (int i = 0; i < array.length; ++i) {
            array[i].marshal();
        }
    }
    
    Vector<IOException> marshalBinds(final int[] array) throws IOException {
        Vector<IOException> vector = null;
        for (int n = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF), i = 0; i < n; ++i) {
            final int n2 = this.oracleStatement.firstRowInBatch + i;
            InputStream[] array2 = null;
            if (this.parameterStream != null) {
                array2 = this.parameterStream[n2];
            }
            byte[][] array3 = null;
            if (this.parameterDatum != null) {
                array3 = this.parameterDatum[n2];
            }
            OracleTypeADT[] array4 = null;
            if (this.parameterOtype != null) {
                array4 = this.parameterOtype[n2];
            }
            final Vector<IOException> marshal = this.rxd.marshal(this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.tmpBindsByteArray, this.conversion, array2, array3, array4, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, null, i, array, this.plsql, this.oracleStatement.returnParamMeta, this.oracleStatement.nbPostPonedColumns, this.oracleStatement.indexOfPostPonedColumn);
            if (marshal != null) {
                if (vector == null) {
                    vector = new Vector<IOException>();
                }
                vector.addAll(marshal);
            }
        }
        return vector;
    }
    
    long setOptions(final boolean b, final boolean b2, final boolean b3, final boolean b4) throws SQLException {
        long n = 0L;
        long n2;
        if (b && !b2 && !b3) {
            n2 = (n | 0x1L);
        }
        else if (b && b2 && !b3) {
            n2 = 32801L;
        }
        else if (b2 && b3) {
            if (b) {
                n |= 0x1L;
            }
            switch (this.typeOfStatement) {
                case 1: {
                    n2 = (n | 0x8060L);
                    break;
                }
                case 32:
                case 64: {
                    if (this.numberOfBindPositions <= 0) {
                        n2 = (n | (0x20L | (long)(this.oracleStatement.connection.autocommit ? 256 : 0)));
                        break;
                    }
                    n2 = (n | (0x420L | (long)(this.oracleStatement.connection.autocommit ? 256 : 0)));
                    if (this.sendBindsDefinition) {
                        n2 |= 0x8L;
                        break;
                    }
                    break;
                }
                case Byte.MIN_VALUE:
                case 2:
                case 4:
                case 8:
                case 16: {
                    if (this.oracleStatement.returnParamAccessors != null) {
                        n2 = (n | (0x420L | (long)(this.oracleStatement.connection.autocommit ? 256 : 0)));
                        break;
                    }
                    n2 = (n | (0x8020L | (long)(this.oracleStatement.connection.autocommit ? 256 : 0)));
                    break;
                }
                default: {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 432);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
        }
        else {
            if (b || b2 || !b3) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 432);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            n2 = 32832L;
        }
        if ((this.typeOfStatement & 0x60) == 0x0) {
            if (b || b2 || !b3) {
                if (this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
                    n2 |= 0x8L;
                }
            }
            if (this.connection.versionNumber >= 9000 && b4) {
                n2 |= 0x10L;
            }
        }
        return n2 & -1L;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        EMPTY_BYTES = new byte[0];
        NLS_KEYS = new String[] { "AUTH_NLS_LXCCURRENCY", "AUTH_NLS_LXCISOCURR", "AUTH_NLS_LXCNUMERICS", null, null, null, null, "AUTH_NLS_LXCDATEFM", "AUTH_NLS_LXCDATELANG", "AUTH_NLS_LXCTERRITORY", "SESSION_NLS_LXCCHARSET", "AUTH_NLS_LXCSORT", "AUTH_NLS_LXCCALENDAR", null, null, null, "AUTH_NLS_LXLAN", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "AUTH_NLS_LXCSORT", null, "AUTH_NLS_LXCUNIONCUR", null, null, null, null, "AUTH_NLS_LXCTIMEFM", "AUTH_NLS_LXCSTMPFM", "AUTH_NLS_LXCTTZNFM", "AUTH_NLS_LXCSTZNFM", "SESSION_NLS_LXCNLSLENSEM", "SESSION_NLS_LXCNCHAREXCP", "SESSION_NLS_LXCNCHARIMP" };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
