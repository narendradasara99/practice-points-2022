// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.BLOB;
import java.io.OutputStream;

class OracleBlobOutputStream extends OutputStream
{
    long lobOffset;
    BLOB blob;
    byte[] buf;
    int count;
    int bufSize;
    boolean isClosed;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleBlobOutputStream(final BLOB blob, final int n) throws SQLException {
        this(blob, n, 1L);
    }
    
    public OracleBlobOutputStream(final BLOB blob, final int bufSize, final long lobOffset) throws SQLException {
        if (blob == null || bufSize <= 0 || lobOffset < 1L) {
            throw new IllegalArgumentException("Illegal Arguments");
        }
        this.blob = blob;
        this.lobOffset = lobOffset;
        final PhysicalConnection physicalConnection = (PhysicalConnection)blob.getInternalConnection();
        synchronized (physicalConnection) {
            this.buf = physicalConnection.getByteBuffer(bufSize);
        }
        this.count = 0;
        this.bufSize = bufSize;
        this.isClosed = false;
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.ensureOpen();
        if (this.count >= this.bufSize) {
            this.flushBuffer();
        }
        this.buf[this.count++] = (byte)n;
    }
    
    @Override
    public void write(final byte[] array, final int n, final int a) throws IOException {
        this.ensureOpen();
        int i = n;
        final int min = Math.min(a, array.length - n);
        if (min >= 2 * this.bufSize) {
            if (this.count > 0) {
                this.flushBuffer();
            }
            try {
                this.lobOffset += this.blob.setBytes(this.lobOffset, array, n, min);
                return;
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
        final int n2 = i + min;
        while (i < n2) {
            final int min2 = Math.min(this.bufSize - this.count, n2 - i);
            System.arraycopy(array, i, this.buf, this.count, min2);
            i += min2;
            this.count += min2;
            if (this.count >= this.bufSize) {
                this.flushBuffer();
            }
        }
    }
    
    @Override
    public void flush() throws IOException {
        this.ensureOpen();
        this.flushBuffer();
    }
    
    @Override
    public void close() throws IOException {
        if (this.isClosed) {
            return;
        }
        try {
            this.isClosed = true;
            this.flushBuffer();
        }
        finally {
            try {
                final PhysicalConnection physicalConnection = (PhysicalConnection)this.blob.getInternalConnection();
                synchronized (physicalConnection) {
                    if (this.buf != null) {
                        physicalConnection.cacheBuffer(this.buf);
                        this.buf = null;
                    }
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
    }
    
    private void flushBuffer() throws IOException {
        try {
            if (this.count > 0) {
                this.lobOffset += this.blob.setBytes(this.lobOffset, this.buf, 0, this.count);
                this.count = 0;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    void ensureOpen() throws IOException {
        try {
            if (this.isClosed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 57, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        try {
            return this.blob.getInternalConnection();
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
