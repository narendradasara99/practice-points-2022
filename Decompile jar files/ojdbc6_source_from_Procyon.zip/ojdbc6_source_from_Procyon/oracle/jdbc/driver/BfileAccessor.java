// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.Reader;
import java.io.InputStream;
import oracle.jdbc.OracleConnection;
import oracle.sql.BFILE;
import oracle.sql.Datum;
import java.util.Map;
import java.sql.SQLException;

class BfileAccessor extends Accessor
{
    static final int maxLength = 530;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    BfileAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 114, 114, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    BfileAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 114, 114, n7, false);
        this.initForDescribe(114, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 530;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getBFILE(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getBFILE(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getBFILE(n);
    }
    
    @Override
    BFILE getBFILE(final int n) throws SQLException {
        BFILE bfile = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
            final byte[] array = new byte[n3];
            System.arraycopy(this.rowSpaceByte, n2, array, 0, n3);
            bfile = new BFILE(this.statement.connection, array);
            if (this.lobPrefetchSizeForThisColumn != -1) {
                bfile.setLength(this.prefetchedLobSize[n]);
            }
        }
        return bfile;
    }
    
    @Override
    InputStream getAsciiStream(final int n) throws SQLException {
        final BFILE bfile = this.getBFILE(n);
        if (bfile == null) {
            return null;
        }
        return bfile.asciiStreamValue();
    }
    
    @Override
    Reader getCharacterStream(final int n) throws SQLException {
        final BFILE bfile = this.getBFILE(n);
        if (bfile == null) {
            return null;
        }
        return bfile.characterStreamValue();
    }
    
    @Override
    InputStream getBinaryStream(final int n) throws SQLException {
        final BFILE bfile = this.getBFILE(n);
        if (bfile == null) {
            return null;
        }
        return bfile.getBinaryStream();
    }
    
    @Override
    byte[] privateGetBytes(final int n) throws SQLException {
        return super.getBytes(n);
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        final BFILE bfile = this.getBFILE(n);
        if (bfile == null) {
            return null;
        }
        final InputStream binaryStream = bfile.getBinaryStream();
        final int size = 4096;
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(size);
        final byte[] array = new byte[size];
        try {
            int read;
            while ((read = binaryStream.read(array)) != -1) {
                byteArrayOutputStream.write(array, 0, read);
            }
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (IndexOutOfBoundsException ex2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 151);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return byteArrayOutputStream.toByteArray();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
