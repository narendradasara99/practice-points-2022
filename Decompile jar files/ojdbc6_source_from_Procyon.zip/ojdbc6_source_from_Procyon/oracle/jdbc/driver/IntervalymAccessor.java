// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Map;
import oracle.sql.Datum;
import oracle.sql.INTERVALYM;
import java.sql.SQLException;

class IntervalymAccessor extends Accessor
{
    static final int maxLength = 5;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    IntervalymAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 182, 182, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    IntervalymAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 182, 182, n7, false);
        this.initForDescribe(182, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 5;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String string = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
            final byte[] array = new byte[n3];
            System.arraycopy(this.rowSpaceByte, n2, array, 0, n3);
            string = new INTERVALYM(array).toString();
        }
        return string;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getINTERVALYM(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getINTERVALYM(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getINTERVALYM(n);
    }
    
    @Override
    INTERVALYM getINTERVALYM(final int n) throws SQLException {
        INTERVALYM intervalym = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n;
            final short n3 = this.rowSpaceIndicator[this.lengthIndex + n];
            final byte[] array = new byte[n3];
            System.arraycopy(this.rowSpaceByte, n2, array, 0, n3);
            intervalym = new INTERVALYM(array);
        }
        return intervalym;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
