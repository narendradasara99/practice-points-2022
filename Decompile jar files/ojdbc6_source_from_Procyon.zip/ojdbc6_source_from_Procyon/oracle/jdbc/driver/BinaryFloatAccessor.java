// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.math.BigInteger;
import oracle.sql.NUMBER;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.Datum;
import java.util.Map;
import java.sql.SQLException;

class BinaryFloatAccessor extends Accessor
{
    static final int MAXLENGTH = 4;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    BinaryFloatAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 100, 100, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    BinaryFloatAccessor(final OracleStatement oracleStatement, int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 100, 100, n7, false);
        this.initForDescribe(100, n, b, n2, n3, n4, n5, n6, n7, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n == 0 || maxFieldSize < n)) {
            n = maxFieldSize;
        }
        this.initForDataAccess(0, n, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, final int n3, final short n4, final int n5) throws SQLException {
        this.init(oracleStatement, n, n2, n4, false);
        this.initForDataAccess(n5, n3, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, int n3, final boolean b, final int n4, final int n5, final int n6, final int n7, final int n8, final short n9) throws SQLException {
        this.init(oracleStatement, n, n2, n9, false);
        this.initForDescribe(n, n3, b, n4, n5, n6, n7, n8, n9, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n3 == 0 || maxFieldSize < n3)) {
            n3 = maxFieldSize;
        }
        this.initForDataAccess(0, n3, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 4;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    float getFloat(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0.0f;
        }
        final int n2 = this.columnIndex + this.byteLength * n;
        final byte b = this.rowSpaceByte[n2];
        final byte b2 = this.rowSpaceByte[n2 + 1];
        final byte b3 = this.rowSpaceByte[n2 + 2];
        final byte b4 = this.rowSpaceByte[n2 + 3];
        int n3;
        int n4;
        int n5;
        int n6;
        if ((b & 0x80) != 0x0) {
            n3 = (b & 0x7F);
            n4 = (b2 & 0xFF);
            n5 = (b3 & 0xFF);
            n6 = (b4 & 0xFF);
        }
        else {
            n3 = (~b & 0xFF);
            n4 = (~b2 & 0xFF);
            n5 = (~b3 & 0xFF);
            n6 = (~b4 & 0xFF);
        }
        return Float.intBitsToFloat(n3 << 24 | n4 << 16 | n5 << 8 | n6);
    }
    
    @Override
    String getString(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return Float.toString(this.getFloat(n));
        }
        return null;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new Float(this.getFloat(n));
        }
        return null;
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new Float(this.getFloat(n));
        }
        return null;
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getBINARY_FLOAT(n);
    }
    
    BINARY_FLOAT getBINARY_FLOAT(final int n) throws SQLException {
        BINARY_FLOAT binary_FLOAT = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            final byte[] array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
            binary_FLOAT = new BINARY_FLOAT(array);
        }
        return binary_FLOAT;
    }
    
    @Override
    NUMBER getNUMBER(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new NUMBER(this.getFloat(n));
        }
        return null;
    }
    
    BigInteger getBigInteger(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new BigInteger(this.getString(n));
        }
        return null;
    }
    
    @Override
    BigDecimal getBigDecimal(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            return new BigDecimal(this.getString(n));
        }
        return null;
    }
    
    @Override
    byte getByte(final int n) throws SQLException {
        return (byte)this.getFloat(n);
    }
    
    @Override
    short getShort(final int n) throws SQLException {
        return (short)this.getFloat(n);
    }
    
    @Override
    int getInt(final int n) throws SQLException {
        return (int)this.getFloat(n);
    }
    
    @Override
    long getLong(final int n) throws SQLException {
        return (long)this.getFloat(n);
    }
    
    @Override
    double getDouble(final int n) throws SQLException {
        return this.getFloat(n);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
