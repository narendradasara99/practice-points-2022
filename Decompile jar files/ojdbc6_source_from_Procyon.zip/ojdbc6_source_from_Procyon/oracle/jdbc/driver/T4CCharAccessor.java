// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.Time;
import oracle.sql.Datum;
import oracle.sql.RAW;
import oracle.sql.TIMESTAMPLTZ;
import java.util.Calendar;
import java.sql.Connection;
import oracle.sql.TIMESTAMPTZ;
import java.sql.Timestamp;
import oracle.sql.TIMESTAMP;
import java.sql.Date;
import oracle.sql.DATE;
import oracle.sql.NUMBER;
import java.io.IOException;
import java.sql.SQLException;

class T4CCharAccessor extends CharAccessor
{
    T4CMAREngine mare;
    boolean underlyingLong;
    final int[] meta;
    final int[] tmp;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CCharAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, n3, b);
        this.underlyingLong = false;
        this.meta = new int[1];
        this.tmp = new int[1];
        this.mare = mare;
        this.calculateSizeTmpByteArray();
    }
    
    T4CCharAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final int oacmxl, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, b, n2, n3, n4, n5, n6, n7);
        this.underlyingLong = false;
        this.meta = new int[1];
        this.tmp = new int[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
        this.calculateSizeTmpByteArray();
        this.oacmxl = oacmxl;
        if (this.oacmxl == -1) {
            this.underlyingLong = true;
            this.oacmxl = 4000;
        }
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        final byte[] tmpByteArray = this.statement.tmpByteArray;
        final int n3 = this.columnIndex + this.lastRowProcessed * this.charLength;
        if (this.rowSpaceIndicator == null) {
            this.mare.unmarshalCLR(new byte[16000], 0, this.meta);
            this.processIndicator(this.meta[0]);
            ++this.lastRowProcessed;
            return false;
        }
        if (this.isNullByDescribe) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
            ++this.lastRowProcessed;
            if (this.statement.connection.versionNumber < 9200) {
                this.processIndicator(0);
            }
            return false;
        }
        if (this.statement.maxFieldSize > 0) {
            this.mare.unmarshalCLR(tmpByteArray, 0, this.meta, this.statement.maxFieldSize);
        }
        else {
            this.mare.unmarshalCLR(tmpByteArray, 0, this.meta);
        }
        this.tmp[0] = this.meta[0];
        int n4;
        if (this.formOfUse == 2) {
            n4 = this.statement.connection.conversion.NCHARBytesToJavaChars(tmpByteArray, 0, this.rowSpaceChar, n3 + 1, this.tmp, this.charLength - 1);
        }
        else {
            n4 = this.statement.connection.conversion.CHARBytesToJavaChars(tmpByteArray, 0, this.rowSpaceChar, n3 + 1, this.tmp, this.charLength - 1);
        }
        this.rowSpaceChar[n3] = (char)(n4 * 2);
        this.processIndicator(this.meta[0]);
        if (this.meta[0] == 0) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
        }
        else {
            this.rowSpaceIndicator[n2] = (short)(this.meta[0] * 2);
            this.rowSpaceIndicator[n] = 0;
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    @Override
    void copyRow() throws SQLException, IOException {
        int n;
        if (this.lastRowProcessed == 0) {
            n = this.statement.rowPrefetchInLastFetch - 1;
        }
        else {
            n = this.lastRowProcessed - 1;
        }
        final int n2 = this.columnIndex + this.lastRowProcessed * this.charLength;
        final int n3 = this.columnIndex + n * this.charLength;
        final int n4 = this.indicatorIndex + this.lastRowProcessed;
        final int n5 = this.indicatorIndex + n;
        final int n6 = this.lengthIndex + this.lastRowProcessed;
        final short n7 = this.rowSpaceIndicator[this.lengthIndex + n];
        final int n8 = this.metaDataIndex + this.lastRowProcessed * 1;
        final int n9 = this.metaDataIndex + n * 1;
        this.rowSpaceIndicator[n6] = n7;
        this.rowSpaceIndicator[n4] = this.rowSpaceIndicator[n5];
        if (!this.isNullByDescribe) {
            System.arraycopy(this.rowSpaceChar, n3, this.rowSpaceChar, n2, this.rowSpaceChar[n3] / '\u0002' + 1);
        }
        System.arraycopy(this.rowSpaceMetaData, n9, this.rowSpaceMetaData, n8, 1);
        ++this.lastRowProcessed;
    }
    
    @Override
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
        final int n3 = this.columnIndex + (n2 - 1) * this.charLength;
        final int n4 = this.columnIndexLastRow + (n - 1) * this.charLength;
        final int n5 = this.indicatorIndex + n2 - 1;
        final int n6 = this.indicatorIndexLastRow + n - 1;
        final int n7 = this.lengthIndex + n2 - 1;
        final short n8 = array3[this.lengthIndexLastRow + n - 1];
        this.rowSpaceIndicator[n7] = n8;
        this.rowSpaceIndicator[n5] = array3[n6];
        if (n8 != 0) {
            System.arraycopy(array2, n4, this.rowSpaceChar, n3, array2[n4] / '\u0002' + 1);
        }
        else {
            this.rowSpaceChar[n3] = '\0';
        }
    }
    
    @Override
    void calculateSizeTmpByteArray() {
        int sizeTmpByteArray;
        if (this.formOfUse == 2) {
            sizeTmpByteArray = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
        }
        else {
            sizeTmpByteArray = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
        }
        if (this.statement.sizeTmpByteArray < sizeTmpByteArray) {
            this.statement.sizeTmpByteArray = sizeTmpByteArray;
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    @Override
    NUMBER getNUMBER(final int n) throws SQLException {
        NUMBER number = null;
        if (this.definedColumnType == 0) {
            number = super.getNUMBER(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                return T4CVarcharAccessor.StringToNUMBER(string);
            }
        }
        return number;
    }
    
    @Override
    DATE getDATE(final int n) throws SQLException {
        DATE date = null;
        if (this.definedColumnType == 0) {
            date = super.getDATE(n);
        }
        else {
            final Date date2 = this.getDate(n);
            if (date2 != null) {
                date = new DATE(date2);
            }
        }
        return date;
    }
    
    @Override
    TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        TIMESTAMP timestamp = null;
        if (this.definedColumnType == 0) {
            timestamp = super.getTIMESTAMP(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                final Timestamp timestamp2 = new Timestamp(T4CVarcharAccessor.DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), array).getTimeInMillis());
                timestamp2.setNanos(array[0]);
                timestamp = new TIMESTAMP(timestamp2);
            }
        }
        return timestamp;
    }
    
    @Override
    TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        TIMESTAMPTZ timestamptz = null;
        if (this.definedColumnType == 0) {
            timestamptz = super.getTIMESTAMPTZ(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                final Calendar dateStringToCalendar = T4CVarcharAccessor.DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), array);
                final Timestamp timestamp = new Timestamp(dateStringToCalendar.getTimeInMillis());
                timestamp.setNanos(array[0]);
                timestamptz = new TIMESTAMPTZ(this.statement.connection, timestamp, dateStringToCalendar);
            }
        }
        return timestamptz;
    }
    
    @Override
    TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        TIMESTAMPLTZ timestampltz = null;
        if (this.definedColumnType == 0) {
            timestampltz = super.getTIMESTAMPLTZ(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                final Calendar dateStringToCalendar = T4CVarcharAccessor.DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), array);
                final Timestamp timestamp = new Timestamp(dateStringToCalendar.getTimeInMillis());
                timestamp.setNanos(array[0]);
                timestampltz = new TIMESTAMPLTZ(this.statement.connection, timestamp, dateStringToCalendar);
            }
        }
        return timestampltz;
    }
    
    @Override
    RAW getRAW(final int n) throws SQLException {
        RAW raw = null;
        if (this.definedColumnType == 0) {
            raw = super.getRAW(n);
        }
        else {
            if (this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
                if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) {
                    raw = new RAW(this.getBytesFromHexChars(n));
                }
                else {
                    raw = new RAW(super.getBytes(n));
                }
            }
        }
        return raw;
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getOracleObject(n);
        }
        final Datum datum = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return datum;
        }
        switch (this.definedColumnType) {
            case -16:
            case -15:
            case -9:
            case -1:
            case 1:
            case 12: {
                return super.getOracleObject(n);
            }
            case -7:
            case -6:
            case -5:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 16: {
                return this.getNUMBER(n);
            }
            case 91: {
                return this.getDATE(n);
            }
            case 92: {
                return this.getDATE(n);
            }
            case 93: {
                return this.getTIMESTAMP(n);
            }
            case -101: {
                return this.getTIMESTAMPTZ(n);
            }
            case -102: {
                return this.getTIMESTAMPLTZ(n);
            }
            case -4:
            case -3:
            case -2: {
                return this.getRAW(n);
            }
            case -8: {
                return this.getROWID(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getBytes(n);
        }
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject != null) {
            return oracleObject.shareBytes();
        }
        return null;
    }
    
    @Override
    boolean getBoolean(final int n) throws SQLException {
        boolean b;
        if (this.definedColumnType == 0) {
            b = super.getBoolean(n);
        }
        else {
            b = this.getNUMBER(n).booleanValue();
        }
        return b;
    }
    
    @Override
    byte getByte(final int n) throws SQLException {
        byte b;
        if (this.definedColumnType == 0) {
            b = super.getByte(n);
        }
        else {
            b = this.getNUMBER(n).byteValue();
        }
        return b;
    }
    
    @Override
    int getInt(final int n) throws SQLException {
        int n2;
        if (this.definedColumnType == 0) {
            n2 = super.getInt(n);
        }
        else {
            n2 = this.getNUMBER(n).intValue();
        }
        return n2;
    }
    
    @Override
    short getShort(final int n) throws SQLException {
        short n2;
        if (this.definedColumnType == 0) {
            n2 = super.getShort(n);
        }
        else {
            n2 = this.getNUMBER(n).shortValue();
        }
        return n2;
    }
    
    @Override
    long getLong(final int n) throws SQLException {
        long n2;
        if (this.definedColumnType == 0) {
            n2 = super.getLong(n);
        }
        else {
            n2 = this.getNUMBER(n).longValue();
        }
        return n2;
    }
    
    @Override
    float getFloat(final int n) throws SQLException {
        float n2;
        if (this.definedColumnType == 0) {
            n2 = super.getFloat(n);
        }
        else {
            n2 = this.getNUMBER(n).floatValue();
        }
        return n2;
    }
    
    @Override
    double getDouble(final int n) throws SQLException {
        double n2;
        if (this.definedColumnType == 0) {
            n2 = super.getDouble(n);
        }
        else {
            n2 = this.getNUMBER(n).doubleValue();
        }
        return n2;
    }
    
    @Override
    Date getDate(final int n) throws SQLException {
        Date date = null;
        if (this.definedColumnType == 0) {
            date = super.getDate(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                date = new Date(T4CVarcharAccessor.DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), new int[1]).getTimeInMillis());
            }
        }
        return date;
    }
    
    @Override
    Timestamp getTimestamp(final int n) throws SQLException {
        Timestamp timestamp = null;
        if (this.definedColumnType == 0) {
            timestamp = super.getTimestamp(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                timestamp = new Timestamp(T4CVarcharAccessor.DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), array).getTimeInMillis());
                timestamp.setNanos(array[0]);
            }
        }
        return timestamp;
    }
    
    @Override
    Time getTime(final int n) throws SQLException {
        Time time = null;
        if (this.definedColumnType == 0) {
            time = super.getTime(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                time = new Time(T4CVarcharAccessor.DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), new int[1]).getTimeInMillis());
            }
        }
        return time;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getObject(n);
        }
        final Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return o;
        }
        switch (this.definedColumnType) {
            case -16:
            case -15:
            case -9:
            case -1:
            case 1:
            case 12: {
                return this.getString(n);
            }
            case 2:
            case 3: {
                return this.getBigDecimal(n);
            }
            case 4: {
                return this.getInt(n);
            }
            case -6: {
                return this.getByte(n);
            }
            case 5: {
                return this.getShort(n);
            }
            case -7:
            case 16: {
                return this.getBoolean(n);
            }
            case -5: {
                return this.getLong(n);
            }
            case 7: {
                return this.getFloat(n);
            }
            case 6:
            case 8: {
                return this.getDouble(n);
            }
            case 91: {
                return this.getDate(n);
            }
            case 92: {
                return this.getTime(n);
            }
            case 93: {
                return this.getTimestamp(n);
            }
            case -4:
            case -3:
            case -2: {
                return this.getBytesFromHexChars(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
