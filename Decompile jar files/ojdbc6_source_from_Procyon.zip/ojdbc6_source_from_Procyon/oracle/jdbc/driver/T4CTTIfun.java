// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.net.ns.BreakNetException;
import java.sql.SQLWarning;
import java.sql.SQLException;
import java.io.IOException;

abstract class T4CTTIfun extends T4CTTIMsg
{
    static final short OOPEN = 2;
    static final short OEXEC = 4;
    static final short OFETCH = 5;
    static final short OCLOSE = 8;
    static final short OLOGOFF = 9;
    static final short OCOMON = 12;
    static final short OCOMOFF = 13;
    static final short OCOMMIT = 14;
    static final short OROLLBACK = 15;
    static final short OCANCEL = 20;
    static final short ODSCRARR = 43;
    static final short OVERSION = 59;
    static final short OK2RPC = 67;
    static final short OALL7 = 71;
    static final short OSQL7 = 74;
    static final short O3LOGON = 81;
    static final short O3LOGA = 82;
    static final short OKOD = 92;
    static final short OALL8 = 94;
    static final short OLOBOPS = 96;
    static final short ODNY = 98;
    static final short OTXSE = 103;
    static final short OTXEN = 104;
    static final short OCCA = 105;
    static final short O80SES = 107;
    static final short OAUTH = 115;
    static final short OSESSKEY = 118;
    static final short OCANA = 120;
    static final short OKPN = 125;
    static final short OOTCM = 127;
    static final short OSCID = 135;
    static final short OSPFPPUT = 138;
    static final short OKPFC = 139;
    static final short OPING = 147;
    static final short OKEYVAL = 154;
    static final short OXSSCS = 155;
    static final short OXSSRO = 156;
    static final short OXSSPO = 157;
    static final short OAQEQ = 121;
    static final short OAQDQ = 122;
    static final short OAQGPS = 132;
    static final short OAQLS = 126;
    static final short OAQXQ = 145;
    static final short OXSNS = 172;
    private short funCode;
    private final byte seqNumber = 0;
    protected final T4CTTIoer oer;
    int receiveState;
    static final int IDLE_RECEIVE_STATE = 0;
    static final int ACTIVE_RECEIVE_STATE = 1;
    static final int READROW_RECEIVE_STATE = 2;
    static final int STREAM_RECEIVE_STATE = 3;
    boolean rpaProcessed;
    boolean rxhProcessed;
    boolean iovProcessed;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIfun(final T4CConnection t4CConnection, final byte b) {
        super(t4CConnection, b);
        this.receiveState = 0;
        this.rpaProcessed = false;
        this.rxhProcessed = false;
        this.iovProcessed = false;
        this.oer = t4CConnection.getT4CTTIoer();
    }
    
    final void setFunCode(final short funCode) {
        this.funCode = funCode;
    }
    
    final short getFunCode() {
        return this.funCode;
    }
    
    private final void marshalFunHeader() throws IOException {
        this.marshalTTCcode();
        this.meg.marshalUB1(this.funCode);
        this.meg.marshalUB1((short)0);
    }
    
    abstract void marshal() throws IOException;
    
    final void doRPC() throws IOException, SQLException {
        if (this.getTTCCode() == 17) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.init();
        this.marshalFunHeader();
        try {
            this.connection.pipeState = 1;
            this.marshal();
            this.connection.pipeState = 2;
            this.receive();
        }
        finally {
            this.connection.pipeState = -1;
        }
    }
    
    final void doPigRPC() throws IOException {
        this.init();
        this.marshalFunHeader();
        this.marshal();
    }
    
    private void init() {
        this.rpaProcessed = false;
        this.rxhProcessed = false;
        this.iovProcessed = false;
    }
    
    void resumeReceive() throws SQLException, IOException {
        this.receive();
    }
    
    private void receive() throws SQLException, IOException {
        this.receiveState = 1;
        SQLException ex = null;
    Label_0629:
        while (true) {
            try {
                switch (this.meg.unmarshalSB1()) {
                    case 8: {
                        if (this.rpaProcessed) {
                            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
                            sqlException.fillInStackTrace();
                            throw sqlException;
                        }
                        this.readRPA();
                        try {
                            this.processRPA();
                        }
                        catch (SQLException ex2) {
                            ex = ex2;
                        }
                        this.rpaProcessed = true;
                        continue;
                    }
                    case 21: {
                        this.readBVC();
                        continue;
                    }
                    case 11: {
                        this.readIOV();
                        this.iovProcessed = true;
                        continue;
                    }
                    case 6: {
                        this.readRXH();
                        this.rxhProcessed = true;
                        continue;
                    }
                    case 7: {
                        this.receiveState = 2;
                        if (this.readRXD()) {
                            this.receiveState = 3;
                            return;
                        }
                        this.receiveState = 1;
                        continue;
                    }
                    case 16: {
                        this.readDCB();
                        continue;
                    }
                    case 14: {
                        this.readLOBD();
                        continue;
                    }
                    case 23: {
                        final byte b = (byte)this.meg.unmarshalUB1();
                        final int unmarshalUB2 = this.meg.unmarshalUB2();
                        final byte b2 = (byte)this.meg.unmarshalUB1();
                        if (b == 1) {
                            for (int i = 0; i < unmarshalUB2; ++i) {
                                new T4CTTIidc(this.connection).unmarshal();
                            }
                            continue;
                        }
                        if (b == 2) {
                            for (int j = 0; j < unmarshalUB2; ++j) {
                                this.meg.unmarshalUB1();
                            }
                            continue;
                        }
                        if (b == 3) {
                            continue;
                        }
                        if (b == 4) {
                            continue;
                        }
                        if (b == 5) {
                            new T4CTTIkvarr(this.connection).unmarshal();
                            continue;
                        }
                        if (b == 6) {
                            for (int k = 0; k < unmarshalUB2; ++k) {
                                this.connection.notify(new NTFXSEvent(this.connection));
                            }
                            continue;
                        }
                        continue;
                    }
                    case 19: {
                        this.meg.marshalUB1((short)19);
                        continue;
                    }
                    case 15: {
                        this.oer.init();
                        this.oer.unmarshalWarning();
                        try {
                            this.oer.processWarning();
                        }
                        catch (SQLWarning sqlWarning) {
                            this.connection.setWarnings(DatabaseError.addSqlWarning(this.connection.getWarnings(), sqlWarning));
                        }
                        continue;
                    }
                    case 9: {
                        if (this.connection.getTTCVersion() >= 3) {
                            this.connection.endToEndECIDSequenceNumber = (short)this.meg.unmarshalUB2();
                        }
                        break Label_0629;
                    }
                    case 4: {
                        this.oer.init();
                        this.oer.unmarshal();
                        try {
                            this.processError();
                        }
                        catch (SQLException ex3) {
                            ex = ex3;
                        }
                        break Label_0629;
                    }
                    default: {
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                }
            }
            catch (BreakNetException ex4) {}
            finally {
                this.connection.sentCancel = false;
            }
        }
        this.receiveState = 0;
        if (ex != null) {
            throw ex;
        }
    }
    
    void processRPA() throws SQLException {
    }
    
    void readRPA() throws IOException, SQLException {
    }
    
    void readBVC() throws IOException, SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void readLOBD() throws IOException, SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void readIOV() throws IOException, SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void readRXH() throws IOException, SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    boolean readRXD() throws IOException, SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void readDCB() throws IOException, SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void processError() throws SQLException {
        this.oer.processError();
    }
    
    final int getErrorCode() throws SQLException {
        return this.oer.retCode;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
