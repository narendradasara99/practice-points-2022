// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.TimeZone;
import java.text.DateFormatSymbols;
import java.io.IOException;
import java.sql.SQLException;

class T4CTimestampltzAccessor extends TimestampltzAccessor
{
    T4CMAREngine mare;
    boolean underlyingLongRaw;
    final int[] meta;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTimestampltzAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, n3, b);
        this.underlyingLongRaw = false;
        this.meta = new int[1];
        this.mare = mare;
    }
    
    T4CTimestampltzAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, (n == -1) ? definedColumnSize : n, b, n2, n3, n4, n5, n6, n7);
        this.underlyingLongRaw = false;
        this.meta = new int[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
        if (n == -1) {
            this.underlyingLongRaw = true;
        }
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        if (this.rowSpaceIndicator == null) {
            this.mare.unmarshalCLR(new byte[16000], 0, this.meta);
            this.processIndicator(this.meta[0]);
            ++this.lastRowProcessed;
            return false;
        }
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        if (this.isNullByDescribe) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
            ++this.lastRowProcessed;
            if (this.statement.connection.versionNumber < 9200) {
                this.processIndicator(0);
            }
            return false;
        }
        this.mare.unmarshalCLR(this.rowSpaceByte, this.columnIndex + this.lastRowProcessed * this.byteLength, this.meta, this.byteLength);
        this.processIndicator(this.meta[0]);
        if (this.meta[0] == 0) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
        }
        else {
            this.rowSpaceIndicator[n2] = (short)this.meta[0];
            this.rowSpaceIndicator[n] = 0;
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    @Override
    void copyRow() throws SQLException, IOException {
        int n;
        if (this.lastRowProcessed == 0) {
            n = this.statement.rowPrefetchInLastFetch - 1;
        }
        else {
            n = this.lastRowProcessed - 1;
        }
        final int n2 = this.columnIndex + this.lastRowProcessed * this.byteLength;
        final int n3 = this.columnIndex + n * this.byteLength;
        final int n4 = this.indicatorIndex + this.lastRowProcessed;
        final int n5 = this.indicatorIndex + n;
        final int n6 = this.lengthIndex + this.lastRowProcessed;
        final short n7 = this.rowSpaceIndicator[this.lengthIndex + n];
        final int n8 = this.metaDataIndex + this.lastRowProcessed * 1;
        final int n9 = this.metaDataIndex + n * 1;
        this.rowSpaceIndicator[n6] = n7;
        this.rowSpaceIndicator[n4] = this.rowSpaceIndicator[n5];
        if (!this.isNullByDescribe) {
            System.arraycopy(this.rowSpaceByte, n3, this.rowSpaceByte, n2, n7);
        }
        System.arraycopy(this.rowSpaceMetaData, n9, this.rowSpaceMetaData, n8, 1);
        ++this.lastRowProcessed;
    }
    
    @Override
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
        final int n3 = this.columnIndex + (n2 - 1) * this.byteLength;
        final int n4 = this.columnIndexLastRow + (n - 1) * this.byteLength;
        final int n5 = this.indicatorIndex + n2 - 1;
        final int n6 = this.indicatorIndexLastRow + n - 1;
        final int n7 = this.lengthIndex + n2 - 1;
        final short n8 = array3[this.lengthIndexLastRow + n - 1];
        this.rowSpaceIndicator[n7] = n8;
        this.rowSpaceIndicator[n5] = array3[n6];
        if (n8 != 0) {
            System.arraycopy(array, n4, this.rowSpaceByte, n3, n8);
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    @Override
    String toText(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final boolean b, final String s) throws SQLException {
        if (this.definedColumnType == 0 || this.definedColumnType == -102) {
            return super.toText(n, n2, n3, n4, n5, n6, n7, b, s);
        }
        return nlsFormatToText(n, n2, n3, n4, n5, n6, n7, b, s, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"));
    }
    
    private static final String nlsFormatToText(int n, final int i, final int j, int n2, final int k, final int l, final int m, final boolean b, final String s, final String str) throws SQLException {
        final char[] charArray = (str + "      ").toCharArray();
        final int length = str.length();
        final StringBuffer sb = new StringBuffer(length + 25);
        String[] shortMonths = null;
        String[] months = null;
        TimeZone timeZone = null;
        for (int n3 = 0; n3 < length; ++n3) {
            switch (charArray[n3]) {
                case 'R':
                case 'r': {
                    if (charArray[n3 + 1] != 'R' && charArray[n3 + 1] != 'r') {
                        break;
                    }
                    if ((charArray[n3 + 2] == 'R' || charArray[n3 + 2] == 'r') && (charArray[n3 + 3] == 'R' || charArray[n3 + 3] == 'r')) {
                        if (n < 1000) {
                            sb.append("0" + n);
                        }
                        else if (n < 100) {
                            sb.append("00" + n);
                        }
                        else if (n < 10) {
                            sb.append("000" + n);
                        }
                        else {
                            sb.append(n);
                        }
                        n3 += 3;
                        break;
                    }
                    if (n >= 100) {
                        n %= 100;
                    }
                    if (n < 10) {
                        sb.append("0" + n);
                    }
                    else {
                        sb.append(n);
                    }
                    ++n3;
                    break;
                }
                case 'Y':
                case 'y': {
                    if (charArray[n3 + 1] != 'Y' && charArray[n3 + 1] != 'y') {
                        break;
                    }
                    if ((charArray[n3 + 2] == 'Y' || charArray[n3 + 2] == 'y') && (charArray[n3 + 3] == 'Y' || charArray[n3 + 3] == 'y')) {
                        if (n < 1000) {
                            sb.append("0" + n);
                        }
                        else if (n < 100) {
                            sb.append("00" + n);
                        }
                        else if (n < 10) {
                            sb.append("000" + n);
                        }
                        else {
                            sb.append(n);
                        }
                        n3 += 3;
                        break;
                    }
                    if (n >= 100) {
                        n %= 100;
                    }
                    if (n < 10) {
                        sb.append("0" + n);
                    }
                    else {
                        sb.append(n);
                    }
                    ++n3;
                    break;
                }
                case 'D':
                case 'd': {
                    if (charArray[n3 + 1] == 'D' || charArray[n3 + 1] == 'd') {
                        sb.append(((j < 10) ? "0" : "") + j);
                        ++n3;
                        break;
                    }
                    break;
                }
                case 'M':
                case 'm': {
                    if (charArray[n3 + 1] == 'M' || charArray[n3 + 1] == 'm') {
                        sb.append(((i < 10) ? "0" : "") + i);
                        ++n3;
                        break;
                    }
                    if (charArray[n3 + 1] == 'I' || charArray[n3 + 1] == 'i') {
                        sb.append(((k < 10) ? "0" : "") + k);
                        ++n3;
                        break;
                    }
                    if ((charArray[n3 + 1] != 'O' && charArray[n3 + 1] != 'o') || (charArray[n3 + 2] != 'N' && charArray[n3 + 2] != 'n')) {
                        break;
                    }
                    if ((charArray[n3 + 3] == 'T' || charArray[n3 + 3] == 't') && (charArray[n3 + 4] == 'H' || charArray[n3 + 4] == 'h')) {
                        if (months == null) {
                            months = new DateFormatSymbols().getMonths();
                        }
                        sb.append(months[i - 1]);
                        n3 += 4;
                        break;
                    }
                    if (shortMonths == null) {
                        shortMonths = new DateFormatSymbols().getShortMonths();
                    }
                    sb.append(shortMonths[i - 1]);
                    n3 += 2;
                    break;
                }
                case 'H':
                case 'h': {
                    if (charArray[n3 + 1] != 'H' && charArray[n3 + 1] != 'h') {
                        break;
                    }
                    if (charArray[n3 + 2] == '2' || charArray[n3 + 3] == '4') {
                        sb.append(((n2 < 10) ? "0" : "") + n2);
                        n3 += 3;
                        break;
                    }
                    if (n2 > 12) {
                        n2 -= 12;
                    }
                    sb.append(((n2 < 10) ? "0" : "") + n2);
                    ++n3;
                    break;
                }
                case 'S':
                case 's': {
                    if (charArray[n3 + 1] != 'S' && charArray[n3 + 1] != 's') {
                        break;
                    }
                    sb.append(((l < 10) ? "0" : "") + l);
                    ++n3;
                    if ((charArray[n3 + 1] == 'X' || charArray[n3 + 1] == 'x') && (charArray[n3 + 2] == 'F' || charArray[n3 + 2] == 'f') && (charArray[n3 + 3] == 'F' || charArray[n3 + 3] == 'f')) {
                        sb.append(".");
                        ++n3;
                        break;
                    }
                    break;
                }
                case 'F':
                case 'f': {
                    if (charArray[n3 + 1] == 'F' || charArray[n3 + 1] == 'f') {
                        sb.append(m);
                        ++n3;
                        break;
                    }
                    break;
                }
                case 'T':
                case 't': {
                    if (charArray[n3 + 1] != 'Z' && charArray[n3 + 1] != 'z') {
                        break;
                    }
                    if (charArray[n3 + 2] == 'R' || charArray[n3 + 2] == 'r') {
                        if (s.length() > 3 && s.startsWith("GMT")) {
                            sb.append(s.substring(3));
                        }
                        else {
                            sb.append(s.toUpperCase());
                        }
                        n3 += 2;
                        break;
                    }
                    if (charArray[n3 + 2] == 'H' || charArray[n3 + 2] == 'h') {
                        if (timeZone == null) {
                            timeZone = TimeZone.getTimeZone(s);
                        }
                        sb.append((long)(timeZone.getRawOffset() / 3600000));
                        n3 += 2;
                        break;
                    }
                    if (charArray[n3 + 2] == 'M' || charArray[n3 + 2] == 'm') {
                        if (timeZone == null) {
                            timeZone = TimeZone.getTimeZone(s);
                        }
                        final long lng = Math.abs(timeZone.getRawOffset()) % 3600000 / 60000;
                        sb.append(((lng < 10L) ? "0" : "") + lng);
                        n3 += 2;
                        break;
                    }
                    break;
                }
                case 'A':
                case 'P':
                case 'a':
                case 'p': {
                    if (charArray[n3 + 1] == 'M' || charArray[n3 + 1] == 'm') {
                        sb.append(b ? "AM" : "PM");
                        ++n3;
                        break;
                    }
                    break;
                }
                default: {
                    sb.append(charArray[n3]);
                    break;
                }
            }
        }
        return sb.substring(0, sb.length());
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getObject(n);
        }
        final Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return o;
        }
        switch (this.definedColumnType) {
            case -1:
            case 1:
            case 12: {
                return this.getString(n);
            }
            case 93: {
                return this.getTimestamp(n);
            }
            case -102: {
                return this.getTIMESTAMPLTZ(n);
            }
            case 91: {
                return this.getDate(n);
            }
            case 92: {
                return this.getTime(n);
            }
            case -4:
            case -3:
            case -2: {
                return this.getBytes(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
