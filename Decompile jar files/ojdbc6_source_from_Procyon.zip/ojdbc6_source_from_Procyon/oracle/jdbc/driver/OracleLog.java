// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.logging.Level;

public class OracleLog
{
    private static final int maxPrintBytes = 512;
    public static final boolean TRACE = false;
    public static final Level INTERNAL_ERROR;
    public static final Level TRACE_1;
    public static final Level TRACE_10;
    public static final Level TRACE_16;
    public static final Level TRACE_20;
    public static final Level TRACE_30;
    public static final Level TRACE_32;
    static boolean securityExceptionWhileGettingSystemProperties;
    
    public static boolean isDebugZip() {
        return false;
    }
    
    public static boolean isPrivateLogAvailable() {
        return false;
    }
    
    public static boolean isEnabled() {
        return false;
    }
    
    public static boolean registerClassNameAndGetCurrentTraceSetting(final Class clazz) {
        return false;
    }
    
    public static void setTrace(final boolean b) {
    }
    
    private static void initialize() {
        setupFromSystemProperties();
    }
    
    public static void setupFromSystemProperties() {
        boolean trace = false;
        OracleLog.securityExceptionWhileGettingSystemProperties = false;
        try {
            final String systemProperty = getSystemProperty("oracle.jdbc.Trace", null);
            if (systemProperty != null && systemProperty.compareTo("true") == 0) {
                trace = true;
            }
        }
        catch (SecurityException ex) {
            OracleLog.securityExceptionWhileGettingSystemProperties = true;
        }
        setTrace(trace);
    }
    
    private static String getSystemProperty(final String s) {
        return getSystemProperty(s, null);
    }
    
    private static String getSystemProperty(final String s, final String s2) {
        if (s != null) {
            final String[] array = { s2 };
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
                @Override
                public Object run() {
                    array[0] = System.getProperty(s, s2);
                    return null;
                }
            });
            return array[0];
        }
        return s2;
    }
    
    public static String argument() {
        return "";
    }
    
    public static String argument(final boolean b) {
        return Boolean.toString(b);
    }
    
    public static String argument(final byte b) {
        return Byte.toString(b);
    }
    
    public static String argument(final short s) {
        return Short.toString(s);
    }
    
    public static String argument(final int i) {
        return Integer.toString(i);
    }
    
    public static String argument(final long i) {
        return Long.toString(i);
    }
    
    public static String argument(final float f) {
        return Float.toString(f);
    }
    
    public static String argument(final double d) {
        return Double.toString(d);
    }
    
    public static String argument(final Object o) {
        if (o == null) {
            return "null";
        }
        if (o instanceof String) {
            return "\"" + (String)o + "\"";
        }
        return o.toString();
    }
    
    @Deprecated
    public static String byteToHexString(final byte b) {
        final StringBuffer sb = new StringBuffer("");
        final int i = 0xFF & b;
        if (i <= 15) {
            sb.append("0x0");
        }
        else {
            sb.append("0x");
        }
        sb.append(Integer.toHexString(i));
        return sb.toString();
    }
    
    @Deprecated
    public static String bytesToPrintableForm(final String s, final byte[] array) {
        return bytesToPrintableForm(s, array, (array == null) ? 0 : array.length);
    }
    
    @Deprecated
    public static String bytesToPrintableForm(final String s, final byte[] array, final int n) {
        String s2;
        if (array == null) {
            s2 = s + ": null";
        }
        else {
            s2 = s + " (" + array.length + " bytes):\n" + bytesToFormattedStr(array, n, "  ");
        }
        return s2;
    }
    
    @Deprecated
    public static String bytesToFormattedStr(final byte[] array, final int n, String str) {
        final StringBuffer sb = new StringBuffer("");
        if (str == null) {
            str = new String("");
        }
        sb.append(str);
        if (array == null) {
            sb.append("byte [] is null");
            return sb.toString();
        }
        for (int i = 0; i < n; ++i) {
            if (i >= 512) {
                sb.append("\n" + str + "... last " + (n - 512) + " bytes were not printed to limit the output size");
                break;
            }
            if (i > 0 && i % 20 == 0) {
                sb.append("\n" + str);
            }
            if (i % 20 == 10) {
                sb.append(" ");
            }
            final int j = 0xFF & array[i];
            if (j <= 15) {
                sb.append("0");
            }
            sb.append(Integer.toHexString(j) + " ");
        }
        return sb.toString();
    }
    
    @Deprecated
    public static byte[] strToUcs2Bytes(final String s) {
        if (s == null) {
            return null;
        }
        return charsToUcs2Bytes(s.toCharArray());
    }
    
    @Deprecated
    public static byte[] charsToUcs2Bytes(final char[] array) {
        if (array == null) {
            return null;
        }
        return charsToUcs2Bytes(array, array.length);
    }
    
    @Deprecated
    public static byte[] charsToUcs2Bytes(final char[] array, final int n) {
        if (array == null) {
            return null;
        }
        if (n < 0) {
            return null;
        }
        return charsToUcs2Bytes(array, n, 0);
    }
    
    @Deprecated
    public static byte[] charsToUcs2Bytes(final char[] array, int n, final int n2) {
        if (array == null) {
            return null;
        }
        if (n > array.length - n2) {
            n = array.length - n2;
        }
        if (n < 0) {
            return null;
        }
        final byte[] array2 = new byte[2 * n];
        int i = n2;
        int n3 = 0;
        while (i < n) {
            array2[n3++] = (byte)(array[i] >> 8 & 0xFF);
            array2[n3++] = (byte)(array[i] & '\u00ff');
            ++i;
        }
        return array2;
    }
    
    @Deprecated
    public static String toPrintableStr(final String s, final int n) {
        if (s == null) {
            return "null";
        }
        if (s.length() > n) {
            return s.substring(0, n - 1) + "\n ... the actual length was " + s.length();
        }
        return s;
    }
    
    public static String toHex(final long n, final int n2) {
        String s = null;
        switch (n2) {
            case 1: {
                s = "00" + Long.toString(n & 0xFFL, 16);
                break;
            }
            case 2: {
                s = "0000" + Long.toString(n & 0xFFFFL, 16);
                break;
            }
            case 3: {
                s = "000000" + Long.toString(n & 0xFFFFFFL, 16);
                break;
            }
            case 4: {
                s = "00000000" + Long.toString(n & 0xFFFFFFFFL, 16);
                break;
            }
            case 5: {
                s = "0000000000" + Long.toString(n & 0xFFFFFFFFFFL, 16);
                break;
            }
            case 6: {
                s = "000000000000" + Long.toString(n & 0xFFFFFFFFFFFFL, 16);
                break;
            }
            case 7: {
                s = "00000000000000" + Long.toString(n & 0xFFFFFFFFFFFFFFL, 16);
                break;
            }
            case 8: {
                return toHex(n >> 32, 4) + toHex(n, 4).substring(2);
            }
            default: {
                return "more than 8 bytes";
            }
        }
        return "0x" + s.substring(s.length() - 2 * n2);
    }
    
    public static String toHex(final byte b) {
        final String string = "00" + Integer.toHexString(b & 0xFF);
        return "0x" + string.substring(string.length() - 2);
    }
    
    public static String toHex(final short n) {
        return toHex(n, 2);
    }
    
    public static String toHex(final int n) {
        return toHex(n, 4);
    }
    
    public static String toHex(final byte[] array, final int b) {
        if (array == null) {
            return "null";
        }
        if (b > array.length) {
            return "byte array not long enough";
        }
        String str = "[";
        final int min = Math.min(64, b);
        for (int i = 0; i < min; ++i) {
            str = str + toHex(array[i]) + " ";
        }
        if (min < b) {
            str += "...";
        }
        return str + "]";
    }
    
    public static String toHex(final byte[] array) {
        if (array == null) {
            return "null";
        }
        return toHex(array, array.length);
    }
    
    static {
        INTERNAL_ERROR = OracleLevel.INTERNAL_ERROR;
        TRACE_1 = OracleLevel.TRACE_1;
        TRACE_10 = OracleLevel.TRACE_10;
        TRACE_16 = OracleLevel.TRACE_16;
        TRACE_20 = OracleLevel.TRACE_20;
        TRACE_30 = OracleLevel.TRACE_30;
        TRACE_32 = OracleLevel.TRACE_32;
        initialize();
    }
    
    private static class OracleLevel extends Level
    {
        static final OracleLevel INTERNAL_ERROR;
        static final OracleLevel TRACE_1;
        static final OracleLevel TRACE_10;
        static final OracleLevel TRACE_16;
        static final OracleLevel TRACE_20;
        static final OracleLevel TRACE_30;
        static final OracleLevel TRACE_32;
        
        OracleLevel(final String name, final int value) {
            super(name, value);
        }
        
        static {
            INTERNAL_ERROR = new OracleLevel("INTERNAL_ERROR", 1100);
            TRACE_1 = new OracleLevel("TRACE_1", Level.FINE.intValue());
            TRACE_10 = new OracleLevel("TRACE_10", 446);
            TRACE_16 = new OracleLevel("TRACE_16", Level.FINER.intValue());
            TRACE_20 = new OracleLevel("TRACE_20", 376);
            TRACE_30 = new OracleLevel("TRACE_30", 316);
            TRACE_32 = new OracleLevel("TRACE_32", Level.FINEST.intValue());
        }
    }
}
