// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class Namespace
{
    static final int ATTRIBUTE_MAX_LENGTH = 30;
    static final int VALUE_MAX_LENGTH = 4000;
    String name;
    boolean clear;
    String[] keys;
    String[] values;
    int nbPairs;
    
    Namespace(final String name) {
        if (name == null) {
            throw new NullPointerException();
        }
        this.name = name;
        this.clear = false;
        this.nbPairs = 0;
        this.keys = new String[5];
        this.values = new String[5];
    }
    
    void clear() {
        this.clear = true;
        for (int i = 0; i < this.nbPairs; ++i) {
            this.keys[i] = null;
            this.values[i] = null;
        }
        this.nbPairs = 0;
    }
    
    void setAttribute(final String s, final String s2) {
        if (s == null || s2 == null || s.equals("")) {
            throw new NullPointerException();
        }
        if (this.nbPairs == this.keys.length) {
            final String[] keys = new String[this.keys.length * 2];
            final String[] values = new String[this.keys.length * 2];
            System.arraycopy(this.keys, 0, keys, 0, this.keys.length);
            System.arraycopy(this.values, 0, values, 0, this.values.length);
            this.keys = keys;
            this.values = values;
        }
        this.keys[this.nbPairs] = s;
        this.values[this.nbPairs] = s2;
        ++this.nbPairs;
    }
}
