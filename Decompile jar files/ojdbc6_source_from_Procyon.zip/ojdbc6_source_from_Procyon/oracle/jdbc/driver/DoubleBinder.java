// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.core.lmx.CoreException;

class DoubleBinder extends VarnumBinder
{
    char[] digits;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    DoubleBinder() {
        this.digits = new char[20];
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) throws SQLException {
        final int n10 = n6 + 1;
        double d = oraclePreparedStatement.parameterDouble[n3][n];
        int dtoa;
        if (d == 0.0) {
            array[n10] = -128;
            dtoa = 1;
        }
        else if (d == Double.POSITIVE_INFINITY) {
            array[n10] = -1;
            array[n10 + 1] = 101;
            dtoa = 2;
        }
        else if (d == Double.NEGATIVE_INFINITY) {
            array[n10] = 0;
            dtoa = 1;
        }
        else {
            final boolean b2 = d < 0.0;
            if (b2) {
                d = -d;
            }
            final long doubleToLongBits = Double.doubleToLongBits(d);
            final int n11 = (int)(doubleToLongBits >> 52 & 0x7FFL);
            int n12 = ((n11 > 1023) ? 126 : 127) - (int)((n11 - 1023) / 6.643856189774725);
            if (n12 < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)3) + " trying to bind " + d);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (n12 > 192) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)2) + " trying to bind " + d);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (d > DoubleBinder.factorTable[n12]) {
                while (n12 > 0 && d > DoubleBinder.factorTable[--n12]) {}
            }
            else {
                while (n12 < 193 && d <= DoubleBinder.factorTable[n12 + 1]) {
                    ++n12;
                }
            }
            if (d == DoubleBinder.factorTable[n12]) {
                if (n12 < 65) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)3) + " trying to bind " + d);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                if (n12 > 192) {
                    final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)2) + " trying to bind " + d);
                    sqlException4.fillInStackTrace();
                    throw sqlException4;
                }
                if (b2) {
                    array[n10] = (byte)(62 - (127 - n12));
                    array[n10 + 1] = 100;
                    array[n10 + 2] = 102;
                    dtoa = 3;
                }
                else {
                    array[n10] = (byte)(192 + (128 - n12));
                    array[n10 + 1] = 2;
                    dtoa = 2;
                }
            }
            else {
                if (n12 < 64) {
                    final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)3) + " trying to bind " + d);
                    sqlException5.fillInStackTrace();
                    throw sqlException5;
                }
                if (n12 > 191) {
                    final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)2) + " trying to bind " + d);
                    sqlException6.fillInStackTrace();
                    throw sqlException6;
                }
                long n13 = (b2 ? (doubleToLongBits & Long.MAX_VALUE) : doubleToLongBits) & 0xFFFFFFFFFFFFFL;
                int n14 = n11;
                final char[] digits = oraclePreparedStatement.digits;
                int n15;
                if (n14 == 0) {
                    while ((n13 & 0x10000000000000L) == 0x0L) {
                        n13 <<= 1;
                        --n14;
                    }
                    n15 = 53 + n14;
                    ++n14;
                }
                else {
                    n13 |= 0x10000000000000L;
                    n15 = 53;
                }
                n14 -= 1023;
                dtoa = this.dtoa(array, n10, d, b2, false, digits, n14, n13, n15);
            }
        }
        array[n6] = (byte)dtoa;
        array3[n9] = 0;
        array3[n8] = (short)(dtoa + 1);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
