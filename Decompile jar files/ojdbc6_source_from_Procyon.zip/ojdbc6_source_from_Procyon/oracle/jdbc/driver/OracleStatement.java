// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Locale;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import java.util.Iterator;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import java.sql.Statement;
import java.sql.Connection;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.BatchUpdateException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import java.util.Calendar;
import java.util.TimeZone;
import java.sql.SQLWarning;
import oracle.jdbc.OracleResultSetCache;
import java.nio.ByteBuffer;
import java.io.InputStream;

abstract class OracleStatement implements oracle.jdbc.internal.OracleStatement, ScrollRsetStatement
{
    static final int PLAIN_STMT = 0;
    static final int PREP_STMT = 1;
    static final int CALL_STMT = 2;
    static final byte IS_UNINITIALIZED = 0;
    static final byte IS_SELECT = 1;
    static final byte IS_DELETE = 2;
    static final byte IS_INSERT = 4;
    static final byte IS_MERGE = 8;
    static final byte IS_UPDATE = 16;
    static final byte IS_PLSQL_BLOCK = 32;
    static final byte IS_CALL_BLOCK = 64;
    static final byte IS_OTHER = Byte.MIN_VALUE;
    static final byte IS_DML = 30;
    static final byte IS_PLSQL = 96;
    int cursorId;
    int numberOfDefinePositions;
    int definesBatchSize;
    Accessor[] accessors;
    int defineByteSubRange;
    int defineCharSubRange;
    int defineIndicatorSubRange;
    int defineLengthSubRange;
    byte[] defineBytes;
    char[] defineChars;
    short[] defineIndicators;
    boolean described;
    boolean describedWithNames;
    byte[] defineMetaData;
    int defineMetaDataSubRange;
    static final int METADATALENGTH = 1;
    int rowsProcessed;
    int cachedDefineByteSize;
    int cachedDefineCharSize;
    int cachedDefineIndicatorSize;
    int cachedDefineMetaDataSize;
    OracleStatement children;
    OracleStatement parent;
    OracleStatement nextChild;
    OracleStatement next;
    OracleStatement prev;
    long c_state;
    int numberOfBindPositions;
    byte[] bindBytes;
    char[] bindChars;
    short[] bindIndicators;
    int bindByteOffset;
    int bindCharOffset;
    int bindIndicatorOffset;
    int bindByteSubRange;
    int bindCharSubRange;
    int bindIndicatorSubRange;
    Accessor[] outBindAccessors;
    InputStream[][] parameterStream;
    Object[][] userStream;
    int firstRowInBatch;
    boolean hasIbtBind;
    byte[] ibtBindBytes;
    char[] ibtBindChars;
    short[] ibtBindIndicators;
    int ibtBindByteOffset;
    int ibtBindCharOffset;
    int ibtBindIndicatorOffset;
    int ibtBindIndicatorSize;
    ByteBuffer[] nioBuffers;
    Object[] lobPrefetchMetaData;
    boolean hasStream;
    byte[] tmpByteArray;
    int sizeTmpByteArray;
    byte[] tmpBindsByteArray;
    boolean needToSendOalToFetch;
    int[] definedColumnType;
    int[] definedColumnSize;
    int[] definedColumnFormOfUse;
    T4CTTIoac[] oacdefSent;
    int[] nbPostPonedColumns;
    int[][] indexOfPostPonedColumn;
    boolean aFetchWasDoneDuringDescribe;
    boolean implicitDefineForLobPrefetchDone;
    int accessorByteOffset;
    int accessorCharOffset;
    int accessorShortOffset;
    static final int VALID_ROWS_UNINIT = -999;
    PhysicalConnection connection;
    OracleInputStream streamList;
    OracleInputStream nextStream;
    OracleResultSetImpl currentResultSet;
    boolean processEscapes;
    boolean convertNcharLiterals;
    int queryTimeout;
    int batch;
    int numberOfExecutedElementsInBatch;
    int currentRank;
    int currentRow;
    int validRows;
    int maxFieldSize;
    int maxRows;
    int totalRowsVisited;
    int rowPrefetch;
    int rowPrefetchInLastFetch;
    int defaultRowPrefetch;
    boolean rowPrefetchChanged;
    int defaultLobPrefetchSize;
    boolean gotLastBatch;
    boolean clearParameters;
    boolean closed;
    boolean sqlStringChanged;
    OracleSql sqlObject;
    boolean needToParse;
    boolean needToPrepareDefineBuffer;
    boolean columnsDefinedByUser;
    byte sqlKind;
    int autoRollback;
    int defaultFetchDirection;
    boolean serverCursor;
    boolean fixedString;
    boolean noMoreUpdateCounts;
    boolean isExecuting;
    OracleStatementWrapper wrapper;
    static final byte EXECUTE_NONE = -1;
    static final byte EXECUTE_QUERY = 1;
    static final byte EXECUTE_UPDATE = 2;
    static final byte EXECUTE_NORMAL = 3;
    byte executionType;
    OracleResultSet scrollRset;
    OracleResultSetCache rsetCache;
    int userRsetType;
    int realRsetType;
    boolean needToAddIdentifier;
    SQLWarning sqlWarning;
    int cacheState;
    int creationState;
    boolean isOpen;
    int statementType;
    boolean columnSetNull;
    int[] returnParamMeta;
    static final int DMLR_METADATA_PREFIX_SIZE = 3;
    static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
    static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
    static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
    static final int DMLR_METADATA_TYPE_OFFSET = 0;
    static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
    static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
    static final int DMLR_METADATA_PER_POSITION_SIZE = 3;
    Accessor[] returnParamAccessors;
    boolean returnParamsFetched;
    int rowsDmlReturned;
    int numReturnParams;
    byte[] returnParamBytes;
    char[] returnParamChars;
    short[] returnParamIndicators;
    int returnParamRowBytes;
    int returnParamRowChars;
    OracleReturnResultSet returnResultSet;
    boolean isAutoGeneratedKey;
    AutoKeyInfo autoKeyInfo;
    TimeZone defaultTimeZone;
    String defaultTimeZoneName;
    Calendar defaultCalendar;
    Calendar gmtCalendar;
    int lastIndex;
    Vector m_batchItems;
    ArrayList tempClobsToFree;
    ArrayList tempBlobsToFree;
    ArrayList oldTempClobsToFree;
    ArrayList oldTempBlobsToFree;
    NTFDCNRegistration registration;
    String[] dcnTableName;
    long dcnQueryId;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    abstract void doDescribe(final boolean p0) throws SQLException;
    
    abstract void executeForDescribe() throws SQLException;
    
    abstract void executeForRows(final boolean p0) throws SQLException;
    
    abstract void fetch() throws SQLException;
    
    void continueReadRow(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    abstract void doClose() throws SQLException;
    
    abstract void closeQuery() throws SQLException;
    
    public int cursorIfRefCursor() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    OracleStatement(final PhysicalConnection physicalConnection, final int n, final int n2) throws SQLException {
        this(physicalConnection, n, n2, -1, -1);
    }
    
    OracleStatement(final PhysicalConnection connection, final int batch, final int n, final int n2, final int n3) throws SQLException {
        this.described = false;
        this.describedWithNames = false;
        this.cachedDefineByteSize = 0;
        this.cachedDefineCharSize = 0;
        this.cachedDefineIndicatorSize = 0;
        this.cachedDefineMetaDataSize = 0;
        this.children = null;
        this.parent = null;
        this.nextChild = null;
        this.hasIbtBind = false;
        this.nioBuffers = null;
        this.lobPrefetchMetaData = null;
        this.sizeTmpByteArray = 0;
        this.needToSendOalToFetch = false;
        this.definedColumnType = null;
        this.definedColumnSize = null;
        this.definedColumnFormOfUse = null;
        this.oacdefSent = null;
        this.nbPostPonedColumns = null;
        this.indexOfPostPonedColumn = null;
        this.aFetchWasDoneDuringDescribe = false;
        this.implicitDefineForLobPrefetchDone = false;
        this.accessorByteOffset = 0;
        this.accessorCharOffset = 0;
        this.accessorShortOffset = 0;
        this.numberOfExecutedElementsInBatch = -1;
        this.rowPrefetchInLastFetch = -1;
        this.sqlKind = 1;
        this.fixedString = false;
        this.noMoreUpdateCounts = false;
        this.isExecuting = false;
        this.executionType = -1;
        this.cacheState = 3;
        this.creationState = 0;
        this.isOpen = false;
        this.statementType = 0;
        this.columnSetNull = false;
        this.defaultTimeZone = null;
        this.defaultTimeZoneName = null;
        this.defaultCalendar = null;
        this.gmtCalendar = null;
        this.m_batchItems = new Vector();
        this.tempClobsToFree = null;
        this.tempBlobsToFree = null;
        this.oldTempClobsToFree = null;
        this.oldTempBlobsToFree = null;
        this.registration = null;
        this.dcnTableName = null;
        this.dcnQueryId = -1L;
        (this.connection = connection).needLine();
        this.connection.registerHeartbeat();
        this.connection.addStatement(this);
        this.sqlObject = new OracleSql(this.connection.conversion);
        this.processEscapes = this.connection.processEscapes;
        this.convertNcharLiterals = this.connection.convertNcharLiterals;
        this.autoRollback = 2;
        this.gotLastBatch = false;
        this.closed = false;
        this.clearParameters = true;
        this.serverCursor = false;
        this.needToAddIdentifier = false;
        this.defaultFetchDirection = 1000;
        this.fixedString = this.connection.getDefaultFixedString();
        this.rowPrefetchChanged = false;
        this.rowPrefetch = n;
        this.defaultRowPrefetch = n;
        if (this.connection.getVersionNumber() >= 11000) {
            this.defaultLobPrefetchSize = this.connection.defaultLobPrefetchSize;
        }
        else {
            this.defaultLobPrefetchSize = -1;
        }
        this.batch = batch;
        this.sqlStringChanged = true;
        this.needToParse = true;
        this.needToPrepareDefineBuffer = true;
        this.columnsDefinedByUser = false;
        if (n2 != -1 || n3 != -1) {
            this.realRsetType = 0;
            this.userRsetType = ResultSetUtil.getRsetTypeCode(n2, n3);
            this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType);
        }
        else {
            this.userRsetType = 1;
            this.realRsetType = 1;
        }
    }
    
    void initializeDefineSubRanges() {
        this.defineByteSubRange = 0;
        this.defineCharSubRange = 0;
        this.defineIndicatorSubRange = 0;
        this.defineMetaDataSubRange = 0;
    }
    
    void prepareDefinePreambles() {
    }
    
    void prepareAccessors() throws SQLException {
        byte[] array = null;
        char[] array2 = null;
        short[] array3 = null;
        boolean b = false;
        if (this.accessors == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        for (int i = 0; i < this.numberOfDefinePositions; ++i) {
            final Accessor accessor = this.accessors[i];
            if (accessor == null) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            switch (accessor.internalType) {
                case 8:
                case 24: {
                    this.hasStream = true;
                    break;
                }
            }
            n += accessor.byteLength;
            n2 += accessor.charLength;
            ++n3;
        }
        if (this.streamList != null && !this.connection.useFetchSizeWithLongColumn) {
            this.rowPrefetch = 1;
        }
        final int rowPrefetch = this.rowPrefetch;
        this.definesBatchSize = rowPrefetch;
        this.initializeDefineSubRanges();
        final int n4 = n3 * rowPrefetch;
        if (this.defineMetaData == null || this.defineMetaData.length < n4) {
            if (this.defineMetaData != null) {
                final byte[] defineMetaData = this.defineMetaData;
            }
            this.defineMetaData = new byte[n4];
        }
        this.cachedDefineByteSize = this.defineByteSubRange + n * rowPrefetch;
        if (this.defineBytes == null || this.defineBytes.length < this.cachedDefineByteSize) {
            if (this.defineBytes != null) {
                array = this.defineBytes;
            }
            this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
        }
        this.defineByteSubRange += this.accessorByteOffset;
        this.cachedDefineCharSize = this.defineCharSubRange + n2 * rowPrefetch;
        if ((this.defineChars == null || this.defineChars.length < this.cachedDefineCharSize) && this.cachedDefineCharSize > 0) {
            if (this.defineChars != null) {
                array2 = this.defineChars;
            }
            this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
        }
        this.defineCharSubRange += this.accessorCharOffset;
        final int n5 = this.numberOfDefinePositions * rowPrefetch;
        final int n6 = this.defineIndicatorSubRange + n5 + n5;
        if (this.defineIndicators == null || this.defineIndicators.length < n6) {
            if (this.defineIndicators != null) {
                array3 = this.defineIndicators;
            }
            this.defineIndicators = new short[n6];
        }
        else if (this.defineIndicators.length >= n6) {
            b = true;
            array3 = this.defineIndicators;
        }
        this.defineIndicatorSubRange += this.accessorShortOffset;
        int lengthIndex = this.defineIndicatorSubRange + n5;
        for (int j = 0; j < this.numberOfDefinePositions; ++j) {
            final Accessor accessor2 = this.accessors[j];
            accessor2.lengthIndexLastRow = accessor2.lengthIndex;
            accessor2.indicatorIndexLastRow = accessor2.indicatorIndex;
            accessor2.columnIndexLastRow = accessor2.columnIndex;
            accessor2.setOffsets(rowPrefetch);
            accessor2.lengthIndex = lengthIndex;
            accessor2.indicatorIndex = this.defineIndicatorSubRange;
            accessor2.metaDataIndex = this.defineMetaDataSubRange;
            accessor2.rowSpaceByte = this.defineBytes;
            accessor2.rowSpaceChar = this.defineChars;
            accessor2.rowSpaceIndicator = this.defineIndicators;
            accessor2.rowSpaceMetaData = this.defineMetaData;
            this.defineIndicatorSubRange += rowPrefetch;
            lengthIndex += rowPrefetch;
            this.defineMetaDataSubRange += rowPrefetch * 1;
        }
        this.prepareDefinePreambles();
        if (this.rowPrefetchInLastFetch != -1 && this.rowPrefetch != this.rowPrefetchInLastFetch) {
            if (array2 == null) {
                array2 = this.defineChars;
            }
            if (array == null) {
                array = this.defineBytes;
            }
            if (array3 == null) {
                array3 = this.defineIndicators;
            }
            this.saveDefineBuffersIfRequired(array2, array, array3, b);
        }
    }
    
    boolean checkAccessorsUsable() throws SQLException {
        if (this.accessors.length < this.numberOfDefinePositions) {
            return false;
        }
        boolean b = true;
        boolean b2 = false;
        boolean b3 = false;
        for (int i = 0; i < this.numberOfDefinePositions; ++i) {
            final Accessor accessor = this.accessors[i];
            if (accessor == null || accessor.externalType == 0) {
                b = false;
            }
            else {
                b2 = true;
            }
        }
        if (b) {
            b3 = true;
        }
        else {
            if (b2) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.columnsDefinedByUser = false;
        }
        return b3;
    }
    
    void executeMaybeDescribe() throws SQLException {
        boolean b = true;
        if (this.rowPrefetchChanged) {
            if (this.streamList == null && this.rowPrefetch != this.definesBatchSize) {
                this.needToPrepareDefineBuffer = true;
            }
            this.rowPrefetchChanged = false;
        }
        if (!this.needToPrepareDefineBuffer) {
            if (this.accessors == null) {
                this.needToPrepareDefineBuffer = true;
            }
            else if (this.columnsDefinedByUser) {
                this.needToPrepareDefineBuffer = !this.checkAccessorsUsable();
            }
        }
        boolean b2 = false;
        try {
            this.isExecuting = true;
            if (this.needToPrepareDefineBuffer) {
                if (!this.columnsDefinedByUser) {
                    this.executeForDescribe();
                    b2 = true;
                    if (this.aFetchWasDoneDuringDescribe) {
                        b = false;
                    }
                }
                if (this.needToPrepareDefineBuffer) {
                    this.prepareAccessors();
                }
            }
            for (int length = this.accessors.length, i = this.numberOfDefinePositions; i < length; ++i) {
                final Accessor accessor = this.accessors[i];
                if (accessor != null) {
                    accessor.rowSpaceIndicator = null;
                }
            }
            if (b) {
                this.executeForRows(b2);
            }
        }
        catch (SQLException ex) {
            this.needToParse = true;
            throw ex;
        }
        finally {
            this.isExecuting = false;
        }
    }
    
    void adjustGotLastBatch() {
    }
    
    void doExecuteWithTimeout() throws SQLException {
        try {
            this.cleanOldTempLobs();
            this.connection.registerHeartbeat();
            this.rowsProcessed = 0;
            if (this.sqlKind == 1) {
                if (this.connection.j2ee13Compliant && this.executionType == 2) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 129);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.connection.needLine();
                if (!this.isOpen) {
                    this.connection.open(this);
                    this.isOpen = true;
                }
                if (this.queryTimeout != 0) {
                    try {
                        this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
                        this.executeMaybeDescribe();
                    }
                    finally {
                        this.connection.getTimeout().cancelTimeout();
                    }
                }
                else {
                    this.executeMaybeDescribe();
                }
                this.checkValidRowsStatus();
                if (this.serverCursor) {
                    this.adjustGotLastBatch();
                }
            }
            else {
                if (this.connection.j2ee13Compliant && (this.sqlKind & 0x60) == 0x0 && this.executionType == 1) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 128);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                ++this.currentRank;
                if (this.currentRank >= this.batch) {
                    try {
                        this.connection.needLine();
                        if (!this.isOpen) {
                            this.connection.open(this);
                            this.isOpen = true;
                        }
                        if (this.queryTimeout != 0) {
                            this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
                        }
                        this.isExecuting = true;
                        this.executeForRows(false);
                    }
                    catch (SQLException ex) {
                        this.needToParse = true;
                        if (this.batch > 1) {
                            this.clearBatch();
                            int[] array;
                            if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch < this.batch) {
                                array = new int[this.numberOfExecutedElementsInBatch];
                                for (int i = 0; i < array.length; ++i) {
                                    array[i] = -2;
                                }
                            }
                            else {
                                array = new int[this.batch];
                                for (int j = 0; j < array.length; ++j) {
                                    array[j] = -3;
                                }
                            }
                            final BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(ex, array.length, array);
                            batchUpdateException.fillInStackTrace();
                            throw batchUpdateException;
                        }
                        this.resetCurrentRowBinders();
                        throw ex;
                    }
                    finally {
                        if (this.queryTimeout != 0) {
                            this.connection.getTimeout().cancelTimeout();
                        }
                        this.currentRank = 0;
                        this.isExecuting = false;
                        this.checkValidRowsStatus();
                    }
                }
            }
        }
        catch (SQLException ex2) {
            this.resetOnExceptionDuringExecute();
            throw ex2;
        }
        this.connection.registerHeartbeat();
    }
    
    void resetOnExceptionDuringExecute() {
        this.needToParse = true;
    }
    
    void resetCurrentRowBinders() {
    }
    
    void open() throws SQLException {
        if (!this.isOpen) {
            this.connection.needLine();
            this.connection.open(this);
            this.isOpen = true;
        }
    }
    
    @Override
    public ResultSet executeQuery(final String s) throws SQLException {
        synchronized (this.connection) {
            ResultSet set = null;
            try {
                this.executionType = 1;
                this.noMoreUpdateCounts = false;
                this.ensureOpen();
                this.checkIfJdbcBatchExists();
                this.sendBatch();
                this.hasStream = false;
                this.sqlObject.initialize(s);
                this.sqlKind = this.sqlObject.getSqlKind();
                this.prepareForNewResults(this.needToParse = true, true);
                if (this.userRsetType == 1) {
                    this.doExecuteWithTimeout();
                    this.currentResultSet = new OracleResultSetImpl(this.connection, this);
                    set = this.currentResultSet;
                }
                else {
                    set = this.doScrollStmtExecuteQuery();
                    if (set == null) {
                        this.currentResultSet = new OracleResultSetImpl(this.connection, this);
                        set = this.currentResultSet;
                    }
                }
            }
            finally {
                this.executionType = -1;
            }
            return set;
        }
    }
    
    @Override
    public void closeWithKey(final String s) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void close() throws SQLException {
        synchronized (this.connection) {
            this.closeOrCache(null);
        }
    }
    
    protected void closeOrCache(final String s) throws SQLException {
        if (this.closed) {
            return;
        }
        if (this.statementType != 0 && this.cacheState != 0 && this.cacheState != 3 && this.connection.isStatementCacheInitialized()) {
            if (s == null) {
                if (this.connection.getImplicitCachingEnabled()) {
                    this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);
                }
                else {
                    this.cacheState = 0;
                    this.hardClose();
                }
            }
            else if (this.connection.getExplicitCachingEnabled()) {
                this.connection.cacheExplicitStatement((OraclePreparedStatement)this, s);
            }
            else {
                this.cacheState = 0;
                this.hardClose();
            }
        }
        else {
            this.hardClose();
        }
    }
    
    protected void hardClose() throws SQLException {
        this.hardClose(true);
    }
    
    private void hardClose(final boolean b) throws SQLException {
        this.alwaysOnClose();
        this.describedWithNames = false;
        this.described = false;
        this.connection.removeStatement(this);
        this.cleanupDefines();
        if (this.isOpen && b && (this.connection.lifecycle == 1 || this.connection.lifecycle == 16 || this.connection.lifecycle == 2)) {
            this.connection.registerHeartbeat();
            if (this.connection.lifecycle == 2) {
                this.connection.needLineUnchecked();
            }
            else {
                this.connection.needLine();
            }
            this.doClose();
            this.isOpen = false;
        }
        this.sqlObject = null;
    }
    
    protected void alwaysOnClose() throws SQLException {
        OracleStatement nextChild;
        for (OracleStatement children = this.children; children != null; children = nextChild) {
            nextChild = children.nextChild;
            children.close();
        }
        if (this.parent != null) {
            this.parent.removeChild(this);
        }
        this.closed = true;
        if (this.connection.lifecycle == 1 || this.connection.lifecycle == 2) {
            if (this.currentResultSet != null) {
                this.currentResultSet.internal_close(false);
                this.currentResultSet = null;
            }
            if (this.scrollRset != null) {
                this.scrollRset.close();
                this.scrollRset = null;
            }
            if (this.returnResultSet != null) {
                this.returnResultSet.close();
                this.returnResultSet = null;
            }
        }
        this.clearWarnings();
        this.m_batchItems = null;
    }
    
    void closeLeaveCursorOpen() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                return;
            }
            this.hardClose(false);
        }
    }
    
    @Override
    public int executeUpdate(final String s) throws SQLException {
        synchronized (this.connection) {
            this.setNonAutoKey();
            return this.executeUpdateInternal(s);
        }
    }
    
    int executeUpdateInternal(final String s) throws SQLException {
        try {
            if (this.executionType == -1) {
                this.executionType = 2;
            }
            this.noMoreUpdateCounts = false;
            this.ensureOpen();
            this.checkIfJdbcBatchExists();
            this.sendBatch();
            this.hasStream = false;
            this.sqlObject.initialize(s);
            this.sqlKind = this.sqlObject.getSqlKind();
            this.prepareForNewResults(this.needToParse = true, true);
            if (this.userRsetType == 1) {
                this.doExecuteWithTimeout();
            }
            else {
                this.doScrollStmtExecuteQuery();
            }
            return this.validRows;
        }
        finally {
            this.executionType = -1;
        }
    }
    
    @Override
    public boolean execute(final String s) throws SQLException {
        synchronized (this.connection) {
            this.setNonAutoKey();
            return this.executeInternal(s);
        }
    }
    
    boolean executeInternal(final String s) throws SQLException {
        try {
            this.executionType = 3;
            this.noMoreUpdateCounts = false;
            this.ensureOpen();
            this.checkIfJdbcBatchExists();
            this.sendBatch();
            this.hasStream = false;
            this.sqlObject.initialize(s);
            this.sqlKind = this.sqlObject.getSqlKind();
            this.prepareForNewResults(this.needToParse = true, true);
            if (this.userRsetType == 1) {
                this.doExecuteWithTimeout();
            }
            else {
                this.doScrollStmtExecuteQuery();
            }
            return this.sqlKind == 1;
        }
        finally {
            this.executionType = -1;
        }
    }
    
    int getNumberOfColumns() throws SQLException {
        this.ensureOpen();
        if (!this.described) {
            synchronized (this.connection) {
                this.doDescribe(false);
                this.described = true;
            }
        }
        return this.numberOfDefinePositions;
    }
    
    Accessor[] getDescription() throws SQLException {
        this.ensureOpen();
        if (!this.described) {
            synchronized (this.connection) {
                this.doDescribe(false);
                this.described = true;
            }
        }
        return this.accessors;
    }
    
    Accessor[] getDescriptionWithNames() throws SQLException {
        this.ensureOpen();
        if (!this.describedWithNames) {
            synchronized (this.connection) {
                this.doDescribe(true);
                this.described = true;
                this.describedWithNames = true;
            }
        }
        return this.accessors;
    }
    
    byte getSqlKind() {
        return this.sqlKind;
    }
    
    @Override
    public void clearDefines() throws SQLException {
        synchronized (this.connection) {
            this.freeLine();
            this.streamList = null;
            this.columnsDefinedByUser = false;
            this.needToPrepareDefineBuffer = true;
            this.numberOfDefinePositions = 0;
            this.definesBatchSize = 0;
            this.described = false;
            this.describedWithNames = false;
            this.cleanupDefines();
        }
    }
    
    void reparseOnRedefineIfNeeded() throws SQLException {
    }
    
    void defineColumnTypeInternal(final int n, final int n2, final int n3, final boolean b, final String s) throws SQLException {
        this.defineColumnTypeInternal(n, n2, n3, (short)1, b, s);
    }
    
    void defineColumnTypeInternal(final int numberOfDefinePositions, final int n, final int n2, short formOfUse, final boolean b, String s) throws SQLException {
        if (this.connection.disableDefinecolumntype) {
            return;
        }
        if (numberOfDefinePositions < 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n == 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final int n3 = numberOfDefinePositions - 1;
        int n4 = (this.maxFieldSize > 0) ? this.maxFieldSize : -1;
        if (b) {
            if (n == 1 || n == 12) {
                this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
            }
        }
        else {
            if (n2 < 0) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 53);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            if ((n4 == -1 && n2 > 0) || (n4 > 0 && n2 < n4)) {
                n4 = n2;
            }
        }
        if (this.currentResultSet != null && !this.currentResultSet.closed) {
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 28);
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        if (!this.columnsDefinedByUser) {
            this.clearDefines();
            this.columnsDefinedByUser = true;
        }
        if (this.numberOfDefinePositions < numberOfDefinePositions) {
            if (this.accessors == null || this.accessors.length < numberOfDefinePositions) {
                final Accessor[] accessors = new Accessor[numberOfDefinePositions << 1];
                if (this.accessors != null) {
                    System.arraycopy(this.accessors, 0, accessors, 0, this.numberOfDefinePositions);
                }
                this.accessors = accessors;
            }
            this.numberOfDefinePositions = numberOfDefinePositions;
        }
        switch (n) {
            case -16:
            case -15:
            case -9:
            case 2011: {
                formOfUse = 2;
                break;
            }
            case 2009: {
                s = "SYS.XMLTYPE";
                break;
            }
        }
        final int internalType = this.getInternalType(n);
        if ((internalType == 109 || internalType == 111) && (s == null || s.equals(""))) {
            final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
            sqlException5.fillInStackTrace();
            throw sqlException5;
        }
        Accessor accessor = this.accessors[n3];
        boolean b2 = true;
        if (accessor != null) {
            final int useForDataAccessIfPossible = accessor.useForDataAccessIfPossible(internalType, n, n4, s);
            if (useForDataAccessIfPossible == 0) {
                formOfUse = accessor.formOfUse;
                accessor = null;
                this.reparseOnRedefineIfNeeded();
            }
            else if (useForDataAccessIfPossible == 1) {
                accessor = null;
                this.reparseOnRedefineIfNeeded();
            }
            else if (useForDataAccessIfPossible == 2) {
                b2 = false;
            }
        }
        if (b2) {
            this.needToPrepareDefineBuffer = true;
        }
        if (accessor == null) {
            this.accessors[n3] = this.allocateAccessor(internalType, n, numberOfDefinePositions, n4, formOfUse, s, false);
            this.described = false;
            this.describedWithNames = false;
        }
    }
    
    Accessor allocateAccessor(final int n, final int n2, final int n3, final int n4, final short n5, final String s, final boolean b) throws SQLException {
        switch (n) {
            case 96: {
                if (b && s != null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                return new CharAccessor(this, n4, n5, n2, b);
            }
            case 8: {
                if (b && s != null) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                if (!b) {
                    return new LongAccessor(this, n3, n4, n5, n2);
                }
            }
            case 1: {
                if (b && s != null) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                return new VarcharAccessor(this, n4, n5, n2, b);
            }
            case 2: {
                if (b && s != null) {
                    final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException4.fillInStackTrace();
                    throw sqlException4;
                }
                return new NumberAccessor(this, n4, n5, n2, b);
            }
            case 6: {
                if (b && s != null) {
                    final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException5.fillInStackTrace();
                    throw sqlException5;
                }
                return new VarnumAccessor(this, n4, n5, n2, b);
            }
            case 24: {
                if (b && s != null) {
                    final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException6.fillInStackTrace();
                    throw sqlException6;
                }
                if (!b) {
                    return new LongRawAccessor(this, n3, n4, n5, n2);
                }
            }
            case 23: {
                if (b && s != null) {
                    final SQLException sqlException7 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException7.fillInStackTrace();
                    throw sqlException7;
                }
                if (b) {
                    return new OutRawAccessor(this, n4, n5, n2);
                }
                return new RawAccessor(this, n4, n5, n2, false);
            }
            case 100: {
                if (b && s != null) {
                    final SQLException sqlException8 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException8.fillInStackTrace();
                    throw sqlException8;
                }
                return new BinaryFloatAccessor(this, n4, n5, n2, b);
            }
            case 101: {
                if (b && s != null) {
                    final SQLException sqlException9 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException9.fillInStackTrace();
                    throw sqlException9;
                }
                return new BinaryDoubleAccessor(this, n4, n5, n2, b);
            }
            case 104: {
                if (b && s != null) {
                    final SQLException sqlException10 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException10.fillInStackTrace();
                    throw sqlException10;
                }
                return new RowidAccessor(this, n4, n5, n2, b);
            }
            case 102: {
                if (b && s != null) {
                    final SQLException sqlException11 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException11.fillInStackTrace();
                    throw sqlException11;
                }
                return new ResultSetAccessor(this, n4, n5, n2, b);
            }
            case 12: {
                if (b && s != null) {
                    final SQLException sqlException12 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException12.fillInStackTrace();
                    throw sqlException12;
                }
                return new DateAccessor(this, n4, n5, n2, b);
            }
            case 113: {
                if (b && s != null) {
                    final SQLException sqlException13 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException13.fillInStackTrace();
                    throw sqlException13;
                }
                final BlobAccessor blobAccessor = new BlobAccessor(this, -1, n5, n2, b);
                if (!b) {
                    blobAccessor.lobPrefetchSizeForThisColumn = n4;
                }
                return blobAccessor;
            }
            case 112: {
                if (b && s != null) {
                    final SQLException sqlException14 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException14.fillInStackTrace();
                    throw sqlException14;
                }
                final ClobAccessor clobAccessor = new ClobAccessor(this, -1, n5, n2, b);
                if (!b) {
                    clobAccessor.lobPrefetchSizeForThisColumn = n4;
                }
                return clobAccessor;
            }
            case 114: {
                if (b && s != null) {
                    final SQLException sqlException15 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException15.fillInStackTrace();
                    throw sqlException15;
                }
                return new BfileAccessor(this, -1, n5, n2, b);
            }
            case 109: {
                if (s != null) {
                    final NamedTypeAccessor namedTypeAccessor = new NamedTypeAccessor(this, s, n5, n2, b);
                    namedTypeAccessor.initMetadata();
                    return namedTypeAccessor;
                }
                if (b) {
                    final SQLException sqlException16 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException16.fillInStackTrace();
                    throw sqlException16;
                }
                final SQLException sqlException17 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
                sqlException17.fillInStackTrace();
                throw sqlException17;
            }
            case 111: {
                if (s != null) {
                    final RefTypeAccessor refTypeAccessor = new RefTypeAccessor(this, s, n5, n2, b);
                    refTypeAccessor.initMetadata();
                    return refTypeAccessor;
                }
                if (b) {
                    final SQLException sqlException18 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException18.fillInStackTrace();
                    throw sqlException18;
                }
                final SQLException sqlException19 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
                sqlException19.fillInStackTrace();
                throw sqlException19;
            }
            case 180: {
                if (b && s != null) {
                    final SQLException sqlException20 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException20.fillInStackTrace();
                    throw sqlException20;
                }
                return new TimestampAccessor(this, n4, n5, n2, b);
            }
            case 181: {
                if (b && s != null) {
                    final SQLException sqlException21 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException21.fillInStackTrace();
                    throw sqlException21;
                }
                return new TimestamptzAccessor(this, n4, n5, n2, b);
            }
            case 231: {
                if (b && s != null) {
                    final SQLException sqlException22 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException22.fillInStackTrace();
                    throw sqlException22;
                }
                return new TimestampltzAccessor(this, n4, n5, n2, b);
            }
            case 182: {
                if (b && s != null) {
                    final SQLException sqlException23 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException23.fillInStackTrace();
                    throw sqlException23;
                }
                return new IntervalymAccessor(this, n4, n5, n2, b);
            }
            case 183: {
                if (b && s != null) {
                    final SQLException sqlException24 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 12, "sqlType=" + n2);
                    sqlException24.fillInStackTrace();
                    throw sqlException24;
                }
                return new IntervaldsAccessor(this, n4, n5, n2, b);
            }
            case 995: {
                final SQLException sqlException25 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89);
                sqlException25.fillInStackTrace();
                throw sqlException25;
            }
            default: {
                final SQLException sqlException26 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException26.fillInStackTrace();
                throw sqlException26;
            }
        }
    }
    
    @Override
    public void defineColumnType(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.defineColumnTypeInternal(n, n2, -1, true, null);
        }
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final int n3) throws SQLException {
        this.defineColumnTypeInternal(n, n2, n3, false, null);
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final int n3, final short n4) throws SQLException {
        this.defineColumnTypeInternal(n, n2, n3, n4, false, null);
    }
    
    @Override
    @Deprecated
    public void defineColumnTypeBytes(final int n, final int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            this.defineColumnTypeInternal(n, n2, n3, false, null);
        }
    }
    
    @Override
    @Deprecated
    public void defineColumnTypeChars(final int n, final int n2, final int n3) throws SQLException {
        this.defineColumnTypeInternal(n, n2, n3, false, null);
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final String s) throws SQLException {
        synchronized (this.connection) {
            this.defineColumnTypeInternal(n, n2, -1, true, s);
        }
    }
    
    void setCursorId(final int cursorId) throws SQLException {
        this.cursorId = cursorId;
    }
    
    void setPrefetchInternal(int defaultRowPrefetch, final boolean b, final boolean b2) throws SQLException {
        if (b) {
            if (defaultRowPrefetch <= 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 20);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        else {
            if (defaultRowPrefetch < 0) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "setFetchSize");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (defaultRowPrefetch == 0) {
                defaultRowPrefetch = this.connection.getDefaultRowPrefetch();
            }
        }
        if (b2) {
            if (defaultRowPrefetch != this.defaultRowPrefetch) {
                this.defaultRowPrefetch = defaultRowPrefetch;
                if (this.currentResultSet == null || this.currentResultSet.closed) {
                    this.rowPrefetchChanged = true;
                }
            }
        }
        else if (defaultRowPrefetch != this.rowPrefetch && this.streamList == null) {
            this.rowPrefetch = defaultRowPrefetch;
            this.rowPrefetchChanged = true;
        }
    }
    
    @Override
    public void setRowPrefetch(final int n) throws SQLException {
        synchronized (this.connection) {
            this.setPrefetchInternal(n, true, true);
        }
    }
    
    @Override
    public void setLobPrefetchSize(final int defaultLobPrefetchSize) throws SQLException {
        synchronized (this.connection) {
            if (defaultLobPrefetchSize < -1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 267);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.defaultLobPrefetchSize = defaultLobPrefetchSize;
        }
    }
    
    @Override
    public int getLobPrefetchSize() {
        return this.defaultLobPrefetchSize;
    }
    
    int getPrefetchInternal(final boolean b) {
        return b ? this.defaultRowPrefetch : this.rowPrefetch;
    }
    
    @Override
    public int getRowPrefetch() {
        synchronized (this.connection) {
            return this.getPrefetchInternal(true);
        }
    }
    
    @Override
    public void setFixedString(final boolean fixedString) {
        this.fixedString = fixedString;
    }
    
    @Override
    public boolean getFixedString() {
        return this.fixedString;
    }
    
    void check_row_prefetch_changed() throws SQLException {
        if (this.rowPrefetchChanged) {
            if (this.streamList == null) {
                this.prepareAccessors();
                this.needToPrepareDefineBuffer = true;
            }
            this.rowPrefetchChanged = false;
        }
    }
    
    void setDefinesInitialized(final boolean b) {
    }
    
    void printState(final String s) throws SQLException {
    }
    
    void checkValidRowsStatus() throws SQLException {
        if (this.validRows == -2) {
            this.validRows = 1;
            this.connection.holdLine(this);
            for (OracleInputStream oracleInputStream = this.streamList; oracleInputStream != null; oracleInputStream = oracleInputStream.nextStream) {
                if (oracleInputStream.hasBeenOpen) {
                    oracleInputStream = oracleInputStream.accessor.initForNewRow();
                }
                oracleInputStream.closed = false;
                oracleInputStream.hasBeenOpen = true;
            }
            this.nextStream = this.streamList;
        }
        else if (this.sqlKind == 1) {
            if (this.validRows < this.rowPrefetch) {
                this.gotLastBatch = true;
            }
        }
        else if ((this.sqlKind & 0x60) == 0x0) {
            this.rowsProcessed = this.validRows;
        }
    }
    
    void cleanupDefines() {
        if (this.accessors != null) {
            for (int i = 0; i < this.accessors.length; ++i) {
                this.accessors[i] = null;
            }
        }
        this.accessors = null;
        this.connection.cacheBuffer(this.defineBytes);
        this.defineBytes = null;
        this.connection.cacheBuffer(this.defineChars);
        this.defineChars = null;
        this.defineIndicators = null;
        this.defineMetaData = null;
    }
    
    @Override
    public int getMaxFieldSize() throws SQLException {
        synchronized (this.connection) {
            return this.maxFieldSize;
        }
    }
    
    @Override
    public void setMaxFieldSize(final int maxFieldSize) throws SQLException {
        synchronized (this.connection) {
            if (maxFieldSize < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.maxFieldSize = maxFieldSize;
        }
    }
    
    @Override
    public int getMaxRows() throws SQLException {
        return this.maxRows;
    }
    
    @Override
    public void setMaxRows(final int maxRows) throws SQLException {
        synchronized (this.connection) {
            if (maxRows < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.maxRows = maxRows;
        }
    }
    
    @Override
    public void setEscapeProcessing(final boolean processEscapes) throws SQLException {
        synchronized (this.connection) {
            this.processEscapes = processEscapes;
        }
    }
    
    @Override
    public int getQueryTimeout() throws SQLException {
        synchronized (this.connection) {
            return this.queryTimeout;
        }
    }
    
    @Override
    public void setQueryTimeout(final int queryTimeout) throws SQLException {
        synchronized (this.connection) {
            if (queryTimeout < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.queryTimeout = queryTimeout;
        }
    }
    
    @Override
    public void cancel() throws SQLException {
        this.doCancel();
    }
    
    boolean doCancel() throws SQLException {
        boolean b = false;
        if (this.closed) {
            return b;
        }
        if (this.connection.statementHoldingLine != null) {
            this.freeLine();
        }
        else if (this.isExecuting) {
            b = true;
            this.connection.cancelOperationOnServer();
        }
        for (OracleStatement oracleStatement = this.children; oracleStatement != null; oracleStatement = oracleStatement.nextChild) {
            b = (b || oracleStatement.doCancel());
        }
        this.connection.releaseLineForCancel();
        return b;
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return this.sqlWarning;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        this.sqlWarning = null;
    }
    
    void foundPlsqlCompilerWarning() throws SQLException {
        final SQLWarning addSqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, "Found Plsql compiler warnings.", 24439);
        if (this.sqlWarning != null) {
            this.sqlWarning.setNextWarning(addSqlWarning);
        }
        else {
            this.sqlWarning = addSqlWarning;
        }
    }
    
    @Override
    public void setCursorName(final String s) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public ResultSet getResultSet() throws SQLException {
        synchronized (this.connection) {
            if (this.userRsetType != 1) {
                return this.scrollRset;
            }
            if (this.sqlKind == 1) {
                if (this.currentResultSet == null) {
                    this.currentResultSet = new OracleResultSetImpl(this.connection, this);
                }
                return this.currentResultSet;
            }
            return null;
        }
    }
    
    @Override
    public int getUpdateCount() throws SQLException {
        synchronized (this.connection) {
            int n = -1;
            switch (this.sqlKind) {
                case Byte.MIN_VALUE: {
                    if (!this.noMoreUpdateCounts) {
                        n = this.rowsProcessed;
                    }
                    this.noMoreUpdateCounts = true;
                    break;
                }
                case 32:
                case 64: {
                    this.noMoreUpdateCounts = true;
                    break;
                }
                case 2:
                case 4:
                case 8:
                case 16: {
                    if (!this.noMoreUpdateCounts) {
                        n = this.rowsProcessed;
                    }
                    this.noMoreUpdateCounts = true;
                    break;
                }
            }
            return n;
        }
    }
    
    @Override
    public boolean getMoreResults() throws SQLException {
        return false;
    }
    
    @Override
    public int sendBatch() throws SQLException {
        return 0;
    }
    
    void prepareForNewResults(final boolean b, final boolean b2) throws SQLException {
        this.clearWarnings();
        if (this.streamList != null) {
            while (this.nextStream != null) {
                try {
                    this.nextStream.close();
                }
                catch (IOException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.nextStream = this.nextStream.nextStream;
            }
            if (b2) {
                OracleInputStream oracleInputStream = this.streamList;
                OracleInputStream oracleInputStream2 = null;
                this.streamList = null;
                while (oracleInputStream != null) {
                    if (!oracleInputStream.hasBeenOpen) {
                        if (oracleInputStream2 == null) {
                            this.streamList = oracleInputStream;
                        }
                        else {
                            oracleInputStream2.nextStream = oracleInputStream;
                        }
                        oracleInputStream2 = oracleInputStream;
                    }
                    oracleInputStream = oracleInputStream.nextStream;
                }
            }
        }
        if (this.currentResultSet != null) {
            this.currentResultSet.internal_close(true);
            this.currentResultSet = null;
        }
        this.currentRow = -1;
        this.validRows = 0;
        if (b) {
            this.totalRowsVisited = 0;
        }
        this.gotLastBatch = false;
        if (this.needToParse && !this.columnsDefinedByUser) {
            if (b2 && this.numberOfDefinePositions != 0) {
                this.numberOfDefinePositions = 0;
            }
            this.needToPrepareDefineBuffer = true;
        }
        if (b && this.rowPrefetch != this.defaultRowPrefetch && this.streamList == null) {
            this.rowPrefetch = this.defaultRowPrefetch;
            this.rowPrefetchChanged = true;
        }
    }
    
    void reopenStreams() throws SQLException {
        for (OracleInputStream oracleInputStream = this.streamList; oracleInputStream != null; oracleInputStream = oracleInputStream.nextStream) {
            if (oracleInputStream.hasBeenOpen) {
                oracleInputStream = oracleInputStream.accessor.initForNewRow();
            }
            oracleInputStream.closed = false;
            oracleInputStream.hasBeenOpen = true;
        }
        this.nextStream = this.streamList;
    }
    
    void endOfResultSet(final boolean b) throws SQLException {
        if (!b) {
            this.prepareForNewResults(false, false);
        }
        this.clearDefines();
        this.rowPrefetchInLastFetch = -1;
    }
    
    boolean wasNullValue() throws SQLException {
        if (this.lastIndex == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 24);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.sqlKind == 1) {
            return this.accessors[this.lastIndex - 1].isNull(this.currentRow);
        }
        return this.outBindAccessors[this.lastIndex - 1].isNull(this.currentRank);
    }
    
    int getColumnIndex(final String anotherString) throws SQLException {
        this.ensureOpen();
        if (!this.describedWithNames) {
            synchronized (this.connection) {
                this.doDescribe(true);
                this.described = true;
                this.describedWithNames = true;
            }
        }
        for (int i = 0; i < this.numberOfDefinePositions; ++i) {
            if (this.accessors[i].columnName.equalsIgnoreCase(anotherString)) {
                return i + 1;
            }
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    int getJDBCType(final int n) throws SQLException {
        int n2 = 0;
        switch (n) {
            case 6: {
                n2 = 2;
                break;
            }
            case 100: {
                n2 = 100;
                break;
            }
            case 101: {
                n2 = 101;
                break;
            }
            case 999: {
                n2 = 999;
                break;
            }
            case 96: {
                n2 = 1;
                break;
            }
            case 1: {
                n2 = 12;
                break;
            }
            case 8: {
                n2 = -1;
                break;
            }
            case 12: {
                n2 = 91;
                break;
            }
            case 180: {
                n2 = 93;
                break;
            }
            case 181: {
                n2 = -101;
                break;
            }
            case 231: {
                n2 = -102;
                break;
            }
            case 182: {
                n2 = -103;
                break;
            }
            case 183: {
                n2 = -104;
                break;
            }
            case 23: {
                n2 = -2;
                break;
            }
            case 24: {
                n2 = -4;
                break;
            }
            case 104: {
                n2 = -8;
                break;
            }
            case 113: {
                n2 = 2004;
                break;
            }
            case 112: {
                n2 = 2005;
                break;
            }
            case 114: {
                n2 = -13;
                break;
            }
            case 102: {
                n2 = -10;
                break;
            }
            case 109: {
                n2 = 2002;
                break;
            }
            case 111: {
                n2 = 2006;
                break;
            }
            case 998: {
                n2 = -14;
                break;
            }
            case 995: {
                n2 = 0;
                break;
            }
            default: {
                n2 = n;
                break;
            }
        }
        return n2;
    }
    
    int getInternalType(final int i) throws SQLException {
        int n = 0;
        switch (i) {
            case -7:
            case -6:
            case -5:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8: {
                n = 6;
                break;
            }
            case 100: {
                n = 100;
                break;
            }
            case 101: {
                n = 101;
                break;
            }
            case 999: {
                n = 999;
                break;
            }
            case 1: {
                n = 96;
                break;
            }
            case -15:
            case -9:
            case 12: {
                n = 1;
                break;
            }
            case -16:
            case -1: {
                n = 8;
                break;
            }
            case 91:
            case 92: {
                n = 12;
                break;
            }
            case -100:
            case 93: {
                n = 180;
                break;
            }
            case -101: {
                n = 181;
                break;
            }
            case -102: {
                n = 231;
                break;
            }
            case -103: {
                n = 182;
                break;
            }
            case -104: {
                n = 183;
                break;
            }
            case -3:
            case -2: {
                n = 23;
                break;
            }
            case -4: {
                n = 24;
                break;
            }
            case -8: {
                n = 104;
                break;
            }
            case 2004: {
                n = 113;
                break;
            }
            case 2005:
            case 2011: {
                n = 112;
                break;
            }
            case -13: {
                n = 114;
                break;
            }
            case -10: {
                n = 102;
                break;
            }
            case 2002:
            case 2003:
            case 2007:
            case 2008:
            case 2009: {
                n = 109;
                break;
            }
            case 2006: {
                n = 111;
                break;
            }
            case -14: {
                n = 998;
                break;
            }
            case 70: {
                n = 1;
                break;
            }
            case 0: {
                n = 995;
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, Integer.toString(i));
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return n;
    }
    
    void describe() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (!this.described) {
                this.doDescribe(false);
            }
        }
    }
    
    void freeLine() throws SQLException {
        if (this.streamList != null) {
            while (this.nextStream != null) {
                try {
                    this.nextStream.close();
                }
                catch (IOException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.nextStream = this.nextStream.nextStream;
            }
        }
    }
    
    void closeUsedStreams(final int n) throws SQLException {
        while (this.nextStream != null && this.nextStream.columnIndex < n) {
            try {
                this.nextStream.close();
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.nextStream = this.nextStream.nextStream;
        }
    }
    
    final void ensureOpen() throws SQLException {
        if (this.connection.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.closed) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    void allocateTmpByteArray() {
    }
    
    @Override
    public void setFetchDirection(final int defaultFetchDirection) throws SQLException {
        synchronized (this.connection) {
            if (defaultFetchDirection == 1000) {
                this.defaultFetchDirection = defaultFetchDirection;
            }
            else {
                if (defaultFetchDirection != 1001 && defaultFetchDirection != 1002) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.defaultFetchDirection = 1000;
                this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
            }
        }
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        return this.defaultFetchDirection;
    }
    
    @Override
    public void setFetchSize(final int n) throws SQLException {
        synchronized (this.connection) {
            this.setPrefetchInternal(n, false, true);
        }
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        return this.getPrefetchInternal(true);
    }
    
    @Override
    public int getResultSetConcurrency() throws SQLException {
        return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
    }
    
    @Override
    public int getResultSetType() throws SQLException {
        return ResultSetUtil.getScrollType(this.userRsetType);
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        return this.connection.getWrapper();
    }
    
    @Override
    public void setResultSetCache(final OracleResultSetCache rsetCache) throws SQLException {
        synchronized (this.connection) {
            try {
                if (rsetCache == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                if (this.rsetCache != null) {
                    this.rsetCache.close();
                }
                this.rsetCache = rsetCache;
            }
            catch (IOException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    public void setResultSetCache(final oracle.jdbc.driver.OracleResultSetCache resultSetCache) throws SQLException {
        synchronized (this.connection) {
            this.setResultSetCache((OracleResultSetCache)resultSetCache);
        }
    }
    
    @Override
    public oracle.jdbc.driver.OracleResultSetCache getResultSetCache() throws SQLException {
        synchronized (this.connection) {
            return (oracle.jdbc.driver.OracleResultSetCache)this.rsetCache;
        }
    }
    
    boolean isOracleBatchStyle() {
        return false;
    }
    
    void initBatch() {
    }
    
    int getBatchSize() {
        return this.m_batchItems.size();
    }
    
    void addBatchItem(final String obj) {
        this.m_batchItems.addElement(obj);
    }
    
    String getBatchItem(final int index) {
        return this.m_batchItems.elementAt(index);
    }
    
    void clearBatchItems() {
        this.m_batchItems.removeAllElements();
    }
    
    void checkIfJdbcBatchExists() throws SQLException {
        if (this.getBatchSize() > 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void addBatch(final String s) throws SQLException {
        synchronized (this.connection) {
            this.addBatchItem(s);
        }
    }
    
    @Override
    public void clearBatch() throws SQLException {
        synchronized (this.connection) {
            this.clearBatchItems();
        }
    }
    
    @Override
    public int[] executeBatch() throws SQLException {
        synchronized (this.connection) {
            this.cleanOldTempLobs();
            int i = 0;
            final int batchSize = this.getBatchSize();
            if (batchSize <= 0) {
                return new int[0];
            }
            final int[] array = new int[batchSize];
            this.ensureOpen();
            this.prepareForNewResults(true, true);
            final int numberOfDefinePositions = this.numberOfDefinePositions;
            final String originalSql = this.sqlObject.getOriginalSql();
            final byte sqlKind = this.sqlKind;
            this.noMoreUpdateCounts = false;
            int validRows = 0;
            try {
                this.connection.registerHeartbeat();
                this.connection.needLine();
                for (i = 0; i < batchSize; ++i) {
                    this.sqlObject.initialize(this.getBatchItem(i));
                    this.sqlKind = this.sqlObject.getSqlKind();
                    this.needToParse = true;
                    this.numberOfDefinePositions = 0;
                    this.rowsProcessed = 0;
                    this.currentRank = 1;
                    if (this.sqlKind == 1) {
                        final BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, "invalid SELECT batch command " + i, i, array);
                        batchUpdateException.fillInStackTrace();
                        throw batchUpdateException;
                    }
                    if (!this.isOpen) {
                        this.connection.open(this);
                        this.isOpen = true;
                    }
                    int validRows2 = -1;
                    try {
                        if (this.queryTimeout != 0) {
                            this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
                        }
                        this.isExecuting = true;
                        this.executeForRows(false);
                        if (this.validRows > 0) {
                            validRows += this.validRows;
                        }
                        validRows2 = this.validRows;
                    }
                    catch (SQLException ex) {
                        this.needToParse = true;
                        this.resetCurrentRowBinders();
                        throw ex;
                    }
                    finally {
                        if (this.queryTimeout != 0) {
                            this.connection.getTimeout().cancelTimeout();
                        }
                        this.validRows = validRows;
                        this.checkValidRowsStatus();
                        this.isExecuting = false;
                    }
                    array[i] = validRows2;
                    if (array[i] < 0) {
                        final BatchUpdateException batchUpdateException2 = DatabaseError.createBatchUpdateException(81, "command return value " + array[i], i, array);
                        batchUpdateException2.fillInStackTrace();
                        throw batchUpdateException2;
                    }
                }
            }
            catch (SQLException ex2) {
                if (ex2 instanceof BatchUpdateException) {
                    throw ex2;
                }
                final BatchUpdateException batchUpdateException3 = DatabaseError.createBatchUpdateException(81, ex2.getMessage(), i, array);
                batchUpdateException3.fillInStackTrace();
                throw batchUpdateException3;
            }
            finally {
                this.clearBatchItems();
                this.numberOfDefinePositions = numberOfDefinePositions;
                if (originalSql != null) {
                    this.sqlObject.initialize(originalSql);
                    this.sqlKind = sqlKind;
                }
                this.currentRank = 0;
            }
            this.connection.registerHeartbeat();
            return array;
        }
    }
    
    @Override
    public int copyBinds(final Statement statement, final int n) throws SQLException {
        return 0;
    }
    
    @Override
    public void notifyCloseRset() throws SQLException {
        this.scrollRset = null;
        this.endOfResultSet(false);
    }
    
    @Override
    public String getOriginalSql() throws SQLException {
        return this.sqlObject.getOriginalSql();
    }
    
    void doScrollExecuteCommon() throws SQLException {
        if (this.scrollRset != null) {
            this.scrollRset.close();
            this.scrollRset = null;
        }
        if (this.sqlKind != 1) {
            this.doExecuteWithTimeout();
            return;
        }
        if (!this.needToAddIdentifier) {
            this.doExecuteWithTimeout();
            this.currentResultSet = new OracleResultSetImpl(this.connection, this);
            this.realRsetType = this.userRsetType;
        }
        else {
            try {
                this.sqlObject.setIncludeRowid(true);
                this.prepareForNewResults(this.needToParse = true, false);
                if (this.columnsDefinedByUser) {
                    final Accessor[] accessors = this.accessors;
                    if (this.accessors == null || this.accessors.length <= this.numberOfDefinePositions) {
                        this.accessors = new Accessor[this.numberOfDefinePositions + 1];
                    }
                    if (accessors != null) {
                        for (int i = this.numberOfDefinePositions; i > 0; --i) {
                            final Accessor accessor = accessors[i - 1];
                            this.accessors[i] = accessor;
                            if (accessor.isColumnNumberAware) {
                                accessor.updateColumnNumber(i);
                            }
                        }
                    }
                    this.allocateRowidAccessor();
                    ++this.numberOfDefinePositions;
                }
                this.doExecuteWithTimeout();
                this.currentResultSet = new OracleResultSetImpl(this.connection, this);
                this.realRsetType = this.userRsetType;
            }
            catch (SQLException ex) {
                if (this.userRsetType > 3) {
                    this.realRsetType = 3;
                }
                else {
                    this.realRsetType = 1;
                }
                this.sqlObject.setIncludeRowid(false);
                this.prepareForNewResults(this.needToParse = true, false);
                if (this.columnsDefinedByUser) {
                    this.needToPrepareDefineBuffer = true;
                    --this.numberOfDefinePositions;
                    System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions);
                    this.accessors[this.numberOfDefinePositions] = null;
                    for (int j = 0; j < this.numberOfDefinePositions; ++j) {
                        final Accessor accessor2 = this.accessors[j];
                        if (accessor2.isColumnNumberAware) {
                            accessor2.updateColumnNumber(j);
                        }
                    }
                }
                this.doExecuteWithTimeout();
                this.currentResultSet = new OracleResultSetImpl(this.connection, this);
                this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, ex.getMessage());
            }
        }
        this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
    }
    
    void allocateRowidAccessor() throws SQLException {
        this.accessors[0] = new RowidAccessor(this, 128, (short)1, -8, false);
    }
    
    OracleResultSet doScrollStmtExecuteQuery() throws SQLException {
        this.doScrollExecuteCommon();
        return this.scrollRset;
    }
    
    void processDmlReturningBind() throws SQLException {
        if (this.returnResultSet != null) {
            this.returnResultSet.close();
        }
        this.returnParamsFetched = false;
        this.returnParamRowBytes = 0;
        this.returnParamRowChars = 0;
        int numReturnParams = 0;
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            final Accessor accessor = this.returnParamAccessors[i];
            if (accessor != null) {
                ++numReturnParams;
                if (accessor.charLength > 0) {
                    this.returnParamRowChars += accessor.charLength;
                }
                else {
                    this.returnParamRowBytes += accessor.byteLength;
                }
            }
        }
        if (this.isAutoGeneratedKey) {
            this.numReturnParams = numReturnParams;
        }
        else {
            if (this.numReturnParams <= 0) {
                this.numReturnParams = this.sqlObject.getReturnParameterCount();
            }
            if (this.numReturnParams != numReturnParams) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 173);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        this.returnParamMeta[0] = this.numReturnParams;
        this.returnParamMeta[1] = this.returnParamRowBytes;
        this.returnParamMeta[2] = this.returnParamRowChars;
    }
    
    void allocateDmlReturnStorage() {
        if (this.rowsDmlReturned == 0) {
            return;
        }
        final int n = this.returnParamRowBytes * this.rowsDmlReturned;
        final int n2 = this.returnParamRowChars * this.rowsDmlReturned;
        final int n3 = 2 * this.numReturnParams * this.rowsDmlReturned;
        this.returnParamBytes = new byte[n];
        this.returnParamChars = new char[n2];
        this.returnParamIndicators = new short[n3];
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            final Accessor accessor = this.returnParamAccessors[i];
            if (accessor != null && (accessor.internalType == 111 || accessor.internalType == 109)) {
                final TypeAccessor typeAccessor = (TypeAccessor)accessor;
                if (typeAccessor.pickledBytes == null || typeAccessor.pickledBytes.length < this.rowsDmlReturned) {
                    typeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];
                }
            }
        }
    }
    
    void fetchDmlReturnParams() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    void setupReturnParamAccessors() {
        if (this.rowsDmlReturned == 0) {
            return;
        }
        int columnIndex = 0;
        int columnIndex2 = 0;
        int indicatorIndex = 0;
        int lengthIndex = this.numReturnParams * this.rowsDmlReturned;
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            final Accessor accessor = this.returnParamAccessors[i];
            if (accessor != null) {
                if (accessor.charLength > 0) {
                    accessor.rowSpaceChar = this.returnParamChars;
                    accessor.columnIndex = columnIndex2;
                    columnIndex2 += this.rowsDmlReturned * accessor.charLength;
                }
                else {
                    accessor.rowSpaceByte = this.returnParamBytes;
                    accessor.columnIndex = columnIndex;
                    columnIndex += this.rowsDmlReturned * accessor.byteLength;
                }
                accessor.rowSpaceIndicator = this.returnParamIndicators;
                accessor.indicatorIndex = indicatorIndex;
                indicatorIndex += this.rowsDmlReturned;
                accessor.lengthIndex = lengthIndex;
                lengthIndex += this.rowsDmlReturned;
            }
        }
    }
    
    void registerReturnParameterInternal(final int n, final int n2, final int n3, final int n4, short n5, String s) throws SQLException {
        if (this.returnParamAccessors == null) {
            this.returnParamAccessors = new Accessor[this.numberOfBindPositions];
        }
        if (this.returnParamMeta == null) {
            this.returnParamMeta = new int[3 + this.numberOfBindPositions * 3];
        }
        switch (n3) {
            case -16:
            case -15:
            case -9:
            case 2011: {
                n5 = 2;
                break;
            }
            case 2009: {
                s = "SYS.SQLXML";
                break;
            }
        }
        final Accessor allocateAccessor = this.allocateAccessor(n2, n3, n + 1, n4, n5, s, true);
        allocateAccessor.isDMLReturnedParam = true;
        this.returnParamAccessors[n] = allocateAccessor;
        final boolean b = allocateAccessor.charLength > 0;
        this.returnParamMeta[3 + n * 3 + 0] = allocateAccessor.defineType;
        this.returnParamMeta[3 + n * 3 + 1] = (b ? 1 : 0);
        this.returnParamMeta[3 + n * 3 + 2] = (b ? allocateAccessor.charLength : allocateAccessor.byteLength);
    }
    
    @Override
    @Deprecated
    public int creationState() {
        synchronized (this.connection) {
            return this.creationState;
        }
    }
    
    public boolean isColumnSetNull(final int n) {
        return this.columnSetNull;
    }
    
    @Override
    public boolean isNCHAR(final int n) throws SQLException {
        if (!this.described) {
            this.describe();
        }
        final int n2 = n - 1;
        if (n2 < 0 || n2 >= this.numberOfDefinePositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.accessors[n2].formOfUse == 2;
    }
    
    void addChild(final OracleStatement children) {
        children.nextChild = this.children;
        this.children = children;
        children.parent = this;
    }
    
    void removeChild(final OracleStatement oracleStatement) {
        if (oracleStatement == this.children) {
            this.children = oracleStatement.nextChild;
        }
        else {
            OracleStatement oracleStatement2;
            for (oracleStatement2 = this.children; oracleStatement2.nextChild != oracleStatement; oracleStatement2 = oracleStatement2.nextChild) {}
            oracleStatement2.nextChild = oracleStatement.nextChild;
        }
        oracleStatement.parent = null;
        oracleStatement.nextChild = null;
    }
    
    @Override
    public boolean getMoreResults(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (!this.isAutoGeneratedKey) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.returnParamAccessors == null || this.numReturnParams == 0) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 144);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        if (this.returnResultSet == null) {
            this.returnResultSet = new OracleReturnResultSet(this);
        }
        return this.returnResultSet;
    }
    
    @Override
    public int executeUpdate(final String s, final int n) throws SQLException {
        this.autoKeyInfo = new AutoKeyInfo(s);
        if (n == 2 || !this.autoKeyInfo.isInsertSqlStmt()) {
            this.autoKeyInfo = null;
            return this.executeUpdate(s);
        }
        if (n != 1) {
            this.autoKeyInfo = null;
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        synchronized (this.connection) {
            this.isAutoGeneratedKey = true;
            final String newSql = this.autoKeyInfo.getNewSql();
            this.numberOfBindPositions = 1;
            this.autoKeyRegisterReturnParams();
            this.processDmlReturningBind();
            return this.executeUpdateInternal(newSql);
        }
    }
    
    @Override
    public int executeUpdate(final String s, final int[] array) throws SQLException {
        if (array == null || array.length == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.autoKeyInfo = new AutoKeyInfo(s, array);
        if (!this.autoKeyInfo.isInsertSqlStmt()) {
            this.autoKeyInfo = null;
            return this.executeUpdate(s);
        }
        synchronized (this.connection) {
            this.isAutoGeneratedKey = true;
            this.connection.doDescribeTable(this.autoKeyInfo);
            final String newSql = this.autoKeyInfo.getNewSql();
            this.numberOfBindPositions = array.length;
            this.autoKeyRegisterReturnParams();
            this.processDmlReturningBind();
            return this.executeUpdateInternal(newSql);
        }
    }
    
    @Override
    public int executeUpdate(final String s, final String[] array) throws SQLException {
        if (array == null || array.length == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.autoKeyInfo = new AutoKeyInfo(s, array);
        if (!this.autoKeyInfo.isInsertSqlStmt()) {
            this.autoKeyInfo = null;
            return this.executeUpdate(s);
        }
        synchronized (this.connection) {
            this.isAutoGeneratedKey = true;
            this.connection.doDescribeTable(this.autoKeyInfo);
            final String newSql = this.autoKeyInfo.getNewSql();
            this.numberOfBindPositions = array.length;
            this.autoKeyRegisterReturnParams();
            this.processDmlReturningBind();
            return this.executeUpdateInternal(newSql);
        }
    }
    
    @Override
    public boolean execute(final String s, final int n) throws SQLException {
        this.autoKeyInfo = new AutoKeyInfo(s);
        if (n == 2 || !this.autoKeyInfo.isInsertSqlStmt()) {
            this.autoKeyInfo = null;
            return this.execute(s);
        }
        if (n != 1) {
            this.autoKeyInfo = null;
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        synchronized (this.connection) {
            this.isAutoGeneratedKey = true;
            final String newSql = this.autoKeyInfo.getNewSql();
            this.numberOfBindPositions = 1;
            this.autoKeyRegisterReturnParams();
            this.processDmlReturningBind();
            return this.executeInternal(newSql);
        }
    }
    
    @Override
    public boolean execute(final String s, final int[] array) throws SQLException {
        if (array == null || array.length == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.autoKeyInfo = new AutoKeyInfo(s, array);
        if (!this.autoKeyInfo.isInsertSqlStmt()) {
            this.autoKeyInfo = null;
            return this.execute(s);
        }
        synchronized (this.connection) {
            this.isAutoGeneratedKey = true;
            this.connection.doDescribeTable(this.autoKeyInfo);
            final String newSql = this.autoKeyInfo.getNewSql();
            this.numberOfBindPositions = array.length;
            this.autoKeyRegisterReturnParams();
            this.processDmlReturningBind();
            return this.executeInternal(newSql);
        }
    }
    
    @Override
    public boolean execute(final String s, final String[] array) throws SQLException {
        if (array == null || array.length == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.autoKeyInfo = new AutoKeyInfo(s, array);
        if (!this.autoKeyInfo.isInsertSqlStmt()) {
            this.autoKeyInfo = null;
            return this.execute(s);
        }
        synchronized (this.connection) {
            this.isAutoGeneratedKey = true;
            this.connection.doDescribeTable(this.autoKeyInfo);
            final String newSql = this.autoKeyInfo.getNewSql();
            this.numberOfBindPositions = array.length;
            this.autoKeyRegisterReturnParams();
            this.processDmlReturningBind();
            return this.executeInternal(newSql);
        }
    }
    
    @Override
    public int getResultSetHoldability() throws SQLException {
        return 1;
    }
    
    @Override
    public int getcacheState() {
        return this.cacheState;
    }
    
    @Override
    public int getstatementType() {
        return this.statementType;
    }
    
    @Override
    public boolean getserverCursor() {
        return this.serverCursor;
    }
    
    void initializeIndicatorSubRange() {
        this.bindIndicatorSubRange = 0;
    }
    
    private void autoKeyRegisterReturnParams() throws SQLException {
        this.initializeIndicatorSubRange();
        this.bindIndicators = new short[this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10 + 2 * this.numberOfBindPositions];
        int bindIndicatorSubRange = this.bindIndicatorSubRange;
        this.bindIndicators[bindIndicatorSubRange + 0] = (short)this.numberOfBindPositions;
        this.bindIndicators[bindIndicatorSubRange + 1] = 0;
        this.bindIndicators[bindIndicatorSubRange + 2] = 1;
        this.bindIndicators[bindIndicatorSubRange + 3] = 0;
        this.bindIndicators[bindIndicatorSubRange + 4] = 1;
        bindIndicatorSubRange += 5;
        final short[] tableFormOfUses = this.autoKeyInfo.tableFormOfUses;
        final int[] columnIndexes = this.autoKeyInfo.columnIndexes;
        for (int i = 0; i < this.numberOfBindPositions; ++i) {
            this.bindIndicators[bindIndicatorSubRange + 0] = 994;
            short n = (short)(this.connection.defaultnchar ? 2 : 1);
            if (tableFormOfUses != null && columnIndexes != null && tableFormOfUses[columnIndexes[i] - 1] == 2) {
                n = 2;
                this.bindIndicators[bindIndicatorSubRange + 9] = n;
            }
            bindIndicatorSubRange += 10;
            this.checkTypeForAutoKey(this.autoKeyInfo.returnTypes[i]);
            String s = null;
            if (this.autoKeyInfo.returnTypes[i] == 111) {
                s = this.autoKeyInfo.tableTypeNames[columnIndexes[i] - 1];
            }
            this.registerReturnParameterInternal(i, this.autoKeyInfo.returnTypes[i], this.autoKeyInfo.returnTypes[i], -1, n, s);
        }
    }
    
    private final void setNonAutoKey() {
        this.isAutoGeneratedKey = false;
        this.numberOfBindPositions = 0;
        this.bindIndicators = null;
        this.returnParamMeta = null;
    }
    
    void saveDefineBuffersIfRequired(final char[] array, final byte[] array2, final short[] array3, final boolean b) throws SQLException {
        if (array != this.defineChars) {
            this.connection.cacheBuffer(array);
        }
        if (array2 != this.defineBytes) {
            this.connection.cacheBuffer(array2);
        }
    }
    
    final void checkTypeForAutoKey(final int n) throws SQLException {
        if (n == 109) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 5);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void moveTempLobsToFree(final CLOB o) {
        final int index;
        if (this.oldTempClobsToFree != null && (index = this.oldTempClobsToFree.indexOf(o)) != -1) {
            this.addToTempLobsToFree(o);
            this.oldTempClobsToFree.remove(index);
        }
    }
    
    void moveTempLobsToFree(final BLOB o) {
        final int index;
        if (this.oldTempBlobsToFree != null && (index = this.oldTempBlobsToFree.indexOf(o)) != -1) {
            this.addToTempLobsToFree(o);
            this.oldTempBlobsToFree.remove(index);
        }
    }
    
    void addToTempLobsToFree(final CLOB e) {
        if (this.tempClobsToFree == null) {
            this.tempClobsToFree = new ArrayList();
        }
        this.tempClobsToFree.add(e);
    }
    
    void addToTempLobsToFree(final BLOB e) {
        if (this.tempBlobsToFree == null) {
            this.tempBlobsToFree = new ArrayList();
        }
        this.tempBlobsToFree.add(e);
    }
    
    void addToOldTempLobsToFree(final CLOB e) {
        if (this.oldTempClobsToFree == null) {
            this.oldTempClobsToFree = new ArrayList();
        }
        this.oldTempClobsToFree.add(e);
    }
    
    void addToOldTempLobsToFree(final BLOB e) {
        if (this.oldTempBlobsToFree == null) {
            this.oldTempBlobsToFree = new ArrayList();
        }
        this.oldTempBlobsToFree.add(e);
    }
    
    void cleanAllTempLobs() {
        this.cleanTempClobs(this.tempClobsToFree);
        this.tempClobsToFree = null;
        this.cleanTempBlobs(this.tempBlobsToFree);
        this.tempBlobsToFree = null;
        this.cleanTempClobs(this.oldTempClobsToFree);
        this.oldTempClobsToFree = null;
        this.cleanTempBlobs(this.oldTempBlobsToFree);
        this.oldTempBlobsToFree = null;
    }
    
    void cleanOldTempLobs() {
        this.cleanTempClobs(this.oldTempClobsToFree);
        this.cleanTempBlobs(this.oldTempBlobsToFree);
        this.oldTempClobsToFree = this.tempClobsToFree;
        this.tempClobsToFree = null;
        this.oldTempBlobsToFree = this.tempBlobsToFree;
        this.tempBlobsToFree = null;
    }
    
    void cleanTempClobs(final ArrayList list) {
        if (list != null) {
            final Iterator<CLOB> iterator = list.iterator();
            while (iterator.hasNext()) {
                try {
                    iterator.next().freeTemporary();
                }
                catch (SQLException ex) {}
            }
        }
    }
    
    void cleanTempBlobs(final ArrayList list) {
        if (list != null) {
            final Iterator<BLOB> iterator = list.iterator();
            while (iterator.hasNext()) {
                try {
                    iterator.next().freeTemporary();
                }
                catch (SQLException ex) {}
            }
        }
    }
    
    TimeZone getDefaultTimeZone() throws SQLException {
        return this.getDefaultTimeZone(false);
    }
    
    TimeZone getDefaultTimeZone(final boolean b) throws SQLException {
        if (this.defaultTimeZone == null) {
            try {
                this.defaultTimeZone = this.connection.getDefaultTimeZone();
            }
            catch (SQLException ex) {}
            if (this.defaultTimeZone == null) {
                this.defaultTimeZone = TimeZone.getDefault();
            }
        }
        return this.defaultTimeZone;
    }
    
    @Override
    public void setDatabaseChangeRegistration(final DatabaseChangeRegistration databaseChangeRegistration) throws SQLException {
        this.registration = (NTFDCNRegistration)databaseChangeRegistration;
    }
    
    @Override
    public String[] getRegisteredTableNames() throws SQLException {
        return this.dcnTableName;
    }
    
    @Override
    public long getRegisteredQueryId() throws SQLException {
        return this.dcnQueryId;
    }
    
    Calendar getDefaultCalendar() throws SQLException {
        if (this.defaultCalendar == null) {
            this.defaultCalendar = Calendar.getInstance(this.getDefaultTimeZone());
        }
        return this.defaultCalendar;
    }
    
    void releaseBuffers() {
        this.cachedDefineIndicatorSize = ((this.defineIndicators != null) ? this.defineIndicators.length : 0);
        this.cachedDefineMetaDataSize = ((this.defineMetaData != null) ? this.defineMetaData.length : 0);
        this.connection.cacheBuffer(this.defineChars);
        this.defineChars = null;
        this.connection.cacheBuffer(this.defineBytes);
        this.defineBytes = null;
        this.defineIndicators = null;
        this.defineMetaData = null;
    }
    
    @Override
    public boolean isClosed() throws SQLException {
        return false;
    }
    
    @Override
    public boolean isPoolable() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.cacheState != 3;
    }
    
    @Override
    public void setPoolable(final boolean b) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (b) {
            this.cacheState = 1;
        }
        else {
            this.cacheState = 3;
        }
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    Calendar getGMTCalendar() {
        if (this.gmtCalendar == null) {
            this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
        }
        return this.gmtCalendar;
    }
    
    void extractNioDefineBuffers(final int n) throws SQLException {
    }
    
    void processLobPrefetchMetaData(final Object[] array) {
    }
    
    void internalClose() throws SQLException {
        this.closed = true;
        if (this.currentResultSet != null) {
            this.currentResultSet.closed = true;
        }
        this.cleanupDefines();
        this.bindBytes = null;
        this.bindChars = null;
        this.bindIndicators = null;
        this.outBindAccessors = null;
        this.parameterStream = null;
        this.userStream = null;
        this.ibtBindBytes = null;
        this.ibtBindChars = null;
        this.ibtBindIndicators = null;
        this.lobPrefetchMetaData = null;
        this.tmpByteArray = null;
        this.definedColumnType = null;
        this.definedColumnSize = null;
        this.definedColumnFormOfUse = null;
        if (this.wrapper != null) {
            this.wrapper.close();
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
