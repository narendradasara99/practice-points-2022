// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.aq.AQAgent;
import java.sql.SQLException;
import java.sql.Timestamp;
import oracle.jdbc.aq.AQMessageProperties;

class AQMessagePropertiesI implements AQMessageProperties
{
    private int attrAttempts;
    private String attrCorrelation;
    private int attrDelay;
    private Timestamp attrEnqTime;
    private String attrExceptionQueue;
    private int attrExpiration;
    private MessageState attrMsgState;
    private int attrPriority;
    private AQAgentI[] attrRecipientList;
    private AQAgentI attrSenderId;
    private String attrTransactionGroup;
    private byte[] attrPreviousQueueMsgId;
    private DeliveryMode deliveryMode;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    AQMessagePropertiesI() {
        this.attrAttempts = -1;
        this.attrCorrelation = null;
        this.attrDelay = 0;
        this.attrEnqTime = null;
        this.attrExceptionQueue = null;
        this.attrExpiration = -1;
        this.attrMsgState = null;
        this.attrPriority = 0;
        this.attrRecipientList = null;
        this.attrSenderId = null;
        this.attrTransactionGroup = null;
        this.attrPreviousQueueMsgId = null;
        this.deliveryMode = null;
    }
    
    @Override
    public int getDequeueAttemptsCount() {
        return this.attrAttempts;
    }
    
    @Override
    public void setCorrelation(final String attrCorrelation) throws SQLException {
        this.attrCorrelation = attrCorrelation;
    }
    
    @Override
    public String getCorrelation() {
        return this.attrCorrelation;
    }
    
    @Override
    public void setDelay(final int attrDelay) throws SQLException {
        this.attrDelay = attrDelay;
    }
    
    @Override
    public int getDelay() {
        return this.attrDelay;
    }
    
    @Override
    public Timestamp getEnqueueTime() {
        return this.attrEnqTime;
    }
    
    @Override
    public void setExceptionQueue(final String attrExceptionQueue) throws SQLException {
        this.attrExceptionQueue = attrExceptionQueue;
    }
    
    @Override
    public String getExceptionQueue() {
        return this.attrExceptionQueue;
    }
    
    @Override
    public void setExpiration(final int attrExpiration) throws SQLException {
        this.attrExpiration = attrExpiration;
    }
    
    @Override
    public int getExpiration() {
        return this.attrExpiration;
    }
    
    @Override
    public MessageState getState() {
        return this.attrMsgState;
    }
    
    @Override
    public void setPriority(final int attrPriority) throws SQLException {
        this.attrPriority = attrPriority;
    }
    
    @Override
    public int getPriority() {
        return this.attrPriority;
    }
    
    @Override
    public void setRecipientList(final AQAgent[] array) throws SQLException {
        this.attrRecipientList = new AQAgentI[array.length];
        for (int i = 0; i < array.length; ++i) {
            this.attrRecipientList[i] = (AQAgentI)array[i];
        }
    }
    
    @Override
    public AQAgent[] getRecipientList() {
        return this.attrRecipientList;
    }
    
    @Override
    public void setSender(final AQAgent aqAgent) throws SQLException {
        this.attrSenderId = (AQAgentI)aqAgent;
    }
    
    @Override
    public AQAgent getSender() {
        return this.attrSenderId;
    }
    
    @Override
    public String getTransactionGroup() {
        return this.attrTransactionGroup;
    }
    
    void setTransactionGroup(final String attrTransactionGroup) {
        this.attrTransactionGroup = attrTransactionGroup;
    }
    
    void setPreviousQueueMessageId(final byte[] attrPreviousQueueMsgId) {
        this.attrPreviousQueueMsgId = attrPreviousQueueMsgId;
    }
    
    @Override
    public byte[] getPreviousQueueMessageId() {
        return this.attrPreviousQueueMsgId;
    }
    
    @Override
    public DeliveryMode getDeliveryMode() {
        return this.deliveryMode;
    }
    
    void setDeliveryMode(final DeliveryMode deliveryMode) {
        this.deliveryMode = deliveryMode;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("Correlation             : " + this.getCorrelation() + "\n");
        final Timestamp enqueueTime = this.getEnqueueTime();
        if (enqueueTime != null) {
            sb.append("Enqueue time            : " + enqueueTime + "\n");
        }
        sb.append("Exception Queue         : " + this.getExceptionQueue() + "\n");
        sb.append("Sender                  : (" + this.getSender() + ")\n");
        final int dequeueAttemptsCount = this.getDequeueAttemptsCount();
        if (dequeueAttemptsCount != -1) {
            sb.append("Attempts                : " + dequeueAttemptsCount + "\n");
        }
        sb.append("Delay                   : " + this.getDelay() + "\n");
        sb.append("Expiration              : " + this.getExpiration() + "\n");
        final MessageState state = this.getState();
        if (state != null) {
            sb.append("State                   : " + state + "\n");
        }
        sb.append("Priority                : " + this.getPriority() + "\n");
        final DeliveryMode deliveryMode = this.getDeliveryMode();
        if (deliveryMode != null) {
            sb.append("Delivery Mode           : " + deliveryMode + "\n");
        }
        sb.append("Recipient List          : {");
        final AQAgent[] recipientList = this.getRecipientList();
        if (recipientList != null) {
            for (int i = 0; i < recipientList.length; ++i) {
                sb.append(recipientList[i]);
                if (i != recipientList.length - 1) {
                    sb.append("; ");
                }
            }
        }
        sb.append("}");
        return sb.toString();
    }
    
    void setAttempts(final int attrAttempts) throws SQLException {
        this.attrAttempts = attrAttempts;
    }
    
    void setEnqueueTime(final Timestamp attrEnqTime) throws SQLException {
        this.attrEnqTime = attrEnqTime;
    }
    
    void setMessageState(final MessageState attrMsgState) throws SQLException {
        this.attrMsgState = attrMsgState;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
