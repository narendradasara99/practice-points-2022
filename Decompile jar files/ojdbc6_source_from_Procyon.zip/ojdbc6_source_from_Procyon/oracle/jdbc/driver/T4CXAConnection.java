// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.xa.OracleXAResource;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.XAException;
import java.sql.Connection;
import oracle.jdbc.xa.client.OracleXAConnection;

public class T4CXAConnection extends OracleXAConnection
{
    T4CTTIOtxen otxen;
    T4CTTIOtxse otxse;
    T4CConnection physicalConnection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public T4CXAConnection(final Connection connection) throws XAException {
        super(connection);
        this.physicalConnection = (T4CConnection)connection;
        this.xaResource = null;
    }
    
    @Override
    public synchronized XAResource getXAResource() {
        try {
            if (this.xaResource == null) {
                this.xaResource = new T4CXAResource(this.physicalConnection, this, this.isXAResourceTransLoose);
                if (this.logicalHandle != null) {
                    ((OracleXAResource)this.xaResource).setLogicalConnection(this.logicalHandle);
                }
            }
        }
        catch (Exception ex) {
            this.xaResource = null;
        }
        return this.xaResource;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
