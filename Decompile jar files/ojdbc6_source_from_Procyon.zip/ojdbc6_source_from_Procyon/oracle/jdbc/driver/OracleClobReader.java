// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.CLOB;
import java.io.Reader;

class OracleClobReader extends Reader
{
    CLOB clob;
    DBConversion dbConversion;
    long lobOffset;
    long markedChar;
    char[] resizableBuffer;
    int initialBufferSize;
    int currentBufferSize;
    int pos;
    int count;
    long maxPosition;
    boolean isClosed;
    boolean endOfStream;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleClobReader(final CLOB clob) throws SQLException {
        this(clob, ((PhysicalConnection)clob.getInternalConnection()).getDefaultStreamChunkSize() / 3);
    }
    
    public OracleClobReader(final CLOB clob, final int n) throws SQLException {
        this(clob, n, 1L);
    }
    
    public OracleClobReader(final CLOB clob, final int initialBufferSize, final long lobOffset) throws SQLException {
        this.maxPosition = Long.MAX_VALUE;
        if (clob == null || initialBufferSize <= 0 || clob.getInternalConnection() == null || lobOffset < 1L) {
            throw new IllegalArgumentException();
        }
        this.dbConversion = ((PhysicalConnection)clob.getInternalConnection()).conversion;
        this.clob = clob;
        this.lobOffset = lobOffset;
        this.markedChar = -1L;
        this.resizableBuffer = null;
        this.initialBufferSize = initialBufferSize;
        this.currentBufferSize = 0;
        final int n = 0;
        this.count = n;
        this.pos = n;
        this.isClosed = false;
    }
    
    public OracleClobReader(final CLOB clob, final int n, final long n2, final long n3) throws SQLException {
        this(clob, n, n2);
        this.maxPosition = n2 + n3;
    }
    
    @Override
    public int read(final char[] array, final int n, final int a) throws IOException {
        this.ensureOpen();
        final int n2 = n + Math.min(a, array.length - n);
        if (!this.needChars(n2 - n)) {
            return -1;
        }
        int n3;
        for (n3 = n + this.writeChars(array, n, n2 - n); n3 < n2 && this.needChars(n2 - n3); n3 += this.writeChars(array, n3, n2 - n3)) {}
        return n3 - n;
    }
    
    protected boolean needChars(final int a) throws IOException {
        this.ensureOpen();
        if (this.pos >= this.count) {
            if (!this.endOfStream) {
                try {
                    if (a > this.currentBufferSize) {
                        this.currentBufferSize = Math.max(a, this.initialBufferSize);
                        final PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
                        synchronized (physicalConnection) {
                            this.resizableBuffer = physicalConnection.getCharBuffer(this.currentBufferSize);
                        }
                    }
                    int currentBufferSize = this.currentBufferSize;
                    if (this.maxPosition - this.lobOffset < this.currentBufferSize) {
                        currentBufferSize = (int)(this.maxPosition - this.lobOffset);
                    }
                    this.count = this.clob.getChars(this.lobOffset, currentBufferSize, this.resizableBuffer);
                    if (this.count < this.currentBufferSize) {
                        this.endOfStream = true;
                    }
                    if (this.count > 0) {
                        this.pos = 0;
                        this.lobOffset += this.count;
                        if (this.lobOffset >= this.maxPosition) {
                            this.endOfStream = true;
                        }
                        return true;
                    }
                }
                catch (SQLException ex) {
                    final IOException ioException = DatabaseError.createIOException(ex);
                    ioException.fillInStackTrace();
                    throw ioException;
                }
            }
            return false;
        }
        return true;
    }
    
    protected int writeChars(final char[] array, final int n, final int a) {
        final int min = Math.min(a, this.count - this.pos);
        System.arraycopy(this.resizableBuffer, this.pos, array, n, min);
        this.pos += min;
        return min;
    }
    
    @Override
    public boolean ready() throws IOException {
        this.ensureOpen();
        return this.pos < this.count;
    }
    
    @Override
    public void close() throws IOException {
        if (this.isClosed) {
            return;
        }
        try {
            this.isClosed = true;
            final PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
            synchronized (physicalConnection) {
                if (this.resizableBuffer != null) {
                    physicalConnection.cacheBuffer(this.resizableBuffer);
                    this.resizableBuffer = null;
                }
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    void ensureOpen() throws IOException {
        try {
            if (this.isClosed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 57, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    @Override
    public void mark(final int n) throws IOException {
        if (n < 0) {
            throw new IllegalArgumentException(DatabaseError.findMessage(195, null));
        }
        this.markedChar = this.lobOffset - this.count + this.pos;
    }
    
    @Override
    public void reset() throws IOException {
        this.ensureOpen();
        if (this.markedChar < 0L) {
            throw new IOException(DatabaseError.findMessage(195, null));
        }
        this.lobOffset = this.markedChar;
        this.pos = this.count;
        this.endOfStream = false;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        this.ensureOpen();
        final long n2 = 0L;
        long n3;
        if (this.count - this.pos >= n) {
            this.pos += (int)n;
            n3 = n2 + n;
        }
        else {
            final long n4 = n2 + (this.count - this.pos);
            this.pos = this.count;
            try {
                final long n5 = this.clob.length() - this.lobOffset + 1L;
                if (n5 >= n - n4) {
                    this.lobOffset += n - n4;
                    n3 = n4 + (n - n4);
                }
                else {
                    this.lobOffset += n5;
                    n3 = n4 + n5;
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
        return n3;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        try {
            return this.clob.getInternalConnection();
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
