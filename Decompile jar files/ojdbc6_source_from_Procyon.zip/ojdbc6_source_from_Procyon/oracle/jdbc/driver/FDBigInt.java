// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class FDBigInt
{
    int nWords;
    int[] data;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    FDBigInt(final int n) {
        this.nWords = 1;
        (this.data = new int[1])[0] = n;
    }
    
    FDBigInt(final long n) {
        (this.data = new int[2])[0] = (int)n;
        this.data[1] = (int)(n >>> 32);
        this.nWords = ((this.data[1] == 0) ? 1 : 2);
    }
    
    FDBigInt(final FDBigInt fdBigInt) {
        final int nWords = fdBigInt.nWords;
        this.nWords = nWords;
        this.data = new int[nWords];
        System.arraycopy(fdBigInt.data, 0, this.data, 0, this.nWords);
    }
    
    FDBigInt(final int[] data, final int nWords) {
        this.data = data;
        this.nWords = nWords;
    }
    
    void lshiftMe(final int n) throws IllegalArgumentException {
        if (n > 0) {
            final int n2 = n >> 5;
            final int n3 = n & 0x1F;
            final int n4 = 32 - n3;
            int[] data = this.data;
            final int[] data2 = this.data;
            if (this.nWords + n2 + 1 > data.length) {
                data = new int[this.nWords + n2 + 1];
            }
            int i = this.nWords + n2;
            int j = this.nWords - 1;
            if (n3 == 0) {
                System.arraycopy(data2, 0, data, n2, this.nWords);
                i = n2 - 1;
            }
            else {
                data[i--] = data2[j] >>> n4;
                while (j >= 1) {
                    data[i--] = (data2[j] << n3 | data2[--j] >>> n4);
                }
                data[i--] = data2[j] << n3;
            }
            while (i >= 0) {
                data[i--] = 0;
            }
            this.data = data;
            this.nWords += n2 + 1;
            while (this.nWords > 1 && this.data[this.nWords - 1] == 0) {
                --this.nWords;
            }
            return;
        }
        if (n == 0) {
            return;
        }
        throw new IllegalArgumentException("negative shift count");
    }
    
    int normalizeMe() throws IllegalArgumentException {
        int n = 0;
        int n2 = 0;
        int i = 0;
        int n3;
        for (n3 = this.nWords - 1; n3 >= 0 && (i = this.data[n3]) == 0; --n3) {
            ++n;
        }
        if (n3 < 0) {
            throw new IllegalArgumentException("zero value");
        }
        this.nWords -= n;
        if ((i & 0xF0000000) != 0x0) {
            for (n2 = 32; (i & 0xF0000000) != 0x0; i >>>= 1, --n2) {}
        }
        else {
            while (i <= 1048575) {
                i <<= 8;
                n2 += 8;
            }
            while (i <= 134217727) {
                i <<= 1;
                ++n2;
            }
        }
        if (n2 != 0) {
            this.lshiftMe(n2);
        }
        return n2;
    }
    
    FDBigInt mult(final int n) {
        final long n2 = n;
        final int[] array = new int[(n2 * ((long)this.data[this.nWords - 1] & 0xFFFFFFFFL) > 268435455L) ? (this.nWords + 1) : this.nWords];
        long n3 = 0L;
        for (int i = 0; i < this.nWords; ++i) {
            final long n4 = n3 + n2 * ((long)this.data[i] & 0xFFFFFFFFL);
            array[i] = (int)n4;
            n3 = n4 >>> 32;
        }
        if (n3 == 0L) {
            return new FDBigInt(array, this.nWords);
        }
        array[this.nWords] = (int)n3;
        return new FDBigInt(array, this.nWords + 1);
    }
    
    FDBigInt mult(final FDBigInt fdBigInt) {
        final int[] array = new int[this.nWords + fdBigInt.nWords];
        for (int i = 0; i < this.nWords; ++i) {
            final long n = (long)this.data[i] & 0xFFFFFFFFL;
            long n2 = 0L;
            int j;
            for (j = 0; j < fdBigInt.nWords; ++j) {
                final long n3 = n2 + (((long)array[i + j] & 0xFFFFFFFFL) + n * ((long)fdBigInt.data[j] & 0xFFFFFFFFL));
                array[i + j] = (int)n3;
                n2 = n3 >>> 32;
            }
            array[i + j] = (int)n2;
        }
        int n4;
        for (n4 = array.length - 1; n4 > 0 && array[n4] == 0; --n4) {}
        return new FDBigInt(array, n4 + 1);
    }
    
    FDBigInt add(final FDBigInt fdBigInt) {
        long n = 0L;
        int[] array;
        int n2;
        int[] array2;
        int n3;
        if (this.nWords >= fdBigInt.nWords) {
            array = this.data;
            n2 = this.nWords;
            array2 = fdBigInt.data;
            n3 = fdBigInt.nWords;
        }
        else {
            array = fdBigInt.data;
            n2 = fdBigInt.nWords;
            array2 = this.data;
            n3 = this.nWords;
        }
        final int[] array3 = new int[n2];
        int i;
        for (i = 0; i < n2; ++i) {
            long n4 = n + ((long)array[i] & 0xFFFFFFFFL);
            if (i < n3) {
                n4 += ((long)array2[i] & 0xFFFFFFFFL);
            }
            array3[i] = (int)n4;
            n = n4 >> 32;
        }
        if (n != 0L) {
            final int[] array4 = new int[array3.length + 1];
            System.arraycopy(array3, 0, array4, 0, array3.length);
            array4[i++] = (int)n;
            return new FDBigInt(array4, i);
        }
        return new FDBigInt(array3, i);
    }
    
    int cmp(final FDBigInt fdBigInt) {
        int i;
        if (this.nWords > fdBigInt.nWords) {
            for (final int n = fdBigInt.nWords - 1, i = this.nWords - 1; i > n; --i) {
                if (this.data[i] != 0) {
                    return 1;
                }
            }
        }
        else if (this.nWords < fdBigInt.nWords) {
            for (final int n2 = this.nWords - 1, i = fdBigInt.nWords - 1; i > n2; --i) {
                if (fdBigInt.data[i] != 0) {
                    return -1;
                }
            }
        }
        else {
            i = this.nWords - 1;
        }
        while (i > 0 && this.data[i] == fdBigInt.data[i]) {
            --i;
        }
        final int n3 = this.data[i];
        final int n4 = fdBigInt.data[i];
        if (n3 < 0) {
            if (n4 < 0) {
                return n3 - n4;
            }
            return 1;
        }
        else {
            if (n4 < 0) {
                return -1;
            }
            return n3 - n4;
        }
    }
    
    int quoRemIteration(final FDBigInt fdBigInt) throws IllegalArgumentException {
        if (this.nWords != fdBigInt.nWords) {
            throw new IllegalArgumentException("disparate values");
        }
        final int n = this.nWords - 1;
        long n2 = ((long)this.data[n] & 0xFFFFFFFFL) / fdBigInt.data[n];
        long n3 = 0L;
        for (int i = 0; i <= n; ++i) {
            final long n4 = n3 + (((long)this.data[i] & 0xFFFFFFFFL) - n2 * ((long)fdBigInt.data[i] & 0xFFFFFFFFL));
            this.data[i] = (int)n4;
            n3 = n4 >> 32;
        }
        if (n3 != 0L) {
            long lng = 0L;
            while (lng == 0L) {
                lng = 0L;
                for (int j = 0; j <= n; ++j) {
                    final long n5 = lng + (((long)this.data[j] & 0xFFFFFFFFL) + ((long)fdBigInt.data[j] & 0xFFFFFFFFL));
                    this.data[j] = (int)n5;
                    lng = n5 >> 32;
                }
                if (lng != 0L && lng != 1L) {
                    throw new RuntimeException("Assertion botch: " + lng + " carry out of division correction");
                }
                --n2;
            }
        }
        long n6 = 0L;
        for (int k = 0; k <= n; ++k) {
            final long n7 = n6 + 10L * ((long)this.data[k] & 0xFFFFFFFFL);
            this.data[k] = (int)n7;
            n6 = n7 >> 32;
        }
        if (n6 != 0L) {
            throw new RuntimeException("Assertion botch: carry out of *10");
        }
        return (int)n2;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
