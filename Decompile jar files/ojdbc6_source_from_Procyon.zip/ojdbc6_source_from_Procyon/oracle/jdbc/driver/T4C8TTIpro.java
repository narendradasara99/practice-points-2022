// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.StringWriter;
import java.io.IOException;
import java.sql.SQLException;

class T4C8TTIpro extends T4CTTIMsg
{
    short svrCharSet;
    short svrCharSetElem;
    byte svrFlags;
    byte[] proSvrStr;
    byte proSvrVer;
    short oVersion;
    boolean svrInfoAvailable;
    byte[] proCliVerTTC8;
    byte[] proCliStrTTC8;
    short NCHAR_CHARSET;
    byte[] runtimeCapabilities;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8TTIpro(final T4CConnection t4CConnection) throws SQLException, IOException {
        super(t4CConnection, (byte)1);
        this.oVersion = -1;
        this.svrInfoAvailable = false;
        this.proCliVerTTC8 = new byte[] { 6, 5, 4, 3, 2, 1, 0 };
        this.proCliStrTTC8 = new byte[] { 74, 97, 118, 97, 95, 84, 84, 67, 45, 56, 46, 50, 46, 48, 0 };
        this.NCHAR_CHARSET = 0;
        this.runtimeCapabilities = null;
    }
    
    byte[] receive() throws SQLException, IOException {
        if (this.meg.unmarshalSB1() != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 401);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.proSvrVer = this.meg.unmarshalSB1();
        this.meg.proSvrVer = this.proSvrVer;
        switch (this.proSvrVer) {
            case 4: {
                this.oVersion = 7230;
                break;
            }
            case 5: {
                this.oVersion = 8030;
                break;
            }
            case 6: {
                this.oVersion = 8100;
                break;
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 444);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        this.meg.unmarshalSB1();
        this.proSvrStr = this.meg.unmarshalTEXT(50);
        this.oVersion = this.getOracleVersion();
        this.svrCharSet = (short)this.meg.unmarshalUB2();
        this.svrFlags = (byte)this.meg.unmarshalUB1();
        final short svrCharSetElem = (short)this.meg.unmarshalUB2();
        this.svrCharSetElem = svrCharSetElem;
        if (svrCharSetElem > 0) {
            this.meg.unmarshalNBytes(this.svrCharSetElem * 5);
        }
        this.svrInfoAvailable = true;
        if (this.proSvrVer < 5) {
            return null;
        }
        final byte rep = this.meg.types.getRep((byte)1);
        this.meg.types.setRep((byte)1, (byte)0);
        final int unmarshalUB2 = this.meg.unmarshalUB2();
        this.meg.types.setRep((byte)1, rep);
        final byte[] unmarshalNBytes = this.meg.unmarshalNBytes(unmarshalUB2);
        final int n = 6 + (unmarshalNBytes[5] & 0xFF) + (unmarshalNBytes[6] & 0xFF);
        this.NCHAR_CHARSET = (short)((unmarshalNBytes[n + 3] & 0xFF) << 8);
        this.NCHAR_CHARSET |= (short)(unmarshalNBytes[n + 4] & 0xFF);
        if (this.proSvrVer < 6) {
            return null;
        }
        final short unmarshalUB3 = this.meg.unmarshalUB1();
        final byte[] array = new byte[unmarshalUB3];
        for (short n2 = 0; n2 < unmarshalUB3; ++n2) {
            array[n2] = (byte)this.meg.unmarshalUB1();
        }
        final short unmarshalUB4 = this.meg.unmarshalUB1();
        if (unmarshalUB4 > 0) {
            this.runtimeCapabilities = new byte[unmarshalUB4];
            for (short n3 = 0; n3 < unmarshalUB4; ++n3) {
                this.runtimeCapabilities[n3] = (byte)this.meg.unmarshalUB1();
            }
        }
        return array;
    }
    
    short getOracleVersion() {
        return this.oVersion;
    }
    
    byte[] getServerRuntimeCapabilities() {
        return this.runtimeCapabilities;
    }
    
    short getCharacterSet() {
        return this.svrCharSet;
    }
    
    short getncharCHARSET() {
        return this.NCHAR_CHARSET;
    }
    
    byte getFlags() {
        return this.svrFlags;
    }
    
    void marshal() throws SQLException, IOException {
        this.marshalTTCcode();
        this.meg.marshalB1Array(this.proCliVerTTC8);
        this.meg.marshalB1Array(this.proCliStrTTC8);
    }
    
    void printServerInfo() {
        if (this.svrInfoAvailable) {
            int i = 0;
            final StringWriter stringWriter = new StringWriter();
            stringWriter.write("Protocol string  =");
            while (i < this.proSvrStr.length) {
                stringWriter.write((char)this.proSvrStr[i++]);
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
