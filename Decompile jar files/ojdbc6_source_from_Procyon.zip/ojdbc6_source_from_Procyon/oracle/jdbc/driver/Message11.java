// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.ResourceBundle;

class Message11 implements Message
{
    private static ResourceBundle bundle;
    private static final String messageFile = "oracle.jdbc.driver.Messages";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public Message11() {
    }
    
    @Override
    public String msg(final String str, final Object obj) {
        if (Message11.bundle == null) {
            try {
                Message11.bundle = ResourceBundle.getBundle("oracle.jdbc.driver.Messages");
            }
            catch (Exception ex) {
                return "Message file 'oracle.jdbc.driver.Messages' is missing.";
            }
        }
        try {
            if (obj != null) {
                return Message11.bundle.getString(str) + ": " + obj;
            }
            return Message11.bundle.getString(str);
        }
        catch (Exception ex2) {
            return "Message [" + str + "] not found in '" + "oracle.jdbc.driver.Messages" + "'.";
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
