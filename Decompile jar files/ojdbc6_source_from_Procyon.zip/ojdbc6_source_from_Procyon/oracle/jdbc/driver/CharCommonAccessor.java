// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.net.MalformedURLException;
import java.net.URL;
import oracle.sql.CharacterSet;
import oracle.sql.CHAR;
import oracle.sql.Datum;
import java.util.Map;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.Reader;
import java.io.InputStream;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import java.sql.SQLException;

abstract class CharCommonAccessor extends Accessor
{
    int internalMaxLengthNewer;
    int internalMaxLengthOlder;
    static final int MAX_NB_CHAR_PLSQL = 32766;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    void setOffsets(final int n) {
        this.columnIndex = this.statement.defineCharSubRange;
        this.statement.defineCharSubRange = this.columnIndex + n * this.charLength;
    }
    
    void init(final OracleStatement oracleStatement, int n, final int n2, int maxFieldSize, final short n3, final int n4, final boolean b, final int internalMaxLengthNewer, final int internalMaxLengthOlder) throws SQLException {
        if (b) {
            if (n != 23) {
                n = 1;
            }
            if (oracleStatement.maxFieldSize > 0 && (maxFieldSize == -1 || maxFieldSize < oracleStatement.maxFieldSize)) {
                maxFieldSize = oracleStatement.maxFieldSize;
            }
        }
        this.init(oracleStatement, n, n2, n3, b);
        if (b && oracleStatement.connection.defaultnchar) {
            this.formOfUse = 2;
        }
        this.internalMaxLengthNewer = internalMaxLengthNewer;
        this.internalMaxLengthOlder = internalMaxLengthOlder;
        this.initForDataAccess(n4, maxFieldSize, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, int n3, final boolean b, final int n4, final int n5, final int n6, final int n7, final int n8, final short n9, final int internalMaxLengthNewer, final int internalMaxLengthOlder) throws SQLException {
        this.init(oracleStatement, n, n2, n9, false);
        this.initForDescribe(n, n3, b, n4, n5, n6, n7, n8, n9, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize != 0 && maxFieldSize <= n3) {
            n3 = maxFieldSize;
        }
        this.internalMaxLengthNewer = internalMaxLengthNewer;
        this.internalMaxLengthOlder = internalMaxLengthOlder;
        this.initForDataAccess(0, n3, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        if (this.statement.connection.getVersionNumber() >= 8000) {
            this.internalTypeMaxLength = this.internalMaxLengthNewer;
        }
        else {
            this.internalTypeMaxLength = this.internalMaxLengthOlder;
        }
        if (internalTypeMaxLength == 0) {
            this.internalTypeMaxLength = 0;
        }
        else if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.charLength = (this.isNullByDescribe ? 0 : (this.internalTypeMaxLength + 1));
    }
    
    @Override
    int getInt(final int n) throws SQLException {
        int int1 = 0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                int1 = Integer.parseInt(this.getString(n).trim());
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return int1;
    }
    
    @Override
    boolean getBoolean(final int n) throws SQLException {
        final String string = this.getString(n);
        if (string == null) {
            return false;
        }
        final String trim = string.trim();
        try {
            return new BigDecimal(trim).signum() != 0;
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    short getShort(final int n) throws SQLException {
        short short1 = 0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                short1 = Short.parseShort(this.getString(n).trim());
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return short1;
    }
    
    @Override
    byte getByte(final int n) throws SQLException {
        byte byte1 = 0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                byte1 = Byte.parseByte(this.getString(n).trim());
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return byte1;
    }
    
    @Override
    long getLong(final int n) throws SQLException {
        long long1 = 0L;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                long1 = Long.parseLong(this.getString(n).trim());
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return long1;
    }
    
    @Override
    float getFloat(final int n) throws SQLException {
        float float1 = 0.0f;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                float1 = Float.parseFloat(this.getString(n).trim());
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return float1;
    }
    
    @Override
    double getDouble(final int n) throws SQLException {
        double double1 = 0.0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                double1 = Double.parseDouble(this.getString(n).trim());
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return double1;
    }
    
    @Override
    BigDecimal getBigDecimal(final int n) throws SQLException {
        BigDecimal bigDecimal = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                final String string = this.getString(n);
                if (string != null) {
                    bigDecimal = new BigDecimal(string.trim());
                }
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return bigDecimal;
    }
    
    @Override
    BigDecimal getBigDecimal(final int n, final int newScale) throws SQLException {
        final BigDecimal bigDecimal = this.getBigDecimal(n);
        if (bigDecimal != null) {
            bigDecimal.setScale(newScale, 6);
        }
        return bigDecimal;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            s = new String(this.rowSpaceChar, n2 + 1, internalTypeMaxLength);
        }
        return s;
    }
    
    @Override
    Date getDate(final int n) throws SQLException {
        Date value = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            value = Date.valueOf(this.getString(n).trim());
        }
        return value;
    }
    
    @Override
    Time getTime(final int n) throws SQLException {
        Time value = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            value = Time.valueOf(this.getString(n).trim());
        }
        return value;
    }
    
    @Override
    Timestamp getTimestamp(final int n) throws SQLException {
        Timestamp value = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            value = Timestamp.valueOf(this.getString(n).trim());
        }
        return value;
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        return this.getBytesInternal(n);
    }
    
    byte[] getBytesInternal(final int n) throws SQLException {
        Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            final DBConversion conversion = this.statement.connection.conversion;
            final byte[] array = new byte[internalTypeMaxLength * 6];
            final int n3 = (this.formOfUse == 2) ? conversion.javaCharsToNCHARBytes(this.rowSpaceChar, n2 + 1, array, 0, internalTypeMaxLength) : conversion.javaCharsToCHARBytes(this.rowSpaceChar, n2 + 1, array, 0, internalTypeMaxLength);
            o = new byte[n3];
            System.arraycopy(array, 0, o, 0, n3);
        }
        return (byte[])o;
    }
    
    @Override
    InputStream getAsciiStream(final int n) throws SQLException {
        InputStream charsToStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            charsToStream = this.statement.connection.conversion.CharsToStream(this.rowSpaceChar, n2 + 1, internalTypeMaxLength, 10);
        }
        return charsToStream;
    }
    
    @Override
    InputStream getUnicodeStream(final int n) throws SQLException {
        InputStream charsToStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            charsToStream = this.statement.connection.conversion.CharsToStream(this.rowSpaceChar, n2 + 1, internalTypeMaxLength << 1, 11);
        }
        return charsToStream;
    }
    
    @Override
    Reader getCharacterStream(final int n) throws SQLException {
        Reader reader = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            reader = new CharArrayReader(this.rowSpaceChar, n2 + 1, internalTypeMaxLength);
        }
        return reader;
    }
    
    @Override
    InputStream getBinaryStream(final int n) throws SQLException {
        InputStream inputStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            final DBConversion conversion = this.statement.connection.conversion;
            final byte[] buf = new byte[internalTypeMaxLength * 6];
            inputStream = new ByteArrayInputStream(buf, 0, (this.formOfUse == 2) ? conversion.javaCharsToNCHARBytes(this.rowSpaceChar, n2 + 1, buf, 0, internalTypeMaxLength) : conversion.javaCharsToCHARBytes(this.rowSpaceChar, n2 + 1, buf, 0, internalTypeMaxLength));
        }
        return inputStream;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getString(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getString(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getCHAR(n);
    }
    
    @Override
    CHAR getCHAR(final int n) throws SQLException {
        final byte[] bytesInternal = this.getBytesInternal(n);
        if (bytesInternal == null || bytesInternal.length == 0) {
            return null;
        }
        CharacterSet set;
        if (this.formOfUse == 2) {
            set = this.statement.connection.conversion.getDriverNCharSetObj();
        }
        else {
            set = this.statement.connection.conversion.getDriverCharSetObj();
        }
        return new CHAR(bytesInternal, set);
    }
    
    @Override
    URL getURL(final int n) throws SQLException {
        URL url = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            try {
                url = new URL(this.getString(n));
            }
            catch (MalformedURLException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 136);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return url;
    }
    
    byte[] getBytesFromHexChars(final int n) throws SQLException {
        byte[] hexChars2Bytes = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.charLength * n;
            int internalTypeMaxLength = this.rowSpaceChar[n2] >> 1;
            if (internalTypeMaxLength > this.internalTypeMaxLength) {
                internalTypeMaxLength = this.internalTypeMaxLength;
            }
            hexChars2Bytes = this.statement.connection.conversion.hexChars2Bytes(this.rowSpaceChar, n2 + 1, internalTypeMaxLength);
        }
        return hexChars2Bytes;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
