// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.sql.SQLWarning;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.DATE;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.net.URL;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.Ref;
import java.util.Map;
import java.sql.NClob;
import java.util.Calendar;
import java.sql.Date;
import java.sql.Clob;
import java.sql.Blob;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.SQLException;

abstract class OracleResultSet implements oracle.jdbc.internal.OracleResultSet
{
    static final boolean DEBUG = false;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    int getFirstUserColumnIndex() throws SQLException {
        return 0;
    }
    
    @Override
    public abstract void closeStatementOnClose() throws SQLException;
    
    @Override
    public abstract Array getArray(final int p0) throws SQLException;
    
    @Override
    public abstract BigDecimal getBigDecimal(final int p0) throws SQLException;
    
    @Override
    public abstract BigDecimal getBigDecimal(final int p0, final int p1) throws SQLException;
    
    @Override
    public abstract Blob getBlob(final int p0) throws SQLException;
    
    @Override
    public abstract boolean getBoolean(final int p0) throws SQLException;
    
    @Override
    public abstract byte getByte(final int p0) throws SQLException;
    
    @Override
    public abstract byte[] getBytes(final int p0) throws SQLException;
    
    @Override
    public abstract Clob getClob(final int p0) throws SQLException;
    
    @Override
    public abstract Date getDate(final int p0) throws SQLException;
    
    @Override
    public abstract Date getDate(final int p0, final Calendar p1) throws SQLException;
    
    @Override
    public abstract double getDouble(final int p0) throws SQLException;
    
    @Override
    public abstract float getFloat(final int p0) throws SQLException;
    
    @Override
    public abstract int getInt(final int p0) throws SQLException;
    
    @Override
    public abstract long getLong(final int p0) throws SQLException;
    
    @Override
    public abstract NClob getNClob(final int p0) throws SQLException;
    
    @Override
    public abstract String getNString(final int p0) throws SQLException;
    
    @Override
    public abstract Object getObject(final int p0) throws SQLException;
    
    @Override
    public abstract Object getObject(final int p0, final Map p1) throws SQLException;
    
    @Override
    public abstract Ref getRef(final int p0) throws SQLException;
    
    @Override
    public abstract RowId getRowId(final int p0) throws SQLException;
    
    @Override
    public abstract short getShort(final int p0) throws SQLException;
    
    @Override
    public abstract SQLXML getSQLXML(final int p0) throws SQLException;
    
    @Override
    public abstract String getString(final int p0) throws SQLException;
    
    @Override
    public abstract Time getTime(final int p0) throws SQLException;
    
    @Override
    public abstract Time getTime(final int p0, final Calendar p1) throws SQLException;
    
    @Override
    public abstract Timestamp getTimestamp(final int p0) throws SQLException;
    
    @Override
    public abstract Timestamp getTimestamp(final int p0, final Calendar p1) throws SQLException;
    
    @Override
    public abstract URL getURL(final int p0) throws SQLException;
    
    @Override
    public abstract ARRAY getARRAY(final int p0) throws SQLException;
    
    @Override
    public abstract BFILE getBFILE(final int p0) throws SQLException;
    
    @Override
    public abstract BFILE getBfile(final int p0) throws SQLException;
    
    @Override
    public abstract BLOB getBLOB(final int p0) throws SQLException;
    
    @Override
    public abstract CHAR getCHAR(final int p0) throws SQLException;
    
    @Override
    public abstract CLOB getCLOB(final int p0) throws SQLException;
    
    @Override
    public abstract ResultSet getCursor(final int p0) throws SQLException;
    
    @Override
    public abstract CustomDatum getCustomDatum(final int p0, final CustomDatumFactory p1) throws SQLException;
    
    @Override
    public abstract DATE getDATE(final int p0) throws SQLException;
    
    @Override
    public abstract INTERVALDS getINTERVALDS(final int p0) throws SQLException;
    
    @Override
    public abstract INTERVALYM getINTERVALYM(final int p0) throws SQLException;
    
    @Override
    public abstract NUMBER getNUMBER(final int p0) throws SQLException;
    
    @Override
    public abstract OPAQUE getOPAQUE(final int p0) throws SQLException;
    
    @Override
    public abstract Datum getOracleObject(final int p0) throws SQLException;
    
    @Override
    public abstract ORAData getORAData(final int p0, final ORADataFactory p1) throws SQLException;
    
    @Override
    public abstract RAW getRAW(final int p0) throws SQLException;
    
    @Override
    public abstract REF getREF(final int p0) throws SQLException;
    
    @Override
    public abstract ROWID getROWID(final int p0) throws SQLException;
    
    @Override
    public abstract STRUCT getSTRUCT(final int p0) throws SQLException;
    
    @Override
    public abstract TIMESTAMPLTZ getTIMESTAMPLTZ(final int p0) throws SQLException;
    
    @Override
    public abstract TIMESTAMPTZ getTIMESTAMPTZ(final int p0) throws SQLException;
    
    @Override
    public abstract TIMESTAMP getTIMESTAMP(final int p0) throws SQLException;
    
    @Override
    public abstract InputStream getAsciiStream(final int p0) throws SQLException;
    
    @Override
    public abstract InputStream getBinaryStream(final int p0) throws SQLException;
    
    @Override
    public abstract Reader getCharacterStream(final int p0) throws SQLException;
    
    @Override
    public abstract Reader getNCharacterStream(final int p0) throws SQLException;
    
    @Override
    public abstract InputStream getUnicodeStream(final int p0) throws SQLException;
    
    @Override
    public abstract void updateArray(final int p0, final Array p1) throws SQLException;
    
    @Override
    public abstract void updateBigDecimal(final int p0, final BigDecimal p1) throws SQLException;
    
    @Override
    public abstract void updateBlob(final int p0, final Blob p1) throws SQLException;
    
    @Override
    public abstract void updateBoolean(final int p0, final boolean p1) throws SQLException;
    
    @Override
    public abstract void updateByte(final int p0, final byte p1) throws SQLException;
    
    @Override
    public abstract void updateBytes(final int p0, final byte[] p1) throws SQLException;
    
    @Override
    public abstract void updateClob(final int p0, final Clob p1) throws SQLException;
    
    @Override
    public abstract void updateDate(final int p0, final Date p1) throws SQLException;
    
    public abstract void updateDate(final int p0, final Date p1, final Calendar p2) throws SQLException;
    
    @Override
    public abstract void updateDouble(final int p0, final double p1) throws SQLException;
    
    @Override
    public abstract void updateFloat(final int p0, final float p1) throws SQLException;
    
    @Override
    public abstract void updateInt(final int p0, final int p1) throws SQLException;
    
    @Override
    public abstract void updateLong(final int p0, final long p1) throws SQLException;
    
    @Override
    public abstract void updateNClob(final int p0, final NClob p1) throws SQLException;
    
    @Override
    public abstract void updateNString(final int p0, final String p1) throws SQLException;
    
    @Override
    public abstract void updateObject(final int p0, final Object p1) throws SQLException;
    
    @Override
    public abstract void updateObject(final int p0, final Object p1, final int p2) throws SQLException;
    
    @Override
    public abstract void updateRef(final int p0, final Ref p1) throws SQLException;
    
    @Override
    public abstract void updateRowId(final int p0, final RowId p1) throws SQLException;
    
    @Override
    public abstract void updateShort(final int p0, final short p1) throws SQLException;
    
    @Override
    public abstract void updateSQLXML(final int p0, final SQLXML p1) throws SQLException;
    
    @Override
    public abstract void updateString(final int p0, final String p1) throws SQLException;
    
    @Override
    public abstract void updateTime(final int p0, final Time p1) throws SQLException;
    
    public abstract void updateTime(final int p0, final Time p1, final Calendar p2) throws SQLException;
    
    @Override
    public abstract void updateTimestamp(final int p0, final Timestamp p1) throws SQLException;
    
    public abstract void updateTimestamp(final int p0, final Timestamp p1, final Calendar p2) throws SQLException;
    
    public abstract void updateURL(final int p0, final URL p1) throws SQLException;
    
    @Override
    public abstract void updateARRAY(final int p0, final ARRAY p1) throws SQLException;
    
    @Override
    public abstract void updateBFILE(final int p0, final BFILE p1) throws SQLException;
    
    @Override
    public abstract void updateBfile(final int p0, final BFILE p1) throws SQLException;
    
    public abstract void updateBinaryFloat(final int p0, final float p1) throws SQLException;
    
    public abstract void updateBinaryFloat(final int p0, final BINARY_FLOAT p1) throws SQLException;
    
    public abstract void updateBinaryDouble(final int p0, final double p1) throws SQLException;
    
    public abstract void updateBinaryDouble(final int p0, final BINARY_DOUBLE p1) throws SQLException;
    
    @Override
    public abstract void updateBLOB(final int p0, final BLOB p1) throws SQLException;
    
    @Override
    public abstract void updateCHAR(final int p0, final CHAR p1) throws SQLException;
    
    @Override
    public abstract void updateCLOB(final int p0, final CLOB p1) throws SQLException;
    
    public abstract void updateCursor(final int p0, final ResultSet p1) throws SQLException;
    
    @Override
    public abstract void updateCustomDatum(final int p0, final CustomDatum p1) throws SQLException;
    
    @Override
    public abstract void updateDATE(final int p0, final DATE p1) throws SQLException;
    
    public abstract void updateFixedCHAR(final int p0, final String p1) throws SQLException;
    
    @Override
    public abstract void updateINTERVALDS(final int p0, final INTERVALDS p1) throws SQLException;
    
    @Override
    public abstract void updateINTERVALYM(final int p0, final INTERVALYM p1) throws SQLException;
    
    @Override
    public abstract void updateNUMBER(final int p0, final NUMBER p1) throws SQLException;
    
    public abstract void updateOPAQUE(final int p0, final OPAQUE p1) throws SQLException;
    
    @Override
    public abstract void updateOracleObject(final int p0, final Datum p1) throws SQLException;
    
    @Override
    public abstract void updateORAData(final int p0, final ORAData p1) throws SQLException;
    
    @Override
    public abstract void updateRAW(final int p0, final RAW p1) throws SQLException;
    
    @Override
    public abstract void updateREF(final int p0, final REF p1) throws SQLException;
    
    public abstract void updateRefType(final int p0, final REF p1) throws SQLException;
    
    @Override
    public abstract void updateROWID(final int p0, final ROWID p1) throws SQLException;
    
    @Override
    public abstract void updateSTRUCT(final int p0, final STRUCT p1) throws SQLException;
    
    @Override
    public abstract void updateTIMESTAMPLTZ(final int p0, final TIMESTAMPLTZ p1) throws SQLException;
    
    @Override
    public abstract void updateTIMESTAMPTZ(final int p0, final TIMESTAMPTZ p1) throws SQLException;
    
    @Override
    public abstract void updateTIMESTAMP(final int p0, final TIMESTAMP p1) throws SQLException;
    
    @Override
    public abstract void updateBlob(final int p0, final InputStream p1) throws SQLException;
    
    @Override
    public abstract void updateBlob(final int p0, final InputStream p1, final long p2) throws SQLException;
    
    @Override
    public abstract void updateClob(final int p0, final Reader p1) throws SQLException;
    
    @Override
    public abstract void updateClob(final int p0, final Reader p1, final long p2) throws SQLException;
    
    @Override
    public abstract void updateNClob(final int p0, final Reader p1) throws SQLException;
    
    @Override
    public abstract void updateNClob(final int p0, final Reader p1, final long p2) throws SQLException;
    
    @Override
    public abstract void updateAsciiStream(final int p0, final InputStream p1) throws SQLException;
    
    @Override
    public abstract void updateAsciiStream(final int p0, final InputStream p1, final int p2) throws SQLException;
    
    @Override
    public abstract void updateAsciiStream(final int p0, final InputStream p1, final long p2) throws SQLException;
    
    @Override
    public abstract void updateBinaryStream(final int p0, final InputStream p1) throws SQLException;
    
    @Override
    public abstract void updateBinaryStream(final int p0, final InputStream p1, final int p2) throws SQLException;
    
    @Override
    public abstract void updateBinaryStream(final int p0, final InputStream p1, final long p2) throws SQLException;
    
    @Override
    public abstract void updateCharacterStream(final int p0, final Reader p1) throws SQLException;
    
    @Override
    public abstract void updateCharacterStream(final int p0, final Reader p1, final int p2) throws SQLException;
    
    @Override
    public abstract void updateCharacterStream(final int p0, final Reader p1, final long p2) throws SQLException;
    
    @Override
    public abstract void updateNCharacterStream(final int p0, final Reader p1) throws SQLException;
    
    @Override
    public abstract void updateNCharacterStream(final int p0, final Reader p1, final long p2) throws SQLException;
    
    public abstract void updateUnicodeStream(final int p0, final InputStream p1, final int p2) throws SQLException;
    
    @Override
    public Array getArray(final String s) throws SQLException {
        return this.getArray(this.findColumn(s));
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s) throws SQLException {
        return this.getBigDecimal(this.findColumn(s));
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s, final int n) throws SQLException {
        return this.getBigDecimal(this.findColumn(s), n);
    }
    
    @Override
    public Blob getBlob(final String s) throws SQLException {
        return this.getBlob(this.findColumn(s));
    }
    
    @Override
    public boolean getBoolean(final String s) throws SQLException {
        return this.getBoolean(this.findColumn(s));
    }
    
    @Override
    public byte getByte(final String s) throws SQLException {
        return this.getByte(this.findColumn(s));
    }
    
    @Override
    public byte[] getBytes(final String s) throws SQLException {
        return this.getBytes(this.findColumn(s));
    }
    
    @Override
    public Clob getClob(final String s) throws SQLException {
        return this.getClob(this.findColumn(s));
    }
    
    @Override
    public Date getDate(final String s) throws SQLException {
        return this.getDate(this.findColumn(s));
    }
    
    @Override
    public Date getDate(final String s, final Calendar calendar) throws SQLException {
        return this.getDate(this.findColumn(s), calendar);
    }
    
    @Override
    public double getDouble(final String s) throws SQLException {
        return this.getDouble(this.findColumn(s));
    }
    
    @Override
    public float getFloat(final String s) throws SQLException {
        return this.getFloat(this.findColumn(s));
    }
    
    @Override
    public int getInt(final String s) throws SQLException {
        return this.getInt(this.findColumn(s));
    }
    
    @Override
    public long getLong(final String s) throws SQLException {
        return this.getLong(this.findColumn(s));
    }
    
    @Override
    public NClob getNClob(final String s) throws SQLException {
        return this.getNClob(this.findColumn(s));
    }
    
    @Override
    public String getNString(final String s) throws SQLException {
        return this.getNString(this.findColumn(s));
    }
    
    @Override
    public Object getObject(final String s) throws SQLException {
        return this.getObject(this.findColumn(s));
    }
    
    @Override
    public Object getObject(final String s, final Map map) throws SQLException {
        return this.getObject(this.findColumn(s), map);
    }
    
    @Override
    public Ref getRef(final String s) throws SQLException {
        return this.getRef(this.findColumn(s));
    }
    
    @Override
    public RowId getRowId(final String s) throws SQLException {
        return this.getRowId(this.findColumn(s));
    }
    
    @Override
    public short getShort(final String s) throws SQLException {
        return this.getShort(this.findColumn(s));
    }
    
    @Override
    public SQLXML getSQLXML(final String s) throws SQLException {
        return this.getSQLXML(this.findColumn(s));
    }
    
    @Override
    public String getString(final String s) throws SQLException {
        return this.getString(this.findColumn(s));
    }
    
    @Override
    public Time getTime(final String s) throws SQLException {
        return this.getTime(this.findColumn(s));
    }
    
    @Override
    public Time getTime(final String s, final Calendar calendar) throws SQLException {
        return this.getTime(this.findColumn(s), calendar);
    }
    
    @Override
    public Timestamp getTimestamp(final String s) throws SQLException {
        return this.getTimestamp(this.findColumn(s));
    }
    
    @Override
    public Timestamp getTimestamp(final String s, final Calendar calendar) throws SQLException {
        return this.getTimestamp(this.findColumn(s), calendar);
    }
    
    @Override
    public URL getURL(final String s) throws SQLException {
        return this.getURL(this.findColumn(s));
    }
    
    @Override
    public ARRAY getARRAY(final String s) throws SQLException {
        return this.getARRAY(this.findColumn(s));
    }
    
    @Override
    public BFILE getBFILE(final String s) throws SQLException {
        return this.getBFILE(this.findColumn(s));
    }
    
    @Override
    public BFILE getBfile(final String s) throws SQLException {
        return this.getBfile(this.findColumn(s));
    }
    
    @Override
    public BLOB getBLOB(final String s) throws SQLException {
        return this.getBLOB(this.findColumn(s));
    }
    
    @Override
    public CHAR getCHAR(final String s) throws SQLException {
        return this.getCHAR(this.findColumn(s));
    }
    
    @Override
    public CLOB getCLOB(final String s) throws SQLException {
        return this.getCLOB(this.findColumn(s));
    }
    
    @Override
    public ResultSet getCursor(final String s) throws SQLException {
        return this.getCursor(this.findColumn(s));
    }
    
    @Override
    public CustomDatum getCustomDatum(final String s, final CustomDatumFactory customDatumFactory) throws SQLException {
        return this.getCustomDatum(this.findColumn(s), customDatumFactory);
    }
    
    @Override
    public DATE getDATE(final String s) throws SQLException {
        return this.getDATE(this.findColumn(s));
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final String s) throws SQLException {
        return this.getINTERVALDS(this.findColumn(s));
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final String s) throws SQLException {
        return this.getINTERVALYM(this.findColumn(s));
    }
    
    @Override
    public NUMBER getNUMBER(final String s) throws SQLException {
        return this.getNUMBER(this.findColumn(s));
    }
    
    @Override
    public OPAQUE getOPAQUE(final String s) throws SQLException {
        return this.getOPAQUE(this.findColumn(s));
    }
    
    @Override
    public Datum getOracleObject(final String s) throws SQLException {
        return this.getOracleObject(this.findColumn(s));
    }
    
    @Override
    public ORAData getORAData(final String s, final ORADataFactory oraDataFactory) throws SQLException {
        return this.getORAData(this.findColumn(s), oraDataFactory);
    }
    
    @Override
    public RAW getRAW(final String s) throws SQLException {
        return this.getRAW(this.findColumn(s));
    }
    
    @Override
    public REF getREF(final String s) throws SQLException {
        return this.getREF(this.findColumn(s));
    }
    
    @Override
    public ROWID getROWID(final String s) throws SQLException {
        return this.getROWID(this.findColumn(s));
    }
    
    @Override
    public STRUCT getSTRUCT(final String s) throws SQLException {
        return this.getSTRUCT(this.findColumn(s));
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final String s) throws SQLException {
        return this.getTIMESTAMPLTZ(this.findColumn(s));
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final String s) throws SQLException {
        return this.getTIMESTAMPTZ(this.findColumn(s));
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final String s) throws SQLException {
        return this.getTIMESTAMP(this.findColumn(s));
    }
    
    @Override
    public InputStream getAsciiStream(final String s) throws SQLException {
        return this.getAsciiStream(this.findColumn(s));
    }
    
    @Override
    public InputStream getBinaryStream(final String s) throws SQLException {
        return this.getBinaryStream(this.findColumn(s));
    }
    
    @Override
    public Reader getCharacterStream(final String s) throws SQLException {
        return this.getCharacterStream(this.findColumn(s));
    }
    
    @Override
    public Reader getNCharacterStream(final String s) throws SQLException {
        return this.getNCharacterStream(this.findColumn(s));
    }
    
    @Override
    public InputStream getUnicodeStream(final String s) throws SQLException {
        return this.getUnicodeStream(this.findColumn(s));
    }
    
    @Override
    public void updateArray(final String s, final Array array) throws SQLException {
        this.updateArray(this.findColumn(s), array);
    }
    
    @Override
    public void updateBigDecimal(final String s, final BigDecimal bigDecimal) throws SQLException {
        this.updateBigDecimal(this.findColumn(s), bigDecimal);
    }
    
    @Override
    public void updateBlob(final String s, final Blob blob) throws SQLException {
        this.updateBlob(this.findColumn(s), blob);
    }
    
    @Override
    public void updateBoolean(final String s, final boolean b) throws SQLException {
        this.updateBoolean(this.findColumn(s), b);
    }
    
    @Override
    public void updateByte(final String s, final byte b) throws SQLException {
        this.updateByte(this.findColumn(s), b);
    }
    
    @Override
    public void updateBytes(final String s, final byte[] array) throws SQLException {
        this.updateBytes(this.findColumn(s), array);
    }
    
    @Override
    public void updateClob(final String s, final Clob clob) throws SQLException {
        this.updateClob(this.findColumn(s), clob);
    }
    
    @Override
    public void updateDate(final String s, final Date date) throws SQLException {
        this.updateDate(this.findColumn(s), date);
    }
    
    public void updateDate(final String s, final Date date, final Calendar calendar) throws SQLException {
        this.updateDate(this.findColumn(s), date, calendar);
    }
    
    @Override
    public void updateDouble(final String s, final double n) throws SQLException {
        this.updateDouble(this.findColumn(s), n);
    }
    
    @Override
    public void updateFloat(final String s, final float n) throws SQLException {
        this.updateFloat(this.findColumn(s), n);
    }
    
    @Override
    public void updateInt(final String s, final int n) throws SQLException {
        this.updateInt(this.findColumn(s), n);
    }
    
    @Override
    public void updateLong(final String s, final long n) throws SQLException {
        this.updateLong(this.findColumn(s), n);
    }
    
    @Override
    public void updateNClob(final String s, final NClob nClob) throws SQLException {
        this.updateNClob(this.findColumn(s), nClob);
    }
    
    @Override
    public void updateNString(final String s, final String s2) throws SQLException {
        this.updateNString(this.findColumn(s), s2);
    }
    
    @Override
    public void updateObject(final String s, final Object o) throws SQLException {
        this.updateObject(this.findColumn(s), o);
    }
    
    @Override
    public void updateObject(final String s, final Object o, final int n) throws SQLException {
        this.updateObject(this.findColumn(s), o, n);
    }
    
    @Override
    public void updateRef(final String s, final Ref ref) throws SQLException {
        this.updateRef(this.findColumn(s), ref);
    }
    
    @Override
    public void updateRowId(final String s, final RowId rowId) throws SQLException {
        this.updateRowId(this.findColumn(s), rowId);
    }
    
    @Override
    public void updateShort(final String s, final short n) throws SQLException {
        this.updateShort(this.findColumn(s), n);
    }
    
    @Override
    public void updateSQLXML(final String s, final SQLXML sqlxml) throws SQLException {
        this.updateSQLXML(this.findColumn(s), sqlxml);
    }
    
    @Override
    public void updateString(final String s, final String s2) throws SQLException {
        this.updateString(this.findColumn(s), s2);
    }
    
    @Override
    public void updateTime(final String s, final Time time) throws SQLException {
        this.updateTime(this.findColumn(s), time);
    }
    
    public void updateTime(final String s, final Time time, final Calendar calendar) throws SQLException {
        this.updateTime(this.findColumn(s), time, calendar);
    }
    
    @Override
    public void updateTimestamp(final String s, final Timestamp timestamp) throws SQLException {
        this.updateTimestamp(this.findColumn(s), timestamp);
    }
    
    public void updateTimestamp(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.updateTimestamp(this.findColumn(s), timestamp, calendar);
    }
    
    public void updateURL(final String s, final URL url) throws SQLException {
        this.updateURL(this.findColumn(s), url);
    }
    
    @Override
    public void updateARRAY(final String s, final ARRAY array) throws SQLException {
        this.updateARRAY(this.findColumn(s), array);
    }
    
    @Override
    public void updateBFILE(final String s, final BFILE bfile) throws SQLException {
        this.updateBFILE(this.findColumn(s), bfile);
    }
    
    @Override
    public void updateBfile(final String s, final BFILE bfile) throws SQLException {
        this.updateBfile(this.findColumn(s), bfile);
    }
    
    public void updateBinaryFloat(final String s, final float n) throws SQLException {
        this.updateBinaryFloat(this.findColumn(s), n);
    }
    
    public void updateBinaryFloat(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        this.updateBinaryFloat(this.findColumn(s), binary_FLOAT);
    }
    
    public void updateBinaryDouble(final String s, final double n) throws SQLException {
        this.updateBinaryDouble(this.findColumn(s), n);
    }
    
    public void updateBinaryDouble(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        this.updateBinaryDouble(this.findColumn(s), binary_DOUBLE);
    }
    
    @Override
    public void updateBLOB(final String s, final BLOB blob) throws SQLException {
        this.updateBLOB(this.findColumn(s), blob);
    }
    
    @Override
    public void updateCHAR(final String s, final CHAR char1) throws SQLException {
        this.updateCHAR(this.findColumn(s), char1);
    }
    
    @Override
    public void updateCLOB(final String s, final CLOB clob) throws SQLException {
        this.updateCLOB(this.findColumn(s), clob);
    }
    
    public void updateCursor(final String s, final ResultSet set) throws SQLException {
        this.updateCursor(this.findColumn(s), set);
    }
    
    @Override
    public void updateCustomDatum(final String s, final CustomDatum customDatum) throws SQLException {
        this.updateCustomDatum(this.findColumn(s), customDatum);
    }
    
    @Override
    public void updateDATE(final String s, final DATE date) throws SQLException {
        this.updateDATE(this.findColumn(s), date);
    }
    
    public void updateFixedCHAR(final String s, final String s2) throws SQLException {
        this.updateFixedCHAR(this.findColumn(s), s2);
    }
    
    @Override
    public void updateINTERVALDS(final String s, final INTERVALDS intervalds) throws SQLException {
        this.updateINTERVALDS(this.findColumn(s), intervalds);
    }
    
    @Override
    public void updateINTERVALYM(final String s, final INTERVALYM intervalym) throws SQLException {
        this.updateINTERVALYM(this.findColumn(s), intervalym);
    }
    
    @Override
    public void updateNUMBER(final String s, final NUMBER number) throws SQLException {
        this.updateNUMBER(this.findColumn(s), number);
    }
    
    public void updateOPAQUE(final String s, final OPAQUE opaque) throws SQLException {
        this.updateOPAQUE(this.findColumn(s), opaque);
    }
    
    @Override
    public void updateOracleObject(final String s, final Datum datum) throws SQLException {
        this.updateOracleObject(this.findColumn(s), datum);
    }
    
    @Override
    public void updateORAData(final String s, final ORAData oraData) throws SQLException {
        this.updateORAData(this.findColumn(s), oraData);
    }
    
    @Override
    public void updateRAW(final String s, final RAW raw) throws SQLException {
        this.updateRAW(this.findColumn(s), raw);
    }
    
    @Override
    public void updateREF(final String s, final REF ref) throws SQLException {
        this.updateREF(this.findColumn(s), ref);
    }
    
    public void updateRefType(final String s, final REF ref) throws SQLException {
        this.updateRefType(this.findColumn(s), ref);
    }
    
    @Override
    public void updateROWID(final String s, final ROWID rowid) throws SQLException {
        this.updateROWID(this.findColumn(s), rowid);
    }
    
    @Override
    public void updateSTRUCT(final String s, final STRUCT struct) throws SQLException {
        this.updateSTRUCT(this.findColumn(s), struct);
    }
    
    @Override
    public void updateTIMESTAMPLTZ(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        this.updateTIMESTAMPLTZ(this.findColumn(s), timestampltz);
    }
    
    @Override
    public void updateTIMESTAMPTZ(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        this.updateTIMESTAMPTZ(this.findColumn(s), timestamptz);
    }
    
    @Override
    public void updateTIMESTAMP(final String s, final TIMESTAMP timestamp) throws SQLException {
        this.updateTIMESTAMP(this.findColumn(s), timestamp);
    }
    
    @Override
    public void updateBlob(final String s, final InputStream inputStream) throws SQLException {
        this.updateBlob(this.findColumn(s), inputStream);
    }
    
    @Override
    public void updateBlob(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.updateBlob(this.findColumn(s), inputStream, n);
    }
    
    @Override
    public void updateClob(final String s, final Reader reader) throws SQLException {
        this.updateClob(this.findColumn(s), reader);
    }
    
    @Override
    public void updateClob(final String s, final Reader reader, final long n) throws SQLException {
        this.updateClob(this.findColumn(s), reader, n);
    }
    
    @Override
    public void updateNClob(final String s, final Reader reader) throws SQLException {
        this.updateNClob(this.findColumn(s), reader);
    }
    
    @Override
    public void updateNClob(final String s, final Reader reader, final long n) throws SQLException {
        this.updateNClob(this.findColumn(s), reader, n);
    }
    
    @Override
    public void updateAsciiStream(final String s, final InputStream inputStream) throws SQLException {
        this.updateAsciiStream(this.findColumn(s), inputStream);
    }
    
    @Override
    public void updateAsciiStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.updateAsciiStream(this.findColumn(s), inputStream, n);
    }
    
    @Override
    public void updateAsciiStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.updateAsciiStream(this.findColumn(s), inputStream, n);
    }
    
    @Override
    public void updateBinaryStream(final String s, final InputStream inputStream) throws SQLException {
        this.updateBinaryStream(this.findColumn(s), inputStream);
    }
    
    @Override
    public void updateBinaryStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.updateBinaryStream(this.findColumn(s), inputStream, n);
    }
    
    @Override
    public void updateBinaryStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.updateBinaryStream(this.findColumn(s), inputStream, n);
    }
    
    @Override
    public void updateCharacterStream(final String s, final Reader reader) throws SQLException {
        this.updateCharacterStream(this.findColumn(s), reader);
    }
    
    @Override
    public void updateCharacterStream(final String s, final Reader reader, final int n) throws SQLException {
        this.updateCharacterStream(this.findColumn(s), reader, n);
    }
    
    @Override
    public void updateCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        this.updateCharacterStream(this.findColumn(s), reader, n);
    }
    
    @Override
    public void updateNCharacterStream(final String s, final Reader reader) throws SQLException {
        this.updateNCharacterStream(this.findColumn(s), reader);
    }
    
    @Override
    public void updateNCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        this.updateNCharacterStream(this.findColumn(s), reader, n);
    }
    
    public void updateUnicodeStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.updateUnicodeStream(this.findColumn(s), inputStream, n);
    }
    
    @Override
    public abstract AuthorizationIndicator getAuthorizationIndicator(final int p0) throws SQLException;
    
    @Override
    public AuthorizationIndicator getAuthorizationIndicator(final String s) throws SQLException {
        return this.getAuthorizationIndicator(this.findColumn(s));
    }
    
    public abstract void setAutoRefetch(final boolean p0) throws SQLException;
    
    public abstract boolean getAutoRefetch() throws SQLException;
    
    @Override
    public abstract SQLWarning getWarnings() throws SQLException;
    
    @Override
    public abstract void clearWarnings() throws SQLException;
    
    @Override
    public abstract String getCursorName() throws SQLException;
    
    @Override
    public abstract ResultSetMetaData getMetaData() throws SQLException;
    
    @Override
    public abstract int findColumn(final String p0) throws SQLException;
    
    @Override
    public abstract boolean next() throws SQLException;
    
    @Override
    public abstract void close() throws SQLException;
    
    @Override
    public abstract boolean wasNull() throws SQLException;
    
    @Override
    public abstract boolean isBeforeFirst() throws SQLException;
    
    @Override
    public abstract boolean isAfterLast() throws SQLException;
    
    @Override
    public abstract boolean isFirst() throws SQLException;
    
    @Override
    public abstract boolean isLast() throws SQLException;
    
    @Override
    public abstract void beforeFirst() throws SQLException;
    
    @Override
    public abstract void afterLast() throws SQLException;
    
    @Override
    public abstract boolean first() throws SQLException;
    
    @Override
    public abstract boolean last() throws SQLException;
    
    @Override
    public abstract int getRow() throws SQLException;
    
    @Override
    public abstract boolean absolute(final int p0) throws SQLException;
    
    @Override
    public abstract boolean relative(final int p0) throws SQLException;
    
    @Override
    public abstract boolean previous() throws SQLException;
    
    @Override
    public abstract void setFetchDirection(final int p0) throws SQLException;
    
    @Override
    public abstract int getFetchDirection() throws SQLException;
    
    @Override
    public abstract void setFetchSize(final int p0) throws SQLException;
    
    @Override
    public abstract int getFetchSize() throws SQLException;
    
    @Override
    public abstract int getType() throws SQLException;
    
    @Override
    public abstract int getConcurrency() throws SQLException;
    
    @Override
    public abstract void insertRow() throws SQLException;
    
    @Override
    public abstract void updateRow() throws SQLException;
    
    @Override
    public abstract void deleteRow() throws SQLException;
    
    @Override
    public abstract void refreshRow() throws SQLException;
    
    @Override
    public abstract void moveToInsertRow() throws SQLException;
    
    @Override
    public abstract void cancelRowUpdates() throws SQLException;
    
    @Override
    public abstract void moveToCurrentRow() throws SQLException;
    
    @Override
    public abstract Statement getStatement() throws SQLException;
    
    @Override
    public abstract boolean rowUpdated() throws SQLException;
    
    @Override
    public abstract boolean rowInserted() throws SQLException;
    
    @Override
    public abstract boolean rowDeleted() throws SQLException;
    
    @Override
    public abstract void updateNull(final int p0) throws SQLException;
    
    @Override
    public void updateNull(final String s) throws SQLException {
        this.updateNull(this.findColumn(s));
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    abstract OracleStatement getOracleStatement() throws SQLException;
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
