// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.EventListener;
import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.aq.AQNotificationListener;
import java.util.Properties;
import oracle.jdbc.aq.AQNotificationRegistration;

class NTFAQRegistration extends NTFRegistration implements AQNotificationRegistration
{
    private final String name;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFAQRegistration(final int n, final boolean b, final String s, final String s2, final String s3, final int n2, final Properties properties, final String name, final short n3) {
        super(n, 1, b, s, s3, n2, properties, s2, n3);
        this.name = name;
    }
    
    @Override
    public void addListener(final AQNotificationListener aqNotificationListener, final Executor executor) throws SQLException {
        final NTFEventListener ntfEventListener = new NTFEventListener(aqNotificationListener);
        ntfEventListener.setExecutor(executor);
        this.addListener(ntfEventListener);
    }
    
    @Override
    public void addListener(final AQNotificationListener aqNotificationListener) throws SQLException {
        this.addListener(new NTFEventListener(aqNotificationListener));
    }
    
    @Override
    public void removeListener(final AQNotificationListener aqNotificationListener) throws SQLException {
        super.removeListener(aqNotificationListener);
    }
    
    @Override
    public String getQueueName() {
        return this.name;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
