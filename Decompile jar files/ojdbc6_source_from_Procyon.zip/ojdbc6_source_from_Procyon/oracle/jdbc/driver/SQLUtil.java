// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.Serializable;
import oracle.jdbc.oracore.OracleNamedType;
import oracle.jdbc.oracore.OracleTypeOPAQUE;
import oracle.jdbc.oracore.OracleTypeCOLLECTION;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.SQLName;
import oracle.sql.BFILE;
import oracle.sql.CLOB;
import oracle.sql.BLOB;
import java.sql.Time;
import java.sql.Date;
import java.sql.Timestamp;
import oracle.sql.REF;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.ArrayDescriptor;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.DATE;
import oracle.sql.ROWID;
import oracle.sql.RAW;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.NUMBER;
import oracle.sql.CHAR;
import oracle.sql.CharacterSet;
import oracle.sql.converter.CharacterSetMetaData;
import oracle.sql.OPAQUE;
import oracle.sql.ARRAY;
import java.sql.SQLData;
import java.sql.Connection;
import oracle.sql.STRUCT;
import oracle.sql.Datum;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.internal.OracleConnection;
import java.util.Hashtable;

public class SQLUtil
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    private static final int CLASS_NOT_FOUND = -1;
    private static final int CLASS_STRING = 0;
    private static final int CLASS_BOOLEAN = 1;
    private static final int CLASS_INTEGER = 2;
    private static final int CLASS_LONG = 3;
    private static final int CLASS_FLOAT = 4;
    private static final int CLASS_DOUBLE = 5;
    private static final int CLASS_BIGDECIMAL = 6;
    private static final int CLASS_DATE = 7;
    private static final int CLASS_TIME = 8;
    private static final int CLASS_TIMESTAMP = 9;
    private static final int TOTAL_CLASSES = 10;
    private static Hashtable classTable;
    
    public static Object SQLToJava(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final Class clazz, final Map map) throws SQLException {
        return SQLToJava(oracleConnection, makeDatum(oracleConnection, array, n, s, 0), clazz, map);
    }
    
    public static CustomDatum SQLToJava(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final CustomDatumFactory customDatumFactory) throws SQLException {
        return customDatumFactory.create(makeDatum(oracleConnection, array, n, s, 0), n);
    }
    
    public static ORAData SQLToJava(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final ORADataFactory oraDataFactory) throws SQLException {
        return oraDataFactory.create(makeDatum(oracleConnection, array, n, s, 0), n);
    }
    
    public static Object SQLToJava(final OracleConnection oracleConnection, final Datum datum, final Class clazz, final Map map) throws SQLException {
        Object o = null;
        if (datum instanceof STRUCT) {
            if (clazz == null) {
                o = ((map != null) ? ((STRUCT)datum).toJdbc(map) : datum.toJdbc());
            }
            else {
                o = ((map != null) ? ((STRUCT)datum).toClass(clazz, map) : ((STRUCT)datum).toClass(clazz));
            }
        }
        else if (clazz == null) {
            o = datum.toJdbc();
        }
        else {
            switch (classNumber(clazz)) {
                case 0: {
                    o = datum.stringValue();
                    break;
                }
                case 1: {
                    o = (datum.longValue() != 0L);
                    break;
                }
                case 2: {
                    o = (int)datum.longValue();
                    break;
                }
                case 3: {
                    o = datum.longValue();
                    break;
                }
                case 4: {
                    o = datum.bigDecimalValue().floatValue();
                    break;
                }
                case 5: {
                    o = datum.bigDecimalValue().doubleValue();
                    break;
                }
                case 6: {
                    o = datum.bigDecimalValue();
                    break;
                }
                case 7: {
                    o = datum.dateValue();
                    break;
                }
                case 8: {
                    o = datum.timeValue();
                    break;
                }
                case 9: {
                    o = datum.timestampValue();
                    break;
                }
                default: {
                    o = datum.toJdbc();
                    if (!clazz.isInstance(o)) {
                        final SQLException sqlException = DatabaseError.createSqlException(null, 59, "invalid data conversion");
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    break;
                }
            }
        }
        return o;
    }
    
    public static byte[] JavaToSQL(final OracleConnection oracleConnection, final Object o, final int n, final String s) throws SQLException {
        if (o == null) {
            return null;
        }
        Datum datum = null;
        if (o instanceof Datum) {
            datum = (Datum)o;
        }
        else if (o instanceof ORAData) {
            datum = ((ORAData)o).toDatum(oracleConnection);
        }
        else if (o instanceof CustomDatum) {
            datum = oracleConnection.toDatum((CustomDatum)o);
        }
        else if (o instanceof SQLData) {
            datum = STRUCT.toSTRUCT(o, oracleConnection);
        }
        if (datum != null) {
            if (!checkDatumType(datum, n, s)) {
                datum = null;
            }
        }
        else {
            datum = makeDatum(oracleConnection, o, n, s);
        }
        if (datum != null) {
            byte[] array;
            if (datum instanceof STRUCT) {
                array = ((STRUCT)datum).toBytes();
            }
            else if (datum instanceof ARRAY) {
                array = ((ARRAY)datum).toBytes();
            }
            else if (datum instanceof OPAQUE) {
                array = ((OPAQUE)datum).toBytes();
            }
            else {
                array = datum.shareBytes();
            }
            return array;
        }
        final SQLException sqlException = DatabaseError.createSqlException(null, 1, "attempt to convert a Datum to incompatible SQL type");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public static Datum makeDatum(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final int n2) throws SQLException {
        Datum datum = null;
        final int ratio = CharacterSetMetaData.getRatio(oracleConnection.getJdbcCsId(), oracleConnection.getDbCsId());
        switch (n) {
            case 96: {
                if (n2 != 0 && n2 < array.length && ratio == 1) {
                    datum = new CHAR(array, 0, n2, CharacterSet.make(oracleConnection.getJdbcCsId()));
                    break;
                }
                datum = new CHAR(array, CharacterSet.make(oracleConnection.getJdbcCsId()));
                break;
            }
            case 1:
            case 8: {
                datum = new CHAR(array, CharacterSet.make(oracleConnection.getJdbcCsId()));
                break;
            }
            case 2:
            case 6: {
                datum = new NUMBER(array);
                break;
            }
            case 100: {
                datum = new BINARY_FLOAT(array);
                break;
            }
            case 101: {
                datum = new BINARY_DOUBLE(array);
                break;
            }
            case 23:
            case 24: {
                datum = new RAW(array);
                break;
            }
            case 104: {
                datum = new ROWID(array);
                break;
            }
            case 102: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet?");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            case 12: {
                datum = new DATE(array);
                break;
            }
            case 182: {
                datum = new INTERVALYM(array);
                break;
            }
            case 183: {
                datum = new INTERVALDS(array);
                break;
            }
            case 180: {
                datum = new TIMESTAMP(array);
                break;
            }
            case 181: {
                datum = new TIMESTAMPTZ(array);
                break;
            }
            case 231: {
                datum = new TIMESTAMPLTZ(array);
                break;
            }
            case 113: {
                datum = oracleConnection.createBlob(array);
                break;
            }
            case 112: {
                datum = oracleConnection.createClob(array);
                break;
            }
            case 114: {
                datum = oracleConnection.createBfile(array);
                break;
            }
            case 109: {
                final TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(s, oracleConnection, array, 0L);
                if (typeDescriptor instanceof StructDescriptor) {
                    datum = new STRUCT((StructDescriptor)typeDescriptor, array, oracleConnection);
                }
                else if (typeDescriptor instanceof ArrayDescriptor) {
                    datum = new ARRAY((ArrayDescriptor)typeDescriptor, array, oracleConnection);
                }
                else if (typeDescriptor instanceof OpaqueDescriptor) {
                    datum = new OPAQUE((OpaqueDescriptor)typeDescriptor, array, oracleConnection);
                }
                break;
            }
            case 111: {
                final Object typeDescriptor2 = getTypeDescriptor(s, oracleConnection);
                if (typeDescriptor2 instanceof StructDescriptor) {
                    datum = new REF((StructDescriptor)typeDescriptor2, oracleConnection, array);
                    break;
                }
                final SQLException sqlException2 = DatabaseError.createSqlException(null, 1, "program error: REF points to a non-STRUCT");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            default: {
                final SQLException sqlException3 = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        return datum;
    }
    
    public static Datum makeNDatum(final OracleConnection oracleConnection, final byte[] array, final int n, final String s, final short n2, final int n3) throws SQLException {
        Datum clob = null;
        switch (n) {
            case 96: {
                final int n4 = n3 * CharacterSetMetaData.getRatio(oracleConnection.getNCharSet(), 1);
                if (n3 != 0 && n4 < array.length) {
                    clob = new CHAR(array, 0, n3, CharacterSet.make(oracleConnection.getNCharSet()));
                    break;
                }
                clob = new CHAR(array, CharacterSet.make(oracleConnection.getNCharSet()));
                break;
            }
            case 1:
            case 8: {
                clob = new CHAR(array, CharacterSet.make(oracleConnection.getNCharSet()));
                break;
            }
            case 112: {
                clob = oracleConnection.createClob(array, n2);
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return clob;
    }
    
    public static Datum makeDatum(final OracleConnection oracleConnection, final Object o, final int n, final String s) throws SQLException {
        return makeDatum(oracleConnection, o, n, s, false);
    }
    
    public static Datum makeDatum(final OracleConnection oracleConnection, final Object o, final int n, final String s, final boolean b) throws SQLException {
        Datum datum = null;
        switch (n) {
            case 1:
            case 8:
            case 96: {
                datum = new CHAR(o, CharacterSet.make(b ? oracleConnection.getNCharSet() : oracleConnection.getJdbcCsId()));
                break;
            }
            case 2:
            case 6: {
                datum = new NUMBER(o);
                break;
            }
            case 100: {
                datum = new BINARY_FLOAT((Float)o);
                break;
            }
            case 101: {
                datum = new BINARY_DOUBLE((Double)o);
                break;
            }
            case 23:
            case 24: {
                datum = new RAW(o);
                break;
            }
            case 104: {
                datum = new ROWID((byte[])o);
                break;
            }
            case 102: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            case 12: {
                datum = new DATE(o);
                break;
            }
            case 180: {
                if (o instanceof TIMESTAMP) {
                    datum = (Datum)o;
                    break;
                }
                if (o instanceof Timestamp) {
                    datum = new TIMESTAMP((Timestamp)o);
                    break;
                }
                if (o instanceof Date) {
                    datum = new TIMESTAMP((Date)o);
                    break;
                }
                if (o instanceof Time) {
                    datum = new TIMESTAMP((Time)o);
                    break;
                }
                if (o instanceof DATE) {
                    datum = new TIMESTAMP((DATE)o);
                    break;
                }
                if (o instanceof String) {
                    datum = new TIMESTAMP((String)o);
                    break;
                }
                if (o instanceof byte[]) {
                    datum = new TIMESTAMP((byte[])o);
                    break;
                }
                break;
            }
            case 181: {
                if (o instanceof TIMESTAMPTZ) {
                    datum = (Datum)o;
                    break;
                }
                if (o instanceof Timestamp) {
                    datum = new TIMESTAMPTZ(oracleConnection, (Timestamp)o);
                    break;
                }
                if (o instanceof Date) {
                    datum = new TIMESTAMPTZ(oracleConnection, (Date)o);
                    break;
                }
                if (o instanceof Time) {
                    datum = new TIMESTAMPTZ(oracleConnection, (Time)o);
                    break;
                }
                if (o instanceof DATE) {
                    datum = new TIMESTAMPTZ(oracleConnection, (DATE)o);
                    break;
                }
                if (o instanceof String) {
                    datum = new TIMESTAMPTZ(oracleConnection, (String)o);
                    break;
                }
                if (o instanceof byte[]) {
                    datum = new TIMESTAMPTZ((byte[])o);
                    break;
                }
                break;
            }
            case 231: {
                if (o instanceof TIMESTAMPLTZ) {
                    datum = (Datum)o;
                    break;
                }
                if (o instanceof Timestamp) {
                    datum = new TIMESTAMPLTZ(oracleConnection, (Timestamp)o);
                    break;
                }
                if (o instanceof Date) {
                    datum = new TIMESTAMPLTZ(oracleConnection, (Date)o);
                    break;
                }
                if (o instanceof Time) {
                    datum = new TIMESTAMPLTZ(oracleConnection, (Time)o);
                    break;
                }
                if (o instanceof DATE) {
                    datum = new TIMESTAMPLTZ(oracleConnection, (DATE)o);
                    break;
                }
                if (o instanceof String) {
                    datum = new TIMESTAMPLTZ(oracleConnection, (String)o);
                    break;
                }
                if (o instanceof byte[]) {
                    datum = new TIMESTAMPLTZ((byte[])o);
                    break;
                }
                break;
            }
            case 113: {
                if (o instanceof BLOB) {
                    datum = (Datum)o;
                }
                if (o instanceof byte[]) {
                    datum = new RAW((byte[])o);
                    break;
                }
                break;
            }
            case 112: {
                if (o instanceof CLOB) {
                    datum = (Datum)o;
                }
                if (o instanceof String) {
                    datum = new CHAR((String)o, CharacterSet.make(b ? oracleConnection.getNCharSet() : oracleConnection.getJdbcCsId()));
                    break;
                }
                break;
            }
            case 114: {
                if (o instanceof BFILE) {
                    datum = (Datum)o;
                    break;
                }
                break;
            }
            case 109: {
                if (o instanceof STRUCT || o instanceof ARRAY || o instanceof OPAQUE) {
                    datum = (Datum)o;
                    break;
                }
                break;
            }
            case 111: {
                if (o instanceof REF) {
                    datum = (Datum)o;
                    break;
                }
                break;
            }
        }
        if (datum == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(null, 1, "Unable to construct a Datum from the specified input");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return datum;
    }
    
    private static int classNumber(final Class key) {
        int intValue = -1;
        final Integer n = SQLUtil.classTable.get(key);
        if (n != null) {
            intValue = n;
        }
        return intValue;
    }
    
    public static Object getTypeDescriptor(final String s, final OracleConnection oracleConnection) throws SQLException {
        final SQLName sqlName = new SQLName(s, oracleConnection);
        final String name = sqlName.getName();
        final Object descriptor = oracleConnection.getDescriptor(name);
        if (descriptor != null) {
            return descriptor;
        }
        final OracleTypeADT oracleTypeADT = new OracleTypeADT(name, (Connection)oracleConnection);
        oracleTypeADT.init(oracleConnection);
        final OracleNamedType cleanup = oracleTypeADT.cleanup();
        Serializable s2 = null;
        switch (cleanup.getTypeCode()) {
            case 2003: {
                s2 = new ArrayDescriptor(sqlName, (OracleTypeCOLLECTION)cleanup, oracleConnection);
                break;
            }
            case 2002:
            case 2008: {
                s2 = new StructDescriptor(sqlName, (OracleTypeADT)cleanup, oracleConnection);
                break;
            }
            case 2007: {
                s2 = new OpaqueDescriptor(sqlName, (OracleTypeOPAQUE)cleanup, oracleConnection);
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 1, "Unrecognized type code");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        oracleConnection.putDescriptor(name, s2);
        return s2;
    }
    
    public static boolean checkDatumType(final Datum datum, final int n, final String anObject) throws SQLException {
        boolean b = false;
        switch (n) {
            case 1:
            case 8:
            case 96: {
                b = (datum instanceof CHAR);
                break;
            }
            case 2:
            case 6: {
                b = (datum instanceof NUMBER);
                break;
            }
            case 100: {
                b = (datum instanceof BINARY_FLOAT);
                break;
            }
            case 101: {
                b = (datum instanceof BINARY_DOUBLE);
                break;
            }
            case 23:
            case 24: {
                b = (datum instanceof RAW);
                break;
            }
            case 104: {
                b = (datum instanceof ROWID);
                break;
            }
            case 12: {
                b = (datum instanceof DATE);
                break;
            }
            case 180: {
                b = (datum instanceof TIMESTAMP);
                break;
            }
            case 181: {
                b = (datum instanceof TIMESTAMPTZ);
                break;
            }
            case 231: {
                b = (datum instanceof TIMESTAMPLTZ);
                break;
            }
            case 113: {
                b = (datum instanceof BLOB);
                break;
            }
            case 112: {
                b = (datum instanceof CLOB);
                break;
            }
            case 114: {
                b = (datum instanceof BFILE);
                break;
            }
            case 111: {
                b = (datum instanceof REF && ((REF)datum).getBaseTypeName().equals(anObject));
                break;
            }
            case 109: {
                if (datum instanceof STRUCT) {
                    b = ((STRUCT)datum).isInHierarchyOf(anObject);
                    break;
                }
                if (datum instanceof ARRAY) {
                    b = ((ARRAY)datum).getSQLTypeName().equals(anObject);
                    break;
                }
                if (datum instanceof OPAQUE) {
                    b = ((OPAQUE)datum).getSQLTypeName().equals(anObject);
                    break;
                }
                break;
            }
            default: {
                b = false;
                break;
            }
        }
        return b;
    }
    
    public static boolean implementsInterface(final Class clazz, final Class clazz2) {
        if (clazz == null) {
            return false;
        }
        if (clazz == clazz2) {
            return true;
        }
        final Class[] interfaces = clazz.getInterfaces();
        for (int i = 0; i < interfaces.length; ++i) {
            if (implementsInterface(interfaces[i], clazz2)) {
                return true;
            }
        }
        return implementsInterface(clazz.getSuperclass(), clazz2);
    }
    
    public static Datum makeOracleDatum(final OracleConnection oracleConnection, final Object o, final int n, final String s) throws SQLException {
        return makeOracleDatum(oracleConnection, o, n, s, false);
    }
    
    public static Datum makeOracleDatum(final OracleConnection oracleConnection, final Object o, final int n, final String s, final boolean b) throws SQLException {
        return makeDatum(oracleConnection, o, getInternalType(n), s, b);
    }
    
    public static int getInternalType(final int n) throws SQLException {
        int n2 = 0;
        switch (n) {
            case -7:
            case -6:
            case -5:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8: {
                n2 = 6;
                break;
            }
            case 100: {
                n2 = 100;
                break;
            }
            case 101: {
                n2 = 101;
                break;
            }
            case 999: {
                n2 = 999;
                break;
            }
            case 1: {
                n2 = 96;
                break;
            }
            case -15: {
                n2 = 96;
                break;
            }
            case 12: {
                n2 = 1;
                break;
            }
            case -9: {
                n2 = 1;
                break;
            }
            case -1: {
                n2 = 8;
                break;
            }
            case 91:
            case 92: {
                n2 = 12;
                break;
            }
            case -100:
            case 93: {
                n2 = 180;
                break;
            }
            case -101: {
                n2 = 181;
                break;
            }
            case -102: {
                n2 = 231;
                break;
            }
            case -104: {
                n2 = 183;
                break;
            }
            case -103: {
                n2 = 182;
                break;
            }
            case -3:
            case -2: {
                n2 = 23;
                break;
            }
            case -4: {
                n2 = 24;
                break;
            }
            case -8: {
                n2 = 104;
                break;
            }
            case 2004: {
                n2 = 113;
                break;
            }
            case 2005: {
                n2 = 112;
                break;
            }
            case 2011: {
                n2 = 112;
                break;
            }
            case -13: {
                n2 = 114;
                break;
            }
            case -10: {
                n2 = 102;
                break;
            }
            case 2002:
            case 2003:
            case 2007:
            case 2008: {
                n2 = 109;
                break;
            }
            case 2006: {
                n2 = 111;
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 4, "get_internal_type");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return n2;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
        SQLUtil.classTable = new Hashtable(10);
        try {
            SQLUtil.classTable.put(Class.forName("java.lang.String"), 0);
            SQLUtil.classTable.put(Class.forName("java.lang.Boolean"), 1);
            SQLUtil.classTable.put(Class.forName("java.lang.Integer"), 2);
            SQLUtil.classTable.put(Class.forName("java.lang.Long"), 3);
            SQLUtil.classTable.put(Class.forName("java.lang.Float"), 4);
            SQLUtil.classTable.put(Class.forName("java.lang.Double"), 5);
            SQLUtil.classTable.put(Class.forName("java.math.BigDecimal"), 6);
            SQLUtil.classTable.put(Class.forName("java.sql.Date"), 7);
            SQLUtil.classTable.put(Class.forName("java.sql.Time"), 8);
            SQLUtil.classTable.put(Class.forName("java.sql.Timestamp"), 9);
        }
        catch (ClassNotFoundException ex) {}
    }
}
