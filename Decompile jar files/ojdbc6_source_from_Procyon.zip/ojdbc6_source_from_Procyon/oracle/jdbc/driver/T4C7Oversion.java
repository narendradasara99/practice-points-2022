// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;

final class T4C7Oversion extends T4CTTIfun
{
    byte[] rdbmsVersion;
    private final boolean rdbmsVersionO2U = true;
    private final int bufLen = 256;
    private final boolean retVerLenO2U = true;
    int retVerLen;
    private final boolean retVerNumO2U = true;
    long retVerNum;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C7Oversion(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.rdbmsVersion = new byte[] { 78, 111, 116, 32, 100, 101, 116, 101, 114, 109, 105, 110, 101, 100, 32, 121, 101, 116 };
        this.retVerLen = 0;
        this.retVerNum = 0L;
        this.setFunCode((short)59);
    }
    
    void doOVERSION() throws SQLException, IOException {
        this.doRPC();
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        this.retVerLen = this.meg.unmarshalUB2();
        this.rdbmsVersion = this.meg.unmarshalCHR(this.retVerLen);
        this.retVerNum = this.meg.unmarshalUB4();
    }
    
    @Override
    void processRPA() throws SQLException {
        if (this.rdbmsVersion == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 438);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    byte[] getVersion() {
        return this.rdbmsVersion;
    }
    
    short getVersionNumber() {
        return (short)((int)((int)((int)(0 + (this.retVerNum >>> 24 & 0xFFL) * 1000L) + (this.retVerNum >>> 20 & 0xFL) * 100L) + (this.retVerNum >>> 12 & 0xFL) * 10L) + (this.retVerNum >>> 8 & 0xFL));
    }
    
    long getVersionNumberasIs() {
        return this.retVerNum;
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalO2U(true);
        this.meg.marshalSWORD(256);
        this.meg.marshalO2U(true);
        this.meg.marshalO2U(true);
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
