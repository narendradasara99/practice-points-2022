// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanInfo;
import javax.management.StandardMBean;

public class OracleDiagnosabilityMBean extends StandardMBean implements DiagnosabilityMXBean
{
    OracleDiagnosabilityMBean() {
        super(DiagnosabilityMXBean.class, true);
    }
    
    @Override
    public boolean getLoggingEnabled() {
        return OracleLog.isEnabled();
    }
    
    @Override
    public void setLoggingEnabled(final boolean trace) {
        OracleLog.setTrace(trace);
    }
    
    @Override
    public boolean stateManageable() {
        return false;
    }
    
    @Override
    public boolean statisticsProvider() {
        return false;
    }
    
    @Override
    protected String getDescription(final MBeanInfo mBeanInfo) {
        return DatabaseError.findMessage("DiagnosabilityMBeanDescription", this);
    }
    
    @Override
    protected String getDescription(final MBeanConstructorInfo mBeanConstructorInfo) {
        return DatabaseError.findMessage("DiagnosabilityMBeanConstructor()", this);
    }
    
    @Override
    protected String getDescription(final MBeanAttributeInfo info) {
        final String name = info.getName();
        if (name.equals("LoggingEnabled")) {
            return DatabaseError.findMessage("DiagnosabilityMBeanLoggingEnabledDescription", this);
        }
        if (name.equals("stateManageable")) {
            return DatabaseError.findMessage("DiagnosabilityMBeanStateManageableDescription", this);
        }
        if (name.equals("statisticsProvider")) {
            return DatabaseError.findMessage("DiagnosabilityMBeanStatisticsProviderDescription", this);
        }
        Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "Got a request to describe an unexpected  Attribute: " + name);
        return super.getDescription(info);
    }
}
