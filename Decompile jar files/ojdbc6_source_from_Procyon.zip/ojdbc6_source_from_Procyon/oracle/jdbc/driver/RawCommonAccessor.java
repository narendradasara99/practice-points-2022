// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.RAW;
import oracle.sql.Datum;
import java.util.Map;
import java.io.CharArrayReader;
import java.io.Reader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import oracle.jdbc.util.RepConversion;
import java.sql.SQLException;

class RawCommonAccessor extends Accessor
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, final int n3, final short n4, final int n5) throws SQLException {
        this.init(oracleStatement, n, n2, n4, false);
        this.initForDataAccess(n5, n3, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, int n3, final boolean b, final int n4, final int n5, final int n6, final int n7, final int n8, final short n9) throws SQLException {
        this.init(oracleStatement, n, n2, n9, false);
        this.initForDescribe(n, n3, b, n4, n5, n6, n7, n8, n9, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n3 == 0 || maxFieldSize < n3)) {
            n3 = maxFieldSize;
        }
        this.initForDataAccess(0, n3, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = Integer.MAX_VALUE;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        final byte[] bytes = this.getBytes(n);
        if (bytes == null) {
            return null;
        }
        if (bytes.length == 0) {
            return null;
        }
        return RepConversion.bArray2String(bytes);
    }
    
    @Override
    InputStream getAsciiStream(final int n) throws SQLException {
        final byte[] bytes = this.getBytes(n);
        if (bytes == null) {
            return null;
        }
        return this.statement.connection.conversion.ConvertStream(new ByteArrayInputStream(bytes), 2);
    }
    
    @Override
    InputStream getUnicodeStream(final int n) throws SQLException {
        final byte[] bytes = this.getBytes(n);
        if (bytes == null) {
            return null;
        }
        return this.statement.connection.conversion.ConvertStream(new ByteArrayInputStream(bytes), 3);
    }
    
    @Override
    Reader getCharacterStream(final int n) throws SQLException {
        final byte[] bytes = this.getBytes(n);
        if (bytes == null) {
            return null;
        }
        final int length = bytes.length;
        final char[] buf = new char[length << 1];
        final DBConversion conversion = this.statement.connection.conversion;
        return new CharArrayReader(buf, 0, DBConversion.RAWBytesToHexChars(bytes, length, buf));
    }
    
    @Override
    InputStream getBinaryStream(final int n) throws SQLException {
        final byte[] bytes = this.getBytes(n);
        if (bytes == null) {
            return null;
        }
        return new ByteArrayInputStream(bytes);
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getBytes(n);
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getBytes(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getRAW(n);
    }
    
    @Override
    RAW getRAW(final int n) throws SQLException {
        final byte[] bytes = this.getBytes(n);
        if (bytes == null) {
            return null;
        }
        return new RAW(bytes);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
