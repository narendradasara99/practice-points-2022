// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.aq.AQNotificationEvent;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import java.net.InetAddress;
import java.net.Socket;
import java.io.IOException;
import oracle.sql.CharacterSet;
import java.nio.channels.SelectionKey;
import java.util.Iterator;
import java.nio.channels.Selector;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

class NTFConnection extends Thread
{
    private static final int NS_HEADER_SIZE = 10;
    private static final int INTERRUPT_SIGNAL = -2;
    private SocketChannel channel;
    private ByteBuffer inBuffer;
    private ByteBuffer outBuffer;
    private int currentNSPacketLength;
    private int currentNSPacketType;
    private ByteBuffer currentNSPacketDataBuffer;
    private boolean needsToBeClosed;
    private NTFManager ntfManager;
    private Selector selector;
    private Iterator iterator;
    private SelectionKey aKey;
    int remotePort;
    String remoteAddress;
    String remoteName;
    int localPort;
    String localAddress;
    String localName;
    String connectionDescription;
    CharacterSet charset;
    static final int NSPTCN = 1;
    static final int NSPTAC = 2;
    static final int NSPTAK = 3;
    static final int NSPTRF = 4;
    static final int NSPTRD = 5;
    static final int NSPTDA = 6;
    static final int NSPTNL = 7;
    static final int NSPTAB = 9;
    static final int NSPTRS = 11;
    static final int NSPTMK = 12;
    static final int NSPTAT = 13;
    static final int NSPTCNL = 14;
    static final int NSPTHI = 19;
    static final short KPDNFY_TIMEOUT = 1;
    static final short KPDNFY_GROUPING = 2;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFConnection(final NTFManager ntfManager, final SocketChannel channel) {
        this.inBuffer = null;
        this.outBuffer = null;
        this.needsToBeClosed = false;
        this.selector = null;
        this.iterator = null;
        this.aKey = null;
        this.charset = null;
        try {
            this.ntfManager = ntfManager;
            (this.channel = channel).configureBlocking(false);
            this.inBuffer = ByteBuffer.allocate(4096);
            this.outBuffer = ByteBuffer.allocate(2048);
            final Socket socket = this.channel.socket();
            final InetAddress inetAddress = socket.getInetAddress();
            final InetAddress localAddress = socket.getLocalAddress();
            this.remotePort = socket.getPort();
            this.localPort = socket.getLocalPort();
            this.remoteAddress = inetAddress.getHostAddress();
            this.remoteName = inetAddress.getHostName();
            this.localAddress = localAddress.getHostAddress();
            this.localName = localAddress.getHostName();
            this.connectionDescription = "local=" + this.localName + "/" + this.localAddress + ":" + this.localPort + ", remote=" + this.remoteName + "/" + this.remoteAddress + ":" + this.remotePort;
        }
        catch (IOException ex) {}
    }
    
    @Override
    public void run() {
        try {
            this.selector = Selector.open();
            this.channel.register(this.selector, 1);
            int i = 0;
            this.inBuffer.limit(0);
            while (!this.needsToBeClosed) {
                if (!this.inBuffer.hasRemaining()) {
                    do {
                        i = this.readFromNetwork();
                    } while (i == 0);
                }
                if (i == -1) {
                    break;
                }
                if (i == -2) {
                    continue;
                }
                this.unmarshalOneNSPacket();
            }
            this.selector.close();
            this.channel.close();
        }
        catch (IOException ex) {}
    }
    
    private int readFromNetwork() throws IOException {
        this.inBuffer.compact();
        while (true) {
            if (this.iterator == null || !this.iterator.hasNext()) {
                this.selector.select();
                if (this.needsToBeClosed) {
                    return -2;
                }
                this.iterator = this.selector.selectedKeys().iterator();
            }
            else {
                this.aKey = this.iterator.next();
                if ((this.aKey.readyOps() & 0x1) == 0x1) {
                    final int read = this.channel.read(this.inBuffer);
                    if (read > 0) {
                        this.inBuffer.flip();
                    }
                    this.iterator.remove();
                    return read;
                }
                continue;
            }
        }
    }
    
    private void getNextNSPacket() throws IOException {
        while (!this.inBuffer.hasRemaining() || this.inBuffer.remaining() < 10) {
            this.readFromNetwork();
        }
        this.currentNSPacketLength = this.inBuffer.getShort();
        this.inBuffer.position(this.inBuffer.position() + 2);
        this.currentNSPacketType = this.inBuffer.get();
        this.inBuffer.position(this.inBuffer.position() + 5);
        while (this.inBuffer.remaining() < this.currentNSPacketLength - 10) {
            this.readFromNetwork();
        }
        final int limit = this.inBuffer.limit();
        final int n = this.inBuffer.position() + this.currentNSPacketLength - 10;
        this.inBuffer.limit(n);
        this.currentNSPacketDataBuffer = this.inBuffer.slice();
        this.inBuffer.limit(limit);
        this.inBuffer.position(n);
    }
    
    private void unmarshalOneNSPacket() throws IOException {
        this.getNextNSPacket();
        if (this.currentNSPacketDataBuffer.hasRemaining()) {
            switch (this.currentNSPacketType) {
                case 1: {
                    final byte[] src = { 0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 0, 0, 8, 0, 127, -1, 1, 0, 0, 0, 0, 24, 65, 1 };
                    this.outBuffer.clear();
                    this.outBuffer.put(src);
                    this.outBuffer.limit(24);
                    this.outBuffer.rewind();
                    this.channel.write(this.outBuffer);
                    break;
                }
                case 6: {
                    if (this.currentNSPacketDataBuffer.get(0) == -34 && this.currentNSPacketDataBuffer.get(1) == -83) {
                        final byte[] src2 = { 0, 127, 0, 0, 6, 0, 0, 0, 0, 0, -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, 0, 31, 0, 14, 0, 1, -34, -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0 };
                        this.outBuffer.clear();
                        this.outBuffer.put(src2);
                        this.outBuffer.limit(src2.length);
                        this.outBuffer.rewind();
                        this.channel.write(this.outBuffer);
                        break;
                    }
                    this.unmarshalNSDataPacket();
                    break;
                }
            }
        }
    }
    
    private void unmarshalNSDataPacket() throws IOException {
        final short short1 = this.readShort();
        final int int1 = this.readInt();
        this.readByte();
        this.readInt();
        final short short2 = this.readShort();
        if (this.charset == null || this.charset.getOracleId() != short2) {
            this.charset = CharacterSet.make(short2);
        }
        this.readByte();
        this.readInt();
        this.readShort();
        this.readByte();
        this.readInt();
        this.readShort();
        final int n = (int1 - 21) / 9;
        final int[] array = new int[n];
        for (int i = 0; i < n; ++i) {
            this.readByte();
            final int int2 = this.readInt();
            final byte[] array2 = new byte[int2];
            this.readBuffer(array2, 0, int2);
            for (int j = 0; j < int2; ++j) {
                if (j < 4) {
                    final int[] array3 = array;
                    final int n2 = i;
                    array3[n2] |= (array2[j] & 0xFF) << 8 * (int2 - j - 1);
                }
            }
        }
        NTFDCNEvent ntfdcnEvent = null;
        NTFAQEvent ntfaqEvent = null;
        int namespace = 0;
        short databaseVersion = 0;
        NTFRegistration[] array4 = null;
        if (short1 >= 2) {
            this.readShort();
            array4 = new NTFRegistration[array.length];
            for (int k = 0; k < array.length; ++k) {
                array4[k] = this.ntfManager.getRegistration(array[k]);
                if (array4[k] != null) {
                    namespace = array4[k].getNamespace();
                    databaseVersion = array4[k].getDatabaseVersion();
                }
            }
            if (namespace == 2) {
                ntfdcnEvent = new NTFDCNEvent(this, databaseVersion);
            }
            else if (namespace == 1) {
                ntfaqEvent = new NTFAQEvent(this, databaseVersion);
            }
            else if (namespace == 0) {}
        }
        if (short1 >= 3) {
            this.readShort();
            this.readInt();
            this.readByte();
            this.readInt();
            final short short3 = this.readShort();
            if (namespace == 2 && ntfdcnEvent != null) {
                ntfdcnEvent.setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType.getEventType(short3));
                if (short3 == 1) {
                    ntfdcnEvent.setEventType(DatabaseChangeEvent.EventType.DEREG);
                }
            }
            else if (namespace == 1 && ntfaqEvent != null) {
                ntfaqEvent.setAdditionalEventType(AQNotificationEvent.AdditionalEventType.getEventType(short3));
                if (short3 == 1) {
                    ntfaqEvent.setEventType(AQNotificationEvent.EventType.DEREG);
                }
            }
        }
        if (short1 > 3) {}
        if (array4 != null) {
            if (namespace == 2) {
                for (int l = 0; l < array4.length; ++l) {
                    if (array4[l] != null && ntfdcnEvent != null) {
                        array4[l].notify(ntfdcnEvent);
                    }
                }
            }
            if (namespace == 1) {
                for (int n3 = 0; n3 < array4.length; ++n3) {
                    if (array4[n3] != null && ntfaqEvent != null) {
                        array4[n3].notify(ntfaqEvent);
                    }
                }
            }
        }
    }
    
    void closeThisConnection() {
        this.needsToBeClosed = true;
    }
    
    byte readByte() throws IOException {
        byte b;
        if (this.currentNSPacketDataBuffer.hasRemaining()) {
            b = this.currentNSPacketDataBuffer.get();
        }
        else {
            this.getNextNSPacket();
            b = this.currentNSPacketDataBuffer.get();
        }
        return b;
    }
    
    short readShort() throws IOException {
        short short1;
        if (this.currentNSPacketDataBuffer.remaining() >= 2) {
            short1 = this.currentNSPacketDataBuffer.getShort();
        }
        else {
            short1 = (short)((this.readByte() & 0xFF) << 8 | (this.readByte() & 0xFF));
        }
        return short1;
    }
    
    int readInt() throws IOException {
        int int1;
        if (this.currentNSPacketDataBuffer.remaining() >= 4) {
            int1 = this.currentNSPacketDataBuffer.getInt();
        }
        else {
            int1 = ((this.readByte() & 0xFF) << 24 | (this.readByte() & 0xFF) << 16 | (this.readByte() & 0xFF) << 8 | (this.readByte() & 0xFF));
        }
        return int1;
    }
    
    long readLong() throws IOException {
        long long1;
        if (this.currentNSPacketDataBuffer.remaining() >= 8) {
            long1 = this.currentNSPacketDataBuffer.getLong();
        }
        else {
            long1 = ((long)(this.readByte() & 0xFF) << 56 | (long)(this.readByte() & 0xFF) << 48 | (long)(this.readByte() & 0xFF) << 40 | (long)(this.readByte() & 0xFF) << 32 | (long)(this.readByte() & 0xFF) << 24 | (long)(this.readByte() & 0xFF) << 16 | (long)(this.readByte() & 0xFF) << 8 | (long)(this.readByte() & 0xFF));
        }
        return long1;
    }
    
    void readBuffer(final byte[] dst, int offset, final int length) throws IOException {
        if (this.currentNSPacketDataBuffer.remaining() >= length) {
            this.currentNSPacketDataBuffer.get(dst, offset, length);
        }
        else {
            int i = 0;
            final int n = 0;
            final int remaining = this.currentNSPacketDataBuffer.remaining();
            this.currentNSPacketDataBuffer.get(dst, offset, remaining);
            offset += remaining;
            int n2 = n + remaining;
            while (i == 0) {
                this.getNextNSPacket();
                final int min = Math.min(this.currentNSPacketDataBuffer.remaining(), length - n2);
                this.currentNSPacketDataBuffer.get(dst, offset, min);
                offset += min;
                n2 += min;
                if (n2 == length) {
                    i = 1;
                }
            }
        }
    }
    
    private String packetToString(final ByteBuffer byteBuffer) throws IOException {
        int len = 0;
        final char[] array = new char[8];
        final StringBuffer sb = new StringBuffer();
        final int position = byteBuffer.position();
        while (byteBuffer.hasRemaining()) {
            final byte value = byteBuffer.get();
            String s = Integer.toHexString(value & 0xFF).toUpperCase();
            if (s.length() == 1) {
                s = "0" + s;
            }
            sb.append(s);
            sb.append(' ');
            if (value > 32 && value < 127) {
                array[len] = (char)value;
            }
            else {
                array[len] = '.';
            }
            if (++len == 8) {
                sb.append('|');
                sb.append(array);
                sb.append('|');
                sb.append('\n');
                len = 0;
            }
        }
        if (len != 0) {
            final int n = 8 - len;
            for (int i = 0; i < n * 3; ++i) {
                sb.append(' ');
            }
            sb.append('|');
            sb.append(array, 0, len);
            for (int j = 0; j < n; ++j) {
                sb.append(' ');
            }
            sb.append('|');
            sb.append('\n');
        }
        sb.append("\nEnd of Packet\n\n");
        byteBuffer.position(position);
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
