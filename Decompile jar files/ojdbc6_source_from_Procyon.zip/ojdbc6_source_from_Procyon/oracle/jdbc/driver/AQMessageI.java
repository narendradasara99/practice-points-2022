// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.OPAQUE;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.StructDescriptor;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.aq.AQMessageProperties;
import java.sql.SQLException;
import oracle.sql.TypeDescriptor;
import java.sql.Connection;
import oracle.xdb.XMLType;
import oracle.sql.RAW;
import oracle.sql.ANYDATA;
import oracle.sql.STRUCT;
import oracle.jdbc.aq.AQMessage;

class AQMessageI implements AQMessage
{
    private byte[] id;
    private AQMessagePropertiesI properties;
    private byte[] toid;
    private byte[] payload;
    private STRUCT payLoadSTRUCT;
    private ANYDATA payLoadANYDATA;
    private RAW payLoadRAW;
    private XMLType payLoadXMLType;
    private Connection conn;
    private String typeName;
    private TypeDescriptor sd;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    AQMessageI(final AQMessagePropertiesI properties, final Connection conn) {
        this.id = null;
        this.properties = null;
        this.toid = null;
        this.properties = properties;
        this.conn = conn;
    }
    
    AQMessageI(final AQMessagePropertiesI properties) throws SQLException {
        this.id = null;
        this.properties = null;
        this.toid = null;
        this.properties = properties;
    }
    
    void setTypeName(final String typeName) {
        this.typeName = typeName;
    }
    
    void setTypeDescriptor(final TypeDescriptor sd) {
        this.sd = sd;
    }
    
    @Override
    public byte[] getMessageId() {
        return this.id;
    }
    
    void setMessageId(final byte[] id) throws SQLException {
        this.id = id;
    }
    
    @Override
    public AQMessageProperties getMessageProperties() {
        return this.properties;
    }
    
    AQMessagePropertiesI getMessagePropertiesI() {
        return this.properties;
    }
    
    @Override
    public void setPayload(final byte[] payload) throws SQLException {
        this.payload = payload;
        this.toid = TypeDescriptor.RAWTOID;
    }
    
    @Override
    public void setPayload(final byte[] payload, final byte[] toid) throws SQLException {
        this.payload = payload;
        this.toid = toid;
    }
    
    @Override
    public void setPayload(final STRUCT payLoadSTRUCT) throws SQLException {
        this.payload = payLoadSTRUCT.toBytes();
        this.payLoadSTRUCT = payLoadSTRUCT;
        this.toid = payLoadSTRUCT.getDescriptor().getOracleTypeADT().getTOID();
    }
    
    @Override
    public void setPayload(final ANYDATA payLoadANYDATA) throws SQLException {
        this.payload = payLoadANYDATA.toDatum(this.conn).shareBytes();
        this.payLoadANYDATA = payLoadANYDATA;
        this.toid = TypeDescriptor.ANYDATATOID;
    }
    
    @Override
    public void setPayload(final RAW payLoadRAW) throws SQLException {
        this.payload = payLoadRAW.shareBytes();
        this.payLoadRAW = payLoadRAW;
        this.toid = TypeDescriptor.RAWTOID;
    }
    
    @Override
    public void setPayload(final XMLType payLoadXMLType) throws SQLException {
        this.payload = payLoadXMLType.toBytes();
        this.payLoadXMLType = payLoadXMLType;
        this.toid = TypeDescriptor.XMLTYPETOID;
    }
    
    @Override
    public byte[] getPayload() {
        return this.payload;
    }
    
    @Override
    public RAW getRAWPayload() throws SQLException {
        RAW raw;
        if (this.payLoadRAW != null) {
            raw = this.payLoadRAW;
        }
        else {
            if (!this.isRAWPayload()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 193);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.payLoadRAW = new RAW(this.payload);
            raw = this.payLoadRAW;
        }
        return raw;
    }
    
    @Override
    public boolean isRAWPayload() throws SQLException {
        if (this.toid == null || this.toid.length != 16) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 252);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return compareToid(this.toid, TypeDescriptor.RAWTOID);
    }
    
    @Override
    public STRUCT getSTRUCTPayload() throws SQLException {
        if (!this.isSTRUCTPayload()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 193);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        STRUCT payLoadSTRUCT;
        if (this.payLoadSTRUCT != null) {
            payLoadSTRUCT = this.payLoadSTRUCT;
        }
        else {
            if (this.sd == null) {
                this.typeName = OracleTypeADT.toid2typename(this.conn, this.toid);
                this.sd = TypeDescriptor.getTypeDescriptor(this.typeName, (oracle.jdbc.OracleConnection)this.conn);
            }
            if (!(this.sd instanceof StructDescriptor)) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 193);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            payLoadSTRUCT = new STRUCT((StructDescriptor)this.sd, this.payload, this.conn);
            this.payLoadSTRUCT = payLoadSTRUCT;
        }
        return payLoadSTRUCT;
    }
    
    @Override
    public boolean isSTRUCTPayload() throws SQLException {
        if (this.toid == null || this.toid.length != 16) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 252);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        boolean b = true;
        boolean b2 = true;
        for (int i = 0; i < 15; ++i) {
            if (this.toid[i] != 0) {
                b2 = false;
                break;
            }
        }
        if (b2 || this.isRAWPayload() || this.isANYDATAPayload()) {
            b = false;
        }
        return b;
    }
    
    @Override
    public ANYDATA getANYDATAPayload() throws SQLException {
        ANYDATA anydata;
        if (this.payLoadANYDATA != null) {
            anydata = this.payLoadANYDATA;
        }
        else {
            if (!this.isANYDATAPayload()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 193);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.payLoadANYDATA = new ANYDATA(new OPAQUE(OpaqueDescriptor.createDescriptor("SYS.ANYDATA", this.conn), this.payload, this.conn));
            anydata = this.payLoadANYDATA;
        }
        return anydata;
    }
    
    @Override
    public boolean isANYDATAPayload() throws SQLException {
        if (this.toid == null || this.toid.length != 16) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 252);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (this.typeName != null && this.typeName.equals("SYS.ANYDATA")) || compareToid(this.toid, TypeDescriptor.ANYDATATOID);
    }
    
    @Override
    public XMLType getXMLTypePayload() throws SQLException {
        XMLType xmlType;
        if (this.payLoadXMLType != null) {
            xmlType = this.payLoadXMLType;
        }
        else {
            if (!this.isXMLTypePayload()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 193);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.payLoadXMLType = XMLType.createXML(new OPAQUE(OpaqueDescriptor.createDescriptor("SYS.XMLTYPE", this.conn), this.payload, this.conn));
            xmlType = this.payLoadXMLType;
        }
        return xmlType;
    }
    
    @Override
    public boolean isXMLTypePayload() throws SQLException {
        if (this.toid == null || this.toid.length != 16) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 252);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (this.typeName != null && this.typeName.equals("SYS.XMLTYPE")) || compareToid(this.toid, TypeDescriptor.XMLTYPETOID);
    }
    
    @Override
    public byte[] getPayloadTOID() {
        return this.toid;
    }
    
    static boolean compareToid(final byte[] array, final byte[] array2) {
        boolean b = false;
        if (array != null) {
            if (array == array2) {
                b = true;
            }
            else if (array.length == array2.length) {
                boolean b2 = true;
                for (int i = 0; i < array.length; ++i) {
                    if (array[i] != array2[i]) {
                        b2 = false;
                        break;
                    }
                }
                if (b2) {
                    b = true;
                }
            }
        }
        return b;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("Message Properties={");
        sb.append(this.properties);
        sb.append("} ");
        return sb.toString();
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
