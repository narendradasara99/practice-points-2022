// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.XSAttribute;

class XSAttributeI extends XSAttribute
{
    String attributeName;
    byte[] attributeNameBytes;
    String attributeValue;
    byte[] attributeValueBytes;
    String attributeDefaultValue;
    byte[] attributeDefaultValueBytes;
    long flag;
    
    XSAttributeI() {
        this.attributeName = null;
        this.attributeValue = null;
        this.attributeDefaultValue = null;
        this.flag = 0L;
    }
    
    @Override
    public void setAttributeName(final String attributeName) throws SQLException {
        this.attributeName = attributeName;
    }
    
    void doCharConversion(final DBConversion dbConversion) throws SQLException {
        if (this.attributeName != null) {
            this.attributeNameBytes = dbConversion.StringToCharBytes(this.attributeName);
        }
        else {
            this.attributeNameBytes = null;
        }
        if (this.attributeValue != null) {
            this.attributeValueBytes = dbConversion.StringToCharBytes(this.attributeValue);
        }
        else {
            this.attributeValueBytes = null;
        }
        if (this.attributeDefaultValue != null) {
            this.attributeDefaultValueBytes = dbConversion.StringToCharBytes(this.attributeDefaultValue);
        }
        else {
            this.attributeDefaultValueBytes = null;
        }
    }
    
    @Override
    public void setAttributeValue(final String attributeValue) throws SQLException {
        this.attributeValue = attributeValue;
    }
    
    @Override
    public void setAttributeDefaultValue(final String attributeDefaultValue) throws SQLException {
        this.attributeDefaultValue = attributeDefaultValue;
    }
    
    @Override
    public void setFlag(final long flag) throws SQLException {
        this.flag = flag;
    }
    
    @Override
    public String getAttributeName() {
        return this.attributeName;
    }
    
    @Override
    public String getAttributeValue() {
        return this.attributeValue;
    }
    
    @Override
    public String getAttributeDefaultValue() {
        return this.attributeDefaultValue;
    }
    
    @Override
    public long getFlag() {
        return this.flag;
    }
    
    void marshal(final T4CMAREngine t4CMAREngine) throws IOException {
        if (this.attributeNameBytes != null) {
            t4CMAREngine.marshalUB4(this.attributeNameBytes.length);
            t4CMAREngine.marshalCLR(this.attributeNameBytes, this.attributeNameBytes.length);
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
        if (this.attributeValueBytes != null) {
            t4CMAREngine.marshalUB4(this.attributeValueBytes.length);
            t4CMAREngine.marshalCLR(this.attributeValueBytes, this.attributeValueBytes.length);
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
        if (this.attributeDefaultValueBytes != null) {
            t4CMAREngine.marshalUB4(this.attributeDefaultValueBytes.length);
            t4CMAREngine.marshalCLR(this.attributeDefaultValueBytes, this.attributeDefaultValueBytes.length);
        }
        else {
            t4CMAREngine.marshalUB4(0L);
        }
        t4CMAREngine.marshalUB4(this.flag);
    }
    
    static XSAttributeI unmarshal(final T4CMAREngine t4CMAREngine) throws SQLException, IOException {
        final int[] array = { 0 };
        String charBytesToString = null;
        String charBytesToString2 = null;
        String charBytesToString3 = null;
        final int n = (int)t4CMAREngine.unmarshalUB4();
        if (n > 0) {
            final byte[] array2 = new byte[n];
            t4CMAREngine.unmarshalCLR(array2, 0, array);
            charBytesToString = t4CMAREngine.conv.CharBytesToString(array2, array[0]);
        }
        final int n2 = (int)t4CMAREngine.unmarshalUB4();
        if (n2 > 0) {
            final byte[] array3 = new byte[n2];
            t4CMAREngine.unmarshalCLR(array3, 0, array);
            charBytesToString2 = t4CMAREngine.conv.CharBytesToString(array3, array[0]);
        }
        final int n3 = (int)t4CMAREngine.unmarshalUB4();
        if (n3 > 0) {
            final byte[] array4 = new byte[n3];
            t4CMAREngine.unmarshalCLR(array4, 0, array);
            charBytesToString3 = t4CMAREngine.conv.CharBytesToString(array4, array[0]);
        }
        final long unmarshalUB4 = t4CMAREngine.unmarshalUB4();
        final XSAttributeI xsAttributeI = new XSAttributeI();
        xsAttributeI.setAttributeName(charBytesToString);
        xsAttributeI.setAttributeValue(charBytesToString2);
        xsAttributeI.setAttributeDefaultValue(charBytesToString3);
        xsAttributeI.setFlag(unmarshalUB4);
        return xsAttributeI;
    }
}
