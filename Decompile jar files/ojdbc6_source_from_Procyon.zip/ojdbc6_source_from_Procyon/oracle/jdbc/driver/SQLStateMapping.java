// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.sql.SQLRecoverableException;
import java.sql.ClientInfoStatus;
import java.util.Map;
import java.sql.SQLClientInfoException;
import java.sql.SQLTransientConnectionException;
import java.sql.SQLTransactionRollbackException;
import java.sql.SQLTimeoutException;
import java.sql.SQLSyntaxErrorException;
import java.sql.SQLNonTransientConnectionException;
import java.sql.SQLInvalidAuthorizationSpecException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLDataException;
import java.sql.SQLTransientException;
import java.sql.SQLNonTransientException;
import java.sql.SQLException;

class SQLStateMapping
{
    public static final int SQLEXCEPTION = 0;
    public static final int SQLNONTRANSIENTEXCEPTION = 1;
    public static final int SQLTRANSIENTEXCEPTION = 2;
    public static final int SQLDATAEXCEPTION = 3;
    public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
    public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
    public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
    public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
    public static final int SQLSYNTAXERROREXCEPTION = 8;
    public static final int SQLTIMEOUTEXCEPTION = 9;
    public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
    public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
    public static final int SQLCLIENTINFOEXCEPTION = 12;
    public static final int SQLRECOVERABLEEXCEPTION = 13;
    int low;
    int high;
    public String sqlState;
    public int exception;
    static final String mappingResource = "errorMap.xml";
    static SQLStateMapping[] all;
    private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public SQLStateMapping(final int low, final int high, final String sqlState, final int exception) {
        this.low = low;
        this.sqlState = sqlState;
        this.exception = exception;
        this.high = high;
    }
    
    public boolean isIncluded(final int n) {
        return this.low <= n && n <= this.high;
    }
    
    public SQLException newSQLException(final String reason, final int vendorCode) {
        switch (this.exception) {
            case 0: {
                return new SQLException(reason, this.sqlState, vendorCode);
            }
            case 1: {
                return new SQLNonTransientException(reason, this.sqlState, vendorCode);
            }
            case 2: {
                return new SQLTransientException(reason, this.sqlState, vendorCode);
            }
            case 3: {
                return new SQLDataException(reason, this.sqlState, vendorCode);
            }
            case 4: {
                return new SQLFeatureNotSupportedException(reason, this.sqlState, vendorCode);
            }
            case 5: {
                return new SQLIntegrityConstraintViolationException(reason, this.sqlState, vendorCode);
            }
            case 6: {
                return new SQLInvalidAuthorizationSpecException(reason, this.sqlState, vendorCode);
            }
            case 7: {
                return new SQLNonTransientConnectionException(reason, this.sqlState, vendorCode);
            }
            case 8: {
                return new SQLSyntaxErrorException(reason, this.sqlState, vendorCode);
            }
            case 9: {
                return new SQLTimeoutException(reason, this.sqlState, vendorCode);
            }
            case 10: {
                return new SQLTransactionRollbackException(reason, this.sqlState, vendorCode);
            }
            case 11: {
                return new SQLTransientConnectionException(reason, this.sqlState, vendorCode);
            }
            case 12: {
                return new SQLClientInfoException(reason, this.sqlState, vendorCode, (Map<String, ClientInfoStatus>)null);
            }
            case 13: {
                return new SQLRecoverableException(reason, this.sqlState, vendorCode);
            }
            default: {
                return new SQLException(reason, this.sqlState, vendorCode);
            }
        }
    }
    
    boolean lessThan(final SQLStateMapping sqlStateMapping) {
        if (this.low < sqlStateMapping.low) {
            return this.high < sqlStateMapping.high;
        }
        return this.high <= sqlStateMapping.high;
    }
    
    @Override
    public String toString() {
        return super.toString() + "(" + this.low + ", " + this.high + ", " + this.sqlState + ", " + this.exception + ")";
    }
    
    public static void main(final String[] array) throws IOException {
        final SQLStateMapping[] doGetMappings = doGetMappings();
        System.out.println("a\t" + doGetMappings);
        for (int i = 0; i < doGetMappings.length; ++i) {
            System.out.println("low:\t" + doGetMappings[i].low + "\thigh:\t" + doGetMappings[i].high + "\tsqlState:\t" + doGetMappings[i].sqlState + "\tsqlException:\t" + doGetMappings[i].exception);
        }
    }
    
    static SQLStateMapping[] getMappings() {
        if (SQLStateMapping.all == null) {
            try {
                SQLStateMapping.all = doGetMappings();
            }
            catch (Throwable t) {
                SQLStateMapping.all = new SQLStateMapping[0];
            }
        }
        return SQLStateMapping.all;
    }
    
    static SQLStateMapping[] doGetMappings() throws IOException {
        final InputStream resourceAsStream = SQLStateMapping.class.getResourceAsStream("errorMap.xml");
        final ArrayList list = new ArrayList(128);
        load(resourceAsStream, list);
        return list.toArray(new SQLStateMapping[0]);
    }
    
    static void load(final InputStream in, final List list) throws IOException {
        final Tokenizer tokenizer = new Tokenizer(new BufferedReader(new InputStreamReader(in)));
        int int1 = -1;
        int int2 = -1;
        String s = null;
        int value = -1;
        String s2 = null;
        int i = 0;
        String next;
        while ((next = tokenizer.next()) != null) {
            switch (i) {
                case 0: {
                    if (next.equals("<")) {
                        i = 1;
                        continue;
                    }
                    continue;
                }
                case 1: {
                    if (next.equals("!")) {
                        i = 2;
                        continue;
                    }
                    if (next.equals("oraErrorSqlStateSqlExceptionMapping")) {
                        i = 6;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
                }
                case 2: {
                    if (next.equals("-")) {
                        i = 3;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
                }
                case 3: {
                    if (next.equals("-")) {
                        i = 4;
                        continue;
                    }
                    continue;
                }
                case 4: {
                    if (next.equals("-")) {
                        i = 5;
                        continue;
                    }
                    i = 3;
                    continue;
                }
                case 5: {
                    if (next.equals(">")) {
                        i = 1;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
                }
                case 6: {
                    if (next.equals(">")) {
                        i = 7;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
                }
                case 7: {
                    if (next.equals("<")) {
                        i = 8;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"<\".");
                }
                case 8: {
                    if (next.equals("!")) {
                        i = 9;
                        continue;
                    }
                    if (next.equals("error")) {
                        i = 14;
                        continue;
                    }
                    if (next.equals("/")) {
                        i = 16;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".");
                }
                case 9: {
                    if (next.equals("-")) {
                        i = 10;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
                }
                case 10: {
                    if (next.equals("-")) {
                        i = 11;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
                }
                case 11: {
                    if (next.equals("-")) {
                        i = 12;
                        continue;
                    }
                    continue;
                }
                case 12: {
                    if (next.equals("-")) {
                        i = 13;
                        continue;
                    }
                    i = 11;
                    continue;
                }
                case 13: {
                    if (next.equals(">")) {
                        i = 7;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
                }
                case 14: {
                    if (next.equals("/")) {
                        i = 15;
                        continue;
                    }
                    if (next.equals("oraErrorFrom")) {
                        i = 19;
                        continue;
                    }
                    if (next.equals("oraErrorTo")) {
                        i = 21;
                        continue;
                    }
                    if (next.equals("sqlState")) {
                        i = 23;
                        continue;
                    }
                    if (next.equals("sqlException")) {
                        i = 25;
                        continue;
                    }
                    if (next.equals("comment")) {
                        i = 27;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of " + "\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", " + "\"sqlException\", \"comment\", \"/\".");
                }
                case 15: {
                    if (next.equals(">")) {
                        try {
                            createOne(list, int1, int2, s, value, s2);
                        }
                        catch (IOException ex) {
                            throw new IOException("Invalid error element at line " + tokenizer.lineno + " of errorMap.xml. " + ex.getMessage());
                        }
                        int1 = -1;
                        int2 = -1;
                        s = null;
                        value = -1;
                        s2 = null;
                        i = 7;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
                }
                case 16: {
                    if (next.equals("oraErrorSqlStateSqlExceptionMapping")) {
                        i = 17;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
                }
                case 17: {
                    if (next.equals(">")) {
                        i = 18;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
                }
                case 18: {
                    continue;
                }
                case 19: {
                    if (next.equals("=")) {
                        i = 20;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
                }
                case 20: {
                    try {
                        int1 = Integer.parseInt(next);
                    }
                    catch (NumberFormatException ex2) {
                        throw new IOException("Unexpected value \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
                    }
                    i = 14;
                    continue;
                }
                case 21: {
                    if (next.equals("=")) {
                        i = 22;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
                }
                case 22: {
                    try {
                        int2 = Integer.parseInt(next);
                    }
                    catch (NumberFormatException ex3) {
                        throw new IOException("Unexpected value \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
                    }
                    i = 14;
                    continue;
                }
                case 23: {
                    if (next.equals("=")) {
                        i = 24;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
                }
                case 24: {
                    s = next;
                    i = 14;
                    continue;
                }
                case 25: {
                    if (next.equals("=")) {
                        i = 26;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
                }
                case 26: {
                    try {
                        value = valueOf(next);
                    }
                    catch (Exception ex4) {
                        throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected SQLException" + " subclass name.");
                    }
                    i = 14;
                    continue;
                }
                case 27: {
                    if (next.equals("=")) {
                        i = 28;
                        continue;
                    }
                    throw new IOException("Unexpected token \"" + next + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
                }
                case 28: {
                    s2 = next;
                    i = 14;
                    continue;
                }
                default: {
                    throw new IOException("Unknown parser state " + i + " at line " + tokenizer.lineno + " of errorMap.xml.");
                }
            }
        }
    }
    
    private static void createOne(final List list, final int n, int n2, final String s, final int n3, final String s2) throws IOException {
        if (n == -1) {
            throw new IOException("oraErrorFrom is a required attribute");
        }
        if (n2 == -1) {
            n2 = n;
        }
        if (s == null || s.length() == 0) {
            throw new IOException("sqlState is a required attribute");
        }
        if (n3 == -1) {
            throw new IOException("sqlException is a required attribute");
        }
        if (s2 == null || s2.length() < 8) {
            throw new IOException("a lengthy comment in required");
        }
        add(list, new SQLStateMapping(n, n2, s, n3));
    }
    
    static void add(final List list, final SQLStateMapping sqlStateMapping) {
        int size;
        for (size = list.size(); size > 0 && !list.get(size - 1).lessThan(sqlStateMapping); --size) {}
        list.add(size, sqlStateMapping);
    }
    
    static int valueOf(final String str) throws Exception {
        if (str.equalsIgnoreCase("SQLEXCEPTION")) {
            return 0;
        }
        if (str.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION")) {
            return 1;
        }
        if (str.equalsIgnoreCase("SQLTRANSIENTEXCEPTION")) {
            return 2;
        }
        if (str.equalsIgnoreCase("SQLDATAEXCEPTION")) {
            return 3;
        }
        if (str.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION")) {
            return 4;
        }
        if (str.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION")) {
            return 5;
        }
        if (str.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION")) {
            return 6;
        }
        if (str.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION")) {
            return 7;
        }
        if (str.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION")) {
            return 8;
        }
        if (str.equalsIgnoreCase("SQLTIMEOUTEXCEPTION")) {
            return 9;
        }
        if (str.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION")) {
            return 10;
        }
        if (str.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION")) {
            return 11;
        }
        if (str.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION")) {
            return 12;
        }
        if (str.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION")) {
            return 13;
        }
        throw new Exception("unexpected exception name: " + str);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    private static final class Tokenizer
    {
        int lineno;
        Reader r;
        int c;
        
        Tokenizer(final Reader r) throws IOException {
            this.lineno = 1;
            this.r = r;
            this.c = r.read();
        }
        
        String next() throws IOException {
            final StringBuffer sb = new StringBuffer(16);
            final boolean b = true;
            while (true) {
                while (this.c != -1) {
                    if (this.c == 10) {
                        ++this.lineno;
                    }
                    if (this.c <= 32 && b) {
                        this.c = this.r.read();
                    }
                    else {
                        if (this.c <= 32 && !b) {
                            this.c = this.r.read();
                        }
                        else if (this.c == 34) {
                            while ((this.c = this.r.read()) != 34) {
                                sb.append((char)this.c);
                            }
                            this.c = this.r.read();
                        }
                        else if ((48 <= this.c && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95) {
                            int n;
                            int read;
                            do {
                                sb.append((char)this.c);
                                n = 48;
                                read = this.r.read();
                                this.c = read;
                            } while ((n <= read && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95);
                        }
                        else {
                            sb.append((char)this.c);
                            this.c = this.r.read();
                        }
                        if (sb.length() > 0) {
                            return sb.toString();
                        }
                        return null;
                    }
                }
                continue;
            }
        }
    }
}
