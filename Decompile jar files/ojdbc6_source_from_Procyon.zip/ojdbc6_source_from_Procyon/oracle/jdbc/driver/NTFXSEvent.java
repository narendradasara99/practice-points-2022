// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.KeywordValueLong;
import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.XSEvent;

class NTFXSEvent extends XSEvent
{
    private final byte[] sid_kpuzxsss;
    private final KeywordValueLongI[] sess_kpuzxsss;
    private final int flg_kpuzxsss;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFXSEvent(final T4CConnection t4CConnection) throws SQLException, IOException {
        super(t4CConnection);
        final T4CMAREngine marshalEngine = t4CConnection.getMarshalEngine();
        this.sid_kpuzxsss = marshalEngine.unmarshalDALC();
        final int n = (int)marshalEngine.unmarshalUB4();
        final byte b = (byte)marshalEngine.unmarshalUB1();
        this.sess_kpuzxsss = new KeywordValueLongI[n];
        for (int i = 0; i < n; ++i) {
            this.sess_kpuzxsss[i] = KeywordValueLongI.unmarshal(marshalEngine);
        }
        this.flg_kpuzxsss = (int)marshalEngine.unmarshalUB4();
    }
    
    @Override
    public byte[] getSessionId() {
        return this.sid_kpuzxsss;
    }
    
    @Override
    public KeywordValueLong[] getDetails() {
        return this.sess_kpuzxsss;
    }
    
    @Override
    public int getFlags() {
        return this.flg_kpuzxsss;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("sid_kpuzxsss  : " + NTFAQEvent.byteBufferToHexString(this.sid_kpuzxsss, 50) + "\n");
        sb.append("sess_kpuzxsss : \n");
        sb.append("  size : " + this.sess_kpuzxsss.length + "\n");
        for (int i = 0; i < this.sess_kpuzxsss.length; ++i) {
            sb.append("  sess_kpuzxsss #" + i + " : \n");
            if (this.sess_kpuzxsss[i] == null) {
                sb.append("null\n");
            }
            else {
                sb.append(this.sess_kpuzxsss[i].toString());
            }
        }
        sb.append("flg_kpuzxsss  : " + this.flg_kpuzxsss + "\n");
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
