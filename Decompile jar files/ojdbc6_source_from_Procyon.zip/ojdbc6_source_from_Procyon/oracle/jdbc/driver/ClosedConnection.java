// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.CLOB;
import oracle.sql.BLOB;
import java.sql.Connection;
import oracle.jdbc.pool.OraclePooledConnection;
import java.sql.SQLException;

class ClosedConnection extends PhysicalConnection
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    ClosedConnection() {
        this.lifecycle = 4;
    }
    
    @Override
    void initializePassword(final String s) throws SQLException {
    }
    
    @Override
    OracleStatement RefCursorBytesToStatement(final byte[] array, final OracleStatement oracleStatement) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    int getDefaultStreamChunkSize() {
        return -1;
    }
    
    @Override
    short doGetVersionNumber() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    String doGetDatabaseProductVersion() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void doRollback() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void doCommit(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void doSetAutoCommit(final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void cancelOperationOnServer() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void doAbort() throws SQLException {
    }
    
    @Override
    void open(final OracleStatement oracleStatement) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    void logon() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void getPropertyForPooledConnection(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public BLOB createTemporaryBlob(final Connection connection, final boolean b, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public CLOB createTemporaryClob(final Connection connection, final boolean b, final int n, final short n2) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
