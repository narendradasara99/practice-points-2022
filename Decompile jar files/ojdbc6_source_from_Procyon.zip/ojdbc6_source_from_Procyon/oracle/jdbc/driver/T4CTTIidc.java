// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CTTIidc extends T4CTTIMsg
{
    T4CTTIkscn kpdqidcscn;
    T4CTTIqcinv[] kpdqidccinv;
    T4CTTIqcinv[] kpdqidcusr;
    long kpdqidcflg;
    
    T4CTTIidc(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)0);
    }
    
    void unmarshal() throws SQLException, IOException {
        (this.kpdqidcscn = new T4CTTIkscn(this.connection)).unmarshal();
        final int unmarshalSWORD = this.meg.unmarshalSWORD();
        final byte b = (byte)this.meg.unmarshalUB1();
        if (unmarshalSWORD > 0) {
            this.kpdqidccinv = new T4CTTIqcinv[unmarshalSWORD];
            for (int i = 0; i < unmarshalSWORD; ++i) {
                (this.kpdqidccinv[i] = new T4CTTIqcinv(this.connection)).unmarshal();
            }
        }
        else {
            this.kpdqidccinv = null;
        }
        final int unmarshalSWORD2 = this.meg.unmarshalSWORD();
        if (unmarshalSWORD2 > 0) {
            this.kpdqidcusr = new T4CTTIqcinv[unmarshalSWORD2];
            for (int j = 0; j < unmarshalSWORD2; ++j) {
                (this.kpdqidcusr[j] = new T4CTTIqcinv(this.connection)).unmarshal();
            }
        }
        else {
            this.kpdqidcusr = null;
        }
        this.kpdqidcflg = this.meg.unmarshalUB4();
    }
}
