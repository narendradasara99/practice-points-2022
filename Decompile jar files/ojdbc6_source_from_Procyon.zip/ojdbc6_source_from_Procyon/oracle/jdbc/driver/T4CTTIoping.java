// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import java.io.IOException;

final class T4CTTIoping extends T4CTTIfun
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIoping(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.setFunCode((short)147);
    }
    
    void doOPING() throws IOException, SQLException {
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
