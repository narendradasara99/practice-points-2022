// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.Reader;
import java.io.InputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.sql.SQLException;

class LongAccessor extends CharCommonAccessor
{
    OracleInputStream stream;
    int columnPosition;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    LongAccessor(final OracleStatement oracleStatement, final int columnPosition, final int n, final short n2, final int n3) throws SQLException {
        this.columnPosition = 0;
        this.init(oracleStatement, 8, 8, n2, false);
        this.columnPosition = columnPosition;
        this.initForDataAccess(n3, n, null);
    }
    
    LongAccessor(final OracleStatement oracleStatement, final int columnPosition, int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.columnPosition = 0;
        this.init(oracleStatement, 8, 8, n7, false);
        this.columnPosition = columnPosition;
        this.initForDescribe(8, n, b, n2, n3, n4, n5, n6, n7, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n == 0 || maxFieldSize < n)) {
            n = maxFieldSize;
        }
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.isStream = true;
        this.isColumnNumberAware = true;
        this.internalTypeMaxLength = Integer.MAX_VALUE;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.charLength = 0;
        this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
    }
    
    @Override
    OracleInputStream initForNewRow() throws SQLException {
        return this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
    }
    
    @Override
    void updateColumnNumber(int n) {
        ++n;
        this.columnPosition = n;
        if (this.stream != null) {
            this.stream.columnIndex = n;
        }
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        return this.getBytesInternal(n);
    }
    
    @Override
    byte[] getBytesInternal(final int n) throws SQLException {
        byte[] byteArray = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            if (this.stream != null) {
                if (this.stream.closed) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 27);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
                final byte[] b = new byte[1024];
                try {
                    int read;
                    while ((read = this.stream.read(b)) != -1) {
                        byteArrayOutputStream.write(b, 0, read);
                    }
                }
                catch (IOException ex) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                byteArray = byteArrayOutputStream.toByteArray();
            }
        }
        return byteArray;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = null;
        final byte[] bytes = this.getBytes(n);
        if (bytes != null) {
            final int min = Math.min(bytes.length, this.internalTypeMaxLength);
            if (min == 0) {
                s = "";
            }
            else if (this.formOfUse == 2) {
                s = this.statement.connection.conversion.NCharBytesToString(bytes, min);
            }
            else {
                s = this.statement.connection.conversion.CharBytesToString(bytes, min);
            }
        }
        return s;
    }
    
    @Override
    InputStream getAsciiStream(final int n) throws SQLException {
        InputStream convertStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1 && this.stream != null) {
            if (this.stream.closed) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 27);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            convertStream = this.statement.connection.conversion.ConvertStream(this.stream, 0);
        }
        return convertStream;
    }
    
    @Override
    InputStream getUnicodeStream(final int n) throws SQLException {
        InputStream convertStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1 && this.stream != null) {
            if (this.stream.closed) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 27);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            convertStream = this.statement.connection.conversion.ConvertStream(this.stream, 1);
        }
        return convertStream;
    }
    
    @Override
    Reader getCharacterStream(final int n) throws SQLException {
        Reader convertCharacterStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1 && this.stream != null) {
            if (this.stream.closed) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 27);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            convertCharacterStream = this.statement.connection.conversion.ConvertCharacterStream(this.stream, 9, this.formOfUse);
        }
        return convertCharacterStream;
    }
    
    @Override
    InputStream getBinaryStream(final int n) throws SQLException {
        InputStream convertStream = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1 && this.stream != null) {
            if (this.stream.closed) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 27);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            convertStream = this.statement.connection.conversion.ConvertStream(this.stream, 6);
        }
        return convertStream;
    }
    
    @Override
    public String toString() {
        return "LongAccessor@" + Integer.toHexString(this.hashCode()) + "{columnPosition = " + this.columnPosition + "}";
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
