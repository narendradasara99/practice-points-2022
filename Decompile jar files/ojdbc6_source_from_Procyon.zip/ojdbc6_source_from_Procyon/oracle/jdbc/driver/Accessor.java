// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLXML;
import java.sql.NClob;
import java.net.URL;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import java.io.Reader;
import java.util.Map;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.BFILE;
import oracle.sql.CLOB;
import oracle.sql.BLOB;
import oracle.sql.RAW;
import oracle.sql.CHAR;
import oracle.sql.REF;
import oracle.sql.OPAQUE;
import oracle.sql.STRUCT;
import oracle.sql.ARRAY;
import oracle.sql.DATE;
import oracle.sql.NUMBER;
import oracle.sql.ROWID;
import oracle.sql.Datum;
import java.sql.ResultSet;
import java.io.InputStream;
import java.sql.Timestamp;
import java.sql.Time;
import java.util.Calendar;
import java.sql.Date;
import java.math.BigDecimal;
import oracle.jdbc.OracleResultSet;
import java.sql.SQLException;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.oracore.OracleType;

abstract class Accessor
{
    static final int FIXED_CHAR = 999;
    static final int CHAR = 96;
    static final int VARCHAR = 1;
    static final int VCS = 9;
    static final int LONG = 8;
    static final int NUMBER = 2;
    static final int VARNUM = 6;
    static final int BINARY_FLOAT = 100;
    static final int BINARY_DOUBLE = 101;
    static final int RAW = 23;
    static final int VBI = 15;
    static final int LONG_RAW = 24;
    static final int ROWID = 104;
    static final int RESULT_SET = 102;
    static final int RSET = 116;
    static final int DATE = 12;
    static final int BLOB = 113;
    static final int CLOB = 112;
    static final int BFILE = 114;
    static final int NAMED_TYPE = 109;
    static final int REF_TYPE = 111;
    static final int TIMESTAMP = 180;
    static final int TIMESTAMPTZ = 181;
    static final int TIMESTAMPLTZ = 231;
    static final int INTERVALYM = 182;
    static final int INTERVALDS = 183;
    static final int UROWID = 208;
    static final int PLSQL_INDEX_TABLE = 998;
    static final int T2S_OVERLONG_RAW = 997;
    static final int SET_CHAR_BYTES = 996;
    static final int NULL_TYPE = 995;
    static final int DML_RETURN_PARAM = 994;
    static final int ONLY_FORM_USABLE = 0;
    static final int NOT_USABLE = 1;
    static final int NO_NEED_TO_PREPARE = 2;
    static final int NEED_TO_PREPARE = 3;
    OracleStatement statement;
    boolean outBind;
    int internalType;
    int internalTypeMaxLength;
    boolean isStream;
    boolean isColumnNumberAware;
    short formOfUse;
    OracleType internalOtype;
    int externalType;
    String internalTypeName;
    String columnName;
    int describeType;
    int describeMaxLength;
    boolean nullable;
    int precision;
    int scale;
    int flags;
    int contflag;
    int total_elems;
    OracleType describeOtype;
    String describeTypeName;
    int definedColumnType;
    int definedColumnSize;
    int oacmxl;
    short udskpos;
    int lobPrefetchSizeForThisColumn;
    long[] prefetchedLobSize;
    int[] prefetchedLobChunkSize;
    byte[] prefetchedClobFormOfUse;
    byte[][] prefetchedLobData;
    char[][] prefetchedLobCharData;
    int[] prefetchedLobDataL;
    OracleResultSetMetaData.SecurityAttribute securityAttribute;
    byte[] rowSpaceByte;
    char[] rowSpaceChar;
    short[] rowSpaceIndicator;
    static final byte DATA_UNAUTHORIZED = 1;
    byte[] rowSpaceMetaData;
    int columnIndex;
    int lengthIndex;
    int indicatorIndex;
    int metaDataIndex;
    int columnIndexLastRow;
    int lengthIndexLastRow;
    int indicatorIndexLastRow;
    int metaDataIndexLastRow;
    int byteLength;
    int charLength;
    int defineType;
    boolean isDMLReturnedParam;
    int lastRowProcessed;
    boolean isUseLess;
    int physicalColumnIndex;
    boolean isNullByDescribe;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    Accessor() {
        this.isStream = false;
        this.isColumnNumberAware = false;
        this.formOfUse = 2;
        this.definedColumnType = 0;
        this.definedColumnSize = 0;
        this.oacmxl = 0;
        this.udskpos = -1;
        this.lobPrefetchSizeForThisColumn = -1;
        this.prefetchedLobSize = null;
        this.prefetchedLobChunkSize = null;
        this.prefetchedClobFormOfUse = null;
        this.prefetchedLobData = null;
        this.prefetchedLobCharData = null;
        this.prefetchedLobDataL = null;
        this.rowSpaceByte = null;
        this.rowSpaceChar = null;
        this.rowSpaceIndicator = null;
        this.rowSpaceMetaData = null;
        this.columnIndex = 0;
        this.lengthIndex = 0;
        this.indicatorIndex = 0;
        this.metaDataIndex = 0;
        this.columnIndexLastRow = 0;
        this.lengthIndexLastRow = 0;
        this.indicatorIndexLastRow = 0;
        this.metaDataIndexLastRow = 0;
        this.byteLength = 0;
        this.charLength = 0;
        this.isDMLReturnedParam = false;
        this.lastRowProcessed = 0;
        this.isUseLess = false;
        this.physicalColumnIndex = -2;
        this.isNullByDescribe = false;
    }
    
    void setOffsets(final int n) {
        this.columnIndex = this.statement.defineByteSubRange;
        this.statement.defineByteSubRange = this.columnIndex + n * this.byteLength;
    }
    
    void init(final OracleStatement statement, final int internalType, final int defineType, final short formOfUse, final boolean outBind) throws SQLException {
        this.statement = statement;
        this.outBind = outBind;
        this.internalType = internalType;
        this.defineType = defineType;
        this.formOfUse = formOfUse;
    }
    
    abstract void initForDataAccess(final int p0, final int p1, final String p2) throws SQLException;
    
    void initForDescribe(final int describeType, final int describeMaxLength, final boolean nullable, final int flags, final int precision, final int scale, final int contflag, final int total_elems, final short formOfUse) throws SQLException {
        this.describeType = describeType;
        this.describeMaxLength = describeMaxLength;
        this.nullable = nullable;
        this.precision = precision;
        this.scale = scale;
        this.flags = flags;
        this.contflag = contflag;
        this.total_elems = total_elems;
        this.formOfUse = formOfUse;
    }
    
    void initForDescribe(final int n, final int n2, final boolean b, final int n3, final int n4, final int n5, final int n6, final int n7, final short n8, final String describeTypeName) throws SQLException {
        this.describeTypeName = describeTypeName;
        this.describeOtype = null;
        this.initForDescribe(n, n2, b, n3, n4, n5, n6, n7, n8);
    }
    
    OracleInputStream initForNewRow() throws SQLException {
        this.unimpl("initForNewRow");
        return null;
    }
    
    int useForDataAccessIfPossible(final int n, final int n2, final int n3, final String s) throws SQLException {
        int n4 = 3;
        int byteLength = 0;
        int charLength = 0;
        if (this.internalType != 0) {
            if (this.internalType != n) {
                n4 = 0;
            }
            else if (this.rowSpaceIndicator != null) {
                byteLength = this.byteLength;
                charLength = this.charLength;
            }
        }
        if (n4 == 3) {
            this.initForDataAccess(n2, n3, s);
            if (!this.outBind && byteLength >= this.byteLength && charLength >= this.charLength) {
                n4 = 2;
            }
        }
        return n4;
    }
    
    boolean useForDescribeIfPossible(final int n, final int n2, final boolean b, final int n3, final int n4, final int n5, final int n6, final int n7, final short n8, final String s) throws SQLException {
        if (this.externalType == 0 && n != this.describeType) {
            return false;
        }
        this.initForDescribe(n, n2, b, n3, n4, n5, n6, n7, n8, s);
        return true;
    }
    
    void setFormOfUse(final short formOfUse) {
        this.formOfUse = formOfUse;
    }
    
    void updateColumnNumber(final int n) {
    }
    
    @Override
    public String toString() {
        return super.toString() + ", statement=" + this.statement + ", outBind=" + this.outBind + ", internalType=" + this.internalType + ", internalTypeMaxLength=" + this.internalTypeMaxLength + ", isStream=" + this.isStream + ", formOfUse=" + this.formOfUse + ", internalOtype=" + this.internalOtype + ", externalType=" + this.externalType + ", internalTypeName=" + this.internalTypeName + ", columnName=" + this.columnName + ", describeType=" + this.describeType + ", describeMaxLength=" + this.describeMaxLength + ", nullable=" + this.nullable + ", precision=" + this.precision + ", scale=" + this.scale + ", flags=" + this.flags + ", contflag=" + this.contflag + ", total_elems=" + this.total_elems + ", describeOtype=" + this.describeOtype + ", describeTypeName=" + this.describeTypeName + ", rowSpaceByte=" + this.rowSpaceByte + ", rowSpaceChar=" + (Object)this.rowSpaceChar + ", rowSpaceIndicator=" + this.rowSpaceIndicator + ", columnIndex=" + this.columnIndex + ", lengthIndex=" + this.lengthIndex + ", indicatorIndex=" + this.indicatorIndex + ", byteLength=" + this.byteLength + ", charLength=" + this.charLength;
    }
    
    void unimpl(final String str) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, str + " not implemented for " + this.getClass());
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    boolean getBoolean(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return false;
        }
        this.unimpl("getBoolean");
        return false;
    }
    
    byte getByte(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0;
        }
        this.unimpl("getByte");
        return 0;
    }
    
    OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(final int n) throws SQLException {
        if (this.rowSpaceMetaData == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if ((this.rowSpaceMetaData[this.metaDataIndex + 1 * n] & 0x1) != 0x0) {
            return OracleResultSet.AuthorizationIndicator.UNAUTHORIZED;
        }
        if (this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED || this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.NONE) {
            return OracleResultSet.AuthorizationIndicator.NONE;
        }
        return OracleResultSet.AuthorizationIndicator.UNKNOWN;
    }
    
    short getShort(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0;
        }
        this.unimpl("getShort");
        return 0;
    }
    
    int getInt(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0;
        }
        this.unimpl("getInt");
        return 0;
    }
    
    long getLong(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0L;
        }
        this.unimpl("getLong");
        return 0L;
    }
    
    float getFloat(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0.0f;
        }
        this.unimpl("getFloat");
        return 0.0f;
    }
    
    double getDouble(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return 0.0;
        }
        this.unimpl("getDouble");
        return 0.0;
    }
    
    BigDecimal getBigDecimal(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getBigDecimal");
        return null;
    }
    
    BigDecimal getBigDecimal(final int n, final int n2) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getBigDecimal");
        return null;
    }
    
    String getString(final int n) throws SQLException {
        return null;
    }
    
    Date getDate(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getDate");
        return null;
    }
    
    Date getDate(final int n, final Calendar calendar) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getDate");
        return null;
    }
    
    Time getTime(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTime");
        return null;
    }
    
    Time getTime(final int n, final Calendar calendar) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTime");
        return null;
    }
    
    Timestamp getTimestamp(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTimestamp");
        return null;
    }
    
    Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTimestamp");
        return null;
    }
    
    byte[] privateGetBytes(final int n) throws SQLException {
        return this.getBytes(n);
    }
    
    byte[] getBytes(final int n) throws SQLException {
        byte[] array = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            array = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3, array, 0, n2);
        }
        return array;
    }
    
    InputStream getAsciiStream(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getAsciiStream");
        return null;
    }
    
    InputStream getUnicodeStream(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getUnicodeStream");
        return null;
    }
    
    InputStream getBinaryStream(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getBinaryStream");
        return null;
    }
    
    Object getObject(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getObject");
        return null;
    }
    
    ResultSet getCursor(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    Datum getOracleObject(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getOracleObject");
        return null;
    }
    
    ROWID getROWID(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
        sqlException2.fillInStackTrace();
        throw sqlException2;
    }
    
    NUMBER getNUMBER(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getNUMBER");
        return null;
    }
    
    DATE getDATE(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getDATE");
        return null;
    }
    
    ARRAY getARRAY(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getARRAY");
        return null;
    }
    
    STRUCT getSTRUCT(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getSTRUCT");
        return null;
    }
    
    OPAQUE getOPAQUE(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getOPAQUE");
        return null;
    }
    
    REF getREF(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getREF");
        return null;
    }
    
    CHAR getCHAR(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getCHAR");
        return null;
    }
    
    RAW getRAW(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getRAW");
        return null;
    }
    
    BLOB getBLOB(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getBLOB");
        return null;
    }
    
    CLOB getCLOB(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getCLOB");
        return null;
    }
    
    BFILE getBFILE(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getBFILE");
        return null;
    }
    
    CustomDatum getCustomDatum(final int n, final CustomDatumFactory customDatumFactory) throws SQLException {
        return customDatumFactory.create(this.getOracleObject(n), 0);
    }
    
    ORAData getORAData(final int n, final ORADataFactory oraDataFactory) throws SQLException {
        return oraDataFactory.create(this.getOracleObject(n), 0);
    }
    
    Object getObject(final int n, final Map map) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getObject");
        return null;
    }
    
    Reader getCharacterStream(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getCharacterStream");
        return null;
    }
    
    INTERVALYM getINTERVALYM(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getINTERVALYM");
        return null;
    }
    
    INTERVALDS getINTERVALDS(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getINTERVALDS");
        return null;
    }
    
    TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTIMESTAMP");
        return null;
    }
    
    TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTIMESTAMPTZ");
        return null;
    }
    
    TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getTIMESTAMPLTZ");
        return null;
    }
    
    URL getURL(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getURL");
        return null;
    }
    
    Datum[] getOraclePlsqlIndexTable(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getOraclePlsqlIndexTable");
        return null;
    }
    
    NClob getNClob(final int n) throws SQLException {
        if (this.formOfUse != 2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, this.columnIndex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (NClob)this.getCLOB(n);
    }
    
    String getNString(final int n) throws SQLException {
        return this.getString(n);
    }
    
    SQLXML getSQLXML(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        this.unimpl("getSQLXML");
        return null;
    }
    
    Reader getNCharacterStream(final int n) throws SQLException {
        return this.getCharacterStream(n);
    }
    
    boolean isNull(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.rowSpaceIndicator[this.indicatorIndex + n] == -1;
    }
    
    void setNull(final int n, final boolean b) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.rowSpaceIndicator[this.indicatorIndex + n] = (short)(b ? -1 : 0);
    }
    
    void fetchNextColumns() throws SQLException {
    }
    
    void calculateSizeTmpByteArray() {
    }
    
    boolean unmarshalOneRow() throws SQLException, IOException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 148);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void copyRow() throws SQLException, IOException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 148);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    int readStream(final byte[] array, final int n) throws SQLException, IOException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 148);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void initMetadata() throws SQLException {
    }
    
    void setDisplaySize(final int describeMaxLength) throws SQLException {
        this.describeMaxLength = describeMaxLength;
    }
    
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.statement.getConnectionDuringExceptionHandling();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
