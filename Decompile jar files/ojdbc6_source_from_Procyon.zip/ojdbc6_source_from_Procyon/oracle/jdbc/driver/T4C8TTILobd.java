// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;

class T4C8TTILobd extends T4CTTIMsg
{
    static final int LOBD_STATE0 = 0;
    static final int LOBD_STATE1 = 1;
    static final int LOBD_STATE2 = 2;
    static final int LOBD_STATE3 = 3;
    static final int LOBD_STATE_EXIT = 4;
    static final short TTCG_LNG = 254;
    static final short LOBDATALENGTH = 252;
    static byte[] ucs2Char;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8TTILobd(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)14);
    }
    
    void marshalLobData(final byte[] array, final long n, final long n2, final boolean b) throws IOException {
        long n3 = n2;
        this.marshalTTCcode();
        if (b) {
            this.meg.outStream.flush();
            this.meg.outStream.writeZeroCopyIO(array, (int)n, (int)n2);
        }
        else {
            int n4 = 0;
            if (n3 > 252L) {
                n4 = 1;
                this.meg.marshalUB1((short)254);
            }
            long n5 = 0L;
            while (n3 > 252L) {
                this.meg.marshalUB1((short)252);
                this.meg.marshalB1Array(array, (int)(n + n5 * 252L), 252);
                ++n5;
                n3 -= 252L;
            }
            if (n3 > 0L) {
                this.meg.marshalUB1((short)n3);
                this.meg.marshalB1Array(array, (int)(n + n5 * 252L), (int)n3);
            }
            if (n4 == 1) {
                this.meg.marshalUB1((short)0);
            }
        }
    }
    
    void marshalClobUB2_For9iDB(final byte[] array, final long n, final long n2) throws IOException {
        long n3 = n2;
        int n4 = 0;
        this.marshalTTCcode();
        if (n3 > 84L) {
            n4 = 1;
            this.meg.marshalUB1((short)254);
        }
        long n5 = 0L;
        while (n3 > 84L) {
            this.meg.marshalUB1((short)252);
            for (int i = 0; i < 84; ++i) {
                this.meg.marshalUB1((short)2);
                this.meg.marshalB1Array(array, (int)(n + n5 * 168L + i * 2), 2);
            }
            ++n5;
            n3 -= 84L;
        }
        if (n3 > 0L) {
            this.meg.marshalUB1((short)(n3 * 3L));
            for (int n6 = 0; n6 < n3; ++n6) {
                this.meg.marshalUB1((short)2);
                this.meg.marshalB1Array(array, (int)(n + n5 * 168L + n6 * 2), 2);
            }
        }
        if (n4 == 1) {
            this.meg.marshalUB1((short)0);
        }
    }
    
    long unmarshalLobData(final byte[] array, final int n, final boolean b) throws SQLException, IOException {
        long n2 = 0L;
        if (b) {
            int n3 = 0;
            final int[] array2 = { 0 };
            for (boolean zeroCopyIO = false; !zeroCopyIO; zeroCopyIO = this.meg.inStream.readZeroCopyIO(array, n + n3, array2), n3 += array2[0]) {}
            n2 = n3;
        }
        else {
            long n4 = n;
            int n5 = 0;
            int i = 0;
            while (i != 4) {
                switch (i) {
                    case 0: {
                        n5 = this.meg.unmarshalUB1();
                        if (n5 == 254) {
                            i = 2;
                            continue;
                        }
                        i = 1;
                        continue;
                    }
                    case 1: {
                        this.meg.getNBytes(array, (int)n4, n5);
                        n2 += n5;
                        i = 4;
                        continue;
                    }
                    case 2: {
                        n5 = this.meg.unmarshalUB1();
                        if (n5 > 0) {
                            i = 3;
                            continue;
                        }
                        i = 4;
                        continue;
                    }
                    case 3: {
                        this.meg.getNBytes(array, (int)n4, n5);
                        n2 += n5;
                        n4 += n5;
                        i = 2;
                        continue;
                    }
                    default: {
                        continue;
                    }
                }
            }
        }
        return n2;
    }
    
    long unmarshalClobUB2_For9iDB(final byte[] array, final int n) throws SQLException, IOException {
        long n2 = 0L;
        long n3 = n;
        int n4 = 0;
        int i = 0;
        while (i != 4) {
            switch (i) {
                case 0: {
                    n4 = this.meg.unmarshalUB1();
                    if (n4 == 254) {
                        i = 2;
                        continue;
                    }
                    i = 1;
                    continue;
                }
                case 1: {
                    for (int j = 0; j < n4; j += this.meg.unmarshalUCS2(array, n3), n3 += 2L) {}
                    n2 += n4;
                    i = 4;
                    continue;
                }
                case 2: {
                    n4 = this.meg.unmarshalUB1();
                    if (n4 > 0) {
                        i = 3;
                        continue;
                    }
                    i = 4;
                    continue;
                }
                case 3: {
                    for (int k = 0; k < n4; k += this.meg.unmarshalUCS2(array, n3), n3 += 2L) {}
                    n2 += n4;
                    i = 2;
                    continue;
                }
                default: {
                    continue;
                }
            }
        }
        return n2;
    }
    
    static {
        T4C8TTILobd.ucs2Char = new byte[2];
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
