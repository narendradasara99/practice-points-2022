// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.EventListener;
import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.dcn.DatabaseChangeListener;
import java.util.Properties;
import oracle.jdbc.dcn.DatabaseChangeRegistration;

class NTFDCNRegistration extends NTFRegistration implements DatabaseChangeRegistration
{
    private final long regid;
    private String[] tables;
    private int nbOfStringsInTable;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFDCNRegistration(final int n, final boolean b, final String s, final long regid, final String s2, final String s3, final int n2, final Properties properties, final short n3) {
        super(n, 2, b, s, s3, n2, properties, s2, n3);
        this.tables = new String[10];
        this.nbOfStringsInTable = 0;
        this.regid = regid;
    }
    
    NTFDCNRegistration(final String s, final long regid, final String s2, final short n) {
        super(0, 2, false, s, null, 0, null, s2, n);
        this.tables = new String[10];
        this.nbOfStringsInTable = 0;
        this.regid = regid;
    }
    
    @Override
    public int getRegistrationId() {
        return (int)this.regid;
    }
    
    @Override
    public long getRegId() {
        return this.regid;
    }
    
    @Override
    public void addListener(final DatabaseChangeListener databaseChangeListener, final Executor executor) throws SQLException {
        final NTFEventListener ntfEventListener = new NTFEventListener(databaseChangeListener);
        ntfEventListener.setExecutor(executor);
        this.addListener(ntfEventListener);
    }
    
    @Override
    public void addListener(final DatabaseChangeListener databaseChangeListener) throws SQLException {
        this.addListener(new NTFEventListener(databaseChangeListener));
    }
    
    @Override
    public void removeListener(final DatabaseChangeListener databaseChangeListener) throws SQLException {
        super.removeListener(databaseChangeListener);
    }
    
    synchronized void addTablesName(final String[] array, final int n) {
        if (this.nbOfStringsInTable + n > this.tables.length) {
            final String[] tables = new String[(this.nbOfStringsInTable + n) * 2];
            System.arraycopy(this.tables, 0, tables, 0, this.tables.length);
            this.tables = tables;
        }
        System.arraycopy(array, 0, this.tables, this.nbOfStringsInTable, n);
        this.nbOfStringsInTable += n;
    }
    
    @Override
    public String[] getTables() {
        final String[] array = new String[this.nbOfStringsInTable];
        System.arraycopy(this.tables, 0, array, 0, this.nbOfStringsInTable);
        return array;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
