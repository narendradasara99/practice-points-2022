// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.XSEvent;
import java.util.concurrent.Executor;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.NotificationRegistration;
import oracle.sql.TIMESTAMPTZ;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.pool.OraclePooledConnection;
import java.io.Writer;
import oracle.sql.CLOB;
import java.io.OutputStream;
import java.sql.Connection;
import oracle.sql.BLOB;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.LobPlsqlUtil;
import oracle.sql.BFILE;
import oracle.jdbc.internal.KeywordValue;
import oracle.net.ns.NSProtocol;
import oracle.jdbc.OracleConnection;
import oracle.net.ns.NetException;
import java.io.UnsupportedEncodingException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Hashtable;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.net.ns.Communication;
import oracle.sql.ClobDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.BfileDBAccess;

class T4CConnection extends PhysicalConnection implements BfileDBAccess, BlobDBAccess, ClobDBAccess
{
    static final short MIN_TTCVER_SUPPORTED = 4;
    static final short V8_TTCVER_SUPPORTED = 5;
    static final short MAX_TTCVER_SUPPORTED = 6;
    static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
    static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
    static final int STREAM_CHUNK_SIZE = 255;
    static final int REFCURSOR_SIZE = 5;
    long LOGON_MODE;
    static final long SYSDBA = 8L;
    static final long SYSOPER = 16L;
    static final long SYSASM = 128L;
    boolean isLoggedOn;
    private boolean useZeroCopyIO;
    boolean useLobPrefetch;
    private String password;
    Communication net;
    private NTFEventListener[] xsListeners;
    boolean readAsNonStream;
    T4CTTIoer oer;
    T4CMAREngine mare;
    T4C8TTIpro pro;
    T4CTTIrxd rxd;
    T4CTTIsto sto;
    T4CTTIspfp spfp;
    T4CTTIoauthenticate auth;
    T4C8Odscrarr describe;
    T4C8Oall all8;
    T4C8Oclose close8;
    T4C7Ocommoncall commoncall;
    T4Caqe aqe;
    T4Caqdq aqdq;
    T4C8TTIBfile bfileMsg;
    T4C8TTIBlob blobMsg;
    T4C8TTIClob clobMsg;
    T4CTTIoses oses;
    T4CTTIoping oping;
    T4CTTIokpn okpn;
    byte[] EMPTY_BYTE;
    T4CTTIOtxen otxen;
    T4CTTIOtxse otxse;
    T4CTTIk2rpc k2rpc;
    T4CTTIoscid oscid;
    T4CTTIokeyval okeyval;
    T4CTTIoxsscs oxsscs;
    T4CTTIoxssro oxssro;
    T4CTTIoxsspo oxsspo;
    T4CTTIxsnsop xsnsop;
    int[] cursorToClose;
    int cursorToCloseOffset;
    int[] queryToClose;
    int queryToCloseOffset;
    int[] lusFunctionId2;
    byte[][] lusSessionId2;
    KeywordValueLong[][] lusInKeyVal2;
    int[] lusInFlags2;
    int lusOffset2;
    int sessionId;
    int serialNumber;
    byte negotiatedTTCversion;
    byte[] serverRuntimeCapabilities;
    Hashtable namespaces;
    byte[] internalName;
    byte[] externalName;
    static final int FREE = -1;
    static final int SEND = 1;
    static final int RECEIVE = 2;
    int pipeState;
    boolean sentCancel;
    static final int MAX_SIZE_VSESSION_OSUSER = 30;
    static final int MAX_SIZE_VSESSION_PROCESS = 24;
    static final int MAX_SIZE_VSESSION_MACHINE = 64;
    static final int MAX_SIZE_VSESSION_TERMINAL = 30;
    static final int MAX_SIZE_VSESSION_PROGRAM = 48;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CConnection(final String s, final Properties properties, final OracleDriverExtension oracleDriverExtension) throws SQLException {
        super(s, properties, oracleDriverExtension);
        this.LOGON_MODE = 0L;
        this.xsListeners = new NTFEventListener[0];
        this.EMPTY_BYTE = new byte[0];
        this.pipeState = -1;
        this.sentCancel = false;
        this.cursorToClose = new int[4];
        this.cursorToCloseOffset = 0;
        this.queryToClose = new int[10];
        this.queryToCloseOffset = 0;
        this.lusFunctionId2 = new int[10];
        this.lusSessionId2 = new byte[10][];
        this.lusInKeyVal2 = new KeywordValueLong[10][];
        this.lusInFlags2 = new int[10];
        this.lusOffset2 = 0;
        this.minVcsBindSize = 0;
        this.streamChunkSize = 255;
        this.namespaces = new Hashtable(5);
    }
    
    @Override
    final void initializePassword(final String password) throws SQLException {
        this.password = password;
    }
    
    @Override
    void logon() throws SQLException {
        try {
            if (this.isLoggedOn) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 428);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.database == null) {
                this.database = "localhost:1521:orcl";
            }
            this.connect(this.database);
            this.all8 = new T4C8Oall(this);
            this.okpn = new T4CTTIokpn(this);
            this.close8 = new T4C8Oclose(this);
            this.sto = new T4CTTIsto(this);
            this.spfp = new T4CTTIspfp(this);
            this.commoncall = new T4C7Ocommoncall(this);
            this.describe = new T4C8Odscrarr(this);
            this.bfileMsg = new T4C8TTIBfile(this);
            this.blobMsg = new T4C8TTIBlob(this);
            this.clobMsg = new T4C8TTIClob(this);
            this.otxen = new T4CTTIOtxen(this);
            this.otxse = new T4CTTIOtxse(this);
            this.oping = new T4CTTIoping(this);
            this.k2rpc = new T4CTTIk2rpc(this);
            this.oses = new T4CTTIoses(this);
            this.okeyval = new T4CTTIokeyval(this);
            this.oxssro = new T4CTTIoxssro(this);
            this.oxsspo = new T4CTTIoxsspo(this);
            this.oxsscs = new T4CTTIoxsscs(this);
            this.xsnsop = new T4CTTIxsnsop(this);
            this.aqe = new T4Caqe(this);
            this.aqdq = new T4Caqdq(this);
            this.oscid = new T4CTTIoscid(this);
            this.LOGON_MODE = 0L;
            if (this.internalLogon != null) {
                if (this.internalLogon.equalsIgnoreCase("sysoper")) {
                    this.LOGON_MODE = 64L;
                }
                else if (this.internalLogon.equalsIgnoreCase("sysdba")) {
                    this.LOGON_MODE = 32L;
                }
                else if (this.internalLogon.equalsIgnoreCase("sysasm")) {
                    this.LOGON_MODE = 4194304L;
                }
            }
            if (this.prelimAuth) {
                this.LOGON_MODE |= 0x80L;
            }
            this.auth = new T4CTTIoauthenticate(this, this.resourceManagerId);
            if (this.userName != null && this.userName.length() != 0) {
                this.auth.doOSESSKEY(this.userName, this.LOGON_MODE);
            }
            this.auth.doOAUTH(this.userName, this.password, this.LOGON_MODE);
            this.sessionId = this.getSessionId();
            this.serialNumber = this.getSerialNumber();
            this.internalName = this.auth.internalName;
            this.externalName = this.auth.externalName;
            this.instanceName = this.sessionProperties.getProperty("AUTH_INSTANCENAME");
            if (!this.prelimAuth) {
                final T4C7Oversion t4C7Oversion = new T4C7Oversion(this);
                t4C7Oversion.doOVERSION();
                final byte[] version = t4C7Oversion.getVersion();
                try {
                    this.databaseProductVersion = new String(version, "UTF8");
                }
                catch (UnsupportedEncodingException ex) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                this.versionNumber = t4C7Oversion.getVersionNumber();
            }
            else {
                this.versionNumber = 0;
            }
            this.isLoggedOn = true;
        }
        catch (NetException ex2) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex3);
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        catch (SQLException ex4) {
            try {
                this.net.disconnect();
            }
            catch (Exception ex5) {}
            this.isLoggedOn = false;
            throw ex4;
        }
    }
    
    void handleIOException(final IOException ex) throws SQLException {
        try {
            this.pipeState = -1;
            this.net.disconnect();
            this.net = null;
        }
        catch (Exception ex2) {}
        this.isLoggedOn = false;
        this.lifecycle = 4;
    }
    
    @Override
    synchronized void logoff() throws SQLException {
        try {
            this.assertLoggedOn("T4CConnection.logoff");
            if (this.lifecycle == 8) {
                return;
            }
            this.sendPiggyBackedMessages();
            this.commoncall.doOLOGOFF();
            this.net.disconnect();
            this.net = null;
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            if (this.lifecycle != 8) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        finally {
            try {
                if (this.net != null) {
                    this.net.disconnect();
                }
            }
            catch (Exception ex2) {}
            this.isLoggedOn = false;
        }
    }
    
    T4CMAREngine getMarshalEngine() {
        return this.mare;
    }
    
    @Override
    synchronized void doCommit(final int n) throws SQLException {
        this.assertLoggedOn("T4CConnection.do_commit");
        try {
            this.sendPiggyBackedMessages();
            if (n == 0) {
                this.commoncall.doOCOMMIT();
            }
            else {
                int n2 = 0;
                if ((n & CommitOption.WRITEBATCH.getCode()) != 0x0) {
                    n2 = (n2 | 0x2 | 0x1);
                }
                else if ((n & CommitOption.WRITEIMMED.getCode()) != 0x0) {
                    n2 |= 0x2;
                }
                if ((n & CommitOption.NOWAIT.getCode()) != 0x0) {
                    n2 = (n2 | 0x8 | 0x4);
                }
                else if ((n & CommitOption.WAIT.getCode()) != 0x0) {
                    n2 |= 0x8;
                }
                this.otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, n2);
                final int outStateFromServer = this.otxen.getOutStateFromServer();
                if (outStateFromServer == 2 || outStateFromServer != 4) {}
            }
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    synchronized void doRollback() throws SQLException {
        try {
            this.assertLoggedOn("T4CConnection.do_rollback");
            this.sendPiggyBackedMessages();
            this.commoncall.doOROLLBACK();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    synchronized void doSetAutoCommit(final boolean b) throws SQLException {
    }
    
    public synchronized void open(final OracleStatement oracleStatement) throws SQLException {
        this.assertLoggedOn("T4CConnection.open");
        oracleStatement.setCursorId(0);
    }
    
    @Override
    synchronized String doGetDatabaseProductVersion() throws SQLException {
        this.assertLoggedOn("T4CConnection.do_getDatabaseProductVersion");
        final T4C7Oversion t4C7Oversion = new T4C7Oversion(this);
        try {
            t4C7Oversion.doOVERSION();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final byte[] version = t4C7Oversion.getVersion();
        String s;
        try {
            s = new String(version, "UTF8");
        }
        catch (UnsupportedEncodingException ex2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return s;
    }
    
    @Override
    synchronized short doGetVersionNumber() throws SQLException {
        this.assertLoggedOn("T4CConnection.do_getVersionNumber");
        final T4C7Oversion t4C7Oversion = new T4C7Oversion(this);
        try {
            t4C7Oversion.doOVERSION();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return t4C7Oversion.getVersionNumber();
    }
    
    @Override
    OracleStatement RefCursorBytesToStatement(final byte[] array, final OracleStatement oracleStatement) throws SQLException {
        final T4CStatement t4CStatement = new T4CStatement(this, -1, -1);
        try {
            t4CStatement.setCursorId(this.mare.unmarshalRefCursor(array));
            t4CStatement.isOpen = true;
            t4CStatement.sqlObject = oracleStatement.sqlObject;
            t4CStatement.serverCursor = true;
            oracleStatement.addChild(t4CStatement);
            t4CStatement.prepareForNewResults(true, false);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        t4CStatement.sqlStringChanged = false;
        t4CStatement.needToParse = false;
        return t4CStatement;
    }
    
    @Override
    void cancelOperationOnServer() throws SQLException {
        try {
            switch (this.pipeState) {
                case -1: {
                    return;
                }
                case 1: {
                    this.net.sendBreak();
                    break;
                }
                case 2: {
                    this.net.sendInterrupt();
                    break;
                }
            }
            this.sentCancel = true;
        }
        catch (NetException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (IOException ex2) {
            this.handleIOException(ex2);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    void connect(final String s) throws IOException, SQLException {
        if (s == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 433);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final Properties properties = new Properties();
        if (this.thinNetProfile != null) {
            properties.setProperty("oracle.net.profile", this.thinNetProfile);
        }
        if (this.thinNetAuthenticationServices != null) {
            properties.setProperty("oracle.net.authentication_services", this.thinNetAuthenticationServices);
        }
        if (this.thinNetAuthenticationKrb5Mutual != null) {
            properties.setProperty("oracle.net.kerberos5_mutual_authentication", this.thinNetAuthenticationKrb5Mutual);
        }
        if (this.thinNetAuthenticationKrb5CcName != null) {
            properties.setProperty("oracle.net.kerberos5_cc_name", this.thinNetAuthenticationKrb5CcName);
        }
        if (this.thinNetEncryptionLevel != null) {
            properties.setProperty("oracle.net.encryption_client", this.thinNetEncryptionLevel);
        }
        if (this.thinNetEncryptionTypes != null) {
            properties.setProperty("oracle.net.encryption_types_client", this.thinNetEncryptionTypes);
        }
        if (this.thinNetChecksumLevel != null) {
            properties.setProperty("oracle.net.crypto_checksum_client", this.thinNetChecksumLevel);
        }
        if (this.thinNetChecksumTypes != null) {
            properties.setProperty("oracle.net.crypto_checksum_types_client", this.thinNetChecksumTypes);
        }
        if (this.thinNetCryptoSeed != null) {
            properties.setProperty("oracle.net.crypto_seed", this.thinNetCryptoSeed);
        }
        if (this.thinTcpNoDelay) {
            properties.setProperty("TCP.NODELAY", "YES");
        }
        if (this.thinReadTimeout != null) {
            properties.setProperty("oracle.net.READ_TIMEOUT", this.thinReadTimeout);
        }
        if (this.thinNetConnectTimeout != null) {
            properties.setProperty("oracle.net.CONNECT_TIMEOUT", this.thinNetConnectTimeout);
        }
        if (this.thinSslServerDnMatch != null) {
            properties.setProperty("oracle.net.ssl_server_dn_match", this.thinSslServerDnMatch);
        }
        if (this.walletLocation != null) {
            properties.setProperty("oracle.net.wallet_location", this.walletLocation);
        }
        if (this.walletPassword != null) {
            properties.setProperty("oracle.net.wallet_password", this.walletPassword);
        }
        if (this.thinSslVersion != null) {
            properties.setProperty("oracle.net.ssl_version", this.thinSslVersion);
        }
        if (this.thinSslCipherSuites != null) {
            properties.setProperty("oracle.net.ssl_cipher_suites", this.thinSslCipherSuites);
        }
        if (this.thinJavaxNetSslKeystore != null) {
            properties.setProperty("javax.net.ssl.keyStore", this.thinJavaxNetSslKeystore);
        }
        if (this.thinJavaxNetSslKeystoretype != null) {
            properties.setProperty("javax.net.ssl.keyStoreType", this.thinJavaxNetSslKeystoretype);
        }
        if (this.thinJavaxNetSslKeystorepassword != null) {
            properties.setProperty("javax.net.ssl.keyStorePassword", this.thinJavaxNetSslKeystorepassword);
        }
        if (this.thinJavaxNetSslTruststore != null) {
            properties.setProperty("javax.net.ssl.trustStore", this.thinJavaxNetSslTruststore);
        }
        if (this.thinJavaxNetSslTruststoretype != null) {
            properties.setProperty("javax.net.ssl.trustStoreType", this.thinJavaxNetSslTruststoretype);
        }
        if (this.thinJavaxNetSslTruststorepassword != null) {
            properties.setProperty("javax.net.ssl.trustStorePassword", this.thinJavaxNetSslTruststorepassword);
        }
        if (this.thinSslKeymanagerfactoryAlgorithm != null) {
            properties.setProperty("ssl.keyManagerFactory.algorithm", this.thinSslKeymanagerfactoryAlgorithm);
        }
        if (this.thinSslTrustmanagerfactoryAlgorithm != null) {
            properties.setProperty("ssl.trustManagerFactory.algorithm", this.thinSslTrustmanagerfactoryAlgorithm);
        }
        if (this.thinNetOldsyntax != null) {
            properties.setProperty("oracle.net.oldSyntax", this.thinNetOldsyntax);
        }
        if (this.thinNamingContextInitial != null) {
            properties.setProperty("java.naming.factory.initial", this.thinNamingContextInitial);
        }
        if (this.thinNamingProviderUrl != null) {
            properties.setProperty("java.naming.provider.url", this.thinNamingProviderUrl);
        }
        if (this.thinNamingSecurityAuthentication != null) {
            properties.setProperty("java.naming.security.authentication", this.thinNamingSecurityAuthentication);
        }
        if (this.thinNamingSecurityPrincipal != null) {
            properties.setProperty("java.naming.security.principal", this.thinNamingSecurityPrincipal);
        }
        if (this.thinNamingSecurityCredentials != null) {
            properties.setProperty("java.naming.security.credentials", this.thinNamingSecurityCredentials);
        }
        if (this.thinNetDisableOutOfBandBreak) {
            properties.setProperty("DISABLE_OOB", "" + this.thinNetDisableOutOfBandBreak);
        }
        if (this.thinNetEnableSDP) {
            properties.setProperty("oracle.net.SDP", "" + this.thinNetEnableSDP);
        }
        properties.setProperty("USE_ZERO_COPY_IO", "" + this.thinNetUseZeroCopyIO);
        properties.setProperty("FORCE_DNS_LOAD_BALANCING", "" + this.thinForceDnsLoadBalancing);
        properties.setProperty("oracle.jdbc.v$session.osuser", this.thinVsessionOsuser);
        properties.setProperty("oracle.jdbc.v$session.program", this.thinVsessionProgram);
        properties.setProperty("T4CConnection.hashCode", Integer.toHexString(this.hashCode()).toUpperCase());
        (this.net = new NSProtocol()).connect(s, properties);
        this.mare = new T4CMAREngine(this.net);
        this.oer = new T4CTTIoer(this);
        this.mare.setConnectionDuringExceptionHandling(this);
        (this.pro = new T4C8TTIpro(this)).marshal();
        final byte[] receive = this.pro.receive();
        this.serverRuntimeCapabilities = this.pro.getServerRuntimeCapabilities();
        final short oracleVersion = this.pro.getOracleVersion();
        final short characterSet = this.pro.getCharacterSet();
        final short driverCharSet = DBConversion.findDriverCharSet(characterSet, oracleVersion);
        this.conversion = new DBConversion(characterSet, driverCharSet, this.pro.getncharCHARSET(), this.isStrictAsciiConversion);
        this.mare.types.setServerConversion(driverCharSet != characterSet);
        final DBConversion conversion = this.conversion;
        if (DBConversion.isCharSetMultibyte(driverCharSet)) {
            final DBConversion conversion2 = this.conversion;
            if (DBConversion.isCharSetMultibyte(this.pro.getCharacterSet())) {
                this.mare.types.setFlags((byte)1);
            }
            else {
                this.mare.types.setFlags((byte)2);
            }
        }
        else {
            this.mare.types.setFlags(this.pro.getFlags());
        }
        this.mare.conv = this.conversion;
        final T4C8TTIdty t4C8TTIdty = new T4C8TTIdty(this, receive, this.serverRuntimeCapabilities, this.logonCap != null && this.logonCap.trim().equals("o3"), this.thinNetUseZeroCopyIO);
        t4C8TTIdty.doRPC();
        this.negotiatedTTCversion = receive[7];
        if (t4C8TTIdty.jdbcThinCompileTimeCapabilities[7] < receive[7]) {
            this.negotiatedTTCversion = t4C8TTIdty.jdbcThinCompileTimeCapabilities[7];
        }
        if (this.serverRuntimeCapabilities != null && this.serverRuntimeCapabilities.length > 6 && (this.serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0x0 && this.thinNetUseZeroCopyIO && (this.net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0x0 && this.getDataIntegrityAlgorithmName().equals("") && this.getEncryptionAlgorithmName().equals("")) {
            this.useZeroCopyIO = true;
        }
        else {
            this.useZeroCopyIO = false;
        }
        if (receive.length > 23 && (receive[23] & 0x40) != 0x0 && (t4C8TTIdty.jdbcThinCompileTimeCapabilities[23] & 0x40) != 0x0) {
            this.useLobPrefetch = true;
        }
        else {
            this.useLobPrefetch = false;
        }
    }
    
    boolean isZeroCopyIOEnabled() {
        return this.useZeroCopyIO;
    }
    
    final T4CTTIoer getT4CTTIoer() {
        return this.oer;
    }
    
    final byte getTTCVersion() {
        return this.negotiatedTTCversion;
    }
    
    @Override
    void doStartup(final int n) throws SQLException {
        try {
            int n2 = 0;
            if (n == DatabaseStartupMode.FORCE.getMode()) {
                n2 = 16;
            }
            else if (n == DatabaseStartupMode.RESTRICT.getMode()) {
                n2 = 1;
            }
            this.spfp.doOSPFPPUT();
            this.sto.doOV6STRT(n2);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    void doShutdown(final int n) throws SQLException {
        try {
            int n2 = 4;
            if (n == DatabaseShutdownMode.TRANSACTIONAL.getMode()) {
                n2 = 128;
            }
            else if (n == DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode()) {
                n2 = 256;
            }
            else if (n == DatabaseShutdownMode.IMMEDIATE.getMode()) {
                n2 = 2;
            }
            else if (n == DatabaseShutdownMode.FINAL.getMode()) {
                n2 = 8;
            }
            else if (n == DatabaseShutdownMode.ABORT.getMode()) {
                n2 = 64;
            }
            this.sendPiggyBackedMessages();
            this.sto.doOV6STOP(n2);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void sendPiggyBackedMessages() throws SQLException, IOException {
        this.sendPiggyBackedClose();
        if (this.endToEndAnyChanged && this.getTTCVersion() >= 3) {
            this.oscid.doOSCID(this.endToEndHasChanged, this.endToEndValues, this.endToEndECIDSequenceNumber);
            for (int i = 0; i < 4; ++i) {
                if (this.endToEndHasChanged[i]) {
                    this.endToEndHasChanged[i] = false;
                }
            }
        }
        this.endToEndAnyChanged = false;
        if (!this.namespaces.isEmpty()) {
            if (this.getTTCVersion() >= 4) {
                final Object[] array = this.namespaces.values().toArray();
                for (int j = 0; j < array.length; ++j) {
                    this.okeyval.doOKEYVAL((Namespace)array[j]);
                }
            }
            this.namespaces.clear();
        }
        if (this.lusOffset2 > 0) {
            for (int k = 0; k < this.lusOffset2; ++k) {
                this.oxsspo.doOXSSPO(this.lusFunctionId2[k], this.lusSessionId2[k], this.lusInKeyVal2[k], this.lusInFlags2[k]);
            }
            this.lusOffset2 = 0;
        }
    }
    
    private void sendPiggyBackedClose() throws SQLException, IOException {
        if (this.queryToCloseOffset > 0) {
            this.close8.doOCANA(this.queryToClose, this.queryToCloseOffset);
            this.queryToCloseOffset = 0;
        }
        if (this.cursorToCloseOffset > 0) {
            this.close8.doOCCA(this.cursorToClose, this.cursorToCloseOffset);
            this.cursorToCloseOffset = 0;
        }
    }
    
    @Override
    void doProxySession(final int n, final Properties properties) throws SQLException {
        try {
            this.sendPiggyBackedMessages();
            this.auth.doOAUTH(n, properties, this.sessionId, this.serialNumber);
            this.oses.doO80SES(this.getSessionId(), this.getSerialNumber(), 1);
            this.savedUser = this.userName;
            if (n == 1) {
                this.userName = properties.getProperty("PROXY_USER_NAME");
            }
            else {
                this.userName = null;
            }
            this.isProxy = true;
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    void closeProxySession() throws SQLException {
        try {
            this.sendPiggyBackedMessages();
            this.commoncall.doOLOGOFF();
            this.oses.doO80SES(this.sessionId, this.serialNumber, 1);
            this.userName = this.savedUser;
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void updateSessionProperties(final KeywordValue[] array) throws SQLException {
        for (int i = 0; i < array.length; ++i) {
            final int keyword = array[i].getKeyword();
            final byte[] binaryValue = array[i].getBinaryValue();
            if (keyword < T4C8Oall.NLS_KEYS.length) {
                final String s = T4C8Oall.NLS_KEYS[keyword];
                if (s != null) {
                    if (binaryValue != null) {
                        this.sessionProperties.setProperty(s, this.mare.conv.CharBytesToString(binaryValue, binaryValue.length));
                    }
                    else if (array[i].getTextValue() != null) {
                        this.sessionProperties.setProperty(s, array[i].getTextValue().trim());
                    }
                }
            }
            else if (keyword == 163) {
                if (binaryValue != null) {
                    final byte b = binaryValue[4];
                    final byte b2 = binaryValue[5];
                    int j;
                    int k;
                    if ((binaryValue[4] & 0xFF) > 120) {
                        j = (binaryValue[4] & 0xFF) - 181;
                        k = (binaryValue[5] & 0xFF) - 60;
                    }
                    else {
                        j = (binaryValue[4] & 0xFF) - 60;
                        k = (binaryValue[5] & 0xFF) - 60;
                    }
                    this.sessionProperties.setProperty("SESSION_TIME_ZONE", ((j > 0) ? "+" : "") + j + ((k <= 9) ? ":0" : ":") + k);
                }
            }
            else if (keyword != 165) {
                if (keyword != 166) {
                    if (keyword != 167) {
                        if (keyword != 168) {
                            if (keyword != 169) {
                                if (keyword != 170) {
                                    if (keyword == 171) {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public Properties getServerSessionInfo() throws SQLException {
        if (this.getVersionNumber() >= 10000 && this.getVersionNumber() < 10200) {
            this.queryFCFProperties(this.sessionProperties);
        }
        return this.sessionProperties;
    }
    
    @Override
    public String getSessionTimeZoneOffset() throws SQLException {
        final String property = this.getServerSessionInfo().getProperty("SESSION_TIME_ZONE");
        String s;
        if (property == null) {
            s = super.getSessionTimeZoneOffset();
        }
        else {
            s = this.tzToOffset(property);
        }
        return s;
    }
    
    int getSessionId() {
        int int1 = -1;
        final String property = this.sessionProperties.getProperty("AUTH_SESSION_ID");
        try {
            int1 = Integer.parseInt(property);
        }
        catch (NumberFormatException ex) {}
        return int1;
    }
    
    int getSerialNumber() {
        int int1 = -1;
        final String property = this.sessionProperties.getProperty("AUTH_SERIAL_NUM");
        try {
            int1 = Integer.parseInt(property);
        }
        catch (NumberFormatException ex) {}
        return int1;
    }
    
    @Override
    public byte getInstanceProperty(final InstanceProperty instanceProperty) throws SQLException {
        byte b = 0;
        if (instanceProperty == InstanceProperty.ASM_VOLUME_SUPPORTED) {
            if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 6) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 256);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            b = this.serverRuntimeCapabilities[5];
        }
        else if (instanceProperty == InstanceProperty.INSTANCE_TYPE) {
            if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 4) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 256);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            b = this.serverRuntimeCapabilities[3];
        }
        return b;
    }
    
    @Override
    public synchronized BlobDBAccess createBlobDBAccess() throws SQLException {
        return this;
    }
    
    @Override
    public synchronized ClobDBAccess createClobDBAccess() throws SQLException {
        return this;
    }
    
    @Override
    public synchronized BfileDBAccess createBfileDBAccess() throws SQLException {
        return this;
    }
    
    @Override
    public synchronized long length(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("length");
        this.assertNotNull(bfile.shareBytes(), "length");
        this.needLine();
        long length;
        try {
            length = this.bfileMsg.getLength(bfile.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return length;
    }
    
    @Override
    public synchronized long position(final BFILE bfile, final byte[] array, final long n) throws SQLException {
        this.assertNotNull(bfile.shareBytes(), "position");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long hasPattern = LobPlsqlUtil.hasPattern(bfile, array, n);
        return (hasPattern == 0L) ? -1L : hasPattern;
    }
    
    @Override
    public long position(final BFILE bfile, final BFILE bfile2, final long n) throws SQLException {
        this.assertNotNull(bfile.shareBytes(), "position");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long subLob = LobPlsqlUtil.isSubLob(bfile, bfile2, n);
        return (subLob == 0L) ? -1L : subLob;
    }
    
    @Override
    public synchronized int getBytes(final BFILE bfile, final long n, final int n2, final byte[] array) throws SQLException {
        this.assertLoggedOn("getBytes");
        this.assertNotNull(bfile.shareBytes(), "getBytes");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getBytes()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n2 <= 0 || array == null) {
            return 0;
        }
        if (this.pipeState != -1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 453, "getBytes()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.needLine();
        long read = 0L;
        if (n2 != 0) {
            try {
                read = this.bfileMsg.read(bfile.shareBytes(), n, n2, array, 0);
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        return (int)read;
    }
    
    @Override
    public String getName(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("getName");
        this.assertNotNull(bfile.shareBytes(), "getName");
        return LobPlsqlUtil.fileGetName(bfile);
    }
    
    @Override
    public String getDirAlias(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("getDirAlias");
        this.assertNotNull(bfile.shareBytes(), "getDirAlias");
        return LobPlsqlUtil.fileGetDirAlias(bfile);
    }
    
    @Override
    public synchronized void openFile(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("openFile");
        this.assertNotNull(bfile.shareBytes(), "openFile");
        this.needLine();
        try {
            this.bfileMsg.open(bfile.shareBytes(), 11);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized boolean isFileOpen(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("openFile");
        this.assertNotNull(bfile.shareBytes(), "openFile");
        this.needLine();
        boolean open;
        try {
            open = this.bfileMsg.isOpen(bfile.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return open;
    }
    
    @Override
    public synchronized boolean fileExists(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("fileExists");
        this.assertNotNull(bfile.shareBytes(), "fileExists");
        this.needLine();
        boolean doesExist;
        try {
            doesExist = this.bfileMsg.doesExist(bfile.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return doesExist;
    }
    
    @Override
    public synchronized void closeFile(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("closeFile");
        this.assertNotNull(bfile.shareBytes(), "closeFile");
        this.needLine();
        try {
            this.bfileMsg.close(bfile.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized void open(final BFILE bfile, final int n) throws SQLException {
        this.assertLoggedOn("open");
        this.assertNotNull(bfile.shareBytes(), "open");
        this.needLine();
        try {
            this.bfileMsg.open(bfile.shareBytes(), n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized void close(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("close");
        this.assertNotNull(bfile.shareBytes(), "close");
        this.needLine();
        try {
            this.bfileMsg.close(bfile.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized boolean isOpen(final BFILE bfile) throws SQLException {
        this.assertLoggedOn("isOpen");
        this.assertNotNull(bfile.shareBytes(), "isOpen");
        this.needLine();
        boolean open;
        try {
            open = this.bfileMsg.isOpen(bfile.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return open;
    }
    
    @Override
    public InputStream newInputStream(final BFILE bfile, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleBlobInputStream(bfile, n);
        }
        return new OracleBlobInputStream(bfile, n, n2);
    }
    
    @Override
    public InputStream newConversionInputStream(final BFILE bfile, final int n) throws SQLException {
        this.assertNotNull(bfile.shareBytes(), "newConversionInputStream");
        return new OracleConversionInputStream(this.conversion, bfile.getBinaryStream(), n);
    }
    
    @Override
    public Reader newConversionReader(final BFILE bfile, final int n) throws SQLException {
        this.assertNotNull(bfile.shareBytes(), "newConversionReader");
        return new OracleConversionReader(this.conversion, bfile.getBinaryStream(), n);
    }
    
    @Override
    public synchronized long length(final BLOB blob) throws SQLException {
        this.assertLoggedOn("length");
        this.assertNotNull(blob.shareBytes(), "length");
        this.needLine();
        long length;
        try {
            length = this.blobMsg.getLength(blob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return length;
    }
    
    @Override
    public long position(final BLOB blob, final byte[] array, final long n) throws SQLException {
        this.assertLoggedOn("position");
        this.assertNotNull(blob.shareBytes(), "position");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long hasPattern = LobPlsqlUtil.hasPattern(blob, array, n);
        return (hasPattern == 0L) ? -1L : hasPattern;
    }
    
    @Override
    public long position(final BLOB blob, final BLOB blob2, final long n) throws SQLException {
        this.assertLoggedOn("position");
        this.assertNotNull(blob.shareBytes(), "position");
        this.assertNotNull(blob2.shareBytes(), "position");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long subLob = LobPlsqlUtil.isSubLob(blob, blob2, n);
        return (subLob == 0L) ? -1L : subLob;
    }
    
    @Override
    public synchronized int getBytes(final BLOB blob, final long n, final int b, final byte[] array) throws SQLException {
        this.assertLoggedOn("getBytes");
        this.assertNotNull(blob.shareBytes(), "getBytes");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getBytes()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.pipeState != -1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 453, "getBytes()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (b <= 0 || array == null) {
            return 0;
        }
        long n2 = 0L;
        long length = -1L;
        if (blob.isActivePrefetch()) {
            final byte[] prefetchedData = blob.getPrefetchedData();
            final int prefetchedDataSize = blob.getPrefetchedDataSize();
            length = blob.length();
            int min = 0;
            if (prefetchedData != null) {
                min = Math.min(prefetchedDataSize, prefetchedData.length);
            }
            if (min > 0 && n <= min) {
                final int min2 = Math.min(min - (int)n + 1, b);
                System.arraycopy(prefetchedData, (int)n - 1, array, 0, min2);
                n2 += min2;
            }
        }
        if (n2 < b && (length == -1L || n - 1L + n2 < length)) {
            this.needLine();
            try {
                n2 += this.blobMsg.read(blob.shareBytes(), n + n2, b - n2, array, (int)n2);
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        return (int)n2;
    }
    
    @Override
    public synchronized int putBytes(final BLOB blob, final long n, final byte[] array, final int n2, final int n3) throws SQLException {
        this.assertLoggedOn("putBytes");
        this.assertNotNull(blob.shareBytes(), "putBytes");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "putBytes()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (array == null || n3 <= 0) {
            return 0;
        }
        this.needLine();
        long write = 0L;
        if (n3 != 0) {
            try {
                blob.setActivePrefetch(false);
                blob.clearCachedData();
                write = this.blobMsg.write(blob.shareBytes(), n, array, n2, n3);
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return (int)write;
    }
    
    @Override
    public synchronized int getChunkSize(final BLOB blob) throws SQLException {
        this.assertLoggedOn("getChunkSize");
        this.assertNotNull(blob.shareBytes(), "getChunkSize");
        this.needLine();
        long chunkSize;
        try {
            chunkSize = this.blobMsg.getChunkSize(blob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (int)chunkSize;
    }
    
    @Override
    public synchronized void trim(final BLOB blob, final long n) throws SQLException {
        this.assertLoggedOn("trim");
        this.assertNotNull(blob.shareBytes(), "trim");
        if (n < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "trim()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.needLine();
        try {
            blob.setActivePrefetch(false);
            blob.clearCachedData();
            this.blobMsg.trim(blob.shareBytes(), n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public synchronized BLOB createTemporaryBlob(final Connection connection, final boolean b, final int n) throws SQLException {
        this.assertLoggedOn("createTemporaryBlob");
        this.needLine();
        BLOB blob;
        try {
            blob = (BLOB)this.blobMsg.createTemporaryLob(this, b, n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return blob;
    }
    
    @Override
    public synchronized void freeTemporary(final BLOB blob, final boolean b) throws SQLException {
        this.assertLoggedOn("freeTemporary");
        this.assertNotNull(blob.shareBytes(), "freeTemporary");
        this.needLine();
        try {
            this.blobMsg.freeTemporaryLob(blob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public boolean isTemporary(final BLOB blob) throws SQLException {
        this.assertNotNull(blob.shareBytes(), "isTemporary");
        boolean b = false;
        final byte[] shareBytes = blob.shareBytes();
        if ((shareBytes[7] & 0x1) > 0 || (shareBytes[4] & 0x40) > 0) {
            b = true;
        }
        return b;
    }
    
    @Override
    public synchronized void open(final BLOB blob, final int n) throws SQLException {
        this.assertLoggedOn("open");
        this.assertNotNull(blob.shareBytes(), "open");
        this.needLine();
        try {
            this.blobMsg.open(blob.shareBytes(), n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized void close(final BLOB blob) throws SQLException {
        this.assertLoggedOn("close");
        this.assertNotNull(blob.shareBytes(), "close");
        this.needLine();
        try {
            this.blobMsg.close(blob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized boolean isOpen(final BLOB blob) throws SQLException {
        this.assertLoggedOn("isOpen");
        this.assertNotNull(blob.shareBytes(), "isOpen");
        this.needLine();
        boolean open;
        try {
            open = this.blobMsg.isOpen(blob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return open;
    }
    
    @Override
    public InputStream newInputStream(final BLOB blob, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleBlobInputStream(blob, n);
        }
        return new OracleBlobInputStream(blob, n, n2);
    }
    
    @Override
    public InputStream newInputStream(final BLOB blob, final int n, final long n2, final long n3) throws SQLException {
        return new OracleBlobInputStream(blob, n, n2, n3);
    }
    
    @Override
    public OutputStream newOutputStream(final BLOB blob, final int n, final long n2, final boolean b) throws SQLException {
        if (n2 != 0L) {
            return new OracleBlobOutputStream(blob, n, n2);
        }
        if (b & this.lobStreamPosStandardCompliant) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleBlobOutputStream(blob, n);
    }
    
    @Override
    public InputStream newConversionInputStream(final BLOB blob, final int n) throws SQLException {
        this.assertNotNull(blob.shareBytes(), "newConversionInputStream");
        return new OracleConversionInputStream(this.conversion, blob.getBinaryStream(), n);
    }
    
    @Override
    public Reader newConversionReader(final BLOB blob, final int n) throws SQLException {
        this.assertNotNull(blob.shareBytes(), "newConversionReader");
        return new OracleConversionReader(this.conversion, blob.getBinaryStream(), n);
    }
    
    @Override
    public synchronized long length(final CLOB clob) throws SQLException {
        this.assertLoggedOn("length");
        this.assertNotNull(clob.shareBytes(), "length");
        this.needLine();
        long length;
        try {
            length = this.clobMsg.getLength(clob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return length;
    }
    
    @Override
    public long position(final CLOB clob, final String s, final long n) throws SQLException {
        if (s == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.assertLoggedOn("position");
        this.assertNotNull(clob.shareBytes(), "position");
        if (n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final char[] dst = new char[s.length()];
        s.getChars(0, dst.length, dst, 0);
        final long hasPattern = LobPlsqlUtil.hasPattern(clob, dst, n);
        return (hasPattern == 0L) ? -1L : hasPattern;
    }
    
    @Override
    public long position(final CLOB clob, final CLOB clob2, final long n) throws SQLException {
        if (clob2 == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.assertLoggedOn("position");
        this.assertNotNull(clob.shareBytes(), "position");
        this.assertNotNull(clob2.shareBytes(), "position");
        if (n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final long subLob = LobPlsqlUtil.isSubLob(clob, clob2, n);
        return (subLob == 0L) ? -1L : subLob;
    }
    
    @Override
    public synchronized int getChars(final CLOB clob, final long n, final int b, final char[] array) throws SQLException {
        this.assertLoggedOn("getChars");
        this.assertNotNull(clob.shareBytes(), "getChars");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getChars()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.pipeState != -1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 453, "getChars()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (b <= 0 || array == null) {
            return 0;
        }
        long n2 = 0L;
        long length = -1L;
        if (clob.isActivePrefetch()) {
            length = clob.length();
            final char[] prefetchedData = clob.getPrefetchedData();
            final int prefetchedDataSize = clob.getPrefetchedDataSize();
            int min = 0;
            if (prefetchedData != null) {
                min = Math.min(prefetchedDataSize, prefetchedData.length);
            }
            if (min > 0 && n <= min) {
                final int min2 = Math.min(min - (int)n + 1, b);
                System.arraycopy(prefetchedData, (int)n - 1, array, 0, min2);
                n2 += min2;
            }
        }
        if (n2 < b && (length == -1L || n - 1L + n2 < length)) {
            this.needLine();
            try {
                n2 += this.clobMsg.read(clob.shareBytes(), (int)n + n2, b - n2, clob.isNCLOB(), array, (int)n2);
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        return (int)n2;
    }
    
    @Override
    public synchronized int putChars(final CLOB clob, final long n, final char[] array, final int n2, final int n3) throws SQLException {
        this.assertLoggedOn("putChars");
        this.assertNotNull(clob.shareBytes(), "putChars");
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "putChars()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (array == null || n3 <= 0) {
            return 0;
        }
        this.needLine();
        long write = 0L;
        if (n3 != 0) {
            try {
                final boolean nclob = clob.isNCLOB();
                clob.setActivePrefetch(false);
                clob.clearCachedData();
                write = this.clobMsg.write(clob.shareBytes(), n, nclob, array, n2, n3);
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return (int)write;
    }
    
    @Override
    public synchronized int getChunkSize(final CLOB clob) throws SQLException {
        this.assertLoggedOn("getChunkSize");
        this.assertNotNull(clob.shareBytes(), "getChunkSize");
        this.needLine();
        long chunkSize;
        try {
            chunkSize = this.clobMsg.getChunkSize(clob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (int)chunkSize;
    }
    
    @Override
    public synchronized void trim(final CLOB clob, final long n) throws SQLException {
        this.assertLoggedOn("trim");
        this.assertNotNull(clob.shareBytes(), "trim");
        if (n < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "trim()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.needLine();
        try {
            clob.setActivePrefetch(false);
            clob.clearCachedData();
            this.clobMsg.trim(clob.shareBytes(), n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public synchronized CLOB createTemporaryClob(final Connection connection, final boolean b, final int n, final short n2) throws SQLException {
        this.assertLoggedOn("createTemporaryClob");
        this.needLine();
        CLOB clob;
        try {
            clob = (CLOB)this.clobMsg.createTemporaryLob(this, b, n, n2);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return clob;
    }
    
    @Override
    public synchronized void freeTemporary(final CLOB clob, final boolean b) throws SQLException {
        this.assertLoggedOn("freeTemporary");
        this.assertNotNull(clob.shareBytes(), "freeTemporary");
        this.needLine();
        try {
            this.clobMsg.freeTemporaryLob(clob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public boolean isTemporary(final CLOB clob) throws SQLException {
        boolean b = false;
        final byte[] shareBytes = clob.shareBytes();
        if ((shareBytes[7] & 0x1) > 0 || (shareBytes[4] & 0x40) > 0) {
            b = true;
        }
        return b;
    }
    
    @Override
    public synchronized void open(final CLOB clob, final int n) throws SQLException {
        this.assertLoggedOn("open");
        this.assertNotNull(clob.shareBytes(), "open");
        this.needLine();
        try {
            this.clobMsg.open(clob.shareBytes(), n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized void close(final CLOB clob) throws SQLException {
        this.assertLoggedOn("close");
        this.assertNotNull(clob.shareBytes(), "close");
        this.needLine();
        try {
            this.clobMsg.close(clob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public synchronized boolean isOpen(final CLOB clob) throws SQLException {
        this.assertLoggedOn("isOpen");
        this.assertNotNull(clob.shareBytes(), "isOpen");
        this.needLine();
        boolean open;
        try {
            open = this.clobMsg.isOpen(clob.shareBytes());
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return open;
    }
    
    @Override
    public InputStream newInputStream(final CLOB clob, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleClobInputStream(clob, n);
        }
        return new OracleClobInputStream(clob, n, n2);
    }
    
    @Override
    public OutputStream newOutputStream(final CLOB clob, final int n, final long n2, final boolean b) throws SQLException {
        if (n2 != 0L) {
            return new OracleClobOutputStream(clob, n, n2);
        }
        if (b & this.lobStreamPosStandardCompliant) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleClobOutputStream(clob, n);
    }
    
    @Override
    public Reader newReader(final CLOB clob, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleClobReader(clob, n);
        }
        return new OracleClobReader(clob, n, n2);
    }
    
    @Override
    public Reader newReader(final CLOB clob, final int n, final long n2, final long n3) throws SQLException {
        return new OracleClobReader(clob, n, n2, n3);
    }
    
    @Override
    public Writer newWriter(final CLOB clob, final int n, final long n2, final boolean b) throws SQLException {
        if (n2 != 0L) {
            return new OracleClobWriter(clob, n, n2);
        }
        if (b & this.lobStreamPosStandardCompliant) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleClobWriter(clob, n);
    }
    
    void assertLoggedOn(final String s) throws SQLException {
        if (!this.isLoggedOn) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 430);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void assertNotNull(final byte[] array, final String s) throws NullPointerException {
        if (array == null) {
            throw new NullPointerException("bytes are null");
        }
    }
    
    @Override
    void internalClose() throws SQLException {
        super.internalClose();
        this.isLoggedOn = false;
        try {
            if (this.net != null) {
                this.net.disconnect();
            }
        }
        catch (Exception ex) {}
    }
    
    @Override
    void doAbort() throws SQLException {
        try {
            this.net.abort();
        }
        catch (NetException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (IOException ex2) {
            this.handleIOException(ex2);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex2);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    protected void doDescribeTable(final AutoKeyInfo autoKeyInfo) throws SQLException {
        final T4CStatement t4CStatement = new T4CStatement(this, -1, -1);
        t4CStatement.open();
        t4CStatement.sqlObject.initialize("SELECT * FROM " + autoKeyInfo.getTableName());
        final Accessor[] array = null;
        Accessor[] accessors;
        try {
            this.describe.doODNY(t4CStatement, 0, array, t4CStatement.sqlObject.getSqlBytes(false, false));
            accessors = this.describe.getAccessors();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int numuds = this.describe.numuds;
        autoKeyInfo.allocateSpaceForDescribedData(numuds);
        for (int i = 0; i < numuds; ++i) {
            final Accessor accessor = accessors[i];
            autoKeyInfo.fillDescribedData(i, accessor.columnName, accessor.describeType, accessor.describeMaxLength, accessor.nullable, accessor.formOfUse, accessor.precision, accessor.scale, accessor.describeTypeName);
        }
        t4CStatement.close();
    }
    
    @Override
    void doSetApplicationContext(final String s, final String s2, final String s3) throws SQLException {
        Namespace value = this.namespaces.get(s);
        if (value == null) {
            value = new Namespace(s);
            this.namespaces.put(s, value);
        }
        value.setAttribute(s2, s3);
    }
    
    @Override
    void doClearAllApplicationContext(final String key) throws SQLException {
        final Namespace value = new Namespace(key);
        value.clear();
        this.namespaces.put(key, value);
    }
    
    @Override
    public void getPropertyForPooledConnection(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        super.getPropertyForPooledConnection(oraclePooledConnection, this.password);
    }
    
    final void getPasswordInternal(final T4CXAResource t4CXAResource) throws SQLException {
        t4CXAResource.setPasswordInternal(this.password);
    }
    
    @Override
    synchronized void doEnqueue(final String s, final AQEnqueueOptions aqEnqueueOptions, final AQMessagePropertiesI aqMessagePropertiesI, final byte[] array, final byte[] array2, final byte[][] array3, final boolean b) throws SQLException {
        try {
            this.needLine();
            this.sendPiggyBackedMessages();
            this.aqe.doOAQEQ(s, aqEnqueueOptions, aqMessagePropertiesI, array2, array, b);
            if (aqEnqueueOptions.getRetrieveMessageId()) {
                array3[0] = this.aqe.getMessageId();
            }
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    synchronized boolean doDequeue(final String s, final AQDequeueOptions aqDequeueOptions, final AQMessagePropertiesI aqMessagePropertiesI, final byte[] array, final byte[][] array2, final byte[][] array3, final boolean b) throws SQLException {
        boolean hasAMessageBeenDequeued;
        try {
            this.needLine();
            this.sendPiggyBackedMessages();
            this.aqdq.doOAQDQ(s, aqDequeueOptions, array, b, aqMessagePropertiesI);
            array2[0] = this.aqdq.getPayload();
            array3[0] = this.aqdq.getDequeuedMessageId();
            hasAMessageBeenDequeued = this.aqdq.hasAMessageBeenDequeued();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return hasAMessageBeenDequeued;
    }
    
    @Override
    synchronized int doPingDatabase() throws SQLException {
        if (this.versionNumber >= 10102) {
            try {
                this.needLine();
                this.sendPiggyBackedMessages();
                this.oping.doOPING();
            }
            catch (IOException ex) {
                return -1;
            }
            catch (SQLException ex2) {
                return -1;
            }
            return 0;
        }
        return super.doPingDatabase();
    }
    
    @Override
    synchronized NTFAQRegistration[] doRegisterAQNotification(final String[] array, final String str, int i, final Properties[] array2) throws SQLException {
        final int length = array.length;
        final int[] array3 = new int[length];
        final byte[][] array4 = new byte[length][];
        final int[] array5 = new int[length];
        final int[] array6 = new int[length];
        final int[] array7 = new int[length];
        final int[] array8 = new int[length];
        final int[] array9 = new int[length];
        final int[] array10 = new int[length];
        final long[] array11 = new long[length];
        final byte[] array12 = new byte[length];
        final int[] array13 = new int[length];
        final byte[] array14 = new byte[length];
        final TIMESTAMPTZ[] array15 = new TIMESTAMPTZ[length];
        final int[] array16 = new int[length];
        boolean b = false;
        if (i == 0) {
            b = true;
            i = 47632;
        }
        for (int j = 0; j < length; ++j) {
            array3[j] = PhysicalConnection.ntfManager.getNextJdbcRegId();
            (array4[j] = new byte[4])[0] = (byte)((array3[j] & 0xFF000000) >> 24);
            array4[j][1] = (byte)((array3[j] & 0xFF0000) >> 16);
            array4[j][2] = (byte)((array3[j] & 0xFF00) >> 8);
            array4[j][3] = (byte)(array3[j] & 0xFF);
            array5[j] = 1;
            array6[j] = 23;
            if (array2.length > j && array2[j] != null) {
                if (array2[j].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0) {
                    final int[] array17 = array7;
                    final int n = j;
                    array17[n] |= 0x1;
                }
                if (array2[j].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0) {
                    final int[] array18 = array7;
                    final int n2 = j;
                    array18[n2] |= 0x10;
                }
                if (array2[j].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0) {
                    final int[] array19 = array7;
                    final int n3 = j;
                    array19[n3] |= 0x2;
                }
                array8[j] = this.readNTFtimeout(array2[j]);
            }
        }
        this.setNtfGroupingOptions(array12, array13, array14, array15, array16, array2);
        final int[] array20 = { i };
        final int listenOnPortT4C = PhysicalConnection.ntfManager.listenOnPortT4C(array20, b) ? 1 : 0;
        i = array20[0];
        final String string = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str + ")(PORT=" + i + "))?PR=0";
        try {
            try {
                final int n4 = listenOnPortT4C;
                this.sendPiggyBackedMessages();
                this.okpn.doOKPN(1, n4, this.userName, string, length, array5, array, array4, array6, array7, array8, array9, array10, array11, array12, array13, array14, array15, array16);
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex2) {
            if (listenOnPortT4C != 0) {
                PhysicalConnection.ntfManager.cleanListenersT4C(i);
            }
            throw ex2;
        }
        final NTFAQRegistration[] array21 = new NTFAQRegistration[length];
        for (int k = 0; k < length; ++k) {
            array21[k] = new NTFAQRegistration(array3[k], true, this.instanceName, this.userName, str, i, array2[k], array[k], this.versionNumber);
        }
        for (int l = 0; l < array21.length; ++l) {
            PhysicalConnection.ntfManager.addRegistration(array21[l]);
        }
        return array21;
    }
    
    private void setNtfGroupingOptions(final byte[] array, final int[] array2, final byte[] array3, final TIMESTAMPTZ[] array4, final int[] array5, final Properties[] array6) throws SQLException {
        for (int i = 0; i < array6.length; ++i) {
            final String property = array6[i].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
            final String property2 = array6[i].getProperty("NTF_GROUPING_VALUE");
            final String property3 = array6[i].getProperty("NTF_GROUPING_TYPE");
            TIMESTAMPTZ timestamptz = null;
            if (array6[i].get("NTF_GROUPING_START_TIME") != null) {
                timestamptz = (TIMESTAMPTZ)array6[i].get("NTF_GROUPING_START_TIME");
            }
            final String property4 = array6[i].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
            if (property.compareTo("NTF_GROUPING_CLASS_TIME") != 0 && property.compareTo("NTF_GROUPING_CLASS_NONE") != 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (property.compareTo("NTF_GROUPING_CLASS_NONE") != 0 && this.getTTCVersion() < 5) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (property.compareTo("NTF_GROUPING_CLASS_TIME") == 0) {
                array[i] = 1;
                array2[i] = 600;
                if (property2 != null) {
                    array2[i] = Integer.parseInt(property2);
                }
                array3[i] = 1;
                if (property3 != null) {
                    if (property3.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0) {
                        array3[i] = 1;
                    }
                    else {
                        if (property3.compareTo("NTF_GROUPING_TYPE_LAST") != 0) {
                            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                            sqlException3.fillInStackTrace();
                            throw sqlException3;
                        }
                        array3[i] = 2;
                    }
                }
                array4[i] = timestamptz;
                if (property4.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0) {
                    array5[i] = 0;
                }
                else {
                    array5[i] = Integer.parseInt(property4);
                }
            }
        }
    }
    
    @Override
    synchronized void doUnregisterAQNotification(final NTFAQRegistration ntfaqRegistration) throws SQLException {
        final String clientHost = ntfaqRegistration.getClientHost();
        final int clientTCPPort = ntfaqRegistration.getClientTCPPort();
        if (clientHost == null) {
            return;
        }
        PhysicalConnection.ntfManager.removeRegistration(ntfaqRegistration);
        PhysicalConnection.ntfManager.freeJdbcRegId(ntfaqRegistration.getJdbcRegId());
        PhysicalConnection.ntfManager.cleanListenersT4C(ntfaqRegistration.getClientTCPPort());
        ntfaqRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
        final String string = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + clientHost + ")(PORT=" + clientTCPPort + "))?PR=0";
        final int[] array = { 1 };
        final String[] array2 = { ntfaqRegistration.getQueueName() };
        final int[] array3 = { 0 };
        final int[] array4 = { 0 };
        final int[] array5 = { 0 };
        final int[] array6 = { 0 };
        final int[] array7 = { 0 };
        final long[] array8 = { 0L };
        final byte[] array9 = { 0 };
        final int[] array10 = { 0 };
        final byte[] array11 = { 0 };
        final TIMESTAMPTZ[] array12 = { null };
        final int[] array13 = { 0 };
        final byte[][] array14 = { null };
        final int jdbcRegId = ntfaqRegistration.getJdbcRegId();
        (array14[0] = new byte[4])[0] = (byte)((jdbcRegId & 0xFF000000) >> 24);
        array14[0][1] = (byte)((jdbcRegId & 0xFF0000) >> 16);
        array14[0][2] = (byte)((jdbcRegId & 0xFF00) >> 8);
        array14[0][3] = (byte)(jdbcRegId & 0xFF);
        try {
            this.sendPiggyBackedMessages();
            this.okpn.doOKPN(2, 0, this.userName, string, 1, array, array2, array14, array3, array4, array5, array6, array7, array8, array9, array10, array11, array12, array13);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(final String str, int i, final Properties properties, final int n, final int n2) throws SQLException {
        int n3 = 0;
        int n4 = 0;
        boolean b = false;
        if (i == 0) {
            b = true;
            i = 47632;
        }
        if (properties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0) {
            n4 |= 0x1;
        }
        if (properties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0) {
            n4 |= 0x10;
        }
        if (properties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0) {
            n3 |= 0x10;
        }
        if (properties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0) {
            n3 |= 0x20;
        }
        if (properties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0) {
            n3 |= 0x40;
        }
        boolean b2 = false;
        boolean b3 = false;
        boolean b4 = false;
        if (properties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0) {
            b2 = true;
        }
        if (properties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0) {
            b3 = true;
        }
        if (properties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0) {
            b4 = true;
        }
        if (b2 || b3 || b4) {
            n3 |= 0xF;
            if (b2) {
                n3 -= 2;
            }
            if (b3) {
                n3 -= 4;
            }
            if (b4) {
                n3 -= 8;
            }
        }
        final byte[] array = { 0 };
        final int[] array2 = { 0 };
        final byte[] array3 = { 0 };
        final TIMESTAMPTZ[] array4 = { null };
        final int[] array5 = { 0 };
        this.setNtfGroupingOptions(array, array2, array3, array4, array5, new Properties[] { properties });
        final int[] array6 = { i };
        final int listenOnPortT4C = PhysicalConnection.ntfManager.listenOnPortT4C(array6, b) ? 1 : 0;
        i = array6[0];
        final String string = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str + ")(PORT=" + i + "))?PR=0";
        final int[] array7 = { 2 };
        final String[] array8 = { null };
        final int[] array9 = { 23 };
        final int[] array10 = { n4 };
        final int[] array11 = { n };
        final int[] array12 = { n3 };
        final int[] array13 = { n2 };
        final long[] array14 = { 0L };
        final int nextJdbcRegId = PhysicalConnection.ntfManager.getNextJdbcRegId();
        final byte[][] array15 = { new byte[4] };
        array15[0][0] = (byte)((nextJdbcRegId & 0xFF000000) >> 24);
        array15[0][1] = (byte)((nextJdbcRegId & 0xFF0000) >> 16);
        array15[0][2] = (byte)((nextJdbcRegId & 0xFF00) >> 8);
        array15[0][3] = (byte)(nextJdbcRegId & 0xFF);
        long registrationId;
        try {
            try {
                final int n5 = listenOnPortT4C;
                this.sendPiggyBackedMessages();
                this.okpn.doOKPN(1, n5, this.userName, string, 1, array7, array8, array15, array9, array10, array11, array12, array13, array14, array, array2, array3, array4, array5);
                registrationId = this.okpn.getRegistrationId();
            }
            catch (IOException ex) {
                this.handleIOException(ex);
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex2) {
            if (listenOnPortT4C != 0) {
                PhysicalConnection.ntfManager.cleanListenersT4C(i);
            }
            throw ex2;
        }
        return new NTFDCNRegistration(nextJdbcRegId, true, this.instanceName, registrationId, this.userName, str, i, properties, this.versionNumber);
    }
    
    @Override
    synchronized void doUnregisterDatabaseChangeNotification(final long n, final String s) throws SQLException {
        final int[] array = { 2 };
        final String[] array2 = { null };
        final int[] array3 = { 0 };
        final int[] array4 = { 0 };
        final int[] array5 = { 0 };
        final int[] array6 = { 0 };
        final int[] array7 = { 0 };
        final byte[] array8 = { 0 };
        final int[] array9 = { 0 };
        final byte[] array10 = { 0 };
        final TIMESTAMPTZ[] array11 = { null };
        final int[] array12 = { 0 };
        final long[] array13 = { n };
        final byte[][] array14 = { null };
        try {
            this.sendPiggyBackedMessages();
            this.okpn.doOKPN(2, 0, null, s, 1, array, array2, array14, array3, array4, array5, array6, array7, array13, array8, array9, array10, array11, array12);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    synchronized void doUnregisterDatabaseChangeNotification(final NTFDCNRegistration ntfdcnRegistration) throws SQLException {
        PhysicalConnection.ntfManager.removeRegistration(ntfdcnRegistration);
        PhysicalConnection.ntfManager.freeJdbcRegId(ntfdcnRegistration.getJdbcRegId());
        PhysicalConnection.ntfManager.cleanListenersT4C(ntfdcnRegistration.getClientTCPPort());
        ntfdcnRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
        this.doUnregisterDatabaseChangeNotification(ntfdcnRegistration.getRegId(), "(ADDRESS=(PROTOCOL=tcp)(HOST=" + ntfdcnRegistration.getClientHost() + ")(PORT=" + ntfdcnRegistration.getClientTCPPort() + "))?PR=0");
    }
    
    @Override
    public String getDataIntegrityAlgorithmName() throws SQLException {
        return this.net.getDataIntegrityName();
    }
    
    @Override
    public String getEncryptionAlgorithmName() throws SQLException {
        return this.net.getEncryptionName();
    }
    
    @Override
    public String getAuthenticationAdaptorName() throws SQLException {
        return this.net.getAuthenticationAdaptorName();
    }
    
    @Override
    void validateConnectionProperties() throws SQLException {
        super.validateConnectionProperties();
        final String regex = ".*[\\00\\(\\)].*";
        if (this.thinVsessionOsuser != null && (this.thinVsessionOsuser.matches(regex) || this.thinVsessionOsuser.length() > 30)) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.osuser' and value is '" + this.thinVsessionOsuser + "'");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.thinVsessionTerminal != null && (this.thinVsessionTerminal.matches(regex) || this.thinVsessionTerminal.length() > 30)) {
            final SQLException sqlException2 = DatabaseError.createSqlException(null, 190, "Property is 'v$session.terminal' and value is '" + this.thinVsessionTerminal + "'");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.thinVsessionMachine != null && (this.thinVsessionMachine.matches(regex) || this.thinVsessionMachine.length() > 64)) {
            final SQLException sqlException3 = DatabaseError.createSqlException(null, 190, "Property is 'v$session.machine' and value is '" + this.thinVsessionMachine + "'");
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        if (this.thinVsessionProgram != null && (this.thinVsessionProgram.matches(regex) || this.thinVsessionProgram.length() > 48)) {
            final SQLException sqlException4 = DatabaseError.createSqlException(null, 190, "Property is 'v$session.program' and value is '" + this.thinVsessionProgram + "'");
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        if (this.thinVsessionProcess != null && (this.thinVsessionProcess.matches(regex) || this.thinVsessionProcess.length() > 24)) {
            final SQLException sqlException5 = DatabaseError.createSqlException(null, 190, "Property is 'v$session.process' and value is '" + this.thinVsessionProcess + "'");
            sqlException5.fillInStackTrace();
            throw sqlException5;
        }
        if (this.thinVsessionIname != null && this.thinVsessionIname.matches(regex)) {
            final SQLException sqlException6 = DatabaseError.createSqlException(null, 190, "Property is 'v$session.iname' and value is '" + this.thinVsessionIname + "'");
            sqlException6.fillInStackTrace();
            throw sqlException6;
        }
        if (this.thinVsessionEname != null && this.thinVsessionEname.matches(regex)) {
            final SQLException sqlException7 = DatabaseError.createSqlException(null, 190, "Property is 'v$session.ename' and value is '" + this.thinVsessionEname + "'");
            sqlException7.fillInStackTrace();
            throw sqlException7;
        }
    }
    
    @Override
    public synchronized byte[] createLightweightSession(final String s, final KeywordValueLong[] array, final int n, final KeywordValueLong[][] array2, final int[] array3) throws SQLException {
        if (array2.length != 1 || array3.length != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        byte[] sessionId;
        try {
            this.sendPiggyBackedMessages();
            this.oxsscs.doOXSSCS(s, array, n);
            sessionId = this.oxsscs.getSessionId();
            array2[0] = this.oxsscs.getOutKV();
            array3[0] = this.oxsscs.getOutFlags();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return sessionId;
    }
    
    private synchronized void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2, final XSNamespace[][] array3, final boolean b) throws SQLException {
        XSNamespace[] namespaces = null;
        try {
            if (b) {
                this.sendPiggyBackedMessages();
            }
            this.xsnsop.doOXSNS(xsOperationCode, array, array2, b);
            if (b) {
                namespaces = this.xsnsop.getNamespaces();
            }
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (array3 != null && array3.length > 0) {
            array3[0] = namespaces;
        }
    }
    
    @Override
    public void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2, final XSNamespace[][] array3) throws SQLException {
        this.doXSNamespaceOp(xsOperationCode, array, array2, array3, true);
    }
    
    @Override
    public void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2) throws SQLException {
        this.doXSNamespaceOp(xsOperationCode, array, array2, null, false);
    }
    
    @Override
    public synchronized void executeLightweightSessionRoundtrip(final int n, final byte[] array, final KeywordValueLong[] array2, final int n2, final KeywordValueLong[][] array3, final int[] array4) throws SQLException {
        if (array3.length != 1 || array4.length != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        try {
            this.sendPiggyBackedMessages();
            this.oxssro.doOXSSRO(n, array, array2, n2);
            array3[0] = this.oxssro.getOutKV();
            array4[0] = this.oxssro.getOutFlags();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public synchronized void executeLightweightSessionPiggyback(final int n, final byte[] array, final KeywordValueLong[] array2, final int n2) throws SQLException {
        if (this.lusOffset2 == this.lusFunctionId2.length) {
            final int length = this.lusFunctionId2.length;
            final int[] lusFunctionId2 = new int[length * 2];
            System.arraycopy(this.lusFunctionId2, 0, lusFunctionId2, 0, length);
            final byte[][] lusSessionId2 = new byte[length * 2][];
            System.arraycopy(this.lusSessionId2, 0, lusSessionId2, 0, length);
            final KeywordValueLong[][] lusInKeyVal2 = new KeywordValueLong[length * 2][];
            System.arraycopy(this.lusInKeyVal2, 0, lusInKeyVal2, 0, length);
            final int[] lusInFlags2 = new int[length * 2];
            System.arraycopy(this.lusInFlags2, 0, lusInFlags2, 0, length);
            this.lusFunctionId2 = lusFunctionId2;
            this.lusSessionId2 = lusSessionId2;
            this.lusInKeyVal2 = lusInKeyVal2;
            this.lusInFlags2 = lusInFlags2;
        }
        this.lusFunctionId2[this.lusOffset2] = n;
        this.lusSessionId2[this.lusOffset2] = array;
        this.lusInKeyVal2[this.lusOffset2] = array2;
        this.lusInFlags2[this.lusOffset2] = n2;
        ++this.lusOffset2;
    }
    
    @Override
    public void addXSEventListener(final XSEventListener xsEventListener, final Executor executor) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final NTFEventListener ntfEventListener = new NTFEventListener(xsEventListener);
        ntfEventListener.setExecutor(executor);
        synchronized (this.xsListeners) {
            final int length = this.xsListeners.length;
            for (int i = 0; i < length; ++i) {
                if (this.xsListeners[i].getXSEventListener() == xsEventListener) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 248);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
            }
            final NTFEventListener[] xsListeners = new NTFEventListener[length + 1];
            System.arraycopy(this.xsListeners, 0, xsListeners, 0, length);
            xsListeners[length] = ntfEventListener;
            this.xsListeners = xsListeners;
        }
    }
    
    @Override
    public void addXSEventListener(final XSEventListener xsEventListener) throws SQLException {
        this.addXSEventListener(xsEventListener, null);
    }
    
    @Override
    public void removeXSEventListener(final XSEventListener xsEventListener) throws SQLException {
        synchronized (this.xsListeners) {
            int length;
            int n;
            for (length = this.xsListeners.length, n = 0; n < length && this.xsListeners[n].getXSEventListener() != xsEventListener; ++n) {}
            if (n == length) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 249);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final NTFEventListener[] xsListeners = new NTFEventListener[length - 1];
            int n2 = 0;
            for (int i = 0; i < length; ++i) {
                if (this.xsListeners[i].getXSEventListener() != xsEventListener) {
                    xsListeners[n2++] = this.xsListeners[i];
                }
            }
            this.xsListeners = xsListeners;
        }
    }
    
    void notify(final NTFXSEvent ntfxsEvent) {
        final NTFEventListener[] xsListeners = this.xsListeners;
        for (int length = xsListeners.length, i = 0; i < length; ++i) {
            final Executor executor = xsListeners[i].getExecutor();
            if (executor != null) {
                executor.execute(new Runnable() {
                    final /* synthetic */ XSEventListener val$l = xsListeners[i].getXSEventListener();
                    
                    @Override
                    public void run() {
                        this.val$l.onXSEvent(ntfxsEvent);
                    }
                });
            }
            else {
                xsListeners[i].getXSEventListener().onXSEvent(ntfxsEvent);
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
