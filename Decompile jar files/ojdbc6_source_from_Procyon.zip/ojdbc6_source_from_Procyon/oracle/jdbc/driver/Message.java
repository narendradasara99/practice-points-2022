// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

public interface Message
{
    String msg(final String p0, final Object p1);
}
