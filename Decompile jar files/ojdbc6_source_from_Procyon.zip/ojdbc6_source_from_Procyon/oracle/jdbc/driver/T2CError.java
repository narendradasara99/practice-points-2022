// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class T2CError
{
    int m_errorNumber;
    byte[] m_errorMessage;
    byte[] m_sqlState;
    
    T2CError() {
        this.m_errorMessage = new byte[1024];
        this.m_sqlState = new byte[6];
    }
}
