// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.concurrent.Executor;
import oracle.jdbc.internal.XSEventListener;
import oracle.sql.TIMEZONETAB;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.internal.KeywordValueLong;
import javax.transaction.xa.XAResource;
import oracle.sql.CustomDatum;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import oracle.jdbc.oracore.OracleTypeCLOB;
import java.sql.ResultSetMetaData;
import oracle.sql.StructDescriptor;
import oracle.sql.ArrayDescriptor;
import oracle.sql.ARRAY;
import java.sql.ResultSet;
import oracle.sql.Datum;
import oracle.jdbc.oracore.OracleTypeADT;
import java.util.Enumeration;
import oracle.sql.ClobDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.BfileDBAccess;
import java.util.Map;
import java.util.Properties;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OraclePooledConnection;

class LogicalConnection extends OracleConnection
{
    static final ClosedConnection closedConnection;
    PhysicalConnection internalConnection;
    OraclePooledConnection pooledConnection;
    boolean closed;
    OracleCloseCallback closeCallback;
    Object privateData;
    long startTime;
    OracleConnectionCacheCallback connectionCacheCallback;
    Object connectionCacheCallbackUserObj;
    int callbackFlag;
    int releasePriority;
    int heartbeatCount;
    int heartbeatLastCount;
    int heartbeatNoChangeCount;
    boolean isAbandonedTimeoutEnabled;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    LogicalConnection(final OraclePooledConnection pooledConnection, final PhysicalConnection internalConnection, final boolean autoCommit) throws SQLException {
        this.closeCallback = null;
        this.privateData = null;
        this.startTime = 0L;
        this.connectionCacheCallback = null;
        this.connectionCacheCallbackUserObj = null;
        this.callbackFlag = 0;
        this.releasePriority = 0;
        this.heartbeatCount = 0;
        this.heartbeatLastCount = 0;
        this.heartbeatNoChangeCount = 0;
        this.isAbandonedTimeoutEnabled = false;
        this.internalConnection = internalConnection;
        this.pooledConnection = pooledConnection;
        (this.connection = this.internalConnection).setWrapper(this);
        this.closed = false;
        this.internalConnection.setAutoCommit(autoCommit);
    }
    
    void registerHeartbeat() throws SQLException {
        if (this.isAbandonedTimeoutEnabled) {
            try {
                ++this.heartbeatCount;
            }
            catch (ArithmeticException ex) {
                this.heartbeatCount = 0;
            }
        }
    }
    
    @Override
    public int getHeartbeatNoChangeCount() throws SQLException {
        if (this.heartbeatCount == this.heartbeatLastCount) {
            ++this.heartbeatNoChangeCount;
        }
        else {
            this.heartbeatLastCount = this.heartbeatCount;
            this.heartbeatNoChangeCount = 0;
        }
        return this.heartbeatNoChangeCount;
    }
    
    @Override
    public oracle.jdbc.internal.OracleConnection physicalConnectionWithin() {
        return this.internalConnection;
    }
    
    public synchronized void registerCloseCallback(final OracleCloseCallback closeCallback, final Object privateData) {
        this.closeCallback = closeCallback;
        this.privateData = privateData;
    }
    
    @Override
    public Connection _getPC() {
        return this.internalConnection;
    }
    
    @Override
    public synchronized boolean isLogicalConnection() {
        return true;
    }
    
    @Override
    public oracle.jdbc.internal.OracleConnection getPhysicalConnection() {
        return this.internalConnection;
    }
    
    @Override
    public Connection getLogicalConnection(final OraclePooledConnection oraclePooledConnection, final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 153);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void getPropertyForPooledConnection(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 153);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized void close() throws SQLException {
        this.closeInternal(true);
    }
    
    @Override
    public void closeInternal(final boolean b) throws SQLException {
        if (this.closed) {
            return;
        }
        if (this.closeCallback != null) {
            this.closeCallback.beforeClose(this, this.privateData);
        }
        this.internalConnection.closeLogicalConnection();
        this.startTime = 0L;
        this.closed = true;
        if (this.pooledConnection != null && b) {
            this.pooledConnection.logicalClose();
        }
        this.internalConnection = LogicalConnection.closedConnection;
        this.connection = LogicalConnection.closedConnection;
        if (this.closeCallback != null) {
            this.closeCallback.afterClose(this.privateData);
        }
    }
    
    @Override
    public void cleanupAndClose(final boolean b) throws SQLException {
        if (this.closed) {
            return;
        }
        this.closed = true;
        final PhysicalConnection internalConnection = this.internalConnection;
        final OraclePooledConnection pooledConnection = this.pooledConnection;
        this.internalConnection = LogicalConnection.closedConnection;
        this.connection = LogicalConnection.closedConnection;
        this.startTime = 0L;
        if (this.closeCallback != null) {
            this.closeCallback.beforeClose(this, this.privateData);
        }
        internalConnection.cleanupAndClose();
        internalConnection.closeLogicalConnection();
        if (pooledConnection != null && b) {
            pooledConnection.logicalClose();
        }
        if (this.closeCallback != null) {
            this.closeCallback.afterClose(this.privateData);
        }
    }
    
    @Override
    public void abort() throws SQLException {
        if (this.closed) {
            return;
        }
        this.internalConnection.abort();
        this.closed = true;
        this.internalConnection = LogicalConnection.closedConnection;
        this.connection = LogicalConnection.closedConnection;
    }
    
    @Override
    public synchronized void close(final Properties t) throws SQLException {
        if (this.pooledConnection != null) {
            this.pooledConnection.cachedConnectionAttributes.clear();
            this.pooledConnection.cachedConnectionAttributes.putAll(t);
        }
        this.close();
    }
    
    @Override
    public synchronized void close(final int closeOption) throws SQLException {
        if ((closeOption & 0x1000) != 0x0) {
            if (this.pooledConnection != null) {
                this.pooledConnection.closeOption = closeOption;
            }
            this.close();
            return;
        }
        if ((closeOption & 0x1) != 0x0) {
            this.internalConnection.close(1);
        }
    }
    
    @Override
    public synchronized void applyConnectionAttributes(final Properties t) throws SQLException {
        if (this.pooledConnection != null) {
            this.pooledConnection.cachedConnectionAttributes.putAll(t);
        }
    }
    
    @Override
    public synchronized Properties getConnectionAttributes() throws SQLException {
        if (this.pooledConnection != null) {
            return this.pooledConnection.cachedConnectionAttributes;
        }
        return null;
    }
    
    @Override
    public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
        if (this.pooledConnection != null) {
            return this.pooledConnection.unMatchedCachedConnAttr;
        }
        return null;
    }
    
    @Override
    public synchronized void setAbandonedTimeoutEnabled(final boolean b) throws SQLException {
        this.isAbandonedTimeoutEnabled = true;
    }
    
    @Override
    public synchronized void registerConnectionCacheCallback(final OracleConnectionCacheCallback connectionCacheCallback, final Object connectionCacheCallbackUserObj, final int callbackFlag) throws SQLException {
        this.connectionCacheCallback = connectionCacheCallback;
        this.connectionCacheCallbackUserObj = connectionCacheCallbackUserObj;
        this.callbackFlag = callbackFlag;
    }
    
    @Override
    public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
        return this.connectionCacheCallback;
    }
    
    @Override
    public Object getConnectionCacheCallbackPrivObj() throws SQLException {
        return this.connectionCacheCallbackUserObj;
    }
    
    @Override
    public int getConnectionCacheCallbackFlag() throws SQLException {
        return this.callbackFlag;
    }
    
    @Override
    public synchronized void setConnectionReleasePriority(final int releasePriority) throws SQLException {
        this.releasePriority = releasePriority;
    }
    
    @Override
    public int getConnectionReleasePriority() throws SQLException {
        return this.releasePriority;
    }
    
    @Override
    public synchronized boolean isClosed() throws SQLException {
        return this.closed;
    }
    
    @Override
    public void setStartTime(final long startTime) throws SQLException {
        if (startTime <= 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.startTime = startTime;
    }
    
    @Override
    public long getStartTime() throws SQLException {
        return this.startTime;
    }
    
    @Override
    public String getDatabaseTimeZone() throws SQLException {
        return this.internalConnection.getDatabaseTimeZone();
    }
    
    @Override
    public Properties getServerSessionInfo() throws SQLException {
        return this.internalConnection.getServerSessionInfo();
    }
    
    @Override
    public Object getClientData(final Object o) {
        return this.internalConnection.getClientData(o);
    }
    
    @Override
    public Object setClientData(final Object o, final Object o2) {
        return this.internalConnection.setClientData(o, o2);
    }
    
    @Override
    public Object removeClientData(final Object o) {
        return this.internalConnection.removeClientData(o);
    }
    
    @Override
    public void setClientIdentifier(final String clientIdentifier) throws SQLException {
        this.internalConnection.setClientIdentifier(clientIdentifier);
    }
    
    @Override
    public void clearClientIdentifier(final String s) throws SQLException {
        this.internalConnection.clearClientIdentifier(s);
    }
    
    @Override
    public short getStructAttrNCsId() throws SQLException {
        return this.internalConnection.getStructAttrNCsId();
    }
    
    @Override
    public Map getTypeMap() throws SQLException {
        return this.internalConnection.getTypeMap();
    }
    
    @Override
    public Properties getDBAccessProperties() throws SQLException {
        return this.internalConnection.getDBAccessProperties();
    }
    
    @Override
    public Properties getOCIHandles() throws SQLException {
        return this.internalConnection.getOCIHandles();
    }
    
    @Override
    public String getDatabaseProductVersion() throws SQLException {
        return this.internalConnection.getDatabaseProductVersion();
    }
    
    @Override
    public void cancel() throws SQLException {
        this.registerHeartbeat();
        this.internalConnection.cancel();
    }
    
    @Override
    public String getURL() throws SQLException {
        return this.internalConnection.getURL();
    }
    
    @Override
    public boolean getIncludeSynonyms() {
        return this.internalConnection.getIncludeSynonyms();
    }
    
    @Override
    public boolean getRemarksReporting() {
        return this.internalConnection.getRemarksReporting();
    }
    
    @Override
    public boolean getRestrictGetTables() {
        return this.internalConnection.getRestrictGetTables();
    }
    
    @Override
    public short getVersionNumber() throws SQLException {
        return this.internalConnection.getVersionNumber();
    }
    
    @Override
    public Map getJavaObjectTypeMap() {
        return this.internalConnection.getJavaObjectTypeMap();
    }
    
    @Override
    public void setJavaObjectTypeMap(final Map javaObjectTypeMap) {
        this.internalConnection.setJavaObjectTypeMap(javaObjectTypeMap);
    }
    
    @Override
    public BfileDBAccess createBfileDBAccess() throws SQLException {
        return this.internalConnection.createBfileDBAccess();
    }
    
    @Override
    public BlobDBAccess createBlobDBAccess() throws SQLException {
        return this.internalConnection.createBlobDBAccess();
    }
    
    @Override
    public ClobDBAccess createClobDBAccess() throws SQLException {
        return this.internalConnection.createClobDBAccess();
    }
    
    @Override
    public void setDefaultFixedString(final boolean defaultFixedString) {
        this.internalConnection.setDefaultFixedString(defaultFixedString);
    }
    
    @Override
    public boolean getTimestamptzInGmt() {
        return this.internalConnection.getTimestamptzInGmt();
    }
    
    @Override
    public boolean getDefaultFixedString() {
        return this.internalConnection.getDefaultFixedString();
    }
    
    @Override
    public oracle.jdbc.OracleConnection getWrapper() {
        return this;
    }
    
    @Override
    public Class classForNameAndSchema(final String s, final String s2) throws ClassNotFoundException {
        return this.internalConnection.classForNameAndSchema(s, s2);
    }
    
    @Override
    public void setFDO(final byte[] fdo) throws SQLException {
        this.internalConnection.setFDO(fdo);
    }
    
    @Override
    public byte[] getFDO(final boolean b) throws SQLException {
        return this.internalConnection.getFDO(b);
    }
    
    @Override
    public boolean getBigEndian() throws SQLException {
        return this.internalConnection.getBigEndian();
    }
    
    @Override
    public Object getDescriptor(final byte[] array) {
        return this.internalConnection.getDescriptor(array);
    }
    
    @Override
    public void putDescriptor(final byte[] array, final Object o) throws SQLException {
        this.internalConnection.putDescriptor(array, o);
    }
    
    @Override
    public void removeDescriptor(final String s) {
        this.internalConnection.removeDescriptor(s);
    }
    
    @Override
    public void removeAllDescriptor() {
        this.internalConnection.removeAllDescriptor();
    }
    
    @Override
    public int numberOfDescriptorCacheEntries() {
        return this.internalConnection.numberOfDescriptorCacheEntries();
    }
    
    @Override
    public Enumeration descriptorCacheKeys() {
        return this.internalConnection.descriptorCacheKeys();
    }
    
    public void getOracleTypeADT(final OracleTypeADT oracleTypeADT) throws SQLException {
        this.internalConnection.getOracleTypeADT(oracleTypeADT);
    }
    
    @Override
    public short getDbCsId() throws SQLException {
        return this.internalConnection.getDbCsId();
    }
    
    @Override
    public short getJdbcCsId() throws SQLException {
        return this.internalConnection.getJdbcCsId();
    }
    
    @Override
    public short getNCharSet() {
        return this.internalConnection.getNCharSet();
    }
    
    @Override
    public ResultSet newArrayDataResultSet(final Datum[] array, final long n, final int n2, final Map map) throws SQLException {
        return this.internalConnection.newArrayDataResultSet(array, n, n2, map);
    }
    
    @Override
    public ResultSet newArrayDataResultSet(final ARRAY array, final long n, final int n2, final Map map) throws SQLException {
        return this.internalConnection.newArrayDataResultSet(array, n, n2, map);
    }
    
    @Override
    public ResultSet newArrayLocatorResultSet(final ArrayDescriptor arrayDescriptor, final byte[] array, final long n, final int n2, final Map map) throws SQLException {
        return this.internalConnection.newArrayLocatorResultSet(arrayDescriptor, array, n, n2, map);
    }
    
    @Override
    public ResultSetMetaData newStructMetaData(final StructDescriptor structDescriptor) throws SQLException {
        return this.internalConnection.newStructMetaData(structDescriptor);
    }
    
    @Override
    public void getForm(final OracleTypeADT oracleTypeADT, final OracleTypeCLOB oracleTypeCLOB, final int n) throws SQLException {
        this.internalConnection.getForm(oracleTypeADT, oracleTypeCLOB, n);
    }
    
    @Override
    public int CHARBytesToJavaChars(final byte[] array, final int n, final char[] array2) throws SQLException {
        return this.internalConnection.CHARBytesToJavaChars(array, n, array2);
    }
    
    @Override
    public int NCHARBytesToJavaChars(final byte[] array, final int n, final char[] array2) throws SQLException {
        return this.internalConnection.NCHARBytesToJavaChars(array, n, array2);
    }
    
    @Override
    public boolean IsNCharFixedWith() {
        return this.internalConnection.IsNCharFixedWith();
    }
    
    @Override
    public short getDriverCharSet() {
        return this.internalConnection.getDriverCharSet();
    }
    
    @Override
    public int getC2SNlsRatio() {
        return this.internalConnection.getC2SNlsRatio();
    }
    
    @Override
    public int getMaxCharSize() throws SQLException {
        return this.internalConnection.getMaxCharSize();
    }
    
    @Override
    public int getMaxCharbyteSize() {
        return this.internalConnection.getMaxCharbyteSize();
    }
    
    @Override
    public int getMaxNCharbyteSize() {
        return this.internalConnection.getMaxNCharbyteSize();
    }
    
    @Override
    public boolean isCharSetMultibyte(final short n) {
        return this.internalConnection.isCharSetMultibyte(n);
    }
    
    @Override
    public int javaCharsToCHARBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.internalConnection.javaCharsToCHARBytes(array, n, array2);
    }
    
    @Override
    public int javaCharsToNCHARBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.internalConnection.javaCharsToNCHARBytes(array, n, array2);
    }
    
    @Override
    public int getStmtCacheSize() {
        return this.internalConnection.getStmtCacheSize();
    }
    
    @Override
    public int getStatementCacheSize() throws SQLException {
        return this.internalConnection.getStatementCacheSize();
    }
    
    @Override
    public boolean getImplicitCachingEnabled() throws SQLException {
        return this.internalConnection.getImplicitCachingEnabled();
    }
    
    @Override
    public boolean getExplicitCachingEnabled() throws SQLException {
        return this.internalConnection.getExplicitCachingEnabled();
    }
    
    @Override
    public void purgeImplicitCache() throws SQLException {
        this.internalConnection.purgeImplicitCache();
    }
    
    @Override
    public void purgeExplicitCache() throws SQLException {
        this.internalConnection.purgeExplicitCache();
    }
    
    @Override
    public PreparedStatement getStatementWithKey(final String s) throws SQLException {
        return this.internalConnection.getStatementWithKey(s);
    }
    
    @Override
    public CallableStatement getCallWithKey(final String s) throws SQLException {
        return this.internalConnection.getCallWithKey(s);
    }
    
    @Override
    public boolean isStatementCacheInitialized() {
        return this.internalConnection.isStatementCacheInitialized();
    }
    
    @Override
    public void setTypeMap(final Map typeMap) {
        this.internalConnection.setTypeMap(typeMap);
    }
    
    @Override
    public String getProtocolType() {
        return this.internalConnection.getProtocolType();
    }
    
    @Override
    public void setTxnMode(final int txnMode) {
        this.internalConnection.setTxnMode(txnMode);
    }
    
    @Override
    public int getTxnMode() {
        return this.internalConnection.getTxnMode();
    }
    
    @Override
    public int getHeapAllocSize() throws SQLException {
        return this.internalConnection.getHeapAllocSize();
    }
    
    @Override
    public int getOCIEnvHeapAllocSize() throws SQLException {
        return this.internalConnection.getOCIEnvHeapAllocSize();
    }
    
    @Override
    public CLOB createClob(final byte[] array) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createClob(array);
    }
    
    @Override
    public CLOB createClobWithUnpickledBytes(final byte[] array) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createClobWithUnpickledBytes(array);
    }
    
    @Override
    public CLOB createClob(final byte[] array, final short n) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createClob(array, n);
    }
    
    @Override
    public BLOB createBlob(final byte[] array) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createBlob(array);
    }
    
    @Override
    public BLOB createBlobWithUnpickledBytes(final byte[] array) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createBlobWithUnpickledBytes(array);
    }
    
    @Override
    public BFILE createBfile(final byte[] array) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createBfile(array);
    }
    
    @Override
    public boolean isDescriptorSharable(final oracle.jdbc.internal.OracleConnection oracleConnection) throws SQLException {
        return this.internalConnection.isDescriptorSharable(oracleConnection);
    }
    
    @Override
    public OracleStatement refCursorCursorToStatement(final int n) throws SQLException {
        return this.internalConnection.refCursorCursorToStatement(n);
    }
    
    @Override
    public long getTdoCState(final String s, final String s2) throws SQLException {
        return this.internalConnection.getTdoCState(s, s2);
    }
    
    @Override
    public Datum toDatum(final CustomDatum customDatum) throws SQLException {
        return this.internalConnection.toDatum(customDatum);
    }
    
    @Override
    public XAResource getXAResource() throws SQLException {
        return this.pooledConnection.getXAResource();
    }
    
    @Override
    public void setApplicationContext(final String s, final String s2, final String s3) throws SQLException {
        this.internalConnection.setApplicationContext(s, s2, s3);
    }
    
    @Override
    public void clearAllApplicationContext(final String s) throws SQLException {
        this.internalConnection.clearAllApplicationContext(s);
    }
    
    @Override
    public boolean isGetObjectReturnsXMLType() {
        return this.internalConnection.getObjectReturnsXmlType;
    }
    
    @Override
    @Deprecated
    public boolean isV8Compatible() throws SQLException {
        return this.getMapDateToTimestamp();
    }
    
    @Override
    public boolean getMapDateToTimestamp() {
        return this.internalConnection.getMapDateToTimestamp();
    }
    
    @Override
    public byte[] createLightweightSession(final String s, final KeywordValueLong[] array, final int n, final KeywordValueLong[][] array2, final int[] array3) throws SQLException {
        return this.internalConnection.createLightweightSession(s, array, n, array2, array3);
    }
    
    @Override
    public void executeLightweightSessionRoundtrip(final int n, final byte[] array, final KeywordValueLong[] array2, final int n2, final KeywordValueLong[][] array3, final int[] array4) throws SQLException {
        this.internalConnection.executeLightweightSessionRoundtrip(n, array, array2, n2, array3, array4);
    }
    
    @Override
    public void executeLightweightSessionPiggyback(final int n, final byte[] array, final KeywordValueLong[] array2, final int n2) throws SQLException {
        this.internalConnection.executeLightweightSessionPiggyback(n, array, array2, n2);
    }
    
    @Override
    public void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2, final XSNamespace[][] array3) throws SQLException {
        this.internalConnection.doXSNamespaceOp(xsOperationCode, array, array2, array3);
    }
    
    @Override
    public void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2) throws SQLException {
        this.internalConnection.doXSNamespaceOp(xsOperationCode, array, array2);
    }
    
    public BLOB createTemporaryBlob(final Connection connection, final boolean b, final int n) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createTemporaryBlob(connection, b, n);
    }
    
    public CLOB createTemporaryClob(final Connection connection, final boolean b, final int n, final short n2) throws SQLException {
        this.registerHeartbeat();
        return this.internalConnection.createTemporaryClob(connection, b, n, n2);
    }
    
    @Override
    public String getDefaultSchemaNameForNamedTypes() throws SQLException {
        return this.internalConnection.getDefaultSchemaNameForNamedTypes();
    }
    
    @Override
    public boolean isUsable() {
        return !this.closed && this.internalConnection.isUsable();
    }
    
    @Override
    public byte getInstanceProperty(final InstanceProperty instanceProperty) throws SQLException {
        return this.internalConnection.getInstanceProperty(instanceProperty);
    }
    
    @Override
    public void setUsable(final boolean usable) {
        this.internalConnection.setUsable(usable);
    }
    
    @Override
    public int getTimezoneVersionNumber() throws SQLException {
        return this.internalConnection.getTimezoneVersionNumber();
    }
    
    @Override
    public TIMEZONETAB getTIMEZONETAB() throws SQLException {
        return this.internalConnection.getTIMEZONETAB();
    }
    
    @Override
    public void addXSEventListener(final XSEventListener xsEventListener) throws SQLException {
        this.internalConnection.addXSEventListener(xsEventListener);
    }
    
    @Override
    public void addXSEventListener(final XSEventListener xsEventListener, final Executor executor) throws SQLException {
        this.internalConnection.addXSEventListener(xsEventListener, executor);
    }
    
    @Override
    public void removeXSEventListener(final XSEventListener xsEventListener) throws SQLException {
        this.internalConnection.removeXSEventListener(xsEventListener);
    }
    
    @Override
    public BufferCacheStatistics getByteBufferCacheStatistics() {
        return this.internalConnection.getByteBufferCacheStatistics();
    }
    
    @Override
    public BufferCacheStatistics getCharBufferCacheStatistics() {
        return this.internalConnection.getCharBufferCacheStatistics();
    }
    
    @Override
    public boolean isDataInLocatorEnabled() throws SQLException {
        return this.internalConnection.isDataInLocatorEnabled();
    }
    
    static {
        closedConnection = new ClosedConnection();
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
