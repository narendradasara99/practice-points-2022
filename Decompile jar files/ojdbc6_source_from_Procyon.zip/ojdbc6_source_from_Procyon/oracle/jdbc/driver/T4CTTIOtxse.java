// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;

final class T4CTTIOtxse extends T4CTTIfun
{
    static final int OTXSTA = 1;
    static final int OTXDET = 2;
    static final int OCI_TRANS_NEW = 1;
    static final int OCI_TRANS_JOIN = 2;
    static final int OCI_TRANS_RESUME = 4;
    static final int OCI_TRANS_STARTMASK = 255;
    static final int OCI_TRANS_READONLY = 256;
    static final int OCI_TRANS_READWRITE = 512;
    static final int OCI_TRANS_SERIALIZABLE = 1024;
    static final int OCI_TRANS_ISOLMASK = 65280;
    static final int OCI_TRANS_LOOSE = 65536;
    static final int OCI_TRANS_TIGHT = 131072;
    static final int OCI_TRANS_TYPEMASK = 983040;
    static final int OCI_TRANS_NOMIGRATE = 1048576;
    static final int OCI_TRANS_SEPARABLE = 2097152;
    boolean sendTransactionContext;
    private int operation;
    private int formatId;
    private int gtridLength;
    private int bqualLength;
    private int timeout;
    private int flag;
    private int[] xidapp;
    private byte[] transactionContext;
    private byte[] xid;
    private int applicationValue;
    private byte[] ctx;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIOtxse(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.sendTransactionContext = false;
        this.xidapp = null;
        this.xid = null;
        this.applicationValue = -1;
        this.ctx = null;
        this.setFunCode((short)103);
    }
    
    void doOTXSE(final int operation, final byte[] transactionContext, final byte[] xid, final int formatId, final int gtridLength, final int bqualLength, final int timeout, final int flag, final int[] xidapp) throws IOException, SQLException {
        if (operation != 1 && operation != 2) {
            throw new SQLException("Invalid operation.");
        }
        this.operation = operation;
        this.formatId = formatId;
        this.gtridLength = gtridLength;
        this.bqualLength = bqualLength;
        this.timeout = timeout;
        this.flag = flag;
        this.xidapp = xidapp;
        this.transactionContext = transactionContext;
        this.xid = xid;
        this.applicationValue = -1;
        this.ctx = null;
        if (this.operation == 2 && this.transactionContext == null) {
            throw new SQLException("Transaction context cannot be null when detach is called.");
        }
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalSWORD(this.operation);
        if (this.operation == 2) {
            this.sendTransactionContext = true;
            this.meg.marshalPTR();
        }
        else {
            this.sendTransactionContext = false;
            this.meg.marshalNULLPTR();
        }
        if (this.transactionContext == null) {
            this.meg.marshalUB4(0L);
        }
        else {
            this.meg.marshalUB4(this.transactionContext.length);
        }
        this.meg.marshalUB4(this.formatId);
        this.meg.marshalUB4(this.gtridLength);
        this.meg.marshalUB4(this.bqualLength);
        if (this.xid != null) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        if (this.xid != null) {
            this.meg.marshalUB4(this.xid.length);
        }
        else {
            this.meg.marshalUB4(0L);
        }
        this.meg.marshalUB4(this.flag);
        this.meg.marshalUWORD(this.timeout);
        if (this.xidapp != null) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        boolean b = false;
        boolean b2 = false;
        if (this.connection.getTTCVersion() >= 5) {
            if (this.connection.internalName != null) {
                b = true;
                this.meg.marshalPTR();
                this.meg.marshalUB4(this.connection.internalName.length);
            }
            else {
                this.meg.marshalNULLPTR();
                this.meg.marshalUB4(0L);
            }
            if (this.connection.externalName != null) {
                b2 = true;
                this.meg.marshalPTR();
                this.meg.marshalUB4(this.connection.externalName.length);
            }
            else {
                this.meg.marshalNULLPTR();
                this.meg.marshalUB4(0L);
            }
        }
        if (this.sendTransactionContext) {
            this.meg.marshalB1Array(this.transactionContext);
        }
        if (this.xid != null) {
            this.meg.marshalB1Array(this.xid);
        }
        if (this.xidapp != null) {
            this.meg.marshalUB4(this.xidapp[0]);
        }
        if (this.connection.getTTCVersion() >= 5) {
            if (b) {
                this.meg.marshalCHR(this.connection.internalName);
            }
            if (b2) {
                this.meg.marshalCHR(this.connection.externalName);
            }
        }
    }
    
    byte[] getContext() {
        return this.ctx;
    }
    
    int getApplicationValue() {
        return this.applicationValue;
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        this.applicationValue = (int)this.meg.unmarshalUB4();
        this.ctx = this.meg.unmarshalNBytes(this.meg.unmarshalUB2());
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
