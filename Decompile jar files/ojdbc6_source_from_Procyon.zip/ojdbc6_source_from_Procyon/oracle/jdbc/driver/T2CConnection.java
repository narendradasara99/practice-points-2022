// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.EnumSet;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import java.sql.DatabaseMetaData;
import java.util.Enumeration;
import java.sql.Savepoint;
import java.sql.Statement;
import oracle.jdbc.OracleSavepoint;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import oracle.sql.CustomDatum;
import java.sql.ResultSet;
import java.util.Map;
import oracle.sql.ArrayDescriptor;
import java.sql.ResultSetMetaData;
import oracle.sql.StructDescriptor;
import oracle.sql.ARRAY;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import java.math.BigDecimal;
import java.math.BigInteger;
import oracle.sql.NUMBER;
import java.sql.Array;
import java.sql.Struct;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import oracle.sql.TIMESTAMPLTZ;
import java.util.Calendar;
import oracle.sql.DATE;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.NClob;
import java.sql.SQLXML;
import javax.transaction.xa.XAResource;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import java.util.concurrent.Executor;
import oracle.jdbc.internal.XSEventListener;
import oracle.sql.TypeDescriptor;
import oracle.sql.TIMEZONETAB;
import oracle.jdbc.pool.OraclePooledConnection;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.io.Writer;
import oracle.sql.NCLOB;
import java.nio.ByteOrder;
import oracle.sql.CLOB;
import java.io.OutputStream;
import oracle.sql.Datum;
import java.sql.Connection;
import oracle.sql.BLOB;
import java.io.Reader;
import java.io.InputStream;
import oracle.sql.LobPlsqlUtil;
import oracle.sql.BFILE;
import oracle.jdbc.pool.OracleOCIConnectionPool;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.SQLName;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.oracore.OracleTypeADT;
import java.sql.SQLWarning;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import oracle.sql.ZONEIDMAP;
import java.util.TimeZone;
import oracle.sql.converter.CharacterSetMetaData;
import java.util.Locale;
import java.sql.SQLException;
import java.nio.ByteBuffer;
import java.util.Properties;
import oracle.jdbc.OracleOCIFailover;
import oracle.sql.ClobDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.BfileDBAccess;

public class T2CConnection extends PhysicalConnection implements BfileDBAccess, BlobDBAccess, ClobDBAccess
{
    static final long JDBC_OCI_LIBRARY_VERSION;
    short[] queryMetaData1;
    byte[] queryMetaData2;
    int queryMetaData1Offset;
    int queryMetaData2Offset;
    private String password;
    int fatalErrorNumber;
    String fatalErrorMessage;
    static final int QMD_dbtype = 0;
    static final int QMD_dbsize = 1;
    static final int QMD_nullok = 2;
    static final int QMD_precision = 3;
    static final int QMD_scale = 4;
    static final int QMD_formOfUse = 5;
    static final int QMD_columnNameLength = 6;
    static final int QMD_tdo0 = 7;
    static final int QMD_tdo1 = 8;
    static final int QMD_tdo2 = 9;
    static final int QMD_tdo3 = 10;
    static final int QMD_charLength = 11;
    static final int QMD_typeNameLength = 12;
    static final int T2C_LOCATOR_MAX_LEN = 16;
    static final int T2C_LINEARIZED_LOCATOR_MAX_LEN = 4000;
    static final int T2C_LINEARIZED_BFILE_LOCATOR_MAX_LEN = 530;
    static final int METADATA1_INDICES_PER_COLUMN = 13;
    protected static final int SIZEOF_QUERYMETADATA2 = 8;
    static final String defaultDriverNameAttribute = "jdbcoci";
    int queryMetaData1Size;
    int queryMetaData2Size;
    long m_nativeState;
    short m_clientCharacterSet;
    byte byteAlign;
    private static final int EOJ_SUCCESS = 0;
    private static final int EOJ_ERROR = -1;
    private static final int EOJ_WARNING = 1;
    private static final int EOJ_GET_STORAGE_ERROR = -4;
    private static final int EOJ_ORA3113_SERVER_NORMAL = -6;
    private static final String OCILIBRARY = "ocijdbc11";
    private int logon_mode;
    static final int LOGON_MODE_DEFAULT = 0;
    static final int LOGON_MODE_SYSDBA = 2;
    static final int LOGON_MODE_SYSOPER = 4;
    static final int LOGON_MODE_SYSASM = 32768;
    static final int LOGON_MODE_CONNECTION_POOL = 5;
    static final int LOGON_MODE_CONNPOOL_CONNECTION = 6;
    static final int LOGON_MODE_CONNPOOL_PROXY_CONNECTION = 7;
    static final int LOGON_MODE_CONNPOOL_ALIASED_CONNECTION = 8;
    static final int T2C_PROXYTYPE_NONE = 0;
    static final int T2C_PROXYTYPE_USER_NAME = 1;
    static final int T2C_PROXYTYPE_DISTINGUISHED_NAME = 2;
    static final int T2C_PROXYTYPE_CERTIFICATE = 3;
    static final int T2C_CONNECTION_FLAG_DEFAULT_LOB_PREFETCH = 0;
    static final int T2C_CONNECTION_FLAG_PRELIM_AUTH = 1;
    private static boolean isLibraryLoaded;
    OracleOCIFailover appCallback;
    Object appCallbackObject;
    private Properties nativeInfo;
    ByteBuffer nioBufferForLob;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected T2CConnection(final String s, final Properties properties, final OracleDriverExtension oracleDriverExtension) throws SQLException {
        super(s, properties, oracleDriverExtension);
        this.queryMetaData1 = null;
        this.queryMetaData2 = null;
        this.queryMetaData1Offset = 0;
        this.queryMetaData2Offset = 0;
        this.fatalErrorNumber = 0;
        this.fatalErrorMessage = null;
        this.queryMetaData1Size = 100;
        this.queryMetaData2Size = 800;
        this.logon_mode = 0;
        this.appCallback = null;
        this.appCallbackObject = null;
        this.initialize();
    }
    
    @Override
    final void initializePassword(final String password) throws SQLException {
        this.password = password;
    }
    
    protected void initialize() {
        this.allocQueryMetaDataBuffers();
    }
    
    private void allocQueryMetaDataBuffers() {
        this.queryMetaData1Offset = 0;
        this.queryMetaData1 = new short[this.queryMetaData1Size * 13];
        this.queryMetaData2Offset = 0;
        this.queryMetaData2 = new byte[this.queryMetaData2Size];
        this.namedTypeAccessorByteLen = 0;
        this.refTypeAccessorByteLen = 0;
    }
    
    void reallocateQueryMetaData(final int a, final int a2) {
        this.queryMetaData1 = null;
        this.queryMetaData2 = null;
        this.queryMetaData1Size = Math.max(a, this.queryMetaData1Size);
        this.queryMetaData2Size = Math.max(a2, this.queryMetaData2Size);
        this.allocQueryMetaDataBuffers();
    }
    
    protected void logon() throws SQLException {
        if (this.database == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 64);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (!T2CConnection.isLibraryLoaded) {
            loadNativeLibrary(this.ocidll);
        }
        if (this.ociConnectionPoolIsPooling) {
            this.processOCIConnectionPooling();
        }
        else {
            final long ociSvcCtxHandle = this.ociSvcCtxHandle;
            final long ociEnvHandle = this.ociEnvHandle;
            final long ociErrHandle = this.ociErrHandle;
            if (ociSvcCtxHandle != 0L && ociEnvHandle != 0L) {
                if (this.ociDriverCharset != null) {
                    this.m_clientCharacterSet = new Integer(this.ociDriverCharset).shortValue();
                    this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
                    final short[] array = new short[5];
                    this.sqlWarning = this.checkError(this.t2cUseConnection(this.m_nativeState, ociEnvHandle, ociSvcCtxHandle, ociErrHandle, array, new long[] { this.defaultLobPrefetchSize }), this.sqlWarning);
                    this.conversion = new DBConversion(array[0], this.m_clientCharacterSet, array[1]);
                    this.byteAlign = (byte)(array[2] & 0xFF);
                    this.timeZoneVersionNumber = (array[3] << 16) + (array[4] & 0xFFFF);
                    return;
                }
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            else {
                if (this.internalLogon == null) {
                    this.logon_mode = 0;
                }
                else if (this.internalLogon.equalsIgnoreCase("SYSDBA")) {
                    this.logon_mode = 2;
                }
                else if (this.internalLogon.equalsIgnoreCase("SYSOPER")) {
                    this.logon_mode = 4;
                }
                else if (this.internalLogon.equalsIgnoreCase("SYSASM")) {
                    this.logon_mode = 32768;
                }
                final String setNewPassword = this.setNewPassword;
                byte[] stringToDriverCharBytes = new byte[0];
                byte[] stringToDriverCharBytes2 = new byte[0];
                final byte[] array2 = new byte[0];
                if (this.nlsLangBackdoor) {
                    this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
                }
                else {
                    this.m_clientCharacterSet = getClientCharSetId();
                }
                if (setNewPassword != null) {
                    stringToDriverCharBytes = DBConversion.stringToDriverCharBytes(setNewPassword, this.m_clientCharacterSet);
                }
                if (this.editionName != null) {
                    stringToDriverCharBytes2 = DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
                }
                byte[] array3;
                if (this.driverNameAttribute == null) {
                    array3 = DBConversion.stringToDriverCharBytes("jdbcoci", this.m_clientCharacterSet);
                }
                else {
                    array3 = DBConversion.stringToDriverCharBytes(this.driverNameAttribute, this.m_clientCharacterSet);
                }
                final byte[] array4 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
                final byte[] array5 = (this.proxyClientName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.proxyClientName, this.m_clientCharacterSet);
                final byte[] array6 = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
                final byte[] stringToDriverCharBytes3 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
                final short[] array7 = new short[5];
                final String nlsLanguage;
                final byte[] array8 = (byte[])(((nlsLanguage = CharacterSetMetaData.getNLSLanguage(Locale.getDefault())) != null) ? nlsLanguage.getBytes() : null);
                final String nlsTerritory;
                final byte[] array9 = (byte[])(((nlsTerritory = CharacterSetMetaData.getNLSTerritory(Locale.getDefault())) != null) ? nlsTerritory.getBytes() : null);
                if (array8 == null || array9 == null) {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 176);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                final TimeZone default1 = TimeZone.getDefault();
                String sessionTimeZone = default1.getID();
                if (!ZONEIDMAP.isValidRegion(sessionTimeZone) || !this.timezoneAsRegion) {
                    final int offset = default1.getOffset(System.currentTimeMillis());
                    final int n = offset / 3600000;
                    final int n2 = offset / 60000 % 60;
                    sessionTimeZone = ((n < 0) ? ("" + n) : ("+" + n)) + ((n2 < 10) ? (":0" + n2) : (":" + n2));
                }
                doSetSessionTimeZone(sessionTimeZone);
                this.sessionTimeZone = sessionTimeZone;
                this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
                final long[] array10 = { this.defaultLobPrefetchSize, (long)(this.prelimAuth ? 1 : 0) };
                if (this.m_nativeState == 0L) {
                    this.sqlWarning = this.checkError(this.t2cCreateState(array4, array4.length, array5, array5.length, array6, array6.length, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, array3, array3.length, stringToDriverCharBytes3, stringToDriverCharBytes3.length, this.m_clientCharacterSet, this.logon_mode, array7, array8, array9, array10), this.sqlWarning);
                }
                else {
                    this.sqlWarning = this.checkError(this.t2cLogon(this.m_nativeState, array4, array4.length, array5, array5.length, array6, array6.length, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, array3, array3.length, stringToDriverCharBytes3, stringToDriverCharBytes3.length, this.logon_mode, array7, array8, array9, array10), this.sqlWarning);
                }
                this.conversion = new DBConversion(array7[0], this.m_clientCharacterSet, array7[1]);
                this.byteAlign = (byte)(array7[2] & 0xFF);
                this.timeZoneVersionNumber = (array7[3] << 16) + (array7[4] & 0xFFFF);
            }
        }
    }
    
    protected void logoff() throws SQLException {
        try {
            if (this.lifecycle == 2) {
                this.checkError(this.t2cLogoff(this.m_nativeState));
            }
        }
        catch (NullPointerException ex) {}
        this.m_nativeState = 0L;
    }
    
    public void open(final OracleStatement oracleStatement) throws SQLException {
        final byte[] bytes = oracleStatement.sqlObject.getSql(oracleStatement.processEscapes, oracleStatement.convertNcharLiterals).getBytes();
        this.checkError(this.t2cCreateStatement(this.m_nativeState, 0L, bytes, bytes.length, oracleStatement, false, oracleStatement.rowPrefetch));
    }
    
    @Override
    void cancelOperationOnServer() throws SQLException {
        this.checkError(this.t2cCancel(this.m_nativeState));
    }
    
    native int t2cAbort(final long p0);
    
    @Override
    void doAbort() throws SQLException {
        this.checkError(this.t2cAbort(this.m_nativeState));
    }
    
    protected void doSetAutoCommit(final boolean b) throws SQLException {
        this.checkError(this.t2cSetAutoCommit(this.m_nativeState, b));
    }
    
    protected void doCommit(final int n) throws SQLException {
        this.checkError(this.t2cCommit(this.m_nativeState, n));
    }
    
    protected void doRollback() throws SQLException {
        this.checkError(this.t2cRollback(this.m_nativeState));
    }
    
    @Override
    synchronized int doPingDatabase() throws SQLException {
        if (this.t2cPingDatabase(this.m_nativeState) == 0) {
            return 0;
        }
        return -1;
    }
    
    protected String doGetDatabaseProductVersion() throws SQLException {
        final byte[] t2cGetProductionVersion = this.t2cGetProductionVersion(this.m_nativeState);
        return this.conversion.CharBytesToString(t2cGetProductionVersion, t2cGetProductionVersion.length);
    }
    
    protected short doGetVersionNumber() throws SQLException {
        short n = 0;
        try {
            final StringTokenizer stringTokenizer = new StringTokenizer(this.doGetDatabaseProductVersion().trim(), " .", false);
            int n2 = 0;
            while (stringTokenizer.hasMoreTokens()) {
                final String nextToken = stringTokenizer.nextToken();
                try {
                    n = (short)(n * 10 + Integer.decode(nextToken).shortValue());
                    if (++n2 == 4) {
                        break;
                    }
                    continue;
                }
                catch (NumberFormatException ex) {}
            }
        }
        catch (NoSuchElementException ex2) {}
        if (n == -1) {
            n = 0;
        }
        return n;
    }
    
    @Override
    public ClobDBAccess createClobDBAccess() {
        return this;
    }
    
    @Override
    public BlobDBAccess createBlobDBAccess() {
        return this;
    }
    
    @Override
    public BfileDBAccess createBfileDBAccess() {
        return this;
    }
    
    protected SQLWarning checkError(final int n) throws SQLException {
        return this.checkError(n, null);
    }
    
    protected SQLWarning checkError(final int n, SQLWarning addSqlWarning) throws SQLException {
        switch (n) {
            case -1:
            case 1: {
                final T2CError t2CError = new T2CError();
                if (this.lifecycle == 1 || this.lifecycle == 16) {
                    final int t2cDescribeError = this.t2cDescribeError(this.m_nativeState, t2CError, t2CError.m_errorMessage);
                    String charBytesToString = null;
                    if (t2cDescribeError != -1) {
                        int n2;
                        for (n2 = 0; n2 < t2CError.m_errorMessage.length && t2CError.m_errorMessage[n2] != 0; ++n2) {}
                        if (this.conversion == null) {
                            throw new Error("conversion == null");
                        }
                        if (t2CError == null) {
                            throw new Error("l_error == null");
                        }
                        charBytesToString = this.conversion.CharBytesToString(t2CError.m_errorMessage, n2, true);
                    }
                    switch (t2CError.m_errorNumber) {
                        case 28:
                        case 600:
                        case 1012:
                        case 1041: {
                            this.internalClose();
                            break;
                        }
                        case 3113:
                        case 3114: {
                            this.close();
                            break;
                        }
                        case -6: {
                            t2CError.m_errorNumber = 3113;
                            break;
                        }
                    }
                    if (t2cDescribeError == -1) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Fetch error message failed!");
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    if (n == -1) {
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), charBytesToString, t2CError.m_errorNumber);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                    addSqlWarning = DatabaseError.addSqlWarning(addSqlWarning, charBytesToString, t2CError.m_errorNumber);
                    break;
                }
                else {
                    if (this.fatalErrorNumber != 0) {
                        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 269);
                        sqlException3.fillInStackTrace();
                        throw sqlException3;
                    }
                    final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
                    sqlException4.fillInStackTrace();
                    throw sqlException4;
                }
                break;
            }
            case -4: {
                final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 254);
                sqlException5.fillInStackTrace();
                throw sqlException5;
            }
        }
        return addSqlWarning;
    }
    
    @Override
    OracleStatement RefCursorBytesToStatement(final byte[] array, final OracleStatement oracleStatement) throws SQLException {
        final T2CStatement t2CStatement = new T2CStatement(this, 1, this.defaultRowPrefetch, -1, -1);
        t2CStatement.needToParse = false;
        t2CStatement.serverCursor = true;
        t2CStatement.prepareForNewResults(t2CStatement.isOpen = true, t2CStatement.processEscapes = false);
        t2CStatement.sqlObject.initialize("select unknown as ref cursor from whatever");
        t2CStatement.sqlKind = 1;
        this.checkError(this.t2cCreateStatement(this.m_nativeState, oracleStatement.c_state, array, array.length, t2CStatement, true, this.defaultRowPrefetch));
        oracleStatement.addChild(t2CStatement);
        return t2CStatement;
    }
    
    @Override
    public void getForm(final OracleTypeADT oracleTypeADT, final OracleTypeCLOB oracleTypeCLOB, final int n) throws SQLException {
        if (oracleTypeCLOB != null) {
            final String[] array = { null };
            final String[] array2 = { null };
            SQLName.parse(oracleTypeADT.getFullName(), array, array2, true);
            final byte[] stringToCharBytes = this.conversion.StringToCharBytes("\"" + array[0] + "\".\"" + array2[0] + "\"");
            final int t2cGetFormOfUse = this.t2cGetFormOfUse(this.m_nativeState, oracleTypeCLOB, stringToCharBytes, stringToCharBytes.length, n);
            if (t2cGetFormOfUse < 0) {
                this.checkError(t2cGetFormOfUse);
            }
            oracleTypeCLOB.setForm(t2cGetFormOfUse);
        }
    }
    
    @Override
    public long getTdoCState(final String str, final String str2) throws SQLException {
        final byte[] stringToCharBytes = this.conversion.StringToCharBytes("\"" + str + "\".\"" + str2 + "\"");
        final int[] array = { 0 };
        final long t2cGetTDO = this.t2cGetTDO(this.m_nativeState, stringToCharBytes, stringToCharBytes.length, array);
        if (t2cGetTDO == 0L) {
            this.checkError(array[0]);
        }
        return t2cGetTDO;
    }
    
    @Override
    @Deprecated
    public Properties getDBAccessProperties() throws SQLException {
        return this.getOCIHandles();
    }
    
    @Override
    public synchronized Properties getOCIHandles() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.nativeInfo == null) {
            final long[] array = new long[3];
            this.checkError(this.t2cGetHandles(this.m_nativeState, array));
            (this.nativeInfo = new Properties()).put("OCIEnvHandle", String.valueOf(array[0]));
            this.nativeInfo.put("OCISvcCtxHandle", String.valueOf(array[1]));
            this.nativeInfo.put("OCIErrHandle", String.valueOf(array[2]));
            this.nativeInfo.put("ClientCharSet", String.valueOf(this.m_clientCharacterSet));
        }
        return this.nativeInfo;
    }
    
    @Override
    public Properties getServerSessionInfo() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.sessionProperties == null) {
            this.sessionProperties = new Properties();
        }
        if (this.getVersionNumber() < 10200) {
            this.queryFCFProperties(this.sessionProperties);
        }
        else {
            this.checkError(t2cGetServerSessionInfo(this.m_nativeState, this.sessionProperties));
        }
        return this.sessionProperties;
    }
    
    @Override
    public byte getInstanceProperty(final InstanceProperty instanceProperty) throws SQLException {
        byte b = 0;
        if (instanceProperty == InstanceProperty.ASM_VOLUME_SUPPORTED) {
            b = this.t2cGetAsmVolProperty(this.m_nativeState);
        }
        else if (instanceProperty == InstanceProperty.INSTANCE_TYPE) {
            b = this.t2cGetInstanceType(this.m_nativeState);
        }
        return b;
    }
    
    public Properties getConnectionPoolInfo() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final Properties properties = new Properties();
        this.checkError(this.t2cGetConnPoolInfo(this.m_nativeState, properties));
        return properties;
    }
    
    public void setConnectionPoolInfo(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) throws SQLException {
        this.checkError(this.t2cSetConnPoolInfo(this.m_nativeState, n, n2, n3, n4, n5, n6));
    }
    
    public void ociPasswordChange(final String s, final String s2, final String s3) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final byte[] array = (s == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(s, this.m_clientCharacterSet);
        final byte[] array2 = (s2 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(s2, this.m_clientCharacterSet);
        final byte[] array3 = (s3 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(s3, this.m_clientCharacterSet);
        this.sqlWarning = this.checkError(this.t2cPasswordChange(this.m_nativeState, array, array.length, array2, array2.length, array3, array3.length), this.sqlWarning);
    }
    
    private void processOCIConnectionPooling() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        T2CConnection t2CConnection = null;
        if (this.ociConnectionPoolLogonMode == "connection_pool") {
            if (this.nlsLangBackdoor) {
                this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
            }
            else {
                this.m_clientCharacterSet = getClientCharSetId();
            }
        }
        else {
            t2CConnection = (T2CConnection)this.ociConnectionPoolObject;
            this.m_clientCharacterSet = t2CConnection.m_clientCharacterSet;
        }
        final byte[] array = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
        final byte[] array2 = (this.editionName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
        final byte[] stringToDriverCharBytes = DBConversion.stringToDriverCharBytes((this.driverNameAttribute == null) ? "jdbcoci" : this.driverNameAttribute, this.m_clientCharacterSet);
        final byte[] stringToDriverCharBytes2 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
        final byte[] bytes = CharacterSetMetaData.getNLSLanguage(Locale.getDefault()).getBytes();
        final byte[] bytes2 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault()).getBytes();
        if (bytes == null || bytes2 == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 176);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final short[] array3 = new short[5];
        final long[] array4 = { this.defaultLobPrefetchSize };
        if (this.ociConnectionPoolLogonMode == "connection_pool") {
            final byte[] array5 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
            this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
            this.logon_mode = 5;
            if (this.lifecycle != 1) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 0, "Internal Error: ");
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            final int[] array6 = new int[6];
            OracleOCIConnectionPool.readPoolConfig(this.ociConnectionPoolMinLimit, this.ociConnectionPoolMaxLimit, this.ociConnectionPoolIncrement, this.ociConnectionPoolTimeout, this.ociConnectionPoolNoWait, this.ociConnectionPoolTransactionDistributed, array6);
            this.sqlWarning = this.checkError(this.t2cCreateConnPool(array5, array5.length, array, array.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, this.m_clientCharacterSet, this.logon_mode, array6[0], array6[1], array6[2], array6[3], array6[4], array6[5]), this.sqlWarning);
            this.versionNumber = 10000;
        }
        else if (this.ociConnectionPoolLogonMode == "connpool_connection") {
            this.logon_mode = 6;
            final byte[] array7 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
            this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
            this.sqlWarning = this.checkError(this.t2cConnPoolLogon(t2CConnection.m_nativeState, array7, array7.length, array, array.length, array2, array2.length, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, this.logon_mode, 0, 0, null, null, 0, null, 0, null, 0, null, 0, null, 0, array3, bytes, bytes2, array4), this.sqlWarning);
        }
        else if (this.ociConnectionPoolLogonMode == "connpool_alias_connection") {
            this.logon_mode = 8;
            final byte[] array8 = (byte[])this.ociConnectionPoolConnID;
            final byte[] array9 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
            this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
            this.sqlWarning = this.checkError(this.t2cConnPoolLogon(t2CConnection.m_nativeState, array9, array9.length, array, array.length, array2, array2.length, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, this.logon_mode, 0, 0, null, null, 0, null, 0, null, 0, null, 0, array8, (array8 == null) ? 0 : array8.length, array3, bytes, bytes2, array4), this.sqlWarning);
        }
        else {
            if (this.ociConnectionPoolLogonMode != "connpool_proxy_connection") {
                final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "connection-pool-logon");
                sqlException4.fillInStackTrace();
                throw sqlException4;
            }
            this.logon_mode = 7;
            final String ociConnectionPoolProxyType = this.ociConnectionPoolProxyType;
            final int intValue = this.ociConnectionPoolProxyNumRoles;
            String[] array10 = null;
            if (intValue > 0) {
                array10 = (String[])this.ociConnectionPoolProxyRoles;
            }
            byte[] bytes3 = null;
            byte[] bytes4 = null;
            byte[] bytes5 = null;
            byte[] array11 = null;
            int n;
            if (ociConnectionPoolProxyType == "proxytype_user_name") {
                n = 1;
                final String ociConnectionPoolProxyUserName = this.ociConnectionPoolProxyUserName;
                if (ociConnectionPoolProxyUserName != null) {
                    bytes3 = ociConnectionPoolProxyUserName.getBytes();
                }
                final String ociConnectionPoolProxyPassword = this.ociConnectionPoolProxyPassword;
                if (ociConnectionPoolProxyPassword != null) {
                    bytes4 = ociConnectionPoolProxyPassword.getBytes();
                }
            }
            else if (ociConnectionPoolProxyType == "proxytype_distinguished_name") {
                n = 2;
                final String ociConnectionPoolProxyDistinguishedName = this.ociConnectionPoolProxyDistinguishedName;
                if (ociConnectionPoolProxyDistinguishedName != null) {
                    bytes5 = ociConnectionPoolProxyDistinguishedName.getBytes();
                }
            }
            else {
                if (ociConnectionPoolProxyType != "proxytype_certificate") {
                    final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 107);
                    sqlException5.fillInStackTrace();
                    throw sqlException5;
                }
                n = 3;
                array11 = (byte[])this.ociConnectionPoolProxyCertificate;
            }
            final byte[] array12 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
            this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
            this.sqlWarning = this.checkError(this.t2cConnPoolLogon(t2CConnection.m_nativeState, array12, array12.length, array, array.length, array2, array2.length, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes2, stringToDriverCharBytes2.length, this.logon_mode, n, intValue, array10, bytes3, (bytes3 == null) ? 0 : bytes3.length, bytes4, (bytes4 == null) ? 0 : bytes4.length, bytes5, (bytes5 == null) ? 0 : bytes5.length, array11, (array11 == null) ? 0 : array11.length, null, 0, array3, bytes, bytes2, array4), this.sqlWarning);
        }
        this.conversion = new DBConversion(array3[0], this.m_clientCharacterSet, array3[1]);
        this.byteAlign = (byte)(array3[2] & 0xFF);
        this.timeZoneVersionNumber = (array3[3] << 16) + (array3[4] & 0xFFFF);
    }
    
    @Override
    public boolean isDescriptorSharable(final oracle.jdbc.internal.OracleConnection oracleConnection) throws SQLException {
        return this == oracleConnection.getPhysicalConnection();
    }
    
    native int t2cBlobRead(final long p0, final byte[] p1, final int p2, final long p3, final int p4, final byte[] p5, final int p6, final boolean p7, final ByteBuffer p8);
    
    native int t2cClobRead(final long p0, final byte[] p1, final int p2, final long p3, final int p4, final char[] p5, final int p6, final boolean p7, final boolean p8, final ByteBuffer p9);
    
    native int t2cBlobWrite(final long p0, final byte[] p1, final int p2, final long p3, final int p4, final byte[] p5, final int p6, final byte[][] p7);
    
    native int t2cClobWrite(final long p0, final byte[] p1, final int p2, final long p3, final int p4, final char[] p5, final int p6, final byte[][] p7, final boolean p8);
    
    native long t2cLobGetLength(final long p0, final byte[] p1, final int p2);
    
    native int t2cBfileOpen(final long p0, final byte[] p1, final int p2, final byte[][] p3);
    
    native int t2cBfileIsOpen(final long p0, final byte[] p1, final int p2, final boolean[] p3);
    
    native int t2cBfileExists(final long p0, final byte[] p1, final int p2, final boolean[] p3);
    
    native String t2cBfileGetName(final long p0, final byte[] p1, final int p2);
    
    native String t2cBfileGetDirAlias(final long p0, final byte[] p1, final int p2);
    
    native int t2cBfileClose(final long p0, final byte[] p1, final int p2, final byte[][] p3);
    
    native int t2cLobGetChunkSize(final long p0, final byte[] p1, final int p2);
    
    native int t2cLobTrim(final long p0, final int p1, final long p2, final byte[] p3, final int p4, final byte[][] p5);
    
    native int t2cLobCreateTemporary(final long p0, final int p1, final boolean p2, final int p3, final short p4, final byte[][] p5);
    
    native int t2cLobFreeTemporary(final long p0, final int p1, final byte[] p2, final int p3, final byte[][] p4);
    
    native int t2cLobIsTemporary(final long p0, final int p1, final byte[] p2, final int p3, final boolean[] p4);
    
    native int t2cLobOpen(final long p0, final int p1, final byte[] p2, final int p3, final int p4, final byte[][] p5);
    
    native int t2cLobIsOpen(final long p0, final int p1, final byte[] p2, final int p3, final boolean[] p4);
    
    native int t2cLobClose(final long p0, final int p1, final byte[] p2, final int p3, final byte[][] p4);
    
    private long lobLength(final byte[] array) throws SQLException {
        final long t2cLobGetLength = this.t2cLobGetLength(this.m_nativeState, array, array.length);
        this.checkError((int)t2cLobGetLength);
        return t2cLobGetLength;
    }
    
    private int blobRead(final byte[] array, final long n, final int n2, final byte[] array2, final boolean b, final ByteBuffer byteBuffer) throws SQLException {
        final int t2cBlobRead = this.t2cBlobRead(this.m_nativeState, array, array.length, n, n2, array2, array2.length, b, byteBuffer);
        this.checkError(t2cBlobRead);
        return t2cBlobRead;
    }
    
    private int blobWrite(final byte[] array, final long n, final byte[] array2, final byte[][] array3, final int n2, final int n3) throws SQLException {
        final int t2cBlobWrite = this.t2cBlobWrite(this.m_nativeState, array, array.length, n, n3, array2, n2, array3);
        this.checkError(t2cBlobWrite);
        return t2cBlobWrite;
    }
    
    private int clobWrite(final byte[] array, final long n, final char[] array2, final byte[][] array3, final boolean b, final int n2, final int n3) throws SQLException {
        final int t2cClobWrite = this.t2cClobWrite(this.m_nativeState, array, array.length, n, n3, array2, n2, array3, b);
        this.checkError(t2cClobWrite);
        return t2cClobWrite;
    }
    
    private int lobGetChunkSize(final byte[] array) throws SQLException {
        final int t2cLobGetChunkSize = this.t2cLobGetChunkSize(this.m_nativeState, array, array.length);
        this.checkError(t2cLobGetChunkSize);
        return t2cLobGetChunkSize;
    }
    
    @Override
    public synchronized long length(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        return this.lobLength(locator);
    }
    
    @Override
    public synchronized long position(final BFILE bfile, final byte[] array, final long n) throws SQLException {
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long hasPattern = LobPlsqlUtil.hasPattern(bfile, array, n);
        return (hasPattern == 0L) ? -1L : hasPattern;
    }
    
    @Override
    public synchronized long position(final BFILE bfile, final BFILE bfile2, final long n) throws SQLException {
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long subLob = LobPlsqlUtil.isSubLob(bfile, bfile2, n);
        return (subLob == 0L) ? -1L : subLob;
    }
    
    @Override
    public synchronized int getBytes(final BFILE bfile, final long n, int length, final byte[] dst) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        if (length <= 0 || dst == null) {
            return 0;
        }
        if (length > dst.length) {
            length = dst.length;
        }
        if (this.useNio) {
            final int length2 = dst.length;
            if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < length2) {
                this.nioBufferForLob = ByteBuffer.allocateDirect(length2);
            }
            else {
                this.nioBufferForLob.rewind();
            }
        }
        final int blobRead = this.blobRead(locator, n, length, dst, this.useNio, this.nioBufferForLob);
        if (this.useNio) {
            this.nioBufferForLob.get(dst);
        }
        return blobRead;
    }
    
    @Override
    public synchronized String getName(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        final String t2cBfileGetName = this.t2cBfileGetName(this.m_nativeState, locator, locator.length);
        this.checkError(t2cBfileGetName.length());
        return t2cBfileGetName;
    }
    
    @Override
    public synchronized String getDirAlias(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        final String t2cBfileGetDirAlias = this.t2cBfileGetDirAlias(this.m_nativeState, locator, locator.length);
        this.checkError(t2cBfileGetDirAlias.length());
        return t2cBfileGetDirAlias;
    }
    
    @Override
    public synchronized void openFile(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cBfileOpen(this.m_nativeState, locator, locator.length, array));
        bfile.setLocator(array[0]);
    }
    
    @Override
    public synchronized boolean isFileOpen(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cBfileIsOpen(this.m_nativeState, locator, locator.length, array));
        return array[0];
    }
    
    @Override
    public synchronized boolean fileExists(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cBfileExists(this.m_nativeState, locator, locator.length, array));
        return array[0];
    }
    
    @Override
    public synchronized void closeFile(final BFILE bfile) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (locator = bfile.getLocator()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cBfileClose(this.m_nativeState, locator, locator.length, array));
        bfile.setLocator(array[0]);
    }
    
    @Override
    public synchronized void open(final BFILE bfile, final int n) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (shareBytes = bfile.shareBytes()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cLobOpen(this.m_nativeState, 114, shareBytes, shareBytes.length, n, array));
        bfile.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized void close(final BFILE bfile) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (shareBytes = bfile.shareBytes()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cLobClose(this.m_nativeState, 114, shareBytes, shareBytes.length, array));
        bfile.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized boolean isOpen(final BFILE bfile) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(bfile != null && (shareBytes = bfile.shareBytes()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cLobIsOpen(this.m_nativeState, 114, shareBytes, shareBytes.length, array));
        return array[0];
    }
    
    @Override
    public InputStream newInputStream(final BFILE bfile, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleBlobInputStream(bfile, n);
        }
        return new OracleBlobInputStream(bfile, n, n2);
    }
    
    @Override
    public InputStream newConversionInputStream(final BFILE bfile, final int n) throws SQLException {
        this.checkTrue(bfile != null && bfile.shareBytes() != null, 54);
        return new OracleConversionInputStream(this.conversion, bfile.getBinaryStream(), n);
    }
    
    @Override
    public Reader newConversionReader(final BFILE bfile, final int n) throws SQLException {
        this.checkTrue(bfile != null && bfile.shareBytes() != null, 54);
        return new OracleConversionReader(this.conversion, bfile.getBinaryStream(), n);
    }
    
    @Override
    public synchronized long length(final BLOB blob) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (locator = blob.getLocator()) != null, 54);
        return this.lobLength(locator);
    }
    
    @Override
    public synchronized long position(final BLOB blob, final byte[] array, final long n) throws SQLException {
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && blob.shareBytes() != null, 54);
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long hasPattern = LobPlsqlUtil.hasPattern(blob, array, n);
        return (hasPattern == 0L) ? -1L : hasPattern;
    }
    
    @Override
    public synchronized long position(final BLOB blob, final BLOB blob2, final long n) throws SQLException {
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && blob.shareBytes() != null, 54);
        this.checkTrue(blob2 != null && blob2.shareBytes() != null, 54);
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long subLob = LobPlsqlUtil.isSubLob(blob, blob2, n);
        return (subLob == 0L) ? -1L : subLob;
    }
    
    @Override
    public synchronized int getBytes(final BLOB blob, final long n, int length, final byte[] array) throws SQLException {
        byte[] locator = null;
        int n2 = 0;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (locator = blob.getLocator()) != null, 54);
        if (length <= 0 || array == null) {
            return 0;
        }
        if (length > array.length) {
            length = array.length;
        }
        long length2 = -1L;
        if (blob.isActivePrefetch()) {
            final byte[] prefetchedData = blob.getPrefetchedData();
            length2 = blob.length();
            if (prefetchedData != null && prefetchedData != null && n <= prefetchedData.length) {
                final int min = Math.min(prefetchedData.length - (int)n + 1, length);
                System.arraycopy(prefetchedData, (int)n - 1, array, 0, min);
                n2 += min;
            }
        }
        if (n2 < length && (length2 == -1L || n - 1L + n2 < length2)) {
            byte[] dst = array;
            final int n3 = n2;
            final int n4 = ((length2 > 0L && length2 < length) ? ((int)length2) : length) - n2;
            if (n2 > 0) {
                dst = new byte[n4];
            }
            if (this.useNio) {
                final int length3 = array.length;
                if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < length3) {
                    this.nioBufferForLob = ByteBuffer.allocateDirect(length3);
                }
                else {
                    this.nioBufferForLob.rewind();
                }
            }
            n2 += this.blobRead(locator, n + n2, n4, dst, this.useNio, this.nioBufferForLob);
            if (this.useNio) {
                this.nioBufferForLob.get(dst);
            }
            if (n3 > 0) {
                System.arraycopy(dst, 0, array, n3, dst.length);
            }
        }
        return n2;
    }
    
    @Override
    public synchronized int putBytes(final BLOB blob, final long n, final byte[] array, final int n2, final int n3) throws SQLException {
        this.checkTrue(n >= 0L, 68);
        int blobWrite;
        if (array == null || array.length == 0 || n3 <= 0) {
            blobWrite = 0;
        }
        else {
            byte[] locator = null;
            this.checkTrue(this.lifecycle == 1, 8);
            this.checkTrue(blob != null && (locator = blob.getLocator()) != null, 54);
            final byte[][] array2 = { null };
            blob.setActivePrefetch(false);
            blob.clearCachedData();
            blobWrite = this.blobWrite(locator, n, array, array2, n2, n3);
            blob.setLocator(array2[0]);
        }
        return blobWrite;
    }
    
    @Override
    public synchronized int getChunkSize(final BLOB blob) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (locator = blob.getLocator()) != null, 54);
        return this.lobGetChunkSize(locator);
    }
    
    @Override
    public synchronized void trim(final BLOB blob, final long n) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (shareBytes = blob.shareBytes()) != null, 54);
        final byte[][] array = { null };
        blob.setActivePrefetch(false);
        blob.clearCachedData();
        this.checkError(this.t2cLobTrim(this.m_nativeState, 113, n, shareBytes, shareBytes.length, array));
        blob.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized BLOB createTemporaryBlob(final Connection connection, final boolean b, final int n) throws SQLException {
        this.checkTrue(this.lifecycle == 1, 8);
        final BLOB blob = new BLOB((oracle.jdbc.OracleConnection)connection);
        final byte[][] array = { null };
        this.checkError(this.t2cLobCreateTemporary(this.m_nativeState, 113, b, n, (short)0, array));
        blob.setShareBytes(array[0]);
        return blob;
    }
    
    @Override
    public synchronized void freeTemporary(final BLOB blob, final boolean b) throws SQLException {
        try {
            byte[] shareBytes = null;
            this.checkTrue(this.lifecycle == 1, 8);
            this.checkTrue(blob != null && (shareBytes = blob.shareBytes()) != null, 54);
            final byte[][] array = { null };
            this.checkError(this.t2cLobFreeTemporary(this.m_nativeState, 113, shareBytes, shareBytes.length, array));
            blob.setShareBytes(array[0]);
        }
        catch (SQLException ex) {
            if (!(b & ex.getErrorCode() == 64201)) {
                throw ex;
            }
            LobPlsqlUtil.freeTemporaryLob(this, blob, 2004);
        }
    }
    
    @Override
    public synchronized boolean isTemporary(final BLOB blob) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(blob != null && (shareBytes = blob.shareBytes()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cLobIsTemporary(this.m_nativeState, 113, shareBytes, shareBytes.length, array));
        return array[0];
    }
    
    @Override
    public synchronized void open(final BLOB blob, final int n) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (shareBytes = blob.shareBytes()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cLobOpen(this.m_nativeState, 113, shareBytes, shareBytes.length, n, array));
        blob.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized void close(final BLOB blob) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (shareBytes = blob.shareBytes()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cLobClose(this.m_nativeState, 113, shareBytes, shareBytes.length, array));
        blob.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized boolean isOpen(final BLOB blob) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(blob != null && (shareBytes = blob.shareBytes()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cLobIsOpen(this.m_nativeState, 113, shareBytes, shareBytes.length, array));
        return array[0];
    }
    
    @Override
    public InputStream newInputStream(final BLOB blob, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleBlobInputStream(blob, n);
        }
        return new OracleBlobInputStream(blob, n, n2);
    }
    
    @Override
    public InputStream newInputStream(final BLOB blob, final int n, final long n2, final long n3) throws SQLException {
        return new OracleBlobInputStream(blob, n, n2, n3);
    }
    
    @Override
    public OutputStream newOutputStream(final BLOB blob, final int n, final long n2, final boolean b) throws SQLException {
        if (n2 != 0L) {
            return new OracleBlobOutputStream(blob, n, n2);
        }
        if (b & this.lobStreamPosStandardCompliant) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleBlobOutputStream(blob, n);
    }
    
    @Override
    public InputStream newConversionInputStream(final BLOB blob, final int n) throws SQLException {
        this.checkTrue(blob != null && blob.shareBytes() != null, 54);
        return new OracleConversionInputStream(this.conversion, blob.getBinaryStream(), n);
    }
    
    @Override
    public Reader newConversionReader(final BLOB blob, final int n) throws SQLException {
        this.checkTrue(blob != null && blob.shareBytes() != null, 54);
        return new OracleConversionReader(this.conversion, blob.getBinaryStream(), n);
    }
    
    @Override
    public synchronized long length(final CLOB clob) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (locator = clob.getLocator()) != null, 54);
        return this.lobLength(locator);
    }
    
    @Override
    public synchronized long position(final CLOB clob, final String s, final long n) throws SQLException {
        if (s == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && clob.shareBytes() != null, 54);
        if (n < 1L) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final char[] dst = new char[s.length()];
        s.getChars(0, dst.length, dst, 0);
        final long hasPattern = LobPlsqlUtil.hasPattern(clob, dst, n);
        return (hasPattern == 0L) ? -1L : hasPattern;
    }
    
    @Override
    public synchronized long position(final CLOB clob, final CLOB clob2, final long n) throws SQLException {
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && clob.shareBytes() != null, 54);
        this.checkTrue(clob2 != null && clob2.shareBytes() != null, 54);
        if (n < 1L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "position()");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final long subLob = LobPlsqlUtil.isSubLob(clob, clob2, n);
        return (subLob == 0L) ? -1L : subLob;
    }
    
    @Override
    public synchronized int getChars(final CLOB clob, final long n, int length, final char[] array) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (locator = clob.getLocator()) != null, 54);
        if (length <= 0 || array == null) {
            return 0;
        }
        if (length > array.length) {
            length = array.length;
        }
        int n2 = 0;
        long length2 = -1L;
        if (clob.isActivePrefetch()) {
            length2 = clob.length();
            final char[] prefetchedData = clob.getPrefetchedData();
            if (prefetchedData != null && n <= prefetchedData.length) {
                final int min = Math.min(prefetchedData.length - (int)n + 1, length);
                System.arraycopy(prefetchedData, (int)n - 1, array, 0, min);
                n2 += min;
            }
        }
        if (n2 < length && (length2 == -1L || n - 1L + n2 < length2)) {
            char[] dst = array;
            final int n3 = n2;
            final int n4 = ((length2 > 0L && length2 < length) ? ((int)length2) : length) - n2;
            if (n2 > 0) {
                dst = new char[n4];
            }
            if (this.useNio) {
                final int capacity = array.length * 2;
                if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < capacity) {
                    this.nioBufferForLob = ByteBuffer.allocateDirect(capacity);
                }
                else {
                    this.nioBufferForLob.rewind();
                }
            }
            n2 += this.t2cClobRead(this.m_nativeState, locator, locator.length, n + n2, n4, dst, dst.length, clob.isNCLOB(), this.useNio, this.nioBufferForLob);
            if (this.useNio) {
                this.nioBufferForLob.order(ByteOrder.LITTLE_ENDIAN).asCharBuffer().get(dst);
            }
            if (n3 > 0) {
                System.arraycopy(dst, 0, array, n3, dst.length);
            }
            this.checkError(n2);
        }
        return n2;
    }
    
    @Override
    public synchronized int putChars(final CLOB clob, final long n, final char[] array, final int n2, final int n3) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(n >= 0L, 68);
        this.checkTrue(clob != null && (locator = clob.getLocator()) != null, 54);
        if (array == null) {
            return 0;
        }
        final byte[][] array2 = { null };
        clob.setActivePrefetch(false);
        clob.clearCachedData();
        final int clobWrite = this.clobWrite(locator, n, array, array2, clob.isNCLOB(), n2, n3);
        clob.setLocator(array2[0]);
        return clobWrite;
    }
    
    @Override
    public synchronized int getChunkSize(final CLOB clob) throws SQLException {
        byte[] locator = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (locator = clob.getLocator()) != null, 54);
        return this.lobGetChunkSize(locator);
    }
    
    @Override
    public synchronized void trim(final CLOB clob, final long n) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (shareBytes = clob.shareBytes()) != null, 54);
        final byte[][] array = { null };
        clob.setActivePrefetch(false);
        clob.clearCachedData();
        this.checkError(this.t2cLobTrim(this.m_nativeState, 112, n, shareBytes, shareBytes.length, array));
        clob.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized CLOB createTemporaryClob(final Connection connection, final boolean b, final int n, final short n2) throws SQLException {
        this.checkTrue(this.lifecycle == 1, 8);
        CLOB clob;
        if (n2 == 1) {
            clob = new CLOB((oracle.jdbc.OracleConnection)connection);
        }
        else {
            clob = new NCLOB((oracle.jdbc.OracleConnection)connection);
        }
        final byte[][] array = { null };
        this.checkError(this.t2cLobCreateTemporary(this.m_nativeState, 112, b, n, n2, array));
        clob.setShareBytes(array[0]);
        return clob;
    }
    
    @Override
    public synchronized void freeTemporary(final CLOB clob, final boolean b) throws SQLException {
        try {
            byte[] shareBytes = null;
            this.checkTrue(this.lifecycle == 1, 8);
            this.checkTrue(clob != null && (shareBytes = clob.shareBytes()) != null, 54);
            final byte[][] array = { null };
            this.checkError(this.t2cLobFreeTemporary(this.m_nativeState, 112, shareBytes, shareBytes.length, array));
            clob.setShareBytes(array[0]);
        }
        catch (SQLException ex) {
            if (!(b & ex.getErrorCode() == 64201)) {
                throw ex;
            }
            LobPlsqlUtil.freeTemporaryLob(this, clob, 2005);
        }
    }
    
    @Override
    public synchronized boolean isTemporary(final CLOB clob) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(clob != null && (shareBytes = clob.shareBytes()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cLobIsTemporary(this.m_nativeState, 112, shareBytes, shareBytes.length, array));
        return array[0];
    }
    
    @Override
    public synchronized void open(final CLOB clob, final int n) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (shareBytes = clob.shareBytes()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cLobOpen(this.m_nativeState, 112, shareBytes, shareBytes.length, n, array));
        clob.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized void close(final CLOB clob) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (shareBytes = clob.shareBytes()) != null, 54);
        final byte[][] array = { null };
        this.checkError(this.t2cLobClose(this.m_nativeState, 112, shareBytes, shareBytes.length, array));
        clob.setShareBytes(array[0]);
    }
    
    @Override
    public synchronized boolean isOpen(final CLOB clob) throws SQLException {
        byte[] shareBytes = null;
        this.checkTrue(this.lifecycle == 1, 8);
        this.checkTrue(clob != null && (shareBytes = clob.shareBytes()) != null, 54);
        final boolean[] array = { false };
        this.checkError(this.t2cLobIsOpen(this.m_nativeState, 112, shareBytes, shareBytes.length, array));
        return array[0];
    }
    
    @Override
    public InputStream newInputStream(final CLOB clob, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleClobInputStream(clob, n);
        }
        return new OracleClobInputStream(clob, n, n2);
    }
    
    @Override
    public OutputStream newOutputStream(final CLOB clob, final int n, final long n2, final boolean b) throws SQLException {
        if (n2 != 0L) {
            return new OracleClobOutputStream(clob, n, n2);
        }
        if (b & this.lobStreamPosStandardCompliant) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleClobOutputStream(clob, n);
    }
    
    @Override
    public Reader newReader(final CLOB clob, final int n, final long n2) throws SQLException {
        if (n2 == 0L) {
            return new OracleClobReader(clob, n);
        }
        return new OracleClobReader(clob, n, n2);
    }
    
    @Override
    public Reader newReader(final CLOB clob, final int n, final long n2, final long n3) throws SQLException {
        return new OracleClobReader(clob, n, n2, n3);
    }
    
    @Override
    public Writer newWriter(final CLOB clob, final int n, final long n2, final boolean b) throws SQLException {
        if (n2 != 0L) {
            return new OracleClobWriter(clob, n, n2);
        }
        if (b & this.lobStreamPosStandardCompliant) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleClobWriter(clob, n);
    }
    
    @Override
    public synchronized void registerTAFCallback(final OracleOCIFailover appCallback, final Object appCallbackObject) throws SQLException {
        this.appCallback = appCallback;
        this.appCallbackObject = appCallbackObject;
        this.checkError(this.t2cRegisterTAFCallback(this.m_nativeState));
    }
    
    synchronized int callTAFCallbackMethod(final int n, final int n2) {
        int callbackFn = 0;
        if (this.appCallback != null) {
            callbackFn = this.appCallback.callbackFn(this, this.appCallbackObject, n, n2);
        }
        return callbackFn;
    }
    
    @Override
    public int getHeapAllocSize() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int t2cGetHeapAllocSize = this.t2cGetHeapAllocSize(this.m_nativeState);
        if (t2cGetHeapAllocSize >= 0) {
            return t2cGetHeapAllocSize;
        }
        if (t2cGetHeapAllocSize == -999) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89);
        sqlException3.fillInStackTrace();
        throw sqlException3;
    }
    
    @Override
    public int getOCIEnvHeapAllocSize() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final int t2cGetOciEnvHeapAllocSize = this.t2cGetOciEnvHeapAllocSize(this.m_nativeState);
        if (t2cGetOciEnvHeapAllocSize >= 0) {
            return t2cGetOciEnvHeapAllocSize;
        }
        if (t2cGetOciEnvHeapAllocSize == -999) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.checkError(t2cGetOciEnvHeapAllocSize);
        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89);
        sqlException3.fillInStackTrace();
        throw sqlException3;
    }
    
    public static final short getClientCharSetId() {
        return 871;
    }
    
    public static short getDriverCharSetIdFromNLS_LANG(final String s) throws SQLException {
        if (!T2CConnection.isLibraryLoaded) {
            loadNativeLibrary(s);
        }
        final short t2cGetDriverCharSetFromNlsLang = t2cGetDriverCharSetFromNlsLang();
        if (t2cGetDriverCharSetFromNlsLang < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return t2cGetDriverCharSetFromNlsLang;
    }
    
    @Override
    void doProxySession(final int n, final Properties properties) throws SQLException {
        byte[][] array = null;
        int length = 0;
        this.savedUser = this.userName;
        this.userName = null;
        byte[] array2;
        byte[] stringToDriverCharBytes3;
        byte[] stringToDriverCharBytes2;
        byte[] stringToDriverCharBytes = stringToDriverCharBytes2 = (stringToDriverCharBytes3 = (array2 = new byte[0]));
        switch (n) {
            case 1: {
                this.userName = properties.getProperty("PROXY_USER_NAME");
                final String property = properties.getProperty("PROXY_USER_PASSWORD");
                if (this.userName != null) {
                    stringToDriverCharBytes2 = DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
                }
                if (property != null) {
                    stringToDriverCharBytes = DBConversion.stringToDriverCharBytes(property, this.m_clientCharacterSet);
                    break;
                }
                break;
            }
            case 2: {
                final String property2 = properties.getProperty("PROXY_DISTINGUISHED_NAME");
                if (property2 != null) {
                    stringToDriverCharBytes3 = DBConversion.stringToDriverCharBytes(property2, this.m_clientCharacterSet);
                    break;
                }
                break;
            }
            case 3: {
                array2 = (byte[])properties.get("PROXY_CERTIFICATE");
                break;
            }
        }
        final String[] array3 = (String[])properties.get("PROXY_ROLES");
        if (array3 != null) {
            length = array3.length;
            array = new byte[length][];
            for (int i = 0; i < length; ++i) {
                if (array3[i] == null) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 150);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                array[i] = DBConversion.stringToDriverCharBytes(array3[i], this.m_clientCharacterSet);
            }
        }
        this.sqlWarning = this.checkError(this.t2cDoProxySession(this.m_nativeState, n, stringToDriverCharBytes2, stringToDriverCharBytes2.length, stringToDriverCharBytes, stringToDriverCharBytes.length, stringToDriverCharBytes3, stringToDriverCharBytes3.length, array2, array2.length, length, array), this.sqlWarning);
        this.isProxy = true;
    }
    
    @Override
    void closeProxySession() throws SQLException {
        this.checkError(this.t2cCloseProxySession(this.m_nativeState));
        this.userName = this.savedUser;
    }
    
    @Override
    protected void doDescribeTable(final AutoKeyInfo autoKeyInfo) throws SQLException {
        final byte[] stringToDriverCharBytes = DBConversion.stringToDriverCharBytes(autoKeyInfo.getTableName(), this.m_clientCharacterSet);
        boolean b = false;
        int t2cDescribeTable;
        do {
            t2cDescribeTable = t2cDescribeTable(this.m_nativeState, stringToDriverCharBytes, stringToDriverCharBytes.length, this.queryMetaData1, this.queryMetaData2, this.queryMetaData1Offset, this.queryMetaData2Offset, this.queryMetaData1Size, this.queryMetaData2Size);
            if (t2cDescribeTable == -1) {
                this.checkError(t2cDescribeTable);
            }
            if (t2cDescribeTable == T2CStatement.T2C_EXTEND_BUFFER) {
                b = true;
                this.reallocateQueryMetaData(this.queryMetaData1Size * 2, this.queryMetaData2Size * 2);
            }
        } while (b);
        this.processDescribeTableData(t2cDescribeTable, autoKeyInfo);
    }
    
    private void processDescribeTableData(final int n, final AutoKeyInfo autoKeyInfo) throws SQLException {
        final short[] queryMetaData1 = this.queryMetaData1;
        final byte[] queryMetaData2 = this.queryMetaData2;
        int queryMetaData1Offset = this.queryMetaData1Offset;
        int queryMetaData2Offset = this.queryMetaData2Offset;
        autoKeyInfo.allocateSpaceForDescribedData(n);
        for (int i = 0; i < n; ++i) {
            final short n2 = queryMetaData1[queryMetaData1Offset + 0];
            final short n3 = queryMetaData1[queryMetaData1Offset + 6];
            final String bytes2String = bytes2String(queryMetaData2, queryMetaData2Offset, n3, this.conversion);
            final short n4 = queryMetaData1[queryMetaData1Offset + 1];
            final short n5 = queryMetaData1[queryMetaData1Offset + 11];
            final boolean b = queryMetaData1[queryMetaData1Offset + 2] != 0;
            final short n6 = queryMetaData1[queryMetaData1Offset + 5];
            final short n7 = queryMetaData1[queryMetaData1Offset + 3];
            final short n8 = queryMetaData1[queryMetaData1Offset + 4];
            final short n9 = queryMetaData1[queryMetaData1Offset + 12];
            queryMetaData2Offset += n3;
            queryMetaData1Offset += 13;
            String bytes2String2 = null;
            if (n9 > 0) {
                bytes2String2 = bytes2String(queryMetaData2, queryMetaData2Offset, n9, this.conversion);
                queryMetaData2Offset += n9;
            }
            autoKeyInfo.fillDescribedData(i, bytes2String, n2, (n5 > 0) ? n5 : n4, b, n6, n7, n8, bytes2String2);
        }
    }
    
    @Override
    void doSetApplicationContext(final String s, final String s2, final String s3) throws SQLException {
        this.checkError(this.t2cSetApplicationContext(this.m_nativeState, s, s2, s3));
    }
    
    @Override
    void doClearAllApplicationContext(final String s) throws SQLException {
        this.checkError(this.t2cClearAllApplicationContext(this.m_nativeState, s));
    }
    
    @Override
    void doStartup(final int n) throws SQLException {
        this.checkError(this.t2cStartupDatabase(this.m_nativeState, n));
    }
    
    @Override
    void doShutdown(final int n) throws SQLException {
        this.checkError(this.t2cShutdownDatabase(this.m_nativeState, n));
    }
    
    private static final void loadNativeLibrary(final String s) throws SQLException {
        if (s == null || s.equals("ocijdbc11")) {
            synchronized (T2CConnection.class) {
                if (!T2CConnection.isLibraryLoaded) {
                    AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
                        @Override
                        public Object run() {
                            System.loadLibrary("ocijdbc11");
                            final int libraryVersionNumber = T2CConnection.getLibraryVersionNumber();
                            if (libraryVersionNumber != T2CConnection.JDBC_OCI_LIBRARY_VERSION) {
                                throw new Error("Incompatible version of libocijdbc[Jdbc:" + T2CConnection.JDBC_OCI_LIBRARY_VERSION + ", Jdbc-OCI:" + libraryVersionNumber);
                            }
                            return null;
                        }
                    });
                    T2CConnection.isLibraryLoaded = true;
                }
            }
        }
        else {
            synchronized (T2CConnection.class) {
                try {
                    System.loadLibrary(s);
                    T2CConnection.isLibraryLoaded = true;
                }
                catch (SecurityException ex) {
                    if (!T2CConnection.isLibraryLoaded) {
                        System.loadLibrary(s);
                        T2CConnection.isLibraryLoaded = true;
                    }
                }
            }
        }
    }
    
    private final void checkTrue(final boolean b, final int n) throws SQLException {
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), n);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    boolean useLittleEndianSetCHARBinder() throws SQLException {
        return this.t2cPlatformIsLittleEndian(this.m_nativeState);
    }
    
    @Override
    public void getPropertyForPooledConnection(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        super.getPropertyForPooledConnection(oraclePooledConnection, this.password);
    }
    
    static final char[] getCharArray(final String s) {
        char[] dst;
        if (s == null) {
            dst = new char[0];
        }
        else {
            dst = new char[s.length()];
            s.getChars(0, s.length(), dst, 0);
        }
        return dst;
    }
    
    static String bytes2String(final byte[] array, final int n, final int n2, final DBConversion dbConversion) throws SQLException {
        final byte[] array2 = new byte[n2];
        System.arraycopy(array, n, array2, 0, n2);
        return dbConversion.CharBytesToString(array2, n2);
    }
    
    void disableNio() {
        this.useNio = false;
    }
    
    private static synchronized void doSetSessionTimeZone(final String s) throws SQLException {
        t2cSetSessionTimeZone(s);
    }
    
    static native int getLibraryVersionNumber();
    
    static native short t2cGetServerSessionInfo(final long p0, final Properties p1);
    
    static native short t2cGetDriverCharSetFromNlsLang();
    
    native int t2cDescribeError(final long p0, final T2CError p1, final byte[] p2);
    
    native int t2cCreateState(final byte[] p0, final int p1, final byte[] p2, final int p3, final byte[] p4, final int p5, final byte[] p6, final int p7, final byte[] p8, final int p9, final byte[] p10, final int p11, final byte[] p12, final int p13, final short p14, final int p15, final short[] p16, final byte[] p17, final byte[] p18, final long[] p19);
    
    native int t2cLogon(final long p0, final byte[] p1, final int p2, final byte[] p3, final int p4, final byte[] p5, final int p6, final byte[] p7, final int p8, final byte[] p9, final int p10, final byte[] p11, final int p12, final byte[] p13, final int p14, final int p15, final short[] p16, final byte[] p17, final byte[] p18, final long[] p19);
    
    private native int t2cLogoff(final long p0);
    
    private native int t2cCancel(final long p0);
    
    private native byte t2cGetAsmVolProperty(final long p0);
    
    private native byte t2cGetInstanceType(final long p0);
    
    private native int t2cCreateStatement(final long p0, final long p1, final byte[] p2, final int p3, final OracleStatement p4, final boolean p5, final int p6);
    
    private native int t2cSetAutoCommit(final long p0, final boolean p1);
    
    private native int t2cCommit(final long p0, final int p1);
    
    private native int t2cRollback(final long p0);
    
    private native int t2cPingDatabase(final long p0);
    
    private native byte[] t2cGetProductionVersion(final long p0);
    
    private native int t2cGetVersionNumber(final long p0);
    
    private native int t2cGetDefaultStreamChunkSize(final long p0);
    
    native int t2cGetFormOfUse(final long p0, final OracleTypeCLOB p1, final byte[] p2, final int p3, final int p4);
    
    native long t2cGetTDO(final long p0, final byte[] p1, final int p2, final int[] p3);
    
    native int t2cCreateConnPool(final byte[] p0, final int p1, final byte[] p2, final int p3, final byte[] p4, final int p5, final short p6, final int p7, final int p8, final int p9, final int p10, final int p11, final int p12, final int p13);
    
    native int t2cConnPoolLogon(final long p0, final byte[] p1, final int p2, final byte[] p3, final int p4, final byte[] p5, final int p6, final byte[] p7, final int p8, final byte[] p9, final int p10, final int p11, final int p12, final int p13, final String[] p14, final byte[] p15, final int p16, final byte[] p17, final int p18, final byte[] p19, final int p20, final byte[] p21, final int p22, final byte[] p23, final int p24, final short[] p25, final byte[] p26, final byte[] p27, final long[] p28);
    
    native int t2cGetConnPoolInfo(final long p0, final Properties p1);
    
    native int t2cSetConnPoolInfo(final long p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6);
    
    native int t2cPasswordChange(final long p0, final byte[] p1, final int p2, final byte[] p3, final int p4, final byte[] p5, final int p6);
    
    protected native byte[] t2cGetConnectionId(final long p0);
    
    native int t2cGetHandles(final long p0, final long[] p1);
    
    native int t2cUseConnection(final long p0, final long p1, final long p2, final long p3, final short[] p4, final long[] p5);
    
    native boolean t2cPlatformIsLittleEndian(final long p0);
    
    native int t2cRegisterTAFCallback(final long p0);
    
    native int t2cGetHeapAllocSize(final long p0);
    
    native int t2cGetOciEnvHeapAllocSize(final long p0);
    
    native int t2cDoProxySession(final long p0, final int p1, final byte[] p2, final int p3, final byte[] p4, final int p5, final byte[] p6, final int p7, final byte[] p8, final int p9, final int p10, final byte[][] p11);
    
    native int t2cCloseProxySession(final long p0);
    
    static native int t2cDescribeTable(final long p0, final byte[] p1, final int p2, final short[] p3, final byte[] p4, final int p5, final int p6, final int p7, final int p8);
    
    native int t2cSetApplicationContext(final long p0, final String p1, final String p2, final String p3);
    
    native int t2cClearAllApplicationContext(final long p0, final String p1);
    
    native int t2cStartupDatabase(final long p0, final int p1);
    
    native int t2cShutdownDatabase(final long p0, final int p1);
    
    static native void t2cSetSessionTimeZone(final String p0);
    
    static {
        JDBC_OCI_LIBRARY_VERSION = Long.parseLong("11.2.0.2.0".replaceAll("\\.", ""));
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
