// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.CLOB;
import java.io.Writer;

class OracleClobWriter extends Writer
{
    DBConversion dbConversion;
    CLOB clob;
    long lobOffset;
    char[] charBuf;
    byte[] nativeBuf;
    int pos;
    int count;
    int chunkSize;
    boolean isClosed;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleClobWriter(final CLOB clob, final int n) throws SQLException {
        this(clob, n, 1L);
    }
    
    public OracleClobWriter(final CLOB clob, final int chunkSize, final long lobOffset) throws SQLException {
        if (clob == null || chunkSize <= 0 || clob.getJavaSqlConnection() == null || lobOffset < 1L) {
            throw new IllegalArgumentException();
        }
        this.dbConversion = ((PhysicalConnection)clob.getInternalConnection()).conversion;
        this.clob = clob;
        this.lobOffset = lobOffset;
        this.charBuf = new char[chunkSize];
        this.nativeBuf = new byte[chunkSize * 3];
        final int n = 0;
        this.count = n;
        this.pos = n;
        this.chunkSize = chunkSize;
        this.isClosed = false;
    }
    
    @Override
    public void write(final char[] array, final int n, final int a) throws IOException {
        synchronized (this.lock) {
            this.ensureOpen();
            int i = n;
            final int min = Math.min(a, array.length - n);
            if (min >= 2 * this.chunkSize) {
                if (this.count > 0) {
                    this.flushBuffer();
                }
                try {
                    this.lobOffset += this.clob.putChars(this.lobOffset, array, n, min);
                }
                catch (SQLException ex) {
                    final IOException ioException = DatabaseError.createIOException(ex);
                    ioException.fillInStackTrace();
                    throw ioException;
                }
                return;
            }
            final int n2 = i + min;
            while (i < n2) {
                final int min2 = Math.min(this.chunkSize - this.count, n2 - i);
                System.arraycopy(array, i, this.charBuf, this.count, min2);
                i += min2;
                this.count += min2;
                if (this.count >= this.chunkSize) {
                    this.flushBuffer();
                }
            }
        }
    }
    
    @Override
    public void flush() throws IOException {
        synchronized (this.lock) {
            this.ensureOpen();
            this.flushBuffer();
        }
    }
    
    @Override
    public void close() throws IOException {
        synchronized (this.lock) {
            this.flushBuffer();
            this.isClosed = true;
        }
    }
    
    private void flushBuffer() throws IOException {
        synchronized (this.lock) {
            try {
                if (this.count > 0) {
                    this.lobOffset += this.clob.putChars(this.lobOffset, this.charBuf, 0, this.count);
                    this.count = 0;
                }
            }
            catch (SQLException ex) {
                final IOException ioException = DatabaseError.createIOException(ex);
                ioException.fillInStackTrace();
                throw ioException;
            }
        }
    }
    
    void ensureOpen() throws IOException {
        try {
            if (this.isClosed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 57, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        try {
            return this.clob.getInternalConnection();
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
