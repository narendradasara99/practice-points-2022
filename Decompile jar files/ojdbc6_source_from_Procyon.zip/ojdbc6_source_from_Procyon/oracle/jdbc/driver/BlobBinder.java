// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class BlobBinder extends DatumBinder
{
    Binder theBlobCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 113;
        binder.bytelen = 4000;
    }
    
    BlobBinder() {
        this.theBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theBlobCopyingBinder;
    }
    
    @Override
    void lastBoundValueCleanup(final OraclePreparedStatement oraclePreparedStatement, final int n) {
        if (oraclePreparedStatement.lastBoundBlobs != null) {
            oraclePreparedStatement.moveTempLobsToFree(oraclePreparedStatement.lastBoundBlobs[n]);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
