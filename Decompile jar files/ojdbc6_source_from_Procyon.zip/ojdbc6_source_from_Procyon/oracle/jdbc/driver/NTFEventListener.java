// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.util.EventListener;
import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.aq.AQNotificationListener;

class NTFEventListener
{
    private final AQNotificationListener aqlistener;
    private final DatabaseChangeListener dcnlistener;
    private final XSEventListener xslistener;
    private Executor executor;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFEventListener(final DatabaseChangeListener dcnlistener) throws SQLException {
        this.executor = null;
        if (dcnlistener == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 246);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.dcnlistener = dcnlistener;
        this.aqlistener = null;
        this.xslistener = null;
    }
    
    NTFEventListener(final AQNotificationListener aqlistener) throws SQLException {
        this.executor = null;
        if (aqlistener == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 246);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.aqlistener = aqlistener;
        this.dcnlistener = null;
        this.xslistener = null;
    }
    
    NTFEventListener(final XSEventListener xslistener) throws SQLException {
        this.executor = null;
        if (xslistener == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 246);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.aqlistener = null;
        this.dcnlistener = null;
        this.xslistener = xslistener;
    }
    
    void setExecutor(final Executor executor) {
        this.executor = executor;
    }
    
    Executor getExecutor() {
        return this.executor;
    }
    
    EventListener getListener() {
        Object o = this.dcnlistener;
        if (o == null) {
            o = this.aqlistener;
        }
        return (EventListener)o;
    }
    
    AQNotificationListener getAQListener() {
        return this.aqlistener;
    }
    
    DatabaseChangeListener getDCNListener() {
        return this.dcnlistener;
    }
    
    XSEventListener getXSEventListener() {
        return this.xslistener;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
