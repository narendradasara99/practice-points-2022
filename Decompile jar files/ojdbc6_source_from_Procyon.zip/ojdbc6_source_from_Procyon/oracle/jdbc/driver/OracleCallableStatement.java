// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.StructDescriptor;
import oracle.sql.ORAData;
import oracle.sql.CustomDatum;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.NClob;
import java.io.Serializable;
import java.net.URL;
import java.util.Calendar;
import java.sql.Array;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Ref;
import java.util.Map;
import java.sql.ResultSet;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatumFactory;
import oracle.sql.ANYDATA;
import java.io.InputStream;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import oracle.sql.BFILE;
import oracle.sql.CLOB;
import oracle.sql.BLOB;
import oracle.sql.RAW;
import java.io.Reader;
import oracle.sql.CHAR;
import oracle.sql.OPAQUE;
import oracle.sql.STRUCT;
import oracle.sql.ARRAY;
import oracle.sql.REF;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.DATE;
import oracle.sql.NUMBER;
import oracle.sql.ROWID;
import oracle.sql.Datum;
import java.sql.SQLException;

abstract class OracleCallableStatement extends OraclePreparedStatement implements oracle.jdbc.internal.OracleCallableStatement
{
    boolean atLeastOneOrdinalParameter;
    boolean atLeastOneNamedParameter;
    String[] namedParameters;
    int parameterCount;
    final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleCallableStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        this(physicalConnection, s, n, n2, 1003, 1007);
    }
    
    OracleCallableStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2, final int n3, final int n4) throws SQLException {
        super(physicalConnection, s, 1, n2, n3, n4);
        this.atLeastOneOrdinalParameter = false;
        this.atLeastOneNamedParameter = false;
        this.namedParameters = new String[8];
        this.parameterCount = 0;
        this.statementType = 2;
    }
    
    void registerOutParameterInternal(final int n, final int n2, final int n3, int n4, String s) throws SQLException {
        final int n5 = n - 1;
        if (n5 < 0 || n > this.numberOfBindPositions) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (n2 == 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final int internalType = this.getInternalType(n2);
        this.resetBatch();
        this.currentRowNeedToPrepareBinds = true;
        if (this.currentRowBindAccessors == null) {
            this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
        }
        switch (n2) {
            case -4:
            case -3:
            case -1:
            case 1:
            case 12:
            case 70: {
                break;
            }
            case -16:
            case -15:
            case -9: {
                this.currentRowFormOfUse[n5] = 2;
                break;
            }
            case 2011: {
                n4 = 0;
                this.currentRowFormOfUse[n5] = 2;
                break;
            }
            case 2009: {
                n4 = 0;
                s = "SYS.XMLTYPE";
                break;
            }
            default: {
                n4 = 0;
                break;
            }
        }
        this.currentRowBindAccessors[n5] = this.allocateAccessor(internalType, n2, n5 + 1, n4, this.currentRowFormOfUse[n5], s, true);
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final String s) throws SQLException {
        if (s == null || s.length() == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60, "empty Object name");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        synchronized (this.connection) {
            this.registerOutParameterInternal(n, n2, 0, 0, s);
        }
    }
    
    @Override
    @Deprecated
    public void registerOutParameterBytes(final int n, final int n2, final int n3, final int n4) throws SQLException {
        synchronized (this.connection) {
            this.registerOutParameterInternal(n, n2, n3, n4, null);
        }
    }
    
    @Override
    @Deprecated
    public void registerOutParameterChars(final int n, final int n2, final int n3, final int n4) throws SQLException {
        synchronized (this.connection) {
            this.registerOutParameterInternal(n, n2, n3, n4, null);
        }
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final int n3, final int n4) throws SQLException {
        synchronized (this.connection) {
            this.registerOutParameterInternal(n, n2, n3, n4, null);
        }
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            this.registerOutParameterInternal(s, n, n2, n3, null);
        }
    }
    
    @Override
    boolean isOracleBatchStyle() {
        return false;
    }
    
    @Override
    void resetBatch() {
        this.batch = 1;
    }
    
    @Override
    public void setExecuteBatch(final int n) throws SQLException {
    }
    
    @Override
    public int sendBatch() throws SQLException {
        synchronized (this.connection) {
            return this.validRows;
        }
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2) throws SQLException {
        this.registerOutParameter(n, n2, 0, -1);
    }
    
    @Override
    public void registerOutParameter(final int n, final int n2, final int n3) throws SQLException {
        this.registerOutParameter(n, n2, n3, -1);
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        return this.wasNullValue();
    }
    
    @Override
    public String getString(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getString(this.currentRank);
    }
    
    @Override
    public Datum getOracleObject(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getOracleObject(this.currentRank);
    }
    
    @Override
    public ROWID getROWID(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getROWID(this.currentRank);
    }
    
    @Override
    public NUMBER getNUMBER(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNUMBER(this.currentRank);
    }
    
    @Override
    public DATE getDATE(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDATE(this.currentRank);
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getINTERVALYM(this.currentRank);
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getINTERVALDS(this.currentRank);
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTIMESTAMP(this.currentRank);
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTIMESTAMPTZ(this.currentRank);
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTIMESTAMPLTZ(this.currentRank);
    }
    
    @Override
    public REF getREF(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getREF(this.currentRank);
    }
    
    @Override
    public ARRAY getARRAY(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getARRAY(this.currentRank);
    }
    
    @Override
    public STRUCT getSTRUCT(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getSTRUCT(this.currentRank);
    }
    
    @Override
    public OPAQUE getOPAQUE(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getOPAQUE(this.currentRank);
    }
    
    @Override
    public CHAR getCHAR(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCHAR(this.currentRank);
    }
    
    @Override
    public Reader getCharacterStream(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCharacterStream(this.currentRank);
    }
    
    @Override
    public RAW getRAW(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getRAW(this.currentRank);
    }
    
    @Override
    public BLOB getBLOB(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBLOB(this.currentRank);
    }
    
    @Override
    public CLOB getCLOB(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCLOB(this.currentRank);
    }
    
    @Override
    public BFILE getBFILE(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBFILE(this.currentRank);
    }
    
    @Override
    public BFILE getBfile(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBFILE(this.currentRank);
    }
    
    @Override
    public boolean getBoolean(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBoolean(this.currentRank);
    }
    
    @Override
    public byte getByte(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getByte(this.currentRank);
    }
    
    @Override
    public short getShort(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getShort(this.currentRank);
    }
    
    @Override
    public int getInt(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getInt(this.currentRank);
    }
    
    @Override
    public long getLong(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getLong(this.currentRank);
    }
    
    @Override
    public float getFloat(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getFloat(this.currentRank);
    }
    
    @Override
    public double getDouble(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDouble(this.currentRank);
    }
    
    @Override
    public BigDecimal getBigDecimal(final int lastIndex, final int n) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBigDecimal(this.currentRank);
    }
    
    @Override
    public byte[] getBytes(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBytes(this.currentRank);
    }
    
    @Override
    public byte[] privateGetBytes(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.privateGetBytes(this.currentRank);
    }
    
    @Override
    public Date getDate(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDate(this.currentRank);
    }
    
    @Override
    public Time getTime(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTime(this.currentRank);
    }
    
    @Override
    public Timestamp getTimestamp(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTimestamp(this.currentRank);
    }
    
    @Override
    public InputStream getAsciiStream(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getAsciiStream(this.currentRank);
    }
    
    @Override
    public InputStream getUnicodeStream(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getUnicodeStream(this.currentRank);
    }
    
    @Override
    public InputStream getBinaryStream(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBinaryStream(this.currentRank);
    }
    
    @Override
    public Object getObject(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getObject(this.currentRank);
    }
    
    @Override
    public Object getAnyDataEmbeddedObject(final int n) throws SQLException {
        Object jdbc = null;
        final Object object = this.getObject(n);
        if (object instanceof ANYDATA) {
            final Datum accessDatum = ((ANYDATA)object).accessDatum();
            if (accessDatum != null) {
                jdbc = accessDatum.toJdbc();
            }
        }
        return jdbc;
    }
    
    @Override
    public Object getCustomDatum(final int lastIndex, final CustomDatumFactory customDatumFactory) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCustomDatum(this.currentRank, customDatumFactory);
    }
    
    @Override
    public Object getORAData(final int lastIndex, final ORADataFactory oraDataFactory) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getORAData(this.currentRank, oraDataFactory);
    }
    
    @Override
    public ResultSet getCursor(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCursor(this.currentRank);
    }
    
    @Override
    public void clearParameters() throws SQLException {
        synchronized (this.connection) {
            super.clearParameters();
        }
    }
    
    @Override
    public Object getObject(final int lastIndex, final Map map) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getObject(this.currentRank, map);
    }
    
    @Override
    public Ref getRef(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getREF(this.currentRank);
    }
    
    @Override
    public Blob getBlob(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBLOB(this.currentRank);
    }
    
    @Override
    public Clob getClob(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCLOB(this.currentRank);
    }
    
    @Override
    public Array getArray(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getARRAY(this.currentRank);
    }
    
    @Override
    public BigDecimal getBigDecimal(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBigDecimal(this.currentRank);
    }
    
    @Override
    public Date getDate(final int lastIndex, final Calendar calendar) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDate(this.currentRank, calendar);
    }
    
    @Override
    public Time getTime(final int lastIndex, final Calendar calendar) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTime(this.currentRank, calendar);
    }
    
    @Override
    public Timestamp getTimestamp(final int lastIndex, final Calendar calendar) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTimestamp(this.currentRank, calendar);
    }
    
    @Override
    public void addBatch() throws SQLException {
        if (this.currentRowBindAccessors != null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        super.addBatch();
    }
    
    @Override
    protected void alwaysOnClose() throws SQLException {
        this.sqlObject.resetNamedParameters();
        this.namedParameters = new String[8];
        this.parameterCount = 0;
        this.atLeastOneOrdinalParameter = false;
        this.atLeastOneNamedParameter = false;
        super.alwaysOnClose();
    }
    
    @Override
    public void registerOutParameter(final String s, final int n) throws SQLException {
        this.registerOutParameterInternal(s, n, 0, -1, null);
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final int n2) throws SQLException {
        this.registerOutParameterInternal(s, n, n2, -1, null);
    }
    
    @Override
    public void registerOutParameter(final String s, final int n, final String s2) throws SQLException {
        this.registerOutParameterInternal(s, n, 0, -1, s2);
    }
    
    void registerOutParameterInternal(final String s, final int n, final int n2, final int n3, final String s2) throws SQLException {
        this.registerOutParameterInternal(this.addNamedPara(s), n, n2, n3, s2);
    }
    
    @Override
    public URL getURL(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getURL(this.currentRank);
    }
    
    @Override
    public void setStringForClob(final String s, final String s2) throws SQLException {
        final int addNamedPara = this.addNamedPara(s);
        if (s2 == null || s2.length() == 0) {
            this.setNull(addNamedPara, 2005);
            return;
        }
        this.setStringForClob(addNamedPara, s2);
    }
    
    @Override
    public void setStringForClob(final int n, final String s) throws SQLException {
        if (s == null || s.length() == 0) {
            this.setNull(n, 2005);
            return;
        }
        synchronized (this.connection) {
            this.setStringForClobCritical(n, s);
        }
    }
    
    @Override
    public void setBytesForBlob(final String s, final byte[] array) throws SQLException {
        this.setBytesForBlob(this.addNamedPara(s), array);
    }
    
    @Override
    public void setBytesForBlob(final int n, final byte[] array) throws SQLException {
        if (array == null || array.length == 0) {
            this.setNull(n, 2004);
            return;
        }
        synchronized (this.connection) {
            this.setBytesForBlobCritical(n, array);
        }
    }
    
    @Override
    public String getString(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getString(this.currentRank);
    }
    
    @Override
    public boolean getBoolean(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBoolean(this.currentRank);
    }
    
    @Override
    public byte getByte(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getByte(this.currentRank);
    }
    
    @Override
    public short getShort(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getShort(this.currentRank);
    }
    
    @Override
    public int getInt(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getInt(this.currentRank);
    }
    
    @Override
    public long getLong(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getLong(this.currentRank);
    }
    
    @Override
    public float getFloat(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getFloat(this.currentRank);
    }
    
    @Override
    public double getDouble(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDouble(this.currentRank);
    }
    
    @Override
    public byte[] getBytes(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBytes(this.currentRank);
    }
    
    @Override
    public Date getDate(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDate(this.currentRank);
    }
    
    @Override
    public Time getTime(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTime(this.currentRank);
    }
    
    @Override
    public Timestamp getTimestamp(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTimestamp(this.currentRank);
    }
    
    @Override
    public Object getObject(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getObject(this.currentRank);
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBigDecimal(this.currentRank);
    }
    
    @Override
    public BigDecimal getBigDecimal(final String s, final int n) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBigDecimal(this.currentRank, n);
    }
    
    @Override
    public Object getObject(final String s, final Map map) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getObject(this.currentRank, map);
    }
    
    @Override
    public Ref getRef(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getREF(this.currentRank);
    }
    
    @Override
    public Blob getBlob(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBLOB(this.currentRank);
    }
    
    @Override
    public Clob getClob(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCLOB(this.currentRank);
    }
    
    @Override
    public Array getArray(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getARRAY(this.currentRank);
    }
    
    @Override
    public Date getDate(final String s, final Calendar calendar) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getDate(this.currentRank, calendar);
    }
    
    @Override
    public Time getTime(final String s, final Calendar calendar) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTime(this.currentRank, calendar);
    }
    
    @Override
    public Timestamp getTimestamp(final String s, final Calendar calendar) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getTimestamp(this.currentRank, calendar);
    }
    
    @Override
    public URL getURL(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getURL(this.currentRank);
    }
    
    @Override
    @Deprecated
    public InputStream getAsciiStream(final String s) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void registerIndexTableOutParameter(final int n, final int n2, final int n3, final int n4) throws SQLException {
        synchronized (this.connection) {
            final int n5 = n - 1;
            if (n5 < 0 || n > this.numberOfBindPositions) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int internalType = this.getInternalType(n3);
            this.resetBatch();
            this.currentRowNeedToPrepareBinds = true;
            if (this.currentRowBindAccessors == null) {
                this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
            }
            this.currentRowBindAccessors[n5] = this.allocateIndexTableAccessor(n3, internalType, n4, n2, this.currentRowFormOfUse[n5], true);
            this.hasIbtBind = true;
        }
    }
    
    PlsqlIndexTableAccessor allocateIndexTableAccessor(final int n, final int n2, final int n3, final int n4, final short n5, final boolean b) throws SQLException {
        return new PlsqlIndexTableAccessor(this, n, n2, n3, n4, n5, b);
    }
    
    @Override
    public Object getPlsqlIndexTable(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum[] oraclePlsqlIndexTable = this.getOraclePlsqlIndexTable(n);
            Serializable[] array = null;
            switch (((PlsqlIndexTableAccessor)this.outBindAccessors[n - 1]).elementInternalType) {
                case 9: {
                    array = new String[oraclePlsqlIndexTable.length];
                    break;
                }
                case 6: {
                    array = new BigDecimal[oraclePlsqlIndexTable.length];
                    break;
                }
                default: {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Invalid column type");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            for (int i = 0; i < array.length; ++i) {
                array[i] = (Serializable)((oraclePlsqlIndexTable[i] != null && oraclePlsqlIndexTable[i].getLength() != 0L) ? oraclePlsqlIndexTable[i].toJdbc() : null);
            }
            return array;
        }
    }
    
    @Override
    public Object getPlsqlIndexTable(final int n, final Class clazz) throws SQLException {
        synchronized (this.connection) {
            final Datum[] oraclePlsqlIndexTable = this.getOraclePlsqlIndexTable(n);
            if (clazz == null || !clazz.isPrimitive()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final String name = clazz.getName();
            if (name.equals("byte")) {
                final byte[] array = new byte[oraclePlsqlIndexTable.length];
                for (int i = 0; i < oraclePlsqlIndexTable.length; ++i) {
                    array[i] = (byte)((oraclePlsqlIndexTable[i] != null) ? oraclePlsqlIndexTable[i].byteValue() : 0);
                }
                return array;
            }
            if (name.equals("char")) {
                final char[] array2 = new char[oraclePlsqlIndexTable.length];
                for (int j = 0; j < oraclePlsqlIndexTable.length; ++j) {
                    array2[j] = ((oraclePlsqlIndexTable[j] != null && oraclePlsqlIndexTable[j].getLength() != 0L) ? ((char)oraclePlsqlIndexTable[j].intValue()) : '\0');
                }
                return array2;
            }
            if (name.equals("double")) {
                final double[] array3 = new double[oraclePlsqlIndexTable.length];
                for (int k = 0; k < oraclePlsqlIndexTable.length; ++k) {
                    array3[k] = ((oraclePlsqlIndexTable[k] != null && oraclePlsqlIndexTable[k].getLength() != 0L) ? oraclePlsqlIndexTable[k].doubleValue() : 0.0);
                }
                return array3;
            }
            if (name.equals("float")) {
                final float[] array4 = new float[oraclePlsqlIndexTable.length];
                for (int l = 0; l < oraclePlsqlIndexTable.length; ++l) {
                    array4[l] = ((oraclePlsqlIndexTable[l] != null && oraclePlsqlIndexTable[l].getLength() != 0L) ? oraclePlsqlIndexTable[l].floatValue() : 0.0f);
                }
                return array4;
            }
            if (name.equals("int")) {
                final int[] array5 = new int[oraclePlsqlIndexTable.length];
                for (int n2 = 0; n2 < oraclePlsqlIndexTable.length; ++n2) {
                    array5[n2] = ((oraclePlsqlIndexTable[n2] != null && oraclePlsqlIndexTable[n2].getLength() != 0L) ? oraclePlsqlIndexTable[n2].intValue() : 0);
                }
                return array5;
            }
            if (name.equals("long")) {
                final long[] array6 = new long[oraclePlsqlIndexTable.length];
                for (int n3 = 0; n3 < oraclePlsqlIndexTable.length; ++n3) {
                    array6[n3] = ((oraclePlsqlIndexTable[n3] != null && oraclePlsqlIndexTable[n3].getLength() != 0L) ? oraclePlsqlIndexTable[n3].longValue() : 0L);
                }
                return array6;
            }
            if (name.equals("short")) {
                final short[] array7 = new short[oraclePlsqlIndexTable.length];
                for (int n4 = 0; n4 < oraclePlsqlIndexTable.length; ++n4) {
                    array7[n4] = (short)((oraclePlsqlIndexTable[n4] != null && oraclePlsqlIndexTable[n4].getLength() != 0L) ? ((short)oraclePlsqlIndexTable[n4].intValue()) : 0);
                }
                return array7;
            }
            if (name.equals("boolean")) {
                final boolean[] array8 = new boolean[oraclePlsqlIndexTable.length];
                for (int n5 = 0; n5 < oraclePlsqlIndexTable.length; ++n5) {
                    array8[n5] = (oraclePlsqlIndexTable[n5] != null && oraclePlsqlIndexTable[n5].getLength() != 0L && oraclePlsqlIndexTable[n5].booleanValue());
                }
                return array8;
            }
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public Datum[] getOraclePlsqlIndexTable(final int lastIndex) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.atLeastOneNamedParameter) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            final Accessor accessor;
            if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            this.lastIndex = lastIndex;
            if (this.streamList != null) {
                this.closeUsedStreams(lastIndex);
            }
            return accessor.getOraclePlsqlIndexTable(this.currentRank);
        }
    }
    
    @Override
    public boolean execute() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters)) {
                this.needToParse = true;
            }
            return super.execute();
        }
    }
    
    @Override
    public int executeUpdate() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters)) {
                this.needToParse = true;
            }
            return super.executeUpdate();
        }
    }
    
    @Override
    void releaseBuffers() {
        if (this.outBindAccessors != null) {
            for (int length = this.outBindAccessors.length, i = 0; i < length; ++i) {
                if (this.outBindAccessors[i] != null) {
                    this.outBindAccessors[i].rowSpaceByte = null;
                    this.outBindAccessors[i].rowSpaceChar = null;
                }
            }
        }
        super.releaseBuffers();
    }
    
    @Override
    void doLocalInitialization() {
        if (this.outBindAccessors != null) {
            for (int length = this.outBindAccessors.length, i = 0; i < length; ++i) {
                if (this.outBindAccessors[i] != null) {
                    this.outBindAccessors[i].rowSpaceByte = this.bindBytes;
                    this.outBindAccessors[i].rowSpaceChar = this.bindChars;
                }
            }
        }
    }
    
    @Override
    public void setArray(final int n, final Array array) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setArrayInternal(n, array);
    }
    
    @Override
    public void setBigDecimal(final int n, final BigDecimal bigDecimal) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBigDecimalInternal(n, bigDecimal);
        }
    }
    
    @Override
    public void setBlob(final int n, final Blob blob) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBlobInternal(n, blob);
        }
    }
    
    @Override
    public void setBoolean(final int n, final boolean b) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBooleanInternal(n, b);
        }
    }
    
    @Override
    public void setByte(final int n, final byte b) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setByteInternal(n, b);
        }
    }
    
    @Override
    public void setBytes(final int n, final byte[] array) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBytesInternal(n, array);
        }
    }
    
    @Override
    public void setClob(final int n, final Clob clob) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setClobInternal(n, clob);
        }
    }
    
    @Override
    public void setDate(final int n, final Date date) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setDateInternal(n, date);
        }
    }
    
    @Override
    public void setDate(final int n, final Date date, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setDateInternal(n, date, calendar);
        }
    }
    
    @Override
    public void setDouble(final int n, final double n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setDoubleInternal(n, n2);
        }
    }
    
    @Override
    public void setFloat(final int n, final float n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setFloatInternal(n, n2);
        }
    }
    
    @Override
    public void setInt(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setIntInternal(n, n2);
        }
    }
    
    @Override
    public void setLong(final int n, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setLongInternal(n, n2);
        }
    }
    
    @Override
    public void setNClob(final int n, final NClob nClob) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNClobInternal(n, nClob);
        }
    }
    
    @Override
    public void setNString(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNStringInternal(n, s);
        }
    }
    
    @Override
    public void setObject(final int n, final Object o) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setObjectInternal(n, o);
    }
    
    @Override
    public void setObject(final int n, final Object o, final int n2) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setObjectInternal(n, o, n2);
    }
    
    @Override
    public void setRef(final int n, final Ref ref) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setRefInternal(n, ref);
    }
    
    @Override
    public void setRowId(final int n, final RowId rowId) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setRowIdInternal(n, rowId);
        }
    }
    
    @Override
    public void setShort(final int n, final short n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setShortInternal(n, n2);
        }
    }
    
    @Override
    public void setSQLXML(final int n, final SQLXML sqlxml) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setSQLXMLInternal(n, sqlxml);
        }
    }
    
    @Override
    public void setString(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setStringInternal(n, s);
        }
    }
    
    @Override
    public void setTime(final int n, final Time time) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTimeInternal(n, time);
        }
    }
    
    @Override
    public void setTime(final int n, final Time time, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTimeInternal(n, time, calendar);
        }
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTimestampInternal(n, timestamp);
        }
    }
    
    @Override
    public void setTimestamp(final int n, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTimestampInternal(n, timestamp, calendar);
        }
    }
    
    @Override
    public void setURL(final int n, final URL url) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setURLInternal(n, url);
        }
    }
    
    @Override
    public void setARRAY(final int n, final ARRAY array) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setARRAYInternal(n, array);
    }
    
    @Override
    public void setBFILE(final int n, final BFILE bfile) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBFILEInternal(n, bfile);
        }
    }
    
    @Override
    public void setBfile(final int n, final BFILE bfile) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBfileInternal(n, bfile);
        }
    }
    
    @Override
    public void setBinaryFloat(final int n, final float n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryFloatInternal(n, n2);
        }
    }
    
    @Override
    public void setBinaryFloat(final int n, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryFloatInternal(n, binary_FLOAT);
        }
    }
    
    @Override
    public void setBinaryDouble(final int n, final double n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryDoubleInternal(n, n2);
        }
    }
    
    @Override
    public void setBinaryDouble(final int n, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryDoubleInternal(n, binary_DOUBLE);
        }
    }
    
    @Override
    public void setBLOB(final int n, final BLOB blob) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBLOBInternal(n, blob);
        }
    }
    
    @Override
    public void setCHAR(final int n, final CHAR char1) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setCHARInternal(n, char1);
        }
    }
    
    @Override
    public void setCLOB(final int n, final CLOB clob) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setCLOBInternal(n, clob);
        }
    }
    
    @Override
    public void setCursor(final int n, final ResultSet set) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setCursorInternal(n, set);
        }
    }
    
    @Override
    public void setCustomDatum(final int n, final CustomDatum customDatum) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setCustomDatumInternal(n, customDatum);
    }
    
    @Override
    public void setDATE(final int n, final DATE date) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setDATEInternal(n, date);
        }
    }
    
    @Override
    public void setFixedCHAR(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setFixedCHARInternal(n, s);
        }
    }
    
    @Override
    public void setINTERVALDS(final int n, final INTERVALDS intervalds) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setINTERVALDSInternal(n, intervalds);
        }
    }
    
    @Override
    public void setINTERVALYM(final int n, final INTERVALYM intervalym) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setINTERVALYMInternal(n, intervalym);
        }
    }
    
    @Override
    public void setNUMBER(final int n, final NUMBER number) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNUMBERInternal(n, number);
        }
    }
    
    @Override
    public void setOPAQUE(final int n, final OPAQUE opaque) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setOPAQUEInternal(n, opaque);
    }
    
    @Override
    public void setOracleObject(final int n, final Datum datum) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setOracleObjectInternal(n, datum);
    }
    
    @Override
    public void setORAData(final int n, final ORAData oraData) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setORADataInternal(n, oraData);
    }
    
    @Override
    public void setRAW(final int n, final RAW raw) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setRAWInternal(n, raw);
        }
    }
    
    @Override
    public void setREF(final int n, final REF ref) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setREFInternal(n, ref);
    }
    
    @Override
    public void setRefType(final int n, final REF ref) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setRefTypeInternal(n, ref);
    }
    
    @Override
    public void setROWID(final int n, final ROWID rowid) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setROWIDInternal(n, rowid);
        }
    }
    
    @Override
    public void setSTRUCT(final int n, final STRUCT struct) throws SQLException {
        this.atLeastOneOrdinalParameter = true;
        this.setSTRUCTInternal(n, struct);
    }
    
    @Override
    public void setTIMESTAMPLTZ(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTIMESTAMPLTZInternal(n, timestampltz);
        }
    }
    
    @Override
    public void setTIMESTAMPTZ(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTIMESTAMPTZInternal(n, timestamptz);
        }
    }
    
    @Override
    public void setTIMESTAMP(final int n, final TIMESTAMP timestamp) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setTIMESTAMPInternal(n, timestamp);
        }
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBlobInternal(n, inputStream);
        }
    }
    
    @Override
    public void setBlob(final int n, final InputStream inputStream, final long n2) throws SQLException {
        synchronized (this.connection) {
            if (n2 < 0L) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.atLeastOneOrdinalParameter = true;
            this.setBlobInternal(n, inputStream, n2);
        }
    }
    
    @Override
    public void setClob(final int n, final Reader reader) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setClobInternal(n, reader);
        }
    }
    
    @Override
    public void setClob(final int n, final Reader reader, final long n2) throws SQLException {
        synchronized (this.connection) {
            if (n2 < 0L) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.atLeastOneOrdinalParameter = true;
            this.setClobInternal(n, reader, n2);
        }
    }
    
    @Override
    public void setNClob(final int n, final Reader reader) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNClobInternal(n, reader);
        }
    }
    
    @Override
    public void setNClob(final int n, final Reader reader, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNClobInternal(n, reader, n2);
        }
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setAsciiStreamInternal(n, inputStream);
        }
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setAsciiStreamInternal(n, inputStream, n2);
        }
    }
    
    @Override
    public void setAsciiStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setAsciiStreamInternal(n, inputStream, n2);
        }
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryStreamInternal(n, inputStream);
        }
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryStreamInternal(n, inputStream, n2);
        }
    }
    
    @Override
    public void setBinaryStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setBinaryStreamInternal(n, inputStream, n2);
        }
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setCharacterStreamInternal(n, reader);
        }
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setCharacterStreamInternal(n, reader, n2);
        }
    }
    
    @Override
    public void setCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setCharacterStreamInternal(n, reader, n2);
        }
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNCharacterStreamInternal(n, reader);
        }
    }
    
    @Override
    public void setNCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setNCharacterStreamInternal(n, reader, n2);
        }
    }
    
    @Override
    public void setUnicodeStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setUnicodeStreamInternal(n, inputStream, n2);
        }
    }
    
    @Override
    public void setArray(final String s, final Array array) throws SQLException {
        this.setArrayInternal(this.addNamedPara(s), array);
    }
    
    @Override
    public void setBigDecimal(final String s, final BigDecimal bigDecimal) throws SQLException {
        this.setBigDecimalInternal(this.addNamedPara(s), bigDecimal);
    }
    
    @Override
    public void setBlob(final String s, final Blob blob) throws SQLException {
        this.setBlobInternal(this.addNamedPara(s), blob);
    }
    
    @Override
    public void setBoolean(final String s, final boolean b) throws SQLException {
        this.setBooleanInternal(this.addNamedPara(s), b);
    }
    
    @Override
    public void setByte(final String s, final byte b) throws SQLException {
        this.setByteInternal(this.addNamedPara(s), b);
    }
    
    @Override
    public void setBytes(final String s, final byte[] array) throws SQLException {
        this.setBytesInternal(this.addNamedPara(s), array);
    }
    
    @Override
    public void setClob(final String s, final Clob clob) throws SQLException {
        this.setClobInternal(this.addNamedPara(s), clob);
    }
    
    @Override
    public void setDate(final String s, final Date date) throws SQLException {
        this.setDateInternal(this.addNamedPara(s), date);
    }
    
    @Override
    public void setDate(final String s, final Date date, final Calendar calendar) throws SQLException {
        this.setDateInternal(this.addNamedPara(s), date, calendar);
    }
    
    @Override
    public void setDouble(final String s, final double n) throws SQLException {
        this.setDoubleInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setFloat(final String s, final float n) throws SQLException {
        this.setFloatInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setInt(final String s, final int n) throws SQLException {
        this.setIntInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setLong(final String s, final long n) throws SQLException {
        this.setLongInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setNClob(final String s, final NClob nClob) throws SQLException {
        this.setNClobInternal(this.addNamedPara(s), nClob);
    }
    
    @Override
    public void setNString(final String s, final String s2) throws SQLException {
        this.setNStringInternal(this.addNamedPara(s), s2);
    }
    
    @Override
    public void setObject(final String s, final Object o) throws SQLException {
        this.setObjectInternal(this.addNamedPara(s), o);
    }
    
    @Override
    public void setObject(final String s, final Object o, final int n) throws SQLException {
        this.setObjectInternal(this.addNamedPara(s), o, n);
    }
    
    @Override
    public void setRef(final String s, final Ref ref) throws SQLException {
        this.setRefInternal(this.addNamedPara(s), ref);
    }
    
    @Override
    public void setRowId(final String s, final RowId rowId) throws SQLException {
        this.setRowIdInternal(this.addNamedPara(s), rowId);
    }
    
    @Override
    public void setShort(final String s, final short n) throws SQLException {
        this.setShortInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setSQLXML(final String s, final SQLXML sqlxml) throws SQLException {
        this.setSQLXMLInternal(this.addNamedPara(s), sqlxml);
    }
    
    @Override
    public void setString(final String s, final String s2) throws SQLException {
        this.setStringInternal(this.addNamedPara(s), s2);
    }
    
    @Override
    public void setTime(final String s, final Time time) throws SQLException {
        this.setTimeInternal(this.addNamedPara(s), time);
    }
    
    @Override
    public void setTime(final String s, final Time time, final Calendar calendar) throws SQLException {
        this.setTimeInternal(this.addNamedPara(s), time, calendar);
    }
    
    @Override
    public void setTimestamp(final String s, final Timestamp timestamp) throws SQLException {
        this.setTimestampInternal(this.addNamedPara(s), timestamp);
    }
    
    @Override
    public void setTimestamp(final String s, final Timestamp timestamp, final Calendar calendar) throws SQLException {
        this.setTimestampInternal(this.addNamedPara(s), timestamp, calendar);
    }
    
    @Override
    public void setURL(final String s, final URL url) throws SQLException {
        this.setURLInternal(this.addNamedPara(s), url);
    }
    
    @Override
    public void setARRAY(final String s, final ARRAY array) throws SQLException {
        this.setARRAYInternal(this.addNamedPara(s), array);
    }
    
    @Override
    public void setBFILE(final String s, final BFILE bfile) throws SQLException {
        this.setBFILEInternal(this.addNamedPara(s), bfile);
    }
    
    @Override
    public void setBfile(final String s, final BFILE bfile) throws SQLException {
        this.setBfileInternal(this.addNamedPara(s), bfile);
    }
    
    @Override
    public void setBinaryFloat(final String s, final float n) throws SQLException {
        this.setBinaryFloatInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setBinaryFloat(final String s, final BINARY_FLOAT binary_FLOAT) throws SQLException {
        this.setBinaryFloatInternal(this.addNamedPara(s), binary_FLOAT);
    }
    
    @Override
    public void setBinaryDouble(final String s, final double n) throws SQLException {
        this.setBinaryDoubleInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setBinaryDouble(final String s, final BINARY_DOUBLE binary_DOUBLE) throws SQLException {
        this.setBinaryDoubleInternal(this.addNamedPara(s), binary_DOUBLE);
    }
    
    @Override
    public void setBLOB(final String s, final BLOB blob) throws SQLException {
        this.setBLOBInternal(this.addNamedPara(s), blob);
    }
    
    @Override
    public void setCHAR(final String s, final CHAR char1) throws SQLException {
        this.setCHARInternal(this.addNamedPara(s), char1);
    }
    
    @Override
    public void setCLOB(final String s, final CLOB clob) throws SQLException {
        this.setCLOBInternal(this.addNamedPara(s), clob);
    }
    
    @Override
    public void setCursor(final String s, final ResultSet set) throws SQLException {
        this.setCursorInternal(this.addNamedPara(s), set);
    }
    
    @Override
    public void setCustomDatum(final String s, final CustomDatum customDatum) throws SQLException {
        this.setCustomDatumInternal(this.addNamedPara(s), customDatum);
    }
    
    @Override
    public void setDATE(final String s, final DATE date) throws SQLException {
        this.setDATEInternal(this.addNamedPara(s), date);
    }
    
    @Override
    public void setFixedCHAR(final String s, final String s2) throws SQLException {
        this.setFixedCHARInternal(this.addNamedPara(s), s2);
    }
    
    @Override
    public void setINTERVALDS(final String s, final INTERVALDS intervalds) throws SQLException {
        this.setINTERVALDSInternal(this.addNamedPara(s), intervalds);
    }
    
    @Override
    public void setINTERVALYM(final String s, final INTERVALYM intervalym) throws SQLException {
        this.setINTERVALYMInternal(this.addNamedPara(s), intervalym);
    }
    
    @Override
    public void setNUMBER(final String s, final NUMBER number) throws SQLException {
        this.setNUMBERInternal(this.addNamedPara(s), number);
    }
    
    @Override
    public void setOPAQUE(final String s, final OPAQUE opaque) throws SQLException {
        this.setOPAQUEInternal(this.addNamedPara(s), opaque);
    }
    
    @Override
    public void setOracleObject(final String s, final Datum datum) throws SQLException {
        this.setOracleObjectInternal(this.addNamedPara(s), datum);
    }
    
    @Override
    public void setORAData(final String s, final ORAData oraData) throws SQLException {
        this.setORADataInternal(this.addNamedPara(s), oraData);
    }
    
    @Override
    public void setRAW(final String s, final RAW raw) throws SQLException {
        this.setRAWInternal(this.addNamedPara(s), raw);
    }
    
    @Override
    public void setREF(final String s, final REF ref) throws SQLException {
        this.setREFInternal(this.addNamedPara(s), ref);
    }
    
    @Override
    public void setRefType(final String s, final REF ref) throws SQLException {
        this.setRefTypeInternal(this.addNamedPara(s), ref);
    }
    
    @Override
    public void setROWID(final String s, final ROWID rowid) throws SQLException {
        this.setROWIDInternal(this.addNamedPara(s), rowid);
    }
    
    @Override
    public void setSTRUCT(final String s, final STRUCT struct) throws SQLException {
        this.setSTRUCTInternal(this.addNamedPara(s), struct);
    }
    
    @Override
    public void setTIMESTAMPLTZ(final String s, final TIMESTAMPLTZ timestampltz) throws SQLException {
        this.setTIMESTAMPLTZInternal(this.addNamedPara(s), timestampltz);
    }
    
    @Override
    public void setTIMESTAMPTZ(final String s, final TIMESTAMPTZ timestamptz) throws SQLException {
        this.setTIMESTAMPTZInternal(this.addNamedPara(s), timestamptz);
    }
    
    @Override
    public void setTIMESTAMP(final String s, final TIMESTAMP timestamp) throws SQLException {
        this.setTIMESTAMPInternal(this.addNamedPara(s), timestamp);
    }
    
    @Override
    public void setBlob(final String s, final InputStream inputStream) throws SQLException {
        this.setBlobInternal(this.addNamedPara(s), inputStream);
    }
    
    @Override
    public void setBlob(final String s, final InputStream inputStream, final long n) throws SQLException {
        if (n < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.setBlobInternal(this.addNamedPara(s), inputStream, n);
    }
    
    @Override
    public void setClob(final String s, final Reader reader) throws SQLException {
        this.setClobInternal(this.addNamedPara(s), reader);
    }
    
    @Override
    public void setClob(final String s, final Reader reader, final long n) throws SQLException {
        if (n < 0L) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.setClobInternal(this.addNamedPara(s), reader, n);
    }
    
    @Override
    public void setNClob(final String s, final Reader reader) throws SQLException {
        this.setNClobInternal(this.addNamedPara(s), reader);
    }
    
    @Override
    public void setNClob(final String s, final Reader reader, final long n) throws SQLException {
        this.setNClobInternal(this.addNamedPara(s), reader, n);
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream) throws SQLException {
        this.setAsciiStreamInternal(this.addNamedPara(s), inputStream);
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.setAsciiStreamInternal(this.addNamedPara(s), inputStream, n);
    }
    
    @Override
    public void setAsciiStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.setAsciiStreamInternal(this.addNamedPara(s), inputStream, n);
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream) throws SQLException {
        this.setBinaryStreamInternal(this.addNamedPara(s), inputStream);
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.setBinaryStreamInternal(this.addNamedPara(s), inputStream, n);
    }
    
    @Override
    public void setBinaryStream(final String s, final InputStream inputStream, final long n) throws SQLException {
        this.setBinaryStreamInternal(this.addNamedPara(s), inputStream, n);
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader) throws SQLException {
        this.setCharacterStreamInternal(this.addNamedPara(s), reader);
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader, final int n) throws SQLException {
        this.setCharacterStreamInternal(this.addNamedPara(s), reader, n);
    }
    
    @Override
    public void setCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        this.setCharacterStreamInternal(this.addNamedPara(s), reader, n);
    }
    
    @Override
    public void setNCharacterStream(final String s, final Reader reader) throws SQLException {
        this.setNCharacterStreamInternal(this.addNamedPara(s), reader);
    }
    
    @Override
    public void setNCharacterStream(final String s, final Reader reader, final long n) throws SQLException {
        this.setNCharacterStreamInternal(this.addNamedPara(s), reader, n);
    }
    
    @Override
    public void setUnicodeStream(final String s, final InputStream inputStream, final int n) throws SQLException {
        this.setUnicodeStreamInternal(this.addNamedPara(s), inputStream, n);
    }
    
    @Override
    public void setNull(final String s, final int n, final String s2) throws SQLException {
        this.setNullInternal(this.addNamedPara(s), n, s2);
    }
    
    @Override
    public void setNull(final String s, final int n) throws SQLException {
        this.setNullInternal(this.addNamedPara(s), n);
    }
    
    @Override
    public void setStructDescriptor(final String s, final StructDescriptor structDescriptor) throws SQLException {
        this.setStructDescriptorInternal(this.addNamedPara(s), structDescriptor);
    }
    
    @Override
    public void setObject(final String s, final Object o, final int n, final int n2) throws SQLException {
        this.setObjectInternal(this.addNamedPara(s), o, n, n2);
    }
    
    @Override
    public void setPlsqlIndexTable(final int n, final Object o, final int n2, final int n3, final int n4, final int n5) throws SQLException {
        synchronized (this.connection) {
            this.atLeastOneOrdinalParameter = true;
            this.setPlsqlIndexTableInternal(n, o, n2, n3, n4, n5);
        }
    }
    
    int addNamedPara(final String s) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final String intern = s.toUpperCase().intern();
        for (int i = 0; i < this.parameterCount; ++i) {
            if (intern == this.namedParameters[i]) {
                return i + 1;
            }
        }
        if (this.parameterCount >= this.namedParameters.length) {
            final String[] namedParameters = new String[this.namedParameters.length * 2];
            System.arraycopy(this.namedParameters, 0, namedParameters, 0, this.namedParameters.length);
            this.namedParameters = namedParameters;
        }
        this.namedParameters[this.parameterCount++] = intern;
        this.atLeastOneNamedParameter = true;
        return this.parameterCount;
    }
    
    @Override
    public Reader getCharacterStream(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getCharacterStream(this.currentRank);
    }
    
    @Override
    public InputStream getUnicodeStream(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getUnicodeStream(this.currentRank);
    }
    
    @Override
    public InputStream getBinaryStream(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getBinaryStream(this.currentRank);
    }
    
    @Override
    public RowId getRowId(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getROWID(this.currentRank);
    }
    
    @Override
    public RowId getRowId(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getROWID(this.currentRank);
    }
    
    @Override
    public NClob getNClob(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNClob(this.currentRank);
    }
    
    @Override
    public NClob getNClob(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNClob(this.currentRank);
    }
    
    @Override
    public SQLXML getSQLXML(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getSQLXML(this.currentRank);
    }
    
    @Override
    public SQLXML getSQLXML(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getSQLXML(this.currentRank);
    }
    
    @Override
    public String getNString(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNString(this.currentRank);
    }
    
    @Override
    public String getNString(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNString(this.currentRank);
    }
    
    @Override
    public Reader getNCharacterStream(final int lastIndex) throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.atLeastOneNamedParameter) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNCharacterStream(this.currentRank);
    }
    
    @Override
    public Reader getNCharacterStream(final String s) throws SQLException {
        if (!this.atLeastOneNamedParameter) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String intern;
        int lastIndex;
        for (intern = s.toUpperCase().intern(), lastIndex = 0; lastIndex < this.parameterCount && intern != this.namedParameters[lastIndex]; ++lastIndex) {}
        ++lastIndex;
        final Accessor accessor;
        if (lastIndex <= 0 || lastIndex > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[lastIndex - 1]) == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.lastIndex = lastIndex;
        if (this.streamList != null) {
            this.closeUsedStreams(lastIndex);
        }
        return accessor.getNCharacterStream(this.currentRank);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
