// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Calendar;
import oracle.jdbc.internal.OracleConnection;
import java.util.TimeZone;

abstract class DateCommonBinder extends Binder
{
    static final int GREGORIAN_CUTOVER_YEAR = 1582;
    static final long GREGORIAN_CUTOVER = -12219292800000L;
    static final int JAN_1_1_JULIAN_DAY = 1721426;
    static final int EPOCH_JULIAN_DAY = 2440588;
    static final int ONE_SECOND = 1000;
    static final int ONE_MINUTE = 60000;
    static final int ONE_HOUR = 3600000;
    static final long ONE_DAY = 86400000L;
    static final int[] NUM_DAYS;
    static final int[] LEAP_NUM_DAYS;
    static final int[] MONTH_LENGTH;
    static final int[] LEAP_MONTH_LENGTH;
    static final int ORACLE_DATE_CENTURY = 0;
    static final int ORACLE_DATE_YEAR = 1;
    static final int ORACLE_DATE_MONTH = 2;
    static final int ORACLE_DATE_DAY = 3;
    static final int ORACLE_DATE_HOUR = 4;
    static final int ORACLE_DATE_MIN = 5;
    static final int ORACLE_DATE_SEC = 6;
    static final int ORACLE_DATE_NANO1 = 7;
    static final int ORACLE_DATE_NANO2 = 8;
    static final int ORACLE_DATE_NANO3 = 9;
    static final int ORACLE_DATE_NANO4 = 10;
    private static int HOUR_MILLISECOND;
    private static int MINUTE_MILLISECOND;
    private static int SECOND_MILLISECOND;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static final long floorDivide(final long n, final long n2) {
        return (n >= 0L) ? (n / n2) : ((n + 1L) / n2 - 1L);
    }
    
    static final int floorDivide(final int n, final int n2) {
        return (n >= 0) ? (n / n2) : ((n + 1) / n2 - 1);
    }
    
    static final int floorDivide(final int n, final int n2, final int[] array) {
        if (n >= 0) {
            array[0] = n % n2;
            return n / n2;
        }
        final int n3 = (n + 1) / n2 - 1;
        array[0] = n - n3 * n2;
        return n3;
    }
    
    static final int floorDivide(final long n, final int n2, final int[] array) {
        if (n >= 0L) {
            array[0] = (int)(n % n2);
            return (int)(n / n2);
        }
        final int n3 = (int)((n + 1L) / n2 - 1L);
        array[0] = (int)(n - n3 * n2);
        return n3;
    }
    
    static final long zoneOffset(final TimeZone timeZone, final int n, final int n2, final int n3, final int n4, final int n5) {
        return timeZone.getOffset((n >= 0) ? 1 : 0, n, n2, n3, n4, n5);
    }
    
    static void setOracleNanos(final long n, final byte[] array, final int n2) {
        array[10 + n2] = (byte)(n & 0xFFL);
        array[9 + n2] = (byte)(n >> 8 & 0xFFL);
        array[8 + n2] = (byte)(n >> 16 & 0xFFL);
        array[7 + n2] = (byte)(n >> 24 & 0xFFL);
    }
    
    static void setOracleHMS(int n, final byte[] array, final int n2) {
        if (n < 0) {
            throw new RuntimeException("Assertion botch: negative time");
        }
        n /= 1000;
        array[6 + n2] = (byte)(n % 60 + 1);
        n /= 60;
        array[5 + n2] = (byte)(n % 60 + 1);
        n /= 60;
        array[4 + n2] = (byte)(n + 1);
    }
    
    static final int setOracleCYMD(final long n, final byte[] array, final int n2, final OraclePreparedStatement oraclePreparedStatement) throws SQLException {
        final TimeZone defaultTimeZone = oraclePreparedStatement.getDefaultTimeZone(true);
        final String defaultTimeZoneName = oraclePreparedStatement.defaultTimeZoneName;
        final Calendar cachedUTCUSCalendar = oraclePreparedStatement.cachedUTCUSCalendar;
        cachedUTCUSCalendar.setTimeInMillis(n);
        final Calendar defaultCalendar = oraclePreparedStatement.getDefaultCalendar();
        defaultCalendar.setTimeInMillis(n);
        int value = defaultCalendar.get(15);
        if (defaultTimeZone.inDaylightTime(cachedUTCUSCalendar.getTime())) {
            value -= defaultCalendar.get(16);
        }
        final long n3 = n + value;
        int n8;
        int n9;
        boolean b;
        int n10;
        if (n3 >= -12219292800000L) {
            final long n4 = 2440588L + floorDivide(n3, 86400000L) - 1721426L;
            int floorDivide;
            int floorDivide2;
            int floorDivide3;
            int floorDivide4;
            if (n4 > 0L) {
                floorDivide = (int)(n4 / 146097L);
                final int n5 = (int)(n4 % 146097L);
                floorDivide2 = n5 / 36524;
                final int n6 = n5 % 36524;
                floorDivide3 = n6 / 1461;
                final int n7 = n6 % 1461;
                floorDivide4 = n7 / 365;
                n8 = n7 % 365;
            }
            else {
                final int[] array2 = { 0 };
                floorDivide = floorDivide(n4, 146097, array2);
                floorDivide2 = floorDivide(array2[0], 36524, array2);
                floorDivide3 = floorDivide(array2[0], 1461, array2);
                floorDivide4 = floorDivide(array2[0], 365, array2);
                n8 = array2[0];
            }
            n9 = 400 * floorDivide + 100 * floorDivide2 + 4 * floorDivide3 + floorDivide4;
            if (floorDivide2 == 4 || floorDivide4 == 4) {
                n8 = 365;
            }
            else {
                ++n9;
            }
            b = ((n9 & 0x3) == 0x0 && (n9 % 100 != 0 || n9 % 400 == 0));
            n10 = (int)((n4 + 1L) % 7L);
        }
        else {
            final long n11 = 2440588L + floorDivide(n3, 86400000L) - 1721424L;
            n9 = (int)floorDivide(4L * n11 + 1464L, 1461L);
            n8 = (int)(n11 - (365 * (n9 - 1) + floorDivide(n9 - 1, 4)));
            b = ((n9 & 0x3) == 0x0);
            n10 = (int)((n11 - 1L) % 7L);
        }
        int n12 = 0;
        if (n8 >= (b ? 60 : 59)) {
            n12 = (b ? 1 : 2);
        }
        int n13 = (12 * (n8 + n12) + 6) / 367;
        int n14 = n8 - (b ? DateCommonBinder.LEAP_NUM_DAYS[n13] : DateCommonBinder.NUM_DAYS[n13]) + 1;
        final int n15 = n10 + ((n10 < 0) ? 8 : 1);
        int n16 = (int)(n3 - n3 / 86400000L * 86400000L);
        if (n16 < 0) {
            n16 += (int)86400000L;
        }
        int n17 = (int)(n16 + (zoneOffset(defaultTimeZone, n9, n13, n14, n15, n16) - value));
        if (n17 >= 86400000L) {
            n17 -= (int)86400000L;
            if (++n14 > (b ? DateCommonBinder.LEAP_MONTH_LENGTH[n13] : DateCommonBinder.MONTH_LENGTH[n13])) {
                n14 = 1;
                if (++n13 == 12) {
                    n13 = 0;
                    ++n9;
                }
            }
        }
        if (n9 <= 0) {
            --n9;
        }
        if (n9 > 9999 || n9 < -4712) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 268);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        array[0 + n2] = (byte)(n9 / 100 + 100);
        array[1 + n2] = (byte)(n9 % 100 + 100);
        array[2 + n2] = (byte)(n13 + 1);
        array[3 + n2] = (byte)n14;
        return n17;
    }
    
    static {
        NUM_DAYS = new int[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
        LEAP_NUM_DAYS = new int[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };
        MONTH_LENGTH = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        LEAP_MONTH_LENGTH = new int[] { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        DateCommonBinder.HOUR_MILLISECOND = 3600000;
        DateCommonBinder.MINUTE_MILLISECOND = 60000;
        DateCommonBinder.SECOND_MILLISECOND = 1000;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
