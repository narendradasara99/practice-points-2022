// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;

final class T4CTTIokeyval extends T4CTTIfun
{
    static final byte KVASET_KPDUSR = 1;
    static final byte KVACLA_KPDUSR = 2;
    private byte[] namespaceByteArr;
    private char[] charArr;
    private byte[][] attrArr;
    private int[] attrArrSize;
    private byte[][] valueArr;
    private int[] valueArrSize;
    private byte[] kvalflg;
    private int nbNamespaceBytes;
    private int nbKeyVal;
    private boolean clear;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIokeyval(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)17);
        this.setFunCode((short)154);
        this.namespaceByteArr = new byte[100];
        this.charArr = new char[100];
        this.attrArr = new byte[10][];
        this.attrArrSize = new int[10];
        this.valueArr = new byte[10][];
        this.valueArrSize = new int[10];
        this.kvalflg = new byte[10];
    }
    
    void doOKEYVAL(final Namespace namespace) throws IOException, SQLException {
        final String name = namespace.name;
        final String[] keys = namespace.keys;
        final String[] values = namespace.values;
        this.clear = namespace.clear;
        this.nbKeyVal = namespace.nbPairs;
        final int n = name.length() * this.meg.conv.cMaxCharSize;
        if (n > this.namespaceByteArr.length) {
            this.namespaceByteArr = new byte[n];
        }
        if (name.length() > this.charArr.length) {
            this.charArr = new char[name.length()];
        }
        name.getChars(0, name.length(), this.charArr, 0);
        this.nbNamespaceBytes = this.meg.conv.javaCharsToCHARBytes(this.charArr, 0, this.namespaceByteArr, 0, name.length());
        if (this.nbKeyVal > 0) {
            if (this.nbKeyVal > this.attrArr.length) {
                this.attrArr = new byte[this.nbKeyVal][];
                this.attrArrSize = new int[this.nbKeyVal];
                this.valueArr = new byte[this.nbKeyVal][];
                this.valueArrSize = new int[this.nbKeyVal];
                this.kvalflg = new byte[this.nbKeyVal];
            }
            for (int i = 0; i < this.nbKeyVal; ++i) {
                final String s = keys[i];
                final String s2 = values[i];
                final int n2 = s.length() * this.meg.conv.cMaxCharSize;
                if (this.attrArr[i] == null || this.attrArr[i].length < n2) {
                    this.attrArr[i] = new byte[n2];
                }
                final int n3 = s2.length() * this.meg.conv.cMaxCharSize;
                if (this.valueArr[i] == null || this.valueArr[i].length < n3) {
                    this.valueArr[i] = new byte[n3];
                }
                if (s.length() > this.charArr.length) {
                    this.charArr = new char[s.length()];
                }
                s.getChars(0, s.length(), this.charArr, 0);
                this.attrArrSize[i] = this.meg.conv.javaCharsToCHARBytes(this.charArr, 0, this.attrArr[i], 0, s.length());
                if (s2.length() > this.charArr.length) {
                    this.charArr = new char[s2.length()];
                }
                s2.getChars(0, s2.length(), this.charArr, 0);
                this.valueArrSize[i] = this.meg.conv.javaCharsToCHARBytes(this.charArr, 0, this.valueArr[i], 0, s2.length());
            }
        }
        this.doPigRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalPTR();
        this.meg.marshalUB4(this.nbNamespaceBytes);
        if (this.nbKeyVal > 0) {
            this.meg.marshalPTR();
        }
        else {
            this.meg.marshalNULLPTR();
        }
        this.meg.marshalUB4(this.nbKeyVal);
        int n = 0;
        if (this.nbKeyVal > 0) {
            n = 1;
        }
        if (this.clear) {
            n |= 0x2;
        }
        this.meg.marshalUB2(n);
        this.meg.marshalNULLPTR();
        this.meg.marshalCHR(this.namespaceByteArr, 0, this.nbNamespaceBytes);
        if (this.nbKeyVal > 0) {
            this.meg.marshalKEYVAL(this.attrArr, this.attrArrSize, this.valueArr, this.valueArrSize, this.kvalflg, this.nbKeyVal);
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
