// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CInputStream extends OracleInputStream
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CInputStream(final OracleStatement oracleStatement, final int n, final Accessor accessor) {
        super(oracleStatement, n, accessor);
    }
    
    @Override
    public boolean isNull() throws IOException {
        if (!this.statement.connection.useFetchSizeWithLongColumn) {
            return super.isNull();
        }
        boolean null;
        try {
            int currentRow = this.statement.currentRow;
            if (currentRow < 0) {
                currentRow = 0;
            }
            if (currentRow >= this.statement.validRows) {
                return true;
            }
            null = this.accessor.isNull(currentRow);
        }
        catch (SQLException ex) {
            final IOException ioException = DatabaseError.createIOException(ex);
            ioException.fillInStackTrace();
            throw ioException;
        }
        return null;
    }
    
    @Override
    public int getBytes(final int n) throws IOException {
        synchronized (this.statement.connection) {
            int stream = -1;
            try {
                if (this.statement.connection.lifecycle == 1 || this.statement.connection.lifecycle == 2) {
                    stream = this.accessor.readStream(this.resizableBuffer, this.initialBufferSize);
                }
            }
            catch (SQLException ex) {
                throw new IOException(ex.getMessage());
            }
            catch (IOException ex2) {
                try {
                    ((T4CConnection)this.statement.connection).handleIOException(ex2);
                }
                catch (SQLException ex3) {}
                throw ex2;
            }
            return stream;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
