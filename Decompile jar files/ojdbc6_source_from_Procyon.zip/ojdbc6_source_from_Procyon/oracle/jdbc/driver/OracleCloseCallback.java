// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;

public interface OracleCloseCallback
{
    void beforeClose(final OracleConnection p0, final Object p1);
    
    void afterClose(final Object p0);
}
