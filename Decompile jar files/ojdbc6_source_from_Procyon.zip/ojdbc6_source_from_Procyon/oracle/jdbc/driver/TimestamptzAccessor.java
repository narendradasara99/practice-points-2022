// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Map;
import java.util.TimeZone;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.DATE;
import oracle.sql.Datum;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.util.Calendar;
import oracle.sql.TIMEZONETAB;
import oracle.sql.ZONEIDMAP;
import java.sql.Connection;
import java.sql.SQLException;

class TimestamptzAccessor extends DateTimeCommonAccessor
{
    static final int maxLength = 13;
    TimestampTzConverter tstzConverter;
    static int OFFSET_HOUR;
    static int OFFSET_MINUTE;
    static byte REGIONIDBIT;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    TimestamptzAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.tstzConverter = null;
        this.init(oracleStatement, 181, 181, n2, b);
        this.initForDataAccess(n3, n, null);
        if (this.statement.connection.timestamptzInGmt) {
            this.tstzConverter = new GmtTimestampTzConverter();
        }
        else {
            this.tstzConverter = new OldTimestampTzConverter();
        }
    }
    
    TimestamptzAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.tstzConverter = null;
        this.init(oracleStatement, 181, 181, n7, false);
        this.initForDescribe(181, n, b, n2, n3, n4, n5, n6, n7, null);
        this.initForDataAccess(0, n, null);
        if (this.statement.connection.timestamptzInGmt) {
            this.tstzConverter = new GmtTimestampTzConverter();
        }
        else {
            this.tstzConverter = new OldTimestampTzConverter();
        }
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 13;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength;
    }
    
    @Override
    String getString(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        final int n2 = this.columnIndex + this.byteLength * n;
        int n3 = 0;
        String s;
        if ((this.oracleTZ1(n2) & TimestamptzAccessor.REGIONIDBIT) != 0x0) {
            n3 = getHighOrderbits(this.oracleTZ1(n2)) + getLowOrderbits(this.oracleTZ2(n2));
            final TIMEZONETAB timezonetab = this.statement.connection.getTIMEZONETAB();
            if (timezonetab.checkID(n3)) {
                timezonetab.updateTable(this.statement.connection, n3);
            }
            s = ZONEIDMAP.getRegion(n3);
        }
        else {
            final int a = this.oracleTZ1(n2) - TimestamptzAccessor.OFFSET_HOUR;
            final int i = this.oracleTZ2(n2) - TimestamptzAccessor.OFFSET_MINUTE;
            s = "GMT" + ((a < 0) ? "-" : "+") + Math.abs(a) + ":" + ((i < 10) ? "0" : "") + i;
        }
        final Calendar gmtCalendar = this.statement.getGMTCalendar();
        gmtCalendar.set(1, ((this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + n2] & 0xFF) - 100);
        gmtCalendar.set(2, this.oracleMonth(n2));
        gmtCalendar.set(5, this.oracleDay(n2));
        gmtCalendar.set(11, this.oracleHour(n2));
        gmtCalendar.set(12, this.oracleMin(n2));
        gmtCalendar.set(13, this.oracleSec(n2));
        gmtCalendar.set(14, 0);
        if ((this.oracleTZ1(n2) & TimestamptzAccessor.REGIONIDBIT) != 0x0) {
            gmtCalendar.add(14, this.statement.connection.getTIMEZONETAB().getOffset(gmtCalendar, n3));
        }
        else {
            gmtCalendar.add(10, this.oracleTZ1(n2) - TimestamptzAccessor.OFFSET_HOUR);
            gmtCalendar.add(12, this.oracleTZ2(n2) - TimestamptzAccessor.OFFSET_MINUTE);
        }
        final int value = gmtCalendar.get(1);
        final int n4 = gmtCalendar.get(2) + 1;
        final int value2 = gmtCalendar.get(5);
        final int value3 = gmtCalendar.get(11);
        final int value4 = gmtCalendar.get(12);
        final int value5 = gmtCalendar.get(13);
        final boolean b = value3 < 12;
        if (s.length() > 3 && s.startsWith("GMT")) {
            s = s.substring(3);
        }
        return this.toText(value, n4, value2, value3, value4, value5, this.oracleNanos(n2), b, s);
    }
    
    @Override
    Date getDate(final int n) throws SQLException {
        return this.tstzConverter.getDate(n);
    }
    
    @Override
    Date getDate(final int n, final Calendar calendar) throws SQLException {
        return this.getDate(n);
    }
    
    @Override
    Time getTime(final int n) throws SQLException {
        return this.tstzConverter.getTime(n);
    }
    
    @Override
    Time getTime(final int n, final Calendar calendar) throws SQLException {
        return this.getTime(n);
    }
    
    @Override
    Timestamp getTimestamp(final int n) throws SQLException {
        return this.tstzConverter.getTimestamp(n);
    }
    
    @Override
    Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        return this.getTimestamp(n);
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.tstzConverter.getObject(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.tstzConverter.getOracleObject(n);
    }
    
    @Override
    DATE getDATE(final int n) throws SQLException {
        return oracle.sql.TIMESTAMPTZ.toDATE(this.statement.connection, this.tstzConverter.getTIMESTAMPTZ(n).getBytes());
    }
    
    @Override
    TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        return oracle.sql.TIMESTAMPTZ.toTIMESTAMP(this.statement.connection, this.tstzConverter.getTIMESTAMPTZ(n).getBytes());
    }
    
    @Override
    TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        return this.tstzConverter.getTIMESTAMPTZ(n);
    }
    
    static int setHighOrderbits(final int n) {
        return (n & 0x1FC0) >> 6;
    }
    
    static int setLowOrderbits(final int n) {
        return (n & 0x3F) << 2;
    }
    
    static int getHighOrderbits(final int n) {
        return (n & 0x7F) << 6;
    }
    
    static int getLowOrderbits(final int n) {
        return (n & 0xFC) >> 2;
    }
    
    static {
        TimestamptzAccessor.OFFSET_HOUR = 20;
        TimestamptzAccessor.OFFSET_MINUTE = 60;
        TimestamptzAccessor.REGIONIDBIT = -128;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    class OldTimestampTzConverter extends TimestampTzConverter
    {
        @Override
        Date getDate(final int n) throws SQLException {
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] == -1) {
                return null;
            }
            final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
            final TimeZone defaultTimeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
            final Calendar instance = Calendar.getInstance(defaultTimeZone);
            instance.set(1, ((TimestamptzAccessor.this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[1 + n2] & 0xFF) - 100);
            instance.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            instance.set(5, TimestamptzAccessor.this.oracleDay(n2));
            instance.set(11, TimestamptzAccessor.this.oracleHour(n2));
            instance.set(12, TimestamptzAccessor.this.oracleMin(n2));
            instance.set(13, TimestamptzAccessor.this.oracleSec(n2));
            instance.set(14, 0);
            if ((TimestamptzAccessor.this.oracleTZ1(n2) & TimestamptzAccessor.REGIONIDBIT) != 0x0) {
                final int n3 = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(n2)) + TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(n2));
                final TIMEZONETAB timezonetab = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
                if (timezonetab.checkID(n3)) {
                    timezonetab.updateTable(TimestamptzAccessor.this.statement.connection, n3);
                }
                final int offset = timezonetab.getOffset(instance, n3);
                final boolean inDaylightTime = defaultTimeZone.inDaylightTime(instance.getTime());
                final boolean inDaylightTime2 = defaultTimeZone.inDaylightTime(new java.util.Date(instance.getTimeInMillis() + offset));
                if (!inDaylightTime && inDaylightTime2) {
                    instance.add(14, -1 * defaultTimeZone.getDSTSavings());
                }
                else if (inDaylightTime && !inDaylightTime2) {
                    instance.add(14, defaultTimeZone.getDSTSavings());
                }
                instance.add(10, offset / 3600000);
                instance.add(12, offset % 3600000 / 60000);
            }
            else {
                instance.add(10, TimestamptzAccessor.this.oracleTZ1(n2) - TimestamptzAccessor.OFFSET_HOUR);
                instance.add(12, TimestamptzAccessor.this.oracleTZ2(n2) - TimestamptzAccessor.OFFSET_MINUTE);
            }
            return new Date(instance.getTimeInMillis());
        }
        
        @Override
        Time getTime(final int n) throws SQLException {
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] == -1) {
                return null;
            }
            final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
            final TimeZone defaultTimeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
            final Calendar instance = Calendar.getInstance(defaultTimeZone);
            instance.set(1, ((TimestamptzAccessor.this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[1 + n2] & 0xFF) - 100);
            instance.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            instance.set(5, TimestamptzAccessor.this.oracleDay(n2));
            instance.set(11, TimestamptzAccessor.this.oracleHour(n2));
            instance.set(12, TimestamptzAccessor.this.oracleMin(n2));
            instance.set(13, TimestamptzAccessor.this.oracleSec(n2));
            instance.set(14, 0);
            if ((TimestamptzAccessor.this.oracleTZ1(n2) & TimestamptzAccessor.REGIONIDBIT) != 0x0) {
                final int n3 = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(n2)) + TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(n2));
                final TIMEZONETAB timezonetab = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
                if (timezonetab.checkID(n3)) {
                    timezonetab.updateTable(TimestamptzAccessor.this.statement.connection, n3);
                }
                final int offset = timezonetab.getOffset(instance, n3);
                final boolean inDaylightTime = defaultTimeZone.inDaylightTime(instance.getTime());
                final boolean inDaylightTime2 = defaultTimeZone.inDaylightTime(new java.util.Date(instance.getTimeInMillis() + offset));
                if (!inDaylightTime && inDaylightTime2) {
                    instance.add(14, -1 * defaultTimeZone.getDSTSavings());
                }
                else if (inDaylightTime && !inDaylightTime2) {
                    instance.add(14, defaultTimeZone.getDSTSavings());
                }
                instance.add(10, offset / 3600000);
                instance.add(12, offset % 3600000 / 60000);
            }
            else {
                instance.add(10, TimestamptzAccessor.this.oracleTZ1(n2) - TimestamptzAccessor.OFFSET_HOUR);
                instance.add(12, TimestamptzAccessor.this.oracleTZ2(n2) - TimestamptzAccessor.OFFSET_MINUTE);
            }
            return new Time(instance.getTimeInMillis());
        }
        
        @Override
        Timestamp getTimestamp(final int n) throws SQLException {
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] == -1) {
                return null;
            }
            final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
            final TimeZone defaultTimeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
            final Calendar instance = Calendar.getInstance(defaultTimeZone);
            final Calendar gmtCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
            final int n3 = ((TimestamptzAccessor.this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[1 + n2] & 0xFF) - 100;
            instance.set(1, n3);
            instance.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            instance.set(5, TimestamptzAccessor.this.oracleDay(n2));
            instance.set(11, TimestamptzAccessor.this.oracleHour(n2));
            instance.set(12, TimestamptzAccessor.this.oracleMin(n2));
            instance.set(13, TimestamptzAccessor.this.oracleSec(n2));
            instance.set(14, 0);
            gmtCalendar.set(1, n3);
            gmtCalendar.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            gmtCalendar.set(5, TimestamptzAccessor.this.oracleDay(n2));
            gmtCalendar.set(11, TimestamptzAccessor.this.oracleHour(n2));
            gmtCalendar.set(12, TimestamptzAccessor.this.oracleMin(n2));
            gmtCalendar.set(13, TimestamptzAccessor.this.oracleSec(n2));
            gmtCalendar.set(14, 0);
            if ((TimestamptzAccessor.this.oracleTZ1(n2) & TimestamptzAccessor.REGIONIDBIT) != 0x0) {
                final int n4 = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(n2)) + TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(n2));
                final TIMEZONETAB timezonetab = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
                if (timezonetab.checkID(n4)) {
                    timezonetab.updateTable(TimestamptzAccessor.this.statement.connection, n4);
                }
                final int offset = timezonetab.getOffset(gmtCalendar, n4);
                final boolean inDaylightTime = defaultTimeZone.inDaylightTime(instance.getTime());
                final boolean inDaylightTime2 = defaultTimeZone.inDaylightTime(new java.util.Date(instance.getTimeInMillis() + offset));
                if (!inDaylightTime && inDaylightTime2) {
                    instance.add(14, -1 * defaultTimeZone.getDSTSavings());
                }
                else if (inDaylightTime && !inDaylightTime2) {
                    instance.add(14, defaultTimeZone.getDSTSavings());
                }
                instance.add(10, offset / 3600000);
                instance.add(12, offset % 3600000 / 60000);
            }
            else {
                instance.add(10, TimestamptzAccessor.this.oracleTZ1(n2) - TimestamptzAccessor.OFFSET_HOUR);
                instance.add(12, TimestamptzAccessor.this.oracleTZ2(n2) - TimestamptzAccessor.OFFSET_MINUTE);
            }
            final Timestamp timestamp = new Timestamp(instance.getTimeInMillis());
            timestamp.setNanos(TimestamptzAccessor.this.oracleNanos(n2));
            return timestamp;
        }
        
        @Override
        TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
            TIMESTAMPTZ timestamptz = null;
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] != -1) {
                final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
                final byte[] array = new byte[13];
                System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, n2, array, 0, 13);
                timestamptz = new TIMESTAMPTZ(array);
            }
            return timestamptz;
        }
    }
    
    class GmtTimestampTzConverter extends TimestampTzConverter
    {
        @Override
        Date getDate(final int n) throws SQLException {
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] == -1) {
                return null;
            }
            final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
            final Calendar gmtCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
            gmtCalendar.set(1, ((TimestamptzAccessor.this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[1 + n2] & 0xFF) - 100);
            gmtCalendar.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            gmtCalendar.set(5, TimestamptzAccessor.this.oracleDay(n2));
            gmtCalendar.set(11, TimestamptzAccessor.this.oracleHour(n2));
            gmtCalendar.set(12, TimestamptzAccessor.this.oracleMin(n2));
            gmtCalendar.set(13, TimestamptzAccessor.this.oracleSec(n2));
            gmtCalendar.set(14, 0);
            return new Date(gmtCalendar.getTimeInMillis());
        }
        
        @Override
        Time getTime(final int n) throws SQLException {
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] == -1) {
                return null;
            }
            final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
            final Calendar gmtCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
            gmtCalendar.set(1, ((TimestamptzAccessor.this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[1 + n2] & 0xFF) - 100);
            gmtCalendar.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            gmtCalendar.set(5, TimestamptzAccessor.this.oracleDay(n2));
            gmtCalendar.set(11, TimestamptzAccessor.this.oracleHour(n2));
            gmtCalendar.set(12, TimestamptzAccessor.this.oracleMin(n2));
            gmtCalendar.set(13, TimestamptzAccessor.this.oracleSec(n2));
            gmtCalendar.set(14, 0);
            return new Time(gmtCalendar.getTimeInMillis());
        }
        
        @Override
        Timestamp getTimestamp(final int n) throws SQLException {
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] == -1) {
                return null;
            }
            final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
            final Calendar gmtCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
            gmtCalendar.set(1, ((TimestamptzAccessor.this.rowSpaceByte[0 + n2] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[1 + n2] & 0xFF) - 100);
            gmtCalendar.set(2, TimestamptzAccessor.this.oracleMonth(n2));
            gmtCalendar.set(5, TimestamptzAccessor.this.oracleDay(n2));
            gmtCalendar.set(11, TimestamptzAccessor.this.oracleHour(n2));
            gmtCalendar.set(12, TimestamptzAccessor.this.oracleMin(n2));
            gmtCalendar.set(13, TimestamptzAccessor.this.oracleSec(n2));
            gmtCalendar.set(14, 0);
            final Timestamp timestamp = new Timestamp(gmtCalendar.getTimeInMillis());
            timestamp.setNanos(TimestamptzAccessor.this.oracleNanos(n2));
            return timestamp;
        }
        
        @Override
        TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
            TIMESTAMPTZ timestamptz = null;
            if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + n] != -1) {
                final int n2 = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * n;
                final byte[] array = new byte[13];
                System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, n2, array, 0, 13);
                timestamptz = new TIMESTAMPTZ(array);
            }
            return timestamptz;
        }
    }
    
    abstract class TimestampTzConverter
    {
        abstract Date getDate(final int p0) throws SQLException;
        
        abstract Time getTime(final int p0) throws SQLException;
        
        abstract Timestamp getTimestamp(final int p0) throws SQLException;
        
        Object getObject(final int n) throws SQLException {
            return this.getTIMESTAMPTZ(n);
        }
        
        Datum getOracleObject(final int n) throws SQLException {
            return this.getTIMESTAMPTZ(n);
        }
        
        Object getObject(final int n, final Map map) throws SQLException {
            return this.getTIMESTAMPTZ(n);
        }
        
        abstract TIMESTAMPTZ getTIMESTAMPTZ(final int p0) throws SQLException;
    }
}
