// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class BINARY_FLOATBinder extends DatumBinder
{
    Binder theBINARY_FLOATCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 100;
        binder.bytelen = 4;
    }
    
    BINARY_FLOATBinder() {
        this.theBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theBINARY_FLOATCopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
