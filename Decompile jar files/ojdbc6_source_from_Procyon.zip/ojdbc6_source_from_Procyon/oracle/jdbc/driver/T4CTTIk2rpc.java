// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import java.io.IOException;

final class T4CTTIk2rpc extends T4CTTIfun
{
    static final int K2RPClogon = 1;
    static final int K2RPCbegin = 2;
    static final int K2RPCend = 3;
    static final int K2RPCrecover = 4;
    static final int K2RPCsession = 5;
    private int k2rpctyp;
    private int command;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIk2rpc(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.setFunCode((short)67);
    }
    
    void doOK2RPC(final int k2rpctyp, final int command) throws IOException, SQLException {
        this.k2rpctyp = k2rpctyp;
        this.command = command;
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalUB4(0L);
        this.meg.marshalUB4(this.k2rpctyp);
        this.meg.marshalPTR();
        this.meg.marshalUB4(3L);
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(0L);
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(0L);
        this.meg.marshalPTR();
        this.meg.marshalUB4(3L);
        this.meg.marshalPTR();
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(0L);
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(0L);
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(this.command);
        this.meg.marshalUB4(0L);
        this.meg.marshalUB4(0L);
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        for (int unmarshalUB2 = this.meg.unmarshalUB2(), i = 0; i < unmarshalUB2; ++i) {
            this.meg.unmarshalUB4();
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
