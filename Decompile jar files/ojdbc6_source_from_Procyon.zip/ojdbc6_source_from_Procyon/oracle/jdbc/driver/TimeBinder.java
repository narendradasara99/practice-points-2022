// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Time;

class TimeBinder extends DateCommonBinder
{
    Binder theTimeCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 12;
        binder.bytelen = 7;
    }
    
    TimeBinder() {
        this.theTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theTimeCopyingBinder;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) throws SQLException {
        final Time[] array4 = oraclePreparedStatement.parameterTime[n3];
        final Time time = array4[n];
        if (b) {
            array4[n] = null;
        }
        if (time == null) {
            array3[n9] = -1;
        }
        else {
            array3[n9] = 0;
            DateCommonBinder.setOracleHMS(DateCommonBinder.setOracleCYMD(time.getTime(), array, n6, oraclePreparedStatement), array, n6);
            if (oraclePreparedStatement.connection.use1900AsYearForTime) {
                array[0 + n6] = 119;
                array[1 + n6] = 100;
                array[3 + n6] = (array[2 + n6] = 1);
            }
            array3[n8] = (short)n4;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
