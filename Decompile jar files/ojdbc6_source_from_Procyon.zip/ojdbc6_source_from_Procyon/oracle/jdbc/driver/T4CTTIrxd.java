// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.OracleResultSetMetaData;
import java.util.Vector;
import oracle.jdbc.oracore.OracleTypeADT;
import java.io.InputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.BitSet;

class T4CTTIrxd extends T4CTTIMsg
{
    static final byte[] NO_BYTES;
    byte[] buffer;
    byte[] bufferCHAR;
    BitSet bvcColSent;
    int nbOfColumns;
    boolean bvcFound;
    boolean isFirstCol;
    static final byte TTICMD_UNAUTHORIZED = 1;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIrxd(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)7);
        this.bvcColSent = null;
        this.nbOfColumns = 0;
        this.bvcFound = false;
        this.isFirstCol = true;
    }
    
    void init() {
        this.isFirstCol = true;
    }
    
    void setNumberOfColumns(final int nbOfColumns) {
        this.nbOfColumns = nbOfColumns;
        this.bvcFound = false;
        if (this.bvcColSent == null || this.bvcColSent.length() < this.nbOfColumns) {
            this.bvcColSent = new BitSet(this.nbOfColumns);
        }
        else {
            this.bvcColSent.clear();
        }
    }
    
    void unmarshalBVC(final int n) throws SQLException, IOException {
        int n2 = 0;
        for (int i = 0; i < this.bvcColSent.length(); ++i) {
            this.bvcColSent.clear(i);
        }
        for (int n3 = this.nbOfColumns / 8 + ((this.nbOfColumns % 8 != 0) ? 1 : 0), j = 0; j < n3; ++j) {
            final byte b = (byte)(this.meg.unmarshalUB1() & 0xFF);
            for (int k = 0; k < 8; ++k) {
                if ((b & 1 << k) != 0x0) {
                    this.bvcColSent.set(j * 8 + k);
                    ++n2;
                }
            }
        }
        if (n2 != n) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.bvcFound = true;
    }
    
    void readBitVector(final byte[] array) throws SQLException, IOException {
        for (int i = 0; i < this.bvcColSent.length(); ++i) {
            this.bvcColSent.clear(i);
        }
        if (array == null || array.length == 0) {
            this.bvcFound = false;
        }
        else {
            for (int j = 0; j < array.length; ++j) {
                final byte b = array[j];
                for (int k = 0; k < 8; ++k) {
                    if ((b & 1 << k) != 0x0) {
                        this.bvcColSent.set(j * 8 + k);
                    }
                }
            }
            this.bvcFound = true;
        }
    }
    
    Vector<IOException> marshal(final byte[] array, final char[] array2, final short[] array3, final int n, final byte[] array4, final DBConversion dbConversion, final InputStream[] array5, final byte[][] array6, final OracleTypeADT[] array7, final byte[] array8, final char[] array9, final short[] array10, final byte[] array11, final int n2, final int[] array12, final boolean b, final int[] array13, final int[] array14, final int[][] array15) throws IOException {
        Vector<IOException> vector = null;
        try {
            this.marshalTTCcode();
            final int n3 = array3[n + 0] & 0xFFFF;
            int n4 = 0;
            int n5 = array14[0];
            int[] array16 = array15[0];
            int n6 = 0;
            for (int i = 0; i < n3; ++i) {
                if (n4 < n5 && array16[n4] == i) {
                    ++n4;
                }
                else {
                    boolean b2 = false;
                    final int n7 = n + 5 + 10 * i;
                    final int n8 = array3[n7 + 0] & 0xFFFF;
                    if (array11 != null && (array11[i] & 0x20) == 0x0) {
                        if (n8 == 998) {
                            ++n6;
                        }
                    }
                    else {
                        final int n9 = ((array3[n7 + 7] & 0xFFFF) << 16) + (array3[n7 + 8] & 0xFFFF) + n2;
                        final int n10 = ((array3[n7 + 5] & 0xFFFF) << 16) + (array3[n7 + 6] & 0xFFFF) + n2;
                        int n11 = array3[n9] & 0xFFFF;
                        int n12 = array3[n10];
                        if (n8 == 116) {
                            this.meg.marshalUB1((short)1);
                            this.meg.marshalUB1((short)0);
                        }
                        else {
                            if (n8 == 994) {
                                n12 = -1;
                                if (array13[3 + i * 3 + 0] == 109) {
                                    b2 = true;
                                }
                            }
                            else if (n8 == 8 || n8 == 24 || (!b && array12 != null && array12.length > i && array12[i] > 4000)) {
                                if (n5 >= array16.length) {
                                    final int[] array17 = new int[array16.length << 1];
                                    System.arraycopy(array16, 0, array17, 0, array16.length);
                                    array16 = array17;
                                }
                                array16[n5++] = i;
                                continue;
                            }
                            if (n12 == -1) {
                                if (n8 == 109 || b2) {
                                    this.meg.marshalDALC(T4CTTIrxd.NO_BYTES);
                                    this.meg.marshalDALC(T4CTTIrxd.NO_BYTES);
                                    this.meg.marshalDALC(T4CTTIrxd.NO_BYTES);
                                    this.meg.marshalUB2(0);
                                    this.meg.marshalUB4(0L);
                                    this.meg.marshalUB2(1);
                                    continue;
                                }
                                if (n8 == 998) {
                                    ++n6;
                                    this.meg.marshalUB4(0L);
                                    continue;
                                }
                                if (n8 == 112 || n8 == 113 || n8 == 114) {
                                    this.meg.marshalUB4(0L);
                                    continue;
                                }
                                if (n8 != 8 && n8 != 24) {
                                    this.meg.marshalUB1((short)0);
                                    continue;
                                }
                            }
                            if (n8 == 998) {
                                final int n13 = ((array10[6 + n6 * 8 + 4] & 0xFFFF) << 16 & 0xFFFF000) | (array10[6 + n6 * 8 + 5] & 0xFFFF);
                                final int n14 = ((array10[6 + n6 * 8 + 6] & 0xFFFF) << 16 & 0xFFFF000) | (array10[6 + n6 * 8 + 7] & 0xFFFF);
                                final int n15 = array10[6 + n6 * 8] & 0xFFFF;
                                final int n16 = array10[6 + n6 * 8 + 1] & 0xFFFF;
                                this.meg.marshalUB4(n13);
                                for (int j = 0; j < n13; ++j) {
                                    final int n17 = n14 + j * n16;
                                    if (n15 == 9) {
                                        this.meg.marshalCLR(array4, dbConversion.javaCharsToCHARBytes(array9, n17 + 1, array4, 0, array9[n17] / '\u0002'));
                                    }
                                    else {
                                        final byte b3 = array8[n17];
                                        if (b3 < 1) {
                                            this.meg.marshalUB1((short)0);
                                        }
                                        else {
                                            this.meg.marshalCLR(array8, n17 + 1, b3);
                                        }
                                    }
                                }
                                ++n6;
                            }
                            else {
                                final int n18 = array3[n7 + 1] & 0xFFFF;
                                if (n18 != 0) {
                                    int n19 = ((array3[n7 + 3] & 0xFFFF) << 16) + (array3[n7 + 4] & 0xFFFF) + n18 * n2;
                                    if (n8 == 6) {
                                        ++n19;
                                        --n11;
                                    }
                                    else if (n8 == 9) {
                                        n19 += 2;
                                        n11 -= 2;
                                    }
                                    else if (n8 == 114 || n8 == 113 || n8 == 112) {
                                        this.meg.marshalUB4(n11);
                                    }
                                    if (n8 == 109 || n8 == 111) {
                                        if (array6 == null) {
                                            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
                                            sqlException.fillInStackTrace();
                                            throw sqlException;
                                        }
                                        final byte[] array18 = array6[i];
                                        final int n20 = (array18 == null) ? 0 : array18.length;
                                        if (n8 == 109) {
                                            this.meg.marshalDALC(T4CTTIrxd.NO_BYTES);
                                            this.meg.marshalDALC(T4CTTIrxd.NO_BYTES);
                                            this.meg.marshalDALC(T4CTTIrxd.NO_BYTES);
                                            this.meg.marshalUB2(0);
                                            this.meg.marshalUB4(n20);
                                            this.meg.marshalUB2(1);
                                        }
                                        if (n20 > 0) {
                                            this.meg.marshalCLR(array18, 0, n20);
                                        }
                                    }
                                    else if (n8 == 104) {
                                        n19 += 2;
                                        final long[] stringToRowid = T4CRowidAccessor.stringToRowid(array, n19, 18);
                                        final short n21 = 14;
                                        final long n22 = stringToRowid[0];
                                        final int n23 = (int)stringToRowid[1];
                                        final short n24 = 0;
                                        final long n25 = stringToRowid[2];
                                        final int n26 = (int)stringToRowid[3];
                                        if (n22 == 0L && n23 == 0 && n25 == 0L && n26 == 0) {
                                            this.meg.marshalUB1((short)0);
                                        }
                                        else {
                                            this.meg.marshalUB1(n21);
                                            this.meg.marshalUB4(n22);
                                            this.meg.marshalUB2(n23);
                                            this.meg.marshalUB1(n24);
                                            this.meg.marshalUB4(n25);
                                            this.meg.marshalUB2(n26);
                                        }
                                    }
                                    else if (n8 == 208) {
                                        n19 += 2;
                                        n11 -= 2;
                                        this.meg.marshalUB4(n11);
                                        this.meg.marshalCLR(array, n19, n11);
                                    }
                                    else if (n11 < 1) {
                                        this.meg.marshalUB1((short)0);
                                    }
                                    else {
                                        this.meg.marshalCLR(array, n19, n11);
                                    }
                                }
                                else {
                                    final int n27 = array3[n7 + 9] & 0xFFFF;
                                    int n28 = ((array3[n7 + 3] & 0xFFFF) << 16) + (array3[n7 + 4] & 0xFFFF) + (array3[n7 + 2] & 0xFFFF) * n2 + 1;
                                    if (n8 == 996) {
                                        final char c = array2[n28 - 1];
                                        if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
                                            this.bufferCHAR = new byte[c];
                                        }
                                        for (char c2 = '\0'; c2 < c; ++c2) {
                                            this.bufferCHAR[c2] = (byte)((array2[n28 + c2 / '\u0002'] & '\uff00') >> 8 & 0xFF);
                                            if (c2 < c - '\u0001') {
                                                this.bufferCHAR[c2 + '\u0001'] = (byte)(array2[n28 + c2 / '\u0002'] & '\u00ff' & 0xFF);
                                                ++c2;
                                            }
                                        }
                                        this.meg.marshalCLR(this.bufferCHAR, c);
                                        if (this.bufferCHAR.length > 4000) {
                                            this.bufferCHAR = null;
                                        }
                                    }
                                    else {
                                        int n29;
                                        if (n8 == 96) {
                                            n29 = n11 / 2;
                                            --n28;
                                        }
                                        else {
                                            n29 = (n11 - 2) / 2;
                                        }
                                        int n30;
                                        if (n27 == 2) {
                                            n30 = dbConversion.javaCharsToNCHARBytes(array2, n28, array4, 0, n29);
                                        }
                                        else {
                                            n30 = dbConversion.javaCharsToCHARBytes(array2, n28, array4, 0, n29);
                                        }
                                        this.meg.marshalCLR(array4, n30);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (n5 > 0) {
                for (final int n31 : array16) {
                    final int n32 = n + 5 + 10 * n31;
                    final int n33 = array3[n32 + 0] & 0xFFFF;
                    final int n34 = ((array3[n32 + 7] & 0xFFFF) << 16) + (array3[n32 + 8] & 0xFFFF) + n2;
                    final short n35 = array3[((array3[n32 + 5] & 0xFFFF) << 16) + (array3[n32 + 6] & 0xFFFF) + n2];
                    final int n36 = array3[n34] & 0xFFFF;
                    int n37 = ((array3[n32 + 3] & 0xFFFF) << 16) + (array3[n32 + 4] & 0xFFFF) + (array3[n32 + 2] & 0xFFFF) * n2 + 1;
                    if (n35 == -1) {
                        this.meg.marshalUB1((short)0);
                    }
                    else if (n33 == 996) {
                        final char c3 = array2[n37 - 1];
                        if (this.bufferCHAR == null || this.bufferCHAR.length < c3) {
                            this.bufferCHAR = new byte[c3];
                        }
                        for (char c4 = '\0'; c4 < c3; ++c4) {
                            this.bufferCHAR[c4] = (byte)((array2[n37 + c4 / '\u0002'] & '\uff00') >> 8 & 0xFF);
                            if (c4 < c3 - '\u0001') {
                                this.bufferCHAR[c4 + '\u0001'] = (byte)(array2[n37 + c4 / '\u0002'] & '\u00ff' & 0xFF);
                                ++c4;
                            }
                        }
                        this.meg.marshalCLR(this.bufferCHAR, c3);
                        if (this.bufferCHAR.length > 4000) {
                            this.bufferCHAR = null;
                        }
                    }
                    else if (n33 != 8 && n33 != 24) {
                        int n38;
                        if (n33 == 96) {
                            n38 = n36 / 2;
                            --n37;
                        }
                        else {
                            n38 = (n36 - 2) / 2;
                        }
                        int n39;
                        if ((array3[n32 + 9] & 0xFFFF) == 0x2) {
                            n39 = dbConversion.javaCharsToNCHARBytes(array2, n37, array4, 0, n38);
                        }
                        else {
                            n39 = dbConversion.javaCharsToCHARBytes(array2, n37, array4, 0, n38);
                        }
                        this.meg.marshalCLR(array4, n39);
                    }
                    else {
                        final int n40 = n31;
                        if (array5 != null) {
                            final InputStream inputStream = array5[n40];
                            if (inputStream != null) {
                                final int len = 64;
                                if (this.buffer == null) {
                                    this.buffer = new byte[len];
                                }
                                this.meg.marshalUB1((short)254);
                                int n41 = 0;
                                while (n41 == 0 && !this.connection.sentCancel) {
                                    int read;
                                    try {
                                        read = inputStream.read(this.buffer, 0, len);
                                    }
                                    catch (IOException e) {
                                        read = -1;
                                        if (vector == null) {
                                            vector = new Vector<IOException>();
                                        }
                                        vector.add(e);
                                    }
                                    if (read == -1) {
                                        n41 = 1;
                                    }
                                    if (read > 0) {
                                        this.meg.marshalUB1((short)(read & 0xFF));
                                        this.meg.marshalB1Array(this.buffer, 0, read);
                                    }
                                }
                                this.meg.marshalSB1((byte)0);
                            }
                        }
                    }
                }
            }
            array14[0] = n5;
            array15[0] = array16;
        }
        catch (SQLException cause) {
            final IOException ex = new IOException();
            ex.initCause(cause);
            throw ex;
        }
        return vector;
    }
    
    boolean unmarshal(final Accessor[] array, final int n) throws SQLException, IOException {
        return this.unmarshal(array, 0, n);
    }
    
    boolean unmarshal(final Accessor[] array, final int n, final int n2) throws SQLException, IOException {
        if (n == 0) {
            this.isFirstCol = true;
        }
        for (int n3 = n; n3 < n2 && n3 < array.length; ++n3) {
            if (array[n3] != null) {
                if (array[n3].physicalColumnIndex < 0) {
                    int physicalColumnIndex = 0;
                    for (int n4 = 0; n4 < n2 && n4 < array.length; ++n4) {
                        if (array[n4] != null) {
                            array[n4].physicalColumnIndex = physicalColumnIndex;
                            if (!array[n4].isUseLess) {
                                ++physicalColumnIndex;
                            }
                        }
                    }
                }
                if (this.bvcFound && !array[n3].isUseLess && !this.bvcColSent.get(array[n3].physicalColumnIndex)) {
                    array[n3].copyRow();
                }
                else {
                    byte b = 0;
                    if (array[n3].statement.statementType != 2 && array[n3].statement.sqlKind != 64 && array[n3].statement.sqlKind != 32) {
                        final int n5 = array[n3].metaDataIndex + array[n3].lastRowProcessed * 1;
                        if (array[n3].securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) {
                            b = (byte)this.meg.unmarshalUB1();
                        }
                        array[n3].rowSpaceMetaData[n5] = b;
                    }
                    if (array[n3].unmarshalOneRow()) {
                        return true;
                    }
                    this.isFirstCol = false;
                }
            }
        }
        return this.bvcFound = false;
    }
    
    boolean unmarshal(final Accessor[] array, final int n, final int n2, final int n3) throws SQLException, IOException {
        return false;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        NO_BYTES = new byte[0];
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
