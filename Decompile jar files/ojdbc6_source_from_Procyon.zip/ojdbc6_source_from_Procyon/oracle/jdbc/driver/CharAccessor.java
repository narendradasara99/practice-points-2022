// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class CharAccessor extends CharCommonAccessor
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    CharAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        int n4 = 2000;
        if (n > n4) {
            n4 = n;
        }
        if (oracleStatement.sqlKind == 32) {
            n4 = 32766;
        }
        this.init(oracleStatement, 96, 9, n, n2, n3, b, n4, 255);
    }
    
    CharAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        int n8 = 2000;
        if (n > n8) {
            n8 = n;
        }
        if (oracleStatement.sqlKind == 32) {
            n8 = 32766;
        }
        this.init(oracleStatement, 96, 9, n, b, n2, n3, n4, n5, n6, n7, n8, 255);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
