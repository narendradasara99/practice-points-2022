// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class FixedCHARBinder extends Binder
{
    Binder theFixedCHARCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 96;
        binder.bytelen = 0;
    }
    
    FixedCHARBinder() {
        this.theFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
        init(this);
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] dst, final short[] array2, final int n4, final int n5, final int n6, final int dstBegin, final int n7, final int n8, final boolean b) {
        final String[] array3 = oraclePreparedStatement.parameterString[n3];
        final String s = array3[n];
        if (b) {
            array3[n] = null;
        }
        if (s == null) {
            array2[n8] = -1;
        }
        else {
            array2[n8] = 0;
            final int length = s.length();
            s.getChars(0, length, dst, dstBegin);
            int n9 = length << 1;
            if (n9 > 65534) {
                n9 = 65534;
            }
            array2[n7] = (short)n9;
        }
    }
    
    @Override
    Binder copyingBinder() {
        return this.theFixedCHARCopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
