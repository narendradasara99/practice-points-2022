// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLXML;
import oracle.sql.DatumWithConnection;
import oracle.sql.JAVA_STRUCT;
import oracle.sql.ARRAY;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.Datum;
import oracle.xdb.XMLType;
import oracle.sql.OPAQUE;
import oracle.sql.STRUCT;
import java.util.Map;
import oracle.sql.StructDescriptor;
import oracle.sql.OpaqueDescriptor;
import java.sql.Connection;
import oracle.sql.ArrayDescriptor;
import oracle.jdbc.OracleConnection;
import oracle.sql.TypeDescriptor;
import oracle.jdbc.oracore.OracleType;
import java.sql.SQLException;

class NamedTypeAccessor extends TypeAccessor
{
    private static final Class xmlType;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NamedTypeAccessor(final OracleStatement oracleStatement, final String s, final short n, final int n2, final boolean b) throws SQLException {
        this.init(oracleStatement, 109, 109, n, b);
        this.initForDataAccess(n2, 0, s);
    }
    
    NamedTypeAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final String s) throws SQLException {
        this.init(oracleStatement, 109, 109, n7, false);
        this.initForDescribe(109, n, b, n2, n3, n4, n5, n6, n7, s);
        this.initForDataAccess(0, n, s);
    }
    
    NamedTypeAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final String s, final OracleType oracleType) throws SQLException {
        this.init(oracleStatement, 109, 109, n7, false);
        this.describeOtype = oracleType;
        this.initForDescribe(109, n, b, n2, n3, n4, n5, n6, n7, s);
        this.internalOtype = oracleType;
        this.initForDataAccess(0, n, s);
    }
    
    @Override
    OracleType otypeFromName(final String s) throws SQLException {
        if (!this.outBind) {
            return TypeDescriptor.getTypeDescriptor(s, this.statement.connection).getPickler();
        }
        if (this.externalType == 2003) {
            return ArrayDescriptor.createDescriptor(s, this.statement.connection).getOracleTypeCOLLECTION();
        }
        if (this.externalType == 2007 || this.externalType == 2009) {
            return OpaqueDescriptor.createDescriptor(s, this.statement.connection).getPickler();
        }
        return StructDescriptor.createDescriptor(s, this.statement.connection).getOracleTypeADT();
    }
    
    @Override
    void initForDataAccess(final int n, final int n2, final String s) throws SQLException {
        super.initForDataAccess(n, n2, s);
        this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        return this.getObject(n, this.statement.connection.getTypeMap());
    }
    
    @Override
    Object getObject(final int n, Map map) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        if (this.externalType == 0) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof STRUCT) {
                return ((STRUCT)oracleObject).toJdbc(map);
            }
            if (!(oracleObject instanceof OPAQUE)) {
                return oracleObject.toJdbc();
            }
            final Object jdbc = ((OPAQUE)oracleObject).toJdbc(map);
            if (NamedTypeAccessor.xmlType == null || !NamedTypeAccessor.xmlType.isInstance(jdbc)) {
                return jdbc;
            }
            if (this.statement.connection.getObjectReturnsXmlType) {
                return jdbc;
            }
            return new OracleSQLXML(this.statement.connection, (XMLType)jdbc);
        }
        else {
            switch (this.externalType) {
                case 2008: {
                    map = null;
                }
                case 2000:
                case 2002:
                case 2003:
                case 2007: {
                    final Datum oracleObject2 = this.getOracleObject(n);
                    if (oracleObject2 == null) {
                        return null;
                    }
                    if (oracleObject2 instanceof STRUCT) {
                        return ((STRUCT)oracleObject2).toJdbc(map);
                    }
                    return oracleObject2.toJdbc();
                }
                case 2009: {
                    final Datum oracleObject3 = this.getOracleObject(n);
                    if (oracleObject3 == null) {
                        return null;
                    }
                    if (oracleObject3 instanceof OPAQUE) {
                        return new OracleSQLXML(this.statement.connection, (OPAQUE)oracleObject3);
                    }
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
                default: {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
            }
        }
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final byte[] pickledBytes = this.pickledBytes(n);
        if (pickledBytes == null || pickledBytes.length == 0) {
            return null;
        }
        final PhysicalConnection connection = this.statement.connection;
        final TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(((OracleTypeADT)this.internalOtype).getFullName(), connection, pickledBytes, 0L);
        DatumWithConnection datumWithConnection = null;
        switch (typeDescriptor.getTypeCode()) {
            case 2003: {
                datumWithConnection = new ARRAY((ArrayDescriptor)typeDescriptor, pickledBytes, connection);
                break;
            }
            case 2002: {
                datumWithConnection = new STRUCT((StructDescriptor)typeDescriptor, pickledBytes, connection);
                break;
            }
            case 2007:
            case 2009: {
                datumWithConnection = new OPAQUE((OpaqueDescriptor)typeDescriptor, pickledBytes, connection);
                break;
            }
            case 2008: {
                datumWithConnection = new JAVA_STRUCT((StructDescriptor)typeDescriptor, pickledBytes, connection);
                break;
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return datumWithConnection;
    }
    
    @Override
    ARRAY getARRAY(final int n) throws SQLException {
        return (ARRAY)this.getOracleObject(n);
    }
    
    @Override
    STRUCT getSTRUCT(final int n) throws SQLException {
        return (STRUCT)this.getOracleObject(n);
    }
    
    @Override
    OPAQUE getOPAQUE(final int n) throws SQLException {
        return (OPAQUE)this.getOracleObject(n);
    }
    
    @Override
    boolean isNull(final int n) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final byte[] pickledBytes = this.pickledBytes(n);
        return pickledBytes == null || pickledBytes.length == 0;
    }
    
    @Override
    SQLXML getSQLXML(final int n) throws SQLException {
        try {
            final OPAQUE opaque = (OPAQUE)this.getOracleObject(n);
            if (opaque == null) {
                return null;
            }
            return new OracleSQLXML(this.statement.connection, opaque);
        }
        catch (ClassCastException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    static {
        Class<?> forName = null;
        try {
            forName = Class.forName("oracle.xdb.XMLType");
        }
        catch (Throwable t) {}
        xmlType = forName;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
