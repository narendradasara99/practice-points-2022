// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class RawAccessor extends RawCommonAccessor
{
    static final int MAXLENGTH_NEW = 2000;
    static final int MAXLENGTH_OLD = 255;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    RawAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 23, 15, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    RawAccessor(final OracleStatement oracleStatement, int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7) throws SQLException {
        this.init(oracleStatement, 23, 15, n7, false);
        this.initForDescribe(23, n, b, n2, n3, n4, n5, n6, n7, null);
        final int maxFieldSize = oracleStatement.maxFieldSize;
        if (maxFieldSize > 0 && (n == 0 || maxFieldSize < n)) {
            n = maxFieldSize;
        }
        this.initForDataAccess(0, n, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        if (this.statement.connection.getVersionNumber() >= 8000) {
            this.internalTypeMaxLength = 2000;
        }
        else {
            this.internalTypeMaxLength = 255;
        }
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength + 2;
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final short n2 = this.rowSpaceIndicator[this.lengthIndex + n];
            final int n3 = this.columnIndex + this.byteLength * n;
            o = new byte[n2];
            System.arraycopy(this.rowSpaceByte, n3 + 2, o, 0, n2);
        }
        return (byte[])o;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
