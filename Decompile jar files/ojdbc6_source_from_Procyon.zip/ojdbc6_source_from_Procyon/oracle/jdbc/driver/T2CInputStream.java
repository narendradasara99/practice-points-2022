// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;
import java.nio.ByteBuffer;

class T2CInputStream extends OracleInputStream
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    native int t2cGetBytes(final long p0, final int p1, final byte[] p2, final int p3, final Accessor[] p4, final byte[] p5, final int p6, final char[] p7, final int p8, final short[] p9, final int p10, final Object[] p11, final Object[] p12, final long p13);
    
    T2CInputStream(final OracleStatement oracleStatement, final int n, final Accessor accessor) {
        super(oracleStatement, n, accessor);
    }
    
    @Override
    public int getBytes(final int a) throws IOException {
        synchronized (this.statement.connection) {
            if (a > this.currentBufferSize) {
                this.currentBufferSize = Math.max(a, this.initialBufferSize);
                this.resizableBuffer = new byte[this.currentBufferSize];
            }
            final long n = (long)(this.statement.connection.useNio ? 1 : 0);
            if (this.statement.connection.useNio) {
                if (this.statement.nioBuffers[3] == null || this.statement.nioBuffers[3].capacity() < this.resizableBuffer.length) {
                    this.statement.nioBuffers[3] = ByteBuffer.allocateDirect(this.resizableBuffer.length);
                }
                else {
                    this.statement.nioBuffers[3].rewind();
                }
            }
            int t2cGetBytes = this.t2cGetBytes(this.statement.c_state, this.columnIndex, this.resizableBuffer, this.currentBufferSize, this.statement.accessors, this.statement.defineBytes, this.statement.accessorByteOffset, this.statement.defineChars, this.statement.accessorCharOffset, this.statement.defineIndicators, this.statement.accessorShortOffset, this.statement.nioBuffers, this.statement.lobPrefetchMetaData, n);
            boolean b = false;
            try {
                if (t2cGetBytes == -1) {
                    ((T2CConnection)this.statement.connection).checkError(t2cGetBytes, this.statement.sqlWarning);
                }
                else if (t2cGetBytes == -2) {
                    b = true;
                    this.accessor.setNull((this.statement.currentRow == -1) ? 0 : this.statement.currentRow, true);
                    t2cGetBytes = 0;
                }
                else if (this.statement.connection.useNio && t2cGetBytes >= 0) {
                    this.accessor.setNull((this.statement.currentRow == -1) ? 0 : this.statement.currentRow, false);
                }
            }
            catch (SQLException ex) {
                throw new IOException(ex.getMessage());
            }
            if (t2cGetBytes <= 0) {
                t2cGetBytes = -1;
                b = true;
            }
            if (this.statement.connection.useNio) {
                final ByteBuffer byteBuffer = this.statement.nioBuffers[3];
                if (byteBuffer != null && t2cGetBytes > 0) {
                    byteBuffer.get(this.resizableBuffer, 0, t2cGetBytes);
                }
                if (b) {
                    try {
                        this.statement.extractNioDefineBuffers(this.columnIndex);
                    }
                    catch (SQLException ex2) {
                        throw new IOException(ex2.getMessage());
                    }
                }
            }
            if (b && this.statement.lobPrefetchMetaData != null) {
                this.statement.processLobPrefetchMetaData(this.statement.lobPrefetchMetaData);
            }
            return t2cGetBytes;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
