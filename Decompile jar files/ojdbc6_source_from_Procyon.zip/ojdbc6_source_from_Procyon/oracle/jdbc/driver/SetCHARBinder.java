// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class SetCHARBinder extends Binder
{
    Binder theSetCHARCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 996;
        binder.bytelen = 0;
    }
    
    SetCHARBinder() {
        this.theSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theSetCHARCopyingBinder;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        final byte[][] array4 = oraclePreparedStatement.parameterDatum[n3];
        final byte[] array5 = array4[n];
        if (b) {
            array4[n] = null;
        }
        if (array5 == null) {
            array3[n9] = -1;
        }
        else {
            array3[n9] = 0;
            int i = array5.length;
            array2[n7] = (char)i;
            if (i > 65532) {
                array3[n8] = -2;
            }
            else {
                array3[n8] = (short)(i + 2);
            }
            int n10 = n7 + (i >> 1);
            if (i % 2 == 1) {
                array2[n10 + 1] = (char)(array5[--i] << 8);
            }
            while (i > 0) {
                i -= 2;
                array2[n10--] = (char)(array5[i] << 8 | (array5[i + 1] & 0xFF));
            }
        }
    }
    
    @Override
    short updateInoutIndicatorValue(final short n) {
        return (short)(n | 0x4);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
