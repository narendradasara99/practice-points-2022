// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;

class T4Ctoh
{
    static final int TOPLVL_KPCTOH = 1;
    static final int SERBEG_KPCTOH = 2;
    static final int SEREND_KPCTOH = 4;
    static final int SERONE_KPCTOH = 8;
    static final int NEW_KPCTOH = 16;
    static final int UPDATE_KPCTOH = 32;
    static final int DELETE_KPCTOH = 64;
    static final int LAST_KPCTOH = 128;
    static final int NOOBJ_KPCTOH = 256;
    static final int NNO_KPCTOH = 512;
    static final int RAWSTR_KPCTOH = 1024;
    static final byte[] EOID_KOTTD;
    static final byte KORFPFNNL = 2;
    static final byte EXTENT_OID = 8;
    static final int DONE_KPCTOC = 0;
    static final int MORE_KPCTOC = -1;
    static final int IGNORE_KPCTOC = -2;
    static final byte[] ANYDATA_TOID;
    static final int KOIDFLEN = 16;
    byte[] toid;
    byte[] oid;
    byte[] snapshot;
    int versionNumber;
    int imageLength;
    int flags;
    int[] intArr;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4Ctoh() {
        this.toid = null;
        this.oid = null;
        this.snapshot = null;
        this.versionNumber = 0;
        this.imageLength = 0;
        this.flags = 0;
        this.intArr = new int[1];
    }
    
    void init(final byte[] array, final int imageLength) {
        if (this.toid == null || this.toid.length != 36) {
            this.toid = new byte[36];
        }
        this.toid[0] = 0;
        this.toid[1] = 36;
        this.toid[2] = 2;
        this.toid[3] = 8;
        System.arraycopy(array, 0, this.toid, 4, 16);
        System.arraycopy(T4Ctoh.EOID_KOTTD, 0, this.toid, 20, 16);
        this.imageLength = imageLength;
        this.oid = null;
        this.snapshot = null;
        this.versionNumber = 0;
        this.flags = 1;
    }
    
    void marshal(final T4CMAREngine t4CMAREngine) throws IOException {
        if (this.toid == null) {
            t4CMAREngine.marshalUB4(0L);
        }
        else {
            t4CMAREngine.marshalUB4(this.toid.length);
            t4CMAREngine.marshalCLR(this.toid, 0, this.toid.length);
        }
        if (this.oid == null) {
            t4CMAREngine.marshalUB4(0L);
        }
        else {
            t4CMAREngine.marshalUB4(this.oid.length);
            t4CMAREngine.marshalCLR(this.oid, 0, this.oid.length);
        }
        if (this.snapshot == null) {
            t4CMAREngine.marshalUB4(0L);
        }
        else {
            t4CMAREngine.marshalUB4(this.snapshot.length);
            t4CMAREngine.marshalCLR(this.snapshot, 0, this.snapshot.length);
        }
        t4CMAREngine.marshalUB2(this.versionNumber);
        t4CMAREngine.marshalUB4(this.imageLength);
        t4CMAREngine.marshalUB2(this.flags);
    }
    
    void unmarshal(final T4CMAREngine t4CMAREngine) throws SQLException, IOException {
        final int n = (int)t4CMAREngine.unmarshalUB4();
        if (this.toid == null || this.toid.length != n) {
            this.toid = new byte[n];
        }
        if (n > 0) {
            t4CMAREngine.unmarshalCLR(this.toid, 0, this.intArr, n);
        }
        final int n2 = (int)t4CMAREngine.unmarshalUB4();
        this.oid = new byte[n2];
        if (n2 > 0) {
            t4CMAREngine.unmarshalCLR(this.oid, 0, this.intArr, n2);
        }
        final int n3 = (int)t4CMAREngine.unmarshalUB4();
        this.snapshot = new byte[n3];
        if (n3 > 0) {
            t4CMAREngine.unmarshalCLR(this.snapshot, 0, this.intArr, n3);
        }
        this.versionNumber = t4CMAREngine.unmarshalUB2();
        this.imageLength = (int)t4CMAREngine.unmarshalUB4();
        this.flags = t4CMAREngine.unmarshalUB2();
    }
    
    static {
        EOID_KOTTD = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1 };
        ANYDATA_TOID = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 17 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
