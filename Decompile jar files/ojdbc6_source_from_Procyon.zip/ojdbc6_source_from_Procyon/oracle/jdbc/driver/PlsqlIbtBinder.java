// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.sql.Datum;

class PlsqlIbtBinder extends Binder
{
    Binder thePlsqlIbtCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    PlsqlIbtBinder() {
        this.thePlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
        init(this);
    }
    
    static void init(final Binder binder) {
        binder.type = 998;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) throws SQLException {
        final PlsqlIbtBindInfo plsqlIbtBindInfo = oraclePreparedStatement.parameterPlsqlIbt[n3][n];
        if (b) {
            oraclePreparedStatement.parameterPlsqlIbt[n3][n] = null;
        }
        int ibtValueIndex = plsqlIbtBindInfo.ibtValueIndex;
        switch (plsqlIbtBindInfo.element_internal_type) {
            case 9: {
                for (int i = 0; i < plsqlIbtBindInfo.curLen; ++i) {
                    final String s = (String)plsqlIbtBindInfo.arrayData[i];
                    if (s != null) {
                        int length = s.length();
                        if (length > plsqlIbtBindInfo.elemMaxLen - 1) {
                            length = plsqlIbtBindInfo.elemMaxLen - 1;
                        }
                        s.getChars(0, length, oraclePreparedStatement.ibtBindChars, ibtValueIndex + 1);
                        oraclePreparedStatement.ibtBindIndicators[plsqlIbtBindInfo.ibtIndicatorIndex + i] = 0;
                        final int n10 = length << 1;
                        oraclePreparedStatement.ibtBindChars[ibtValueIndex] = (char)n10;
                        oraclePreparedStatement.ibtBindIndicators[plsqlIbtBindInfo.ibtLengthIndex + i] = (short)((n10 == 0) ? 3 : ((short)(n10 + 2)));
                    }
                    else {
                        oraclePreparedStatement.ibtBindIndicators[plsqlIbtBindInfo.ibtIndicatorIndex + i] = -1;
                    }
                    ibtValueIndex += plsqlIbtBindInfo.elemMaxLen;
                }
                break;
            }
            case 6: {
                for (int j = 0; j < plsqlIbtBindInfo.curLen; ++j) {
                    Object bytes = null;
                    if (plsqlIbtBindInfo.arrayData[j] != null) {
                        bytes = ((Datum)plsqlIbtBindInfo.arrayData[j]).getBytes();
                    }
                    if (bytes == null) {
                        oraclePreparedStatement.ibtBindIndicators[plsqlIbtBindInfo.ibtIndicatorIndex + j] = -1;
                    }
                    else {
                        oraclePreparedStatement.ibtBindIndicators[plsqlIbtBindInfo.ibtIndicatorIndex + j] = 0;
                        oraclePreparedStatement.ibtBindIndicators[plsqlIbtBindInfo.ibtLengthIndex + j] = (short)(bytes.length + 1);
                        oraclePreparedStatement.ibtBindBytes[ibtValueIndex] = (byte)bytes.length;
                        System.arraycopy(bytes, 0, oraclePreparedStatement.ibtBindBytes, ibtValueIndex + 1, bytes.length);
                    }
                    ibtValueIndex += plsqlIbtBindInfo.elemMaxLen;
                }
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 97);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
    }
    
    @Override
    Binder copyingBinder() {
        return this.thePlsqlIbtCopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
