// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Iterator;
import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;

class NTFListener extends Thread
{
    private NTFConnection[] connections;
    private int nbOfConnections;
    private boolean needsToBeClosed;
    NTFManager dcnManager;
    ServerSocketChannel ssChannel;
    int tcpport;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFListener(final NTFManager dcnManager, final ServerSocketChannel ssChannel, final int tcpport) {
        this.connections = null;
        this.nbOfConnections = 0;
        this.needsToBeClosed = false;
        this.dcnManager = dcnManager;
        this.connections = new NTFConnection[10];
        this.ssChannel = ssChannel;
        this.tcpport = tcpport;
    }
    
    @Override
    public void run() {
        try {
            final Selector open = Selector.open();
            this.ssChannel.register(open, 16);
            while (true) {
                open.select();
                if (this.needsToBeClosed) {
                    break;
                }
                final Iterator<SelectionKey> iterator = open.selectedKeys().iterator();
                while (iterator.hasNext()) {
                    final SelectionKey selectionKey = iterator.next();
                    if ((selectionKey.readyOps() & 0x10) == 0x10) {
                        final NTFConnection ntfConnection = new NTFConnection(this.dcnManager, ((ServerSocketChannel)selectionKey.channel()).accept());
                        if (this.connections.length == this.nbOfConnections) {
                            final NTFConnection[] connections = new NTFConnection[this.connections.length * 2];
                            System.arraycopy(this.connections, 0, connections, 0, this.connections.length);
                            this.connections = connections;
                        }
                        (this.connections[this.nbOfConnections++] = ntfConnection).start();
                        iterator.remove();
                    }
                }
            }
            open.close();
            this.ssChannel.close();
        }
        catch (IOException ex) {}
    }
    
    synchronized void closeThisListener() {
        for (int i = 0; i < this.nbOfConnections; ++i) {
            this.connections[i].closeThisConnection();
            this.connections[i].interrupt();
        }
        this.needsToBeClosed = true;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
