// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;

class OracleSavepoint implements oracle.jdbc.OracleSavepoint
{
    private static final int MAX_ID_VALUE = 65535;
    private static final int INVALID_ID_VALUE = -1;
    static final int NAMED_SAVEPOINT_TYPE = 2;
    static final int UNNAMED_SAVEPOINT_TYPE = 1;
    static final int UNKNOWN_SAVEPOINT_TYPE = 0;
    private static int s_seedId;
    private int m_id;
    private String m_name;
    private int m_type;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleSavepoint() {
        this.m_id = -1;
        this.m_name = null;
        this.m_type = 0;
        this.m_type = 1;
        this.m_id = this.getNextId();
        this.m_name = null;
    }
    
    OracleSavepoint(final String name) throws SQLException {
        this.m_id = -1;
        this.m_name = null;
        this.m_type = 0;
        if (name != null && name.length() != 0 && !OracleSql.isValidObjectName(name)) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.m_type = 2;
        this.m_name = name;
        this.m_id = -1;
    }
    
    @Override
    public int getSavepointId() throws SQLException {
        if (this.m_type == 2) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 118);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.m_id;
    }
    
    @Override
    public String getSavepointName() throws SQLException {
        if (this.m_type == 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 119);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.m_name;
    }
    
    int getType() {
        return this.m_type;
    }
    
    private synchronized int getNextId() {
        return OracleSavepoint.s_seedId = (OracleSavepoint.s_seedId + 1) % 65535;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        OracleSavepoint.s_seedId = 0;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
