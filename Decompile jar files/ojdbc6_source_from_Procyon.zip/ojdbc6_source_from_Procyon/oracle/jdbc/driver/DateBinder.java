// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Date;

class DateBinder extends DateCommonBinder
{
    Binder theDateCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 12;
        binder.bytelen = 7;
    }
    
    DateBinder() {
        this.theDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theDateCopyingBinder;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) throws SQLException {
        final Date[] array4 = oraclePreparedStatement.parameterDate[n3];
        final Date date = array4[n];
        if (b) {
            array4[n] = null;
        }
        if (date == null) {
            array3[n9] = -1;
        }
        else {
            array3[n9] = 0;
            final long n10 = DateCommonBinder.setOracleCYMD(date.getTime(), array, n6, oraclePreparedStatement);
            array[6 + n6] = 1;
            array[4 + n6] = (array[5 + n6] = 1);
            array3[n8] = (short)n4;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
