// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class RowidBinder extends Binder
{
    Binder theRowidCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 9;
        binder.bytelen = 130;
    }
    
    RowidBinder() {
        this.theRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
        init(this);
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) throws SQLException {
        final byte[][] array4 = oraclePreparedStatement.parameterDatum[n3];
        final byte[] array5 = array4[n];
        if (b) {
            array4[n] = null;
        }
        if (array5 == null) {
            array3[n9] = -1;
        }
        else {
            array3[n9] = 0;
            final int length = array5.length;
            System.arraycopy(array5, 0, array, n6 + 2, length);
            array[n6] = (byte)(length >> 8);
            array[n6 + 1] = (byte)(length & 0xFF);
            array3[n8] = (short)(length + 2);
        }
    }
    
    @Override
    Binder copyingBinder() {
        return this.theRowidCopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
