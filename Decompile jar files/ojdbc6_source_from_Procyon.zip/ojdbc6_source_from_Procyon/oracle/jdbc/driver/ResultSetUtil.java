// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

class ResultSetUtil
{
    static final int[][] allRsetTypes;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static OracleResultSet createScrollResultSet(final ScrollRsetStatement scrollRsetStatement, final OracleResultSet set, final int n) throws SQLException {
        switch (n) {
            case 1: {
                return set;
            }
            case 2: {
                return new UpdatableResultSet(scrollRsetStatement, (OracleResultSetImpl)set, getScrollType(n), getUpdateConcurrency(n));
            }
            case 3: {
                return new ScrollableResultSet(scrollRsetStatement, (OracleResultSetImpl)set, getScrollType(n), getUpdateConcurrency(n));
            }
            case 4: {
                return new UpdatableResultSet(scrollRsetStatement, new ScrollableResultSet(scrollRsetStatement, (OracleResultSetImpl)set, getScrollType(n), getUpdateConcurrency(n)), getScrollType(n), getUpdateConcurrency(n));
            }
            case 5: {
                return new SensitiveScrollableResultSet(scrollRsetStatement, (OracleResultSetImpl)set, getScrollType(n), getUpdateConcurrency(n));
            }
            case 6: {
                return new UpdatableResultSet(scrollRsetStatement, new SensitiveScrollableResultSet(scrollRsetStatement, (OracleResultSetImpl)set, getScrollType(n), getUpdateConcurrency(n)), getScrollType(n), getUpdateConcurrency(n));
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 23, null);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
    }
    
    static int getScrollType(final int n) {
        return ResultSetUtil.allRsetTypes[n][0];
    }
    
    static int getUpdateConcurrency(final int n) {
        return ResultSetUtil.allRsetTypes[n][1];
    }
    
    static int getRsetTypeCode(final int n, final int n2) throws SQLException {
        for (int i = 0; i < ResultSetUtil.allRsetTypes.length; ++i) {
            if (ResultSetUtil.allRsetTypes[i][0] == n && ResultSetUtil.allRsetTypes[i][1] == n2) {
                return i;
            }
        }
        final SQLException sqlException = DatabaseError.createSqlException(null, 68);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static boolean needIdentifier(final int n) throws SQLException {
        return n != 1 && n != 3;
    }
    
    static boolean needIdentifier(final int n, final int n2) throws SQLException {
        return needIdentifier(getRsetTypeCode(n, n2));
    }
    
    static boolean needCache(final int n) throws SQLException {
        return n >= 3;
    }
    
    static boolean needCache(final int n, final int n2) throws SQLException {
        return needCache(getRsetTypeCode(n, n2));
    }
    
    static boolean supportRefreshRow(final int n) throws SQLException {
        return n >= 4;
    }
    
    static boolean supportRefreshRow(final int n, final int n2) throws SQLException {
        return supportRefreshRow(getRsetTypeCode(n, n2));
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        allRsetTypes = new int[][] { { 0, 0 }, { 1003, 1007 }, { 1003, 1008 }, { 1004, 1007 }, { 1004, 1008 }, { 1005, 1007 }, { 1005, 1008 } };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
