// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.util.Enumeration;
import java.sql.SQLException;
import java.net.ServerSocket;
import java.io.IOException;
import java.net.BindException;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.util.Hashtable;

class NTFManager
{
    private Hashtable<Integer, NTFListener> nsListeners;
    private Hashtable<Integer, NTFRegistration> ntfRegistrations;
    private byte[] listOfJdbcRegId;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFManager() {
        this.nsListeners = new Hashtable<Integer, NTFListener>();
        this.ntfRegistrations = new Hashtable<Integer, NTFRegistration>();
        this.listOfJdbcRegId = new byte[20];
    }
    
    synchronized boolean listenOnPortT4C(final int[] array, final boolean b) throws SQLException {
        int i = array[0];
        boolean b2 = false;
        if (this.nsListeners.get(i) == null) {
            b2 = true;
            try {
                final ServerSocketChannel open = ServerSocketChannel.open();
                open.configureBlocking(false);
                final ServerSocket socket = open.socket();
                while (true) {
                    try {
                        socket.bind(new InetSocketAddress(i));
                    }
                    catch (BindException ex2) {
                        if (!b) {
                            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 250);
                            sqlException.fillInStackTrace();
                            throw sqlException;
                        }
                        ++i;
                        continue;
                    }
                    catch (IOException ex3) {
                        if (!b) {
                            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 250);
                            sqlException2.fillInStackTrace();
                            throw sqlException2;
                        }
                        ++i;
                        continue;
                    }
                    break;
                }
                final NTFListener value = new NTFListener(this, open, i);
                this.nsListeners.put(i, value);
                value.start();
            }
            catch (IOException ex) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
        }
        array[0] = i;
        return b2;
    }
    
    synchronized int getNextJdbcRegId() {
        int n;
        for (n = 1; n < this.listOfJdbcRegId.length && this.listOfJdbcRegId[n] != 0; ++n) {}
        if (n == this.listOfJdbcRegId.length - 1) {
            final byte[] listOfJdbcRegId = new byte[this.listOfJdbcRegId.length * 2];
            System.arraycopy(this.listOfJdbcRegId, 0, listOfJdbcRegId, 0, this.listOfJdbcRegId.length);
            this.listOfJdbcRegId = listOfJdbcRegId;
        }
        this.listOfJdbcRegId[n] = 2;
        return n;
    }
    
    synchronized void addRegistration(final NTFRegistration value) {
        final Integer value2 = value.getJdbcRegId();
        final Hashtable ntfRegistrations = (Hashtable)this.ntfRegistrations.clone();
        ntfRegistrations.put(value2, value);
        this.ntfRegistrations = (Hashtable<Integer, NTFRegistration>)ntfRegistrations;
    }
    
    synchronized boolean removeRegistration(final NTFRegistration ntfRegistration) {
        final Integer value = ntfRegistration.getJdbcRegId();
        final Hashtable ntfRegistrations = (Hashtable)this.ntfRegistrations.clone();
        final Object remove = ntfRegistrations.remove(value);
        this.ntfRegistrations = (Hashtable<Integer, NTFRegistration>)ntfRegistrations;
        boolean b = false;
        if (remove != null) {
            b = true;
        }
        return b;
    }
    
    synchronized void freeJdbcRegId(final int n) {
        if (this.listOfJdbcRegId != null && this.listOfJdbcRegId.length > n) {
            this.listOfJdbcRegId[n] = 0;
        }
    }
    
    synchronized void cleanListenersT4C(final int n) {
        Enumeration<Integer> keys;
        int n2;
        for (keys = this.ntfRegistrations.keys(), n2 = 0; n2 == 0 && keys.hasMoreElements(); n2 = 1) {
            if (this.ntfRegistrations.get(keys.nextElement()).getClientTCPPort() == n) {}
        }
        if (n2 == 0) {
            final NTFListener ntfListener = this.nsListeners.get(n);
            if (ntfListener != null) {
                ntfListener.closeThisListener();
                ntfListener.interrupt();
                this.nsListeners.remove(n);
            }
        }
    }
    
    NTFRegistration getRegistration(final int i) {
        return this.ntfRegistrations.get(i);
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
