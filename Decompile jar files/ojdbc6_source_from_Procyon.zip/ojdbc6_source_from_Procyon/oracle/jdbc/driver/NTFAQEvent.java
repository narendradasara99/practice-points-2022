// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.aq.AQAgent;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.sql.TIMESTAMP;
import java.io.IOException;
import java.nio.ByteBuffer;
import oracle.jdbc.aq.AQNotificationEvent;

class NTFAQEvent extends AQNotificationEvent
{
    private String registrationString;
    private int namespace;
    private byte[] payload;
    private String queueName;
    private byte[] messageId;
    private String consumerName;
    private NTFConnection conn;
    private AQMessagePropertiesI msgProp;
    private EventType eventType;
    private AdditionalEventType additionalEventType;
    private ByteBuffer dataBuffer;
    private boolean isReady;
    private short databaseVersion;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFAQEvent(final NTFConnection conn, final short databaseVersion) throws IOException {
        super(conn);
        this.queueName = null;
        this.messageId = null;
        this.consumerName = null;
        this.eventType = EventType.REGULAR;
        this.additionalEventType = AdditionalEventType.NONE;
        this.isReady = false;
        this.conn = conn;
        final int int1 = this.conn.readInt();
        final byte[] array = new byte[int1];
        this.conn.readBuffer(array, 0, int1);
        this.dataBuffer = ByteBuffer.wrap(array);
        this.databaseVersion = databaseVersion;
    }
    
    private void initEvent() throws SQLException {
        this.dataBuffer.get();
        final int int1 = this.dataBuffer.getInt();
        final byte[] dst = new byte[int1];
        this.dataBuffer.get(dst, 0, int1);
        this.registrationString = this.conn.charset.toString(dst, 0, int1);
        this.dataBuffer.get();
        final int int2 = this.dataBuffer.getInt();
        final byte[] dst2 = new byte[int2];
        this.dataBuffer.get(dst2, 0, int2);
        this.namespace = dst2[0];
        this.dataBuffer.get();
        final int int3 = this.dataBuffer.getInt();
        if (int3 > 0) {
            this.payload = new byte[int3];
            this.dataBuffer.get(this.payload, 0, int3);
        }
        else {
            this.payload = null;
        }
        if (this.dataBuffer.hasRemaining()) {
            int int4 = 0;
            if (this.databaseVersion >= 10200) {
                this.dataBuffer.get();
                this.dataBuffer.getInt();
                int4 = this.dataBuffer.getInt();
            }
            this.dataBuffer.get();
            final int int5 = this.dataBuffer.getInt();
            final byte[] dst3 = new byte[int5];
            this.dataBuffer.get(dst3, 0, int5);
            this.queueName = this.conn.charset.toString(dst3, 0, int5);
            this.dataBuffer.get();
            final int int6 = this.dataBuffer.getInt();
            this.messageId = new byte[int6];
            this.dataBuffer.get(this.messageId, 0, int6);
            this.dataBuffer.get();
            final int int7 = this.dataBuffer.getInt();
            final byte[] dst4 = new byte[int7];
            this.dataBuffer.get(dst4, 0, int7);
            this.consumerName = this.conn.charset.toString(dst4, 0, int7);
            this.dataBuffer.get();
            final int int8 = this.dataBuffer.getInt();
            final byte[] dst5 = new byte[int8];
            this.dataBuffer.get(dst5, 0, int8);
            this.dataBuffer.get();
            this.dataBuffer.getInt();
            int int9 = this.dataBuffer.getInt();
            if (dst5[0] == 1) {
                int9 = -int9;
            }
            final int priority = int9;
            this.dataBuffer.get();
            this.dataBuffer.getInt();
            final int int10 = this.dataBuffer.getInt();
            this.dataBuffer.get();
            final int int11 = this.dataBuffer.getInt();
            final byte[] dst6 = new byte[int11];
            this.dataBuffer.get(dst6, 0, int11);
            this.dataBuffer.get();
            this.dataBuffer.getInt();
            int int12 = this.dataBuffer.getInt();
            if (dst6[0] == 1) {
                int12 = -int12;
            }
            final int expiration = int12;
            this.dataBuffer.get();
            this.dataBuffer.getInt();
            final int int13 = this.dataBuffer.getInt();
            this.dataBuffer.get();
            final int int14 = this.dataBuffer.getInt();
            final byte[] dst7 = new byte[int14];
            this.dataBuffer.get(dst7, 0, int14);
            final TIMESTAMP timestamp = new TIMESTAMP(dst7);
            this.dataBuffer.get();
            final int int15 = this.dataBuffer.getInt();
            final byte[] dst8 = new byte[int15];
            this.dataBuffer.get(dst8, 0, int15);
            final byte b = dst8[0];
            this.dataBuffer.get();
            final int int16 = this.dataBuffer.getInt();
            final byte[] dst9 = new byte[int16];
            this.dataBuffer.get(dst9, 0, int16);
            final String string = this.conn.charset.toString(dst9, 0, int16);
            this.dataBuffer.get();
            final int int17 = this.dataBuffer.getInt();
            final byte[] dst10 = new byte[int17];
            this.dataBuffer.get(dst10, 0, int17);
            final String string2 = this.conn.charset.toString(dst10, 0, int17);
            this.dataBuffer.get();
            final int int18 = this.dataBuffer.getInt();
            byte[] array = null;
            if (int18 > 0) {
                array = new byte[int18];
                this.dataBuffer.get(array, 0, int18);
            }
            this.dataBuffer.get();
            final int int19 = this.dataBuffer.getInt();
            final byte[] dst11 = new byte[int19];
            this.dataBuffer.get(dst11, 0, int19);
            final String string3 = this.conn.charset.toString(dst11, 0, int19);
            this.dataBuffer.get();
            final int int20 = this.dataBuffer.getInt();
            final byte[] dst12 = new byte[int20];
            this.dataBuffer.get(dst12, 0, int20);
            final String string4 = this.conn.charset.toString(dst12, 0, int20);
            this.dataBuffer.get();
            this.dataBuffer.getInt();
            final byte value = this.dataBuffer.get();
            (this.msgProp = new AQMessagePropertiesI()).setAttempts(int13);
            this.msgProp.setCorrelation(string2);
            this.msgProp.setDelay(int10);
            this.msgProp.setEnqueueTime(timestamp.timestampValue());
            this.msgProp.setMessageState(AQMessageProperties.MessageState.getMessageState(b));
            if (this.databaseVersion >= 10200) {
                this.msgProp.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(int4));
            }
            this.msgProp.setPreviousQueueMessageId(array);
            final AQAgentI sender = new AQAgentI();
            sender.setAddress(string4);
            sender.setName(string3);
            sender.setProtocol(value);
            this.msgProp.setSender(sender);
            this.msgProp.setPriority(priority);
            this.msgProp.setExpiration(expiration);
            this.msgProp.setExceptionQueue(string);
        }
        this.isReady = true;
    }
    
    @Override
    public AQMessageProperties getMessageProperties() throws SQLException {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.msgProp;
    }
    
    @Override
    public String getRegistration() throws SQLException {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.registrationString;
    }
    
    @Override
    public EventType getEventType() {
        return this.eventType;
    }
    
    @Override
    public AdditionalEventType getAdditionalEventType() {
        return this.additionalEventType;
    }
    
    void setEventType(final EventType eventType) throws IOException {
        this.eventType = eventType;
    }
    
    void setAdditionalEventType(final AdditionalEventType additionalEventType) {
        this.additionalEventType = additionalEventType;
    }
    
    @Override
    public byte[] getPayload() throws SQLException {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.payload;
    }
    
    @Override
    public String getQueueName() throws SQLException {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.queueName;
    }
    
    @Override
    public byte[] getMessageId() throws SQLException {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.messageId;
    }
    
    @Override
    public String getConsumerName() throws SQLException {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.consumerName;
    }
    
    @Override
    public String getConnectionInformation() {
        return this.conn.connectionDescription;
    }
    
    @Override
    public String toString() {
        if (!this.isReady) {
            try {
                this.initEvent();
            }
            catch (SQLException ex) {
                return ex.getMessage();
            }
        }
        final StringBuffer sb = new StringBuffer();
        sb.append("Connection information  : " + this.conn.connectionDescription + "\n");
        sb.append("Event type              : " + this.eventType + "\n");
        if (this.additionalEventType != AdditionalEventType.NONE) {
            sb.append("Additional event type   : " + this.additionalEventType + "\n");
        }
        sb.append("Namespace               : " + this.namespace + "\n");
        sb.append("Registration            : " + this.registrationString + "\n");
        sb.append("Queue name              : " + this.queueName + "\n");
        sb.append("Consumer name           : " + this.consumerName + "\n");
        if (this.payload != null) {
            sb.append("Payload length          : " + this.payload.length + "\n");
            sb.append("Payload (first 50 bytes): " + byteBufferToHexString(this.payload, 50) + "\n");
        }
        else {
            sb.append("Payload                 : null\n");
        }
        sb.append("Message ID              : " + byteBufferToHexString(this.messageId, 50) + "\n");
        if (this.msgProp != null) {
            sb.append(this.msgProp.toString());
        }
        return sb.toString();
    }
    
    static final String byteBufferToHexString(final byte[] array, final int n) {
        if (array == null) {
            return null;
        }
        int n2 = 0;
        int n3 = 1;
        final StringBuffer sb = new StringBuffer();
        while (n2 < array.length && n2 < n) {
            if (n3 == 0) {
                sb.append(' ');
            }
            else {
                n3 = 0;
            }
            String s = Integer.toHexString(array[n2] & 0xFF);
            if (s.length() == 1) {
                s = "0" + s;
            }
            sb.append(s);
            ++n2;
        }
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
