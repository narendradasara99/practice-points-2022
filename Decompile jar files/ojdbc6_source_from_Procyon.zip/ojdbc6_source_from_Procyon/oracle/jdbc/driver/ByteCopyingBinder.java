// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

abstract class ByteCopyingBinder extends Binder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    Binder copyingBinder() {
        return this;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        byte[] lastBoundBytes;
        int n10;
        int n11;
        if (n2 == 0) {
            lastBoundBytes = oraclePreparedStatement.lastBoundBytes;
            n10 = oraclePreparedStatement.lastBoundByteOffsets[n];
            array3[n9] = oraclePreparedStatement.lastBoundInds[n];
            array3[n8] = oraclePreparedStatement.lastBoundLens[n];
            if (lastBoundBytes == array && n10 == n6) {
                return;
            }
            n11 = oraclePreparedStatement.lastBoundByteLens[n];
            if (n11 > n4) {
                n11 = n4;
            }
        }
        else {
            lastBoundBytes = array;
            n10 = n6 - n4;
            array3[n9] = array3[n9 - 1];
            array3[n8] = array3[n8 - 1];
            n11 = n4;
        }
        System.arraycopy(lastBoundBytes, n10, array, n6, n11);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
