// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.oci.OracleOCIConnection;
import java.sql.Connection;
import java.util.Properties;

class T2CDriverExtension extends OracleDriverExtension
{
    static final int T2C_DEFAULT_BATCHSIZE = 1;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    Connection getConnection(final String s, final Properties properties) throws SQLException {
        T2CConnection t2CConnection;
        if (properties.getProperty("is_connection_pooling") == "true") {
            t2CConnection = new OracleOCIConnection(s, properties, (Object)this);
        }
        else {
            t2CConnection = new T2CConnection(s, properties, this);
        }
        return t2CConnection;
    }
    
    @Override
    OracleStatement allocateStatement(final PhysicalConnection physicalConnection, final int n, final int n2) throws SQLException {
        return new T2CStatement((T2CConnection)physicalConnection, 1, physicalConnection.defaultRowPrefetch, n, n2);
    }
    
    @Override
    OraclePreparedStatement allocatePreparedStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        return new T2CPreparedStatement((T2CConnection)physicalConnection, s, physicalConnection.defaultExecuteBatch, physicalConnection.defaultRowPrefetch, n, n2);
    }
    
    @Override
    OracleCallableStatement allocateCallableStatement(final PhysicalConnection physicalConnection, final String s, final int n, final int n2) throws SQLException {
        return new T2CCallableStatement((T2CConnection)physicalConnection, s, physicalConnection.defaultExecuteBatch, physicalConnection.defaultRowPrefetch, n, n2);
    }
    
    @Override
    OracleInputStream createInputStream(final OracleStatement oracleStatement, final int n, final Accessor accessor) throws SQLException {
        return new T2CInputStream(oracleStatement, n, accessor);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
