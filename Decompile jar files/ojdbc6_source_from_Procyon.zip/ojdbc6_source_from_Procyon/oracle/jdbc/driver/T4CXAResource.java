// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.OracleXAException;
import javax.sql.XAConnection;
import oracle.jdbc.xa.client.OracleXADataSource;
import java.sql.SQLException;
import java.io.IOException;
import oracle.jdbc.xa.OracleXid;
import javax.transaction.xa.Xid;
import javax.transaction.xa.XAException;
import java.sql.Connection;
import oracle.jdbc.xa.OracleXAConnection;
import oracle.jdbc.xa.client.OracleXAResource;

class T4CXAResource extends OracleXAResource
{
    T4CConnection physicalConn;
    int[] applicationValueArr;
    boolean isTransLoose;
    byte[] context;
    int errorNumber;
    private String password;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CXAResource(final T4CConnection physicalConn, final OracleXAConnection oracleXAConnection, final boolean isTransLoose) throws XAException {
        super(physicalConn, oracleXAConnection);
        this.applicationValueArr = new int[1];
        this.isTransLoose = false;
        this.physicalConn = physicalConn;
        this.isTransLoose = isTransLoose;
    }
    
    @Override
    protected int doStart(final Xid xid, int n) throws XAException {
        synchronized (this.physicalConn) {
            if (this.isTransLoose) {
                n |= 0x10000;
            }
            if ((n & 0x8200000) == 0x8000000 && OracleXid.isLocalTransaction(xid)) {
                return 0;
            }
            this.applicationValueArr[0] = 0;
            int errorCode;
            try {
                try {
                    final T4CTTIOtxse otxse = this.physicalConn.otxse;
                    byte[] array = null;
                    final byte[] globalTransactionId = xid.getGlobalTransactionId();
                    final byte[] branchQualifier = xid.getBranchQualifier();
                    int min = 0;
                    int min2 = 0;
                    if (globalTransactionId != null && branchQualifier != null) {
                        min = Math.min(globalTransactionId.length, 64);
                        min2 = Math.min(branchQualifier.length, 64);
                        array = new byte[128];
                        System.arraycopy(globalTransactionId, 0, array, 0, min);
                        System.arraycopy(branchQualifier, 0, array, min, min2);
                    }
                    final int n2 = 0;
                    int n3;
                    if ((n & 0x200000) != 0x0 || (n & 0x8000000) != 0x0) {
                        n3 = (n2 | 0x4);
                    }
                    else {
                        n3 = (n2 | 0x1);
                    }
                    if ((n & 0x100) != 0x0) {
                        n3 |= 0x100;
                    }
                    if ((n & 0x200) != 0x0) {
                        n3 |= 0x200;
                    }
                    if ((n & 0x400) != 0x0) {
                        n3 |= 0x400;
                    }
                    if ((n & 0x10000) != 0x0) {
                        n3 |= 0x10000;
                    }
                    this.physicalConn.needLine();
                    this.physicalConn.sendPiggyBackedMessages();
                    otxse.doOTXSE(1, null, array, xid.getFormatId(), min, min2, this.timeout, n3, this.applicationValueArr);
                    this.applicationValueArr[0] = otxse.getApplicationValue();
                    final byte[] context = otxse.getContext();
                    if (context != null) {
                        this.context = context;
                    }
                    errorCode = 0;
                }
                catch (IOException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            catch (SQLException ex2) {
                errorCode = ex2.getErrorCode();
                if (errorCode == 0) {
                    throw new XAException(-6);
                }
            }
            return errorCode;
        }
    }
    
    @Override
    protected int doEnd(final Xid xid, final int n, final boolean b) throws XAException {
        synchronized (this.physicalConn) {
            int errorCode;
            try {
                try {
                    final T4CTTIOtxse otxse = this.physicalConn.otxse;
                    byte[] array = null;
                    final byte[] globalTransactionId = xid.getGlobalTransactionId();
                    final byte[] branchQualifier = xid.getBranchQualifier();
                    int min = 0;
                    int min2 = 0;
                    if (globalTransactionId != null && branchQualifier != null) {
                        min = Math.min(globalTransactionId.length, 64);
                        min2 = Math.min(branchQualifier.length, 64);
                        array = new byte[128];
                        System.arraycopy(globalTransactionId, 0, array, 0, min);
                        System.arraycopy(branchQualifier, 0, array, min, min2);
                    }
                    if (this.context == null) {
                        final int doStart = this.doStart(xid, 134217728);
                        if (doStart != 0) {
                            return doStart;
                        }
                    }
                    final byte[] context = this.context;
                    int n2 = 0;
                    if ((n & 0x2) == 0x2) {
                        n2 = 1048576;
                    }
                    else if ((n & 0x2000000) == 0x2000000 && (n & 0x100000) != 0x100000) {
                        n2 = 1048576;
                    }
                    final int[] applicationValueArr = this.applicationValueArr;
                    final int n3 = 0;
                    applicationValueArr[n3] >>= 16;
                    this.physicalConn.needLine();
                    this.physicalConn.sendPiggyBackedMessages();
                    otxse.doOTXSE(2, context, array, xid.getFormatId(), min, min2, this.timeout, n2, this.applicationValueArr);
                    this.applicationValueArr[0] = otxse.getApplicationValue();
                    final byte[] context2 = otxse.getContext();
                    if (context2 != null) {
                        this.context = context2;
                    }
                    errorCode = 0;
                }
                catch (IOException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            catch (SQLException ex2) {
                errorCode = ex2.getErrorCode();
                if (errorCode == 0) {
                    throw new XAException(-6);
                }
            }
            return errorCode;
        }
    }
    
    @Override
    protected void doCommit(final Xid xid, final boolean b) throws SQLException, XAException {
        synchronized (this.physicalConn) {
            final int n = b ? 4 : 2;
            try {
                final int doTransaction = this.doTransaction(xid, 1, n);
                if (b) {
                    if (doTransaction == 2) {
                        return;
                    }
                    if (doTransaction == 4) {
                        return;
                    }
                }
                if (b || doTransaction != 5) {
                    if (doTransaction == 8) {
                        throw new XAException(106);
                    }
                    throw new XAException(-6);
                }
            }
            catch (SQLException ex) {
                final int errorCode = ex.getErrorCode();
                if (errorCode == 24756) {
                    this.kputxrec(xid, 1, this.timeout + 120, ex);
                }
                else {
                    if (errorCode != 24780) {
                        throw ex;
                    }
                    OracleXADataSource oracleXADataSource = null;
                    XAConnection xaConnection = null;
                    try {
                        oracleXADataSource = new OracleXADataSource();
                        oracleXADataSource.setURL(this.physicalConn.url);
                        oracleXADataSource.setUser(this.physicalConn.userName);
                        this.physicalConn.getPasswordInternal(this);
                        oracleXADataSource.setPassword(this.password);
                        xaConnection = oracleXADataSource.getXAConnection();
                        xaConnection.getXAResource().commit(xid, b);
                    }
                    catch (SQLException cause) {
                        final XAException ex2 = new XAException(-6);
                        ex2.initCause(cause);
                        throw ex2;
                    }
                    finally {
                        try {
                            if (xaConnection != null) {
                                xaConnection.close();
                            }
                            if (oracleXADataSource != null) {
                                oracleXADataSource.close();
                            }
                        }
                        catch (Exception ex3) {}
                    }
                }
            }
        }
    }
    
    @Override
    protected int doPrepare(final Xid xid) throws XAException, SQLException {
        synchronized (this.physicalConn) {
            int n;
            try {
                final int doTransaction = this.doTransaction(xid, 3, 0);
                if (doTransaction == 8) {
                    throw new XAException(106);
                }
                if (doTransaction == 4) {
                    n = 3;
                }
                else if (doTransaction == 1) {
                    n = 0;
                }
                else {
                    if (doTransaction == 3) {
                        throw new XAException(100);
                    }
                    throw new XAException(-6);
                }
            }
            catch (SQLException cause) {
                if (cause.getErrorCode() == 25351) {
                    final XAException ex = new XAException(-6);
                    ex.initCause(cause);
                    throw ex;
                }
                throw cause;
            }
            return n;
        }
    }
    
    @Override
    protected int doForget(final Xid xid) throws XAException, SQLException {
        synchronized (this.physicalConn) {
            final int n = -1;
            if (OracleXid.isLocalTransaction(xid)) {
                return 24771;
            }
            final int doStart = this.doStart(xid, 134217728);
            if (doStart == 24756) {
                this.kputxrec(xid, 4, 1, null);
                return n;
            }
            if (doStart == 0) {
                try {
                    this.doEnd(xid, 0, false);
                }
                catch (Exception ex) {}
            }
            if (doStart == 0 || doStart == 2079 || doStart == 24754 || doStart == 24761 || doStart == 24774 || doStart == 24776 || doStart == 25351) {
                return 24769;
            }
            if (doStart == 24752) {
                return 24771;
            }
            return doStart;
        }
    }
    
    @Override
    protected void doRollback(final Xid xid) throws XAException, SQLException {
        synchronized (this.physicalConn) {
            try {
                final int doTransaction = this.doTransaction(xid, 2, 3);
                if (doTransaction == 8) {
                    throw new XAException(106);
                }
                if (doTransaction != 3) {
                    throw new XAException(-6);
                }
            }
            catch (SQLException ex) {
                final int errorCode = ex.getErrorCode();
                if (errorCode == 24756) {
                    this.kputxrec(xid, 2, this.timeout + 120, ex);
                }
                else if (errorCode == 24780) {
                    OracleXADataSource oracleXADataSource = null;
                    XAConnection xaConnection = null;
                    try {
                        oracleXADataSource = new OracleXADataSource();
                        oracleXADataSource.setURL(this.physicalConn.url);
                        oracleXADataSource.setUser(this.physicalConn.userName);
                        this.physicalConn.getPasswordInternal(this);
                        oracleXADataSource.setPassword(this.password);
                        xaConnection = oracleXADataSource.getXAConnection();
                        xaConnection.getXAResource().rollback(xid);
                    }
                    catch (SQLException cause) {
                        final XAException ex2 = new XAException(-6);
                        ex2.initCause(cause);
                        throw ex2;
                    }
                    finally {
                        try {
                            if (xaConnection != null) {
                                xaConnection.close();
                            }
                            if (oracleXADataSource != null) {
                                oracleXADataSource.close();
                            }
                        }
                        catch (Exception ex3) {}
                    }
                }
                else if (errorCode != 25402) {
                    throw ex;
                }
            }
        }
    }
    
    int doTransaction(final Xid xid, final int n, final int n2) throws SQLException {
        int outStateFromServer;
        try {
            final T4CTTIOtxen otxen = this.physicalConn.otxen;
            byte[] array = null;
            final byte[] globalTransactionId = xid.getGlobalTransactionId();
            final byte[] branchQualifier = xid.getBranchQualifier();
            int min = 0;
            int min2 = 0;
            if (globalTransactionId != null && branchQualifier != null) {
                min = Math.min(globalTransactionId.length, 64);
                min2 = Math.min(branchQualifier.length, 64);
                array = new byte[128];
                System.arraycopy(globalTransactionId, 0, array, 0, min);
                System.arraycopy(branchQualifier, 0, array, min, min2);
            }
            final byte[] context = this.context;
            this.physicalConn.needLine();
            this.physicalConn.sendPiggyBackedMessages();
            otxen.doOTXEN(n, context, array, xid.getFormatId(), min, min2, this.timeout, n2, 0);
            outStateFromServer = otxen.getOutStateFromServer();
        }
        catch (IOException ex) {
            this.physicalConn.handleIOException(ex);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return outStateFromServer;
    }
    
    protected void kputxrec(final Xid xid, final int n, int n2, final SQLException cause) throws XAException, SQLException {
        int n3 = 0;
        switch (n) {
            case 1: {
                n3 = 3;
                break;
            }
            case 4: {
                n3 = 2;
                break;
            }
            default: {
                n3 = 0;
                break;
            }
        }
        int doTransaction = 0;
        while (n2-- > 0) {
            doTransaction = this.doTransaction(xid, 5, n3);
            if (doTransaction != 7) {
                break;
            }
            try {
                Thread.sleep(1000L);
            }
            catch (Exception ex4) {}
        }
        if (doTransaction == 7) {
            throw new XAException(-6);
        }
        int n4 = -1;
        int n5 = 0;
        switch (doTransaction) {
            case 3: {
                if (n == 1) {
                    n5 = 7;
                    break;
                }
                n5 = 8;
                n4 = -3;
                break;
            }
            case 0: {
                if (n == 4) {
                    n5 = 8;
                    n4 = -3;
                    break;
                }
                n5 = 7;
                if (n == 1) {
                    n4 = -4;
                    break;
                }
                break;
            }
            case 2: {
                if (n == 4) {
                    n5 = 8;
                    n4 = -6;
                    break;
                }
            }
            case 5: {
                if (n == 4) {
                    n5 = 7;
                    break;
                }
                n4 = 7;
                n5 = 8;
                break;
            }
            case 4: {
                if (n == 4) {
                    n5 = 7;
                    break;
                }
                n4 = 6;
                n5 = 8;
                break;
            }
            case 6: {
                if (n == 4) {
                    n5 = 7;
                    break;
                }
                n4 = 5;
                n5 = 8;
                break;
            }
            default: {
                n4 = -3;
                n5 = 8;
                break;
            }
        }
        final T4CTTIk2rpc k2rpc = this.physicalConn.k2rpc;
        try {
            k2rpc.doOK2RPC(3, n5);
        }
        catch (IOException cause2) {
            final XAException ex = new XAException(-7);
            ex.initCause(cause2);
            throw ex;
        }
        catch (SQLException cause3) {
            final XAException ex2 = new XAException(-6);
            ex2.initCause(cause3);
            throw ex2;
        }
        if (n4 != -1) {
            OracleXAException ex3;
            if (cause != null) {
                ex3 = new OracleXAException(cause.getErrorCode(), n4);
                ex3.initCause(cause);
            }
            else {
                ex3 = new OracleXAException(0, n4);
            }
            throw ex3;
        }
    }
    
    final void setPasswordInternal(final String password) {
        this.password = password;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.physicalConn;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
