// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.CharacterSet;
import oracle.sql.CHAR;
import oracle.sql.Datum;
import java.io.Serializable;
import oracle.sql.NUMBER;
import java.math.BigDecimal;
import java.sql.SQLException;

class PlsqlIndexTableAccessor extends Accessor
{
    int elementInternalType;
    int maxNumberOfElements;
    int elementMaxLen;
    int ibtValueIndex;
    int ibtIndicatorIndex;
    int ibtLengthIndex;
    int ibtMetaIndex;
    int ibtByteLength;
    int ibtCharLength;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    PlsqlIndexTableAccessor(final OracleStatement oracleStatement, final int n, final int elementInternalType, final int elementMaxLen, final int maxNumberOfElements, final short n2, final boolean b) throws SQLException {
        this.init(oracleStatement, 998, 998, n2, b);
        this.elementInternalType = elementInternalType;
        this.maxNumberOfElements = maxNumberOfElements;
        this.initForDataAccess(n, this.elementMaxLen = elementMaxLen, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int n, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        switch (this.elementInternalType) {
            case 1:
            case 96: {
                this.internalTypeMaxLength = ((OraclePreparedStatement)this.statement).maxIbtVarcharElementLength;
                if (n > this.internalTypeMaxLength) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 53);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.elementMaxLen = ((n == 0) ? this.internalTypeMaxLength : n) + 1;
                this.ibtCharLength = this.elementMaxLen * this.maxNumberOfElements;
                this.elementInternalType = 9;
                break;
            }
            case 6: {
                this.internalTypeMaxLength = 21;
                this.elementMaxLen = this.internalTypeMaxLength + 1;
                this.ibtByteLength = this.elementMaxLen * this.maxNumberOfElements;
                break;
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 97);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    Object[] getPlsqlIndexTable(final int n) throws SQLException {
        final short[] ibtBindIndicators = this.statement.ibtBindIndicators;
        final int n2 = ((ibtBindIndicators[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (ibtBindIndicators[this.ibtMetaIndex + 5] & 0xFFFF);
        int ibtValueIndex = this.ibtValueIndex;
        Serializable[] array = null;
        switch (this.elementInternalType) {
            case 9: {
                array = new String[n2];
                final char[] ibtBindChars = this.statement.ibtBindChars;
                for (int i = 0; i < n2; ++i) {
                    if (ibtBindIndicators[this.ibtIndicatorIndex + i] == -1) {
                        array[i] = null;
                    }
                    else {
                        array[i] = new String(ibtBindChars, ibtValueIndex + 1, ibtBindChars[ibtValueIndex] >> 1);
                    }
                    ibtValueIndex += this.elementMaxLen;
                }
                break;
            }
            case 6: {
                array = new BigDecimal[n2];
                final byte[] ibtBindBytes = this.statement.ibtBindBytes;
                for (int j = 0; j < n2; ++j) {
                    if (ibtBindIndicators[this.ibtIndicatorIndex + j] == -1) {
                        array[j] = null;
                    }
                    else {
                        final byte b = ibtBindBytes[ibtValueIndex];
                        final byte[] array2 = new byte[b];
                        System.arraycopy(ibtBindBytes, ibtValueIndex + 1, array2, 0, b);
                        array[j] = oracle.sql.NUMBER.toBigDecimal(array2);
                    }
                    ibtValueIndex += this.elementMaxLen;
                }
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 97);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return array;
    }
    
    @Override
    Datum[] getOraclePlsqlIndexTable(final int n) throws SQLException {
        final short[] ibtBindIndicators = this.statement.ibtBindIndicators;
        final int n2 = ((ibtBindIndicators[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (ibtBindIndicators[this.ibtMetaIndex + 5] & 0xFFFF);
        int ibtValueIndex = this.ibtValueIndex;
        Datum[] array = null;
        switch (this.elementInternalType) {
            case 9: {
                array = new CHAR[n2];
                final CharacterSet make = CharacterSet.make(2000);
                final char[] ibtBindChars = this.statement.ibtBindChars;
                for (int i = 0; i < n2; ++i) {
                    if (ibtBindIndicators[this.ibtIndicatorIndex + i] == -1) {
                        array[i] = null;
                    }
                    else {
                        final char c = ibtBindChars[ibtValueIndex];
                        final byte[] array2 = new byte[c];
                        DBConversion.javaCharsToUcs2Bytes(ibtBindChars, ibtValueIndex + 1, array2, 0, c >> 1);
                        array[i] = new CHAR(array2, make);
                    }
                    ibtValueIndex += this.elementMaxLen;
                }
                break;
            }
            case 6: {
                array = new NUMBER[n2];
                final byte[] ibtBindBytes = this.statement.ibtBindBytes;
                for (int j = 0; j < n2; ++j) {
                    if (ibtBindIndicators[this.ibtIndicatorIndex + j] == -1) {
                        array[j] = null;
                    }
                    else {
                        final byte b = ibtBindBytes[ibtValueIndex];
                        final byte[] array3 = new byte[b];
                        System.arraycopy(ibtBindBytes, ibtValueIndex + 1, array3, 0, b);
                        array[j] = new NUMBER(array3);
                    }
                    ibtValueIndex += this.elementMaxLen;
                }
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 97);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return array;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
