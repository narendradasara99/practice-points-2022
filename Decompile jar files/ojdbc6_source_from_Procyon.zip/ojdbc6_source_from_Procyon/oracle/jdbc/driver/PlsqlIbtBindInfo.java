// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

class PlsqlIbtBindInfo
{
    Object[] arrayData;
    int maxLen;
    int curLen;
    int element_internal_type;
    int elemMaxLen;
    int ibtByteLength;
    int ibtCharLength;
    int ibtValueIndex;
    int ibtIndicatorIndex;
    int ibtLengthIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    PlsqlIbtBindInfo(final Object[] arrayData, final int maxLen, final int curLen, final int element_internal_type, final int n) throws SQLException {
        this.arrayData = arrayData;
        this.maxLen = maxLen;
        this.curLen = curLen;
        switch (this.element_internal_type = element_internal_type) {
            case 1:
            case 96: {
                this.elemMaxLen = ((n == 0) ? 2 : (n + 1));
                this.ibtCharLength = this.elemMaxLen * maxLen;
                this.element_internal_type = 9;
                break;
            }
            case 6: {
                this.elemMaxLen = 22;
                this.ibtByteLength = this.elemMaxLen * maxLen;
                break;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(null, 97);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
