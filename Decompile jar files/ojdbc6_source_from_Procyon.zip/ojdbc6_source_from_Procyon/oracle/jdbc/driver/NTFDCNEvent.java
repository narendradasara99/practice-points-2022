// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.dcn.QueryChangeDescription;
import oracle.jdbc.dcn.TableChangeDescription;
import java.io.IOException;
import java.nio.ByteBuffer;
import oracle.jdbc.dcn.DatabaseChangeEvent;

class NTFDCNEvent extends DatabaseChangeEvent
{
    private int notifVersion;
    private int notifRegid;
    private EventType eventType;
    private AdditionalEventType additionalEventType;
    private String databaseName;
    private byte[] notifXid;
    private int notifScn1;
    private int notifScn2;
    private int numberOfTables;
    private NTFDCNTableChanges[] tcdesc;
    private int numberOfQueries;
    private NTFDCNQueryChanges[] qdesc;
    private long registrationId;
    private NTFConnection conn;
    private int csid;
    private boolean isReady;
    private ByteBuffer dataBuffer;
    private boolean isDeregistrationEvent;
    private short databaseVersion;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NTFDCNEvent(final NTFConnection conn, final short databaseVersion) throws IOException {
        super(conn);
        this.notifVersion = 0;
        this.notifRegid = 0;
        this.additionalEventType = AdditionalEventType.NONE;
        this.databaseName = null;
        this.notifXid = new byte[8];
        this.notifScn1 = 0;
        this.notifScn2 = 0;
        this.numberOfTables = 0;
        this.tcdesc = null;
        this.numberOfQueries = 0;
        this.qdesc = null;
        this.isReady = false;
        this.isDeregistrationEvent = false;
        this.conn = conn;
        this.csid = this.conn.charset.getOracleId();
        final int int1 = this.conn.readInt();
        final byte[] array = new byte[int1];
        this.conn.readBuffer(array, 0, int1);
        this.dataBuffer = ByteBuffer.wrap(array);
        this.databaseVersion = databaseVersion;
    }
    
    private void initEvent() {
        this.dataBuffer.get();
        final int int1 = this.dataBuffer.getInt();
        final byte[] array = new byte[int1];
        this.dataBuffer.get(array, 0, int1);
        String s = null;
        try {
            s = new String(array, "UTF-8");
        }
        catch (Exception ex) {}
        this.registrationId = Long.parseLong(s.replaceFirst("CHNF", ""));
        this.dataBuffer.get();
        final int int2 = this.dataBuffer.getInt();
        this.dataBuffer.get(new byte[int2], 0, int2);
        this.dataBuffer.get();
        this.dataBuffer.getInt();
        if (this.dataBuffer.hasRemaining()) {
            this.notifVersion = this.dataBuffer.getShort();
            this.notifRegid = this.dataBuffer.getInt();
            this.eventType = EventType.getEventType(this.dataBuffer.getInt());
            final short short1 = this.dataBuffer.getShort();
            final byte[] array2 = new byte[short1];
            this.dataBuffer.get(array2, 0, short1);
            try {
                this.databaseName = new String(array2, "UTF-8");
            }
            catch (Exception ex2) {}
            this.dataBuffer.get(this.notifXid);
            this.notifScn1 = this.dataBuffer.getInt();
            this.notifScn2 = this.dataBuffer.getShort();
            if (this.eventType == EventType.OBJCHANGE) {
                this.numberOfTables = this.dataBuffer.getShort();
                this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
                for (int i = 0; i < this.tcdesc.length; ++i) {
                    this.tcdesc[i] = new NTFDCNTableChanges(this.dataBuffer, this.csid);
                }
            }
            else if (this.eventType == EventType.QUERYCHANGE) {
                this.numberOfQueries = this.dataBuffer.getShort();
                this.qdesc = new NTFDCNQueryChanges[this.numberOfQueries];
                for (int j = 0; j < this.numberOfQueries; ++j) {
                    this.qdesc[j] = new NTFDCNQueryChanges(this.dataBuffer, this.csid);
                }
            }
        }
        this.isReady = true;
    }
    
    @Override
    public String getDatabaseName() {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.databaseName;
    }
    
    @Override
    public TableChangeDescription[] getTableChangeDescription() {
        if (!this.isReady) {
            this.initEvent();
        }
        if (this.eventType == EventType.OBJCHANGE) {
            return this.tcdesc;
        }
        return null;
    }
    
    @Override
    public QueryChangeDescription[] getQueryChangeDescription() {
        if (!this.isReady) {
            this.initEvent();
        }
        if (this.eventType == EventType.QUERYCHANGE) {
            return this.qdesc;
        }
        return null;
    }
    
    @Override
    public byte[] getTransactionId() {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.notifXid;
    }
    
    @Override
    public String getTransactionId(final boolean b) {
        if (!this.isReady) {
            this.initEvent();
        }
        int i;
        int j;
        long lng;
        if (!b) {
            i = ((this.notifXid[0] & 0xFF) << 8 | (this.notifXid[1] & 0xFF));
            j = ((this.notifXid[2] & 0xFF) << 8 | (this.notifXid[3] & 0xFF));
            lng = (((this.notifXid[4] & 0xFF) << 24 | (this.notifXid[5] & 0xFF) << 16 | (this.notifXid[6] & 0xFF) << 8 | (this.notifXid[7] & 0xFF)) & -1);
        }
        else {
            i = ((this.notifXid[1] & 0xFF) << 8 | (this.notifXid[0] & 0xFF));
            j = ((this.notifXid[3] & 0xFF) << 8 | (this.notifXid[2] & 0xFF));
            lng = (((this.notifXid[7] & 0xFF) << 24 | (this.notifXid[6] & 0xFF) << 16 | (this.notifXid[5] & 0xFF) << 8 | (this.notifXid[4] & 0xFF)) & -1);
        }
        return "" + i + "." + j + "." + lng;
    }
    
    void setEventType(final EventType eventType) throws IOException {
        if (!this.isReady) {
            this.initEvent();
        }
        this.eventType = eventType;
        if (this.eventType == EventType.DEREG) {
            this.isDeregistrationEvent = true;
        }
    }
    
    void setAdditionalEventType(final AdditionalEventType additionalEventType) {
        this.additionalEventType = additionalEventType;
    }
    
    @Override
    public EventType getEventType() {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.eventType;
    }
    
    @Override
    public AdditionalEventType getAdditionalEventType() {
        return this.additionalEventType;
    }
    
    boolean isDeregistrationEvent() {
        return this.isDeregistrationEvent;
    }
    
    @Override
    public String getConnectionInformation() {
        return this.conn.connectionDescription;
    }
    
    @Override
    public int getRegistrationId() {
        if (!this.isReady) {
            this.initEvent();
        }
        return (int)this.registrationId;
    }
    
    @Override
    public long getRegId() {
        if (!this.isReady) {
            this.initEvent();
        }
        return this.registrationId;
    }
    
    @Override
    public String toString() {
        if (!this.isReady) {
            this.initEvent();
        }
        final StringBuffer sb = new StringBuffer();
        sb.append("Connection information  : " + this.conn.connectionDescription + "\n");
        sb.append("Registration ID         : " + this.registrationId + "\n");
        sb.append("Notification version    : " + this.notifVersion + "\n");
        sb.append("Event type              : " + this.eventType + "\n");
        if (this.additionalEventType != AdditionalEventType.NONE) {
            sb.append("Additional event type   : " + this.additionalEventType + "\n");
        }
        if (this.databaseName != null) {
            sb.append("Database name           : " + this.databaseName + "\n");
        }
        final TableChangeDescription[] tableChangeDescription = this.getTableChangeDescription();
        if (tableChangeDescription != null) {
            sb.append("Table Change Description (length=" + this.numberOfTables + ")\n");
            for (int i = 0; i < tableChangeDescription.length; ++i) {
                sb.append(tableChangeDescription[i].toString());
            }
        }
        final QueryChangeDescription[] queryChangeDescription = this.getQueryChangeDescription();
        if (queryChangeDescription != null) {
            sb.append("Query Change Description (length=" + this.numberOfQueries + ")\n");
            for (int j = 0; j < queryChangeDescription.length; ++j) {
                sb.append(queryChangeDescription[j].toString());
            }
        }
        return sb.toString();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
