// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;

final class T4C8Odscrarr extends T4CTTIfun
{
    private static final byte OPERATIONFLAGS = 7;
    private static final long SQLPARSEVERSION = 2L;
    byte[] sqltext;
    T4CTTIdcb dcb;
    int cursor_id;
    int numuds;
    private static final boolean UDSARRAYO2U = true;
    private static final boolean NUMUDSO2U = true;
    OracleStatement statement;
    private Accessor[] accessors;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4C8Odscrarr(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.cursor_id = 0;
        this.numuds = 0;
        this.statement = null;
        this.setFunCode((short)98);
        this.dcb = new T4CTTIdcb(t4CConnection);
    }
    
    void doODNY(final OracleStatement statement, final int n, final Accessor[] accessors, final byte[] sqltext) throws IOException, SQLException {
        this.numuds = 0;
        this.cursor_id = statement.cursorId;
        this.statement = statement;
        if (sqltext != null && sqltext.length > 0) {
            this.sqltext = sqltext;
        }
        else {
            this.sqltext = PhysicalConnection.EMPTY_BYTE_ARRAY;
        }
        this.dcb.init(statement, n);
        this.accessors = accessors;
        this.numuds = 0;
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalUB1((short)7);
        this.meg.marshalSWORD(this.cursor_id);
        if (this.sqltext.length == 0) {
            this.meg.marshalNULLPTR();
        }
        else {
            this.meg.marshalPTR();
        }
        this.meg.marshalSB4(this.sqltext.length);
        this.meg.marshalUB4(2L);
        this.meg.marshalO2U(true);
        this.meg.marshalO2U(true);
        this.meg.marshalCHR(this.sqltext);
        this.sqltext = PhysicalConnection.EMPTY_BYTE_ARRAY;
    }
    
    Accessor[] getAccessors() {
        return this.accessors;
    }
    
    @Override
    void readRPA() throws IOException, SQLException {
        this.accessors = this.dcb.receiveCommon(this.accessors, true);
        this.numuds = this.dcb.numuds;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
