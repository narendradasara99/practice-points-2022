// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.Array;
import java.sql.Connection;
import oracle.sql.ARRAY;
import java.sql.SQLException;
import oracle.sql.ArrayDescriptor;
import java.util.Map;

class ArrayLocatorResultSet extends OracleResultSetImpl
{
    static int COUNT_UNLIMITED;
    Map map;
    long beginIndex;
    int count;
    long currentIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public ArrayLocatorResultSet(final OracleConnection oracleConnection, final ArrayDescriptor arrayDescriptor, final byte[] array, final Map map) throws SQLException {
        this(oracleConnection, arrayDescriptor, array, 0L, ArrayLocatorResultSet.COUNT_UNLIMITED, map);
    }
    
    public ArrayLocatorResultSet(final OracleConnection oracleConnection, final ArrayDescriptor arrayDescriptor, final byte[] locator, final long beginIndex, final int count, final Map map) throws SQLException {
        super((PhysicalConnection)oracleConnection, null);
        if (arrayDescriptor == null || oracleConnection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Invalid arguments");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.close_statement_on_close = true;
        this.count = count;
        this.currentIndex = 0L;
        this.beginIndex = beginIndex;
        this.map = map;
        final ARRAY array = new ARRAY(arrayDescriptor, oracleConnection, null);
        array.setLocator(locator);
        OraclePreparedStatement statement;
        if (arrayDescriptor.getBaseType() == 2002 || arrayDescriptor.getBaseType() == 2008) {
            statement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oracleConnection.prepareStatement("SELECT ROWNUM, SYS_NC_ROWINFO$ FROM TABLE( CAST(:1 AS " + arrayDescriptor.getName() + ") )")).preparedStatement;
        }
        else {
            statement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oracleConnection.prepareStatement("SELECT ROWNUM, COLUMN_VALUE FROM TABLE( CAST(:1 AS " + arrayDescriptor.getName() + ") )")).preparedStatement;
        }
        statement.setArray(1, array);
        statement.executeQuery();
        this.statement = statement;
    }
    
    @Override
    public boolean next() throws SQLException {
        synchronized (this.connection) {
            if (this.currentIndex < this.beginIndex) {
                while (this.currentIndex < this.beginIndex) {
                    ++this.currentIndex;
                    if (!super.next()) {
                        return false;
                    }
                }
                return true;
            }
            if (this.count == ArrayLocatorResultSet.COUNT_UNLIMITED) {
                return super.next();
            }
            if (this.currentIndex < this.beginIndex + this.count - 1L) {
                ++this.currentIndex;
                return super.next();
            }
            return false;
        }
    }
    
    @Override
    public Object getObject(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getObject(n, this.map);
        }
    }
    
    @Override
    public int findColumn(final String s) throws SQLException {
        synchronized (this.connection) {
            if (s.equalsIgnoreCase("index")) {
                return 1;
            }
            if (s.equalsIgnoreCase("value")) {
                return 2;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 6, "get_column_index");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    static {
        ArrayLocatorResultSet.COUNT_UNLIMITED = -1;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
