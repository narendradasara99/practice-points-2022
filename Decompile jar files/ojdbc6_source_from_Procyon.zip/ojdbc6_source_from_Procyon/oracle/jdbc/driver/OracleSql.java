// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.HashMap;
import oracle.jdbc.internal.OracleConnection;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Map;

public class OracleSql
{
    static final int UNINITIALIZED = -1;
    static final String[] EMPTY_LIST;
    DBConversion conversion;
    String originalSql;
    String parameterSql;
    String utickSql;
    String processedSql;
    String rowidSql;
    String actualSql;
    byte[] sqlBytes;
    byte sqlKind;
    int parameterCount;
    boolean currentConvertNcharLiterals;
    boolean currentProcessEscapes;
    boolean includeRowid;
    String[] parameterList;
    char[] currentParameter;
    int bindParameterCount;
    String[] bindParameterList;
    int cachedBindParameterCount;
    String[] cachedBindParameterList;
    String cachedParameterSql;
    String cachedUtickSql;
    String cachedProcessedSql;
    String cachedRowidSql;
    String cachedActualSql;
    byte[] cachedSqlBytes;
    int selectEndIndex;
    int orderByStartIndex;
    int orderByEndIndex;
    int whereStartIndex;
    int whereEndIndex;
    int forUpdateStartIndex;
    int forUpdateEndIndex;
    int[] ncharLiteralLocation;
    int lastNcharLiteralLocation;
    static final String paramPrefix = "rowid";
    int paramSuffix;
    StringBuffer stringBufferForScrollableStatement;
    private static final int cMax = 127;
    private static final int[][] TRANSITION;
    private static final int[][] ACTION;
    private static final int NO_ACTION = 0;
    private static final int DELETE_ACTION = 1;
    private static final int INSERT_ACTION = 2;
    private static final int MERGE_ACTION = 3;
    private static final int UPDATE_ACTION = 4;
    private static final int PLSQL_ACTION = 5;
    private static final int CALL_ACTION = 6;
    private static final int SELECT_ACTION = 7;
    private static final int ORDER_ACTION = 10;
    private static final int ORDER_BY_ACTION = 11;
    private static final int WHERE_ACTION = 9;
    private static final int FOR_ACTION = 12;
    private static final int FOR_UPDATE_ACTION = 13;
    private static final int OTHER_ACTION = 8;
    private static final int QUESTION_ACTION = 14;
    private static final int PARAMETER_ACTION = 15;
    private static final int END_PARAMETER_ACTION = 16;
    private static final int START_NCHAR_LITERAL_ACTION = 17;
    private static final int END_NCHAR_LITERAL_ACTION = 18;
    private static final int SAVE_DELIMITER_ACTION = 19;
    private static final int LOOK_FOR_DELIMITER_ACTION = 20;
    private static final int INITIAL_STATE = 0;
    private static final int RESTART_STATE = 66;
    private static final OracleSqlReadOnly.ODBCAction[][] ODBC_ACTION;
    private static final boolean DEBUG_CBI = false;
    int current_argument;
    int i;
    int length;
    char c;
    boolean first;
    String odbc_sql;
    StringBuffer oracle_sql;
    StringBuffer token_buffer;
    static final Map<Byte, String> sqlKindStrings;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected OracleSql(final DBConversion conversion) {
        this.sqlKind = 0;
        this.parameterCount = -1;
        this.currentConvertNcharLiterals = true;
        this.currentProcessEscapes = true;
        this.includeRowid = false;
        this.parameterList = OracleSql.EMPTY_LIST;
        this.currentParameter = null;
        this.bindParameterCount = -1;
        this.bindParameterList = null;
        this.cachedBindParameterCount = -1;
        this.cachedBindParameterList = null;
        this.selectEndIndex = -1;
        this.orderByStartIndex = -1;
        this.orderByEndIndex = -1;
        this.whereStartIndex = -1;
        this.whereEndIndex = -1;
        this.forUpdateStartIndex = -1;
        this.forUpdateEndIndex = -1;
        this.ncharLiteralLocation = new int[513];
        this.lastNcharLiteralLocation = -1;
        this.paramSuffix = 0;
        this.stringBufferForScrollableStatement = null;
        this.conversion = conversion;
    }
    
    protected void initialize(final String originalSql) throws SQLException {
        if (originalSql == null || originalSql.length() == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 104);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.originalSql = originalSql;
        this.utickSql = null;
        this.processedSql = null;
        this.rowidSql = null;
        this.actualSql = null;
        this.sqlBytes = null;
        this.sqlKind = 0;
        this.parameterCount = -1;
        this.parameterList = OracleSql.EMPTY_LIST;
        this.includeRowid = false;
        this.parameterSql = this.originalSql;
        this.bindParameterCount = -1;
        this.bindParameterList = null;
        this.cachedBindParameterCount = -1;
        this.cachedBindParameterList = null;
        this.cachedParameterSql = null;
        this.cachedActualSql = null;
        this.cachedProcessedSql = null;
        this.cachedRowidSql = null;
        this.cachedSqlBytes = null;
        this.selectEndIndex = -1;
        this.orderByStartIndex = -1;
        this.orderByEndIndex = -1;
        this.whereStartIndex = -1;
        this.whereEndIndex = -1;
        this.forUpdateStartIndex = -1;
        this.forUpdateEndIndex = -1;
    }
    
    String getOriginalSql() {
        return this.originalSql;
    }
    
    boolean setNamedParameters(final int bindParameterCount, final String[] bindParameterList) throws SQLException {
        boolean b;
        if (bindParameterCount == 0) {
            this.bindParameterCount = -1;
            b = (this.bindParameterCount != this.cachedBindParameterCount);
        }
        else {
            this.bindParameterCount = bindParameterCount;
            this.bindParameterList = bindParameterList;
            b = (this.bindParameterCount != this.cachedBindParameterCount);
            if (!b) {
                for (int i = 0; i < bindParameterCount; ++i) {
                    if (this.bindParameterList[i] != this.cachedBindParameterList[i]) {
                        b = true;
                        break;
                    }
                }
            }
            if (b) {
                if (this.bindParameterCount != this.getParameterCount()) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 197);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                final char[] charArray = this.originalSql.toCharArray();
                final StringBuffer sb = new StringBuffer();
                int n = 0;
                for (int j = 0; j < charArray.length; ++j) {
                    if (charArray[j] != '?') {
                        sb.append(charArray[j]);
                    }
                    else {
                        sb.append(this.bindParameterList[n++]);
                        sb.append("=>" + this.nextArgument());
                    }
                }
                this.parameterSql = sb.toString();
                this.actualSql = null;
                this.utickSql = null;
                this.processedSql = null;
                this.rowidSql = null;
                this.sqlBytes = null;
            }
            else {
                this.parameterSql = this.cachedParameterSql;
                this.actualSql = this.cachedActualSql;
                this.utickSql = this.cachedUtickSql;
                this.processedSql = this.cachedProcessedSql;
                this.rowidSql = this.cachedRowidSql;
                this.sqlBytes = this.cachedSqlBytes;
            }
        }
        this.cachedBindParameterList = null;
        this.cachedParameterSql = null;
        this.cachedActualSql = null;
        this.cachedUtickSql = null;
        this.cachedProcessedSql = null;
        this.cachedRowidSql = null;
        this.cachedSqlBytes = null;
        return b;
    }
    
    void resetNamedParameters() {
        this.cachedBindParameterCount = this.bindParameterCount;
        if (this.bindParameterCount != -1) {
            if (this.cachedBindParameterList == null || this.cachedBindParameterList == this.bindParameterList || this.cachedBindParameterList.length < this.bindParameterCount) {
                this.cachedBindParameterList = new String[this.bindParameterCount];
            }
            System.arraycopy(this.bindParameterList, 0, this.cachedBindParameterList, 0, this.bindParameterCount);
            this.cachedParameterSql = this.parameterSql;
            this.cachedActualSql = this.actualSql;
            this.cachedUtickSql = this.utickSql;
            this.cachedProcessedSql = this.processedSql;
            this.cachedRowidSql = this.rowidSql;
            this.cachedSqlBytes = this.sqlBytes;
            this.bindParameterCount = -1;
            this.bindParameterList = null;
            this.parameterSql = this.originalSql;
            this.actualSql = null;
            this.utickSql = null;
            this.processedSql = null;
            this.rowidSql = null;
            this.sqlBytes = null;
        }
    }
    
    String getSql(final boolean currentProcessEscapes, final boolean currentConvertNcharLiterals) throws SQLException {
        if (this.sqlKind == 0) {
            this.computeBasicInfo(this.parameterSql);
        }
        if (currentProcessEscapes != this.currentProcessEscapes || currentConvertNcharLiterals != this.currentConvertNcharLiterals) {
            if (currentConvertNcharLiterals != this.currentConvertNcharLiterals) {
                this.utickSql = null;
            }
            this.processedSql = null;
            this.rowidSql = null;
            this.actualSql = null;
            this.sqlBytes = null;
        }
        this.currentConvertNcharLiterals = currentConvertNcharLiterals;
        this.currentProcessEscapes = currentProcessEscapes;
        if (this.actualSql == null) {
            if (this.utickSql == null) {
                this.utickSql = (this.currentConvertNcharLiterals ? this.convertNcharLiterals(this.parameterSql) : this.parameterSql);
            }
            if (this.processedSql == null) {
                this.processedSql = (this.currentProcessEscapes ? this.parse(this.utickSql) : this.utickSql);
            }
            if (this.rowidSql == null) {
                this.rowidSql = (this.includeRowid ? this.addRowid(this.processedSql) : this.processedSql);
            }
            this.actualSql = this.rowidSql;
        }
        return this.actualSql;
    }
    
    String getRevisedSql() throws SQLException {
        if (this.sqlKind == 0) {
            this.computeBasicInfo(this.parameterSql);
        }
        return this.addRowid(this.removeForUpdate(this.parameterSql));
    }
    
    String removeForUpdate(String s) throws SQLException {
        if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {
            s = s.substring(0, this.orderByStartIndex);
        }
        else if (this.forUpdateStartIndex != -1) {
            s = s.substring(0, this.forUpdateStartIndex);
        }
        return s;
    }
    
    void appendForUpdate(final StringBuffer sb) throws SQLException {
        if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {
            sb.append(this.originalSql.substring(this.orderByStartIndex));
        }
        else if (this.forUpdateStartIndex != -1) {
            sb.append(this.originalSql.substring(this.forUpdateStartIndex));
        }
    }
    
    String getInsertSqlForUpdatableResultSet(final UpdatableResultSet set) throws SQLException {
        final String originalSql = this.getOriginalSql();
        final boolean generatedSqlNeedEscapeProcessing = this.generatedSqlNeedEscapeProcessing();
        if (this.stringBufferForScrollableStatement == null) {
            this.stringBufferForScrollableStatement = new StringBuffer(originalSql.length() + 100);
        }
        else {
            this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
        }
        this.stringBufferForScrollableStatement.append("insert into (");
        this.stringBufferForScrollableStatement.append(this.removeForUpdate(originalSql));
        this.stringBufferForScrollableStatement.append(") values ( ");
        for (int i = 1; i < set.getColumnCount(); ++i) {
            if (i != 1) {
                this.stringBufferForScrollableStatement.append(", ");
            }
            if (generatedSqlNeedEscapeProcessing) {
                this.stringBufferForScrollableStatement.append("?");
            }
            else {
                this.stringBufferForScrollableStatement.append(":" + this.generateParameterName());
            }
        }
        this.stringBufferForScrollableStatement.append(")");
        this.paramSuffix = 0;
        return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
    }
    
    String getRefetchSqlForScrollableResultSet(final ScrollableResultSet set, final int n) throws SQLException {
        final String revisedSql = this.getRevisedSql();
        final boolean generatedSqlNeedEscapeProcessing = this.generatedSqlNeedEscapeProcessing();
        if (this.stringBufferForScrollableStatement == null) {
            this.stringBufferForScrollableStatement = new StringBuffer(revisedSql.length() + 100);
        }
        else {
            this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
        }
        this.stringBufferForScrollableStatement.append(revisedSql);
        if (this.whereStartIndex == -1) {
            this.stringBufferForScrollableStatement.append(generatedSqlNeedEscapeProcessing ? " WHERE ( ROWID = ?" : (" WHERE ( ROWID = :" + this.generateParameterName()));
        }
        else {
            this.stringBufferForScrollableStatement.append(generatedSqlNeedEscapeProcessing ? " AND ( ROWID = ?" : (" AND ( ROWID = :" + this.generateParameterName()));
        }
        for (int i = 0; i < n - 1; ++i) {
            if (generatedSqlNeedEscapeProcessing) {
                this.stringBufferForScrollableStatement.append(" OR ROWID = ?");
            }
            else {
                this.stringBufferForScrollableStatement.append(" OR ROWID = :" + this.generateParameterName());
            }
        }
        this.stringBufferForScrollableStatement.append(" ) ");
        this.appendForUpdate(this.stringBufferForScrollableStatement);
        this.paramSuffix = 0;
        return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
    }
    
    String getUpdateSqlForUpdatableResultSet(final UpdatableResultSet set, final int n, final Object[] array, final int[] array2) throws SQLException {
        final String revisedSql = this.getRevisedSql();
        final boolean generatedSqlNeedEscapeProcessing = this.generatedSqlNeedEscapeProcessing();
        if (this.stringBufferForScrollableStatement == null) {
            this.stringBufferForScrollableStatement = new StringBuffer(revisedSql.length() + 100);
        }
        else {
            this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
        }
        this.stringBufferForScrollableStatement.append("update (");
        this.stringBufferForScrollableStatement.append(revisedSql);
        this.stringBufferForScrollableStatement.append(") set ");
        if (array != null) {
            for (int i = 0; i < n; ++i) {
                if (i > 0) {
                    this.stringBufferForScrollableStatement.append(", ");
                }
                this.stringBufferForScrollableStatement.append(set.getInternalMetadata().getColumnName(array2[i] + 1));
                if (generatedSqlNeedEscapeProcessing) {
                    this.stringBufferForScrollableStatement.append(" = ?");
                }
                else {
                    this.stringBufferForScrollableStatement.append(" = :" + this.generateParameterName());
                }
            }
        }
        this.stringBufferForScrollableStatement.append(" WHERE ");
        if (generatedSqlNeedEscapeProcessing) {
            this.stringBufferForScrollableStatement.append(" ROWID = ?");
        }
        else {
            this.stringBufferForScrollableStatement.append(" ROWID = :" + this.generateParameterName());
        }
        this.paramSuffix = 0;
        return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
    }
    
    String getDeleteSqlForUpdatableResultSet(final UpdatableResultSet set) throws SQLException {
        final String revisedSql = this.getRevisedSql();
        final boolean generatedSqlNeedEscapeProcessing = this.generatedSqlNeedEscapeProcessing();
        if (this.stringBufferForScrollableStatement == null) {
            this.stringBufferForScrollableStatement = new StringBuffer(revisedSql.length() + 100);
        }
        else {
            this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
        }
        this.stringBufferForScrollableStatement.append("delete from (");
        this.stringBufferForScrollableStatement.append(revisedSql);
        this.stringBufferForScrollableStatement.append(") where ");
        if (generatedSqlNeedEscapeProcessing) {
            this.stringBufferForScrollableStatement.append(" ROWID = ?");
        }
        else {
            this.stringBufferForScrollableStatement.append(" ROWID = :" + this.generateParameterName());
        }
        this.paramSuffix = 0;
        return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
    }
    
    final boolean generatedSqlNeedEscapeProcessing() {
        return this.parameterCount > 0 && this.parameterList == OracleSql.EMPTY_LIST;
    }
    
    byte[] getSqlBytes(final boolean b, final boolean b2) throws SQLException {
        if (this.sqlBytes == null || b != this.currentProcessEscapes) {
            this.sqlBytes = this.conversion.StringToCharBytes(this.getSql(b, b2));
        }
        return this.sqlBytes;
    }
    
    byte getSqlKind() throws SQLException {
        if (this.sqlKind == 0) {
            this.computeBasicInfo(this.parameterSql);
        }
        return this.sqlKind;
    }
    
    protected int getParameterCount() throws SQLException {
        if (this.parameterCount == -1) {
            this.computeBasicInfo(this.parameterSql);
        }
        return this.parameterCount;
    }
    
    protected String[] getParameterList() throws SQLException {
        if (this.parameterCount == -1) {
            this.computeBasicInfo(this.parameterSql);
        }
        return this.parameterList;
    }
    
    void setIncludeRowid(final boolean includeRowid) {
        if (includeRowid != this.includeRowid) {
            this.includeRowid = includeRowid;
            this.rowidSql = null;
            this.actualSql = null;
            this.sqlBytes = null;
        }
    }
    
    @Override
    public String toString() {
        return (this.parameterSql == null) ? "null" : this.parameterSql;
    }
    
    private String hexUnicode(final int n) throws SQLException {
        final String hexString = Integer.toHexString(n);
        switch (hexString.length()) {
            case 0: {
                return "\\0000";
            }
            case 1: {
                return "\\000" + hexString;
            }
            case 2: {
                return "\\00" + hexString;
            }
            case 3: {
                return "\\0" + hexString;
            }
            case 4: {
                return "\\" + hexString;
            }
            default: {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 89, "Unexpected case in OracleSql.hexUnicode: " + n);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
    }
    
    String convertNcharLiterals(final String s) throws SQLException {
        if (this.lastNcharLiteralLocation <= 2) {
            return s;
        }
        String s2 = "";
        int n = 0;
        String string;
        while (true) {
            final int beginIndex = this.ncharLiteralLocation[n++];
            final int endIndex = this.ncharLiteralLocation[n++];
            string = s2 + s.substring(beginIndex, endIndex);
            if (n >= this.lastNcharLiteralLocation) {
                break;
            }
            final int n2 = this.ncharLiteralLocation[n];
            s2 = string + "u'";
            for (int i = endIndex + 2; i < n2; ++i) {
                final char char1 = s.charAt(i);
                if (char1 == '\\') {
                    s2 += "\\\\";
                }
                else if (char1 < '\u0080') {
                    s2 += char1;
                }
                else {
                    s2 += this.hexUnicode(char1);
                }
            }
        }
        return string;
    }
    
    void computeBasicInfo(final String s) throws SQLException {
        this.parameterCount = 0;
        this.lastNcharLiteralLocation = 0;
        this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = 0;
        char c = '\0';
        int count = 0;
        int n = 0;
        final int length = s.length();
        int orderByStartIndex = -1;
        int forUpdateStartIndex = -1;
        for (int n2 = length + 1, i = 0; i < n2; ++i) {
            final char ch = (i < length) ? s.charAt(i) : ' ';
            int n3;
            if ((n3 = ch) > 127) {
                if (Character.isLetterOrDigit(ch)) {
                    n3 = 88;
                }
                else {
                    n3 = 32;
                }
            }
            switch (OracleSql.ACTION[n][n3]) {
                case 1: {
                    this.sqlKind = 2;
                    break;
                }
                case 2: {
                    this.sqlKind = 4;
                    break;
                }
                case 3: {
                    this.sqlKind = 8;
                    break;
                }
                case 4: {
                    this.sqlKind = 16;
                    break;
                }
                case 5: {
                    this.sqlKind = 32;
                    break;
                }
                case 6: {
                    this.sqlKind = 64;
                    break;
                }
                case 7: {
                    this.sqlKind = 1;
                    this.selectEndIndex = i;
                    break;
                }
                case 8: {
                    this.sqlKind = -128;
                    break;
                }
                case 9: {
                    this.whereStartIndex = i - 5;
                    this.whereEndIndex = i;
                    break;
                }
                case 10: {
                    orderByStartIndex = i - 5;
                    break;
                }
                case 11: {
                    this.orderByStartIndex = orderByStartIndex;
                    this.orderByEndIndex = i;
                    break;
                }
                case 12: {
                    forUpdateStartIndex = i - 3;
                    break;
                }
                case 13: {
                    this.forUpdateStartIndex = forUpdateStartIndex;
                    this.forUpdateEndIndex = i;
                    break;
                }
                case 14: {
                    ++this.parameterCount;
                    break;
                }
                case 15: {
                    if (this.currentParameter == null) {
                        this.currentParameter = new char[32];
                    }
                    if (count >= this.currentParameter.length) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 134, new String(this.currentParameter));
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    this.currentParameter[count++] = ch;
                    break;
                }
                case 16: {
                    if (count > 0) {
                        if (this.parameterList == OracleSql.EMPTY_LIST) {
                            this.parameterList = new String[8];
                        }
                        else if (this.parameterList.length <= this.parameterCount) {
                            final String[] parameterList = new String[this.parameterList.length * 4];
                            System.arraycopy(this.parameterList, 0, parameterList, 0, this.parameterList.length);
                            this.parameterList = parameterList;
                        }
                        this.parameterList[this.parameterCount] = new String(this.currentParameter, 0, count).intern();
                        count = 0;
                        ++this.parameterCount;
                        break;
                    }
                    break;
                }
                case 17: {
                    this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = i - 1;
                    if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
                        this.growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
                        break;
                    }
                    break;
                }
                case 18: {
                    this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = i;
                    if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
                        this.growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
                        break;
                    }
                    break;
                }
                case 19: {
                    if (ch == '[') {
                        c = ']';
                        break;
                    }
                    if (ch == '{') {
                        c = '}';
                        break;
                    }
                    if (ch == '<') {
                        c = '>';
                        break;
                    }
                    if (ch == '(') {
                        c = ')';
                        break;
                    }
                    c = ch;
                    break;
                }
                case 20: {
                    if (ch == c) {
                        ++n;
                        break;
                    }
                    break;
                }
            }
            n = OracleSql.TRANSITION[n][n3];
        }
        if (this.lastNcharLiteralLocation + 2 >= this.ncharLiteralLocation.length) {
            this.growNcharLiteralLocation(this.lastNcharLiteralLocation + 2);
        }
        this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = length;
        this.ncharLiteralLocation[this.lastNcharLiteralLocation] = length;
    }
    
    void growNcharLiteralLocation(final int n) {
        final int[] ncharLiteralLocation = new int[n];
        System.arraycopy(this.ncharLiteralLocation, 0, ncharLiteralLocation, 0, this.ncharLiteralLocation.length);
        this.ncharLiteralLocation = null;
        this.ncharLiteralLocation = ncharLiteralLocation;
    }
    
    private String addRowid(final String s) throws SQLException {
        if (this.selectEndIndex == -1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 88);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return "select rowid as \"__Oracle_JDBC_interal_ROWID__\"," + s.substring(this.selectEndIndex);
    }
    
    String parse(final String odbc_sql) throws SQLException {
        this.first = true;
        this.current_argument = 1;
        this.i = 0;
        this.odbc_sql = odbc_sql;
        this.length = this.odbc_sql.length();
        if (this.oracle_sql == null) {
            this.oracle_sql = new StringBuffer(this.length);
            this.token_buffer = new StringBuffer(32);
        }
        else {
            this.oracle_sql.ensureCapacity(this.length);
        }
        this.oracle_sql.delete(0, this.oracle_sql.length());
        this.skipSpace();
        this.handleODBC(ParseMode.NORMAL);
        if (this.i < this.length) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 33, this.i);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.oracle_sql.substring(0, this.oracle_sql.length());
    }
    
    void handleODBC(final ParseMode parseMode) throws SQLException {
        int n = (parseMode == ParseMode.NORMAL) ? 0 : 66;
        char c = '\0';
        int n2 = 0;
        while (this.i < this.length) {
            final char c2 = (this.i < this.length) ? this.odbc_sql.charAt(this.i) : ' ';
            int n3;
            if ((n3 = c2) > 127) {
                if (Character.isLetterOrDigit(c2)) {
                    n3 = 88;
                }
                else {
                    n3 = 32;
                }
            }
            switch (OracleSql.ODBC_ACTION[n][n3]) {
                case COPY: {
                    this.oracle_sql.append(c2);
                    break;
                }
                case QUESTION: {
                    this.oracle_sql.append(this.nextArgument());
                    this.oracle_sql.append(' ');
                    break;
                }
                case SAVE_DELIMITER: {
                    if (c2 == '[') {
                        c = ']';
                    }
                    else if (c2 == '{') {
                        c = '}';
                    }
                    else if (c2 == '<') {
                        c = '>';
                    }
                    else if (c2 == '(') {
                        c = ')';
                    }
                    else {
                        c = c2;
                    }
                    this.oracle_sql.append(c2);
                    break;
                }
                case LOOK_FOR_DELIMITER: {
                    if (c2 == c) {
                        ++n;
                    }
                    this.oracle_sql.append(c2);
                    break;
                }
                case FUNCTION: {
                    this.handleFunction();
                    break;
                }
                case CALL: {
                    this.handleCall();
                    break;
                }
                case TIME: {
                    this.handleTime();
                    break;
                }
                case TIMESTAMP: {
                    this.handleTimestamp();
                    break;
                }
                case DATE: {
                    this.handleDate();
                    break;
                }
                case ESCAPE: {
                    this.handleEscape();
                    break;
                }
                case SCALAR_FUNCTION: {
                    this.handleScalarFunction();
                    break;
                }
                case OUTER_JOIN: {
                    this.handleOuterJoin();
                    break;
                }
                case UNKNOWN_ESCAPE: {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, this.i);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                case END_ODBC_ESCAPE: {
                    if (parseMode == ParseMode.SCALAR) {
                        return;
                    }
                }
                case COMMA: {
                    if (parseMode == ParseMode.LOCATE_1 && n2 > 1) {
                        this.oracle_sql.append(c2);
                        break;
                    }
                    if (parseMode == ParseMode.LOCATE_1) {
                        return;
                    }
                    if (parseMode == ParseMode.LOCATE_2) {
                        break;
                    }
                    this.oracle_sql.append(c2);
                    break;
                }
                case OPEN_PAREN: {
                    if (parseMode == ParseMode.LOCATE_1) {
                        if (n2 > 0) {
                            this.oracle_sql.append(c2);
                        }
                        ++n2;
                        break;
                    }
                    if (parseMode == ParseMode.LOCATE_2) {
                        ++n2;
                        this.oracle_sql.append(c2);
                        break;
                    }
                    this.oracle_sql.append(c2);
                    break;
                }
                case CLOSE_PAREN: {
                    if (parseMode == ParseMode.LOCATE_1) {
                        --n2;
                        this.oracle_sql.append(c2);
                        break;
                    }
                    if (parseMode == ParseMode.LOCATE_2 && n2 > 1) {
                        --n2;
                        this.oracle_sql.append(c2);
                        break;
                    }
                    if (parseMode == ParseMode.LOCATE_2) {
                        ++this.i;
                        return;
                    }
                    this.oracle_sql.append(c2);
                    break;
                }
            }
            n = OracleSql.TRANSITION[n][n3];
            ++this.i;
        }
    }
    
    void handleFunction() throws SQLException {
        final boolean first = this.first;
        this.first = false;
        if (first) {
            this.oracle_sql.append("BEGIN ");
        }
        this.appendChar(this.oracle_sql, '?');
        this.skipSpace();
        if (this.c != '=') {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 33, this.i + ". Expecting \"=\" got \"" + this.c + "\"");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        ++this.i;
        this.skipSpace();
        if (!this.odbc_sql.startsWith("call", this.i)) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 33, this.i + ". Expecting \"call\"");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.i += 4;
        this.oracle_sql.append(" := ");
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
        if (first) {
            this.oracle_sql.append("; END;");
        }
    }
    
    void handleCall() throws SQLException {
        final boolean first = this.first;
        this.first = false;
        if (first) {
            this.oracle_sql.append("BEGIN ");
        }
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
        this.skipSpace();
        if (first) {
            this.oracle_sql.append("; END;");
        }
    }
    
    void handleTimestamp() throws SQLException {
        this.oracle_sql.append("TO_TIMESTAMP (");
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
        this.oracle_sql.append(", 'YYYY-MM-DD HH24:MI:SS.FF')");
    }
    
    void handleTime() throws SQLException {
        this.oracle_sql.append("TO_DATE (");
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
        this.oracle_sql.append(", 'HH24:MI:SS')");
    }
    
    void handleDate() throws SQLException {
        this.oracle_sql.append("TO_DATE (");
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
        this.oracle_sql.append(", 'YYYY-MM-DD')");
    }
    
    void handleEscape() throws SQLException {
        this.oracle_sql.append("ESCAPE ");
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
    }
    
    void handleScalarFunction() throws SQLException {
        this.token_buffer.delete(0, this.token_buffer.length());
        ++this.i;
        this.skipSpace();
        while (this.i < this.length) {
            final char char1 = this.odbc_sql.charAt(this.i);
            this.c = char1;
            if (!Character.isJavaLetterOrDigit(char1) && this.c != '?') {
                break;
            }
            this.token_buffer.append(this.c);
            ++this.i;
        }
        final String intern = this.token_buffer.substring(0, this.token_buffer.length()).toUpperCase().intern();
        if (intern == "ABS") {
            this.usingFunctionName(intern);
        }
        else if (intern == "ACOS") {
            this.usingFunctionName(intern);
        }
        else if (intern == "ASIN") {
            this.usingFunctionName(intern);
        }
        else if (intern == "ATAN") {
            this.usingFunctionName(intern);
        }
        else if (intern == "ATAN2") {
            this.usingFunctionName(intern);
        }
        else if (intern == "CEILING") {
            this.usingFunctionName("CEIL");
        }
        else if (intern == "COS") {
            this.usingFunctionName(intern);
        }
        else {
            if (intern == "COT") {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (intern == "DEGREES") {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (intern == "EXP") {
                this.usingFunctionName(intern);
            }
            else if (intern == "FLOOR") {
                this.usingFunctionName(intern);
            }
            else if (intern == "LOG") {
                this.usingFunctionName("LN");
            }
            else if (intern == "LOG10") {
                this.replacingFunctionPrefix("LOG ( 10, ");
            }
            else if (intern == "MOD") {
                this.usingFunctionName(intern);
            }
            else if (intern == "PI") {
                this.replacingFunctionPrefix("( 3.141592653589793238462643383279502884197169399375 ");
            }
            else if (intern == "POWER") {
                this.usingFunctionName(intern);
            }
            else {
                if (intern == "RADIANS") {
                    final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                    sqlException3.fillInStackTrace();
                    throw sqlException3;
                }
                if (intern == "RAND") {
                    final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                    sqlException4.fillInStackTrace();
                    throw sqlException4;
                }
                if (intern == "ROUND") {
                    this.usingFunctionName(intern);
                }
                else if (intern == "SIGN") {
                    this.usingFunctionName(intern);
                }
                else if (intern == "SIN") {
                    this.usingFunctionName(intern);
                }
                else if (intern == "SQRT") {
                    this.usingFunctionName(intern);
                }
                else if (intern == "TAN") {
                    this.usingFunctionName(intern);
                }
                else if (intern == "TRUNCATE") {
                    this.usingFunctionName("TRUNC");
                }
                else if (intern == "ASCII") {
                    this.usingFunctionName(intern);
                }
                else if (intern == "CHAR") {
                    this.usingFunctionName("CHR");
                }
                else if (intern == "CHAR_LENGTH") {
                    this.usingFunctionName("LENGTH");
                }
                else if (intern == "CHARACTER_LENGTH") {
                    this.usingFunctionName("LENGTH");
                }
                else if (intern == "CONCAT") {
                    this.usingFunctionName(intern);
                }
                else {
                    if (intern == "DIFFERENCE") {
                        final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                        sqlException5.fillInStackTrace();
                        throw sqlException5;
                    }
                    if (intern == "INSERT") {
                        final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                        sqlException6.fillInStackTrace();
                        throw sqlException6;
                    }
                    if (intern == "LCASE") {
                        this.usingFunctionName("LOWER");
                    }
                    else {
                        if (intern == "LEFT") {
                            final SQLException sqlException7 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                            sqlException7.fillInStackTrace();
                            throw sqlException7;
                        }
                        if (intern == "LENGTH") {
                            this.usingFunctionName(intern);
                        }
                        else if (intern == "LOCATE") {
                            final StringBuffer oracle_sql = this.oracle_sql;
                            this.oracle_sql = new StringBuffer();
                            this.handleODBC(ParseMode.LOCATE_1);
                            final StringBuffer oracle_sql2 = this.oracle_sql;
                            (this.oracle_sql = oracle_sql).append("INSTR(");
                            this.handleODBC(ParseMode.LOCATE_2);
                            this.oracle_sql.append(',');
                            this.oracle_sql.append(oracle_sql2);
                            this.oracle_sql.append(')');
                            this.handleODBC(ParseMode.SCALAR);
                        }
                        else if (intern == "LTRIM") {
                            this.usingFunctionName(intern);
                        }
                        else if (intern == "OCTET_LENGTH") {
                            this.usingFunctionName("LENGTHB");
                        }
                        else {
                            if (intern == "POSITION") {
                                final SQLException sqlException8 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                sqlException8.fillInStackTrace();
                                throw sqlException8;
                            }
                            if (intern == "REPEAT") {
                                final SQLException sqlException9 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                sqlException9.fillInStackTrace();
                                throw sqlException9;
                            }
                            if (intern == "REPLACE") {
                                this.usingFunctionName(intern);
                            }
                            else {
                                if (intern == "RIGHT") {
                                    final SQLException sqlException10 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                    sqlException10.fillInStackTrace();
                                    throw sqlException10;
                                }
                                if (intern == "RTRIM") {
                                    this.usingFunctionName(intern);
                                }
                                else if (intern == "SOUNDEX") {
                                    this.usingFunctionName(intern);
                                }
                                else {
                                    if (intern == "SPACE") {
                                        final SQLException sqlException11 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                        sqlException11.fillInStackTrace();
                                        throw sqlException11;
                                    }
                                    if (intern == "SUBSTRING") {
                                        this.usingFunctionName("SUBSTR");
                                    }
                                    else if (intern == "UCASE") {
                                        this.usingFunctionName("UPPER");
                                    }
                                    else if (intern == "CURRENT_DATE") {
                                        this.replacingFunctionPrefix("(CURRENT_DATE");
                                    }
                                    else {
                                        if (intern == "CURRENT_TIME") {
                                            final SQLException sqlException12 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                            sqlException12.fillInStackTrace();
                                            throw sqlException12;
                                        }
                                        if (intern == "CURRENT_TIMESTAMP") {
                                            this.replacingFunctionPrefix("(CURRENT_TIMESTAMP");
                                        }
                                        else if (intern == "CURDATE") {
                                            this.replacingFunctionPrefix("(CURRENT_DATE");
                                        }
                                        else if (intern == "CURTIME") {
                                            this.replacingFunctionPrefix("(CURRENT_TIMESTAMP");
                                        }
                                        else {
                                            if (intern == "DAYNAME") {
                                                final SQLException sqlException13 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                sqlException13.fillInStackTrace();
                                                throw sqlException13;
                                            }
                                            if (intern == "DAYOFMONTH") {
                                                this.replacingFunctionPrefix("EXTRACT ( DAY FROM ");
                                            }
                                            else {
                                                if (intern == "DAYOFWEEK") {
                                                    final SQLException sqlException14 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                    sqlException14.fillInStackTrace();
                                                    throw sqlException14;
                                                }
                                                if (intern == "DAYOFYEAR") {
                                                    final SQLException sqlException15 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                    sqlException15.fillInStackTrace();
                                                    throw sqlException15;
                                                }
                                                if (intern == "EXTRACT") {
                                                    this.usingFunctionName("EXTRACT");
                                                }
                                                else if (intern == "HOUR") {
                                                    this.replacingFunctionPrefix("EXTRACT ( HOUR FROM ");
                                                }
                                                else if (intern == "MINUTE") {
                                                    this.replacingFunctionPrefix("EXTRACT ( MINUTE FROM ");
                                                }
                                                else if (intern == "MONTH") {
                                                    this.replacingFunctionPrefix("EXTRACT ( MONTH FROM ");
                                                }
                                                else {
                                                    if (intern == "MONTHNAME") {
                                                        final SQLException sqlException16 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                        sqlException16.fillInStackTrace();
                                                        throw sqlException16;
                                                    }
                                                    if (intern == "NOW") {
                                                        this.replacingFunctionPrefix("(CURRENT_TIMESTAMP");
                                                    }
                                                    else {
                                                        if (intern == "QUARTER") {
                                                            final SQLException sqlException17 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                            sqlException17.fillInStackTrace();
                                                            throw sqlException17;
                                                        }
                                                        if (intern == "SECOND") {
                                                            this.replacingFunctionPrefix("EXTRACT ( SECOND FROM ");
                                                        }
                                                        else {
                                                            if (intern == "TIMESTAMPADD") {
                                                                final SQLException sqlException18 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                                sqlException18.fillInStackTrace();
                                                                throw sqlException18;
                                                            }
                                                            if (intern == "TIMESTAMPDIFF") {
                                                                final SQLException sqlException19 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                                sqlException19.fillInStackTrace();
                                                                throw sqlException19;
                                                            }
                                                            if (intern == "WEEK") {
                                                                final SQLException sqlException20 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                                sqlException20.fillInStackTrace();
                                                                throw sqlException20;
                                                            }
                                                            if (intern == "YEAR") {
                                                                this.replacingFunctionPrefix("EXTRACT ( YEAR FROM ");
                                                            }
                                                            else {
                                                                if (intern == "DATABASE") {
                                                                    final SQLException sqlException21 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                                    sqlException21.fillInStackTrace();
                                                                    throw sqlException21;
                                                                }
                                                                if (intern == "IFNULL") {
                                                                    this.usingFunctionName("NVL");
                                                                }
                                                                else if (intern == "USER") {
                                                                    this.replacingFunctionPrefix("(USER");
                                                                }
                                                                else {
                                                                    if (intern == "CONVERT") {
                                                                        final SQLException sqlException22 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                                        sqlException22.fillInStackTrace();
                                                                        throw sqlException22;
                                                                    }
                                                                    final SQLException sqlException23 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 34, intern);
                                                                    sqlException23.fillInStackTrace();
                                                                    throw sqlException23;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    void usingFunctionName(final String str) throws SQLException {
        this.oracle_sql.append(str);
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
    }
    
    void replacingFunctionPrefix(final String str) throws SQLException {
        this.skipSpace();
        if (this.i < this.length && (this.c = this.odbc_sql.charAt(this.i)) == '(') {
            ++this.i;
            this.oracle_sql.append(str);
            this.skipSpace();
            this.handleODBC(ParseMode.SCALAR);
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 33);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void handleOuterJoin() throws SQLException {
        this.oracle_sql.append(" ( ");
        this.skipSpace();
        this.handleODBC(ParseMode.SCALAR);
        this.oracle_sql.append(" ) ");
    }
    
    String nextArgument() {
        final String string = ":" + this.current_argument;
        ++this.current_argument;
        return string;
    }
    
    void appendChar(final StringBuffer sb, final char c) {
        if (c == '?') {
            sb.append(this.nextArgument());
        }
        else {
            sb.append(c);
        }
    }
    
    void skipSpace() {
        while (this.i < this.length && (this.c = this.odbc_sql.charAt(this.i)) == ' ') {
            ++this.i;
        }
    }
    
    String generateParameterName() {
        if (this.parameterCount == 0 || this.parameterList == null) {
            return "rowid" + this.paramSuffix++;
        }
        String string = null;
    Label_0045:
        while (true) {
            string = "rowid" + this.paramSuffix++;
            for (int i = 0; i < this.parameterList.length; ++i) {
                if (string.equals(this.parameterList[i])) {
                    continue Label_0045;
                }
            }
            break;
        }
        return string;
    }
    
    static boolean isValidPlsqlWarning(final String s) throws SQLException {
        return s.matches("('\\s*([a-zA-Z0-9:,\\(\\)\\s])*')\\s*(,\\s*'([a-zA-Z0-9:,\\(\\)\\s])*')*");
    }
    
    public static boolean isValidObjectName(final String s) throws SQLException {
        if (s.matches("([a-zA-Z]{1}\\w*(\\$|\\#)*\\w*)|(\".*)")) {
            return true;
        }
        final char[] charArray = s.toCharArray();
        final int length = charArray.length;
        if (!Character.isLetter(charArray[0])) {
            return false;
        }
        for (int i = 1; i < length; ++i) {
            if (!Character.isLetterOrDigit(charArray[i]) && charArray[i] != '$' && charArray[i] != '#' && charArray[i] != '_') {
                return false;
            }
        }
        return true;
    }
    
    public static void main(final String[] array) {
        if (array.length < 2) {
            System.err.println("ERROR: incorrect usage. OracleSql (-transition <file> | <process_escapes> <convert_nchars> { <sql> } )");
            return;
        }
        if (array[0].equals("-dump")) {
            dumpTransitionMatrix(array[1]);
            return;
        }
        final boolean equals = array[0].equals("true");
        final boolean equals2 = array[1].equals("true");
        String[] array2;
        if (array.length > 2) {
            array2 = new String[array.length - 2];
            System.arraycopy(array, 2, array2, 0, array2.length);
        }
        else {
            array2 = new String[] { "select ? from dual", "insert into dual values (?)", "delete from dual", "update dual set dummy = ?", "merge tab into dual", " select ? from dual where ? = ?", "select ?from dual where?=?for update", "select '?', n'?', q'???', q'{?}', q'{cat's}' from dual", "select'?',n'?',q'???',q'{?}',q'{cat's}'from dual", "select--line\n? from dual", "select --line\n? from dual", "--line\nselect ? from dual", " --line\nselect ? from dual", "--line\n select ? from dual", "begin proc4in4out (:x1, :x2, :x3, :x4); end;", "{CALL tkpjpn01(:pin, :pinout, :pout)}", "select :NumberBindVar as the_number from dual", "select {fn locate(bob(carol(),ted(alice,sue)), 'xfy')} from dual", "CREATE USER vijay6 IDENTIFIED BY \"vjay?\"" };
        }
        for (final String x : array2) {
            try {
                System.out.println("\n\n-----------------------");
                System.out.println(x);
                System.out.println();
                final OracleSql oracleSql = new OracleSql(null);
                oracleSql.initialize(x);
                final String sql = oracleSql.getSql(equals, equals2);
                System.out.println(OracleSql.sqlKindStrings.get(oracleSql.sqlKind) + ", " + oracleSql.parameterCount);
                final String[] parameterList = oracleSql.getParameterList();
                if (parameterList == OracleSql.EMPTY_LIST) {
                    System.out.println("parameterList is empty");
                }
                else {
                    for (int j = 0; j < parameterList.length; ++j) {
                        System.out.println("parameterList[" + j + "] = " + parameterList[j]);
                    }
                }
                if (oracleSql.lastNcharLiteralLocation == 2) {
                    System.out.println("No NCHAR literals");
                }
                else {
                    System.out.println("NCHAR Literals");
                    int k = 1;
                    while (k < oracleSql.lastNcharLiteralLocation - 1) {
                        System.out.println(sql.substring(oracleSql.ncharLiteralLocation[k++], oracleSql.ncharLiteralLocation[k++]));
                    }
                }
                System.out.println("Keywords");
                if (oracleSql.selectEndIndex == -1) {
                    System.out.println("no select");
                }
                else {
                    System.out.println("'" + sql.substring(oracleSql.selectEndIndex - 6, oracleSql.selectEndIndex) + "'");
                }
                if (oracleSql.orderByStartIndex == -1) {
                    System.out.println("no order by");
                }
                else {
                    System.out.println("'" + sql.substring(oracleSql.orderByStartIndex, oracleSql.orderByEndIndex) + "'");
                }
                if (oracleSql.whereStartIndex == -1) {
                    System.out.println("no where");
                }
                else {
                    System.out.println("'" + sql.substring(oracleSql.whereStartIndex, oracleSql.whereEndIndex) + "'");
                }
                if (oracleSql.forUpdateStartIndex == -1) {
                    System.out.println("no for update");
                }
                else {
                    System.out.println("'" + sql.substring(oracleSql.forUpdateStartIndex, oracleSql.forUpdateEndIndex) + "'");
                }
                System.out.println("\"" + sql + "\"");
                System.out.println("\"" + oracleSql.getRevisedSql() + "\"");
            }
            catch (Exception x2) {
                System.out.println(x2);
            }
        }
    }
    
    private static final void dumpTransitionMatrix(final String fileName) {
        try {
            final PrintWriter printWriter = new PrintWriter(fileName);
            printWriter.print(",");
            for (int i = 0; i < 128; ++i) {
                printWriter.print("'" + ((i < 32) ? ("0x" + Integer.toHexString(i)) : Character.toString((char)i)) + ((i < 127) ? "'," : "'"));
            }
            printWriter.println();
            final int[][] transition = OracleSqlReadOnly.TRANSITION;
            final String[] parser_STATE_NAME = OracleSqlReadOnly.PARSER_STATE_NAME;
            for (int j = 0; j < OracleSql.TRANSITION.length; ++j) {
                printWriter.print(parser_STATE_NAME[j] + ",");
                for (int k = 0; k < transition[j].length; ++k) {
                    printWriter.print(parser_STATE_NAME[transition[j][k]] + ((k < 127) ? "," : ""));
                }
                printWriter.println();
            }
            printWriter.close();
        }
        catch (Throwable x) {
            System.err.println(x);
        }
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    int getReturnParameterCount() throws SQLException {
        if (this.sqlKind == 0) {
            this.computeBasicInfo(this.parameterSql);
        }
        if ((this.sqlKind & 0x1E) == 0x0) {
            return -1;
        }
        int n = -1;
        final String upperCase = this.getOriginalSql().toUpperCase();
        final int substrPos = this.getSubstrPos(upperCase, "RETURNING");
        if (substrPos >= 0 && this.getSubstrPos(upperCase.substring(substrPos), "INTO") >= 0) {
            final char[] dst = new char[upperCase.length() - substrPos];
            upperCase.getChars(substrPos, upperCase.length(), dst, 0);
            n = 0;
            for (int i = 0; i < dst.length; ++i) {
                switch (dst[i]) {
                    case ':':
                    case '?': {
                        ++n;
                        break;
                    }
                }
            }
        }
        return n;
    }
    
    private int getSubstrPos(final String s, final String str) throws SQLException {
        int n = -1;
        final int index = s.indexOf(str);
        if (index >= 1 && Character.isWhitespace(s.charAt(index - 1))) {
            final int index2 = index + str.length();
            if (index2 < s.length() && Character.isWhitespace(s.charAt(index2))) {
                n = index;
            }
        }
        return n;
    }
    
    static {
        EMPTY_LIST = new String[0];
        TRANSITION = OracleSqlReadOnly.TRANSITION;
        ACTION = OracleSqlReadOnly.ACTION;
        ODBC_ACTION = OracleSqlReadOnly.ODBC_ACTION;
        (sqlKindStrings = new HashMap<Byte, String>()).put(0, "IS_UNINITIALIZED");
        OracleSql.sqlKindStrings.put((Byte)1, "IS_SELECT");
        OracleSql.sqlKindStrings.put((Byte)2, "IS_DELETE");
        OracleSql.sqlKindStrings.put((Byte)4, "IS_INSERT");
        OracleSql.sqlKindStrings.put((Byte)8, "IS_MERGE");
        OracleSql.sqlKindStrings.put((Byte)16, "IS_UPDATE");
        OracleSql.sqlKindStrings.put((Byte)32, "IS_PLSQL_BLOCK");
        OracleSql.sqlKindStrings.put((Byte)64, "IS_CALL_BLOCK");
        OracleSql.sqlKindStrings.put((Byte)(-128), "IS_OTHER");
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    enum ParseMode
    {
        NORMAL, 
        SCALAR, 
        LOCATE_1, 
        LOCATE_2;
    }
}
