// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValue;

class T4CTTIkvarr extends T4CTTIMsg
{
    KeywordValue[] kpdkvarrptr;
    long kpdkvarrflg;
    
    T4CTTIkvarr(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)0);
        this.kpdkvarrptr = null;
    }
    
    void unmarshal() throws SQLException, IOException {
        final int n = (int)this.meg.unmarshalUB4();
        final byte b = (byte)this.meg.unmarshalUB1();
        if (n > 0) {
            this.kpdkvarrptr = new KeywordValueI[n];
            for (int i = 0; i < n; ++i) {
                this.kpdkvarrptr[i] = KeywordValueI.unmarshal(this.meg);
            }
            this.connection.updateSessionProperties(this.kpdkvarrptr);
        }
        else {
            this.kpdkvarrptr = null;
        }
        this.kpdkvarrflg = this.meg.unmarshalUB4();
    }
}
