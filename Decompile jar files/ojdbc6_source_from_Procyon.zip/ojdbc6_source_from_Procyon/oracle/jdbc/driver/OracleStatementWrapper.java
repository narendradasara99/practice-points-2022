// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.OracleResultSetCache;
import java.sql.SQLWarning;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleCallableStatement;
import oracle.jdbc.internal.OracleStatement;

class OracleStatementWrapper implements OracleStatement
{
    private Object forEquals;
    protected OracleStatement statement;
    static final OracleCallableStatement closedStatement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleStatementWrapper(final oracle.jdbc.OracleStatement forEquals) throws SQLException {
        this.forEquals = forEquals;
        this.statement = (OracleStatement)forEquals;
        ((oracle.jdbc.driver.OracleStatement)forEquals).wrapper = this;
    }
    
    @Override
    public void close() throws SQLException {
        this.statement.close();
        this.statement = OracleStatementWrapper.closedStatement;
    }
    
    @Override
    public void closeWithKey(final String s) throws SQLException {
        this.statement.closeWithKey(s);
        this.statement = OracleStatementWrapper.closedStatement;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o != null && this.getClass() == o.getClass() && this.forEquals == ((OracleStatementWrapper)o).forEquals;
    }
    
    @Override
    public int hashCode() {
        return this.forEquals.hashCode();
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        return this.statement.getFetchDirection();
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        return this.statement.getFetchSize();
    }
    
    @Override
    public int getMaxFieldSize() throws SQLException {
        return this.statement.getMaxFieldSize();
    }
    
    @Override
    public int getMaxRows() throws SQLException {
        return this.statement.getMaxRows();
    }
    
    @Override
    public int getQueryTimeout() throws SQLException {
        return this.statement.getQueryTimeout();
    }
    
    @Override
    public int getResultSetConcurrency() throws SQLException {
        return this.statement.getResultSetConcurrency();
    }
    
    @Override
    public int getResultSetHoldability() throws SQLException {
        return this.statement.getResultSetHoldability();
    }
    
    @Override
    public int getResultSetType() throws SQLException {
        return this.statement.getResultSetType();
    }
    
    @Override
    public int getUpdateCount() throws SQLException {
        return this.statement.getUpdateCount();
    }
    
    @Override
    public void cancel() throws SQLException {
        this.statement.cancel();
    }
    
    @Override
    public void clearBatch() throws SQLException {
        this.statement.clearBatch();
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        this.statement.clearWarnings();
    }
    
    @Override
    public boolean getMoreResults() throws SQLException {
        return this.statement.getMoreResults();
    }
    
    @Override
    public int[] executeBatch() throws SQLException {
        return this.statement.executeBatch();
    }
    
    @Override
    public void setFetchDirection(final int fetchDirection) throws SQLException {
        this.statement.setFetchDirection(fetchDirection);
    }
    
    @Override
    public void setFetchSize(final int fetchSize) throws SQLException {
        this.statement.setFetchSize(fetchSize);
    }
    
    @Override
    public void setMaxFieldSize(final int maxFieldSize) throws SQLException {
        this.statement.setMaxFieldSize(maxFieldSize);
    }
    
    @Override
    public void setMaxRows(final int maxRows) throws SQLException {
        this.statement.setMaxRows(maxRows);
    }
    
    @Override
    public void setQueryTimeout(final int queryTimeout) throws SQLException {
        this.statement.setQueryTimeout(queryTimeout);
    }
    
    @Override
    public boolean getMoreResults(final int n) throws SQLException {
        return this.statement.getMoreResults(n);
    }
    
    @Override
    public void setEscapeProcessing(final boolean escapeProcessing) throws SQLException {
        this.statement.setEscapeProcessing(escapeProcessing);
    }
    
    @Override
    public int executeUpdate(final String s) throws SQLException {
        return this.statement.executeUpdate(s);
    }
    
    @Override
    public void addBatch(final String s) throws SQLException {
        this.statement.addBatch(s);
    }
    
    @Override
    public void setCursorName(final String cursorName) throws SQLException {
        this.statement.setCursorName(cursorName);
    }
    
    @Override
    public boolean execute(final String s) throws SQLException {
        return this.statement.execute(s);
    }
    
    @Override
    public int executeUpdate(final String s, final int n) throws SQLException {
        return this.statement.executeUpdate(s, n);
    }
    
    @Override
    public boolean execute(final String s, final int n) throws SQLException {
        return this.statement.execute(s, n);
    }
    
    @Override
    public int executeUpdate(final String s, final int[] array) throws SQLException {
        return this.statement.executeUpdate(s, array);
    }
    
    @Override
    public boolean execute(final String s, final int[] array) throws SQLException {
        return this.statement.execute(s, array);
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        return this.statement.getConnection();
    }
    
    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        return this.statement.getGeneratedKeys();
    }
    
    @Override
    public ResultSet getResultSet() throws SQLException {
        return this.statement.getResultSet();
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return this.statement.getWarnings();
    }
    
    @Override
    public int executeUpdate(final String s, final String[] array) throws SQLException {
        return this.statement.executeUpdate(s, array);
    }
    
    @Override
    public boolean execute(final String s, final String[] array) throws SQLException {
        return this.statement.execute(s, array);
    }
    
    @Override
    public ResultSet executeQuery(final String s) throws SQLException {
        return this.statement.executeQuery(s);
    }
    
    @Override
    public void clearDefines() throws SQLException {
        this.statement.clearDefines();
    }
    
    @Override
    public void defineColumnType(final int n, final int n2) throws SQLException {
        this.statement.defineColumnType(n, n2);
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final int n3) throws SQLException {
        this.statement.defineColumnType(n, n2, n3);
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final int n3, final short n4) throws SQLException {
        this.statement.defineColumnType(n, n2, n3, n4);
    }
    
    @Override
    public void defineColumnTypeBytes(final int n, final int n2, final int n3) throws SQLException {
        this.statement.defineColumnTypeBytes(n, n2, n3);
    }
    
    @Override
    public void defineColumnTypeChars(final int n, final int n2, final int n3) throws SQLException {
        this.statement.defineColumnTypeChars(n, n2, n3);
    }
    
    @Override
    public void defineColumnType(final int n, final int n2, final String s) throws SQLException {
        this.statement.defineColumnType(n, n2, s);
    }
    
    @Override
    public int getRowPrefetch() {
        return this.statement.getRowPrefetch();
    }
    
    @Override
    public void setResultSetCache(final OracleResultSetCache resultSetCache) throws SQLException {
        this.statement.setResultSetCache(resultSetCache);
    }
    
    @Override
    public void setRowPrefetch(final int rowPrefetch) throws SQLException {
        this.statement.setRowPrefetch(rowPrefetch);
    }
    
    @Override
    public int getLobPrefetchSize() {
        return this.statement.getLobPrefetchSize();
    }
    
    @Override
    public void setLobPrefetchSize(final int lobPrefetchSize) throws SQLException {
        this.statement.setLobPrefetchSize(lobPrefetchSize);
    }
    
    @Override
    public int creationState() {
        return this.statement.creationState();
    }
    
    @Override
    public boolean isNCHAR(final int n) throws SQLException {
        return this.statement.isNCHAR(n);
    }
    
    @Override
    public void setDatabaseChangeRegistration(final DatabaseChangeRegistration databaseChangeRegistration) throws SQLException {
        this.statement.setDatabaseChangeRegistration(databaseChangeRegistration);
    }
    
    @Override
    public boolean isClosed() throws SQLException {
        return this.statement.isClosed();
    }
    
    @Override
    public boolean isPoolable() throws SQLException {
        return this.statement.isPoolable();
    }
    
    @Override
    public void setPoolable(final boolean poolable) throws SQLException {
        this.statement.setPoolable(poolable);
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public void setFixedString(final boolean fixedString) {
        this.statement.setFixedString(fixedString);
    }
    
    @Override
    public boolean getFixedString() {
        return this.statement.getFixedString();
    }
    
    @Override
    public int sendBatch() throws SQLException {
        return this.statement.sendBatch();
    }
    
    @Override
    public boolean getserverCursor() {
        return this.statement.getserverCursor();
    }
    
    @Override
    public int getcacheState() {
        return this.statement.getcacheState();
    }
    
    @Override
    public int getstatementType() {
        return this.statement.getstatementType();
    }
    
    @Override
    public String[] getRegisteredTableNames() throws SQLException {
        return this.statement.getRegisteredTableNames();
    }
    
    @Override
    public long getRegisteredQueryId() throws SQLException {
        return this.statement.getRegisteredQueryId();
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        closedStatement = new OracleClosedStatement();
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
