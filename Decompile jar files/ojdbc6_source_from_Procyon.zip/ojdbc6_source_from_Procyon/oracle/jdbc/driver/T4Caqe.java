// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.aq.AQEnqueueOptions;

final class T4Caqe extends T4CTTIfun
{
    static final int KPD_AQ_BUFMSG = 2;
    static final int KPD_AQ_EITHER = 16;
    static final int OCI_COMMIT_ON_SUCCESS = 32;
    static final int ATTR_TRANSFORMATION = 196;
    T4CTTIaqm aqm;
    T4Ctoh toh;
    private byte[] queueNameBytes;
    private AQEnqueueOptions enqueueOptions;
    private AQMessagePropertiesI messageProperties;
    private byte[] messageData;
    private byte[] messageOid;
    private boolean isRawQueue;
    private int nbExtensions;
    private byte[][] extensionTextValues;
    private byte[][] extensionBinaryValues;
    private int[] extensionKeywords;
    private AQAgentI[] attrRecipientList;
    private byte[][] recipientTextValues;
    private byte[][] recipientBinaryValues;
    private int[] recipientKeywords;
    private byte[] aqmcorBytes;
    private byte[] aqmeqnBytes;
    private boolean retrieveMessageId;
    private byte[] outMsgid;
    private byte[] senderAgentName;
    private byte[] senderAgentAddress;
    private byte senderAgentProtocol;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4Caqe(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.queueNameBytes = null;
        this.enqueueOptions = null;
        this.messageProperties = null;
        this.messageData = null;
        this.messageOid = null;
        this.isRawQueue = false;
        this.nbExtensions = 0;
        this.extensionTextValues = null;
        this.extensionBinaryValues = null;
        this.extensionKeywords = null;
        this.attrRecipientList = null;
        this.recipientTextValues = null;
        this.recipientBinaryValues = null;
        this.recipientKeywords = null;
        this.retrieveMessageId = false;
        this.outMsgid = null;
        this.senderAgentName = null;
        this.senderAgentAddress = null;
        this.senderAgentProtocol = 0;
        this.setFunCode((short)121);
        this.toh = new T4Ctoh();
        this.aqm = new T4CTTIaqm(this.connection, this.toh);
    }
    
    void doOAQEQ(final String s, final AQEnqueueOptions enqueueOptions, final AQMessagePropertiesI messageProperties, final byte[] messageData, final byte[] messageOid, final boolean isRawQueue) throws SQLException, IOException {
        this.enqueueOptions = enqueueOptions;
        this.messageProperties = messageProperties;
        final String correlation = this.messageProperties.getCorrelation();
        if (correlation != null && correlation.length() != 0) {
            this.aqmcorBytes = this.meg.conv.StringToCharBytes(correlation);
        }
        else {
            this.aqmcorBytes = null;
        }
        final String exceptionQueue = this.messageProperties.getExceptionQueue();
        if (exceptionQueue != null && exceptionQueue.length() != 0) {
            this.aqmeqnBytes = this.meg.conv.StringToCharBytes(exceptionQueue);
        }
        else {
            this.aqmeqnBytes = null;
        }
        final AQAgentI aqAgentI = (AQAgentI)this.messageProperties.getSender();
        if (aqAgentI != null) {
            if (aqAgentI.getName() != null) {
                this.senderAgentName = this.meg.conv.StringToCharBytes(aqAgentI.getName());
            }
            else {
                this.senderAgentName = null;
            }
            if (aqAgentI.getAddress() != null) {
                this.senderAgentAddress = this.meg.conv.StringToCharBytes(aqAgentI.getAddress());
            }
            else {
                this.senderAgentAddress = null;
            }
            this.senderAgentProtocol = (byte)aqAgentI.getProtocol();
        }
        else {
            this.senderAgentName = null;
            this.senderAgentAddress = null;
            this.senderAgentProtocol = 0;
        }
        this.messageData = messageData;
        this.messageOid = messageOid;
        this.isRawQueue = isRawQueue;
        if (s != null && s.length() != 0) {
            this.queueNameBytes = this.meg.conv.StringToCharBytes(s);
        }
        else {
            this.queueNameBytes = null;
        }
        this.attrRecipientList = (AQAgentI[])this.messageProperties.getRecipientList();
        if (this.attrRecipientList != null && this.attrRecipientList.length > 0) {
            this.recipientTextValues = new byte[this.attrRecipientList.length * 3][];
            this.recipientBinaryValues = new byte[this.attrRecipientList.length * 3][];
            this.recipientKeywords = new int[this.attrRecipientList.length * 3];
            for (int i = 0; i < this.attrRecipientList.length; ++i) {
                if (this.attrRecipientList[i].getName() != null) {
                    this.recipientTextValues[3 * i] = this.meg.conv.StringToCharBytes(this.attrRecipientList[i].getName());
                }
                if (this.attrRecipientList[i].getAddress() != null) {
                    this.recipientTextValues[3 * i + 1] = this.meg.conv.StringToCharBytes(this.attrRecipientList[i].getAddress());
                }
                (this.recipientBinaryValues[3 * i + 2] = new byte[1])[0] = (byte)this.attrRecipientList[i].getProtocol();
                this.recipientKeywords[3 * i] = 3 * i;
                this.recipientKeywords[3 * i + 1] = 3 * i + 1;
                this.recipientKeywords[3 * i + 2] = 3 * i + 2;
            }
        }
        final String transformation = this.enqueueOptions.getTransformation();
        if (transformation != null && transformation.length() > 0) {
            this.nbExtensions = 1;
            this.extensionTextValues = new byte[this.nbExtensions][];
            this.extensionBinaryValues = new byte[this.nbExtensions][];
            this.extensionKeywords = new int[this.nbExtensions];
            this.extensionTextValues[0] = this.meg.conv.StringToCharBytes(transformation);
            this.extensionBinaryValues[0] = null;
            this.extensionKeywords[0] = 196;
        }
        else {
            this.nbExtensions = 0;
        }
        this.outMsgid = null;
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.queueNameBytes.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.aqm.initToDefaultValues();
        this.aqm.aqmpri = this.messageProperties.getPriority();
        this.aqm.aqmdel = this.messageProperties.getDelay();
        this.aqm.aqmexp = this.messageProperties.getExpiration();
        this.aqm.aqmcorBytes = this.aqmcorBytes;
        this.aqm.aqmeqnBytes = this.aqmeqnBytes;
        this.aqm.senderAgentName = this.senderAgentName;
        this.aqm.senderAgentAddress = this.senderAgentAddress;
        this.aqm.senderAgentProtocol = this.senderAgentProtocol;
        this.aqm.originalMsgId = this.messageProperties.getPreviousQueueMessageId();
        this.aqm.marshal();
        final AQAgentI[] array = (AQAgentI[])this.messageProperties.getRecipientList();
        if (array != null && array.length > 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(array.length * 3);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalSB4(this.enqueueOptions.getVisibility().getCode());
        boolean b = false;
        if (this.enqueueOptions.getRelativeMessageId() != null && this.enqueueOptions.getRelativeMessageId().length > 0) {
            b = true;
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.enqueueOptions.getRelativeMessageId().length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalSWORD(this.enqueueOptions.getSequenceDeviation().getCode());
        this.meg.marshalPTR();
        this.meg.marshalSWORD(16);
        this.meg.marshalUB2(1);
        if (!this.isRawQueue) {
            this.meg.marshalPTR();
            this.meg.marshalNULLPTR();
            this.meg.marshalUB4(0L);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalPTR();
            this.meg.marshalUB4(this.messageData.length);
        }
        if (this.enqueueOptions.getRetrieveMessageId()) {
            this.retrieveMessageId = true;
            this.meg.marshalPTR();
            this.meg.marshalSWORD(16);
        }
        else {
            this.retrieveMessageId = false;
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        int n = 0;
        if (this.connection.autocommit) {
            n = 32;
        }
        if (this.enqueueOptions.getDeliveryMode() == AQEnqueueOptions.DeliveryMode.BUFFERED) {
            n |= 0x2;
        }
        this.meg.marshalUB4(n);
        this.meg.marshalNULLPTR();
        this.meg.marshalNULLPTR();
        if (this.nbExtensions > 0) {
            this.meg.marshalPTR();
            this.meg.marshalSWORD(this.nbExtensions);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
        }
        this.meg.marshalNULLPTR();
        this.meg.marshalSWORD(0);
        this.meg.marshalNULLPTR();
        this.meg.marshalSWORD(0);
        this.meg.marshalNULLPTR();
        if (this.connection.getTTCVersion() >= 4) {
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
            this.meg.marshalNULLPTR();
            this.meg.marshalSWORD(0);
            this.meg.marshalNULLPTR();
            this.meg.marshalNULLPTR();
        }
        if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
            this.meg.marshalCHR(this.queueNameBytes);
        }
        if (array != null && array.length > 0) {
            this.meg.marshalKPDKV(this.recipientTextValues, this.recipientBinaryValues, this.recipientKeywords);
        }
        if (b) {
            this.meg.marshalB1Array(this.enqueueOptions.getRelativeMessageId());
        }
        this.meg.marshalB1Array(this.messageOid);
        if (!this.isRawQueue) {
            this.toh.init(this.messageOid, this.messageData.length);
            this.toh.marshal(this.meg);
            this.meg.marshalCLR(this.messageData, 0, this.messageData.length);
        }
        else {
            this.meg.marshalB1Array(this.messageData);
        }
        if (this.nbExtensions > 0) {
            this.meg.marshalKPDKV(this.extensionTextValues, this.extensionBinaryValues, this.extensionKeywords);
        }
    }
    
    byte[] getMessageId() {
        return this.outMsgid;
    }
    
    @Override
    void readRPA() throws SQLException, IOException {
        if (this.retrieveMessageId) {
            this.outMsgid = new byte[16];
            this.meg.unmarshalBuffer(this.outMsgid, 0, 16);
        }
        this.meg.unmarshalUB2();
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
