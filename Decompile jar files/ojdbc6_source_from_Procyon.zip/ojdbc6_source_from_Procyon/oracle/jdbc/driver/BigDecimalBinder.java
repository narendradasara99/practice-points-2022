// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.core.lmx.CoreException;
import java.math.BigDecimal;

class BigDecimalBinder extends VarnumBinder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) throws SQLException {
        final int n10 = n6 + 1;
        final BigDecimal bigDecimal = oraclePreparedStatement.parameterBigDecimal[n3][n];
        String s = bigDecimal.toString();
        final int index;
        if ((index = s.indexOf("E")) != -1) {
            final StringBuffer sb = new StringBuffer(s.length() + 5);
            final int beginIndex = (s.charAt(0) == '-') ? 1 : 0;
            final String substring = s.substring(index + 1);
            final BigDecimal bigDecimal2 = new BigDecimal(s.substring(beginIndex, index));
            final boolean b2 = substring.charAt(0) == '-';
            int int1 = Integer.parseInt(substring.substring(1));
            String str = bigDecimal2.toString();
            final int index2 = str.indexOf(".");
            int length;
            int n11 = length = str.length();
            if (index2 != -1) {
                str = str.substring(0, index2) + str.substring(index2 + 1);
                --n11;
                if (b2) {
                    int1 -= index2;
                }
                else {
                    length = ++int1;
                }
            }
            else if (b2) {
                int1 -= n11;
            }
            else {
                length = ++int1;
            }
            if (beginIndex != 0) {
                sb.append("-");
            }
            if (b2) {
                sb.append("0.");
                for (int i = 0; i < int1; ++i) {
                    sb.append("0");
                }
                sb.append(str);
            }
            else {
                for (int n12 = (int1 > n11) ? int1 : n11, j = 0; j < n12; ++j) {
                    if (length == j) {
                        sb.append(".");
                    }
                    sb.append((n11 > j) ? str.charAt(j) : '0');
                }
            }
            s = sb.toString();
        }
        final int length2 = s.length();
        int index3 = s.indexOf(46);
        int index4;
        final int n13 = index4 = ((s.charAt(0) == 45) ? 1 : 0);
        int n14 = 2;
        if (index3 == -1) {
            index3 = length2;
        }
        else if ((length2 - index3 & 0x1) != 0x0) {}
        char char1;
        while (index4 < length2 && ((char1 = s.charAt(index4)) < '1' || char1 > '9')) {
            ++index4;
        }
        int n15;
        if (index4 >= length2) {
            array[n10] = -128;
            n15 = 1;
        }
        else {
            int n16;
            if (index4 < index3) {
                n16 = 2 - (index3 - index4 & 0x1);
            }
            else {
                n16 = 1 + (index4 - index3 & 0x1);
            }
            final int n17 = (index3 - index4 - 1) / 2;
            if (n17 > 62) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)3) + " trying to bind " + bigDecimal);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (n17 < -65) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, CoreException.getMessage((byte)2) + " trying to bind " + bigDecimal);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            int n18 = index4 + n16 + 38;
            if (n18 > length2) {
                n18 = length2;
            }
            for (int k = index4 + n16; k < n18; k += 2) {
                if (k == index3) {
                    --k;
                    if (n18 < length2) {
                        ++n18;
                    }
                }
                else if (s.charAt(k) != '0' || (k + 1 < length2 && s.charAt(k + 1) != '0')) {
                    n14 = (k - index4 - n16) / 2 + 3;
                }
            }
            int l = n10 + 2;
            int n19 = index4 + n16;
            if (n13 == 0) {
                array[n10] = (byte)(192 + n17 + 1);
                int n20 = s.charAt(index4) - '0';
                if (n16 == 2) {
                    n20 = n20 * 10 + ((index4 + 1 < length2) ? (s.charAt(index4 + 1) - '0') : 0);
                }
                array[n10 + 1] = (byte)(n20 + 1);
                while (l < n10 + n14) {
                    if (n19 == index3) {
                        ++n19;
                    }
                    int n21 = (s.charAt(n19) - '0') * 10;
                    if (n19 + 1 < length2) {
                        n21 += s.charAt(n19 + 1) - '0';
                    }
                    array[l++] = (byte)(n21 + 1);
                    n19 += 2;
                }
            }
            else {
                array[n10] = (byte)(62 - n17);
                int n22 = s.charAt(index4) - '0';
                if (n16 == 2) {
                    n22 = n22 * 10 + ((index4 + 1 < length2) ? (s.charAt(index4 + 1) - '0') : 0);
                }
                array[n10 + 1] = (byte)(101 - n22);
                while (l < n10 + n14) {
                    if (n19 == index3) {
                        ++n19;
                    }
                    int n23 = (s.charAt(n19) - '0') * 10;
                    if (n19 + 1 < length2) {
                        n23 += s.charAt(n19 + 1) - '0';
                    }
                    array[l++] = (byte)(101 - n23);
                    n19 += 2;
                }
                if (n14 < 21) {
                    array[n10 + n14++] = 102;
                }
            }
            n15 = n14;
        }
        array[n6] = (byte)n15;
        array3[n9] = 0;
        array3[n8] = (short)(n15 + 1);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
