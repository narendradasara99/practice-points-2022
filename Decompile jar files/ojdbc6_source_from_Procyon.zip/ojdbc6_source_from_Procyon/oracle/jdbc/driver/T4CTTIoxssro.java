// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import java.io.IOException;
import oracle.jdbc.internal.KeywordValueLong;

final class T4CTTIoxssro extends T4CTTIfun
{
    private int functionId;
    private byte[] sessionId;
    private KeywordValueLong[] inKV;
    private int inFlags;
    private KeywordValueLong[] outKV;
    private int outFlags;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIoxssro(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.sessionId = null;
        this.inKV = null;
        this.outKV = null;
        this.outFlags = -1;
        this.setFunCode((short)156);
    }
    
    void doOXSSRO(final int functionId, final byte[] sessionId, final KeywordValueLong[] inKV, final int inFlags) throws IOException, SQLException {
        this.functionId = functionId;
        this.sessionId = sessionId;
        this.inKV = inKV;
        this.inFlags = inFlags;
        this.outKV = null;
        this.outFlags = -1;
        if (this.inKV != null) {
            for (int i = 0; i < this.inKV.length; ++i) {
                ((KeywordValueLongI)this.inKV[i]).doCharConversion(this.meg.conv);
            }
        }
        this.doRPC();
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalUB4(this.functionId);
        boolean b = false;
        if (this.sessionId != null && this.sessionId.length > 0) {
            b = true;
            this.meg.marshalPTR();
            this.meg.marshalUB4(this.sessionId.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalUB4(0L);
        }
        boolean b2 = false;
        if (this.inKV != null && this.inKV.length > 0) {
            b2 = true;
            this.meg.marshalPTR();
            this.meg.marshalUB4(this.inKV.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalUB4(0L);
        }
        this.meg.marshalUB4(this.inFlags);
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        this.meg.marshalPTR();
        if (b) {
            this.meg.marshalB1Array(this.sessionId);
        }
        if (b2) {
            for (int i = 0; i < this.inKV.length; ++i) {
                ((KeywordValueLongI)this.inKV[i]).marshal(this.meg);
            }
        }
    }
    
    KeywordValueLong[] getOutKV() {
        return this.outKV;
    }
    
    int getOutFlags() {
        return this.outFlags;
    }
    
    @Override
    void readRPA() throws SQLException, IOException {
        final int n = (int)this.meg.unmarshalUB4();
        this.outKV = new KeywordValueLong[n];
        for (int i = 0; i < n; ++i) {
            this.outKV[i] = KeywordValueLongI.unmarshal(this.meg);
        }
        this.outFlags = (int)this.meg.unmarshalUB4();
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
