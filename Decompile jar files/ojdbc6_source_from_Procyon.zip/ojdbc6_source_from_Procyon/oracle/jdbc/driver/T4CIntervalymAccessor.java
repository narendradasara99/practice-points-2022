// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

class T4CIntervalymAccessor extends IntervalymAccessor
{
    T4CMAREngine mare;
    static int maxLength;
    final int[] meta;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CIntervalymAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, T4CIntervalymAccessor.maxLength, n2, n3, b);
        this.meta = new int[1];
        this.mare = mare;
    }
    
    T4CIntervalymAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, T4CIntervalymAccessor.maxLength, b, n2, n3, n4, n5, n6, n7);
        this.meta = new int[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        if (this.rowSpaceIndicator == null) {
            this.mare.unmarshalCLR(new byte[16000], 0, this.meta);
            this.processIndicator(this.meta[0]);
            ++this.lastRowProcessed;
            return false;
        }
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        if (this.isNullByDescribe) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
            ++this.lastRowProcessed;
            if (this.statement.connection.versionNumber < 9200) {
                this.processIndicator(0);
            }
            return false;
        }
        this.mare.unmarshalCLR(this.rowSpaceByte, this.columnIndex + this.lastRowProcessed * this.byteLength, this.meta, this.byteLength);
        this.processIndicator(this.meta[0]);
        if (this.meta[0] == 0) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
        }
        else {
            this.rowSpaceIndicator[n2] = (short)this.meta[0];
            this.rowSpaceIndicator[n] = 0;
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    @Override
    void copyRow() throws SQLException, IOException {
        int n;
        if (this.lastRowProcessed == 0) {
            n = this.statement.rowPrefetchInLastFetch - 1;
        }
        else {
            n = this.lastRowProcessed - 1;
        }
        final int n2 = this.columnIndex + this.lastRowProcessed * this.byteLength;
        final int n3 = this.columnIndex + n * this.byteLength;
        final int n4 = this.indicatorIndex + this.lastRowProcessed;
        final int n5 = this.indicatorIndex + n;
        final int n6 = this.lengthIndex + this.lastRowProcessed;
        final short n7 = this.rowSpaceIndicator[this.lengthIndex + n];
        final int n8 = this.metaDataIndex + this.lastRowProcessed * 1;
        final int n9 = this.metaDataIndex + n * 1;
        this.rowSpaceIndicator[n6] = n7;
        this.rowSpaceIndicator[n4] = this.rowSpaceIndicator[n5];
        if (!this.isNullByDescribe) {
            System.arraycopy(this.rowSpaceByte, n3, this.rowSpaceByte, n2, n7);
        }
        System.arraycopy(this.rowSpaceMetaData, n9, this.rowSpaceMetaData, n8, 1);
        ++this.lastRowProcessed;
    }
    
    @Override
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
        final int n3 = this.columnIndex + (n2 - 1) * this.byteLength;
        final int n4 = this.columnIndexLastRow + (n - 1) * this.byteLength;
        final int n5 = this.indicatorIndex + n2 - 1;
        final int n6 = this.indicatorIndexLastRow + n - 1;
        final int n7 = this.lengthIndex + n2 - 1;
        final short n8 = array3[this.lengthIndexLastRow + n - 1];
        this.rowSpaceIndicator[n7] = n8;
        this.rowSpaceIndicator[n5] = array3[n6];
        if (n8 != 0) {
            System.arraycopy(array, n4, this.rowSpaceByte, n3, n8);
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getObject(n);
        }
        final Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return o;
        }
        switch (this.definedColumnType) {
            case -1:
            case 1:
            case 12: {
                return this.getString(n);
            }
            case -103: {
                return this.getINTERVALYM(n);
            }
            case -4:
            case -3:
            case -2: {
                return this.getBytes(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    static {
        T4CIntervalymAccessor.maxLength = 11;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
