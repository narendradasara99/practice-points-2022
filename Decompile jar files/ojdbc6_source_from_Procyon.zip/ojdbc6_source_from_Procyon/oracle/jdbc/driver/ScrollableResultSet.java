// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.NClob;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.BFILE;
import oracle.sql.NCLOB;
import oracle.sql.REF;
import oracle.sql.ARRAY;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.TIMESTAMP;
import oracle.sql.NUMBER;
import oracle.sql.ROWID;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.sql.Array;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Ref;
import oracle.sql.OPAQUE;
import oracle.sql.DATE;
import oracle.sql.STRUCT;
import java.util.Map;
import java.io.Reader;
import java.io.ByteArrayInputStream;
import oracle.sql.CHAR;
import java.io.InputStream;
import java.sql.Timestamp;
import java.sql.Time;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import java.sql.Date;
import oracle.sql.BLOB;
import oracle.sql.RAW;
import java.math.BigDecimal;
import oracle.jdbc.OracleResultSet;
import java.sql.Connection;
import oracle.sql.CLOB;
import oracle.sql.Datum;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.io.IOException;
import java.util.Vector;
import java.sql.ResultSetMetaData;

class ScrollableResultSet extends BaseResultSet
{
    PhysicalConnection connection;
    OracleResultSetImpl resultSet;
    ScrollRsetStatement scrollStmt;
    ResultSetMetaData metadata;
    private int rsetType;
    private int rsetConcurency;
    private int beginColumnIndex;
    private int columnCount;
    private int wasNull;
    OracleResultSetCache rsetCache;
    int currentRow;
    private int numRowsCached;
    private boolean allRowsCached;
    private int lastRefetchSz;
    private Vector refetchRowids;
    private OraclePreparedStatement refetchStmt;
    private int usrFetchDirection;
    private static final ClassRef XMLTYPE_CLASS;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    ScrollableResultSet(final ScrollRsetStatement scrollStmt, final OracleResultSetImpl resultSet, final int rsetType, final int rsetConcurency) throws SQLException {
        this.connection = ((OracleStatement)scrollStmt).connection;
        this.resultSet = resultSet;
        this.metadata = null;
        this.scrollStmt = scrollStmt;
        this.rsetType = rsetType;
        this.rsetConcurency = rsetConcurency;
        this.beginColumnIndex = (needIdentifier(rsetType, rsetConcurency) ? 1 : 0);
        this.columnCount = 0;
        this.wasNull = -1;
        this.rsetCache = scrollStmt.getResultSetCache();
        if (this.rsetCache == null) {
            this.rsetCache = new OracleResultSetCacheImpl();
        }
        else {
            try {
                this.rsetCache.clear();
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        this.currentRow = 0;
        this.numRowsCached = 0;
        this.allRowsCached = false;
        this.lastRefetchSz = 0;
        this.refetchRowids = null;
        this.refetchStmt = null;
        this.usrFetchDirection = 1000;
        this.getInternalMetadata();
    }
    
    @Override
    public void close() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                return;
            }
            super.close();
            if (this.resultSet != null) {
                this.resultSet.close();
            }
            if (this.refetchStmt != null) {
                this.refetchStmt.close();
            }
            if (this.scrollStmt != null) {
                this.scrollStmt.notifyCloseRset();
            }
            if (this.refetchRowids != null) {
                this.refetchRowids.removeAllElements();
            }
            this.resultSet = null;
            this.scrollStmt = null;
            this.refetchStmt = null;
            this.refetchRowids = null;
            this.metadata = null;
            try {
                if (this.rsetCache != null) {
                    this.rsetCache.clear();
                    this.rsetCache.close();
                }
            }
            catch (IOException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            finally {
                this.rsetCache = null;
            }
        }
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        synchronized (this.connection) {
            if (this.wasNull == -1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 24);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.wasNull == 1;
        }
    }
    
    @Override
    public Statement getStatement() throws SQLException {
        synchronized (this.connection) {
            return (Statement)this.scrollStmt;
        }
    }
    
    void resetBeginColumnIndex() {
        synchronized (this.connection) {
            this.beginColumnIndex = 0;
        }
    }
    
    ResultSet getResultSet() {
        synchronized (this.connection) {
            return this.resultSet;
        }
    }
    
    int removeRowInCache(final int n) throws SQLException {
        synchronized (this.connection) {
            if (!this.isEmptyResultSet() && this.isValidRow(n)) {
                this.removeCachedRowAt(n);
                --this.numRowsCached;
                if (n >= this.currentRow) {
                    --this.currentRow;
                }
                return 1;
            }
            return 0;
        }
    }
    
    int refreshRowsInCache(final int n, final int n2, final int n3) throws SQLException {
        synchronized (this.connection) {
            OracleResultSetImpl oracleResultSetImpl = null;
            final int get_refetch_size = this.get_refetch_size(n, n2, n3);
            try {
                if (get_refetch_size > 0) {
                    if (get_refetch_size != this.lastRefetchSz) {
                        if (this.refetchStmt != null) {
                            this.refetchStmt.close();
                        }
                        (this.refetchStmt = this.prepare_refetch_statement(get_refetch_size)).setQueryTimeout(((OracleStatement)this.scrollStmt).getQueryTimeout());
                        this.lastRefetchSz = get_refetch_size;
                    }
                    this.prepare_refetch_binds(this.refetchStmt, get_refetch_size);
                    oracleResultSetImpl = (OracleResultSetImpl)this.refetchStmt.executeQuery();
                    this.save_refetch_results(oracleResultSetImpl, n, get_refetch_size, n3);
                }
            }
            finally {
                if (oracleResultSetImpl != null) {
                    oracleResultSetImpl.close();
                }
            }
            return get_refetch_size;
        }
    }
    
    @Override
    public boolean next() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isEmptyResultSet()) {
                return false;
            }
            if (this.currentRow < 1) {
                this.currentRow = 1;
            }
            else {
                ++this.currentRow;
            }
            return this.isValidRow(this.currentRow);
        }
    }
    
    @Override
    public boolean isBeforeFirst() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return !this.isEmptyResultSet() && this.currentRow < 1;
        }
    }
    
    @Override
    public boolean isAfterLast() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return !this.isEmptyResultSet() && this.currentRow > 0 && !this.isValidRow(this.currentRow);
        }
    }
    
    @Override
    public boolean isFirst() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.currentRow == 1;
        }
    }
    
    @Override
    public boolean isLast() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return !this.isEmptyResultSet() && this.isValidRow(this.currentRow) && !this.isValidRow(this.currentRow + 1);
        }
    }
    
    @Override
    public void beforeFirst() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (!this.isEmptyResultSet()) {
                this.currentRow = 0;
            }
        }
    }
    
    @Override
    public void afterLast() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (!this.isEmptyResultSet()) {
                this.currentRow = this.getLastRow() + 1;
            }
        }
    }
    
    @Override
    public boolean first() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isEmptyResultSet()) {
                return false;
            }
            this.currentRow = 1;
            return this.isValidRow(this.currentRow);
        }
    }
    
    @Override
    public boolean last() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isEmptyResultSet()) {
                return false;
            }
            this.currentRow = this.getLastRow();
            return this.isValidRow(this.currentRow);
        }
    }
    
    @Override
    public int getRow() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isValidRow(this.currentRow)) {
                return this.currentRow;
            }
            return 0;
        }
    }
    
    @Override
    public boolean absolute(final int n) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (n == 0) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "absolute(" + n + ")");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (this.isEmptyResultSet()) {
                return false;
            }
            if (n > 0) {
                this.currentRow = n;
            }
            else if (n < 0) {
                this.currentRow = this.getLastRow() + 1 + n;
            }
            return this.isValidRow(this.currentRow);
        }
    }
    
    @Override
    public boolean relative(final int n) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isEmptyResultSet()) {
                return false;
            }
            if (this.isValidRow(this.currentRow)) {
                this.currentRow += n;
                return this.isValidRow(this.currentRow);
            }
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 82, "relative");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public boolean previous() throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isEmptyResultSet()) {
                return false;
            }
            if (this.isAfterLast()) {
                this.currentRow = this.getLastRow();
            }
            else {
                --this.currentRow;
            }
            return this.isValidRow(this.currentRow);
        }
    }
    
    @Override
    public Datum getOracleObject(final int n) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.wasNull = -1;
            if (!this.isValidRow(this.currentRow)) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (n < 1 || n > this.getColumnCount()) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            final Datum cachedDatumValue = this.getCachedDatumValueAt(this.currentRow, n + this.beginColumnIndex);
            this.wasNull = ((cachedDatumValue == null) ? 1 : 0);
            return cachedDatumValue;
        }
    }
    
    @Override
    public String getString(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                case 2005:
                case 2011: {
                    final CLOB clob = (CLOB)oracleObject;
                    return clob.getSubString(1L, (int)clob.length());
                }
                default: {
                    return oracleObject.stringValue(this.connection);
                }
            }
        }
    }
    
    @Override
    public boolean getBoolean(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            return oracleObject != null && oracleObject.booleanValue();
        }
    }
    
    @Override
    public AuthorizationIndicator getAuthorizationIndicator(final int n) throws SQLException {
        synchronized (this.connection) {
            if (!this.isValidRow(this.currentRow)) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (n < 1 || n > this.getColumnCount()) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            AuthorizationIndicator indicator = null;
            CachedRowElement cachedRowElement;
            try {
                cachedRowElement = (CachedRowElement)this.rsetCache.get(this.currentRow, n);
            }
            catch (IOException ex) {
                final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                sqlException3.fillInStackTrace();
                throw sqlException3;
            }
            if (cachedRowElement != null) {
                indicator = cachedRowElement.getIndicator();
            }
            return indicator;
        }
    }
    
    @Override
    public byte getByte(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.byteValue();
            }
            return 0;
        }
    }
    
    @Override
    public short getShort(final int n) throws SQLException {
        synchronized (this.connection) {
            final long long1 = this.getLong(n);
            if (long1 > 65537L || long1 < -65538L) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26, "getShort");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return (short)long1;
        }
    }
    
    @Override
    public int getInt(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.intValue();
            }
            return 0;
        }
    }
    
    @Override
    public long getLong(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.longValue();
            }
            return 0L;
        }
    }
    
    @Override
    public float getFloat(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.floatValue();
            }
            return 0.0f;
        }
    }
    
    @Override
    public double getDouble(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.doubleValue();
            }
            return 0.0;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.bigDecimalValue();
            }
            return null;
        }
    }
    
    @Override
    public byte[] getBytes(final int n) throws SQLException {
        synchronized (this.connection) {
            byte[] array = null;
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                if (oracleObject instanceof RAW) {
                    array = ((RAW)oracleObject).shareBytes();
                }
                else if (oracleObject instanceof BLOB) {
                    final BLOB blob = (BLOB)oracleObject;
                    final long length = blob.length();
                    if (length > 2147483647L) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 151);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    array = blob.getBytes(1L, (int)length);
                    if (blob.isTemporary()) {
                        this.resultSet.statement.addToTempLobsToFree(blob);
                    }
                }
                else {
                    array = oracleObject.getBytes();
                }
            }
            return array;
        }
    }
    
    @Override
    public Date getDate(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            Date date = null;
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case -101: {
                        date = ((TIMESTAMPTZ)oracleObject).dateValue(this.connection);
                        break;
                    }
                    case -102: {
                        date = ((TIMESTAMPLTZ)oracleObject).dateValue(this.connection);
                        break;
                    }
                    default: {
                        date = oracleObject.dateValue();
                        break;
                    }
                }
            }
            return date;
        }
    }
    
    @Override
    public Time getTime(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            Time time = null;
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case -101: {
                        time = ((TIMESTAMPTZ)oracleObject).timeValue(this.connection);
                        break;
                    }
                    case -102: {
                        time = ((TIMESTAMPLTZ)oracleObject).timeValue(this.connection, this.connection.getDbTzCalendar());
                        break;
                    }
                    default: {
                        time = oracleObject.timeValue();
                        break;
                    }
                }
            }
            return time;
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            Timestamp timestamp = null;
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case -101: {
                        timestamp = ((TIMESTAMPTZ)oracleObject).timestampValue(this.connection);
                        break;
                    }
                    case -102: {
                        timestamp = ((TIMESTAMPLTZ)oracleObject).timestampValue(this.connection, this.connection.getDbTzCalendar());
                        break;
                    }
                    default: {
                        timestamp = oracleObject.timestampValue();
                        break;
                    }
                }
            }
            return timestamp;
        }
    }
    
    @Override
    public InputStream getAsciiStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            final int columnType = this.getInternalMetadata().getColumnType(n + this.beginColumnIndex);
            if (oracleObject instanceof CHAR && (columnType == -15 || columnType == -9)) {
                final DBConversion conversion = this.connection.conversion;
                final byte[] shareBytes = oracleObject.shareBytes();
                final DBConversion dbConversion = conversion;
                final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(shareBytes);
                final PhysicalConnection connection = this.connection;
                return dbConversion.ConvertStream(byteArrayInputStream, 12);
            }
            return oracleObject.asciiStreamValue();
        }
    }
    
    @Override
    public InputStream getUnicodeStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            final DBConversion conversion = this.connection.conversion;
            final byte[] shareBytes = oracleObject.shareBytes();
            if (oracleObject instanceof RAW) {
                final DBConversion dbConversion = conversion;
                final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(shareBytes);
                final PhysicalConnection connection = this.connection;
                return dbConversion.ConvertStream(byteArrayInputStream, 3);
            }
            if (oracleObject instanceof CHAR) {
                final DBConversion dbConversion2 = conversion;
                final ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(shareBytes);
                final PhysicalConnection connection2 = this.connection;
                return dbConversion2.ConvertStream(byteArrayInputStream2, 1);
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public InputStream getBinaryStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.binaryStreamValue();
            }
            return null;
        }
    }
    
    @Override
    public Object getObject(final int n) throws SQLException {
        return this.getObject(n, this.connection.getTypeMap());
    }
    
    @Override
    public Reader getCharacterStream(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                return oracleObject.characterStreamValue();
            }
            return null;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n) throws SQLException {
        return this.getBigDecimal(n, 0);
    }
    
    @Override
    public Object getObject(final int n, final Map map) throws SQLException {
        synchronized (this.connection) {
            Object o = null;
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case 2002: {
                        o = ((STRUCT)oracleObject).toJdbc(map);
                        break;
                    }
                    case 91: {
                        if (this.connection.mapDateToTimestamp) {
                            o = oracleObject.toJdbc();
                            break;
                        }
                        o = oracleObject.dateValue();
                        break;
                    }
                    case 93: {
                        if (oracleObject instanceof DATE) {
                            if (this.connection.mapDateToTimestamp) {
                                o = oracleObject.toJdbc();
                                break;
                            }
                            o = oracleObject.dateValue();
                            break;
                        }
                        else {
                            if (this.connection.j2ee13Compliant) {
                                o = oracleObject.toJdbc();
                                break;
                            }
                            o = oracleObject;
                            break;
                        }
                        break;
                    }
                    case -102:
                    case -101: {
                        o = oracleObject;
                        break;
                    }
                    case 2007: {
                        o = ((OPAQUE)oracleObject).toJdbc(map);
                        if (!this.connection.getObjectReturnsXmlType && ScrollableResultSet.XMLTYPE_CLASS != null && ScrollableResultSet.XMLTYPE_CLASS.get().isInstance(o)) {
                            o = new OracleSQLXML(this.connection, (OPAQUE)oracleObject);
                            break;
                        }
                        break;
                    }
                    default: {
                        o = oracleObject.toJdbc();
                        break;
                    }
                }
            }
            return o;
        }
    }
    
    @Override
    public Ref getRef(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getREF(n);
        }
    }
    
    @Override
    public Blob getBlob(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getBLOB(n);
        }
    }
    
    @Override
    public Clob getClob(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getCLOB(n);
        }
    }
    
    @Override
    public Array getArray(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getARRAY(n);
        }
    }
    
    @Override
    public Date getDate(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            Date date = null;
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case -101: {
                        date = new Date(((TIMESTAMPTZ)oracleObject).timestampValue(this.connection).getTime());
                        break;
                    }
                    case -102: {
                        final Calendar dbTzCalendar = this.connection.getDbTzCalendar();
                        date = new Date(((TIMESTAMPLTZ)oracleObject).timestampValue(this.connection, (dbTzCalendar == null) ? calendar : dbTzCalendar).getTime());
                        break;
                    }
                    default: {
                        date = new Date(oracleObject.timestampValue(calendar).getTime());
                        break;
                    }
                }
            }
            return date;
        }
    }
    
    @Override
    public Time getTime(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            Time time = null;
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case -101: {
                        time = new Time(((TIMESTAMPTZ)oracleObject).timestampValue(this.connection).getTime());
                        break;
                    }
                    case -102: {
                        final Calendar dbTzCalendar = this.connection.getDbTzCalendar();
                        time = new Time(((TIMESTAMPLTZ)oracleObject).timestampValue(this.connection, (dbTzCalendar == null) ? calendar : dbTzCalendar).getTime());
                        break;
                    }
                    default: {
                        time = new Time(oracleObject.timestampValue(calendar).getTime());
                        break;
                    }
                }
            }
            return time;
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            Timestamp timestamp = null;
            if (oracleObject != null) {
                switch (this.getInternalMetadata().getColumnType(n + this.beginColumnIndex)) {
                    case -101: {
                        timestamp = ((TIMESTAMPTZ)oracleObject).timestampValue(this.connection);
                        break;
                    }
                    case -102: {
                        final Calendar dbTzCalendar = this.connection.getDbTzCalendar();
                        timestamp = ((TIMESTAMPLTZ)oracleObject).timestampValue(this.connection, (dbTzCalendar == null) ? calendar : dbTzCalendar);
                        break;
                    }
                    default: {
                        timestamp = oracleObject.timestampValue(calendar);
                        break;
                    }
                }
            }
            return timestamp;
        }
    }
    
    @Override
    public URL getURL(final int n) throws SQLException {
        synchronized (this.connection) {
            final int internalType = SQLUtil.getInternalType(this.getInternalMetadata().getColumnType(n + this.beginColumnIndex));
            Label_0106: {
                if (internalType != 96 && internalType != 1) {
                    if (internalType != 8) {
                        break Label_0106;
                    }
                }
                try {
                    final String string = this.getString(n);
                    URL url;
                    if (string == null) {
                        url = null;
                    }
                    else {
                        url = new URL(string);
                    }
                    return url;
                }
                catch (MalformedURLException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 136);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Conversion to java.net.URL not supported.");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public ResultSet getCursor(final int n) throws SQLException {
        synchronized (this.connection) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCursor");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public ROWID getROWID(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof ROWID) {
                return (ROWID)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getROWID");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public NUMBER getNUMBER(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof NUMBER) {
                return (NUMBER)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getNUMBER");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public DATE getDATE(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof DATE) {
                return (DATE)oracleObject;
            }
            if (oracleObject instanceof TIMESTAMP) {
                return TIMESTAMP.toDATE(oracleObject.getBytes());
            }
            if (oracleObject instanceof TIMESTAMPLTZ) {
                return TIMESTAMPLTZ.toDATE(this.connection, oracleObject.getBytes());
            }
            if (oracleObject instanceof TIMESTAMPTZ) {
                return TIMESTAMPTZ.toDATE(this.connection, oracleObject.getBytes());
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getDATE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof TIMESTAMP) {
                return (TIMESTAMP)oracleObject;
            }
            if (oracleObject instanceof TIMESTAMPLTZ) {
                return TIMESTAMPLTZ.toTIMESTAMP(this.connection, oracleObject.getBytes());
            }
            if (oracleObject instanceof TIMESTAMPTZ) {
                return TIMESTAMPTZ.toTIMESTAMP(this.connection, oracleObject.getBytes());
            }
            if (oracleObject instanceof DATE) {
                return new TIMESTAMP((DATE)oracleObject);
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof TIMESTAMPTZ) {
                return (TIMESTAMPTZ)oracleObject;
            }
            if (oracleObject instanceof TIMESTAMPLTZ) {
                return TIMESTAMPLTZ.toTIMESTAMPTZ(this.connection, oracleObject.getBytes());
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof TIMESTAMPLTZ) {
                return (TIMESTAMPLTZ)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof INTERVALDS) {
                return (INTERVALDS)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof INTERVALYM) {
                return (INTERVALYM)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public ARRAY getARRAY(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof ARRAY) {
                return (ARRAY)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getARRAY");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public STRUCT getSTRUCT(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof STRUCT) {
                return (STRUCT)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public OPAQUE getOPAQUE(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof OPAQUE) {
                return (OPAQUE)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public REF getREF(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof REF) {
                return (REF)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getREF");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public CHAR getCHAR(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof CHAR) {
                return (CHAR)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCHAR");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public RAW getRAW(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof RAW) {
                return (RAW)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getRAW");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public BLOB getBLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof BLOB) {
                return (BLOB)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBLOB");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public CLOB getCLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof CLOB) {
                return (CLOB)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCLOB");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public NCLOB getNCLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof NCLOB) {
                return (NCLOB)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCLOB");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public BFILE getBFILE(final int n) throws SQLException {
        synchronized (this.connection) {
            final Datum oracleObject = this.getOracleObject(n);
            if (oracleObject == null) {
                return null;
            }
            if (oracleObject instanceof BFILE) {
                return (BFILE)oracleObject;
            }
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBFILE");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public BFILE getBfile(final int n) throws SQLException {
        synchronized (this.connection) {
            return this.getBFILE(n);
        }
    }
    
    @Override
    public CustomDatum getCustomDatum(final int n, final CustomDatumFactory customDatumFactory) throws SQLException {
        synchronized (this.connection) {
            return customDatumFactory.create(this.getOracleObject(n), 0);
        }
    }
    
    @Override
    public ORAData getORAData(final int n, final ORADataFactory oraDataFactory) throws SQLException {
        synchronized (this.connection) {
            return oraDataFactory.create(this.getOracleObject(n), 0);
        }
    }
    
    @Override
    public NClob getNClob(final int n) throws SQLException {
        final NCLOB nclob = this.getNCLOB(n);
        if (nclob == null) {
            return null;
        }
        if (!(nclob instanceof NClob)) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 184);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return nclob;
    }
    
    @Override
    public String getNString(final int n) throws SQLException {
        return this.getString(n);
    }
    
    @Override
    public Reader getNCharacterStream(final int n) throws SQLException {
        return this.getCharacterStream(n);
    }
    
    @Override
    public RowId getRowId(final int n) throws SQLException {
        return this.getROWID(n);
    }
    
    @Override
    public SQLXML getSQLXML(final int n) throws SQLException {
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject == null) {
            return null;
        }
        if (oracleObject instanceof SQLXML) {
            return (SQLXML)oracleObject;
        }
        if (oracleObject instanceof OPAQUE) {
            return new OracleSQLXML(this.connection, (OPAQUE)oracleObject);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getSQLXML");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        synchronized (this.connection) {
            return new OracleResultSetMetaData(this.connection, (OracleStatement)this.scrollStmt, this.beginColumnIndex);
        }
    }
    
    @Override
    public int findColumn(final String s) throws SQLException {
        synchronized (this.connection) {
            if (this.closed) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            return this.resultSet.findColumn(s) - this.beginColumnIndex;
        }
    }
    
    @Override
    public void setFetchDirection(final int n) throws SQLException {
        synchronized (this.connection) {
            if (n == 1000) {
                this.usrFetchDirection = n;
            }
            else {
                if (n != 1001 && n != 1002) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                this.usrFetchDirection = n;
                this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
            }
        }
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        return 1000;
    }
    
    @Override
    public void setFetchSize(final int fetchSize) throws SQLException {
        synchronized (this.connection) {
            this.resultSet.setFetchSize(fetchSize);
        }
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        synchronized (this.connection) {
            return this.resultSet.getFetchSize();
        }
    }
    
    @Override
    public int getType() throws SQLException {
        return this.rsetType;
    }
    
    @Override
    public int getConcurrency() throws SQLException {
        return this.rsetConcurency;
    }
    
    @Override
    public void refreshRow() throws SQLException {
        if (!needIdentifier(this.rsetType, this.rsetConcurency)) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "refreshRow");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.isValidRow(this.currentRow)) {
            final int fetchDirection = this.getFetchDirection();
            try {
                this.refreshRowsInCache(this.currentRow, this.getFetchSize(), fetchDirection);
            }
            catch (SQLException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex, 90, "Unsupported syntax for refreshRow()");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            return;
        }
        final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 82, "refreshRow");
        sqlException3.fillInStackTrace();
        throw sqlException3;
    }
    
    private boolean isEmptyResultSet() throws SQLException {
        return this.numRowsCached == 0 && ((this.numRowsCached == 0 && this.allRowsCached) || !this.isValidRow(1));
    }
    
    boolean isValidRow(final int n) throws SQLException {
        return (n > 0 && n <= this.numRowsCached) || (n > 0 && this.cacheRowAt(n));
    }
    
    private void cacheCurrentRow(final OracleResultSetImpl oracleResultSetImpl, final int n) throws SQLException {
        for (int i = 0; i < this.getColumnCount(); ++i) {
            final CachedRowElement cachedRowElement = new CachedRowElement(n, i + 1, oracleResultSetImpl.getAuthorizationIndicator(i + 1), oracleResultSetImpl.privateGetBytes(i + 1));
            final int internalType = oracleResultSetImpl.statement.accessors[i].internalType;
            if (internalType == 112) {
                cachedRowElement.setData(oracleResultSetImpl.getCLOB(i + 1));
            }
            else if (internalType == 113) {
                cachedRowElement.setData(oracleResultSetImpl.getBLOB(i + 1));
            }
            this.putCachedValueAt(n, i + 1, cachedRowElement);
        }
    }
    
    private boolean cacheRowAt(final int n) throws SQLException {
        while (this.numRowsCached < n && this.resultSet.next()) {
            this.cacheCurrentRow(this.resultSet, ++this.numRowsCached);
        }
        if (this.numRowsCached < n) {
            this.allRowsCached = true;
            return false;
        }
        return true;
    }
    
    private int cacheAllRows() throws SQLException {
        while (this.resultSet.next()) {
            this.cacheCurrentRow(this.resultSet, ++this.numRowsCached);
        }
        this.allRowsCached = true;
        return this.numRowsCached;
    }
    
    int getColumnCount() throws SQLException {
        if (this.columnCount == 0) {
            final int numberOfDefinePositions = this.resultSet.statement.numberOfDefinePositions;
            if (this.resultSet.statement.accessors != null && numberOfDefinePositions > 0) {
                this.columnCount = numberOfDefinePositions;
            }
            else {
                this.columnCount = this.getInternalMetadata().getColumnCount();
            }
        }
        return this.columnCount;
    }
    
    private ResultSetMetaData getInternalMetadata() throws SQLException {
        if (this.metadata == null) {
            this.metadata = this.resultSet.getMetaData();
        }
        return this.metadata;
    }
    
    private int getLastRow() throws SQLException {
        if (!this.allRowsCached) {
            this.cacheAllRows();
        }
        return this.numRowsCached;
    }
    
    private int get_refetch_size(final int n, final int n2, final int n3) throws SQLException {
        final int n4 = (n3 == 1001) ? -1 : 1;
        int n5 = 0;
        if (this.refetchRowids == null) {
            this.refetchRowids = new Vector(10);
        }
        else {
            this.refetchRowids.removeAllElements();
        }
        while (n5 < n2 && this.isValidRow(n + n5 * n4)) {
            this.refetchRowids.addElement(this.getCachedDatumValueAt(n + n5 * n4, 1));
            ++n5;
        }
        return n5;
    }
    
    private OraclePreparedStatement prepare_refetch_statement(final int n) throws SQLException {
        if (n < 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (OraclePreparedStatement)((OraclePreparedStatementWrapper)this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getRefetchSqlForScrollableResultSet(this, n))).preparedStatement;
    }
    
    private void prepare_refetch_binds(final OraclePreparedStatement oraclePreparedStatement, final int n) throws SQLException {
        final int copyBinds = this.scrollStmt.copyBinds(oraclePreparedStatement, 0);
        for (int i = 0; i < n; ++i) {
            oraclePreparedStatement.setROWID(copyBinds + i + 1, (ROWID)this.refetchRowids.elementAt(i));
        }
    }
    
    private void save_refetch_results(final OracleResultSetImpl oracleResultSetImpl, final int n, final int n2, final int n3) throws SQLException {
        final int n4 = (n3 == 1001) ? -1 : 1;
        while (oracleResultSetImpl.next()) {
            final ROWID rowid = oracleResultSetImpl.getROWID(1);
            int n5 = 0;
            int n6 = n;
            while (n5 == 0 && n6 < n + n2 * n4) {
                if (((ROWID)this.getCachedDatumValueAt(n6, 1)).stringValue(this.connection).equals(rowid.stringValue(this.connection))) {
                    n5 = 1;
                }
                else {
                    n6 += n4;
                }
            }
            if (n5 != 0) {
                this.cacheCurrentRow(oracleResultSetImpl, n6);
            }
        }
    }
    
    private Datum getCachedDatumValueAt(final int n, final int n2) throws SQLException {
        CachedRowElement cachedRowElement;
        try {
            cachedRowElement = (CachedRowElement)this.rsetCache.get(n, n2);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        Datum data = null;
        if (cachedRowElement != null) {
            data = cachedRowElement.getDataAsDatum();
            final byte[] data2 = cachedRowElement.getData();
            if (data == null && data2 != null && data2.length > 0) {
                final int columnType = this.getInternalMetadata().getColumnType(n2);
                int columnDisplaySize = this.getInternalMetadata().getColumnDisplaySize(n2);
                final int internalType = ((OracleResultSetMetaData)this.getInternalMetadata()).getDescription()[n2 - 1].internalType;
                final int maxFieldSize = this.scrollStmt.getMaxFieldSize();
                if (maxFieldSize > 0 && maxFieldSize < columnDisplaySize) {
                    columnDisplaySize = maxFieldSize;
                }
                String columnTypeName = null;
                if (columnType == 2006 || columnType == 2002 || columnType == 2008 || columnType == 2007 || columnType == 2003 || columnType == 2009) {
                    columnTypeName = this.getInternalMetadata().getColumnTypeName(n2);
                }
                final short formOfUse = this.resultSet.statement.accessors[n2 - 1].formOfUse;
                if (formOfUse == 2 && (internalType == 96 || internalType == 1 || internalType == 8 || internalType == 112)) {
                    data = SQLUtil.makeNDatum(this.connection, data2, internalType, columnTypeName, formOfUse, columnDisplaySize);
                }
                else {
                    data = SQLUtil.makeDatum(this.connection, data2, internalType, columnTypeName, columnDisplaySize);
                }
                cachedRowElement.setData(data);
            }
        }
        return data;
    }
    
    private void putCachedValueAt(final int n, final int n2, final CachedRowElement cachedRowElement) throws SQLException {
        try {
            this.rsetCache.put(n, n2, cachedRowElement);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    private void removeCachedRowAt(final int n) throws SQLException {
        try {
            this.rsetCache.remove(n);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public static boolean needIdentifier(final int n, final int n2) {
        return (n != 1003 || n2 != 1007) && (n != 1004 || n2 != 1007);
    }
    
    public static boolean needCache(final int n, final int n2) {
        return n != 1003 && (n != 1004 || n2 != 1007);
    }
    
    public static boolean supportRefreshRow(final int n, final int n2) {
        return n != 1003 && (n != 1004 || n2 != 1007);
    }
    
    @Override
    int getFirstUserColumnIndex() {
        return this.beginColumnIndex;
    }
    
    @Override
    public String getCursorName() throws SQLException {
        synchronized (this.connection) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "getCursorName");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    @Override
    OracleStatement getOracleStatement() throws SQLException {
        return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
    }
    
    static {
        ClassRef instance = null;
        try {
            instance = ClassRef.newInstance("oracle.xdb.XMLType");
        }
        catch (ClassNotFoundException ex) {}
        XMLTYPE_CLASS = instance;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
