// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class RawBinder extends DatumBinder
{
    Binder theRawCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static void init(final Binder binder) {
        binder.type = 23;
        binder.bytelen = 4000;
    }
    
    RawBinder() {
        this.theRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
        init(this);
    }
    
    @Override
    Binder copyingBinder() {
        return this.theRawCopyingBinder;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
