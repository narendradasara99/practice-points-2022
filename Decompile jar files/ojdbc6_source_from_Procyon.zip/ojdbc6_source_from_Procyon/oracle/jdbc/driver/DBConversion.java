// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.Reader;
import java.io.InputStream;
import oracle.jdbc.util.RepConversion;
import oracle.sql.converter.CharacterSetMetaData;
import java.sql.SQLException;
import oracle.sql.CharacterSet;

public class DBConversion
{
    public static final boolean DO_CONVERSION_WITH_REPLACEMENT = true;
    public static final short ORACLE8_PROD_VERSION = 8030;
    protected short serverNCharSetId;
    protected short serverCharSetId;
    protected short clientCharSetId;
    protected CharacterSet serverCharSet;
    protected CharacterSet serverNCharSet;
    protected CharacterSet clientCharSet;
    protected CharacterSet asciiCharSet;
    protected boolean isServerCharSetFixedWidth;
    protected boolean isServerNCharSetFixedWidth;
    protected int c2sNlsRatio;
    protected int s2cNlsRatio;
    protected int sMaxCharSize;
    protected int cMaxCharSize;
    protected int maxNCharSize;
    protected boolean isServerCSMultiByte;
    private boolean isStrictASCIIConversion;
    public static final short DBCS_CHARSET = -1;
    public static final short UCS2_CHARSET = -5;
    public static final short ASCII_CHARSET = 1;
    public static final short ISO_LATIN_1_CHARSET = 31;
    public static final short AL24UTFFSS_CHARSET = 870;
    public static final short UTF8_CHARSET = 871;
    public static final short AL32UTF8_CHARSET = 873;
    public static final short AL16UTF16_CHARSET = 2000;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public DBConversion(final short n, final short n2, final short n3, final boolean isStrictASCIIConversion) throws SQLException {
        this.isStrictASCIIConversion = isStrictASCIIConversion;
        if (n2 != -1) {
            this.init(n, n2, n3);
        }
    }
    
    public DBConversion(final short n, final short n2, final short n3) throws SQLException {
        this(n, n2, n3, false);
    }
    
    void init(final short serverCharSetId, final short clientCharSetId, final short serverNCharSetId) throws SQLException {
        switch (clientCharSetId) {
            case -5:
            case 1:
            case 2:
            case 31:
            case 178:
            case 870:
            case 871:
            case 873: {
                break;
            }
            default: {
                unexpectedCharset(clientCharSetId);
                break;
            }
        }
        this.serverCharSetId = serverCharSetId;
        this.clientCharSetId = clientCharSetId;
        this.serverCharSet = CharacterSet.make(this.serverCharSetId);
        this.serverNCharSetId = serverNCharSetId;
        this.serverNCharSet = CharacterSet.make(this.serverNCharSetId);
        this.clientCharSet = CharacterSet.make(this.clientCharSetId);
        this.c2sNlsRatio = CharacterSetMetaData.getRatio(serverCharSetId, clientCharSetId);
        this.s2cNlsRatio = CharacterSetMetaData.getRatio(clientCharSetId, serverCharSetId);
        this.sMaxCharSize = CharacterSetMetaData.getRatio(serverCharSetId, 1);
        this.cMaxCharSize = CharacterSetMetaData.getRatio(clientCharSetId, 1);
        this.maxNCharSize = CharacterSetMetaData.getRatio(serverNCharSetId, 1);
        this.findFixedWidthInfo();
    }
    
    void findFixedWidthInfo() throws SQLException {
        this.isServerCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverCharSetId);
        this.isServerNCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverNCharSetId);
        this.isServerCSMultiByte = (this.sMaxCharSize > 1);
    }
    
    public short getServerCharSetId() {
        return this.serverCharSetId;
    }
    
    public short getNCharSetId() {
        return this.serverNCharSetId;
    }
    
    public boolean IsNCharFixedWith() {
        return this.serverNCharSetId == 2000;
    }
    
    public short getClientCharSet() {
        if (this.clientCharSetId == -1) {
            return this.serverCharSetId;
        }
        return this.clientCharSetId;
    }
    
    public CharacterSet getDbCharSetObj() {
        return this.serverCharSet;
    }
    
    public CharacterSet getDriverCharSetObj() {
        return this.clientCharSet;
    }
    
    public CharacterSet getDriverNCharSetObj() {
        return this.serverNCharSet;
    }
    
    public static final short findDriverCharSet(final short n, final short n2) {
        short n3 = 0;
        switch (n) {
            case 1:
            case 2:
            case 31:
            case 178:
            case 873: {
                n3 = n;
                break;
            }
            default: {
                n3 = (short)((n2 >= 8030) ? 871 : 870);
                break;
            }
        }
        return n3;
    }
    
    public static final byte[] stringToDriverCharBytes(final String s, final short n) throws SQLException {
        if (s == null) {
            return null;
        }
        byte[] array = null;
        switch (n) {
            case -5:
            case 2000: {
                array = CharacterSet.stringToAL16UTF16Bytes(s);
                break;
            }
            case 1:
            case 2: {
                array = CharacterSet.stringToASCII(s);
                break;
            }
            case 870:
            case 871: {
                array = CharacterSet.stringToUTF(s);
                break;
            }
            case 873: {
                array = CharacterSet.stringToAL32UTF8(s);
                break;
            }
            default: {
                unexpectedCharset(n);
                break;
            }
        }
        return array;
    }
    
    public byte[] StringToCharBytes(final String s) throws SQLException {
        if (s.length() == 0) {
            return null;
        }
        switch (this.clientCharSetId) {
            case -1: {
                return this.serverCharSet.convertWithReplacement(s);
            }
            case 2:
            case 31:
            case 178: {
                return this.clientCharSet.convertWithReplacement(s);
            }
            default: {
                return stringToDriverCharBytes(s, this.clientCharSetId);
            }
        }
    }
    
    public String CharBytesToString(final byte[] array, final int n) throws SQLException {
        return this.CharBytesToString(array, n, true);
    }
    
    public String CharBytesToString(final byte[] ascii, final int count, final boolean b) throws SQLException {
        String s = null;
        if (ascii.length == 0) {
            return s;
        }
        switch (this.clientCharSetId) {
            case -5: {
                s = CharacterSet.AL16UTF16BytesToString(ascii, count);
                break;
            }
            case 1: {
                s = new String(ascii, 0, 0, count);
                break;
            }
            case 2:
            case 31:
            case 178: {
                if (b) {
                    s = this.clientCharSet.toStringWithReplacement(ascii, 0, count);
                    break;
                }
                s = this.clientCharSet.toString(ascii, 0, count);
                break;
            }
            case 870:
            case 871: {
                s = CharacterSet.UTFToString(ascii, 0, count, b);
                break;
            }
            case 873: {
                s = CharacterSet.AL32UTF8ToString(ascii, 0, count, b);
                break;
            }
            case -1: {
                s = this.serverCharSet.toStringWithReplacement(ascii, 0, count);
                break;
            }
            default: {
                unexpectedCharset(this.clientCharSetId);
                break;
            }
        }
        return s;
    }
    
    public String NCharBytesToString(final byte[] ascii, final int count) throws SQLException {
        String s = null;
        if (this.clientCharSetId == -1) {
            s = this.serverNCharSet.toStringWithReplacement(ascii, 0, count);
        }
        else {
            switch (this.serverNCharSetId) {
                case -5:
                case 2000: {
                    s = CharacterSet.AL16UTF16BytesToString(ascii, count);
                    break;
                }
                case 1:
                case 2: {
                    s = new String(ascii, 0, 0, count);
                    break;
                }
                case 31:
                case 178: {
                    s = this.serverNCharSet.toStringWithReplacement(ascii, 0, count);
                    break;
                }
                case 870:
                case 871: {
                    s = CharacterSet.UTFToString(ascii, 0, count);
                    break;
                }
                case 873: {
                    s = CharacterSet.AL32UTF8ToString(ascii, 0, count);
                    break;
                }
                case -1: {
                    s = this.serverCharSet.toStringWithReplacement(ascii, 0, count);
                    break;
                }
                default: {
                    unexpectedCharset(this.clientCharSetId);
                    break;
                }
            }
        }
        return s;
    }
    
    public int javaCharsToCHARBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.javaCharsToCHARBytes(array, n, array2, this.clientCharSetId);
    }
    
    public int javaCharsToCHARBytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) throws SQLException {
        return this.javaCharsToCHARBytes(array, n, array2, n2, this.clientCharSetId, n3);
    }
    
    public int javaCharsToNCHARBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.javaCharsToCHARBytes(array, n, array2, this.serverNCharSetId);
    }
    
    public int javaCharsToNCHARBytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) throws SQLException {
        return this.javaCharsToCHARBytes(array, n, array2, n2, this.serverNCharSetId, n3);
    }
    
    protected int javaCharsToCHARBytes(final char[] array, final int n, final byte[] array2, final short n2) throws SQLException {
        return this.javaCharsToCHARBytes(array, 0, array2, 0, n2, n);
    }
    
    protected int javaCharsToCHARBytes(final char[] value, final int offset, final byte[] array, final int n, final short n2, final int count) throws SQLException {
        int n3 = 0;
        switch (n2) {
            case -5:
            case 2000: {
                n3 = CharacterSet.convertJavaCharsToAL16UTF16Bytes(value, offset, array, n, count);
                break;
            }
            case 2:
            case 178: {
                final byte[] convertWithReplacement = this.clientCharSet.convertWithReplacement(new String(value, offset, count));
                System.arraycopy(convertWithReplacement, 0, array, 0, convertWithReplacement.length);
                n3 = convertWithReplacement.length;
                break;
            }
            case 1: {
                n3 = CharacterSet.convertJavaCharsToASCIIBytes(value, offset, array, n, count, this.isStrictASCIIConversion);
                break;
            }
            case 31: {
                n3 = CharacterSet.convertJavaCharsToISOLATIN1Bytes(value, offset, array, n, count);
                break;
            }
            case 870:
            case 871: {
                n3 = CharacterSet.convertJavaCharsToUTFBytes(value, offset, array, n, count);
                break;
            }
            case 873: {
                n3 = CharacterSet.convertJavaCharsToAL32UTF8Bytes(value, offset, array, n, count);
                break;
            }
            case -1: {
                n3 = this.javaCharsToDbCsBytes(value, offset, array, n, count);
                break;
            }
            default: {
                unexpectedCharset(this.clientCharSetId);
                break;
            }
        }
        return n3;
    }
    
    public int CHARBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int[] array3, final int n3) throws SQLException {
        return _CHARBytesToJavaChars(array, n, array2, n2, this.clientCharSetId, array3, n3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, false);
    }
    
    public int NCHARBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final int[] array3, final int n3) throws SQLException {
        return _CHARBytesToJavaChars(array, n, array2, n2, this.serverNCharSetId, array3, n3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, true);
    }
    
    static final int _CHARBytesToJavaChars(final byte[] array, final int n, final char[] array2, final int n2, final short n3, final int[] array3, int n4, final CharacterSet set, final CharacterSet set2, final CharacterSet set3, final boolean b) throws SQLException {
        int n5 = 0;
        switch (n3) {
            case -5:
            case 2000: {
                int n6 = array3[0] - array3[0] % 2;
                if (n4 > array2.length - n2) {
                    n4 = array2.length - n2;
                }
                if (n4 * 2 < n6) {
                    n6 = n4 * 2;
                }
                n5 = CharacterSet.convertAL16UTF16BytesToJavaChars(array, n, array2, n2, n6, true);
                array3[0] -= n6;
                break;
            }
            case 1: {
                int n7 = array3[0];
                if (n4 > array2.length - n2) {
                    n4 = array2.length - n2;
                }
                if (n4 < n7) {
                    n7 = n4;
                }
                n5 = CharacterSet.convertASCIIBytesToJavaChars(array, n, array2, n2, n7);
                array3[0] -= n7;
                break;
            }
            case 31:
            case 178: {
                n5 = set.toCharWithReplacement(array, 0, array2, n2, array3[0]);
                final int n8 = 0;
                array3[n8] -= n5;
                break;
            }
            case 870:
            case 871: {
                if (n4 > array2.length - n2) {
                    n4 = array2.length - n2;
                }
                n5 = CharacterSet.convertUTFBytesToJavaChars(array, n, array2, n2, array3, true, n4);
                break;
            }
            case 873: {
                if (n4 > array2.length - n2) {
                    n4 = array2.length - n2;
                }
                n5 = CharacterSet.convertAL32UTF8BytesToJavaChars(array, n, array2, n2, array3, true, n4);
                break;
            }
            case -1: {
                unexpectedCharset((short)(-1));
                break;
            }
            default: {
                CharacterSet set4 = set3;
                if (b) {
                    set4 = set2;
                }
                final char[] charArray = set4.toStringWithReplacement(array, n, array3[0]).toCharArray();
                int length = charArray.length;
                if (length > n4) {
                    length = n4;
                }
                n5 = length;
                array3[0] -= length;
                System.arraycopy(charArray, 0, array2, n2, length);
                break;
            }
        }
        return n5;
    }
    
    public byte[] asciiBytesToCHARBytes(final byte[] array) {
        byte[] convert = null;
        switch (this.clientCharSetId) {
            case -5: {
                convert = new byte[array.length * 2];
                int i = 0;
                int n = 0;
                while (i < array.length) {
                    convert[n++] = 0;
                    convert[n++] = array[i];
                    ++i;
                }
                break;
            }
            case -1: {
                if (this.asciiCharSet == null) {
                    this.asciiCharSet = CharacterSet.make(1);
                }
                try {
                    convert = this.serverCharSet.convert(this.asciiCharSet, array, 0, array.length);
                }
                catch (SQLException ex) {}
                break;
            }
            default: {
                convert = array;
                break;
            }
        }
        return convert;
    }
    
    public int javaCharsToDbCsBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.javaCharsToDbCsBytes(array, 0, array2, 0, n);
    }
    
    public int javaCharsToDbCsBytes(final char[] value, final int offset, final byte[] array, final int n, final int count) throws SQLException {
        int length = 0;
        catchCharsLen(value, offset, count);
        final byte[] convertWithReplacement = this.serverCharSet.convertWithReplacement(new String(value, offset, count));
        if (convertWithReplacement != null) {
            length = convertWithReplacement.length;
            catchBytesLen(array, n, length);
            System.arraycopy(convertWithReplacement, 0, array, n, length);
        }
        return length;
    }
    
    public static final int javaCharsToUcs2Bytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return javaCharsToUcs2Bytes(array, 0, array2, 0, n);
    }
    
    public static final int javaCharsToUcs2Bytes(final char[] array, final int n, final byte[] array2, final int n2, final int n3) throws SQLException {
        catchCharsLen(array, n, n3);
        catchBytesLen(array2, n2, n3 * 2);
        final int n4 = n3 + n;
        int i = n;
        int n5 = n2;
        while (i < n4) {
            array2[n5++] = (byte)(array[i] >> 8 & 0xFF);
            array2[n5++] = (byte)(array[i] & '\u00ff');
            ++i;
        }
        return n5 - n2;
    }
    
    public static final int ucs2BytesToJavaChars(final byte[] array, final int n, final char[] array2) throws SQLException {
        return CharacterSet.AL16UTF16BytesToJavaChars(array, n, array2);
    }
    
    public static final byte[] stringToAsciiBytes(final String s) {
        return CharacterSet.stringToASCII(s);
    }
    
    public static final int asciiBytesToJavaChars(final byte[] array, final int n, final char[] array2) throws SQLException {
        return CharacterSet.convertASCIIBytesToJavaChars(array, 0, array2, 0, n);
    }
    
    public static final int javaCharsToAsciiBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return CharacterSet.convertJavaCharsToASCIIBytes(array, 0, array2, 0, n);
    }
    
    public static final boolean isCharSetMultibyte(final short n) {
        switch (n) {
            case 1:
            case 31: {
                return false;
            }
            case -5:
            case -1:
            case 870:
            case 871:
            case 873: {
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    public int getMaxCharbyteSize() {
        return this._getMaxCharbyteSize(this.clientCharSetId);
    }
    
    public int getMaxNCharbyteSize() {
        return this._getMaxCharbyteSize(this.serverNCharSetId);
    }
    
    public int _getMaxCharbyteSize(final short n) {
        switch (n) {
            case 1: {
                return 1;
            }
            case 31: {
                return 1;
            }
            case 870:
            case 871: {
                return 3;
            }
            case -5:
            case 2000: {
                return 2;
            }
            case -1: {
                return 4;
            }
            case 873: {
                return 4;
            }
            default: {
                return 1;
            }
        }
    }
    
    public boolean isUcs2CharSet() {
        return this.clientCharSetId == -5;
    }
    
    public static final int RAWBytesToHexChars(final byte[] array, final int n, final char[] array2) {
        int i = 0;
        int n2 = 0;
        while (i < n) {
            array2[n2++] = (char)RepConversion.nibbleToHex((byte)(array[i] >> 4 & 0xF));
            array2[n2++] = (char)RepConversion.nibbleToHex((byte)(array[i] & 0xF));
            ++i;
        }
        return n2;
    }
    
    public final int hexDigit2Nibble(final char c) throws SQLException {
        final int digit = Character.digit(c, 16);
        if (digit == -1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 59, "Invalid hex digit: " + c);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return digit;
    }
    
    public final byte[] hexString2Bytes(final String s) throws SQLException {
        final int length = s.length();
        final char[] dst = new char[length];
        s.getChars(0, length, dst, 0);
        return this.hexChars2Bytes(dst, 0, length);
    }
    
    public final byte[] hexChars2Bytes(final char[] array, final int n, final int n2) throws SQLException {
        int i = 0;
        int n3 = n;
        if (n2 == 0) {
            return new byte[0];
        }
        byte[] array2;
        if (n2 % 2 > 0) {
            array2 = new byte[(n2 + 1) / 2];
            array2[i++] = (byte)this.hexDigit2Nibble(array[n3++]);
        }
        else {
            array2 = new byte[n2 / 2];
        }
        while (i < array2.length) {
            array2[i] = (byte)(this.hexDigit2Nibble(array[n3++]) << 4 | this.hexDigit2Nibble(array[n3++]));
            ++i;
        }
        return array2;
    }
    
    public InputStream ConvertStream(final InputStream inputStream, final int n) {
        return new OracleConversionInputStream(this, inputStream, n);
    }
    
    public InputStream ConvertStream(final InputStream inputStream, final int n, final int n2) {
        return new OracleConversionInputStream(this, inputStream, n, n2);
    }
    
    public InputStream ConvertStreamInternal(final InputStream inputStream, final int n, final int n2) {
        return new OracleConversionInputStreamInternal(this, inputStream, n, n2);
    }
    
    public InputStream ConvertStream(final Reader reader, final int n, final int n2, final short n3) {
        return new OracleConversionInputStream(this, reader, n, n2, n3);
    }
    
    public InputStream ConvertStreamInternal(final Reader reader, final int n, final int n2, final short n3) {
        return new OracleConversionInputStreamInternal(this, reader, n, n2, n3);
    }
    
    public Reader ConvertCharacterStream(final InputStream inputStream, final int n) throws SQLException {
        return new OracleConversionReader(this, inputStream, n);
    }
    
    public Reader ConvertCharacterStream(final InputStream inputStream, final int n, final short formOfUse) throws SQLException {
        final OracleConversionReader oracleConversionReader = new OracleConversionReader(this, inputStream, n);
        oracleConversionReader.setFormOfUse(formOfUse);
        return oracleConversionReader;
    }
    
    public InputStream CharsToStream(final char[] array, final int n, final int n2, final int n3) throws SQLException {
        if (n3 == 10) {
            return new AsciiStream(array, n, n2);
        }
        if (n3 == 11) {
            return new UnicodeStream(array, n, n2);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 39, "unknownConversion");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static final void unexpectedCharset(final short n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(null, 35, "DBConversion");
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected static final void catchBytesLen(final byte[] array, final int n, final int n2) throws SQLException {
        if (n + n2 > array.length) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 39, "catchBytesLen");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    protected static final void catchCharsLen(final char[] array, final int n, final int n2) throws SQLException {
        if (n + n2 > array.length) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 39, "catchCharsLen");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public static final int getUtfLen(final char c) {
        int n;
        if ((c & '\uff80') == 0x0) {
            n = 1;
        }
        else if ((c & '\uf800') == 0x0) {
            n = 2;
        }
        else {
            n = 3;
        }
        return n;
    }
    
    int encodedByteLength(final String s, final boolean b) {
        int length = 0;
        if (s != null) {
            length = s.length();
            if (length != 0) {
                if (b) {
                    length = (this.isServerNCharSetFixedWidth ? (length * this.maxNCharSize) : this.serverNCharSet.encodedByteLength(s));
                }
                else {
                    length = (this.isServerCharSetFixedWidth ? (length * this.sMaxCharSize) : this.serverCharSet.encodedByteLength(s));
                }
            }
        }
        return length;
    }
    
    int encodedByteLength(final char[] array, final boolean b) {
        int length = 0;
        if (array != null) {
            length = array.length;
            if (length != 0) {
                if (b) {
                    length = (this.isServerNCharSetFixedWidth ? (length * this.maxNCharSize) : this.serverNCharSet.encodedByteLength(array));
                }
                else {
                    length = (this.isServerCharSetFixedWidth ? (length * this.sMaxCharSize) : this.serverCharSet.encodedByteLength(array));
                }
            }
        }
        return length;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    class AsciiStream extends OracleBufferedStream
    {
        AsciiStream(final char[] value, final int offset, final int n) {
            super(n);
            this.currentBufferSize = this.initialBufferSize;
            this.resizableBuffer = new byte[this.currentBufferSize];
            if (DBConversion.this.serverCharSetId == 1 || !DBConversion.this.isStrictASCIIConversion) {
                int n2 = offset;
                for (int i = 0; i < n; ++i) {
                    this.resizableBuffer[i] = (byte)value[n2++];
                }
            }
            else {
                if (DBConversion.this.asciiCharSet == null) {
                    DBConversion.this.asciiCharSet = CharacterSet.make(1);
                }
                this.resizableBuffer = DBConversion.this.asciiCharSet.convertWithReplacement(new String(value, offset, n));
            }
            this.count = n;
        }
        
        @Override
        public boolean needBytes() {
            return !this.closed && this.pos < this.count;
        }
        
        @Override
        public boolean needBytes(final int n) {
            return !this.closed && this.pos < this.count;
        }
    }
    
    class UnicodeStream extends OracleBufferedStream
    {
        UnicodeStream(final char[] array, final int n, final int count) {
            super(count);
            this.currentBufferSize = this.initialBufferSize;
            this.resizableBuffer = new byte[this.currentBufferSize];
            int n2 = n;
            char c;
            for (int i = 0; i < count; this.resizableBuffer[i++] = (byte)(c >> 8 & 0xFF), this.resizableBuffer[i++] = (byte)(c & '\u00ff')) {
                c = array[n2++];
            }
            this.count = count;
        }
        
        @Override
        public boolean needBytes() {
            return !this.closed && this.pos < this.count;
        }
        
        @Override
        public boolean needBytes(final int n) {
            return !this.closed && this.pos < this.count;
        }
    }
}
