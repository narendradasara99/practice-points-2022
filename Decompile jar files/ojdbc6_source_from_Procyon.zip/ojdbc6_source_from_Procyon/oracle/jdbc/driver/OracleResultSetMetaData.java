// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Map;
import java.sql.Connection;
import oracle.sql.StructDescriptor;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.OracleConnection;
import oracle.sql.TypeDescriptor;
import oracle.jdbc.oracore.OracleNamedType;
import java.sql.SQLException;

class OracleResultSetMetaData implements oracle.jdbc.internal.OracleResultSetMetaData
{
    PhysicalConnection connection;
    OracleStatement statement;
    int m_beginColumnIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleResultSetMetaData() {
    }
    
    public OracleResultSetMetaData(final PhysicalConnection connection, final OracleStatement statement) throws SQLException {
        this.connection = connection;
        (this.statement = statement).describe();
        this.m_beginColumnIndex = 0;
    }
    
    OracleResultSetMetaData(final PhysicalConnection connection, final OracleStatement statement, final int beginColumnIndex) throws SQLException {
        this.connection = connection;
        (this.statement = statement).describe();
        this.m_beginColumnIndex = beginColumnIndex;
    }
    
    public OracleResultSetMetaData(final OracleResultSet set) throws SQLException {
        this.statement = (OracleStatement)((OracleStatementWrapper)set.getStatement()).statement;
        this.connection = (PhysicalConnection)this.statement.getConnection();
        this.statement.describe();
        this.m_beginColumnIndex = set.getFirstUserColumnIndex();
    }
    
    @Override
    public int getColumnCount() throws SQLException {
        return this.statement.getNumberOfColumns() - this.m_beginColumnIndex;
    }
    
    @Override
    public boolean isAutoIncrement(final int n) throws SQLException {
        return false;
    }
    
    int getValidColumnIndex(final int n) throws SQLException {
        final int n2 = n + this.m_beginColumnIndex - 1;
        if (n2 < 0 || n2 >= this.statement.getNumberOfColumns()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 3, "getValidColumnIndex");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return n2;
    }
    
    @Override
    public boolean isCaseSensitive(final int n) throws SQLException {
        final int columnType = this.getColumnType(n);
        return columnType == 1 || columnType == 12 || columnType == -1;
    }
    
    @Override
    public boolean isSearchable(final int n) throws SQLException {
        final int columnType = this.getColumnType(n);
        return columnType != -4 && columnType != -1 && columnType != 2004 && columnType != 2005 && columnType != -13 && columnType != 2002 && columnType != 2008 && columnType != 2007 && columnType != 2003 && columnType != 2006 && columnType != -10;
    }
    
    @Override
    public boolean isCurrency(final int n) throws SQLException {
        final int columnType = this.getColumnType(n);
        return columnType == 2 || columnType == 6;
    }
    
    @Override
    public int isNullable(final int n) throws SQLException {
        return this.getDescription()[this.getValidColumnIndex(n)].nullable ? 1 : 0;
    }
    
    @Override
    public boolean isSigned(final int n) throws SQLException {
        return true;
    }
    
    @Override
    public int getColumnDisplaySize(final int n) throws SQLException {
        return this.getDescription()[this.getValidColumnIndex(n)].describeMaxLength;
    }
    
    @Override
    public String getColumnLabel(final int n) throws SQLException {
        return this.getColumnName(n);
    }
    
    @Override
    public String getColumnName(final int n) throws SQLException {
        return this.statement.getDescriptionWithNames()[this.getValidColumnIndex(n)].columnName;
    }
    
    @Override
    public String getSchemaName(final int n) throws SQLException {
        return "";
    }
    
    @Override
    public int getPrecision(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        switch (this.getDescription()[validColumnIndex].describeType) {
            case 112:
            case 113: {
                return -1;
            }
            case 8:
            case 24: {
                return Integer.MAX_VALUE;
            }
            case 1:
            case 96: {
                return this.getDescription()[validColumnIndex].describeMaxLength;
            }
            default: {
                return this.getDescription()[validColumnIndex].precision;
            }
        }
    }
    
    @Override
    public SecurityAttribute getSecurityAttribute(final int n) throws SQLException {
        return this.getDescription()[this.getValidColumnIndex(n)].securityAttribute;
    }
    
    @Override
    public int getScale(final int n) throws SQLException {
        final int scale = this.getDescription()[this.getValidColumnIndex(n)].scale;
        return (scale == -127 && this.statement.connection.j2ee13Compliant) ? 0 : scale;
    }
    
    @Override
    public String getTableName(final int n) throws SQLException {
        return "";
    }
    
    @Override
    public String getCatalogName(final int n) throws SQLException {
        return "";
    }
    
    @Override
    public int getColumnType(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        switch (this.getDescription()[validColumnIndex].describeType) {
            case 96: {
                if (this.getDescription()[validColumnIndex].formOfUse == 2) {
                    return -15;
                }
                return 1;
            }
            case 1: {
                if (this.getDescription()[validColumnIndex].formOfUse == 2) {
                    return -9;
                }
                return 12;
            }
            case 8: {
                return -1;
            }
            case 2:
            case 6: {
                if (this.statement.connection.j2ee13Compliant && this.getDescription()[validColumnIndex].precision != 0 && this.getDescription()[validColumnIndex].scale == -127) {
                    return 6;
                }
                return 2;
            }
            case 100: {
                return 100;
            }
            case 101: {
                return 101;
            }
            case 23: {
                return -3;
            }
            case 24: {
                return -4;
            }
            case 104:
            case 208: {
                return -8;
            }
            case 102: {
                return -10;
            }
            case 12: {
                return this.connection.mapDateToTimestamp ? 93 : 91;
            }
            case 180: {
                return 93;
            }
            case 181: {
                return -101;
            }
            case 231: {
                return -102;
            }
            case 113: {
                return 2004;
            }
            case 112: {
                if (this.getDescription()[validColumnIndex].formOfUse == 2) {
                    return 2011;
                }
                return 2005;
            }
            case 114: {
                return -13;
            }
            case 109: {
                final TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(((OracleNamedType)this.getDescription()[validColumnIndex].describeOtype).getFullName(), this.connection);
                if (typeDescriptor != null) {
                    return typeDescriptor.getTypeCode();
                }
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 60);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            case 111: {
                return 2006;
            }
            case 182: {
                return -103;
            }
            case 183: {
                return -104;
            }
            default: {
                return 1111;
            }
        }
    }
    
    @Override
    public String getColumnTypeName(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        switch (this.getDescription()[validColumnIndex].describeType) {
            case 96: {
                if (this.getDescription()[validColumnIndex].formOfUse == 2) {
                    return "NCHAR";
                }
                return "CHAR";
            }
            case 1: {
                if (this.getDescription()[validColumnIndex].formOfUse == 2) {
                    return "NVARCHAR2";
                }
                return "VARCHAR2";
            }
            case 8: {
                return "LONG";
            }
            case 2:
            case 6: {
                if (this.statement.connection.j2ee13Compliant && this.getDescription()[validColumnIndex].precision != 0 && this.getDescription()[validColumnIndex].scale == -127) {
                    return "FLOAT";
                }
                return "NUMBER";
            }
            case 100: {
                return "BINARY_FLOAT";
            }
            case 101: {
                return "BINARY_DOUBLE";
            }
            case 23: {
                return "RAW";
            }
            case 24: {
                return "LONG RAW";
            }
            case 104:
            case 208: {
                return "ROWID";
            }
            case 102: {
                return "REFCURSOR";
            }
            case 12: {
                return "DATE";
            }
            case 180: {
                return "TIMESTAMP";
            }
            case 181: {
                return "TIMESTAMP WITH TIME ZONE";
            }
            case 231: {
                return "TIMESTAMP WITH LOCAL TIME ZONE";
            }
            case 113: {
                return "BLOB";
            }
            case 112: {
                if (this.getDescription()[validColumnIndex].formOfUse == 2) {
                    return "NCLOB";
                }
                return "CLOB";
            }
            case 114: {
                return "BFILE";
            }
            case 109: {
                return ((OracleTypeADT)this.getDescription()[validColumnIndex].describeOtype).getFullName();
            }
            case 111: {
                return ((OracleTypeADT)this.getDescription()[validColumnIndex].describeOtype).getFullName();
            }
            case 182: {
                return "INTERVALYM";
            }
            case 183: {
                return "INTERVALDS";
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public boolean isReadOnly(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public boolean isWritable(final int n) throws SQLException {
        return true;
    }
    
    @Override
    public boolean isDefinitelyWritable(final int n) throws SQLException {
        return false;
    }
    
    @Override
    public String getColumnClassName(final int n) throws SQLException {
        final int validColumnIndex = this.getValidColumnIndex(n);
        switch (this.getDescription()[validColumnIndex].describeType) {
            case 1:
            case 8:
            case 96:
            case 999: {
                return "java.lang.String";
            }
            case 2:
            case 6: {
                if (this.getDescription()[validColumnIndex].precision != 0 && this.getDescription()[validColumnIndex].scale == -127) {
                    return "java.lang.Double";
                }
                return "java.math.BigDecimal";
            }
            case 23:
            case 24: {
                return "byte[]";
            }
            case 12: {
                return "java.sql.Timestamp";
            }
            case 180: {
                if (this.statement.connection.j2ee13Compliant) {
                    return "java.sql.Timestamp";
                }
                return "oracle.sql.TIMESTAMP";
            }
            case 181: {
                return "oracle.sql.TIMESTAMPTZ";
            }
            case 231: {
                return "oracle.sql.TIMESTAMPLTZ";
            }
            case 182: {
                return "oracle.sql.INTERVALYM";
            }
            case 183: {
                return "oracle.sql.INTERVALDS";
            }
            case 104:
            case 208: {
                return "oracle.sql.ROWID";
            }
            case 113: {
                return "oracle.sql.BLOB";
            }
            case 112: {
                return "oracle.sql.CLOB";
            }
            case 114: {
                return "oracle.sql.BFILE";
            }
            case 102: {
                return "OracleResultSet";
            }
            case 109: {
                switch (this.getColumnType(n)) {
                    case 2003: {
                        return "oracle.sql.ARRAY";
                    }
                    case 2007: {
                        return "oracle.sql.OPAQUE";
                    }
                    case 2008: {
                        final OracleNamedType oracleNamedType = (OracleNamedType)this.getDescription()[validColumnIndex].describeOtype;
                        final Map javaObjectTypeMap = this.connection.getJavaObjectTypeMap();
                        if (javaObjectTypeMap != null) {
                            final Class clazz = javaObjectTypeMap.get(oracleNamedType.getFullName());
                            if (clazz != null) {
                                return clazz.getName();
                            }
                        }
                        return StructDescriptor.getJavaObjectClassName(this.connection, oracleNamedType.getSchemaName(), oracleNamedType.getSimpleName());
                    }
                    case 2002: {
                        final Map typeMap = this.connection.getTypeMap();
                        if (typeMap != null) {
                            final Class clazz2 = typeMap.get(((OracleNamedType)this.getDescription()[validColumnIndex].describeOtype).getFullName());
                            if (clazz2 != null) {
                                return clazz2.getName();
                            }
                        }
                        return "oracle.sql.STRUCT";
                    }
                    case 2009: {
                        return "java.sql.SQLXML";
                    }
                    default: {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                }
                break;
            }
            case 111: {
                return "oracle.sql.REF";
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public boolean isNCHAR(final int n) throws SQLException {
        return this.getDescription()[this.getValidColumnIndex(n)].formOfUse == 2;
    }
    
    Accessor[] getDescription() throws SQLException {
        return this.statement.getDescription();
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
