// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.Datum;
import java.util.Map;
import oracle.sql.NUMBER;
import java.math.BigInteger;
import java.sql.SQLException;
import java.math.BigDecimal;

class NumberCommonAccessor extends Accessor
{
    static final boolean GET_XXX_ROUNDS = false;
    int[] digs;
    static final int LNXSGNBT = 128;
    static final byte LNXDIGS = 20;
    static final byte LNXEXPBS = 64;
    static final int LNXEXPMX = 127;
    static final BigDecimal BIGDEC_ZERO;
    static final byte MAX_LONG_EXPONENT = 9;
    static final byte MIN_LONG_EXPONENT = 9;
    static final byte MAX_INT_EXPONENT = 4;
    static final byte MIN_INT_EXPONENT = 4;
    static final byte MAX_SHORT_EXPONENT = 2;
    static final byte MIN_SHORT_EXPONENT = 2;
    static final byte MAX_BYTE_EXPONENT = 1;
    static final byte MIN_BYTE_EXPONENT = 1;
    static final int[] MAX_LONG;
    static final int[] MIN_LONG;
    static final int MAX_LONG_length = 11;
    static final int MIN_LONG_length = 12;
    static final double[] factorTable;
    static final double[] small10pow;
    static final int tablemax;
    static final double tablemaxexponent = 127.0;
    static final double tableminexponent;
    static final int MANTISSA_SIZE = 53;
    static final int[] expdigs0;
    static final int[] expdigs1;
    static final int[] expdigs2;
    static final int[] expdigs3;
    static final int[] expdigs4;
    static final int[] expdigs5;
    static final int[] expdigs6;
    static final int[] expdigs7;
    static final int[] expdigs8;
    static final int[] expdigs9;
    static final int[] expdigs10;
    static final int[] expdigs11;
    static final int[] expdigs12;
    static final int[] expdigs13;
    static final int[] expdigs14;
    static final int[] expdigs15;
    static final int[] expdigs16;
    static final int[] expdigs17;
    static final int[] expdigs18;
    static final int[] expdigs19;
    static final int[] expdigs20;
    static final int[] expdigs21;
    static final int[] expdigs22;
    static final int[] expdigs23;
    static final int[] expdigs24;
    static final int[] expdigs25;
    static final int[] expdigs26;
    static final int[] expdigs27;
    static final int[] expdigs28;
    static final int[] expdigs29;
    static final int[] expdigs30;
    static final int[] expdigs31;
    static final int[] expdigs32;
    static final int[] expdigs33;
    static final int[] expdigs34;
    static final int[] expdigs35;
    static final int[] expdigs36;
    static final int[] expdigs37;
    static final int[] expdigs38;
    static final int[] expdigs39;
    static final int[] expdigs40;
    static final int[] expdigs41;
    static final int[] expdigs42;
    static final int[] expdigs43;
    static final int[] expdigs44;
    static final int[] expdigs45;
    static final int[] expdigs46;
    static final int[] expdigs47;
    static final int[] expdigs48;
    static final int[] expdigs49;
    static final int[] expdigs50;
    static final int[] expdigs51;
    static final int[] expdigs52;
    static final int[] expdigs53;
    static final int[] expdigs54;
    static final int[] expdigs55;
    static final int[] expdigs56;
    static final int[] expdigs57;
    static final int[] expdigs58;
    static final int[] expdigs59;
    static final int[] expdigs60;
    static final int[] expdigs61;
    static final int[] expdigs62;
    static final int[] expdigs63;
    static final int[] expdigs64;
    static final int[] expdigs65;
    static final int[] expdigs66;
    static final int[] expdigs67;
    static final int[] expdigs68;
    static final int[] expdigs69;
    static final int[] expdigs70;
    static final int[] expdigs71;
    static final int[] expdigs72;
    static final int[] expdigs73;
    static final int[] expdigs74;
    static final int[] expdigs75;
    static final int[] expdigs76;
    static final int[] expdigs77;
    static final int[] expdigs78;
    static final int[] expdigs79;
    static final int[] expdigs80;
    static final int[] expdigs81;
    static final int[] expdigs82;
    static final int[] expdigs83;
    static final int[] expdigs84;
    static final int[] expdigs85;
    static final int[] expdigs86;
    static final int[] expdigs87;
    static final int[] expdigs88;
    static final int[] expdigs89;
    static final int[] expdigs90;
    static final int[] expdigs91;
    static final int[] expdigs92;
    static final int[] expdigs93;
    static final int[] expdigs94;
    static final int[] expdigs95;
    static final int[] expdigs96;
    static final int[] expdigs97;
    static final int[] expdigs98;
    static final int[] expdigs99;
    static final int[] expdigs100;
    static final int[] expdigs101;
    static final int[] expdigs102;
    static final int[] expdigs103;
    static final int[] expdigs104;
    static final int[] expdigs105;
    static final int[] expdigs106;
    static final int[] expdigs107;
    static final int[] expdigs108;
    static final int[] expdigs109;
    static final int[] expdigs110;
    static final int[] expdigs111;
    static final int[] expdigs112;
    static final int[] expdigs113;
    static final int[] expdigs114;
    static final int[] expdigs115;
    static final int[] expdigs116;
    static final int[] expdigs117;
    static final int[] expdigs118;
    static final int[] expdigs119;
    static final int[] expdigs120;
    static final int[] expdigs121;
    static final int[] expdigs122;
    static final int[] expdigs123;
    static final int[] expdigs124;
    static final int[] expdigs125;
    static final int[] expdigs126;
    static final int[] expdigs127;
    static final int[] expdigs128;
    static final int[] expdigs129;
    static final int[] expdigs130;
    static final int[] expdigs131;
    static final int[] expdigs132;
    static final int[] expdigs133;
    static final int[] expdigs134;
    static final int[] expdigs135;
    static final int[] expdigs136;
    static final int[] expdigs137;
    static final int[] expdigs138;
    static final int[] expdigs139;
    static final int[] expdigs140;
    static final int[] expdigs141;
    static final int[] expdigs142;
    static final int[] expdigs143;
    static final int[] expdigs144;
    static final int[] expdigs145;
    static final int[] expdigs146;
    static final int[] expdigs147;
    static final int[][] expdigstable;
    static final int[] nexpdigstable;
    static final int[] binexpstable;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    NumberCommonAccessor() {
        this.digs = new int[27];
    }
    
    void init(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b) throws SQLException {
        this.init(oracleStatement, 6, 6, n2, b);
        this.initForDataAccess(n3, n, null);
    }
    
    void init(final OracleStatement oracleStatement, final int n, final int n2, final boolean b, final int n3, final int n4, final int n5, final int n6, final int n7, final short n8) throws SQLException {
        this.init(oracleStatement, 6, 6, n8, false);
        this.initForDescribe(n, n2, b, n3, n4, n5, n6, n7, n8, null);
        this.initForDataAccess(0, n2, null);
    }
    
    @Override
    void initForDataAccess(final int externalType, final int internalTypeMaxLength, final String s) throws SQLException {
        if (externalType != 0) {
            this.externalType = externalType;
        }
        this.internalTypeMaxLength = 21;
        if (internalTypeMaxLength > 0 && internalTypeMaxLength < this.internalTypeMaxLength) {
            this.internalTypeMaxLength = internalTypeMaxLength;
        }
        this.byteLength = this.internalTypeMaxLength + 1;
    }
    
    @Override
    int getInt(final int n) throws SQLException {
        int n2 = 0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n3 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n3 - 1];
            final byte b2 = rowSpaceByte[n3];
            int n4 = 0;
            if ((b2 & 0xFFFFFF80) != 0x0) {
                final byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
                final byte b4 = (byte)(b - 1);
                final int n5 = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
                final int n6 = n5 + n3;
                if (b3 >= 4) {
                    if (b3 > 4) {
                        this.throwOverflow();
                    }
                    long n7 = 0L;
                    if (n5 > 1) {
                        n7 = rowSpaceByte[n3 + 1] - 1;
                        for (int i = 2 + n3; i < n6; ++i) {
                            n7 = n7 * 100L + (rowSpaceByte[i] - 1);
                        }
                    }
                    for (int j = b3 - b4; j >= 0; --j) {
                        n7 *= 100L;
                    }
                    if (n7 > 2147483647L) {
                        this.throwOverflow();
                    }
                    n4 = (int)n7;
                }
                else {
                    if (n5 > 1) {
                        n4 = rowSpaceByte[n3 + 1] - 1;
                        for (int k = 2 + n3; k < n6; ++k) {
                            n4 = n4 * 100 + (rowSpaceByte[k] - 1);
                        }
                    }
                    for (int l = b3 - b4; l >= 0; --l) {
                        n4 *= 100;
                    }
                }
            }
            else {
                final byte b5 = (byte)((~b2 & 0xFFFFFF7F) - 65);
                byte b6 = (byte)(b - 1);
                if (b6 != 20 || rowSpaceByte[n3 + b6] == 102) {
                    --b6;
                }
                final int n8 = (b6 > b5 + 1) ? (b5 + 2) : (b6 + 1);
                final int n9 = n8 + n3;
                if (b5 >= 4) {
                    if (b5 > 4) {
                        this.throwOverflow();
                    }
                    long n10 = 0L;
                    if (n8 > 1) {
                        n10 = 101 - rowSpaceByte[n3 + 1];
                        for (int n11 = 2 + n3; n11 < n9; ++n11) {
                            n10 = n10 * 100L + (101 - rowSpaceByte[n11]);
                        }
                    }
                    for (int n12 = b5 - b6; n12 >= 0; --n12) {
                        n10 *= 100L;
                    }
                    final long n13 = -n10;
                    if (n13 < -2147483648L) {
                        this.throwOverflow();
                    }
                    n4 = (int)n13;
                }
                else {
                    if (n8 > 1) {
                        n4 = 101 - rowSpaceByte[n3 + 1];
                        for (int n14 = 2 + n3; n14 < n9; ++n14) {
                            n4 = n4 * 100 + (101 - rowSpaceByte[n14]);
                        }
                    }
                    for (int n15 = b5 - b6; n15 >= 0; --n15) {
                        n4 *= 100;
                    }
                    n4 = -n4;
                }
            }
            n2 = n4;
        }
        return n2;
    }
    
    @Override
    boolean getBoolean(final int n) throws SQLException {
        boolean b = false;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n2 = this.columnIndex + this.byteLength * n + 1;
            b = (rowSpaceByte[n2 - 1] != 1 || rowSpaceByte[n2] != -128);
        }
        return b;
    }
    
    @Override
    short getShort(final int n) throws SQLException {
        short n2 = 0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n3 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n3 - 1];
            final byte b2 = rowSpaceByte[n3];
            int n4 = 0;
            if ((b2 & 0xFFFFFF80) != 0x0) {
                final byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
                if (b3 > 2) {
                    this.throwOverflow();
                }
                final byte b4 = (byte)(b - 1);
                final int n5 = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
                final int n6 = n5 + n3;
                if (n5 > 1) {
                    n4 = rowSpaceByte[n3 + 1] - 1;
                    for (int i = 2 + n3; i < n6; ++i) {
                        n4 = n4 * 100 + (rowSpaceByte[i] - 1);
                    }
                }
                for (int j = b3 - b4; j >= 0; --j) {
                    n4 *= 100;
                }
                if (b3 == 2 && n4 > 32767) {
                    this.throwOverflow();
                }
            }
            else {
                final byte b5 = (byte)((~b2 & 0xFFFFFF7F) - 65);
                if (b5 > 2) {
                    this.throwOverflow();
                }
                byte b6 = (byte)(b - 1);
                if (b6 != 20 || rowSpaceByte[n3 + b6] == 102) {
                    --b6;
                }
                final int n7 = (b6 > b5 + 1) ? (b5 + 2) : (b6 + 1);
                final int n8 = n7 + n3;
                if (n7 > 1) {
                    n4 = 101 - rowSpaceByte[n3 + 1];
                    for (int k = 2 + n3; k < n8; ++k) {
                        n4 = n4 * 100 + (101 - rowSpaceByte[k]);
                    }
                }
                for (int l = b5 - b6; l >= 0; --l) {
                    n4 *= 100;
                }
                n4 = -n4;
                if (b5 == 2 && n4 < -32768) {
                    this.throwOverflow();
                }
            }
            n2 = (short)n4;
        }
        return n2;
    }
    
    @Override
    byte getByte(final int n) throws SQLException {
        byte b = 0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n2 = this.columnIndex + this.byteLength * n + 1;
            final byte b2 = rowSpaceByte[n2 - 1];
            final byte b3 = rowSpaceByte[n2];
            int n3 = 0;
            if ((b3 & 0xFFFFFF80) != 0x0) {
                final byte b4 = (byte)((b3 & 0xFFFFFF7F) - 65);
                if (b4 > 1) {
                    this.throwOverflow();
                }
                final byte b5 = (byte)(b2 - 1);
                if (b5 > b4 + 1) {
                    switch (b4) {
                        case 0: {
                            n3 = rowSpaceByte[n2 + 1] - 1;
                            break;
                        }
                        case 1: {
                            n3 = (rowSpaceByte[n2 + 1] - 1) * 100 + (rowSpaceByte[n2 + 2] - 1);
                            if (n3 > 127) {
                                this.throwOverflow();
                                break;
                            }
                            break;
                        }
                    }
                }
                else if (b5 == 1) {
                    if (b4 == 1) {
                        n3 = (rowSpaceByte[n2 + 1] - 1) * 100;
                        if (n3 > 127) {
                            this.throwOverflow();
                        }
                    }
                    else {
                        n3 = rowSpaceByte[n2 + 1] - 1;
                    }
                }
                else if (b5 == 2) {
                    n3 = (rowSpaceByte[n2 + 1] - 1) * 100 + (rowSpaceByte[n2 + 2] - 1);
                    if (n3 > 127) {
                        this.throwOverflow();
                    }
                }
            }
            else {
                final byte b6 = (byte)((~b3 & 0xFFFFFF7F) - 65);
                if (b6 > 1) {
                    this.throwOverflow();
                }
                byte b7 = (byte)(b2 - 1);
                if (b7 != 20 || rowSpaceByte[n2 + b7] == 102) {
                    --b7;
                }
                if (b7 > b6 + 1) {
                    switch (b6) {
                        case 0: {
                            n3 = -(101 - rowSpaceByte[n2 + 1]);
                            break;
                        }
                        case 1: {
                            n3 = -((101 - rowSpaceByte[n2 + 1]) * 100 + (101 - rowSpaceByte[n2 + 2]));
                            if (n3 < -128) {
                                this.throwOverflow();
                                break;
                            }
                            break;
                        }
                    }
                }
                else if (b7 == 1) {
                    if (b6 == 1) {
                        n3 = -(101 - rowSpaceByte[n2 + 1]) * 100;
                        if (n3 < -128) {
                            this.throwOverflow();
                        }
                    }
                    else {
                        n3 = -(101 - rowSpaceByte[n2 + 1]);
                    }
                }
                else if (b7 == 2) {
                    n3 = -((101 - rowSpaceByte[n2 + 1]) * 100 + (101 - rowSpaceByte[n2 + 2]));
                    if (n3 < -128) {
                        this.throwOverflow();
                    }
                }
            }
            b = (byte)n3;
        }
        return b;
    }
    
    @Override
    long getLong(final int n) throws SQLException {
        long n2 = 0L;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n3 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n3 - 1];
            final byte b2 = rowSpaceByte[n3];
            long n4 = 0L;
            if ((b2 & 0xFFFFFF80) != 0x0) {
                if (b2 == -128 && b == 1) {
                    return 0L;
                }
                final byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
                if (b3 > 9) {
                    this.throwOverflow();
                }
                if (b3 == 9) {
                    byte b4 = 1;
                    byte b5;
                    if ((b5 = b) > 11) {
                        b5 = 11;
                    }
                    while (b4 < b5) {
                        final int n5 = rowSpaceByte[n3 + b4] & 0xFF;
                        final int n6 = NumberCommonAccessor.MAX_LONG[b4];
                        if (n5 != n6) {
                            if (n5 < n6) {
                                break;
                            }
                            this.throwOverflow();
                        }
                        ++b4;
                    }
                    if (b4 == b5 && b > 11) {
                        this.throwOverflow();
                    }
                }
                final byte b6 = (byte)(b - 1);
                final int n7 = (b6 > b3 + 1) ? (b3 + 2) : (b6 + 1);
                final int n8 = n7 + n3;
                if (n7 > 1) {
                    n4 = rowSpaceByte[n3 + 1] - 1;
                    for (int i = 2 + n3; i < n8; ++i) {
                        n4 = n4 * 100L + (rowSpaceByte[i] - 1);
                    }
                }
                for (int j = b3 - b6; j >= 0; --j) {
                    n4 *= 100L;
                }
            }
            else {
                final byte b7 = (byte)((~b2 & 0xFFFFFF7F) - 65);
                if (b7 > 9) {
                    this.throwOverflow();
                }
                if (b7 == 9) {
                    byte b8 = 1;
                    byte b9;
                    if ((b9 = b) > 12) {
                        b9 = 12;
                    }
                    while (b8 < b9) {
                        final int n9 = rowSpaceByte[n3 + b8] & 0xFF;
                        final int n10 = NumberCommonAccessor.MIN_LONG[b8];
                        if (n9 != n10) {
                            if (n9 > n10) {
                                break;
                            }
                            this.throwOverflow();
                        }
                        ++b8;
                    }
                    if (b8 == b9 && b < 12) {
                        this.throwOverflow();
                    }
                }
                byte b10 = (byte)(b - 1);
                if (b10 != 20 || rowSpaceByte[n3 + b10] == 102) {
                    --b10;
                }
                final int n11 = (b10 > b7 + 1) ? (b7 + 2) : (b10 + 1);
                final int n12 = n11 + n3;
                if (n11 > 1) {
                    n4 = 101 - rowSpaceByte[n3 + 1];
                    for (int k = 2 + n3; k < n12; ++k) {
                        n4 = n4 * 100L + (101 - rowSpaceByte[k]);
                    }
                }
                for (int l = b7 - b10; l >= 0; --l) {
                    n4 *= 100L;
                }
                n4 = -n4;
            }
            n2 = n4;
        }
        return n2;
    }
    
    @Override
    float getFloat(final int n) throws SQLException {
        float n2 = 0.0f;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n3 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n3 - 1];
            final byte b2 = rowSpaceByte[n3];
            int n4 = n3 + 1;
            double n7 = 0.0;
            if ((b2 & 0xFFFFFF80) != 0x0) {
                if (b2 == -128 && b == 1) {
                    return 0.0f;
                }
                if (b == 2 && b2 == -1 && rowSpaceByte[n3 + 1] == 101) {
                    return Float.POSITIVE_INFINITY;
                }
                byte b3;
                int n5;
                for (b3 = (byte)((b2 & 0xFFFFFF7F) - 65), n5 = b - 1; rowSpaceByte[n4] == 1 && n5 > 0; ++n4, --n5, --b3) {}
                final int n6 = (int)(127.0 - b3);
                switch (n5) {
                    case 1: {
                        n7 = (rowSpaceByte[n4] - 1) * NumberCommonAccessor.factorTable[n6];
                        break;
                    }
                    case 2: {
                        n7 = ((rowSpaceByte[n4] - 1) * 100 + (rowSpaceByte[n4 + 1] - 1)) * NumberCommonAccessor.factorTable[n6 + 1];
                        break;
                    }
                    case 3: {
                        n7 = ((rowSpaceByte[n4] - 1) * 10000 + (rowSpaceByte[n4 + 1] - 1) * 100 + (rowSpaceByte[n4 + 2] - 1)) * NumberCommonAccessor.factorTable[n6 + 2];
                        break;
                    }
                    case 4: {
                        n7 = ((rowSpaceByte[n4] - 1) * 1000000 + (rowSpaceByte[n4 + 1] - 1) * 10000 + (rowSpaceByte[n4 + 2] - 1) * 100 + (rowSpaceByte[n4 + 3] - 1)) * NumberCommonAccessor.factorTable[n6 + 3];
                        break;
                    }
                    case 5: {
                        n7 = ((rowSpaceByte[n4 + 1] - 1) * 1000000 + (rowSpaceByte[n4 + 2] - 1) * 10000 + (rowSpaceByte[n4 + 3] - 1) * 100 + (rowSpaceByte[n4 + 4] - 1)) * NumberCommonAccessor.factorTable[n6 + 4] + (rowSpaceByte[n4] - 1) * NumberCommonAccessor.factorTable[n6];
                        break;
                    }
                    case 6: {
                        n7 = ((rowSpaceByte[n4 + 2] - 1) * 1000000 + (rowSpaceByte[n4 + 3] - 1) * 10000 + (rowSpaceByte[n4 + 4] - 1) * 100 + (rowSpaceByte[n4 + 5] - 1)) * NumberCommonAccessor.factorTable[n6 + 5] + ((rowSpaceByte[n4] - 1) * 100 + (rowSpaceByte[n4 + 1] - 1)) * NumberCommonAccessor.factorTable[n6 + 1];
                        break;
                    }
                    default: {
                        n7 = ((rowSpaceByte[n4 + 3] - 1) * 1000000 + (rowSpaceByte[n4 + 4] - 1) * 10000 + (rowSpaceByte[n4 + 5] - 1) * 100 + (rowSpaceByte[n4 + 6] - 1)) * NumberCommonAccessor.factorTable[n6 + 6] + ((rowSpaceByte[n4] - 1) * 10000 + (rowSpaceByte[n4 + 1] - 1) * 100 + (rowSpaceByte[n4 + 2] - 1)) * NumberCommonAccessor.factorTable[n6 + 2];
                        break;
                    }
                }
            }
            else {
                if (b2 == 0 && b == 1) {
                    return Float.NEGATIVE_INFINITY;
                }
                byte b4 = (byte)((~b2 & 0xFFFFFF7F) - 65);
                int n8 = b - 1;
                if (n8 != 20 || rowSpaceByte[n3 + n8] == 102) {
                    --n8;
                }
                while (rowSpaceByte[n4] == 1 && n8 > 0) {
                    ++n4;
                    --n8;
                    --b4;
                }
                final int n9 = (int)(127.0 - b4);
                switch (n8) {
                    case 1: {
                        n7 = -(101 - rowSpaceByte[n4]) * NumberCommonAccessor.factorTable[n9];
                        break;
                    }
                    case 2: {
                        n7 = -((101 - rowSpaceByte[n4]) * 100 + (101 - rowSpaceByte[n4 + 1])) * NumberCommonAccessor.factorTable[n9 + 1];
                        break;
                    }
                    case 3: {
                        n7 = -((101 - rowSpaceByte[n4]) * 10000 + (101 - rowSpaceByte[n4 + 1]) * 100 + (101 - rowSpaceByte[n4 + 2])) * NumberCommonAccessor.factorTable[n9 + 2];
                        break;
                    }
                    case 4: {
                        n7 = -((101 - rowSpaceByte[n4]) * 1000000 + (101 - rowSpaceByte[n4 + 1]) * 10000 + (101 - rowSpaceByte[n4 + 2]) * 100 + (101 - rowSpaceByte[n4 + 3])) * NumberCommonAccessor.factorTable[n9 + 3];
                        break;
                    }
                    case 5: {
                        n7 = -(((101 - rowSpaceByte[n4 + 1]) * 1000000 + (101 - rowSpaceByte[n4 + 2]) * 10000 + (101 - rowSpaceByte[n4 + 3]) * 100 + (101 - rowSpaceByte[n4 + 4])) * NumberCommonAccessor.factorTable[n9 + 4] + (101 - rowSpaceByte[n4]) * NumberCommonAccessor.factorTable[n9]);
                        break;
                    }
                    case 6: {
                        n7 = -(((101 - rowSpaceByte[n4 + 2]) * 1000000 + (101 - rowSpaceByte[n4 + 3]) * 10000 + (101 - rowSpaceByte[n4 + 4]) * 100 + (101 - rowSpaceByte[n4 + 5])) * NumberCommonAccessor.factorTable[n9 + 5] + ((101 - rowSpaceByte[n4]) * 100 + (101 - rowSpaceByte[n4 + 1])) * NumberCommonAccessor.factorTable[n9 + 1]);
                        break;
                    }
                    default: {
                        n7 = -(((101 - rowSpaceByte[n4 + 3]) * 1000000 + (101 - rowSpaceByte[n4 + 4]) * 10000 + (101 - rowSpaceByte[n4 + 5]) * 100 + (101 - rowSpaceByte[n4 + 6])) * NumberCommonAccessor.factorTable[n9 + 6] + ((101 - rowSpaceByte[n4]) * 10000 + (101 - rowSpaceByte[n4 + 1]) * 100 + (101 - rowSpaceByte[n4 + 2])) * NumberCommonAccessor.factorTable[n9 + 2]);
                        break;
                    }
                }
            }
            n2 = (float)n7;
        }
        return n2;
    }
    
    @Override
    double getDouble(final int n) throws SQLException {
        double n2 = 0.0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n3 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n3 - 1];
            final byte b2 = rowSpaceByte[n3];
            final int n4 = n3 + 1;
            int n5 = b - 1;
            boolean b3 = true;
            byte b4;
            boolean b5;
            int n6;
            if ((b2 & 0xFFFFFF80) != 0x0) {
                if (b2 == -128 && b == 1) {
                    return 0.0;
                }
                if (b == 2 && b2 == -1 && rowSpaceByte[n3 + 1] == 101) {
                    return Double.POSITIVE_INFINITY;
                }
                b4 = (byte)((b2 & 0xFFFFFF7F) - 65);
                b5 = ((rowSpaceByte[n4 + n5 - 1] - 1) % 10 == 0);
                n6 = rowSpaceByte[n4] - 1;
            }
            else {
                b3 = false;
                if (b2 == 0 && b == 1) {
                    return Double.NEGATIVE_INFINITY;
                }
                b4 = (byte)((~b2 & 0xFFFFFF7F) - 65);
                if (n5 != 20 || rowSpaceByte[n3 + n5] == 102) {
                    --n5;
                }
                b5 = ((101 - rowSpaceByte[n4 + n5 - 1]) % 10 == 0);
                n6 = 101 - rowSpaceByte[n4];
            }
            int n7 = n5 << 1;
            if (b5) {
                --n7;
            }
            final int n8 = (b4 + 1 << 1) - n7;
            if (n6 < 10) {
                --n7;
            }
            double longBitsToDouble;
            if (n7 <= 15 && ((n8 >= 0 && n8 <= 37 - n7) || (n8 < 0 && n8 >= -22))) {
                int n9 = 0;
                int n10 = 0;
                int n11 = 0;
                int n12 = 0;
                int n13 = 0;
                int n14 = 0;
                int n15 = 0;
                if (b3) {
                    switch (n5) {
                        default: {
                            n15 = rowSpaceByte[n4 + 7] - 1;
                        }
                        case 7: {
                            n14 = rowSpaceByte[n4 + 6] - 1;
                        }
                        case 6: {
                            n13 = rowSpaceByte[n4 + 5] - 1;
                        }
                        case 5: {
                            n12 = rowSpaceByte[n4 + 4] - 1;
                        }
                        case 4: {
                            n11 = rowSpaceByte[n4 + 3] - 1;
                        }
                        case 3: {
                            n10 = rowSpaceByte[n4 + 2] - 1;
                        }
                        case 2: {
                            n9 = rowSpaceByte[n4 + 1] - 1;
                        }
                        case 1: {
                            break;
                        }
                    }
                }
                else {
                    switch (n5) {
                        default: {
                            n15 = 101 - rowSpaceByte[n4 + 7];
                        }
                        case 7: {
                            n14 = 101 - rowSpaceByte[n4 + 6];
                        }
                        case 6: {
                            n13 = 101 - rowSpaceByte[n4 + 5];
                        }
                        case 5: {
                            n12 = 101 - rowSpaceByte[n4 + 4];
                        }
                        case 4: {
                            n11 = 101 - rowSpaceByte[n4 + 3];
                        }
                        case 3: {
                            n10 = 101 - rowSpaceByte[n4 + 2];
                        }
                        case 2: {
                            n9 = 101 - rowSpaceByte[n4 + 1];
                        }
                        case 1: {
                            break;
                        }
                    }
                }
                double n16 = 0.0;
                if (b5) {
                    switch (n5) {
                        default: {
                            n16 = n6 / 10;
                            break;
                        }
                        case 2: {
                            n16 = n6 * 10 + n9 / 10;
                            break;
                        }
                        case 3: {
                            n16 = n6 * 1000 + n9 * 10 + n10 / 10;
                            break;
                        }
                        case 4: {
                            n16 = n6 * 100000 + n9 * 1000 + n10 * 10 + n11 / 10;
                            break;
                        }
                        case 5: {
                            n16 = n6 * 10000000 + n9 * 100000 + n10 * 1000 + n11 * 10 + n12 / 10;
                            break;
                        }
                        case 6: {
                            n16 = (double)(n6 * 1000000000L + (n9 * 10000000 + n10 * 100000 + n11 * 1000 + n12 * 10 + n13 / 10));
                            break;
                        }
                        case 7: {
                            n16 = (double)((n6 * 100 + n9) * 1000000000L + (n10 * 10000000 + n11 * 100000 + n12 * 1000 + n13 * 10 + n14 / 10));
                            break;
                        }
                        case 8: {
                            n16 = (double)((n6 * 10000 + n9 * 100 + n10) * 1000000000L + (n11 * 10000000 + n12 * 100000 + n13 * 1000 + n14 * 10 + n15 / 10));
                            break;
                        }
                    }
                }
                else {
                    switch (n5) {
                        default: {
                            n16 = n6;
                            break;
                        }
                        case 2: {
                            n16 = n6 * 100 + n9;
                            break;
                        }
                        case 3: {
                            n16 = n6 * 10000 + n9 * 100 + n10;
                            break;
                        }
                        case 4: {
                            n16 = n6 * 1000000 + n9 * 10000 + n10 * 100 + n11;
                            break;
                        }
                        case 5: {
                            n16 = (double)(n6 * 100000000L + (n9 * 1000000 + n10 * 10000 + n11 * 100 + n12));
                            break;
                        }
                        case 6: {
                            n16 = (double)((n6 * 100 + n9) * 100000000L + (n10 * 1000000 + n11 * 10000 + n12 * 100 + n13));
                            break;
                        }
                        case 7: {
                            n16 = (double)((n6 * 10000 + n9 * 100 + n10) * 100000000L + (n11 * 1000000 + n12 * 10000 + n13 * 100 + n14));
                            break;
                        }
                        case 8: {
                            n16 = (double)((n6 * 1000000 + n9 * 10000 + n10 * 100 + n11) * 100000000L + (n12 * 1000000 + n13 * 10000 + n14 * 100 + n15));
                            break;
                        }
                    }
                }
                if (n8 == 0 || n16 == 0.0) {
                    longBitsToDouble = n16;
                }
                else if (n8 >= 0) {
                    if (n8 <= 22) {
                        longBitsToDouble = n16 * NumberCommonAccessor.small10pow[n8];
                    }
                    else {
                        final int n17 = 15 - n7;
                        longBitsToDouble = n16 * NumberCommonAccessor.small10pow[n17] * NumberCommonAccessor.small10pow[n8 - n17];
                    }
                }
                else {
                    longBitsToDouble = n16 / NumberCommonAccessor.small10pow[-n8];
                }
            }
            else {
                int n18 = 0;
                int n19 = 0;
                int n20 = 0;
                int n21 = 0;
                int n22 = 0;
                int n23 = 0;
                int n24 = 0;
                int n25 = 0;
                int n26 = 0;
                int n27 = 0;
                int n28 = 0;
                int n29 = 0;
                int n30 = 0;
                int n31 = 0;
                boolean b6 = false;
                int n32;
                if (b3) {
                    int i;
                    if ((n5 & 0x1) != 0x0) {
                        i = 2;
                        n32 = n6;
                    }
                    else {
                        i = 3;
                        n32 = n6 * 100 + (rowSpaceByte[n4 + 1] - 1);
                    }
                    while (i < n5) {
                        int n33 = (rowSpaceByte[n4 + i - 1] - 1) * 100 + (rowSpaceByte[n4 + i] - 1) + n32 * 10000;
                        switch (n26) {
                            default: {
                                n32 = (n33 & 0xFFFF);
                                final int n34 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n34 & 0xFFFF);
                                final int n35 = (n34 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n35 & 0xFFFF);
                                final int n36 = (n35 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n36 & 0xFFFF);
                                final int n37 = (n36 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n37 & 0xFFFF);
                                final int n38 = (n37 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n38 & 0xFFFF);
                                final int n39 = (n38 >> 16 & 0xFFFF) + n23 * 10000;
                                n23 = (n39 & 0xFFFF);
                                final int n40 = (n39 >> 16 & 0xFFFF) + n24 * 10000;
                                n24 = (n40 & 0xFFFF);
                                n33 = (n40 >> 16 & 0xFFFF) + n25 * 10000;
                                n25 = (n33 & 0xFFFF);
                                break;
                            }
                            case 7: {
                                n32 = (n33 & 0xFFFF);
                                final int n41 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n41 & 0xFFFF);
                                final int n42 = (n41 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n42 & 0xFFFF);
                                final int n43 = (n42 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n43 & 0xFFFF);
                                final int n44 = (n43 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n44 & 0xFFFF);
                                final int n45 = (n44 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n45 & 0xFFFF);
                                final int n46 = (n45 >> 16 & 0xFFFF) + n23 * 10000;
                                n23 = (n46 & 0xFFFF);
                                n33 = (n46 >> 16 & 0xFFFF) + n24 * 10000;
                                n24 = (n33 & 0xFFFF);
                                break;
                            }
                            case 6: {
                                n32 = (n33 & 0xFFFF);
                                final int n47 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n47 & 0xFFFF);
                                final int n48 = (n47 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n48 & 0xFFFF);
                                final int n49 = (n48 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n49 & 0xFFFF);
                                final int n50 = (n49 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n50 & 0xFFFF);
                                final int n51 = (n50 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n51 & 0xFFFF);
                                n33 = (n51 >> 16 & 0xFFFF) + n23 * 10000;
                                n23 = (n33 & 0xFFFF);
                                break;
                            }
                            case 5: {
                                n32 = (n33 & 0xFFFF);
                                final int n52 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n52 & 0xFFFF);
                                final int n53 = (n52 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n53 & 0xFFFF);
                                final int n54 = (n53 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n54 & 0xFFFF);
                                final int n55 = (n54 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n55 & 0xFFFF);
                                n33 = (n55 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n33 & 0xFFFF);
                                break;
                            }
                            case 4: {
                                n32 = (n33 & 0xFFFF);
                                final int n56 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n56 & 0xFFFF);
                                final int n57 = (n56 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n57 & 0xFFFF);
                                final int n58 = (n57 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n58 & 0xFFFF);
                                n33 = (n58 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n33 & 0xFFFF);
                                break;
                            }
                            case 3: {
                                n32 = (n33 & 0xFFFF);
                                final int n59 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n59 & 0xFFFF);
                                final int n60 = (n59 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n60 & 0xFFFF);
                                n33 = (n60 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n33 & 0xFFFF);
                                break;
                            }
                            case 2: {
                                n32 = (n33 & 0xFFFF);
                                final int n61 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n61 & 0xFFFF);
                                n33 = (n61 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n33 & 0xFFFF);
                                break;
                            }
                            case 1: {
                                n32 = (n33 & 0xFFFF);
                                n33 = (n33 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n33 & 0xFFFF);
                                break;
                            }
                            case 0: {
                                n32 = (n33 & 0xFFFF);
                                break;
                            }
                        }
                        final int n62 = n33 >> 16 & 0xFFFF;
                        if (n62 != 0) {
                            switch (++n26) {
                                case 8: {
                                    n25 = n62;
                                    break;
                                }
                                case 7: {
                                    n24 = n62;
                                    break;
                                }
                                case 6: {
                                    n23 = n62;
                                    break;
                                }
                                case 5: {
                                    n22 = n62;
                                    break;
                                }
                                case 4: {
                                    n21 = n62;
                                    break;
                                }
                                case 3: {
                                    n20 = n62;
                                    break;
                                }
                                case 2: {
                                    n19 = n62;
                                    break;
                                }
                                case 1: {
                                    n18 = n62;
                                    break;
                                }
                            }
                        }
                        i += 2;
                    }
                }
                else {
                    int j;
                    if ((n5 & 0x1) != 0x0) {
                        j = 2;
                        n32 = n6;
                    }
                    else {
                        j = 3;
                        n32 = n6 * 100 + (101 - rowSpaceByte[n4 + 1]);
                    }
                    while (j < n5) {
                        int n63 = (101 - rowSpaceByte[n4 + j - 1]) * 100 + (101 - rowSpaceByte[n4 + j]) + n32 * 10000;
                        switch (n26) {
                            default: {
                                n32 = (n63 & 0xFFFF);
                                final int n64 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n64 & 0xFFFF);
                                final int n65 = (n64 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n65 & 0xFFFF);
                                final int n66 = (n65 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n66 & 0xFFFF);
                                final int n67 = (n66 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n67 & 0xFFFF);
                                final int n68 = (n67 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n68 & 0xFFFF);
                                final int n69 = (n68 >> 16 & 0xFFFF) + n23 * 10000;
                                n23 = (n69 & 0xFFFF);
                                final int n70 = (n69 >> 16 & 0xFFFF) + n24 * 10000;
                                n24 = (n70 & 0xFFFF);
                                n63 = (n70 >> 16 & 0xFFFF) + n25 * 10000;
                                n25 = (n63 & 0xFFFF);
                                break;
                            }
                            case 7: {
                                n32 = (n63 & 0xFFFF);
                                final int n71 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n71 & 0xFFFF);
                                final int n72 = (n71 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n72 & 0xFFFF);
                                final int n73 = (n72 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n73 & 0xFFFF);
                                final int n74 = (n73 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n74 & 0xFFFF);
                                final int n75 = (n74 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n75 & 0xFFFF);
                                final int n76 = (n75 >> 16 & 0xFFFF) + n23 * 10000;
                                n23 = (n76 & 0xFFFF);
                                n63 = (n76 >> 16 & 0xFFFF) + n24 * 10000;
                                n24 = (n63 & 0xFFFF);
                                break;
                            }
                            case 6: {
                                n32 = (n63 & 0xFFFF);
                                final int n77 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n77 & 0xFFFF);
                                final int n78 = (n77 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n78 & 0xFFFF);
                                final int n79 = (n78 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n79 & 0xFFFF);
                                final int n80 = (n79 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n80 & 0xFFFF);
                                final int n81 = (n80 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n81 & 0xFFFF);
                                n63 = (n81 >> 16 & 0xFFFF) + n23 * 10000;
                                n23 = (n63 & 0xFFFF);
                                break;
                            }
                            case 5: {
                                n32 = (n63 & 0xFFFF);
                                final int n82 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n82 & 0xFFFF);
                                final int n83 = (n82 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n83 & 0xFFFF);
                                final int n84 = (n83 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n84 & 0xFFFF);
                                final int n85 = (n84 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n85 & 0xFFFF);
                                n63 = (n85 >> 16 & 0xFFFF) + n22 * 10000;
                                n22 = (n63 & 0xFFFF);
                                break;
                            }
                            case 4: {
                                n32 = (n63 & 0xFFFF);
                                final int n86 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n86 & 0xFFFF);
                                final int n87 = (n86 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n87 & 0xFFFF);
                                final int n88 = (n87 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n88 & 0xFFFF);
                                n63 = (n88 >> 16 & 0xFFFF) + n21 * 10000;
                                n21 = (n63 & 0xFFFF);
                                break;
                            }
                            case 3: {
                                n32 = (n63 & 0xFFFF);
                                final int n89 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n89 & 0xFFFF);
                                final int n90 = (n89 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n90 & 0xFFFF);
                                n63 = (n90 >> 16 & 0xFFFF) + n20 * 10000;
                                n20 = (n63 & 0xFFFF);
                                break;
                            }
                            case 2: {
                                n32 = (n63 & 0xFFFF);
                                final int n91 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n91 & 0xFFFF);
                                n63 = (n91 >> 16 & 0xFFFF) + n19 * 10000;
                                n19 = (n63 & 0xFFFF);
                                break;
                            }
                            case 1: {
                                n32 = (n63 & 0xFFFF);
                                n63 = (n63 >> 16 & 0xFFFF) + n18 * 10000;
                                n18 = (n63 & 0xFFFF);
                                break;
                            }
                            case 0: {
                                n32 = (n63 & 0xFFFF);
                                break;
                            }
                        }
                        final int n92 = n63 >> 16 & 0xFFFF;
                        if (n92 != 0) {
                            switch (++n26) {
                                case 8: {
                                    n25 = n92;
                                    break;
                                }
                                case 7: {
                                    n24 = n92;
                                    break;
                                }
                                case 6: {
                                    n23 = n92;
                                    break;
                                }
                                case 5: {
                                    n22 = n92;
                                    break;
                                }
                                case 4: {
                                    n21 = n92;
                                    break;
                                }
                                case 3: {
                                    n20 = n92;
                                    break;
                                }
                                case 2: {
                                    n19 = n92;
                                    break;
                                }
                                case 1: {
                                    n18 = n92;
                                    break;
                                }
                            }
                        }
                        j += 2;
                    }
                }
                int n93 = n26;
                ++n26;
                final int n94 = 62 - b4 + n5;
                int n95 = NumberCommonAccessor.nexpdigstable[n94];
                final int[] array = NumberCommonAccessor.expdigstable[n94];
                final int n96 = n26 + 5;
                int n97 = 0;
                if (n95 > n96) {
                    n97 = n95 - n96;
                    n95 = n96;
                }
                int n98 = 0;
                int k = 0;
                int n99;
                int l;
                for (n99 = n95 - 1 + (n26 - 1) - 4, l = 0; l < n99; ++l) {
                    int n100 = k & 0xFFFF;
                    int n101 = k >> 16 & 0xFFFF;
                    for (int n102 = (n26 < l + 1) ? n26 : (l + 1), n103 = (l - n95 + 1 > 0) ? (l - n95 + 1) : 0; n103 < n102; ++n103) {
                        final int n104 = n97 + l - n103;
                        int n105 = 0;
                        switch (n103) {
                            case 8: {
                                n105 = n25 * array[n104];
                                break;
                            }
                            case 7: {
                                n105 = n24 * array[n104];
                                break;
                            }
                            case 6: {
                                n105 = n23 * array[n104];
                                break;
                            }
                            case 5: {
                                n105 = n22 * array[n104];
                                break;
                            }
                            case 4: {
                                n105 = n21 * array[n104];
                                break;
                            }
                            case 3: {
                                n105 = n20 * array[n104];
                                break;
                            }
                            case 2: {
                                n105 = n19 * array[n104];
                                break;
                            }
                            case 1: {
                                n105 = n18 * array[n104];
                                break;
                            }
                            default: {
                                n105 = n32 * array[n104];
                                break;
                            }
                        }
                        n100 += (n105 & 0xFFFF);
                        n101 += (n105 >> 16 & 0xFFFF);
                    }
                    b6 = (b6 || (n100 & 0xFFFF) != 0x0);
                    k = n101 + (n100 >> 16 & 0xFFFF);
                }
                for (n99 += 5; l < n99; ++l) {
                    int n106 = k & 0xFFFF;
                    int n107 = k >> 16 & 0xFFFF;
                    for (int n108 = (n26 < l + 1) ? n26 : (l + 1), n109 = (l - n95 + 1 > 0) ? (l - n95 + 1) : 0; n109 < n108; ++n109) {
                        final int n110 = n97 + l - n109;
                        int n111 = 0;
                        switch (n109) {
                            case 8: {
                                n111 = n25 * array[n110];
                                break;
                            }
                            case 7: {
                                n111 = n24 * array[n110];
                                break;
                            }
                            case 6: {
                                n111 = n23 * array[n110];
                                break;
                            }
                            case 5: {
                                n111 = n22 * array[n110];
                                break;
                            }
                            case 4: {
                                n111 = n21 * array[n110];
                                break;
                            }
                            case 3: {
                                n111 = n20 * array[n110];
                                break;
                            }
                            case 2: {
                                n111 = n19 * array[n110];
                                break;
                            }
                            case 1: {
                                n111 = n18 * array[n110];
                                break;
                            }
                            default: {
                                n111 = n32 * array[n110];
                                break;
                            }
                        }
                        n106 += (n111 & 0xFFFF);
                        n107 += (n111 >> 16 & 0xFFFF);
                    }
                    switch (n98++) {
                        case 4: {
                            n31 = (n106 & 0xFFFF);
                            break;
                        }
                        case 3: {
                            n30 = (n106 & 0xFFFF);
                            break;
                        }
                        case 2: {
                            n29 = (n106 & 0xFFFF);
                            break;
                        }
                        case 1: {
                            n28 = (n106 & 0xFFFF);
                            break;
                        }
                        default: {
                            n27 = (n106 & 0xFFFF);
                            break;
                        }
                    }
                    k = n107 + (n106 >> 16 & 0xFFFF);
                }
                while (k != 0) {
                    if (n98 < 5) {
                        switch (n98++) {
                            case 4: {
                                n31 = (k & 0xFFFF);
                                break;
                            }
                            case 3: {
                                n30 = (k & 0xFFFF);
                                break;
                            }
                            case 2: {
                                n29 = (k & 0xFFFF);
                                break;
                            }
                            case 1: {
                                n28 = (k & 0xFFFF);
                                break;
                            }
                            default: {
                                n27 = (k & 0xFFFF);
                                break;
                            }
                        }
                    }
                    else {
                        b6 = (b6 || n27 != 0);
                        n27 = n28;
                        n28 = n29;
                        n29 = n30;
                        n30 = n31;
                        n31 = (k & 0xFFFF);
                    }
                    k = (k >> 16 & 0xFFFF);
                    ++n93;
                }
                int n112 = (NumberCommonAccessor.binexpstable[n94] + n93) * 16 - 1;
                int n113 = 0;
                switch (n98) {
                    case 5: {
                        n113 = n31;
                        break;
                    }
                    case 4: {
                        n113 = n30;
                        break;
                    }
                    case 3: {
                        n113 = n29;
                        break;
                    }
                    case 2: {
                        n113 = n28;
                        break;
                    }
                    default: {
                        n113 = n27;
                        break;
                    }
                }
                for (int n114 = n113 >> 1; n114 != 0; n114 >>= 1) {
                    ++n112;
                }
                int n115 = 5;
                int n116 = n113 << 5;
                int n117 = 0;
                int n118 = 0;
                while ((n116 & 0x100000) == 0x0) {
                    n116 <<= 1;
                    ++n115;
                }
                switch (n98) {
                    case 5: {
                        if (n115 > 16) {
                            n116 |= (n30 << n115 - 16 | n29 >> 32 - n115);
                            n117 = (n29 << n115 | n28 << n115 - 16 | n27 >> 32 - n115);
                            n118 = (n27 & 1 << 31 - n115);
                            b6 = (b6 || n27 << n115 + 1 != 0);
                            break;
                        }
                        if (n115 == 16) {
                            n116 |= n30;
                            n117 = (n29 << 16 | n28);
                            n118 = (n27 & 0x8000);
                            b6 = (b6 || (n27 & 0x7FFF) != 0x0);
                            break;
                        }
                        n116 |= n30 >> 16 - n115;
                        n117 = (n30 << 16 + n115 | n29 << n115 | n28 >> 16 - n115);
                        n118 = (n28 & 1 << 15 - n115);
                        if (n115 < 15) {
                            b6 = (b6 || n28 << n115 + 17 != 0);
                        }
                        b6 = (b6 || n27 != 0);
                        break;
                    }
                    case 4: {
                        if (n115 > 16) {
                            n116 |= (n29 << n115 - 16 | n28 >> 32 - n115);
                            n117 = (n28 << n115 | n27 << n115 - 16);
                            break;
                        }
                        if (n115 == 16) {
                            n116 |= n29;
                            n117 = (n28 << 16 | n27);
                            break;
                        }
                        n116 |= n29 >> 16 - n115;
                        n117 = (n29 << 16 + n115 | n28 << n115 | n27 >> 16 - n115);
                        n118 = (n27 & 1 << 15 - n115);
                        if (n115 < 15) {
                            b6 = (b6 || n27 << n115 + 17 != 0);
                            break;
                        }
                        break;
                    }
                    case 3: {
                        if (n115 > 16) {
                            n116 |= (n28 << n115 - 16 | n27 >> 32 - n115);
                            n117 = n27 << n115;
                            break;
                        }
                        if (n115 == 16) {
                            n116 |= n28;
                            n117 = n27 << 16;
                            break;
                        }
                        n116 |= n28 >> 16 - n115;
                        n117 = (n28 << 16 + n115 | n27 << n115);
                        break;
                    }
                    case 2: {
                        if (n115 > 16) {
                            n116 |= n27 << n115 - 16;
                            break;
                        }
                        if (n115 == 16) {
                            n116 |= n27;
                            break;
                        }
                        n116 |= n27 >> 16 - n115;
                        n117 = n27 << 16 + n115;
                        break;
                    }
                }
                if (n118 != 0 && (b6 || (n117 & 0x1) != 0x0)) {
                    if (n117 == -1) {
                        n117 = 0;
                        if ((++n116 & 0x200000) != 0x0) {
                            n117 = (n117 >> 1 | n116 << 31);
                            n116 >>= 1;
                            ++n112;
                        }
                    }
                    else {
                        ++n117;
                    }
                }
                longBitsToDouble = Double.longBitsToDouble((long)n112 << 52 | (long)(n116 & 0xFFFFF) << 32 | ((long)n117 & 0xFFFFFFFFL));
            }
            n2 = (b3 ? longBitsToDouble : (-longBitsToDouble));
        }
        return n2;
    }
    
    double getDoubleImprecise(final int n) throws SQLException {
        double n2 = 0.0;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n3 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n3 - 1];
            final byte b2 = rowSpaceByte[n3];
            double n4 = 0.0;
            final int n5 = n3 + 1;
            if ((b2 & 0xFFFFFF80) != 0x0) {
                if (b2 == -128 && b == 1) {
                    return 0.0;
                }
                if (b == 2 && b2 == -1 && rowSpaceByte[n3 + 1] == 101) {
                    return Double.POSITIVE_INFINITY;
                }
                final byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
                final int n6 = b - 1;
                final int n7 = (int)(127.0 - b3);
                int i = n6 % 4;
                switch (i) {
                    case 1: {
                        n4 = (rowSpaceByte[n5] - 1) * NumberCommonAccessor.factorTable[n7];
                        break;
                    }
                    case 2: {
                        n4 = ((rowSpaceByte[n5] - 1) * 100 + (rowSpaceByte[n5 + 1] - 1)) * NumberCommonAccessor.factorTable[n7 + 1];
                        break;
                    }
                    case 3: {
                        n4 = ((rowSpaceByte[n5] - 1) * 10000 + (rowSpaceByte[n5 + 1] - 1) * 100 + (rowSpaceByte[n5 + 2] - 1)) * NumberCommonAccessor.factorTable[n7 + 2];
                        break;
                    }
                }
                while (i < n6) {
                    n4 += ((rowSpaceByte[n5 + i] - 1) * 1000000 + (rowSpaceByte[n5 + i + 1] - 1) * 10000 + (rowSpaceByte[n5 + i + 2] - 1) * 100 + (rowSpaceByte[n5 + i + 3] - 1)) * NumberCommonAccessor.factorTable[n7 + i + 3];
                    i += 4;
                }
            }
            else {
                if (b2 == 0 && b == 1) {
                    return Double.NEGATIVE_INFINITY;
                }
                final byte b4 = (byte)((~b2 & 0xFFFFFF7F) - 65);
                int n8 = b - 1;
                if (n8 != 20 || rowSpaceByte[n3 + n8] == 102) {
                    --n8;
                }
                final int n9 = (int)(127.0 - b4);
                int j = n8 % 4;
                switch (j) {
                    case 1: {
                        n4 = (101 - rowSpaceByte[n5]) * NumberCommonAccessor.factorTable[n9];
                        break;
                    }
                    case 2: {
                        n4 = ((101 - rowSpaceByte[n5]) * 100 + (101 - rowSpaceByte[n5 + 1])) * NumberCommonAccessor.factorTable[n9 + 1];
                        break;
                    }
                    case 3: {
                        n4 = ((101 - rowSpaceByte[n5]) * 10000 + (101 - rowSpaceByte[n5 + 1]) * 100 + (101 - rowSpaceByte[n5 + 2])) * NumberCommonAccessor.factorTable[n9 + 2];
                        break;
                    }
                }
                while (j < n8) {
                    n4 += ((101 - rowSpaceByte[n5 + j]) * 1000000 + (101 - rowSpaceByte[n5 + j + 1]) * 10000 + (101 - rowSpaceByte[n5 + j + 2]) * 100 + (101 - rowSpaceByte[n5 + j + 3])) * NumberCommonAccessor.factorTable[n9 + j + 3];
                    j += 4;
                }
                n4 = -n4;
            }
            n2 = n4;
        }
        return n2;
    }
    
    @Override
    BigDecimal getBigDecimal(final int n) throws SQLException {
        BigDecimal bigDecimal = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final byte[] rowSpaceByte = this.rowSpaceByte;
            final int n2 = this.columnIndex + this.byteLength * n + 1;
            final byte b = rowSpaceByte[n2 - 1];
            for (int i = 0; i < 27; ++i) {
                this.digs[i] = 0;
            }
            final byte b2 = 1;
            int n3 = 26;
            final byte b3 = rowSpaceByte[n2];
            boolean b4 = false;
            int signum;
            int n4;
            int j;
            int n5;
            byte b8;
            int n6;
            if ((b3 & 0xFFFFFF80) != 0x0) {
                if (b3 == -128 && b == 1) {
                    return NumberCommonAccessor.BIGDEC_ZERO;
                }
                if (b == 2 && b3 == -1 && rowSpaceByte[n2 + 1] == 101) {
                    this.throwOverflow();
                }
                signum = 1;
                final byte b5 = (byte)((b3 & 0xFFFFFF7F) - 65);
                n4 = b - 1;
                j = n4 - 1;
                n5 = b5 - n4 + 1 << 1;
                if (n5 > 0) {
                    n5 = 0;
                    j = b5;
                }
                else if (n5 < 0) {
                    b4 = ((rowSpaceByte[n2 + n4] - 1) % 10 == 0);
                }
                final byte[] array = rowSpaceByte;
                final byte b6 = (byte)n2;
                final byte b7 = b2;
                b8 = (byte)(b2 + 1);
                n6 = array[b6 + b7] - 1;
                while ((j & 0x1) != 0x0) {
                    if (b8 > n4) {
                        n6 *= 100;
                    }
                    else {
                        final int n7 = n6 * 100;
                        final byte[] array2 = rowSpaceByte;
                        final byte b9 = (byte)n2;
                        final byte b10 = b8;
                        ++b8;
                        n6 = n7 + (array2[b9 + b10] - 1);
                    }
                    --j;
                }
            }
            else {
                if (b3 == 0 && b == 1) {
                    this.throwOverflow();
                }
                signum = -1;
                final byte b11 = (byte)((~b3 & 0xFFFFFF7F) - 65);
                n4 = b - 1;
                if (n4 != 20 || rowSpaceByte[n2 + n4] == 102) {
                    --n4;
                }
                j = n4 - 1;
                n5 = b11 - n4 + 1 << 1;
                if (n5 > 0) {
                    n5 = 0;
                    j = b11;
                }
                else if (n5 < 0) {
                    b4 = ((101 - rowSpaceByte[n2 + n4]) % 10 == 0);
                }
                final byte b12 = 101;
                final byte[] array3 = rowSpaceByte;
                final byte b13 = (byte)n2;
                final byte b14 = b2;
                b8 = (byte)(b2 + 1);
                n6 = b12 - array3[b13 + b14];
                while ((j & 0x1) != 0x0) {
                    if (b8 > n4) {
                        n6 *= 100;
                    }
                    else {
                        final int n8 = n6 * 100;
                        final byte b15 = 101;
                        final byte[] array4 = rowSpaceByte;
                        final byte b16 = (byte)n2;
                        final byte b17 = b8;
                        ++b8;
                        n6 = n8 + (b15 - array4[b16 + b17]);
                    }
                    --j;
                }
            }
            if (b4) {
                ++n5;
                n6 /= 10;
            }
            final int n9 = n4 - 1;
            while (j != 0) {
                int n10;
                if (signum == 1) {
                    if (b4) {
                        n10 = (rowSpaceByte[n2 + b8 - 1] - 1) % 10 * 1000 + (rowSpaceByte[n2 + b8] - 1) * 10 + (rowSpaceByte[n2 + b8 + 1] - 1) / 10 + n6 * 10000;
                        b8 += 2;
                    }
                    else if (b8 < n9) {
                        n10 = (rowSpaceByte[n2 + b8] - 1) * 100 + (rowSpaceByte[n2 + b8 + 1] - 1) + n6 * 10000;
                        b8 += 2;
                    }
                    else {
                        int n11 = 0;
                        if (b8 <= n4) {
                            int k;
                            int n12;
                            byte[] array5;
                            byte b18;
                            byte b19;
                            for (k = 0; b8 <= n4; ++b8, n11 = n12 + (array5[b18 + b19] - 1), ++k) {
                                n12 = n11 * 100;
                                array5 = rowSpaceByte;
                                b18 = (byte)n2;
                                b19 = b8;
                            }
                            while (k < 2) {
                                n11 *= 100;
                                ++k;
                            }
                        }
                        n10 = n11 + n6 * 10000;
                    }
                }
                else if (b4) {
                    n10 = (101 - rowSpaceByte[n2 + b8 - 1]) % 10 * 1000 + (101 - rowSpaceByte[n2 + b8]) * 10 + (101 - rowSpaceByte[n2 + b8 + 1]) / 10 + n6 * 10000;
                    b8 += 2;
                }
                else if (b8 < n9) {
                    n10 = (101 - rowSpaceByte[n2 + b8]) * 100 + (101 - rowSpaceByte[n2 + b8 + 1]) + n6 * 10000;
                    b8 += 2;
                }
                else {
                    int n13 = 0;
                    if (b8 <= n4) {
                        int l;
                        int n14;
                        byte b20;
                        byte[] array6;
                        byte b21;
                        byte b22;
                        for (l = 0; b8 <= n4; ++b8, n13 = n14 + (b20 - array6[b21 + b22]), ++l) {
                            n14 = n13 * 100;
                            b20 = 101;
                            array6 = rowSpaceByte;
                            b21 = (byte)n2;
                            b22 = b8;
                        }
                        while (l < 2) {
                            n13 *= 100;
                            ++l;
                        }
                    }
                    n10 = n13 + n6 * 10000;
                }
                n6 = (n10 & 0xFFFF);
                for (int n15 = 25; n15 >= n3; --n15) {
                    n10 = (n10 >> 16) + this.digs[n15] * 10000;
                    this.digs[n15] = (n10 & 0xFFFF);
                }
                if (n3 > 0) {
                    final int n16 = n10 >> 16;
                    if (n16 != 0) {
                        final int[] digs = this.digs;
                        n3 = (byte)(n3 - 1);
                        digs[n3] = n16;
                    }
                }
                j -= 2;
            }
            this.digs[26] = n6;
            final byte b23 = (byte)(this.digs[n3] >> 8 & 0xFF);
            int n17;
            byte[] magnitude;
            if (b23 == 0) {
                n17 = 53 - (n3 << 1);
                magnitude = new byte[n17];
                for (int n18 = 26; n18 > n3; --n18) {
                    final int n19 = n18 - n3 << 1;
                    magnitude[n19 - 1] = (byte)(this.digs[n18] >> 8 & 0xFF);
                    magnitude[n19] = (byte)(this.digs[n18] & 0xFF);
                }
                magnitude[0] = (byte)(this.digs[n3] & 0xFF);
            }
            else {
                n17 = 54 - (n3 << 1);
                magnitude = new byte[n17];
                for (int n20 = 26; n20 > n3; --n20) {
                    final int n21 = n20 - n3 << 1;
                    magnitude[n21] = (byte)(this.digs[n20] >> 8 & 0xFF);
                    magnitude[n21 + 1] = (byte)(this.digs[n20] & 0xFF);
                }
                magnitude[0] = b23;
                magnitude[1] = (byte)(this.digs[n3] & 0xFF);
            }
            if (n5 == 0 && n17 < 8 && n17 > 0) {
                long n22 = (long)magnitude[0] & 0xFFL;
                for (int n23 = 1; n23 < n17; ++n23) {
                    n22 = (n22 << 8 | (long)(magnitude[n23] & 0xFF));
                }
                bigDecimal = new BigDecimal(n22 * signum);
            }
            else {
                bigDecimal = new BigDecimal(new BigInteger(signum, magnitude), -n5);
            }
        }
        return bigDecimal;
    }
    
    @Override
    BigDecimal getBigDecimal(final int n, final int newScale) throws SQLException {
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return null;
        }
        return this.getBigDecimal(n).setScale(newScale, 6);
    }
    
    @Override
    String getString(final int n) throws SQLException {
        final String s = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return s;
        }
        final byte[] rowSpaceByte = this.rowSpaceByte;
        final int n2 = this.columnIndex + this.byteLength * n + 1;
        final byte b = rowSpaceByte[n2 - 1];
        final byte[] array = new byte[b];
        System.arraycopy(rowSpaceByte, n2, array, 0, b);
        final NUMBER number = new NUMBER(array);
        final String string = oracle.sql.NUMBER.toString(array);
        int length = string.length();
        if (string.startsWith("0.") || string.startsWith("-0.")) {
            --length;
        }
        if (length > 38) {
            final String text = number.toText(-44, null);
            int n3 = text.indexOf(69);
            final int index = text.indexOf(43);
            if (n3 == -1) {
                n3 = text.indexOf(101);
            }
            int index2;
            for (index2 = n3 - 1; text.charAt(index2) == '0'; --index2) {}
            final String substring = text.substring(0, index2 + 1);
            String str;
            if (index > 0) {
                str = text.substring(index + 1);
            }
            else {
                str = text.substring(n3 + 1);
            }
            return (substring + "E" + str).trim();
        }
        return number.toText(38, null).trim();
    }
    
    @Override
    NUMBER getNUMBER(final int n) throws SQLException {
        NUMBER number = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n + 1;
            final byte b = this.rowSpaceByte[n2 - 1];
            final byte[] array = new byte[b];
            System.arraycopy(this.rowSpaceByte, n2, array, 0, b);
            number = new NUMBER(array);
        }
        return number;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        Object bigDecimal = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            if (this.externalType == 0) {
                if (this.statement.connection.j2ee13Compliant && this.precision != 0 && this.scale == -127) {
                    bigDecimal = new Double(this.getDouble(n));
                }
                else {
                    bigDecimal = this.getBigDecimal(n);
                }
            }
            else {
                switch (this.externalType) {
                    case -7: {
                        return this.getBoolean(n);
                    }
                    case -6: {
                        return this.getByte(n);
                    }
                    case 5: {
                        return this.getShort(n);
                    }
                    case 4: {
                        return this.getInt(n);
                    }
                    case -5: {
                        return this.getLong(n);
                    }
                    case 6:
                    case 8: {
                        return this.getDouble(n);
                    }
                    case 7: {
                        return this.getFloat(n);
                    }
                    case 2:
                    case 3: {
                        return this.getBigDecimal(n);
                    }
                    default: {
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                }
            }
        }
        return bigDecimal;
    }
    
    @Override
    Object getObject(final int n, final Map map) throws SQLException {
        return this.getObject(n);
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        return this.getNUMBER(n);
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
            final int n2 = this.columnIndex + this.byteLength * n + 1;
            final byte b = this.rowSpaceByte[n2 - 1];
            o = new byte[b];
            System.arraycopy(this.rowSpaceByte, n2, o, 0, b);
        }
        return (byte[])o;
    }
    
    void throwOverflow() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    static {
        BIGDEC_ZERO = BigDecimal.valueOf(0L);
        MAX_LONG = new int[] { 202, 10, 23, 34, 73, 4, 69, 55, 78, 59, 8 };
        MIN_LONG = new int[] { 53, 92, 79, 68, 29, 98, 33, 47, 24, 43, 93, 102 };
        factorTable = new double[] { 1.0E254, 1.0E252, 1.0E250, 1.0E248, 1.0E246, 1.0E244, 1.0E242, 1.0E240, 1.0E238, 1.0E236, 1.0E234, 1.0E232, 1.0E230, 1.0E228, 1.0E226, 1.0E224, 1.0E222, 1.0E220, 1.0E218, 1.0E216, 1.0E214, 1.0E212, 1.0E210, 1.0E208, 1.0E206, 1.0E204, 1.0E202, 1.0E200, 1.0E198, 1.0E196, 1.0E194, 1.0E192, 1.0E190, 1.0E188, 1.0E186, 1.0E184, 1.0E182, 1.0E180, 1.0E178, 1.0E176, 1.0E174, 1.0E172, 1.0E170, 1.0E168, 1.0E166, 1.0E164, 1.0E162, 1.0E160, 1.0E158, 1.0E156, 1.0E154, 1.0E152, 1.0E150, 1.0E148, 1.0E146, 1.0E144, 1.0E142, 1.0E140, 1.0E138, 1.0E136, 1.0E134, 1.0E132, 1.0E130, 1.0E128, 1.0E126, 1.0E124, 1.0E122, 1.0E120, 1.0E118, 1.0E116, 1.0E114, 1.0E112, 1.0E110, 1.0E108, 1.0E106, 1.0E104, 1.0E102, 1.0E100, 1.0E98, 1.0E96, 1.0E94, 1.0E92, 1.0E90, 1.0E88, 1.0E86, 1.0E84, 1.0E82, 1.0E80, 1.0E78, 1.0E76, 1.0E74, 1.0E72, 1.0E70, 1.0E68, 1.0E66, 1.0E64, 1.0E62, 1.0E60, 1.0E58, 1.0E56, 1.0E54, 1.0E52, 1.0E50, 1.0E48, 1.0E46, 1.0E44, 1.0E42, 1.0E40, 1.0E38, 1.0E36, 1.0E34, 1.0E32, 1.0E30, 1.0E28, 1.0E26, 1.0E24, 1.0E22, 1.0E20, 1.0E18, 1.0E16, 1.0E14, 1.0E12, 1.0E10, 1.0E8, 1000000.0, 10000.0, 100.0, 1.0, 0.01, 1.0E-4, 1.0E-6, 1.0E-8, 1.0E-10, 1.0E-12, 1.0E-14, 1.0E-16, 1.0E-18, 1.0E-20, 1.0E-22, 1.0E-24, 1.0E-26, 1.0E-28, 1.0E-30, 1.0E-32, 1.0E-34, 1.0E-36, 1.0E-38, 1.0E-40, 1.0E-42, 1.0E-44, 1.0E-46, 1.0E-48, 1.0E-50, 1.0E-52, 1.0E-54, 1.0E-56, 1.0E-58, 1.0E-60, 1.0E-62, 1.0E-64, 1.0E-66, 1.0E-68, 1.0E-70, 1.0E-72, 1.0E-74, 1.0E-76, 1.0E-78, 1.0E-80, 1.0E-82, 1.0E-84, 1.0E-86, 1.0E-88, 1.0E-90, 1.0E-92, 1.0E-94, 1.0E-96, 1.0E-98, 1.0E-100, 1.0E-102, 1.0E-104, 1.0E-106, 1.0E-108, 1.0E-110, 1.0E-112, 1.0E-114, 1.0E-116, 1.0E-118, 1.0E-120, 1.0E-122, 1.0E-124, 1.0E-126, 1.0E-128, 1.0E-130, 1.0E-132, 1.0E-134, 1.0E-136, 1.0E-138, 1.0E-140, 1.0E-142, 1.0E-144, 1.0E-146, 1.0E-148, 1.0E-150, 1.0E-152, 1.0E-154, 1.0E-156, 1.0E-158, 1.0E-160, 1.0E-162, 1.0E-164, 1.0E-166, 1.0E-168, 1.0E-170, 1.0E-172, 1.0E-174, 1.0E-176, 1.0E-178, 1.0E-180, 1.0E-182, 1.0E-184, 1.0E-186, 1.0E-188, 1.0E-190, 1.0E-192, 1.0E-194, 1.0E-196, 1.0E-198, 1.0E-200, 1.0E-202, 1.0E-204, 1.0E-206, 1.0E-208, 1.0E-210, 1.0E-212, 1.0E-214, 1.0E-216, 1.0E-218, 1.0E-220, 1.0E-222, 1.0E-224, 1.0E-226, 1.0E-228, 1.0E-230, 1.0E-232, 1.0E-234, 1.0E-236, 1.0E-238, 1.0E-240, 1.0E-242, 1.0E-244, 1.0E-246, 1.0E-248, 1.0E-250, 1.0E-252, 1.0E-254 };
        small10pow = new double[] { 1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 1.0E7, 1.0E8, 1.0E9, 1.0E10, 1.0E11, 1.0E12, 1.0E13, 1.0E14, 1.0E15, 1.0E16, 1.0E17, 1.0E18, 1.0E19, 1.0E20, 1.0E21, 1.0E22 };
        tablemax = NumberCommonAccessor.factorTable.length;
        tableminexponent = 127.0 - (NumberCommonAccessor.tablemax - 20);
        expdigs0 = new int[] { 25597, 55634, 18440, 18324, 42485, 50370, 56862, 11593, 45703, 57341, 10255, 12549, 59579, 5 };
        expdigs1 = new int[] { 50890, 19916, 24149, 23777, 11324, 41057, 14921, 56274, 30917, 19462, 54968, 47943, 38791, 3872 };
        expdigs2 = new int[] { 24101, 29690, 40218, 29073, 29604, 22037, 27674, 9082, 56670, 55244, 20865, 54874, 47573, 38 };
        expdigs3 = new int[] { 22191, 40873, 1607, 45622, 23883, 24544, 32988, 43530, 61694, 55616, 43150, 32976, 27418, 25379 };
        expdigs4 = new int[] { 55927, 44317, 6569, 54851, 238, 63160, 51447, 12231, 55667, 25459, 5674, 40962, 52047, 253 };
        expdigs5 = new int[] { 56264, 8962, 51839, 64773, 39323, 49783, 15587, 30924, 36601, 56615, 27581, 36454, 35254, 2 };
        expdigs6 = new int[] { 21545, 25466, 59727, 37873, 13099, 7602, 15571, 49963, 37664, 46896, 14328, 59258, 17403, 1663 };
        expdigs7 = new int[] { 12011, 4842, 3874, 57395, 38141, 46606, 49307, 60792, 31833, 21440, 9318, 47123, 41461, 16 };
        expdigs8 = new int[] { 52383, 25023, 56409, 43947, 51036, 17420, 62725, 5735, 53692, 44882, 64439, 36137, 24719, 10900 };
        expdigs9 = new int[] { 65404, 27119, 57580, 26653, 42453, 19179, 26186, 42000, 1847, 62708, 14406, 12813, 247, 109 };
        expdigs10 = new int[] { 36698, 50078, 40552, 35000, 49576, 56552, 261, 49572, 31475, 59609, 45363, 46658, 5900, 1 };
        expdigs11 = new int[] { 33321, 54106, 42443, 60698, 47535, 24088, 45785, 18352, 47026, 40291, 5183, 35843, 24059, 714 };
        expdigs12 = new int[] { 12129, 44450, 22706, 34030, 37175, 8760, 31915, 56544, 23407, 52176, 7260, 41646, 9415, 7 };
        expdigs13 = new int[] { 43054, 17160, 43698, 6780, 36385, 52800, 62346, 52747, 33988, 2855, 31979, 38083, 44325, 4681 };
        expdigs14 = new int[] { 60723, 40803, 16165, 19073, 2985, 9703, 41911, 37227, 41627, 1994, 38986, 27250, 53527, 46 };
        expdigs15 = new int[] { 36481, 57623, 45627, 58488, 53274, 7238, 2063, 31221, 62631, 25319, 35409, 25293, 54667, 30681 };
        expdigs16 = new int[] { 52138, 47106, 3077, 4517, 41165, 38738, 39997, 10142, 13078, 16637, 53438, 54647, 53630, 306 };
        expdigs17 = new int[] { 25425, 24719, 55736, 8564, 12208, 3664, 51518, 17140, 61079, 30312, 2500, 30693, 4468, 3 };
        expdigs18 = new int[] { 58368, 65134, 52675, 3178, 26300, 7986, 11833, 515, 23109, 63525, 29138, 19030, 50114, 2010 };
        expdigs19 = new int[] { 41216, 15724, 12323, 26246, 59245, 58406, 46648, 13767, 11372, 15053, 61895, 48686, 7054, 20 };
        expdigs20 = new int[] { 0, 29248, 62416, 1433, 14025, 43846, 39905, 44375, 137, 47955, 62409, 33386, 48983, 13177 };
        expdigs21 = new int[] { 0, 21264, 53708, 60962, 25043, 64008, 31200, 50906, 9831, 56185, 43877, 36378, 50952, 131 };
        expdigs22 = new int[] { 0, 50020, 25440, 60247, 44814, 39961, 6865, 26068, 34832, 9081, 17478, 44928, 20825, 1 };
        expdigs23 = new int[] { 0, 0, 52929, 10084, 25506, 6346, 61348, 31525, 52689, 61296, 27615, 15903, 40426, 863 };
        expdigs24 = new int[] { 0, 16384, 24122, 53840, 43508, 13170, 51076, 37670, 58198, 31414, 57292, 61762, 41691, 8 };
        expdigs25 = new int[] { 0, 0, 4096, 29077, 42481, 30581, 10617, 59493, 46251, 1892, 5557, 4505, 52391, 5659 };
        expdigs26 = new int[] { 0, 0, 58368, 11431, 1080, 29797, 47947, 36639, 42405, 50481, 29546, 9875, 39190, 56 };
        expdigs27 = new int[] { 0, 0, 0, 57600, 63028, 53094, 12749, 18174, 21993, 48265, 14922, 59933, 4030, 37092 };
        expdigs28 = new int[] { 0, 0, 0, 576, 1941, 35265, 9302, 42780, 50682, 28007, 29640, 28124, 60333, 370 };
        expdigs29 = new int[] { 0, 0, 0, 5904, 8539, 12149, 36793, 43681, 12958, 60573, 21267, 35015, 46478, 3 };
        expdigs30 = new int[] { 0, 0, 0, 0, 7268, 50548, 47962, 3644, 22719, 26999, 41893, 7421, 56711, 2430 };
        expdigs31 = new int[] { 0, 0, 0, 0, 7937, 49002, 60772, 28216, 38893, 55975, 63988, 59711, 20227, 24 };
        expdigs32 = new int[] { 0, 0, 0, 16384, 38090, 63404, 55657, 8801, 62648, 13666, 57656, 60234, 15930 };
        expdigs33 = new int[] { 0, 0, 0, 4096, 37081, 37989, 16940, 55138, 17665, 39458, 9751, 20263, 159 };
        expdigs34 = new int[] { 0, 0, 0, 58368, 35104, 16108, 61773, 14313, 30323, 54789, 57113, 38868, 1 };
        expdigs35 = new int[] { 0, 0, 0, 8448, 18701, 29652, 51080, 65023, 27172, 37903, 3192, 1044 };
        expdigs36 = new int[] { 0, 0, 0, 37440, 63101, 2917, 39177, 50457, 25830, 50186, 28867, 10 };
        expdigs37 = new int[] { 0, 0, 0, 56080, 45850, 37384, 3668, 12301, 38269, 18196, 6842 };
        expdigs38 = new int[] { 0, 0, 0, 46436, 13565, 50181, 34770, 37478, 5625, 27707, 68 };
        expdigs39 = new int[] { 0, 0, 0, 32577, 45355, 38512, 38358, 3651, 36101, 44841 };
        expdigs40 = new int[] { 0, 0, 16384, 28506, 5696, 56746, 15456, 50499, 27230, 448 };
        expdigs41 = new int[] { 0, 0, 4096, 285, 9232, 58239, 57170, 38515, 31729, 4 };
        expdigs42 = new int[] { 0, 0, 58368, 41945, 57108, 12378, 28752, 48226, 2938 };
        expdigs43 = new int[] { 0, 0, 24832, 47605, 49067, 23716, 61891, 25385, 29 };
        expdigs44 = new int[] { 0, 0, 8768, 2442, 50298, 23174, 19624, 19259 };
        expdigs45 = new int[] { 0, 0, 40720, 45899, 1813, 31689, 38862, 192 };
        expdigs46 = new int[] { 0, 0, 36452, 14221, 34752, 48813, 60681, 1 };
        expdigs47 = new int[] { 0, 0, 61313, 34220, 16731, 11629, 1262 };
        expdigs48 = new int[] { 0, 16384, 60906, 18036, 40144, 40748, 12 };
        expdigs49 = new int[] { 0, 4096, 609, 15909, 52830, 8271 };
        expdigs50 = new int[] { 0, 58368, 3282, 56520, 47058, 82 };
        expdigs51 = new int[] { 0, 41216, 52461, 7118, 54210 };
        expdigs52 = new int[] { 0, 45632, 51642, 6624, 542 };
        expdigs53 = new int[] { 0, 25360, 24109, 27591, 5 };
        expdigs54 = new int[] { 0, 42852, 46771, 3552 };
        expdigs55 = new int[] { 0, 28609, 34546, 35 };
        expdigs56 = new int[] { 16384, 4218, 23283 };
        expdigs57 = new int[] { 4096, 54437, 232 };
        expdigs58 = new int[] { 58368, 21515, 2 };
        expdigs59 = new int[] { 57600, 1525 };
        expdigs60 = new int[] { 16960, 15 };
        expdigs61 = new int[] { 10000 };
        expdigs62 = new int[] { 100 };
        expdigs63 = new int[] { 1 };
        expdigs64 = new int[] { 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 655 };
        expdigs65 = new int[] { 14784, 18979, 33659, 19503, 2726, 9542, 629, 2202, 40475, 10590, 4299, 47815, 36280, 6 };
        expdigs66 = new int[] { 16332, 9978, 33613, 31138, 35584, 64252, 13857, 14424, 62281, 46279, 36150, 46573, 63392, 4294 };
        expdigs67 = new int[] { 6716, 24348, 22618, 23904, 21327, 3919, 44703, 19149, 28803, 48959, 6259, 50273, 62237, 42 };
        expdigs68 = new int[] { 8471, 23660, 38254, 26440, 33662, 38879, 9869, 11588, 41479, 23225, 60127, 24310, 32615, 28147 };
        expdigs69 = new int[] { 13191, 6790, 63297, 30410, 12788, 42987, 23691, 28296, 32527, 38898, 41233, 4830, 31128, 281 };
        expdigs70 = new int[] { 4064, 53152, 62236, 29139, 46658, 12881, 31694, 4870, 19986, 24637, 9587, 28884, 53395, 2 };
        expdigs71 = new int[] { 26266, 10526, 16260, 55017, 35680, 40443, 19789, 17356, 30195, 55905, 28426, 63010, 44197, 1844 };
        expdigs72 = new int[] { 38273, 7969, 37518, 26764, 23294, 63974, 18547, 17868, 24550, 41191, 17323, 53714, 29277, 18 };
        expdigs73 = new int[] { 16739, 37738, 38090, 26589, 43521, 1543, 15713, 10671, 11975, 41533, 18106, 9348, 16921, 12089 };
        expdigs74 = new int[] { 14585, 61981, 58707, 16649, 25994, 39992, 28337, 17801, 37475, 22697, 31638, 16477, 58496, 120 };
        expdigs75 = new int[] { 58472, 2585, 40564, 27691, 44824, 27269, 58610, 54572, 35108, 30373, 35050, 10650, 13692, 1 };
        expdigs76 = new int[] { 50392, 58911, 41968, 49557, 29112, 29939, 43526, 63500, 55595, 27220, 25207, 38361, 18456, 792 };
        expdigs77 = new int[] { 26062, 32046, 3696, 45060, 46821, 40931, 50242, 60272, 24148, 20588, 6150, 44948, 60477, 7 };
        expdigs78 = new int[] { 12430, 30407, 320, 41980, 58777, 41755, 41041, 13609, 45167, 13348, 40838, 60354, 19454, 5192 };
        expdigs79 = new int[] { 30926, 26518, 13110, 43018, 54982, 48258, 24658, 15209, 63366, 11929, 20069, 43857, 60487, 51 };
        expdigs80 = new int[] { 51263, 54048, 48761, 48627, 30576, 49046, 4414, 61195, 61755, 48474, 19124, 55906, 15511, 34028 };
        expdigs81 = new int[] { 39834, 11681, 47018, 3107, 64531, 54229, 41331, 41899, 51735, 42427, 59173, 13010, 18505, 340 };
        expdigs82 = new int[] { 27268, 6670, 31272, 9861, 45865, 10372, 12865, 62678, 23454, 35158, 20252, 29621, 26399, 3 };
        expdigs83 = new int[] { 57738, 46147, 66, 48154, 11239, 21430, 55809, 46003, 15044, 25138, 52780, 48043, 4883, 2230 };
        expdigs84 = new int[] { 20893, 62065, 64225, 52254, 59094, 55919, 60195, 5702, 48647, 50058, 7736, 41768, 19709, 22 };
        expdigs85 = new int[] { 37714, 32321, 45840, 36031, 33290, 47121, 5146, 28127, 9887, 25390, 52929, 2698, 1073, 14615 };
        expdigs86 = new int[] { 35111, 8187, 18153, 56721, 40309, 59453, 51824, 4868, 45974, 3530, 43783, 8546, 9841, 146 };
        expdigs87 = new int[] { 23288, 61030, 42779, 19572, 29894, 47780, 45082, 32816, 43713, 33458, 25341, 63655, 30244, 1 };
        expdigs88 = new int[] { 58138, 33000, 62869, 37127, 61799, 298, 46353, 5693, 63898, 62040, 989, 23191, 53065, 957 };
        expdigs89 = new int[] { 42524, 32442, 36673, 15444, 22900, 658, 61412, 32824, 21610, 64190, 1975, 11373, 37886, 9 };
        expdigs90 = new int[] { 26492, 4357, 32437, 10852, 34233, 53968, 55056, 34692, 64553, 38226, 41929, 21646, 6667, 6277 };
        expdigs91 = new int[] { 61213, 698, 16053, 50571, 2963, 50347, 13657, 48188, 46520, 19387, 33187, 25775, 50529, 62 };
        expdigs92 = new int[] { 42864, 54351, 45226, 20476, 23443, 17724, 3780, 44701, 52910, 23402, 28374, 46862, 40234, 41137 };
        expdigs93 = new int[] { 23366, 62147, 58123, 44113, 55284, 39498, 3314, 9622, 9704, 27759, 25187, 43722, 24650, 411 };
        expdigs94 = new int[] { 38899, 44530, 19586, 37141, 1863, 9570, 32801, 31553, 51870, 62536, 51369, 30583, 7455, 4 };
        expdigs95 = new int[] { 10421, 4321, 43699, 3472, 65252, 17057, 13858, 29819, 14733, 21490, 40602, 31315, 65186, 2695 };
        expdigs96 = new int[] { 6002, 54438, 29272, 34113, 17036, 25074, 36183, 953, 25051, 12011, 20722, 4245, 62911, 26 };
        expdigs97 = new int[] { 14718, 45935, 8408, 42891, 21312, 56531, 44159, 45581, 20325, 36295, 35509, 24455, 30844, 17668 };
        expdigs98 = new int[] { 54542, 45023, 23021, 3050, 31015, 20881, 50904, 40432, 33626, 14125, 44264, 60537, 44872, 176 };
        expdigs99 = new int[] { 60183, 8969, 14648, 17725, 11451, 50016, 34587, 46279, 19341, 42084, 16826, 5848, 50256, 1 };
        expdigs100 = new int[] { 64999, 53685, 60382, 19151, 25736, 5357, 31302, 23283, 14225, 52622, 56781, 39489, 60351, 1157 };
        expdigs101 = new int[] { 1305, 4469, 39270, 18541, 63827, 59035, 54707, 16616, 32910, 48367, 64137, 2360, 37959, 11 };
        expdigs102 = new int[] { 45449, 32125, 19705, 56098, 51958, 5225, 18285, 13654, 9341, 25888, 50946, 26855, 36068, 7588 };
        expdigs103 = new int[] { 27324, 53405, 43450, 25464, 3796, 3329, 46058, 53220, 26307, 53998, 33932, 23861, 58032, 75 };
        expdigs104 = new int[] { 63080, 50735, 1844, 21406, 57926, 63607, 24936, 52889, 23469, 64488, 539, 8859, 21210, 49732 };
        expdigs105 = new int[] { 62890, 39828, 3950, 32982, 39245, 21607, 40226, 50991, 18584, 10475, 59643, 40720, 21183, 497 };
        expdigs106 = new int[] { 37329, 64623, 11835, 985, 46923, 48712, 28582, 21481, 28366, 41392, 13703, 49559, 63781, 4 };
        expdigs107 = new int[] { 3316, 60011, 41933, 47959, 54404, 39790, 12283, 941, 46090, 42226, 18108, 38803, 16879, 3259 };
        expdigs108 = new int[] { 46563, 56305, 5006, 45044, 49040, 12849, 778, 6563, 46336, 3043, 7390, 2354, 38835, 32 };
        expdigs109 = new int[] { 28653, 3742, 33331, 2671, 39772, 29981, 56489, 1973, 26280, 26022, 56391, 56434, 57039, 21359 };
        expdigs110 = new int[] { 9461, 17732, 7542, 26241, 8917, 24548, 61513, 13126, 59245, 41547, 1874, 41852, 39236, 213 };
        expdigs111 = new int[] { 36794, 22459, 63645, 14024, 42032, 53329, 25518, 11272, 18287, 20076, 62933, 3039, 8912, 2 };
        expdigs112 = new int[] { 14926, 15441, 32337, 42579, 26354, 35154, 22815, 36955, 12564, 8047, 856, 41917, 55080, 1399 };
        expdigs113 = new int[] { 8668, 50617, 10153, 17465, 1574, 28532, 15301, 58041, 38791, 60373, 663, 29255, 65431, 13 };
        expdigs114 = new int[] { 21589, 32199, 24754, 45321, 9349, 26230, 35019, 37508, 20896, 42986, 31405, 12458, 65173, 9173 };
        expdigs115 = new int[] { 46746, 1632, 61196, 50915, 64318, 41549, 2971, 23968, 59191, 58756, 61917, 779, 48493, 91 };
        expdigs116 = new int[] { 1609, 63382, 15744, 15685, 51627, 56348, 33838, 52458, 44148, 11077, 56293, 41906, 45227, 60122 };
        expdigs117 = new int[] { 19676, 45198, 6055, 38823, 8380, 49060, 17377, 58196, 43039, 21737, 59545, 12870, 14870, 601 };
        expdigs118 = new int[] { 4128, 2418, 28241, 13495, 26298, 3767, 31631, 5169, 8950, 27087, 56956, 4060, 804, 6 };
        expdigs119 = new int[] { 39930, 40673, 19029, 54677, 38145, 23200, 41325, 24564, 24955, 54484, 23863, 52998, 13147, 3940 };
        expdigs120 = new int[] { 3676, 24655, 34924, 27416, 23974, 887, 10899, 4833, 21221, 28725, 19899, 57546, 26345, 39 };
        expdigs121 = new int[] { 28904, 41324, 18596, 42292, 12070, 52013, 30810, 61057, 55753, 32324, 38953, 6752, 32688, 25822 };
        expdigs122 = new int[] { 42232, 26627, 2807, 27948, 50583, 49016, 32420, 64180, 3178, 3600, 21361, 52496, 14744, 258 };
        expdigs123 = new int[] { 2388, 59904, 28863, 7488, 31963, 8354, 47510, 15059, 2653, 58363, 31670, 21496, 38158, 2 };
        expdigs124 = new int[] { 50070, 5266, 26158, 10774, 15148, 6873, 30230, 33898, 63720, 51799, 4515, 50124, 19875, 1692 };
        expdigs125 = new int[] { 54240, 3984, 12058, 2729, 13914, 11865, 38313, 39660, 10467, 20834, 36745, 57517, 60491, 16 };
        expdigs126 = new int[] { 5387, 58214, 9214, 13883, 14445, 34873, 21745, 13490, 23334, 25008, 58535, 19372, 44484, 11090 };
        expdigs127 = new int[] { 27578, 64807, 12543, 794, 13907, 61297, 12013, 64360, 15961, 20566, 24178, 15922, 59427, 110 };
        expdigs128 = new int[] { 49427, 41935, 46000, 59645, 45358, 51075, 15848, 32756, 38170, 14623, 35631, 57175, 7147, 1 };
        expdigs129 = new int[] { 33941, 39160, 55469, 45679, 22878, 60091, 37210, 18508, 1638, 57398, 65026, 41643, 54966, 726 };
        expdigs130 = new int[] { 60632, 24639, 41842, 62060, 20544, 59583, 52800, 1495, 48513, 43827, 10480, 1727, 17589, 7 };
        expdigs131 = new int[] { 5590, 60244, 53985, 26632, 53049, 33628, 58267, 54922, 21641, 62744, 58109, 2070, 26887, 4763 };
        expdigs132 = new int[] { 62970, 37957, 34618, 29757, 24123, 2302, 17622, 58876, 44780, 6525, 33349, 36065, 41556, 47 };
        expdigs133 = new int[] { 1615, 24878, 20040, 11487, 23235, 27766, 59005, 57847, 60881, 11588, 63635, 61281, 31817, 31217 };
        expdigs134 = new int[] { 14434, 2870, 65081, 44023, 40864, 40254, 47120, 6476, 32066, 23053, 17020, 19618, 11459, 312 };
        expdigs135 = new int[] { 43398, 40005, 36695, 8304, 12205, 16131, 42414, 38075, 63890, 2851, 61774, 59833, 7978, 3 };
        expdigs136 = new int[] { 56426, 22060, 15473, 31824, 19088, 38788, 64386, 12875, 35770, 65519, 11824, 19623, 56959, 2045 };
        expdigs137 = new int[] { 16292, 32333, 10640, 47504, 29026, 30534, 23581, 6682, 10188, 24248, 44027, 51969, 30060, 20 };
        expdigs138 = new int[] { 29432, 37518, 55373, 2727, 33243, 22572, 16689, 35625, 34145, 15830, 59880, 32552, 52948, 13407 };
        expdigs139 = new int[] { 61898, 27244, 41841, 33450, 18682, 13988, 24415, 11497, 1652, 34237, 34677, 325, 5117, 134 };
        expdigs140 = new int[] { 16347, 3549, 48915, 22616, 21158, 51913, 32356, 21086, 3293, 8862, 1002, 26873, 22333, 1 };
        expdigs141 = new int[] { 25966, 63733, 28215, 31946, 40858, 58538, 11004, 6877, 6109, 3965, 35478, 37365, 45488, 878 };
        expdigs142 = new int[] { 45479, 34060, 17321, 19980, 1719, 16314, 29601, 8588, 58388, 22321, 14117, 63288, 51572, 8 };
        expdigs143 = new int[] { 46861, 47640, 11481, 23766, 46730, 53756, 8682, 60589, 42028, 27453, 29714, 31598, 39954, 5758 };
        expdigs144 = new int[] { 29304, 58803, 51232, 27762, 60760, 17576, 19092, 26820, 11561, 48771, 6850, 27841, 38410, 57 };
        expdigs145 = new int[] { 2916, 49445, 34666, 46387, 18627, 58279, 60468, 190, 3545, 51889, 51605, 47909, 40910, 37739 };
        expdigs146 = new int[] { 19034, 62098, 15419, 33887, 38852, 53011, 28129, 37357, 11176, 48360, 9035, 9654, 25968, 377 };
        expdigs147 = new int[] { 25094, 10451, 7363, 55389, 57404, 27399, 11422, 39695, 28947, 12935, 61694, 26310, 50722, 3 };
        expdigstable = new int[][] { NumberCommonAccessor.expdigs0, NumberCommonAccessor.expdigs1, NumberCommonAccessor.expdigs2, NumberCommonAccessor.expdigs3, NumberCommonAccessor.expdigs4, NumberCommonAccessor.expdigs5, NumberCommonAccessor.expdigs6, NumberCommonAccessor.expdigs7, NumberCommonAccessor.expdigs8, NumberCommonAccessor.expdigs9, NumberCommonAccessor.expdigs10, NumberCommonAccessor.expdigs11, NumberCommonAccessor.expdigs12, NumberCommonAccessor.expdigs13, NumberCommonAccessor.expdigs14, NumberCommonAccessor.expdigs15, NumberCommonAccessor.expdigs16, NumberCommonAccessor.expdigs17, NumberCommonAccessor.expdigs18, NumberCommonAccessor.expdigs19, NumberCommonAccessor.expdigs20, NumberCommonAccessor.expdigs21, NumberCommonAccessor.expdigs22, NumberCommonAccessor.expdigs23, NumberCommonAccessor.expdigs24, NumberCommonAccessor.expdigs25, NumberCommonAccessor.expdigs26, NumberCommonAccessor.expdigs27, NumberCommonAccessor.expdigs28, NumberCommonAccessor.expdigs29, NumberCommonAccessor.expdigs30, NumberCommonAccessor.expdigs31, NumberCommonAccessor.expdigs32, NumberCommonAccessor.expdigs33, NumberCommonAccessor.expdigs34, NumberCommonAccessor.expdigs35, NumberCommonAccessor.expdigs36, NumberCommonAccessor.expdigs37, NumberCommonAccessor.expdigs38, NumberCommonAccessor.expdigs39, NumberCommonAccessor.expdigs40, NumberCommonAccessor.expdigs41, NumberCommonAccessor.expdigs42, NumberCommonAccessor.expdigs43, NumberCommonAccessor.expdigs44, NumberCommonAccessor.expdigs45, NumberCommonAccessor.expdigs46, NumberCommonAccessor.expdigs47, NumberCommonAccessor.expdigs48, NumberCommonAccessor.expdigs49, NumberCommonAccessor.expdigs50, NumberCommonAccessor.expdigs51, NumberCommonAccessor.expdigs52, NumberCommonAccessor.expdigs53, NumberCommonAccessor.expdigs54, NumberCommonAccessor.expdigs55, NumberCommonAccessor.expdigs56, NumberCommonAccessor.expdigs57, NumberCommonAccessor.expdigs58, NumberCommonAccessor.expdigs59, NumberCommonAccessor.expdigs60, NumberCommonAccessor.expdigs61, NumberCommonAccessor.expdigs62, NumberCommonAccessor.expdigs63, NumberCommonAccessor.expdigs64, NumberCommonAccessor.expdigs65, NumberCommonAccessor.expdigs66, NumberCommonAccessor.expdigs67, NumberCommonAccessor.expdigs68, NumberCommonAccessor.expdigs69, NumberCommonAccessor.expdigs70, NumberCommonAccessor.expdigs71, NumberCommonAccessor.expdigs72, NumberCommonAccessor.expdigs73, NumberCommonAccessor.expdigs74, NumberCommonAccessor.expdigs75, NumberCommonAccessor.expdigs76, NumberCommonAccessor.expdigs77, NumberCommonAccessor.expdigs78, NumberCommonAccessor.expdigs79, NumberCommonAccessor.expdigs80, NumberCommonAccessor.expdigs81, NumberCommonAccessor.expdigs82, NumberCommonAccessor.expdigs83, NumberCommonAccessor.expdigs84, NumberCommonAccessor.expdigs85, NumberCommonAccessor.expdigs86, NumberCommonAccessor.expdigs87, NumberCommonAccessor.expdigs88, NumberCommonAccessor.expdigs89, NumberCommonAccessor.expdigs90, NumberCommonAccessor.expdigs91, NumberCommonAccessor.expdigs92, NumberCommonAccessor.expdigs93, NumberCommonAccessor.expdigs94, NumberCommonAccessor.expdigs95, NumberCommonAccessor.expdigs96, NumberCommonAccessor.expdigs97, NumberCommonAccessor.expdigs98, NumberCommonAccessor.expdigs99, NumberCommonAccessor.expdigs100, NumberCommonAccessor.expdigs101, NumberCommonAccessor.expdigs102, NumberCommonAccessor.expdigs103, NumberCommonAccessor.expdigs104, NumberCommonAccessor.expdigs105, NumberCommonAccessor.expdigs106, NumberCommonAccessor.expdigs107, NumberCommonAccessor.expdigs108, NumberCommonAccessor.expdigs109, NumberCommonAccessor.expdigs110, NumberCommonAccessor.expdigs111, NumberCommonAccessor.expdigs112, NumberCommonAccessor.expdigs113, NumberCommonAccessor.expdigs114, NumberCommonAccessor.expdigs115, NumberCommonAccessor.expdigs116, NumberCommonAccessor.expdigs117, NumberCommonAccessor.expdigs118, NumberCommonAccessor.expdigs119, NumberCommonAccessor.expdigs120, NumberCommonAccessor.expdigs121, NumberCommonAccessor.expdigs122, NumberCommonAccessor.expdigs123, NumberCommonAccessor.expdigs124, NumberCommonAccessor.expdigs125, NumberCommonAccessor.expdigs126, NumberCommonAccessor.expdigs127, NumberCommonAccessor.expdigs128, NumberCommonAccessor.expdigs129, NumberCommonAccessor.expdigs130, NumberCommonAccessor.expdigs131, NumberCommonAccessor.expdigs132, NumberCommonAccessor.expdigs133, NumberCommonAccessor.expdigs134, NumberCommonAccessor.expdigs135, NumberCommonAccessor.expdigs136, NumberCommonAccessor.expdigs137, NumberCommonAccessor.expdigs138, NumberCommonAccessor.expdigs139, NumberCommonAccessor.expdigs140, NumberCommonAccessor.expdigs141, NumberCommonAccessor.expdigs142, NumberCommonAccessor.expdigs143, NumberCommonAccessor.expdigs144, NumberCommonAccessor.expdigs145, NumberCommonAccessor.expdigs146, NumberCommonAccessor.expdigs147 };
        nexpdigstable = new int[] { 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 13, 12, 12, 11, 11, 10, 10, 10, 9, 9, 8, 8, 8, 7, 7, 6, 6, 5, 5, 5, 4, 4, 3, 3, 3, 2, 2, 1, 1, 1, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14 };
        binexpstable = new int[] { 90, 89, 89, 88, 88, 88, 87, 87, 86, 86, 86, 85, 85, 84, 84, 83, 83, 83, 82, 82, 81, 81, 81, 80, 80, 79, 79, 78, 78, 78, 77, 77, 76, 76, 76, 75, 75, 74, 74, 73, 73, 73, 72, 72, 71, 71, 71, 70, 70, 69, 69, 68, 68, 68, 67, 67, 66, 66, 66, 65, 65, 64, 64, 64, 63, 63, 62, 62, 61, 61, 61, 60, 60, 59, 59, 59, 58, 58, 57, 57, 56, 56, 56, 55, 55, 54, 54, 54, 53, 53, 52, 52, 51, 51, 51, 50, 50, 49, 49, 49, 48, 48, 47, 47, 46, 46, 46, 45, 45, 44, 44, 44, 43, 43, 42, 42, 41, 41, 41, 40, 40, 39, 39, 39, 38, 38, 37, 37, 37, 36, 36, 35, 35, 34, 34, 34, 33, 33, 32, 32, 32, 31, 31, 30, 30, 29, 29, 29 };
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
