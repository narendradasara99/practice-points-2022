// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.GregorianCalendar;
import oracle.jdbc.internal.OracleConnection;
import java.text.DateFormatSymbols;
import java.math.BigDecimal;
import oracle.sql.ROWID;
import java.sql.Time;
import oracle.sql.Datum;
import oracle.sql.RAW;
import oracle.sql.TIMESTAMPLTZ;
import java.util.Calendar;
import java.sql.Connection;
import oracle.sql.TIMESTAMPTZ;
import java.sql.Timestamp;
import oracle.sql.TIMESTAMP;
import java.sql.Date;
import oracle.sql.DATE;
import oracle.sql.NUMBER;
import java.io.IOException;
import java.sql.SQLException;

class T4CVarcharAccessor extends VarcharAccessor
{
    T4CMAREngine mare;
    static final int t4MaxLength = 4000;
    static final int t4CallMaxLength = 4001;
    static final int t4PlsqlMaxLength = 32766;
    static final int t4SqlMinLength = 32;
    boolean underlyingLong;
    final int[] meta;
    final int[] tmp;
    final int[] escapeSequenceArr;
    final boolean[] readHeaderArr;
    final boolean[] readAsNonStreamArr;
    static final int NONE = -1;
    static final int DAY = 1;
    static final int MM_MONTH = 2;
    static final int FULL_MONTH = 3;
    static final int MON_MONTH = 4;
    static final int YY_YEAR = 5;
    static final int RR_YEAR = 6;
    static final int HH_HOUR = 7;
    static final int HH24_HOUR = 8;
    static final int MINUTE = 9;
    static final int SECOND = 10;
    static final int NSECOND = 11;
    static final int AM = 12;
    static final int TZR = 13;
    static final int TZH = 14;
    static final int TZM = 15;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CVarcharAccessor(final OracleStatement oracleStatement, final int n, final short n2, final int n3, final boolean b, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, n2, n3, b);
        this.underlyingLong = false;
        this.meta = new int[1];
        this.tmp = new int[1];
        this.escapeSequenceArr = new int[1];
        this.readHeaderArr = new boolean[1];
        this.readAsNonStreamArr = new boolean[1];
        this.mare = mare;
        this.calculateSizeTmpByteArray();
    }
    
    T4CVarcharAccessor(final OracleStatement oracleStatement, final int n, final boolean b, final int n2, final int n3, final int n4, final int n5, final int n6, final short n7, final int oacmxl, final int definedColumnType, final int definedColumnSize, final T4CMAREngine mare) throws SQLException {
        super(oracleStatement, n, b, n2, n3, n4, n5, n6, n7);
        this.underlyingLong = false;
        this.meta = new int[1];
        this.tmp = new int[1];
        this.escapeSequenceArr = new int[1];
        this.readHeaderArr = new boolean[1];
        this.readAsNonStreamArr = new boolean[1];
        this.mare = mare;
        this.definedColumnType = definedColumnType;
        this.definedColumnSize = definedColumnSize;
        this.calculateSizeTmpByteArray();
        this.oacmxl = oacmxl;
        if (this.oacmxl == -1) {
            this.underlyingLong = true;
            this.oacmxl = 4000;
        }
    }
    
    void processIndicator(final int n) throws IOException, SQLException {
        if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
            this.mare.unmarshalUB2();
            this.mare.unmarshalUB2();
        }
        else if (this.statement.connection.versionNumber < 9200) {
            this.mare.unmarshalSB2();
            if (this.statement.sqlKind != 32 && this.statement.sqlKind != 64) {
                this.mare.unmarshalSB2();
            }
        }
        else if (this.statement.sqlKind == 32 || this.statement.sqlKind == 64 || this.isDMLReturnedParam) {
            this.mare.processIndicator(n <= 0, n);
        }
    }
    
    @Override
    boolean unmarshalOneRow() throws SQLException, IOException {
        if (this.isUseLess) {
            ++this.lastRowProcessed;
            return false;
        }
        final int n = this.indicatorIndex + this.lastRowProcessed;
        final int n2 = this.lengthIndex + this.lastRowProcessed;
        final byte[] tmpByteArray = this.statement.tmpByteArray;
        final int n3 = this.columnIndex + this.lastRowProcessed * this.charLength;
        if (!this.underlyingLong) {
            if (this.rowSpaceIndicator == null) {
                this.mare.unmarshalCLR(new byte[16000], 0, this.meta);
                this.processIndicator(this.meta[0]);
                ++this.lastRowProcessed;
                return false;
            }
            if (this.isNullByDescribe) {
                this.rowSpaceIndicator[n] = -1;
                this.rowSpaceIndicator[n2] = 0;
                ++this.lastRowProcessed;
                if (this.statement.connection.versionNumber < 9200) {
                    this.processIndicator(0);
                }
                return false;
            }
            if (this.statement.maxFieldSize > 0) {
                this.mare.unmarshalCLR(tmpByteArray, 0, this.meta, this.statement.maxFieldSize);
            }
            else {
                this.mare.unmarshalCLR(tmpByteArray, 0, this.meta);
            }
        }
        else {
            this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
            if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0])) {
                this.meta[0] = 0;
                this.mare.processIndicator(false, 0);
                this.mare.unmarshalUB2();
            }
            else {
                int i = 0;
                int n4 = 0;
                byte[] array = tmpByteArray;
                this.readHeaderArr[0] = true;
                this.readAsNonStreamArr[0] = false;
                while (i != -1) {
                    if (array == tmpByteArray && n4 + 255 > tmpByteArray.length) {
                        array = new byte[255];
                    }
                    int n5;
                    if (array == tmpByteArray) {
                        n5 = n4;
                    }
                    else {
                        n5 = 0;
                    }
                    i = T4CLongAccessor.readStreamFromWire(array, n5, 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
                    if (i != -1) {
                        if (array == tmpByteArray) {
                            n4 += i;
                        }
                        else {
                            if (tmpByteArray.length - n4 <= 0) {
                                continue;
                            }
                            final int n6 = tmpByteArray.length - n4;
                            System.arraycopy(array, 0, tmpByteArray, n4, n6);
                            n4 += n6;
                        }
                    }
                }
                if (array != tmpByteArray) {}
                this.meta[0] = n4;
            }
        }
        this.tmp[0] = this.meta[0];
        int n7;
        if (this.formOfUse == 2) {
            n7 = this.statement.connection.conversion.NCHARBytesToJavaChars(tmpByteArray, 0, this.rowSpaceChar, n3 + 1, this.tmp, this.charLength - 1);
        }
        else {
            n7 = this.statement.connection.conversion.CHARBytesToJavaChars(tmpByteArray, 0, this.rowSpaceChar, n3 + 1, this.tmp, this.charLength - 1);
        }
        this.rowSpaceChar[n3] = (char)(n7 * 2);
        if (!this.underlyingLong) {
            this.processIndicator(this.meta[0]);
        }
        if (this.meta[0] == 0) {
            this.rowSpaceIndicator[n] = -1;
            this.rowSpaceIndicator[n2] = 0;
        }
        else {
            this.rowSpaceIndicator[n2] = (short)(this.meta[0] * 2);
            this.rowSpaceIndicator[n] = 0;
        }
        ++this.lastRowProcessed;
        return false;
    }
    
    @Override
    void copyRow() throws SQLException, IOException {
        int n;
        if (this.lastRowProcessed == 0) {
            n = this.statement.rowPrefetchInLastFetch - 1;
        }
        else {
            n = this.lastRowProcessed - 1;
        }
        final int n2 = this.columnIndex + this.lastRowProcessed * this.charLength;
        final int n3 = this.columnIndex + n * this.charLength;
        final int n4 = this.indicatorIndex + this.lastRowProcessed;
        final int n5 = this.indicatorIndex + n;
        final int n6 = this.lengthIndex + this.lastRowProcessed;
        final short n7 = this.rowSpaceIndicator[this.lengthIndex + n];
        final int n8 = this.metaDataIndex + this.lastRowProcessed * 1;
        final int n9 = this.metaDataIndex + n * 1;
        this.rowSpaceIndicator[n6] = n7;
        this.rowSpaceIndicator[n4] = this.rowSpaceIndicator[n5];
        if (!this.isNullByDescribe) {
            System.arraycopy(this.rowSpaceChar, n3, this.rowSpaceChar, n2, this.rowSpaceChar[n3] / '\u0002' + 1);
        }
        System.arraycopy(this.rowSpaceMetaData, n9, this.rowSpaceMetaData, n8, 1);
        ++this.lastRowProcessed;
    }
    
    @Override
    void saveDataFromOldDefineBuffers(final byte[] array, final char[] array2, final short[] array3, final int n, final int n2) throws SQLException {
        final int n3 = this.columnIndex + (n2 - 1) * this.charLength;
        final int n4 = this.columnIndexLastRow + (n - 1) * this.charLength;
        final int n5 = this.indicatorIndex + n2 - 1;
        final int n6 = this.indicatorIndexLastRow + n - 1;
        final int n7 = this.lengthIndex + n2 - 1;
        final short n8 = array3[this.lengthIndexLastRow + n - 1];
        this.rowSpaceIndicator[n7] = n8;
        this.rowSpaceIndicator[n5] = array3[n6];
        if (n8 != 0) {
            System.arraycopy(array2, n4, this.rowSpaceChar, n3, array2[n4] / '\u0002' + 1);
        }
        else {
            this.rowSpaceChar[n3] = '\0';
        }
    }
    
    @Override
    void calculateSizeTmpByteArray() {
        int sizeTmpByteArray;
        if (this.formOfUse == 2) {
            sizeTmpByteArray = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
        }
        else {
            sizeTmpByteArray = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
        }
        if (this.statement.sizeTmpByteArray < sizeTmpByteArray) {
            this.statement.sizeTmpByteArray = sizeTmpByteArray;
        }
    }
    
    @Override
    String getString(final int n) throws SQLException {
        String s = super.getString(n);
        if (s != null && this.definedColumnSize > 0 && s.length() > this.definedColumnSize) {
            s = s.substring(0, this.definedColumnSize);
        }
        return s;
    }
    
    @Override
    NUMBER getNUMBER(final int n) throws SQLException {
        NUMBER number = null;
        if (this.definedColumnType == 0) {
            number = super.getNUMBER(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                return StringToNUMBER(string);
            }
        }
        return number;
    }
    
    @Override
    DATE getDATE(final int n) throws SQLException {
        DATE date = null;
        if (this.definedColumnType == 0) {
            date = super.getDATE(n);
        }
        else {
            final Date date2 = this.getDate(n);
            if (date2 != null) {
                date = new DATE(date2);
            }
        }
        return date;
    }
    
    @Override
    TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        TIMESTAMP timestamp = null;
        if (this.definedColumnType == 0) {
            timestamp = super.getTIMESTAMP(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                final Timestamp timestamp2 = new Timestamp(DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), array).getTimeInMillis());
                timestamp2.setNanos(array[0]);
                timestamp = new TIMESTAMP(timestamp2);
            }
        }
        return timestamp;
    }
    
    @Override
    TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        TIMESTAMPTZ timestamptz = null;
        if (this.definedColumnType == 0) {
            timestamptz = super.getTIMESTAMPTZ(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                final Calendar dateStringToCalendar = DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), array);
                final Timestamp timestamp = new Timestamp(dateStringToCalendar.getTimeInMillis());
                timestamp.setNanos(array[0]);
                timestamptz = new TIMESTAMPTZ(this.statement.connection, timestamp, dateStringToCalendar);
            }
        }
        return timestamptz;
    }
    
    @Override
    TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        TIMESTAMPLTZ timestampltz = null;
        if (this.definedColumnType == 0) {
            timestampltz = super.getTIMESTAMPLTZ(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                final Calendar dateStringToCalendar = DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), array);
                final Timestamp timestamp = new Timestamp(dateStringToCalendar.getTimeInMillis());
                timestamp.setNanos(array[0]);
                timestampltz = new TIMESTAMPLTZ(this.statement.connection, timestamp, dateStringToCalendar);
            }
        }
        return timestampltz;
    }
    
    @Override
    RAW getRAW(final int n) throws SQLException {
        RAW raw = null;
        if (this.definedColumnType == 0) {
            raw = super.getRAW(n);
        }
        else {
            if (this.rowSpaceIndicator == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.rowSpaceIndicator[this.indicatorIndex + n] != -1) {
                if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) {
                    raw = new RAW(this.getBytesFromHexChars(n));
                }
                else {
                    raw = new RAW(super.getBytes(n));
                }
            }
        }
        return raw;
    }
    
    @Override
    Datum getOracleObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getOracleObject(n);
        }
        final Datum datum = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return datum;
        }
        switch (this.definedColumnType) {
            case -16:
            case -15:
            case -9:
            case -1:
            case 1:
            case 12: {
                return super.getOracleObject(n);
            }
            case -7:
            case -6:
            case -5:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 16: {
                return this.getNUMBER(n);
            }
            case 91: {
                return this.getDATE(n);
            }
            case 92: {
                return this.getDATE(n);
            }
            case 93: {
                return this.getTIMESTAMP(n);
            }
            case -101: {
                return this.getTIMESTAMPTZ(n);
            }
            case -102: {
                return this.getTIMESTAMPLTZ(n);
            }
            case -4:
            case -3:
            case -2: {
                return this.getRAW(n);
            }
            case -8: {
                return this.getROWID(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    @Override
    byte[] getBytes(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getBytes(n);
        }
        final Datum oracleObject = this.getOracleObject(n);
        if (oracleObject != null) {
            return oracleObject.shareBytes();
        }
        return null;
    }
    
    @Override
    boolean getBoolean(final int n) throws SQLException {
        boolean b;
        if (this.definedColumnType == 0) {
            b = super.getBoolean(n);
        }
        else {
            b = this.getNUMBER(n).booleanValue();
        }
        return b;
    }
    
    @Override
    byte getByte(final int n) throws SQLException {
        byte b;
        if (this.definedColumnType == 0) {
            b = super.getByte(n);
        }
        else {
            b = this.getNUMBER(n).byteValue();
        }
        return b;
    }
    
    @Override
    int getInt(final int n) throws SQLException {
        int n2;
        if (this.definedColumnType == 0) {
            n2 = super.getInt(n);
        }
        else {
            n2 = this.getNUMBER(n).intValue();
        }
        return n2;
    }
    
    @Override
    short getShort(final int n) throws SQLException {
        short n2;
        if (this.definedColumnType == 0) {
            n2 = super.getShort(n);
        }
        else {
            n2 = this.getNUMBER(n).shortValue();
        }
        return n2;
    }
    
    @Override
    long getLong(final int n) throws SQLException {
        long n2;
        if (this.definedColumnType == 0) {
            n2 = super.getLong(n);
        }
        else {
            n2 = this.getNUMBER(n).longValue();
        }
        return n2;
    }
    
    @Override
    float getFloat(final int n) throws SQLException {
        float n2;
        if (this.definedColumnType == 0) {
            n2 = super.getFloat(n);
        }
        else {
            n2 = this.getNUMBER(n).floatValue();
        }
        return n2;
    }
    
    @Override
    double getDouble(final int n) throws SQLException {
        double n2;
        if (this.definedColumnType == 0) {
            n2 = super.getDouble(n);
        }
        else {
            n2 = this.getNUMBER(n).doubleValue();
        }
        return n2;
    }
    
    @Override
    Date getDate(final int n) throws SQLException {
        Date date = null;
        if (this.definedColumnType == 0) {
            date = super.getDate(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                date = new Date(DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), new int[1]).getTimeInMillis());
            }
        }
        return date;
    }
    
    @Override
    Timestamp getTimestamp(final int n) throws SQLException {
        Timestamp timestamp = null;
        if (this.definedColumnType == 0) {
            timestamp = super.getTimestamp(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                final int[] array = { 0 };
                timestamp = new Timestamp(DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), array).getTimeInMillis());
                timestamp.setNanos(array[0]);
            }
        }
        return timestamp;
    }
    
    @Override
    Time getTime(final int n) throws SQLException {
        Time time = null;
        if (this.definedColumnType == 0) {
            time = super.getTime(n);
        }
        else {
            final String string = this.getString(n);
            if (string != null) {
                time = new Time(DATEStringToCalendar(string, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), new int[1]).getTimeInMillis());
            }
        }
        return time;
    }
    
    @Override
    Object getObject(final int n) throws SQLException {
        if (this.definedColumnType == 0) {
            return super.getObject(n);
        }
        final Object o = null;
        if (this.rowSpaceIndicator == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 21);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowSpaceIndicator[this.indicatorIndex + n] == -1) {
            return o;
        }
        switch (this.definedColumnType) {
            case -16:
            case -15:
            case -9:
            case -1:
            case 1:
            case 12: {
                return this.getString(n);
            }
            case 2:
            case 3: {
                return this.getBigDecimal(n);
            }
            case 4: {
                return this.getInt(n);
            }
            case -6: {
                return this.getByte(n);
            }
            case 5: {
                return this.getShort(n);
            }
            case -7:
            case 16: {
                return this.getBoolean(n);
            }
            case -5: {
                return this.getLong(n);
            }
            case 7: {
                return this.getFloat(n);
            }
            case 6:
            case 8: {
                return this.getDouble(n);
            }
            case 91: {
                return this.getDate(n);
            }
            case 92: {
                return this.getTime(n);
            }
            case 93: {
                return this.getTimestamp(n);
            }
            case -101: {
                return this.getTIMESTAMPTZ(n);
            }
            case -102: {
                return this.getTIMESTAMPLTZ(n);
            }
            case -4:
            case -3:
            case -2: {
                return this.getBytesFromHexChars(n);
            }
            case -8: {
                return this.getROWID(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    @Override
    ROWID getROWID(final int n) throws SQLException {
        final byte[] bytesInternal = this.getBytesInternal(n);
        ROWID rowid = null;
        if (bytesInternal != null) {
            rowid = new ROWID(bytesInternal);
        }
        return rowid;
    }
    
    static final NUMBER StringToNUMBER(final String val) throws SQLException {
        return new NUMBER(new BigDecimal(val));
    }
    
    static final Calendar DATEStringToCalendar(String string, final String str, final int[] array) throws SQLException {
        final char[] charArray = (str + " ").toCharArray();
        string += " ";
        final int min = Math.min(string.length(), charArray.length);
        int n = -1;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int int1 = 0;
        int int2 = 0;
        int year = 0;
        int int3 = 0;
        int int4 = 0;
        int int5 = 0;
        int int6 = 0;
        String substring = null;
        String substring2 = null;
        int n5 = 0;
        String[] shortMonths = null;
        String[] months = null;
        for (int i = 0; i < min; ++i) {
            switch (charArray[i]) {
                case 'R':
                case 'r': {
                    if (n != 6) {
                        n = 6;
                        n2 = i;
                        break;
                    }
                    break;
                }
                case 'Y':
                case 'y': {
                    if (n != 5) {
                        n = 5;
                        n2 = i;
                        break;
                    }
                    break;
                }
                case 'D':
                case 'd': {
                    if (n != 1) {
                        n = 1;
                        n2 = i;
                        break;
                    }
                    break;
                }
                case 'M':
                case 'm': {
                    if (n == 2 && n == 4 && n == 3 && n == 9) {
                        break;
                    }
                    n2 = i;
                    if (i + 4 < min && (charArray[i + 1] == 'O' || charArray[i + 1] == 'o') && (charArray[i + 2] == 'N' || charArray[i + 2] == 'n') && (charArray[i + 3] == 'T' || charArray[i + 3] == 't') && (charArray[i + 4] == 'H' || charArray[i + 4] == 'h')) {
                        n = 3;
                        i += 4;
                        break;
                    }
                    if (i + 2 < min && (charArray[i + 1] == 'O' || charArray[i + 1] == 'o') && (charArray[i + 2] == 'N' || charArray[i + 2] == 'n')) {
                        n = 4;
                        i += 2;
                        break;
                    }
                    if (i + 1 < min && (charArray[i + 1] == 'M' || charArray[i + 1] == 'm')) {
                        n = 2;
                        ++i;
                        break;
                    }
                    if (i + 1 < min && (charArray[i + 1] == 'I' || charArray[i + 1] == 'i')) {
                        n = 9;
                        ++i;
                        break;
                    }
                    break;
                }
                case 'H':
                case 'h': {
                    if (n != 7) {
                        n = 7;
                        n2 = i;
                        break;
                    }
                    if (i + 2 < min && (charArray[i + 1] == '2' || charArray[i + 4] == '4')) {
                        n = 8;
                        i += 2;
                        break;
                    }
                    break;
                }
                case 'S':
                case 's': {
                    if (i + 1 < min && (charArray[i + 1] == 'S' || charArray[i + 1] == 's')) {
                        n = 10;
                        n2 = i;
                        ++i;
                        break;
                    }
                    break;
                }
                case 'F':
                case 'f': {
                    if (n != 11) {
                        n = 11;
                        n2 = i;
                        break;
                    }
                    break;
                }
                case 'A':
                case 'a': {
                    if (i + 1 < min && (charArray[i + 1] == 'M' || charArray[i + 1] == 'm')) {
                        n = 12;
                        n2 = i;
                        ++i;
                        break;
                    }
                    break;
                }
                case 'T':
                case 't': {
                    if (i + 2 < min && (charArray[i + 1] == 'Z' || charArray[i + 1] == 'z') && (charArray[i + 2] == 'R' || charArray[i + 2] == 'r')) {
                        n = 13;
                        n2 = i;
                        i += 2;
                        break;
                    }
                    break;
                }
                default: {
                    n5 = 1;
                    break;
                }
            }
            if (n5 != 0 && n != -1) {
                final int n6 = i - n2;
                final int n7 = n4 + (n2 - n3);
                n4 = n7 + n6;
                switch (n) {
                    case 1: {
                        int1 = Integer.parseInt(string.substring(n7, n4));
                        break;
                    }
                    case 2: {
                        int2 = Integer.parseInt(string.substring(n7, n4));
                        break;
                    }
                    case 3: {
                        int index;
                        for (index = n7; index < string.length() && string.charAt(index) != charArray[i]; ++index) {}
                        n4 = index;
                        if (n4 == n7) {
                            break;
                        }
                        final String trim = string.substring(n7, n4).trim();
                        if (months == null) {
                            months = new DateFormatSymbols().getMonths();
                        }
                        for (int2 = 0; int2 < months.length && !trim.equalsIgnoreCase(months[int2]); ++int2) {}
                        if (int2 >= 12) {
                            final SQLException sqlException = DatabaseError.createSqlException(null, 59);
                            sqlException.fillInStackTrace();
                            throw sqlException;
                        }
                        break;
                    }
                    case 4: {
                        int index2;
                        for (index2 = n7; index2 < string.length() && string.charAt(index2) != charArray[i]; ++index2) {}
                        n4 = index2;
                        if (n4 == n7) {
                            break;
                        }
                        final String trim2 = string.substring(n7, n4).trim();
                        if (shortMonths == null) {
                            shortMonths = new DateFormatSymbols().getShortMonths();
                        }
                        for (int2 = 0; int2 < shortMonths.length && !trim2.equalsIgnoreCase(shortMonths[int2]); ++int2) {}
                        if (int2 >= 12) {
                            final SQLException sqlException2 = DatabaseError.createSqlException(null, 59);
                            sqlException2.fillInStackTrace();
                            throw sqlException2;
                        }
                        break;
                    }
                    case 5: {
                        year = Integer.parseInt(string.substring(n7, n4));
                        if (n6 == 2) {
                            year += 2000;
                            break;
                        }
                        break;
                    }
                    case 6: {
                        year = Integer.parseInt(string.substring(n7, n4));
                        if (n6 == 2 && year < 50) {
                            year += 2000;
                            break;
                        }
                        year += 1900;
                        break;
                    }
                    case 7:
                    case 8: {
                        n4 = n7 + 2;
                        int3 = Integer.parseInt(string.substring(n7, n4));
                        break;
                    }
                    case 9: {
                        int4 = Integer.parseInt(string.substring(n7, n4));
                        break;
                    }
                    case 10: {
                        int5 = Integer.parseInt(string.substring(n7, n4));
                        break;
                    }
                    case 11: {
                        final int n8 = n7;
                        int index3;
                        char char1;
                        for (index3 = n7; index3 < string.length() && (char1 = string.charAt(index3)) >= '0' && char1 <= '9'; ++index3) {}
                        n4 = n8 + (index3 - n7);
                        if (n4 != n7) {
                            int6 = Integer.parseInt(string.substring(n7, n4));
                            break;
                        }
                        break;
                    }
                    case 12: {
                        if (n4 > 0) {
                            substring = string.substring(n7, n4);
                            break;
                        }
                        break;
                    }
                    case 13: {
                        n4 = n7;
                        for (int j = n7; j < string.length(); ++j) {
                            final char char2;
                            if (((char2 = string.charAt(j)) < '0' || char2 > '9') && (char2 < 'a' || char2 > 'z')) {
                                if (char2 < 'A') {
                                    break;
                                }
                                if (char2 > 'Z') {
                                    break;
                                }
                            }
                            n4 = j;
                        }
                        if (n4 != n7) {
                            substring2 = string.substring(n7, n4);
                            break;
                        }
                        break;
                    }
                    default: {
                        System.out.println("\n\n\n             ***** ERROR(1) ****\n");
                        break;
                    }
                }
                n3 = i;
                n = -1;
                n5 = 0;
            }
        }
        final GregorianCalendar gregorianCalendar = new GregorianCalendar(year, int2, int1, int3, int4, int5);
        if (substring != null) {
            gregorianCalendar.set(9, substring.equalsIgnoreCase("AM") ? 0 : 1);
        }
        if (substring2 != null) {}
        if (int6 != 0) {
            array[0] = int6;
        }
        return gregorianCalendar;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
