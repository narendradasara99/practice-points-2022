// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.io.Writer;
import java.io.OutputStream;
import java.io.IOException;
import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.NClob;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.BFILE;
import oracle.sql.CLOB;
import oracle.sql.NCLOB;
import oracle.sql.BLOB;
import oracle.sql.REF;
import oracle.sql.OPAQUE;
import oracle.sql.ARRAY;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.NUMBER;
import oracle.sql.ROWID;
import java.sql.ResultSet;
import java.net.MalformedURLException;
import java.net.URL;
import oracle.sql.TIMESTAMP;
import oracle.sql.DATE;
import java.util.Calendar;
import java.sql.Array;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Ref;
import oracle.sql.STRUCT;
import java.util.Map;
import java.io.Reader;
import oracle.sql.CHAR;
import java.io.ByteArrayInputStream;
import oracle.sql.RAW;
import java.io.InputStream;
import java.sql.Timestamp;
import java.sql.Time;
import java.sql.Date;
import java.math.BigDecimal;
import java.sql.Connection;
import oracle.sql.Datum;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSetMetaData;

class UpdatableResultSet extends BaseResultSet
{
    static final int concurrencyType = 1008;
    static final int BEGIN_COLUMN_INDEX = 1;
    static final int MAX_CHAR_BUFFER_SIZE = 1024;
    static final int MAX_BYTE_BUFFER_SIZE = 1024;
    PhysicalConnection connection;
    OracleResultSet resultSet;
    boolean isCachedRset;
    ScrollRsetStatement scrollStmt;
    ResultSetMetaData rsetMetaData;
    private int rsetType;
    private int columnCount;
    private OraclePreparedStatement deleteStmt;
    private OraclePreparedStatement insertStmt;
    private OraclePreparedStatement updateStmt;
    private int[] indexColsChanged;
    private Object[] rowBuffer;
    private boolean[] m_nullIndicator;
    private int[][] typeInfo;
    private boolean isInserting;
    private boolean isUpdating;
    private int wasNull;
    private static final int VALUE_NULL = 1;
    private static final int VALUE_NOT_NULL = 2;
    private static final int VALUE_UNKNOWN = 3;
    private static final int VALUE_IN_RSET = 4;
    private static final int ASCII_STREAM = 1;
    private static final int BINARY_STREAM = 2;
    private static final int UNICODE_STREAM = 3;
    private static int _MIN_STREAM_SIZE;
    ArrayList tempClobsToFree;
    ArrayList tempBlobsToFree;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    UpdatableResultSet(final ScrollRsetStatement scrollRsetStatement, final ScrollableResultSet set, final int n, final int n2) throws SQLException {
        this.tempClobsToFree = null;
        this.tempBlobsToFree = null;
        this.init(scrollRsetStatement, set, n, n2);
        set.resetBeginColumnIndex();
        this.getInternalMetadata();
        this.isCachedRset = true;
    }
    
    UpdatableResultSet(final ScrollRsetStatement scrollRsetStatement, final OracleResultSetImpl oracleResultSetImpl, final int n, final int n2) throws SQLException {
        this.tempClobsToFree = null;
        this.tempBlobsToFree = null;
        this.init(scrollRsetStatement, oracleResultSetImpl, n, n2);
        this.getInternalMetadata();
        this.isCachedRset = false;
    }
    
    private void init(final ScrollRsetStatement scrollStmt, final OracleResultSet resultSet, final int rsetType, final int n) throws SQLException {
        if (scrollStmt == null || resultSet == null || n != 1008) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.connection = ((OracleStatement)scrollStmt).connection;
        this.resultSet = resultSet;
        this.scrollStmt = scrollStmt;
        this.rsetType = rsetType;
        this.deleteStmt = null;
        this.insertStmt = null;
        this.updateStmt = null;
        this.indexColsChanged = null;
        this.rowBuffer = null;
        this.m_nullIndicator = null;
        this.typeInfo = null;
        this.isInserting = false;
        this.isUpdating = false;
        this.wasNull = -1;
        this.rsetMetaData = null;
        this.columnCount = 0;
    }
    
    void ensureOpen() throws SQLException {
        if (this.closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 10);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.resultSet == null || this.scrollStmt == null || ((OracleStatement)this.scrollStmt).closed) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public void close() throws SQLException {
        if (this.closed) {
            return;
        }
        synchronized (this.connection) {
            super.close();
            if (this.resultSet != null) {
                this.resultSet.close();
            }
            if (this.insertStmt != null) {
                this.insertStmt.close();
            }
            if (this.updateStmt != null) {
                this.updateStmt.close();
            }
            if (this.deleteStmt != null) {
                this.deleteStmt.close();
            }
            if (this.scrollStmt != null) {
                this.scrollStmt.notifyCloseRset();
            }
            this.cancelRowInserts();
            this.connection = LogicalConnection.closedConnection;
            this.resultSet = null;
            this.scrollStmt = null;
            this.rsetMetaData = null;
            this.scrollStmt = null;
            this.deleteStmt = null;
            this.insertStmt = null;
            this.updateStmt = null;
            this.indexColsChanged = null;
            this.rowBuffer = null;
            this.m_nullIndicator = null;
            this.typeInfo = null;
        }
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            switch (this.wasNull) {
                case 1: {
                    return true;
                }
                case 2: {
                    return false;
                }
                case 4: {
                    return this.resultSet.wasNull();
                }
                default: {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 24);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
        }
    }
    
    @Override
    int getFirstUserColumnIndex() {
        return 1;
    }
    
    @Override
    public Statement getStatement() throws SQLException {
        synchronized (this.connection) {
            return (Statement)this.scrollStmt;
        }
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        final SQLWarning warnings = this.resultSet.getWarnings();
        if (this.sqlWarning == null) {
            return warnings;
        }
        SQLWarning sqlWarning;
        for (sqlWarning = this.sqlWarning; sqlWarning.getNextWarning() != null; sqlWarning = sqlWarning.getNextWarning()) {}
        sqlWarning.setNextWarning(warnings);
        return this.sqlWarning;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        this.sqlWarning = null;
        this.resultSet.clearWarnings();
    }
    
    @Override
    public boolean next() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            return this.resultSet.next();
        }
    }
    
    @Override
    public boolean isBeforeFirst() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.isBeforeFirst();
        }
    }
    
    @Override
    public boolean isAfterLast() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.isAfterLast();
        }
    }
    
    @Override
    public boolean isFirst() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.isFirst();
        }
    }
    
    @Override
    public boolean isLast() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.isLast();
        }
    }
    
    @Override
    public void beforeFirst() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            this.resultSet.beforeFirst();
        }
    }
    
    @Override
    public void afterLast() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            this.resultSet.afterLast();
        }
    }
    
    @Override
    public boolean first() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            return this.resultSet.first();
        }
    }
    
    @Override
    public boolean last() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            return this.resultSet.last();
        }
    }
    
    @Override
    public int getRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.getRow();
        }
    }
    
    @Override
    public boolean absolute(final int n) throws SQLException {
        synchronized (this.connection) {
            this.cancelRowChanges();
            return this.resultSet.absolute(n);
        }
    }
    
    @Override
    public boolean relative(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            return this.resultSet.relative(n);
        }
    }
    
    @Override
    public boolean previous() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowChanges();
            return this.resultSet.previous();
        }
    }
    
    @Override
    public Datum getOracleObject(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            final Object o = null;
            this.setIsNull(3);
            Datum datum;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                this.setIsNull(o == null);
                datum = this.getRowBufferDatumAt(n);
            }
            else {
                this.setIsNull(4);
                datum = this.resultSet.getOracleObject(n + 1);
            }
            return datum;
        }
    }
    
    @Override
    public String getString(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            String s = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    s = rowBufferDatum.stringValue(this.connection);
                }
            }
            else {
                this.setIsNull(4);
                s = this.resultSet.getString(n + 1);
            }
            return s;
        }
    }
    
    @Override
    public boolean getBoolean(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            boolean b = false;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    b = rowBufferDatum.booleanValue();
                }
            }
            else {
                this.setIsNull(4);
                b = this.resultSet.getBoolean(n + 1);
            }
            return b;
        }
    }
    
    @Override
    public AuthorizationIndicator getAuthorizationIndicator(final int n) throws SQLException {
        return this.resultSet.getAuthorizationIndicator(n + 1);
    }
    
    @Override
    public byte getByte(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            byte b = 0;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    b = rowBufferDatum.byteValue();
                }
            }
            else {
                this.setIsNull(4);
                b = this.resultSet.getByte(n + 1);
            }
            return b;
        }
    }
    
    @Override
    public short getShort(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            short short1;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final long long1 = this.getLong(n);
                if (long1 > 65537L || long1 < -65538L) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 26, "getShort");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                short1 = (short)long1;
            }
            else {
                this.setIsNull(4);
                short1 = this.resultSet.getShort(n + 1);
            }
            return short1;
        }
    }
    
    @Override
    public int getInt(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            int n2 = 0;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    n2 = rowBufferDatum.intValue();
                }
            }
            else {
                this.setIsNull(4);
                n2 = this.resultSet.getInt(n + 1);
            }
            return n2;
        }
    }
    
    @Override
    public long getLong(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            long n2 = 0L;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    n2 = rowBufferDatum.longValue();
                }
            }
            else {
                this.setIsNull(4);
                n2 = this.resultSet.getLong(n + 1);
            }
            return n2;
        }
    }
    
    @Override
    public float getFloat(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            float n2 = 0.0f;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    n2 = rowBufferDatum.floatValue();
                }
            }
            else {
                this.setIsNull(4);
                n2 = this.resultSet.getFloat(n + 1);
            }
            return n2;
        }
    }
    
    @Override
    public double getDouble(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            double n2 = 0.0;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    n2 = rowBufferDatum.doubleValue();
                }
            }
            else {
                this.setIsNull(4);
                n2 = this.resultSet.getDouble(n + 1);
            }
            return n2;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n, final int n2) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            BigDecimal bigDecimal = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    bigDecimal = rowBufferDatum.bigDecimalValue();
                }
            }
            else {
                this.setIsNull(4);
                bigDecimal = this.resultSet.getBigDecimal(n + 1);
            }
            return bigDecimal;
        }
    }
    
    @Override
    public byte[] getBytes(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            byte[] array = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    array = rowBufferDatum.getBytes();
                }
            }
            else {
                this.setIsNull(4);
                array = this.resultSet.getBytes(n + 1);
            }
            return array;
        }
    }
    
    @Override
    public Date getDate(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Date date = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    date = rowBufferDatum.dateValue();
                }
            }
            else {
                this.setIsNull(4);
                date = this.resultSet.getDate(n + 1);
            }
            return date;
        }
    }
    
    @Override
    public Time getTime(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Time time = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    time = rowBufferDatum.timeValue();
                }
            }
            else {
                this.setIsNull(4);
                time = this.resultSet.getTime(n + 1);
            }
            return time;
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Timestamp timestamp = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    timestamp = rowBufferDatum.timestampValue();
                }
            }
            else {
                this.setIsNull(4);
                timestamp = this.resultSet.getTimestamp(n + 1);
            }
            return timestamp;
        }
    }
    
    @Override
    public InputStream getAsciiStream(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            InputStream inputStream = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Object rowBuffer = this.getRowBufferAt(n);
                this.setIsNull(rowBuffer == null);
                if (rowBuffer != null) {
                    if (rowBuffer instanceof InputStream) {
                        inputStream = (InputStream)rowBuffer;
                    }
                    else {
                        inputStream = this.getRowBufferDatumAt(n).asciiStreamValue();
                    }
                }
            }
            else {
                this.setIsNull(4);
                inputStream = this.resultSet.getAsciiStream(n + 1);
            }
            return inputStream;
        }
    }
    
    @Override
    public InputStream getUnicodeStream(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            InputStream inputStream = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Object rowBuffer = this.getRowBufferAt(n);
                this.setIsNull(rowBuffer == null);
                if (rowBuffer != null) {
                    if (rowBuffer instanceof InputStream) {
                        inputStream = (InputStream)rowBuffer;
                    }
                    else {
                        final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                        final DBConversion conversion = this.connection.conversion;
                        final byte[] shareBytes = rowBufferDatum.shareBytes();
                        if (rowBufferDatum instanceof RAW) {
                            final DBConversion dbConversion = conversion;
                            final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(shareBytes);
                            final PhysicalConnection connection = this.connection;
                            inputStream = dbConversion.ConvertStream(byteArrayInputStream, 3);
                        }
                        else {
                            if (!(rowBufferDatum instanceof CHAR)) {
                                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
                                sqlException.fillInStackTrace();
                                throw sqlException;
                            }
                            final DBConversion dbConversion2 = conversion;
                            final ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(shareBytes);
                            final PhysicalConnection connection2 = this.connection;
                            inputStream = dbConversion2.ConvertStream(byteArrayInputStream2, 1);
                        }
                    }
                }
            }
            else {
                this.setIsNull(4);
                inputStream = this.resultSet.getUnicodeStream(n + 1);
            }
            return inputStream;
        }
    }
    
    @Override
    public InputStream getBinaryStream(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            InputStream inputStream = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Object rowBuffer = this.getRowBufferAt(n);
                this.setIsNull(rowBuffer == null);
                if (rowBuffer != null) {
                    if (rowBuffer instanceof InputStream) {
                        inputStream = (InputStream)rowBuffer;
                    }
                    else {
                        inputStream = this.getRowBufferDatumAt(n).binaryStreamValue();
                    }
                }
            }
            else {
                this.setIsNull(4);
                inputStream = this.resultSet.getBinaryStream(n + 1);
            }
            return inputStream;
        }
    }
    
    @Override
    public Object getObject(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Object o = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum oracleObject = this.getOracleObject(n);
                this.setIsNull(oracleObject == null);
                if (oracleObject != null) {
                    o = oracleObject.toJdbc();
                }
            }
            else {
                this.setIsNull(4);
                o = this.resultSet.getObject(n + 1);
            }
            return o;
        }
    }
    
    @Override
    public Reader getCharacterStream(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Reader reader = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Object rowBuffer = this.getRowBufferAt(n);
                this.setIsNull(rowBuffer == null);
                if (rowBuffer != null) {
                    if (rowBuffer instanceof Reader) {
                        reader = (Reader)rowBuffer;
                    }
                    else {
                        reader = this.getRowBufferDatumAt(n).characterStreamValue();
                    }
                }
            }
            else {
                this.setIsNull(4);
                reader = this.resultSet.getCharacterStream(n + 1);
            }
            return reader;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            BigDecimal bigDecimal = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null) {
                    bigDecimal = rowBufferDatum.bigDecimalValue();
                }
            }
            else {
                this.setIsNull(4);
                bigDecimal = this.resultSet.getBigDecimal(n + 1);
            }
            return bigDecimal;
        }
    }
    
    @Override
    public Object getObject(final int n, final Map map) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Object o = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum oracleObject = this.getOracleObject(n);
                this.setIsNull(oracleObject == null);
                if (oracleObject != null) {
                    if (oracleObject instanceof STRUCT) {
                        o = ((STRUCT)oracleObject).toJdbc(map);
                    }
                    else {
                        o = oracleObject.toJdbc();
                    }
                }
            }
            else {
                this.setIsNull(4);
                o = this.resultSet.getObject(n + 1, map);
            }
            return o;
        }
    }
    
    @Override
    public Ref getRef(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.getREF(n);
        }
    }
    
    @Override
    public Blob getBlob(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.getBLOB(n);
        }
    }
    
    @Override
    public Clob getClob(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.getCLOB(n);
        }
    }
    
    @Override
    public Array getArray(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.getARRAY(n);
        }
    }
    
    @Override
    public Date getDate(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Date date = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum oracleObject = this.getOracleObject(n);
                this.setIsNull(oracleObject == null);
                if (oracleObject != null) {
                    if (oracleObject instanceof DATE) {
                        date = ((DATE)oracleObject).dateValue(calendar);
                    }
                    else if (oracleObject instanceof TIMESTAMP) {
                        date = new Date(((TIMESTAMP)oracleObject).timestampValue(calendar).getTime());
                    }
                    else {
                        final DATE date2 = new DATE(oracleObject.stringValue(this.connection));
                        if (date2 != null) {
                            date = date2.dateValue(calendar);
                        }
                    }
                }
            }
            else {
                this.setIsNull(4);
                date = this.resultSet.getDate(n + 1, calendar);
            }
            return date;
        }
    }
    
    @Override
    public Time getTime(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Time time = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum oracleObject = this.getOracleObject(n);
                this.setIsNull(oracleObject == null);
                if (oracleObject != null) {
                    if (oracleObject instanceof DATE) {
                        time = ((DATE)oracleObject).timeValue(calendar);
                    }
                    else if (oracleObject instanceof TIMESTAMP) {
                        time = new Time(((TIMESTAMP)oracleObject).timestampValue(calendar).getTime());
                    }
                    else {
                        final DATE date = new DATE(oracleObject.stringValue(this.connection));
                        if (date != null) {
                            time = date.timeValue(calendar);
                        }
                    }
                }
            }
            else {
                this.setIsNull(4);
                time = this.resultSet.getTime(n + 1, calendar);
            }
            return time;
        }
    }
    
    @Override
    public Timestamp getTimestamp(final int n, final Calendar calendar) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Timestamp timestamp = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum oracleObject = this.getOracleObject(n);
                this.setIsNull(oracleObject == null);
                if (oracleObject != null) {
                    if (oracleObject instanceof DATE) {
                        timestamp = ((DATE)oracleObject).timestampValue(calendar);
                    }
                    else if (oracleObject instanceof TIMESTAMP) {
                        timestamp = ((TIMESTAMP)oracleObject).timestampValue(calendar);
                    }
                    else {
                        final DATE date = new DATE(oracleObject.stringValue(this.connection));
                        if (date != null) {
                            timestamp = date.timestampValue(calendar);
                        }
                    }
                }
            }
            else {
                this.setIsNull(4);
                timestamp = this.resultSet.getTimestamp(n + 1, calendar);
            }
            return timestamp;
        }
    }
    
    @Override
    public URL getURL(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            final int internalType = SQLUtil.getInternalType(this.getInternalMetadata().getColumnType(n + 1));
            Label_0107: {
                if (internalType != 96 && internalType != 1) {
                    if (internalType != 8) {
                        break Label_0107;
                    }
                }
                try {
                    final String string = this.getString(n);
                    URL url;
                    if (string == null) {
                        url = null;
                    }
                    else {
                        url = new URL(string);
                    }
                    return url;
                }
                catch (MalformedURLException ex) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 136);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
            final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
            unsupportedFeatureSqlException.fillInStackTrace();
            throw unsupportedFeatureSqlException;
        }
    }
    
    @Override
    public ResultSet getCursor(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                this.setIsNull(this.getOracleObject(n) == null);
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCursor");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.setIsNull(4);
            return this.resultSet.getCursor(n + 1);
        }
    }
    
    @Override
    public ROWID getROWID(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            ROWID rowid;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof ROWID)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getROWID");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                rowid = (ROWID)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                rowid = this.resultSet.getROWID(n + 1);
            }
            return rowid;
        }
    }
    
    @Override
    public NUMBER getNUMBER(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            NUMBER number;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof NUMBER)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getNUMBER");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                number = (NUMBER)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                number = this.resultSet.getNUMBER(n + 1);
            }
            return number;
        }
    }
    
    @Override
    public DATE getDATE(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            DATE date = null;
            this.setIsNull(3);
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                if (rowBufferDatum != null) {
                    if (rowBufferDatum instanceof DATE) {
                        date = (DATE)rowBufferDatum;
                    }
                    else {
                        if (!(rowBufferDatum instanceof TIMESTAMP)) {
                            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getDATE");
                            sqlException.fillInStackTrace();
                            throw sqlException;
                        }
                        date = new DATE(((TIMESTAMP)rowBufferDatum).timestampValue());
                    }
                }
                else {
                    this.setIsNull(rowBufferDatum == null);
                }
            }
            else {
                this.setIsNull(4);
                date = this.resultSet.getDATE(n + 1);
            }
            return date;
        }
    }
    
    @Override
    public TIMESTAMP getTIMESTAMP(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            TIMESTAMP timestamp;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof TIMESTAMP)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                timestamp = (TIMESTAMP)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                timestamp = this.resultSet.getTIMESTAMP(n + 1);
            }
            return timestamp;
        }
    }
    
    @Override
    public TIMESTAMPTZ getTIMESTAMPTZ(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            TIMESTAMPTZ timestamptz;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof TIMESTAMPTZ)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                timestamptz = (TIMESTAMPTZ)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                timestamptz = this.resultSet.getTIMESTAMPTZ(n + 1);
            }
            return timestamptz;
        }
    }
    
    @Override
    public TIMESTAMPLTZ getTIMESTAMPLTZ(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            TIMESTAMPLTZ timestampltz;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof TIMESTAMPLTZ)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                timestampltz = (TIMESTAMPLTZ)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                timestampltz = this.resultSet.getTIMESTAMPLTZ(n + 1);
            }
            return timestampltz;
        }
    }
    
    @Override
    public INTERVALDS getINTERVALDS(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            INTERVALDS intervalds;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof INTERVALDS)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                intervalds = (INTERVALDS)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                intervalds = this.resultSet.getINTERVALDS(n + 1);
            }
            return intervalds;
        }
    }
    
    @Override
    public INTERVALYM getINTERVALYM(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            INTERVALYM intervalym;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof INTERVALYM)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                intervalym = (INTERVALYM)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                intervalym = this.resultSet.getINTERVALYM(n + 1);
            }
            return intervalym;
        }
    }
    
    @Override
    public ARRAY getARRAY(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            ARRAY array;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof ARRAY)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getARRAY");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                array = (ARRAY)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                array = this.resultSet.getARRAY(n + 1);
            }
            return array;
        }
    }
    
    @Override
    public STRUCT getSTRUCT(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            STRUCT struct;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof STRUCT)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                struct = (STRUCT)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                struct = this.resultSet.getSTRUCT(n + 1);
            }
            return struct;
        }
    }
    
    @Override
    public OPAQUE getOPAQUE(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            OPAQUE opaque;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof OPAQUE)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                opaque = (OPAQUE)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                opaque = this.resultSet.getOPAQUE(n + 1);
            }
            return opaque;
        }
    }
    
    @Override
    public REF getREF(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            REF ref;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof REF)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getREF");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                ref = (REF)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                ref = this.resultSet.getREF(n + 1);
            }
            return ref;
        }
    }
    
    @Override
    public CHAR getCHAR(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            CHAR char1;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof CHAR)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCHAR");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                char1 = (CHAR)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                char1 = this.resultSet.getCHAR(n + 1);
            }
            return char1;
        }
    }
    
    @Override
    public RAW getRAW(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            RAW raw;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof RAW)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getRAW");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                raw = (RAW)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                raw = this.resultSet.getRAW(n + 1);
            }
            return raw;
        }
    }
    
    @Override
    public BLOB getBLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            BLOB blob;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof BLOB)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBLOB");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                blob = (BLOB)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                blob = this.resultSet.getBLOB(n + 1);
            }
            return blob;
        }
    }
    
    public NCLOB getNCLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            NCLOB nclob;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof NCLOB)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCLOB");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                nclob = (NCLOB)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                nclob = (NCLOB)this.resultSet.getNClob(n + 1);
            }
            return nclob;
        }
    }
    
    @Override
    public CLOB getCLOB(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            CLOB clob;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof CLOB)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getCLOB");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                clob = (CLOB)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                clob = this.resultSet.getCLOB(n + 1);
            }
            return clob;
        }
    }
    
    @Override
    public BFILE getBFILE(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            BFILE bfile;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof BFILE)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getBFILE");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                bfile = (BFILE)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                bfile = this.resultSet.getBFILE(n + 1);
            }
            return bfile;
        }
    }
    
    @Override
    public BFILE getBfile(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.getBFILE(n);
        }
    }
    
    @Override
    public CustomDatum getCustomDatum(final int n, final CustomDatumFactory customDatumFactory) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (customDatumFactory == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.setIsNull(3);
            CustomDatum customDatum;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                customDatum = customDatumFactory.create(rowBufferDatum, 0);
            }
            else {
                this.setIsNull(4);
                customDatum = this.resultSet.getCustomDatum(n + 1, customDatumFactory);
            }
            return customDatum;
        }
    }
    
    @Override
    public ORAData getORAData(final int n, final ORADataFactory oraDataFactory) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (oraDataFactory == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.setIsNull(3);
            ORAData oraData;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                oraData = oraDataFactory.create(rowBufferDatum, 0);
            }
            else {
                this.setIsNull(4);
                oraData = this.resultSet.getORAData(n + 1, oraDataFactory);
            }
            return oraData;
        }
    }
    
    @Override
    public NClob getNClob(final int n) throws SQLException {
        this.ensureOpen();
        final NCLOB nclob = this.getNCLOB(n);
        if (nclob == null) {
            return null;
        }
        if (!(nclob instanceof NClob)) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 184);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return nclob;
    }
    
    @Override
    public String getNString(final int n) throws SQLException {
        this.ensureOpen();
        return this.getString(n);
    }
    
    @Override
    public Reader getNCharacterStream(final int n) throws SQLException {
        this.ensureOpen();
        return this.getCharacterStream(n);
    }
    
    @Override
    public RowId getRowId(final int n) throws SQLException {
        this.ensureOpen();
        return this.getROWID(n);
    }
    
    @Override
    public SQLXML getSQLXML(final int n) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.setIsNull(3);
            SQLXML sqlxml;
            if (this.isOnInsertRow() || (this.isUpdatingRow() && this.isRowBufferUpdatedAt(n))) {
                final Datum rowBufferDatum = this.getRowBufferDatumAt(n);
                this.setIsNull(rowBufferDatum == null);
                if (rowBufferDatum != null && !(rowBufferDatum instanceof SQLXML)) {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 4, "getSQLXML");
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
                sqlxml = (SQLXML)rowBufferDatum;
            }
            else {
                this.setIsNull(4);
                sqlxml = this.resultSet.getSQLXML(n + 1);
            }
            return sqlxml;
        }
    }
    
    @Override
    public void updateRowId(final int n, final RowId rowId) throws SQLException {
        this.updateROWID(n, (ROWID)rowId);
    }
    
    @Override
    public void updateNCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        this.updateCharacterStream(n, reader, n2);
    }
    
    @Override
    public void updateNCharacterStream(final int n, final Reader reader) throws SQLException {
        this.updateCharacterStream(n, reader);
    }
    
    @Override
    public void updateSQLXML(final int n, final SQLXML sqlxml) throws SQLException {
        this.updateOracleObject(n, (Datum)sqlxml);
    }
    
    @Override
    public void updateNString(final int n, final String s) throws SQLException {
        this.updateString(n, s);
    }
    
    @Override
    public void updateNClob(final int n, final NClob nClob) throws SQLException {
        this.updateClob(n, nClob);
    }
    
    @Override
    public void updateAsciiStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.updateAsciiStream(n, inputStream, (int)n2);
    }
    
    @Override
    public void updateAsciiStream(final int n, final InputStream inputStream) throws SQLException {
        this.updateAsciiStream(n, inputStream, Integer.MAX_VALUE);
    }
    
    @Override
    public void updateBinaryStream(final int n, final InputStream inputStream, final long n2) throws SQLException {
        this.updateBinaryStream(n, inputStream, (int)n2);
    }
    
    @Override
    public void updateBinaryStream(final int n, final InputStream inputStream) throws SQLException {
        this.updateBinaryStream(n, inputStream, Integer.MAX_VALUE);
    }
    
    @Override
    public void updateCharacterStream(final int n, final Reader reader, final long n2) throws SQLException {
        this.updateCharacterStream(n, reader, (int)n2);
    }
    
    @Override
    public void updateCharacterStream(final int n, final Reader reader) throws SQLException {
        this.updateCharacterStream(n, reader, Integer.MAX_VALUE);
    }
    
    @Override
    public void updateBlob(final int n, final InputStream inputStream) throws SQLException {
        final Blob blob = this.connection.createBlob();
        this.addToTempLobsToFree(blob);
        final int bufferSize = ((BLOB)blob).getBufferSize();
        final OutputStream setBinaryStream = blob.setBinaryStream(1L);
        final byte[] array = new byte[bufferSize];
        try {
            while (true) {
                final int read = inputStream.read(array);
                if (read == -1) {
                    break;
                }
                setBinaryStream.write(array, 0, read);
            }
            setBinaryStream.close();
            this.updateBlob(n, blob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void updateBlob(final int n, final InputStream inputStream, final long n2) throws SQLException {
        final Blob blob = this.connection.createBlob();
        this.addToTempLobsToFree(blob);
        final int bufferSize = ((BLOB)blob).getBufferSize();
        final OutputStream setBinaryStream = blob.setBinaryStream(1L);
        final byte[] array = new byte[bufferSize];
        long n3 = n2;
        try {
            while (n3 > 0L) {
                final int read = inputStream.read(array, 0, Math.min(bufferSize, (int)n3));
                if (read == -1) {
                    break;
                }
                setBinaryStream.write(array, 0, read);
                n3 -= read;
            }
            setBinaryStream.close();
            this.updateBlob(n, blob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void updateClob(final int n, final Reader reader, final long n2) throws SQLException {
        final Clob clob = this.connection.createClob();
        this.addToTempLobsToFree(clob);
        final int bufferSize = ((CLOB)clob).getBufferSize();
        final Writer setCharacterStream = clob.setCharacterStream(1L);
        final char[] array = new char[bufferSize];
        long n3 = n2;
        try {
            while (n3 > 0L) {
                final int read = reader.read(array, 0, Math.min(bufferSize, (int)n3));
                if (read == -1) {
                    break;
                }
                setCharacterStream.write(array, 0, read);
                n3 -= read;
            }
            setCharacterStream.close();
            this.updateClob(n, clob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void updateClob(final int n, final Reader reader) throws SQLException {
        final Clob clob = this.connection.createClob();
        this.addToTempLobsToFree(clob);
        final int bufferSize = ((CLOB)clob).getBufferSize();
        final Writer setCharacterStream = clob.setCharacterStream(1L);
        final char[] cbuf = new char[bufferSize];
        try {
            while (true) {
                final int read = reader.read(cbuf);
                if (read == -1) {
                    break;
                }
                setCharacterStream.write(cbuf, 0, read);
            }
            setCharacterStream.close();
            this.updateClob(n, clob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void updateClob(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final Clob clob = this.connection.createClob();
        this.addToTempLobsToFree(clob);
        final int bufferSize = ((CLOB)clob).getBufferSize();
        final OutputStream setAsciiStream = clob.setAsciiStream(1L);
        final byte[] array = new byte[bufferSize];
        long n3 = n2;
        try {
            while (n3 > 0L) {
                final int read = inputStream.read(array, 0, Math.min(bufferSize, (int)n3));
                if (read == -1) {
                    break;
                }
                setAsciiStream.write(array, 0, read);
                n3 -= read;
            }
            setAsciiStream.close();
            this.updateClob(n, clob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void updateNClob(final int n, final InputStream inputStream, final int n2) throws SQLException {
        final NClob nClob = this.connection.createNClob();
        this.addToTempLobsToFree(nClob);
        final int bufferSize = ((NCLOB)nClob).getBufferSize();
        final OutputStream setAsciiStream = nClob.setAsciiStream(1L);
        final byte[] array = new byte[bufferSize];
        long n3 = n2;
        try {
            while (n3 > 0L) {
                final int read = inputStream.read(array, 0, Math.min(bufferSize, (int)n3));
                if (read == -1) {
                    break;
                }
                setAsciiStream.write(array, 0, read);
                n3 -= read;
            }
            setAsciiStream.close();
            this.updateNClob(n, nClob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void updateNClob(final int n, final Reader reader, final long n2) throws SQLException {
        final NClob nClob = this.connection.createNClob();
        this.addToTempLobsToFree(nClob);
        final int bufferSize = ((CLOB)nClob).getBufferSize();
        final Writer setCharacterStream = nClob.setCharacterStream(1L);
        final char[] array = new char[bufferSize];
        long n3 = n2;
        try {
            while (n3 > 0L) {
                final int read = reader.read(array, 0, Math.min(bufferSize, (int)n3));
                if (read == -1) {
                    break;
                }
                setCharacterStream.write(array, 0, read);
                n3 -= read;
            }
            setCharacterStream.close();
            this.updateNClob(n, nClob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void updateNClob(final int n, final Reader reader) throws SQLException {
        final NClob nClob = this.connection.createNClob();
        this.addToTempLobsToFree(nClob);
        final int bufferSize = ((CLOB)nClob).getBufferSize();
        final Writer setCharacterStream = nClob.setCharacterStream(1L);
        final char[] cbuf = new char[bufferSize];
        try {
            while (true) {
                final int read = reader.read(cbuf);
                if (read == -1) {
                    break;
                }
                setCharacterStream.write(cbuf, 0, read);
            }
            setCharacterStream.close();
            this.updateNClob(n, nClob);
        }
        catch (IOException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    void addToTempLobsToFree(final Clob e) {
        if (this.tempClobsToFree == null) {
            this.tempClobsToFree = new ArrayList();
        }
        this.tempClobsToFree.add(e);
    }
    
    void addToTempLobsToFree(final Blob e) {
        if (this.tempBlobsToFree == null) {
            this.tempBlobsToFree = new ArrayList();
        }
        this.tempBlobsToFree.add(e);
    }
    
    void cleanTempLobs() {
        this.cleanTempClobs(this.tempClobsToFree);
        this.cleanTempBlobs(this.tempBlobsToFree);
        this.tempClobsToFree = null;
        this.tempBlobsToFree = null;
    }
    
    void cleanTempBlobs(final ArrayList list) {
        if (list != null) {
            final Iterator<BLOB> iterator = list.iterator();
            while (iterator.hasNext()) {
                try {
                    iterator.next().freeTemporary();
                }
                catch (SQLException ex) {}
            }
        }
    }
    
    void cleanTempClobs(final ArrayList list) {
        if (list != null) {
            final Iterator<CLOB> iterator = list.iterator();
            while (iterator.hasNext()) {
                try {
                    iterator.next().freeTemporary();
                }
                catch (SQLException ex) {}
            }
        }
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        if (((OracleStatement)this.scrollStmt).closed) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 9, "getMetaData");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        synchronized (this.connection) {
            return new OracleResultSetMetaData(this.connection, (OracleStatement)this.scrollStmt, 1);
        }
    }
    
    @Override
    public int findColumn(final String s) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.findColumn(s) - 1;
        }
    }
    
    @Override
    public void setFetchDirection(final int fetchDirection) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.resultSet.setFetchDirection(fetchDirection);
        }
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.getFetchDirection();
        }
    }
    
    @Override
    public void setFetchSize(final int fetchSize) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.resultSet.setFetchSize(fetchSize);
        }
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            return this.resultSet.getFetchSize();
        }
    }
    
    @Override
    public int getType() throws SQLException {
        return this.rsetType;
    }
    
    @Override
    public int getConcurrency() throws SQLException {
        return 1008;
    }
    
    @Override
    public boolean rowUpdated() throws SQLException {
        return false;
    }
    
    @Override
    public boolean rowInserted() throws SQLException {
        return false;
    }
    
    @Override
    public boolean rowDeleted() throws SQLException {
        return false;
    }
    
    @Override
    public void insertRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (!this.isOnInsertRow()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 83);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.prepareInsertRowStatement();
            this.prepareInsertRowBinds();
            this.executeInsertRow();
        }
    }
    
    @Override
    public void updateRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.isOnInsertRow()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 84);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int numColumnsChanged = this.getNumColumnsChanged();
            if (numColumnsChanged > 0) {
                this.prepareUpdateRowStatement(numColumnsChanged);
                this.prepareUpdateRowBinds(numColumnsChanged);
                this.executeUpdateRow();
            }
        }
    }
    
    @Override
    public void deleteRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.isOnInsertRow()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 84);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.prepareDeleteRowStatement();
            this.prepareDeleteRowBinds();
            this.executeDeleteRow();
        }
    }
    
    @Override
    public void refreshRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.isOnInsertRow()) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 84);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.resultSet.refreshRow();
        }
    }
    
    @Override
    public void cancelRowUpdates() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.isUpdating) {
                this.isUpdating = false;
                this.clearRowBuffer();
            }
        }
    }
    
    @Override
    public void moveToInsertRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            if (this.isOnInsertRow()) {
                return;
            }
            this.isInserting = true;
            if (this.rowBuffer == null) {
                this.rowBuffer = new Object[this.getColumnCount()];
            }
            if (this.m_nullIndicator == null) {
                this.m_nullIndicator = new boolean[this.getColumnCount()];
            }
            this.clearRowBuffer();
        }
    }
    
    @Override
    public void moveToCurrentRow() throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            this.cancelRowInserts();
        }
    }
    
    @Override
    public void updateString(final int n, final String s) throws SQLException {
        synchronized (this.connection) {
            if (s == null || s.length() == 0) {
                this.updateNull(n);
            }
            else {
                this.updateObject(n, s);
            }
        }
    }
    
    @Override
    public void updateNull(final int n) throws SQLException {
        synchronized (this.connection) {
            this.setRowBufferAt(n, null);
        }
    }
    
    @Override
    public void updateBoolean(final int n, final boolean b) throws SQLException {
        this.updateObject(n, b);
    }
    
    @Override
    public void updateByte(final int n, final byte i) throws SQLException {
        this.updateObject(n, (int)i);
    }
    
    @Override
    public void updateShort(final int n, final short i) throws SQLException {
        this.updateObject(n, (int)i);
    }
    
    @Override
    public void updateInt(final int n, final int i) throws SQLException {
        this.updateObject(n, i);
    }
    
    @Override
    public void updateLong(final int n, final long l) throws SQLException {
        this.updateObject(n, l);
    }
    
    @Override
    public void updateFloat(final int n, final float f) throws SQLException {
        this.updateObject(n, f);
    }
    
    @Override
    public void updateDouble(final int n, final double d) throws SQLException {
        this.updateObject(n, d);
    }
    
    @Override
    public void updateBigDecimal(final int n, final BigDecimal bigDecimal) throws SQLException {
        this.updateObject(n, bigDecimal);
    }
    
    @Override
    public void updateBytes(final int n, final byte[] array) throws SQLException {
        this.updateObject(n, array);
    }
    
    @Override
    public void updateDate(final int n, final Date date) throws SQLException {
        this.updateObject(n, date);
    }
    
    @Override
    public void updateTime(final int n, final Time time) throws SQLException {
        this.updateObject(n, time);
    }
    
    @Override
    public void updateTimestamp(final int n, final Timestamp timestamp) throws SQLException {
        this.updateObject(n, timestamp);
    }
    
    @Override
    public void updateAsciiStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.ensureOpen();
        final int columnType = this.getInternalMetadata().getColumnType(1 + n);
        if (inputStream != null && n2 > 0) {
            switch (columnType) {
                case 2005: {
                    this.updateClob(n, inputStream, n2);
                    break;
                }
                case 2004: {
                    this.updateBlob(n, inputStream, n2);
                    break;
                }
                case -1: {
                    this.setRowBufferAt(n, inputStream, new int[] { n2, 1 });
                    break;
                }
                default: {
                    try {
                        int i = n2;
                        final byte[] array = new byte[1024];
                        final char[] str = new char[1024];
                        final StringBuilder sb = new StringBuilder(1024);
                        while (i > 0) {
                            int len;
                            if (i >= 1024) {
                                len = inputStream.read(array);
                            }
                            else {
                                len = inputStream.read(array, 0, i);
                            }
                            if (len == -1) {
                                break;
                            }
                            final DBConversion conversion = this.connection.conversion;
                            DBConversion.asciiBytesToJavaChars(array, len, str);
                            sb.append(str, 0, len);
                            i -= len;
                        }
                        inputStream.close();
                        if (i == n2) {
                            this.updateNull(n);
                            return;
                        }
                        this.updateString(n, sb.toString());
                    }
                    catch (IOException ex) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    break;
                }
            }
        }
        else {
            this.setRowBufferAt(n, null);
        }
    }
    
    @Override
    public void updateBinaryStream(final int n, final InputStream inputStream, final int n2) throws SQLException {
        this.ensureOpen();
        final int columnType = this.getInternalMetadata().getColumnType(1 + n);
        if (inputStream != null && n2 > 0) {
            switch (columnType) {
                case 2004: {
                    this.updateBlob(n, inputStream, n2);
                    break;
                }
                case -4: {
                    this.setRowBufferAt(n, inputStream, new int[] { n2, 2 });
                    break;
                }
                default: {
                    try {
                        int i = n2;
                        final byte[] b = new byte[1024];
                        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
                        while (i > 0) {
                            int len;
                            if (i >= 1024) {
                                len = inputStream.read(b);
                            }
                            else {
                                len = inputStream.read(b, 0, i);
                            }
                            if (len == -1) {
                                break;
                            }
                            byteArrayOutputStream.write(b, 0, len);
                            i -= len;
                        }
                        inputStream.close();
                        if (i == n2) {
                            this.updateNull(n);
                            return;
                        }
                        this.updateBytes(n, byteArrayOutputStream.toByteArray());
                    }
                    catch (IOException ex) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    break;
                }
            }
        }
        else {
            this.setRowBufferAt(n, null);
        }
    }
    
    @Override
    public void updateCharacterStream(final int n, final Reader reader, final int n2) throws SQLException {
        int i = n2;
        this.ensureOpen();
        final int columnType = this.getInternalMetadata().getColumnType(1 + n);
        if (reader != null && n2 > 0) {
            switch (columnType) {
                case 2005: {
                    this.updateClob(n, reader, n2);
                    break;
                }
                case 2011: {
                    this.updateNClob(n, reader, n2);
                    break;
                }
                case -1: {
                    this.setRowBufferAt(n, reader, new int[] { n2 });
                    break;
                }
                default: {
                    try {
                        final char[] array = new char[1024];
                        final StringBuilder sb = new StringBuilder(1024);
                        while (i > 0) {
                            int len;
                            if (i >= 1024) {
                                len = reader.read(array);
                            }
                            else {
                                len = reader.read(array, 0, i);
                            }
                            if (len == -1) {
                                break;
                            }
                            sb.append(array, 0, len);
                            i -= len;
                        }
                        reader.close();
                        if (i == n2) {
                            this.updateNull(n);
                            return;
                        }
                        this.updateString(n, sb.toString());
                    }
                    catch (IOException ex) {
                        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex);
                        sqlException.fillInStackTrace();
                        throw sqlException;
                    }
                    break;
                }
            }
        }
        else {
            this.setRowBufferAt(n, null);
        }
    }
    
    @Override
    public void updateObject(final int n, final Object o, final int n2) throws SQLException {
        this.updateObject(n, o);
    }
    
    @Override
    public void updateObject(final int n, final Object o) throws SQLException {
        synchronized (this.connection) {
            this.ensureOpen();
            Datum oracleDatum = null;
            if (o != null) {
                if (o instanceof Datum) {
                    oracleDatum = (Datum)o;
                }
                else {
                    final OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)this.getInternalMetadata();
                    final int n2 = n + 1;
                    if (oracleResultSetMetaData.getColumnType(n2) == 96) {
                        final int columnDisplaySize = oracleResultSetMetaData.getColumnDisplaySize(n2);
                        String string = (String)o;
                        for (int i = string.length(); i < columnDisplaySize; ++i) {
                            string += " ";
                        }
                    }
                    oracleDatum = SQLUtil.makeOracleDatum(this.connection, o, oracleResultSetMetaData.getColumnType(n2), null, oracleResultSetMetaData.isNCHAR(n2));
                }
            }
            this.setRowBufferAt(n, oracleDatum);
        }
    }
    
    @Override
    public void updateOracleObject(final int n, final Datum datum) throws SQLException {
        synchronized (this.connection) {
            this.setRowBufferAt(n, datum);
        }
    }
    
    @Override
    public void updateROWID(final int n, final ROWID rowid) throws SQLException {
        this.updateOracleObject(n, rowid);
    }
    
    @Override
    public void updateNUMBER(final int n, final NUMBER number) throws SQLException {
        this.updateOracleObject(n, number);
    }
    
    @Override
    public void updateDATE(final int n, final DATE date) throws SQLException {
        this.updateOracleObject(n, date);
    }
    
    @Override
    public void updateINTERVALYM(final int n, final INTERVALYM intervalym) throws SQLException {
        this.updateOracleObject(n, intervalym);
    }
    
    @Override
    public void updateINTERVALDS(final int n, final INTERVALDS intervalds) throws SQLException {
        this.updateOracleObject(n, intervalds);
    }
    
    @Override
    public void updateTIMESTAMP(final int n, final TIMESTAMP timestamp) throws SQLException {
        this.updateOracleObject(n, timestamp);
    }
    
    @Override
    public void updateTIMESTAMPTZ(final int n, final TIMESTAMPTZ timestamptz) throws SQLException {
        this.updateOracleObject(n, timestamptz);
    }
    
    @Override
    public void updateTIMESTAMPLTZ(final int n, final TIMESTAMPLTZ timestampltz) throws SQLException {
        this.updateOracleObject(n, timestampltz);
    }
    
    @Override
    public void updateARRAY(final int n, final ARRAY array) throws SQLException {
        this.updateOracleObject(n, array);
    }
    
    @Override
    public void updateSTRUCT(final int n, final STRUCT struct) throws SQLException {
        this.updateOracleObject(n, struct);
    }
    
    @Override
    public void updateOPAQUE(final int n, final OPAQUE opaque) throws SQLException {
        this.updateOracleObject(n, opaque);
    }
    
    @Override
    public void updateREF(final int n, final REF ref) throws SQLException {
        this.updateOracleObject(n, ref);
    }
    
    @Override
    public void updateCHAR(final int n, final CHAR char1) throws SQLException {
        this.updateOracleObject(n, char1);
    }
    
    @Override
    public void updateRAW(final int n, final RAW raw) throws SQLException {
        this.updateOracleObject(n, raw);
    }
    
    @Override
    public void updateBLOB(final int n, final BLOB blob) throws SQLException {
        this.updateOracleObject(n, blob);
    }
    
    @Override
    public void updateCLOB(final int n, final CLOB clob) throws SQLException {
        this.updateOracleObject(n, clob);
    }
    
    @Override
    public void updateBFILE(final int n, final BFILE bfile) throws SQLException {
        this.updateOracleObject(n, bfile);
    }
    
    @Override
    public void updateBfile(final int n, final BFILE bfile) throws SQLException {
        this.updateOracleObject(n, bfile);
    }
    
    @Override
    public void updateCustomDatum(final int n, final CustomDatum customDatum) throws SQLException {
        throw new Error("wanna do datum = ((CustomDatum) x).toDatum(m_comm)");
    }
    
    @Override
    public void updateORAData(final int n, final ORAData oraData) throws SQLException {
        this.updateOracleObject(n, oraData.toDatum(this.connection));
    }
    
    @Override
    public void updateRef(final int n, final Ref ref) throws SQLException {
        this.updateREF(n, (REF)ref);
    }
    
    @Override
    public void updateBlob(final int n, final Blob blob) throws SQLException {
        this.updateBLOB(n, (BLOB)blob);
    }
    
    @Override
    public void updateClob(final int n, final Clob clob) throws SQLException {
        this.updateCLOB(n, (CLOB)clob);
    }
    
    @Override
    public void updateArray(final int n, final Array array) throws SQLException {
        this.updateARRAY(n, (ARRAY)array);
    }
    
    int getColumnCount() throws SQLException {
        if (this.columnCount == 0) {
            if (this.resultSet instanceof OracleResultSetImpl) {
                if (((OracleResultSetImpl)this.resultSet).statement.accessors != null) {
                    this.columnCount = ((OracleResultSetImpl)this.resultSet).statement.numberOfDefinePositions;
                }
                else {
                    this.columnCount = this.getInternalMetadata().getColumnCount();
                }
            }
            else {
                this.columnCount = ((ScrollableResultSet)this.resultSet).getColumnCount();
            }
        }
        return this.columnCount;
    }
    
    ResultSetMetaData getInternalMetadata() throws SQLException {
        if (this.rsetMetaData == null) {
            this.rsetMetaData = this.resultSet.getMetaData();
        }
        return this.rsetMetaData;
    }
    
    private void cancelRowChanges() throws SQLException {
        synchronized (this.connection) {
            if (this.isInserting) {
                this.cancelRowInserts();
            }
            if (this.isUpdating) {
                this.cancelRowUpdates();
            }
        }
    }
    
    boolean isOnInsertRow() {
        return this.isInserting;
    }
    
    private void cancelRowInserts() {
        if (this.isInserting) {
            this.isInserting = false;
            this.clearRowBuffer();
        }
    }
    
    boolean isUpdatingRow() {
        return this.isUpdating;
    }
    
    private void clearRowBuffer() {
        if (this.rowBuffer != null) {
            for (int i = 0; i < this.rowBuffer.length; ++i) {
                this.rowBuffer[i] = null;
            }
        }
        if (this.m_nullIndicator != null) {
            for (int j = 0; j < this.m_nullIndicator.length; ++j) {
                this.m_nullIndicator[j] = false;
            }
        }
        if (this.typeInfo != null) {
            for (int k = 0; k < this.typeInfo.length; ++k) {
                if (this.typeInfo[k] != null) {
                    for (int l = 0; l < this.typeInfo[k].length; ++l) {
                        this.typeInfo[k][l] = 0;
                    }
                }
            }
        }
        this.cleanTempLobs();
    }
    
    private void setRowBufferAt(final int n, final Datum datum) throws SQLException {
        this.setRowBufferAt(n, datum, null);
    }
    
    private void setRowBufferAt(final int n, final Object o, final int[] array) throws SQLException {
        if (!this.isInserting) {
            if (this.isBeforeFirst() || this.isAfterLast() || this.getRow() == 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 82);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.isUpdating = true;
        }
        if (n < 1 || n > this.getColumnCount() - 1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "setRowBufferAt");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.rowBuffer == null) {
            this.rowBuffer = new Object[this.getColumnCount()];
        }
        if (this.m_nullIndicator == null) {
            this.m_nullIndicator = new boolean[this.getColumnCount()];
            for (int i = 0; i < this.getColumnCount(); ++i) {
                this.m_nullIndicator[i] = false;
            }
        }
        if (array != null) {
            if (this.typeInfo == null) {
                this.typeInfo = new int[this.getColumnCount()][];
            }
            this.typeInfo[n] = array;
        }
        this.rowBuffer[n] = o;
        this.m_nullIndicator[n] = (o == null);
    }
    
    private Datum getRowBufferDatumAt(final int n) throws SQLException {
        if (n < 1 || n > this.getColumnCount() - 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        Object oracleDatum = null;
        if (this.rowBuffer != null) {
            final Object o = this.rowBuffer[n];
            if (o != null) {
                if (o instanceof Datum) {
                    oracleDatum = o;
                }
                else {
                    final OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)this.getInternalMetadata();
                    final int n2 = n + 1;
                    oracleDatum = SQLUtil.makeOracleDatum(this.connection, o, oracleResultSetMetaData.getColumnType(n2), null, oracleResultSetMetaData.isNCHAR(n2));
                    this.rowBuffer[n] = oracleDatum;
                }
            }
        }
        return (Datum)oracleDatum;
    }
    
    private Object getRowBufferAt(final int n) throws SQLException {
        if (n < 1 || n > this.getColumnCount() - 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.rowBuffer != null) {
            return this.rowBuffer[n];
        }
        return null;
    }
    
    private boolean isRowBufferUpdatedAt(final int n) {
        return this.rowBuffer != null && (this.rowBuffer[n] != null || this.m_nullIndicator[n]);
    }
    
    private void prepareInsertRowStatement() throws SQLException {
        if (this.insertStmt == null) {
            (this.insertStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getInsertSqlForUpdatableResultSet(this))).preparedStatement).setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
            if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
                this.insertStmt.setEscapeProcessing(true);
            }
        }
    }
    
    private void prepareInsertRowBinds() throws SQLException {
        final int prepareSubqueryBinds = this.prepareSubqueryBinds(this.insertStmt, 1);
        final OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)this.getInternalMetadata();
        for (int i = 1; i < this.getColumnCount(); ++i) {
            final Object rowBuffer = this.getRowBufferAt(i);
            if (rowBuffer != null) {
                if (rowBuffer instanceof Reader) {
                    if (oracleResultSetMetaData.isNCHAR(i + 1)) {
                        this.insertStmt.setFormOfUse(prepareSubqueryBinds, (short)2);
                    }
                    this.insertStmt.setCharacterStream(prepareSubqueryBinds + i - 1, (Reader)rowBuffer, this.typeInfo[i][0]);
                }
                else if (rowBuffer instanceof InputStream) {
                    if (this.typeInfo[i][1] == 2) {
                        this.insertStmt.setBinaryStream(prepareSubqueryBinds + i - 1, (InputStream)rowBuffer, this.typeInfo[i][0]);
                    }
                    else if (this.typeInfo[i][1] == 1) {
                        this.insertStmt.setAsciiStream(prepareSubqueryBinds + i - 1, (InputStream)rowBuffer, this.typeInfo[i][0]);
                    }
                }
                else {
                    final Datum rowBufferDatum = this.getRowBufferDatumAt(i);
                    if (oracleResultSetMetaData.isNCHAR(i + 1)) {
                        this.insertStmt.setFormOfUse(prepareSubqueryBinds + i - 1, (short)2);
                    }
                    this.insertStmt.setOracleObject(prepareSubqueryBinds + i - 1, rowBufferDatum);
                }
            }
            else {
                final int columnType = this.getInternalMetadata().getColumnType(i + 1);
                if (columnType == 2006 || columnType == 2002 || columnType == 2008 || columnType == 2007 || columnType == 2003) {
                    this.insertStmt.setNull(prepareSubqueryBinds + i - 1, columnType, this.getInternalMetadata().getColumnTypeName(i + 1));
                }
                else {
                    this.insertStmt.setNull(prepareSubqueryBinds + i - 1, columnType);
                }
            }
        }
    }
    
    private void executeInsertRow() throws SQLException {
        if (this.insertStmt.executeUpdate() != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 85);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    private int getNumColumnsChanged() throws SQLException {
        int n = 0;
        if (this.indexColsChanged == null) {
            this.indexColsChanged = new int[this.getColumnCount()];
        }
        if (this.rowBuffer != null) {
            for (int i = 1; i < this.getColumnCount(); ++i) {
                if (this.rowBuffer[i] != null || (this.rowBuffer[i] == null && this.m_nullIndicator[i])) {
                    this.indexColsChanged[n++] = i;
                }
            }
        }
        return n;
    }
    
    private void prepareUpdateRowStatement(final int n) throws SQLException {
        if (this.updateStmt != null) {
            this.updateStmt.close();
        }
        (this.updateStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getUpdateSqlForUpdatableResultSet(this, n, this.rowBuffer, this.indexColsChanged))).preparedStatement).setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
        if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
            this.updateStmt.setEscapeProcessing(true);
        }
    }
    
    private void prepareUpdateRowBinds(final int n) throws SQLException {
        int prepareSubqueryBinds = this.prepareSubqueryBinds(this.updateStmt, 1);
        final OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)this.getInternalMetadata();
        for (int i = 0; i < n; ++i) {
            final int n2 = this.indexColsChanged[i];
            final Object rowBuffer = this.getRowBufferAt(n2);
            if (rowBuffer != null) {
                if (rowBuffer instanceof Reader) {
                    if (oracleResultSetMetaData.isNCHAR(n2 + 1)) {
                        this.updateStmt.setFormOfUse(prepareSubqueryBinds, (short)2);
                    }
                    this.updateStmt.setCharacterStream(prepareSubqueryBinds++, (Reader)rowBuffer, this.typeInfo[n2][0]);
                }
                else if (rowBuffer instanceof InputStream) {
                    if (this.typeInfo[n2][1] == 2) {
                        this.updateStmt.setBinaryStream(prepareSubqueryBinds++, (InputStream)rowBuffer, this.typeInfo[n2][0]);
                    }
                    else if (this.typeInfo[n2][1] == 1) {
                        this.updateStmt.setAsciiStream(prepareSubqueryBinds++, (InputStream)rowBuffer, this.typeInfo[n2][0]);
                    }
                }
                else {
                    final Datum rowBufferDatum = this.getRowBufferDatumAt(n2);
                    if (oracleResultSetMetaData.isNCHAR(n2 + 1)) {
                        this.updateStmt.setFormOfUse(prepareSubqueryBinds, (short)2);
                    }
                    this.updateStmt.setOracleObject(prepareSubqueryBinds++, rowBufferDatum);
                }
            }
            else {
                final int columnType = this.getInternalMetadata().getColumnType(n2 + 1);
                if (columnType == 2006 || columnType == 2002 || columnType == 2008 || columnType == 2007 || columnType == 2003) {
                    this.updateStmt.setNull(prepareSubqueryBinds++, columnType, this.getInternalMetadata().getColumnTypeName(n2 + 1));
                }
                else {
                    if (oracleResultSetMetaData.isNCHAR(n2 + 1)) {
                        this.updateStmt.setFormOfUse(prepareSubqueryBinds, (short)2);
                    }
                    this.updateStmt.setNull(prepareSubqueryBinds++, columnType);
                }
            }
        }
        this.prepareCompareSelfBinds(this.updateStmt, prepareSubqueryBinds);
    }
    
    private void executeUpdateRow() throws SQLException {
        try {
            if (this.updateStmt.executeUpdate() == 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 85);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (this.isCachedRset) {
                ((ScrollableResultSet)this.resultSet).refreshRowsInCache(this.getRow(), 1, 1000);
                this.cancelRowUpdates();
            }
        }
        finally {
            if (this.updateStmt != null) {
                this.updateStmt.close();
                this.updateStmt = null;
            }
        }
    }
    
    private void prepareDeleteRowStatement() throws SQLException {
        if (this.deleteStmt == null) {
            (this.deleteStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getDeleteSqlForUpdatableResultSet(this))).preparedStatement).setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
            if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
                this.deleteStmt.setEscapeProcessing(true);
            }
        }
    }
    
    private void prepareDeleteRowBinds() throws SQLException {
        this.prepareCompareSelfBinds(this.deleteStmt, this.prepareSubqueryBinds(this.deleteStmt, 1));
    }
    
    private void executeDeleteRow() throws SQLException {
        if (this.deleteStmt.executeUpdate() == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 85);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.isCachedRset) {
            ((ScrollableResultSet)this.resultSet).removeRowInCache(this.getRow());
        }
    }
    
    private int prepareCompareSelfBinds(final OraclePreparedStatement oraclePreparedStatement, final int n) throws SQLException {
        oraclePreparedStatement.setOracleObject(n, this.resultSet.getOracleObject(1));
        return n + 1;
    }
    
    private int prepareSubqueryBinds(final OraclePreparedStatement oraclePreparedStatement, final int n) throws SQLException {
        return this.scrollStmt.copyBinds(oraclePreparedStatement, n - 1) + 1;
    }
    
    private void setIsNull(final int wasNull) {
        this.wasNull = wasNull;
    }
    
    private void setIsNull(final boolean b) {
        if (b) {
            this.wasNull = 1;
        }
        else {
            this.wasNull = 2;
        }
    }
    
    @Override
    public String getCursorName() throws SQLException {
        synchronized (this.connection) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 23, "getCursorName");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    @Override
    OracleStatement getOracleStatement() throws SQLException {
        return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
    }
    
    static {
        UpdatableResultSet._MIN_STREAM_SIZE = 4000;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
