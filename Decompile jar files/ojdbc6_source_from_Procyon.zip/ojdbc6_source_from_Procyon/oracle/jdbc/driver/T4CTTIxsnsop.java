// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.io.IOException;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.internal.OracleConnection;

class T4CTTIxsnsop extends T4CTTIfun
{
    private OracleConnection.XSOperationCode operationCode;
    private byte[] sessionId;
    private XSNamespace[] namespaces;
    private XSNamespace[] outNamespaces;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    T4CTTIxsnsop(final T4CConnection t4CConnection) {
        super(t4CConnection, (byte)3);
        this.setFunCode((short)172);
    }
    
    void doOXSNS(final OracleConnection.XSOperationCode operationCode, final byte[] sessionId, final XSNamespace[] namespaces, final boolean b) throws IOException, SQLException {
        if (b) {
            this.setTTCCode((byte)3);
        }
        else {
            this.setTTCCode((byte)17);
        }
        this.operationCode = operationCode;
        this.sessionId = sessionId;
        this.namespaces = namespaces;
        if (this.namespaces != null) {
            for (int i = 0; i < this.namespaces.length; ++i) {
                ((XSNamespaceI)this.namespaces[i]).doCharConversion(this.meg.conv);
            }
        }
        if (b) {
            this.doRPC();
        }
        else {
            this.doPigRPC();
        }
    }
    
    @Override
    void marshal() throws IOException {
        this.meg.marshalUB4(this.operationCode.getCode());
        boolean b = false;
        if (this.sessionId != null && this.sessionId.length > 0) {
            b = true;
            this.meg.marshalPTR();
            this.meg.marshalUB4(this.sessionId.length);
        }
        else {
            this.meg.marshalNULLPTR();
            this.meg.marshalUB4(0L);
        }
        boolean b2 = false;
        this.meg.marshalPTR();
        if (this.namespaces != null && this.namespaces.length > 0) {
            b2 = true;
            this.meg.marshalUB4(this.namespaces.length);
        }
        else {
            this.meg.marshalUB4(0L);
        }
        this.meg.marshalPTR();
        if (b) {
            this.meg.marshalB1Array(this.sessionId);
        }
        if (b2) {
            for (int i = 0; i < this.namespaces.length; ++i) {
                ((XSNamespaceI)this.namespaces[i]).marshal(this.meg);
            }
        }
    }
    
    @Override
    void readRPA() throws SQLException, IOException {
        this.outNamespaces = null;
        final int n = (int)this.meg.unmarshalUB4();
        if (n > 0) {
            this.outNamespaces = new XSNamespace[n];
            for (int i = 0; i < n; ++i) {
                this.outNamespaces[i] = XSNamespaceI.unmarshal(this.meg);
            }
        }
    }
    
    XSNamespace[] getNamespaces() throws SQLException {
        return this.outNamespaces;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return this.connection;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
