// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;

class SensitiveScrollableResultSet extends ScrollableResultSet
{
    int beginLastFetchedIndex;
    int endLastFetchedIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    SensitiveScrollableResultSet(final ScrollRsetStatement scrollRsetStatement, final OracleResultSetImpl oracleResultSetImpl, final int n, final int n2) throws SQLException {
        super(scrollRsetStatement, oracleResultSetImpl, n, n2);
        final int validRows = oracleResultSetImpl.getValidRows();
        if (validRows > 0) {
            this.beginLastFetchedIndex = 1;
            this.endLastFetchedIndex = validRows;
        }
        else {
            this.beginLastFetchedIndex = 0;
            this.endLastFetchedIndex = 0;
        }
    }
    
    @Override
    public boolean next() throws SQLException {
        synchronized (this.connection) {
            if (super.next()) {
                this.handle_refetch();
                return true;
            }
            return false;
        }
    }
    
    @Override
    public boolean first() throws SQLException {
        synchronized (this.connection) {
            if (super.first()) {
                this.handle_refetch();
                return true;
            }
            return false;
        }
    }
    
    @Override
    public boolean last() throws SQLException {
        synchronized (this.connection) {
            if (super.last()) {
                this.handle_refetch();
                return true;
            }
            return false;
        }
    }
    
    @Override
    public boolean absolute(final int n) throws SQLException {
        synchronized (this.connection) {
            if (super.absolute(n)) {
                this.handle_refetch();
                return true;
            }
            return false;
        }
    }
    
    @Override
    public boolean relative(final int n) throws SQLException {
        synchronized (this.connection) {
            if (super.relative(n)) {
                this.handle_refetch();
                return true;
            }
            return false;
        }
    }
    
    @Override
    public boolean previous() throws SQLException {
        synchronized (this.connection) {
            if (super.previous()) {
                this.handle_refetch();
                return true;
            }
            return false;
        }
    }
    
    @Override
    public void refreshRow() throws SQLException {
        synchronized (this.connection) {
            if (!this.isValidRow(this.currentRow)) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 11);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final int fetchDirection = this.getFetchDirection();
            int refreshRowsInCache;
            try {
                refreshRowsInCache = this.refreshRowsInCache(this.currentRow, this.getFetchSize(), fetchDirection);
            }
            catch (SQLException ex) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), ex, 90, "Unsupported syntax for refreshRow()");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
            if (refreshRowsInCache != 0) {
                this.beginLastFetchedIndex = this.currentRow;
                this.endLastFetchedIndex = this.currentRow + refreshRowsInCache - 1;
            }
        }
    }
    
    @Override
    int removeRowInCache(final int n) throws SQLException {
        synchronized (this.connection) {
            final int removeRowInCache = super.removeRowInCache(n);
            if (removeRowInCache != 0) {
                if (n >= this.beginLastFetchedIndex && n <= this.endLastFetchedIndex && this.beginLastFetchedIndex != this.endLastFetchedIndex) {
                    --this.endLastFetchedIndex;
                }
                else {
                    final int n2 = 0;
                    this.endLastFetchedIndex = n2;
                    this.beginLastFetchedIndex = n2;
                }
            }
            return removeRowInCache;
        }
    }
    
    private boolean handle_refetch() throws SQLException {
        synchronized (this.connection) {
            if ((this.currentRow >= this.beginLastFetchedIndex && this.currentRow <= this.endLastFetchedIndex) || (this.currentRow >= this.endLastFetchedIndex && this.currentRow <= this.beginLastFetchedIndex)) {
                return false;
            }
            this.refreshRow();
            return true;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
