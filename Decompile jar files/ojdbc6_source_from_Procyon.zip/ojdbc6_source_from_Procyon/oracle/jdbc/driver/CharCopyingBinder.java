// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

abstract class CharCopyingBinder extends Binder
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    Binder copyingBinder() {
        return this;
    }
    
    @Override
    void bind(final OraclePreparedStatement oraclePreparedStatement, final int n, final int n2, final int n3, final byte[] array, final char[] array2, final short[] array3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final boolean b) {
        char[] lastBoundChars;
        int n10;
        int n11;
        if (n2 == 0) {
            lastBoundChars = oraclePreparedStatement.lastBoundChars;
            n10 = oraclePreparedStatement.lastBoundCharOffsets[n];
            array3[n9] = oraclePreparedStatement.lastBoundInds[n];
            array3[n8] = oraclePreparedStatement.lastBoundLens[n];
            if (lastBoundChars == array2 && n10 == n7) {
                return;
            }
            n11 = oraclePreparedStatement.lastBoundCharLens[n];
            if (n11 > n5) {
                n11 = n5;
            }
        }
        else {
            lastBoundChars = array2;
            n10 = n7 - n5;
            array3[n9] = array3[n9 - 1];
            array3[n8] = array3[n8 - 1];
            n11 = n5;
        }
        System.arraycopy(lastBoundChars, n10, array2, n7, n11);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
