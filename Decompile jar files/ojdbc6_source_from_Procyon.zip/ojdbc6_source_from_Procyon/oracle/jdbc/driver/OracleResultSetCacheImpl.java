// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.util.Vector;

class OracleResultSetCacheImpl implements OracleResultSetCache
{
    private static int DEFAULT_WIDTH;
    private static int DEFAULT_SIZE;
    Vector cachedRows;
    int nbOfColumnsInRow;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleResultSetCacheImpl() {
        this(OracleResultSetCacheImpl.DEFAULT_WIDTH);
    }
    
    OracleResultSetCacheImpl(final int nbOfColumnsInRow) {
        this.cachedRows = null;
        if (nbOfColumnsInRow > 0) {
            this.nbOfColumnsInRow = nbOfColumnsInRow;
        }
        this.cachedRows = new Vector(OracleResultSetCacheImpl.DEFAULT_SIZE);
    }
    
    @Override
    public void put(final int n, final int n2, final Object obj) {
        while (this.cachedRows.size() < n) {
            this.cachedRows.addElement(new Vector<Vector>(this.nbOfColumnsInRow));
        }
        final Vector<Object> vector = this.cachedRows.elementAt(n - 1);
        while (vector.size() < n2) {
            vector.addElement(null);
        }
        vector.setElementAt(obj, n2 - 1);
    }
    
    @Override
    public Object get(final int n, final int n2) {
        return this.cachedRows.elementAt(n - 1).elementAt(n2 - 1);
    }
    
    @Override
    public void remove(final int n) {
        this.cachedRows.removeElementAt(n - 1);
    }
    
    @Override
    public void remove(final int n, final int n2) {
        this.cachedRows.removeElementAt(n - 1);
    }
    
    @Override
    public void clear() {
    }
    
    @Override
    public void close() {
    }
    
    public int getLength() {
        return 0;
    }
    
    static {
        OracleResultSetCacheImpl.DEFAULT_WIDTH = 5;
        OracleResultSetCacheImpl.DEFAULT_SIZE = 5;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
