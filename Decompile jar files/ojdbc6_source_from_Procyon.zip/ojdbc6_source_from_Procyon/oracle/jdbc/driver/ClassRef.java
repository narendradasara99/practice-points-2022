// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

class ClassRef
{
    private final ThreadLocal<Class> ref;
    private final String className;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static final ClassRef newInstance(final String s) throws ClassNotFoundException {
        return new ClassRef(s);
    }
    
    private ClassRef(final String className) throws ClassNotFoundException {
        this.ref = new ThreadLocal<Class>();
        this.className = className;
        this.ref.set(Class.forName(this.className, true, Thread.currentThread().getContextClassLoader()));
    }
    
    Class get() {
        Class<?> forName = this.ref.get();
        if (forName == null) {
            try {
                forName = Class.forName(this.className, true, Thread.currentThread().getContextClassLoader());
            }
            catch (ClassNotFoundException cause) {
                final NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(cause.getMessage());
                noClassDefFoundError.initCause(cause);
                throw noClassDefFoundError;
            }
            this.ref.set(forName);
        }
        return forName;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
