// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import oracle.sql.SQLName;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import java.net.UnknownHostException;
import java.net.InetAddress;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.internal.KeywordValueLong;
import javax.transaction.xa.XAResource;
import java.sql.SQLXML;
import java.sql.NClob;
import java.sql.Clob;
import java.sql.Blob;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.STRUCT;
import java.sql.Struct;
import java.sql.Array;
import java.math.BigInteger;
import java.math.BigDecimal;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import java.sql.Timestamp;
import java.sql.Time;
import oracle.sql.DATE;
import java.sql.Date;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.NCLOB;
import oracle.sql.CLOB;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.pool.OraclePooledConnection;
import java.sql.ResultSetMetaData;
import oracle.sql.StructDescriptor;
import oracle.sql.ArrayDescriptor;
import oracle.sql.ARRAY;
import oracle.sql.Datum;
import oracle.sql.CustomDatum;
import oracle.jdbc.oracore.OracleTypeADT;
import java.util.GregorianCalendar;
import oracle.jdbc.OracleOCIFailover;
import oracle.sql.BfileDBAccess;
import oracle.sql.ClobDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.jdbc.OracleSavepoint;
import java.sql.Savepoint;
import oracle.jdbc.oracore.Util;
import java.sql.ResultSet;
import java.util.Collection;
import java.util.Vector;
import oracle.sql.TypeDescriptor;
import java.sql.DatabaseMetaData;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import java.security.Permission;
import java.util.EnumSet;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Enumeration;
import oracle.security.pki.OracleSecretStore;
import oracle.security.pki.OracleWallet;
import oracle.net.nt.CustomSSLSocketFactory;
import java.sql.DriverManager;
import java.util.Iterator;
import java.sql.SQLException;
import oracle.sql.TIMEZONETAB;
import java.util.Calendar;
import oracle.jdbc.OracleSQLPermission;
import java.util.regex.Pattern;
import oracle.sql.CharacterSet;
import java.util.TimeZone;
import java.sql.Statement;
import java.sql.SQLWarning;
import oracle.jdbc.OracleDatabaseMetaData;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

abstract class PhysicalConnection extends OracleConnection
{
    public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
    public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
    public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
    public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
    public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
    public static final char slash_character = '/';
    public static final char at_sign_character = '@';
    public static final char left_square_bracket_character = '[';
    public static final char right_square_bracket_character = ']';
    static final byte[] EMPTY_BYTE_ARRAY;
    char[][] charOutput;
    byte[][] byteOutput;
    short[][] shortOutput;
    Properties sessionProperties;
    boolean retainV9BindBehavior;
    String userName;
    String database;
    boolean autocommit;
    String protocol;
    int streamChunkSize;
    boolean setFloatAndDoubleUseBinary;
    String ocidll;
    String thinVsessionTerminal;
    String thinVsessionMachine;
    String thinVsessionOsuser;
    String thinVsessionProgram;
    String thinVsessionProcess;
    String thinVsessionIname;
    String thinVsessionEname;
    String thinNetProfile;
    String thinNetAuthenticationServices;
    String thinNetAuthenticationKrb5Mutual;
    String thinNetAuthenticationKrb5CcName;
    String thinNetEncryptionLevel;
    String thinNetEncryptionTypes;
    String thinNetChecksumLevel;
    String thinNetChecksumTypes;
    String thinNetCryptoSeed;
    boolean thinTcpNoDelay;
    String thinReadTimeout;
    String thinNetConnectTimeout;
    boolean thinNetDisableOutOfBandBreak;
    boolean thinNetUseZeroCopyIO;
    boolean thinNetEnableSDP;
    boolean use1900AsYearForTime;
    boolean timestamptzInGmt;
    boolean timezoneAsRegion;
    String thinSslServerDnMatch;
    String thinSslVersion;
    String thinSslCipherSuites;
    String thinJavaxNetSslKeystore;
    String thinJavaxNetSslKeystoretype;
    String thinJavaxNetSslKeystorepassword;
    String thinJavaxNetSslTruststore;
    String thinJavaxNetSslTruststoretype;
    String thinJavaxNetSslTruststorepassword;
    String thinSslKeymanagerfactoryAlgorithm;
    String thinSslTrustmanagerfactoryAlgorithm;
    String thinNetOldsyntax;
    String thinNamingContextInitial;
    String thinNamingProviderUrl;
    String thinNamingSecurityAuthentication;
    String thinNamingSecurityPrincipal;
    String thinNamingSecurityCredentials;
    String walletLocation;
    String walletPassword;
    String proxyClientName;
    boolean useNio;
    String ociDriverCharset;
    String editionName;
    String logonCap;
    String internalLogon;
    boolean createDescriptorUseCurrentSchemaForSchemaName;
    long ociSvcCtxHandle;
    long ociEnvHandle;
    long ociErrHandle;
    boolean prelimAuth;
    boolean nlsLangBackdoor;
    String setNewPassword;
    boolean spawnNewThreadToCancel;
    int defaultExecuteBatch;
    int defaultRowPrefetch;
    int defaultLobPrefetchSize;
    boolean enableDataInLocator;
    boolean enableReadDataInLocator;
    boolean overrideEnableReadDataInLocator;
    boolean reportRemarks;
    boolean includeSynonyms;
    boolean restrictGettables;
    boolean accumulateBatchResult;
    boolean useFetchSizeWithLongColumn;
    boolean processEscapes;
    boolean fixedString;
    boolean defaultnchar;
    boolean permitTimestampDateMismatch;
    String resourceManagerId;
    boolean disableDefinecolumntype;
    boolean convertNcharLiterals;
    boolean j2ee13Compliant;
    boolean mapDateToTimestamp;
    boolean useThreadLocalBufferCache;
    String driverNameAttribute;
    int maxCachedBufferSize;
    int implicitStatementCacheSize;
    boolean lobStreamPosStandardCompliant;
    boolean getObjectReturnsXmlType;
    boolean isStrictAsciiConversion;
    boolean thinForceDnsLoadBalancing;
    String url;
    String savedUser;
    int commitOption;
    int ociConnectionPoolMinLimit;
    int ociConnectionPoolMaxLimit;
    int ociConnectionPoolIncrement;
    int ociConnectionPoolTimeout;
    boolean ociConnectionPoolNoWait;
    boolean ociConnectionPoolTransactionDistributed;
    String ociConnectionPoolLogonMode;
    boolean ociConnectionPoolIsPooling;
    Object ociConnectionPoolObject;
    Object ociConnectionPoolConnID;
    String ociConnectionPoolProxyType;
    Integer ociConnectionPoolProxyNumRoles;
    Object ociConnectionPoolProxyRoles;
    String ociConnectionPoolProxyUserName;
    String ociConnectionPoolProxyPassword;
    String ociConnectionPoolProxyDistinguishedName;
    Object ociConnectionPoolProxyCertificate;
    static NTFManager ntfManager;
    public int protocolId;
    OracleTimeout timeout;
    DBConversion conversion;
    boolean xaWantsError;
    boolean usingXA;
    int txnMode;
    byte[] fdo;
    Boolean bigEndian;
    OracleStatement statements;
    int lifecycle;
    static final int OPEN = 1;
    static final int CLOSING = 2;
    static final int CLOSED = 4;
    static final int ABORTED = 8;
    static final int BLOCKED = 16;
    boolean clientIdSet;
    String clientId;
    int txnLevel;
    Map map;
    Map javaObjectMap;
    final Hashtable[] descriptorCacheStack;
    int dci;
    OracleStatement statementHoldingLine;
    OracleDatabaseMetaData databaseMetaData;
    LogicalConnection logicalConnectionAttached;
    boolean isProxy;
    OracleSql sqlObj;
    SQLWarning sqlWarning;
    boolean readOnly;
    LRUStatementCache statementCache;
    boolean clearStatementMetaData;
    OracleCloseCallback closeCallback;
    Object privateData;
    Statement savepointStatement;
    boolean isUsable;
    TimeZone defaultTimeZone;
    final int[] endToEndMaxLength;
    boolean endToEndAnyChanged;
    final boolean[] endToEndHasChanged;
    short endToEndECIDSequenceNumber;
    static final int DMS_NONE = 0;
    static final int DMS_10G = 1;
    static final int DMS_11 = 2;
    String[] endToEndValues;
    final int whichDMS = 0;
    oracle.jdbc.OracleConnection wrapper;
    int minVcsBindSize;
    int maxRawBytesSql;
    int maxRawBytesPlsql;
    int maxVcsCharsSql;
    int maxVcsNCharsSql;
    int maxVcsBytesPlsql;
    int maxIbtVarcharElementLength;
    String instanceName;
    OracleDriverExtension driverExtension;
    static final String uninitializedMarker = "";
    String databaseProductVersion;
    short versionNumber;
    int namedTypeAccessorByteLen;
    int refTypeAccessorByteLen;
    CharacterSet setCHARCharSetObj;
    CharacterSet setCHARNCharSetObj;
    boolean plsqlCompilerWarnings;
    private static final Pattern driverNameAttributePattern;
    private static final OracleSQLPermission CALL_ABORT_PERMISSION;
    static final String DATABASE_NAME = "DATABASE_NAME";
    static final String SERVER_HOST = "SERVER_HOST";
    static final String INSTANCE_NAME = "INSTANCE_NAME";
    static final String SERVICE_NAME = "SERVICE_NAME";
    Hashtable clientData;
    private BufferCacheStore connectionBufferCacheStore;
    private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore;
    private int pingResult;
    String sessionTimeZone;
    String databaseTimeZone;
    Calendar dbTzCalendar;
    static final String RAW_STR = "RAW";
    static final String SYS_RAW_STR = "SYS.RAW";
    static final String SYS_ANYDATA_STR = "SYS.ANYDATA";
    static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
    int timeZoneVersionNumber;
    TIMEZONETAB timeZoneTab;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected PhysicalConnection() {
        this.charOutput = new char[1][];
        this.byteOutput = new byte[1][];
        this.shortOutput = new short[1][];
        this.sessionProperties = null;
        this.ociConnectionPoolMinLimit = 0;
        this.ociConnectionPoolMaxLimit = 0;
        this.ociConnectionPoolIncrement = 0;
        this.ociConnectionPoolTimeout = 0;
        this.ociConnectionPoolNoWait = false;
        this.ociConnectionPoolTransactionDistributed = false;
        this.ociConnectionPoolLogonMode = null;
        this.ociConnectionPoolIsPooling = false;
        this.ociConnectionPoolObject = null;
        this.ociConnectionPoolConnID = null;
        this.ociConnectionPoolProxyType = null;
        this.ociConnectionPoolProxyNumRoles = 0;
        this.ociConnectionPoolProxyRoles = null;
        this.ociConnectionPoolProxyUserName = null;
        this.ociConnectionPoolProxyPassword = null;
        this.ociConnectionPoolProxyDistinguishedName = null;
        this.ociConnectionPoolProxyCertificate = null;
        this.protocolId = -3;
        this.txnMode = 0;
        this.clientIdSet = false;
        this.clientId = null;
        this.descriptorCacheStack = new Hashtable[2];
        this.dci = 0;
        this.databaseMetaData = null;
        this.isProxy = false;
        this.sqlObj = null;
        this.sqlWarning = null;
        this.readOnly = false;
        this.statementCache = null;
        this.clearStatementMetaData = false;
        this.closeCallback = null;
        this.privateData = null;
        this.savepointStatement = null;
        this.isUsable = true;
        this.defaultTimeZone = null;
        this.endToEndMaxLength = new int[4];
        this.endToEndAnyChanged = false;
        this.endToEndHasChanged = new boolean[4];
        this.endToEndECIDSequenceNumber = -32768;
        this.endToEndValues = null;
        this.wrapper = null;
        this.instanceName = null;
        this.databaseProductVersion = "";
        this.versionNumber = -1;
        this.plsqlCompilerWarnings = false;
        this.sessionTimeZone = null;
        this.databaseTimeZone = null;
        this.dbTzCalendar = null;
        this.timeZoneVersionNumber = -1;
        this.timeZoneTab = null;
    }
    
    PhysicalConnection(final String s, final Properties properties, final OracleDriverExtension driverExtension) throws SQLException {
        this.charOutput = new char[1][];
        this.byteOutput = new byte[1][];
        this.shortOutput = new short[1][];
        this.sessionProperties = null;
        this.ociConnectionPoolMinLimit = 0;
        this.ociConnectionPoolMaxLimit = 0;
        this.ociConnectionPoolIncrement = 0;
        this.ociConnectionPoolTimeout = 0;
        this.ociConnectionPoolNoWait = false;
        this.ociConnectionPoolTransactionDistributed = false;
        this.ociConnectionPoolLogonMode = null;
        this.ociConnectionPoolIsPooling = false;
        this.ociConnectionPoolObject = null;
        this.ociConnectionPoolConnID = null;
        this.ociConnectionPoolProxyType = null;
        this.ociConnectionPoolProxyNumRoles = 0;
        this.ociConnectionPoolProxyRoles = null;
        this.ociConnectionPoolProxyUserName = null;
        this.ociConnectionPoolProxyPassword = null;
        this.ociConnectionPoolProxyDistinguishedName = null;
        this.ociConnectionPoolProxyCertificate = null;
        this.protocolId = -3;
        this.txnMode = 0;
        this.clientIdSet = false;
        this.clientId = null;
        this.descriptorCacheStack = new Hashtable[2];
        this.dci = 0;
        this.databaseMetaData = null;
        this.isProxy = false;
        this.sqlObj = null;
        this.sqlWarning = null;
        this.readOnly = false;
        this.statementCache = null;
        this.clearStatementMetaData = false;
        this.closeCallback = null;
        this.privateData = null;
        this.savepointStatement = null;
        this.isUsable = true;
        this.defaultTimeZone = null;
        this.endToEndMaxLength = new int[4];
        this.endToEndAnyChanged = false;
        this.endToEndHasChanged = new boolean[4];
        this.endToEndECIDSequenceNumber = -32768;
        this.endToEndValues = null;
        this.wrapper = null;
        this.instanceName = null;
        this.databaseProductVersion = "";
        this.versionNumber = -1;
        this.plsqlCompilerWarnings = false;
        this.sessionTimeZone = null;
        this.databaseTimeZone = null;
        this.dbTzCalendar = null;
        this.timeZoneVersionNumber = -1;
        this.timeZoneTab = null;
        this.readConnectionProperties(s, properties);
        this.driverExtension = driverExtension;
        this.initialize(null, null, null);
        this.logicalConnectionAttached = null;
        try {
            this.needLine();
            this.logon();
            this.setAutoCommit(this.autocommit);
            if (this.getVersionNumber() >= 11202) {
                this.minVcsBindSize = 4001;
                this.maxRawBytesSql = 4000;
                this.maxRawBytesPlsql = 32766;
                this.maxVcsCharsSql = 32766;
                this.maxVcsNCharsSql = 32766;
                this.maxVcsBytesPlsql = 32766;
                this.maxIbtVarcharElementLength = 32766;
                this.endToEndMaxLength[0] = 64;
                this.endToEndMaxLength[1] = 64;
                this.endToEndMaxLength[2] = 64;
                this.endToEndMaxLength[3] = 64;
            }
            else if (this.getVersionNumber() >= 11000) {
                this.minVcsBindSize = 4001;
                this.maxRawBytesSql = 4000;
                this.maxRawBytesPlsql = 32766;
                this.maxVcsCharsSql = 32766;
                this.maxVcsNCharsSql = 32766;
                this.maxVcsBytesPlsql = 32766;
                this.maxIbtVarcharElementLength = 32766;
                this.endToEndMaxLength[0] = 32;
                this.endToEndMaxLength[1] = 64;
                this.endToEndMaxLength[2] = 64;
                this.endToEndMaxLength[3] = 48;
            }
            else if (this.getVersionNumber() >= 10000) {
                this.minVcsBindSize = 4001;
                this.maxRawBytesSql = 2000;
                this.maxRawBytesPlsql = 32512;
                this.maxVcsCharsSql = 32766;
                this.maxVcsNCharsSql = 32766;
                this.maxVcsBytesPlsql = 32512;
                this.maxIbtVarcharElementLength = 32766;
                this.endToEndMaxLength[0] = 32;
                this.endToEndMaxLength[1] = 64;
                this.endToEndMaxLength[2] = 64;
                this.endToEndMaxLength[3] = 48;
            }
            else if (this.getVersionNumber() >= 9200) {
                this.minVcsBindSize = 4001;
                this.maxRawBytesSql = 2000;
                this.maxRawBytesPlsql = 32512;
                this.maxVcsCharsSql = 32766;
                this.maxVcsNCharsSql = 32766;
                this.maxVcsBytesPlsql = 32512;
                this.maxIbtVarcharElementLength = 32766;
                this.endToEndMaxLength[0] = 32;
                this.endToEndMaxLength[1] = 64;
                this.endToEndMaxLength[2] = 64;
                this.endToEndMaxLength[3] = 48;
            }
            else {
                this.minVcsBindSize = 4001;
                this.maxRawBytesSql = 2000;
                this.maxRawBytesPlsql = 2000;
                this.maxVcsCharsSql = 4000;
                this.maxVcsNCharsSql = 4000;
                this.maxVcsBytesPlsql = 4000;
                this.maxIbtVarcharElementLength = 4000;
                this.endToEndMaxLength[0] = 32;
                this.endToEndMaxLength[1] = 64;
                this.endToEndMaxLength[2] = 64;
                this.endToEndMaxLength[3] = 48;
            }
            this.initializeSetCHARCharSetObjs();
            if (this.implicitStatementCacheSize > 0) {
                this.setStatementCacheSize(this.implicitStatementCacheSize);
                this.setImplicitCachingEnabled(true);
            }
        }
        catch (SQLException ex) {
            this.lifecycle = 2;
            try {
                this.logoff();
            }
            catch (SQLException ex2) {}
            this.lifecycle = 4;
            throw ex;
        }
        this.txnMode = 0;
    }
    
    private static final String propertyVariableName(final String s) {
        final char[] dst = new char[s.length()];
        s.getChars(0, s.length(), dst, 0);
        String s2 = "";
        for (int i = 0; i < dst.length; ++i) {
            if (Character.isUpperCase(dst[i])) {
                s2 += "_";
            }
            s2 += Character.toUpperCase(dst[i]);
        }
        return s2;
    }
    
    private void initializeUserDefaults(final Properties properties) {
        for (final String key : OracleDriver.DEFAULT_CONNECTION_PROPERTIES.stringPropertyNames()) {
            if (!properties.containsKey(key)) {
                properties.setProperty(key, OracleDriver.DEFAULT_CONNECTION_PROPERTIES.getProperty(key));
            }
        }
    }
    
    private void readConnectionProperties(final String url, final Properties properties) throws SQLException {
        this.initializeUserDefaults(properties);
        String s = null;
        if (properties != null) {
            s = properties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
        }
        if (s == null) {
            s = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", null);
        }
        if (s == null) {
            s = "false";
        }
        this.retainV9BindBehavior = (s != null && s.equalsIgnoreCase("true"));
        String userName = null;
        if (properties != null) {
            userName = properties.getProperty("user");
            if (userName == null) {
                userName = properties.getProperty("oracle.jdbc.user");
            }
        }
        if (userName == null) {
            userName = getSystemProperty("oracle.jdbc.user", null);
        }
        if (userName == null) {
            userName = null;
        }
        this.userName = userName;
        String database = null;
        if (properties != null) {
            database = properties.getProperty("database");
            if (database == null) {
                database = properties.getProperty("oracle.jdbc.database");
            }
        }
        if (database == null) {
            database = getSystemProperty("oracle.jdbc.database", null);
        }
        if (database == null) {
            database = null;
        }
        this.database = database;
        String s2 = null;
        if (properties != null) {
            s2 = properties.getProperty("autoCommit");
            if (s2 == null) {
                s2 = properties.getProperty("oracle.jdbc.autoCommit");
            }
        }
        if (s2 == null) {
            s2 = getSystemProperty("oracle.jdbc.autoCommit", null);
        }
        if (s2 == null) {
            s2 = "true";
        }
        this.autocommit = (s2 != null && s2.equalsIgnoreCase("true"));
        String protocol = null;
        if (properties != null) {
            protocol = properties.getProperty("protocol");
            if (protocol == null) {
                protocol = properties.getProperty("oracle.jdbc.protocol");
            }
        }
        if (protocol == null) {
            protocol = getSystemProperty("oracle.jdbc.protocol", null);
        }
        if (protocol == null) {
            protocol = null;
        }
        this.protocol = protocol;
        String s3 = null;
        if (properties != null) {
            s3 = properties.getProperty("oracle.jdbc.StreamChunkSize");
        }
        if (s3 == null) {
            s3 = getSystemProperty("oracle.jdbc.StreamChunkSize", null);
        }
        if (s3 == null) {
            s3 = "16384";
        }
        try {
            this.streamChunkSize = Integer.parseInt(s3);
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String s4 = null;
        if (properties != null) {
            s4 = properties.getProperty("SetFloatAndDoubleUseBinary");
            if (s4 == null) {
                s4 = properties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary");
            }
        }
        if (s4 == null) {
            s4 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", null);
        }
        if (s4 == null) {
            s4 = "false";
        }
        this.setFloatAndDoubleUseBinary = (s4 != null && s4.equalsIgnoreCase("true"));
        String ocidll = null;
        if (properties != null) {
            ocidll = properties.getProperty("oracle.jdbc.ocinativelibrary");
        }
        if (ocidll == null) {
            ocidll = getSystemProperty("oracle.jdbc.ocinativelibrary", null);
        }
        if (ocidll == null) {
            ocidll = null;
        }
        this.ocidll = ocidll;
        String thinVsessionTerminal = null;
        if (properties != null) {
            thinVsessionTerminal = properties.getProperty("v$session.terminal");
            if (thinVsessionTerminal == null) {
                thinVsessionTerminal = properties.getProperty("oracle.jdbc.v$session.terminal");
            }
        }
        if (thinVsessionTerminal == null) {
            thinVsessionTerminal = getSystemProperty("oracle.jdbc.v$session.terminal", null);
        }
        if (thinVsessionTerminal == null) {
            thinVsessionTerminal = "unknown";
        }
        this.thinVsessionTerminal = thinVsessionTerminal;
        String thinVsessionMachine = null;
        if (properties != null) {
            thinVsessionMachine = properties.getProperty("v$session.machine");
            if (thinVsessionMachine == null) {
                thinVsessionMachine = properties.getProperty("oracle.jdbc.v$session.machine");
            }
        }
        if (thinVsessionMachine == null) {
            thinVsessionMachine = getSystemProperty("oracle.jdbc.v$session.machine", null);
        }
        if (thinVsessionMachine == null) {
            thinVsessionMachine = null;
        }
        this.thinVsessionMachine = thinVsessionMachine;
        String thinVsessionOsuser = null;
        if (properties != null) {
            thinVsessionOsuser = properties.getProperty("v$session.osuser");
            if (thinVsessionOsuser == null) {
                thinVsessionOsuser = properties.getProperty("oracle.jdbc.v$session.osuser");
            }
        }
        if (thinVsessionOsuser == null) {
            thinVsessionOsuser = getSystemProperty("oracle.jdbc.v$session.osuser", null);
        }
        if (thinVsessionOsuser == null) {
            thinVsessionOsuser = null;
        }
        this.thinVsessionOsuser = thinVsessionOsuser;
        String thinVsessionProgram = null;
        if (properties != null) {
            thinVsessionProgram = properties.getProperty("v$session.program");
            if (thinVsessionProgram == null) {
                thinVsessionProgram = properties.getProperty("oracle.jdbc.v$session.program");
            }
        }
        if (thinVsessionProgram == null) {
            thinVsessionProgram = getSystemProperty("oracle.jdbc.v$session.program", null);
        }
        if (thinVsessionProgram == null) {
            thinVsessionProgram = "JDBC Thin Client";
        }
        this.thinVsessionProgram = thinVsessionProgram;
        String thinVsessionProcess = null;
        if (properties != null) {
            thinVsessionProcess = properties.getProperty("v$session.process");
            if (thinVsessionProcess == null) {
                thinVsessionProcess = properties.getProperty("oracle.jdbc.v$session.process");
            }
        }
        if (thinVsessionProcess == null) {
            thinVsessionProcess = getSystemProperty("oracle.jdbc.v$session.process", null);
        }
        if (thinVsessionProcess == null) {
            thinVsessionProcess = "1234";
        }
        this.thinVsessionProcess = thinVsessionProcess;
        String thinVsessionIname = null;
        if (properties != null) {
            thinVsessionIname = properties.getProperty("v$session.iname");
            if (thinVsessionIname == null) {
                thinVsessionIname = properties.getProperty("oracle.jdbc.v$session.iname");
            }
        }
        if (thinVsessionIname == null) {
            thinVsessionIname = getSystemProperty("oracle.jdbc.v$session.iname", null);
        }
        if (thinVsessionIname == null) {
            thinVsessionIname = "jdbc_ttc_impl";
        }
        this.thinVsessionIname = thinVsessionIname;
        String thinVsessionEname = null;
        if (properties != null) {
            thinVsessionEname = properties.getProperty("v$session.ename");
            if (thinVsessionEname == null) {
                thinVsessionEname = properties.getProperty("oracle.jdbc.v$session.ename");
            }
        }
        if (thinVsessionEname == null) {
            thinVsessionEname = getSystemProperty("oracle.jdbc.v$session.ename", null);
        }
        if (thinVsessionEname == null) {
            thinVsessionEname = null;
        }
        this.thinVsessionEname = thinVsessionEname;
        String thinNetProfile = null;
        if (properties != null) {
            thinNetProfile = properties.getProperty("oracle.net.profile");
        }
        if (thinNetProfile == null) {
            thinNetProfile = getSystemProperty("oracle.net.profile", null);
        }
        if (thinNetProfile == null) {
            thinNetProfile = null;
        }
        this.thinNetProfile = thinNetProfile;
        String thinNetAuthenticationServices = null;
        if (properties != null) {
            thinNetAuthenticationServices = properties.getProperty("oracle.net.authentication_services");
        }
        if (thinNetAuthenticationServices == null) {
            thinNetAuthenticationServices = getSystemProperty("oracle.net.authentication_services", null);
        }
        if (thinNetAuthenticationServices == null) {
            thinNetAuthenticationServices = null;
        }
        this.thinNetAuthenticationServices = thinNetAuthenticationServices;
        String thinNetAuthenticationKrb5Mutual = null;
        if (properties != null) {
            thinNetAuthenticationKrb5Mutual = properties.getProperty("oracle.net.kerberos5_mutual_authentication");
        }
        if (thinNetAuthenticationKrb5Mutual == null) {
            thinNetAuthenticationKrb5Mutual = getSystemProperty("oracle.net.kerberos5_mutual_authentication", null);
        }
        if (thinNetAuthenticationKrb5Mutual == null) {
            thinNetAuthenticationKrb5Mutual = null;
        }
        this.thinNetAuthenticationKrb5Mutual = thinNetAuthenticationKrb5Mutual;
        String thinNetAuthenticationKrb5CcName = null;
        if (properties != null) {
            thinNetAuthenticationKrb5CcName = properties.getProperty("oracle.net.kerberos5_cc_name");
        }
        if (thinNetAuthenticationKrb5CcName == null) {
            thinNetAuthenticationKrb5CcName = getSystemProperty("oracle.net.kerberos5_cc_name", null);
        }
        if (thinNetAuthenticationKrb5CcName == null) {
            thinNetAuthenticationKrb5CcName = null;
        }
        this.thinNetAuthenticationKrb5CcName = thinNetAuthenticationKrb5CcName;
        String thinNetEncryptionLevel = null;
        if (properties != null) {
            thinNetEncryptionLevel = properties.getProperty("oracle.net.encryption_client");
        }
        if (thinNetEncryptionLevel == null) {
            thinNetEncryptionLevel = getSystemProperty("oracle.net.encryption_client", null);
        }
        if (thinNetEncryptionLevel == null) {
            thinNetEncryptionLevel = null;
        }
        this.thinNetEncryptionLevel = thinNetEncryptionLevel;
        String thinNetEncryptionTypes = null;
        if (properties != null) {
            thinNetEncryptionTypes = properties.getProperty("oracle.net.encryption_types_client");
        }
        if (thinNetEncryptionTypes == null) {
            thinNetEncryptionTypes = getSystemProperty("oracle.net.encryption_types_client", null);
        }
        if (thinNetEncryptionTypes == null) {
            thinNetEncryptionTypes = null;
        }
        this.thinNetEncryptionTypes = thinNetEncryptionTypes;
        String thinNetChecksumLevel = null;
        if (properties != null) {
            thinNetChecksumLevel = properties.getProperty("oracle.net.crypto_checksum_client");
        }
        if (thinNetChecksumLevel == null) {
            thinNetChecksumLevel = getSystemProperty("oracle.net.crypto_checksum_client", null);
        }
        if (thinNetChecksumLevel == null) {
            thinNetChecksumLevel = null;
        }
        this.thinNetChecksumLevel = thinNetChecksumLevel;
        String thinNetChecksumTypes = null;
        if (properties != null) {
            thinNetChecksumTypes = properties.getProperty("oracle.net.crypto_checksum_types_client");
        }
        if (thinNetChecksumTypes == null) {
            thinNetChecksumTypes = getSystemProperty("oracle.net.crypto_checksum_types_client", null);
        }
        if (thinNetChecksumTypes == null) {
            thinNetChecksumTypes = null;
        }
        this.thinNetChecksumTypes = thinNetChecksumTypes;
        String thinNetCryptoSeed = null;
        if (properties != null) {
            thinNetCryptoSeed = properties.getProperty("oracle.net.crypto_seed");
        }
        if (thinNetCryptoSeed == null) {
            thinNetCryptoSeed = getSystemProperty("oracle.net.crypto_seed", null);
        }
        if (thinNetCryptoSeed == null) {
            thinNetCryptoSeed = null;
        }
        this.thinNetCryptoSeed = thinNetCryptoSeed;
        String s5 = null;
        if (properties != null) {
            s5 = properties.getProperty("oracle.jdbc.TcpNoDelay");
        }
        if (s5 == null) {
            s5 = getSystemProperty("oracle.jdbc.TcpNoDelay", null);
        }
        if (s5 == null) {
            s5 = "false";
        }
        this.thinTcpNoDelay = (s5 != null && s5.equalsIgnoreCase("true"));
        String thinReadTimeout = null;
        if (properties != null) {
            thinReadTimeout = properties.getProperty("oracle.jdbc.ReadTimeout");
        }
        if (thinReadTimeout == null) {
            thinReadTimeout = getSystemProperty("oracle.jdbc.ReadTimeout", null);
        }
        if (thinReadTimeout == null) {
            thinReadTimeout = null;
        }
        this.thinReadTimeout = thinReadTimeout;
        String thinNetConnectTimeout = null;
        if (properties != null) {
            thinNetConnectTimeout = properties.getProperty("oracle.net.CONNECT_TIMEOUT");
        }
        if (thinNetConnectTimeout == null) {
            thinNetConnectTimeout = getSystemProperty("oracle.net.CONNECT_TIMEOUT", null);
        }
        if (thinNetConnectTimeout == null) {
            thinNetConnectTimeout = null;
        }
        this.thinNetConnectTimeout = thinNetConnectTimeout;
        String s6 = null;
        if (properties != null) {
            s6 = properties.getProperty("oracle.net.disableOob");
        }
        if (s6 == null) {
            s6 = getSystemProperty("oracle.net.disableOob", null);
        }
        if (s6 == null) {
            s6 = "false";
        }
        this.thinNetDisableOutOfBandBreak = (s6 != null && s6.equalsIgnoreCase("true"));
        String s7 = null;
        if (properties != null) {
            s7 = properties.getProperty("oracle.net.useZeroCopyIO");
        }
        if (s7 == null) {
            s7 = getSystemProperty("oracle.net.useZeroCopyIO", null);
        }
        if (s7 == null) {
            s7 = "true";
        }
        this.thinNetUseZeroCopyIO = (s7 != null && s7.equalsIgnoreCase("true"));
        String s8 = null;
        if (properties != null) {
            s8 = properties.getProperty("oracle.net.SDP");
        }
        if (s8 == null) {
            s8 = getSystemProperty("oracle.net.SDP", null);
        }
        if (s8 == null) {
            s8 = "false";
        }
        this.thinNetEnableSDP = (s8 != null && s8.equalsIgnoreCase("true"));
        String s9 = null;
        if (properties != null) {
            s9 = properties.getProperty("oracle.jdbc.use1900AsYearForTime");
        }
        if (s9 == null) {
            s9 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", null);
        }
        if (s9 == null) {
            s9 = "false";
        }
        this.use1900AsYearForTime = (s9 != null && s9.equalsIgnoreCase("true"));
        String s10 = null;
        if (properties != null) {
            s10 = properties.getProperty("oracle.jdbc.timestampTzInGmt");
        }
        if (s10 == null) {
            s10 = getSystemProperty("oracle.jdbc.timestampTzInGmt", null);
        }
        if (s10 == null) {
            s10 = "true";
        }
        this.timestamptzInGmt = (s10 != null && s10.equalsIgnoreCase("true"));
        String s11 = null;
        if (properties != null) {
            s11 = properties.getProperty("oracle.jdbc.timezoneAsRegion");
        }
        if (s11 == null) {
            s11 = getSystemProperty("oracle.jdbc.timezoneAsRegion", null);
        }
        if (s11 == null) {
            s11 = "true";
        }
        this.timezoneAsRegion = (s11 != null && s11.equalsIgnoreCase("true"));
        String thinSslServerDnMatch = null;
        if (properties != null) {
            thinSslServerDnMatch = properties.getProperty("oracle.net.ssl_server_dn_match");
        }
        if (thinSslServerDnMatch == null) {
            thinSslServerDnMatch = getSystemProperty("oracle.net.ssl_server_dn_match", null);
        }
        if (thinSslServerDnMatch == null) {
            thinSslServerDnMatch = null;
        }
        this.thinSslServerDnMatch = thinSslServerDnMatch;
        String thinSslVersion = null;
        if (properties != null) {
            thinSslVersion = properties.getProperty("oracle.net.ssl_version");
        }
        if (thinSslVersion == null) {
            thinSslVersion = getSystemProperty("oracle.net.ssl_version", null);
        }
        if (thinSslVersion == null) {
            thinSslVersion = null;
        }
        this.thinSslVersion = thinSslVersion;
        String thinSslCipherSuites = null;
        if (properties != null) {
            thinSslCipherSuites = properties.getProperty("oracle.net.ssl_cipher_suites");
        }
        if (thinSslCipherSuites == null) {
            thinSslCipherSuites = getSystemProperty("oracle.net.ssl_cipher_suites", null);
        }
        if (thinSslCipherSuites == null) {
            thinSslCipherSuites = null;
        }
        this.thinSslCipherSuites = thinSslCipherSuites;
        String thinJavaxNetSslKeystore = null;
        if (properties != null) {
            thinJavaxNetSslKeystore = properties.getProperty("javax.net.ssl.keyStore");
        }
        if (thinJavaxNetSslKeystore == null) {
            thinJavaxNetSslKeystore = getSystemProperty("javax.net.ssl.keyStore", null);
        }
        if (thinJavaxNetSslKeystore == null) {
            thinJavaxNetSslKeystore = null;
        }
        this.thinJavaxNetSslKeystore = thinJavaxNetSslKeystore;
        String thinJavaxNetSslKeystoretype = null;
        if (properties != null) {
            thinJavaxNetSslKeystoretype = properties.getProperty("javax.net.ssl.keyStoreType");
        }
        if (thinJavaxNetSslKeystoretype == null) {
            thinJavaxNetSslKeystoretype = getSystemProperty("javax.net.ssl.keyStoreType", null);
        }
        if (thinJavaxNetSslKeystoretype == null) {
            thinJavaxNetSslKeystoretype = null;
        }
        this.thinJavaxNetSslKeystoretype = thinJavaxNetSslKeystoretype;
        String thinJavaxNetSslKeystorepassword = null;
        if (properties != null) {
            thinJavaxNetSslKeystorepassword = properties.getProperty("javax.net.ssl.keyStorePassword");
        }
        if (thinJavaxNetSslKeystorepassword == null) {
            thinJavaxNetSslKeystorepassword = getSystemProperty("javax.net.ssl.keyStorePassword", null);
        }
        if (thinJavaxNetSslKeystorepassword == null) {
            thinJavaxNetSslKeystorepassword = null;
        }
        this.thinJavaxNetSslKeystorepassword = thinJavaxNetSslKeystorepassword;
        String thinJavaxNetSslTruststore = null;
        if (properties != null) {
            thinJavaxNetSslTruststore = properties.getProperty("javax.net.ssl.trustStore");
        }
        if (thinJavaxNetSslTruststore == null) {
            thinJavaxNetSslTruststore = getSystemProperty("javax.net.ssl.trustStore", null);
        }
        if (thinJavaxNetSslTruststore == null) {
            thinJavaxNetSslTruststore = null;
        }
        this.thinJavaxNetSslTruststore = thinJavaxNetSslTruststore;
        String thinJavaxNetSslTruststoretype = null;
        if (properties != null) {
            thinJavaxNetSslTruststoretype = properties.getProperty("javax.net.ssl.trustStoreType");
        }
        if (thinJavaxNetSslTruststoretype == null) {
            thinJavaxNetSslTruststoretype = getSystemProperty("javax.net.ssl.trustStoreType", null);
        }
        if (thinJavaxNetSslTruststoretype == null) {
            thinJavaxNetSslTruststoretype = null;
        }
        this.thinJavaxNetSslTruststoretype = thinJavaxNetSslTruststoretype;
        String thinJavaxNetSslTruststorepassword = null;
        if (properties != null) {
            thinJavaxNetSslTruststorepassword = properties.getProperty("javax.net.ssl.trustStorePassword");
        }
        if (thinJavaxNetSslTruststorepassword == null) {
            thinJavaxNetSslTruststorepassword = getSystemProperty("javax.net.ssl.trustStorePassword", null);
        }
        if (thinJavaxNetSslTruststorepassword == null) {
            thinJavaxNetSslTruststorepassword = null;
        }
        this.thinJavaxNetSslTruststorepassword = thinJavaxNetSslTruststorepassword;
        String thinSslKeymanagerfactoryAlgorithm = null;
        if (properties != null) {
            thinSslKeymanagerfactoryAlgorithm = properties.getProperty("ssl.keyManagerFactory.algorithm");
            if (thinSslKeymanagerfactoryAlgorithm == null) {
                thinSslKeymanagerfactoryAlgorithm = properties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm");
            }
        }
        if (thinSslKeymanagerfactoryAlgorithm == null) {
            thinSslKeymanagerfactoryAlgorithm = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", null);
        }
        if (thinSslKeymanagerfactoryAlgorithm == null) {
            thinSslKeymanagerfactoryAlgorithm = null;
        }
        this.thinSslKeymanagerfactoryAlgorithm = thinSslKeymanagerfactoryAlgorithm;
        String thinSslTrustmanagerfactoryAlgorithm = null;
        if (properties != null) {
            thinSslTrustmanagerfactoryAlgorithm = properties.getProperty("ssl.trustManagerFactory.algorithm");
            if (thinSslTrustmanagerfactoryAlgorithm == null) {
                thinSslTrustmanagerfactoryAlgorithm = properties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm");
            }
        }
        if (thinSslTrustmanagerfactoryAlgorithm == null) {
            thinSslTrustmanagerfactoryAlgorithm = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", null);
        }
        if (thinSslTrustmanagerfactoryAlgorithm == null) {
            thinSslTrustmanagerfactoryAlgorithm = null;
        }
        this.thinSslTrustmanagerfactoryAlgorithm = thinSslTrustmanagerfactoryAlgorithm;
        String thinNetOldsyntax = null;
        if (properties != null) {
            thinNetOldsyntax = properties.getProperty("oracle.net.oldSyntax");
        }
        if (thinNetOldsyntax == null) {
            thinNetOldsyntax = getSystemProperty("oracle.net.oldSyntax", null);
        }
        if (thinNetOldsyntax == null) {
            thinNetOldsyntax = null;
        }
        this.thinNetOldsyntax = thinNetOldsyntax;
        String property = null;
        if (properties != null) {
            property = properties.getProperty("java.naming.factory.initial");
        }
        if (property == null) {
            property = null;
        }
        this.thinNamingContextInitial = property;
        String property2 = null;
        if (properties != null) {
            property2 = properties.getProperty("java.naming.provider.url");
        }
        if (property2 == null) {
            property2 = null;
        }
        this.thinNamingProviderUrl = property2;
        String property3 = null;
        if (properties != null) {
            property3 = properties.getProperty("java.naming.security.authentication");
        }
        if (property3 == null) {
            property3 = null;
        }
        this.thinNamingSecurityAuthentication = property3;
        String property4 = null;
        if (properties != null) {
            property4 = properties.getProperty("java.naming.security.principal");
        }
        if (property4 == null) {
            property4 = null;
        }
        this.thinNamingSecurityPrincipal = property4;
        String property5 = null;
        if (properties != null) {
            property5 = properties.getProperty("java.naming.security.credentials");
        }
        if (property5 == null) {
            property5 = null;
        }
        this.thinNamingSecurityCredentials = property5;
        String walletLocation = null;
        if (properties != null) {
            walletLocation = properties.getProperty("oracle.net.wallet_location");
        }
        if (walletLocation == null) {
            walletLocation = getSystemProperty("oracle.net.wallet_location", null);
        }
        if (walletLocation == null) {
            walletLocation = null;
        }
        this.walletLocation = walletLocation;
        String walletPassword = null;
        if (properties != null) {
            walletPassword = properties.getProperty("oracle.net.wallet_password");
        }
        if (walletPassword == null) {
            walletPassword = getSystemProperty("oracle.net.wallet_password", null);
        }
        if (walletPassword == null) {
            walletPassword = null;
        }
        this.walletPassword = walletPassword;
        String proxyClientName = null;
        if (properties != null) {
            proxyClientName = properties.getProperty("oracle.jdbc.proxyClientName");
        }
        if (proxyClientName == null) {
            proxyClientName = getSystemProperty("oracle.jdbc.proxyClientName", null);
        }
        if (proxyClientName == null) {
            proxyClientName = null;
        }
        this.proxyClientName = proxyClientName;
        String s12 = null;
        if (properties != null) {
            s12 = properties.getProperty("oracle.jdbc.useNio");
        }
        if (s12 == null) {
            s12 = getSystemProperty("oracle.jdbc.useNio", null);
        }
        if (s12 == null) {
            s12 = "false";
        }
        this.useNio = (s12 != null && s12.equalsIgnoreCase("true"));
        String ociDriverCharset = null;
        if (properties != null) {
            ociDriverCharset = properties.getProperty("JDBCDriverCharSetId");
            if (ociDriverCharset == null) {
                ociDriverCharset = properties.getProperty("oracle.jdbc.JDBCDriverCharSetId");
            }
        }
        if (ociDriverCharset == null) {
            ociDriverCharset = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", null);
        }
        if (ociDriverCharset == null) {
            ociDriverCharset = null;
        }
        this.ociDriverCharset = ociDriverCharset;
        String editionName = null;
        if (properties != null) {
            editionName = properties.getProperty("oracle.jdbc.editionName");
        }
        if (editionName == null) {
            editionName = getSystemProperty("oracle.jdbc.editionName", null);
        }
        if (editionName == null) {
            editionName = null;
        }
        this.editionName = editionName;
        String logonCap = null;
        if (properties != null) {
            logonCap = properties.getProperty("oracle.jdbc.thinLogonCapability");
        }
        if (logonCap == null) {
            logonCap = getSystemProperty("oracle.jdbc.thinLogonCapability", null);
        }
        if (logonCap == null) {
            logonCap = "o5";
        }
        this.logonCap = logonCap;
        String internalLogon = null;
        if (properties != null) {
            internalLogon = properties.getProperty("internal_logon");
            if (internalLogon == null) {
                internalLogon = properties.getProperty("oracle.jdbc.internal_logon");
            }
        }
        if (internalLogon == null) {
            internalLogon = getSystemProperty("oracle.jdbc.internal_logon", null);
        }
        if (internalLogon == null) {
            internalLogon = null;
        }
        this.internalLogon = internalLogon;
        String s13 = null;
        if (properties != null) {
            s13 = properties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
        }
        if (s13 == null) {
            s13 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", null);
        }
        if (s13 == null) {
            s13 = "false";
        }
        this.createDescriptorUseCurrentSchemaForSchemaName = (s13 != null && s13.equalsIgnoreCase("true"));
        String s14 = null;
        if (properties != null) {
            s14 = properties.getProperty("OCISvcCtxHandle");
            if (s14 == null) {
                s14 = properties.getProperty("oracle.jdbc.OCISvcCtxHandle");
            }
        }
        if (s14 == null) {
            s14 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", null);
        }
        if (s14 == null) {
            s14 = "0";
        }
        try {
            this.ociSvcCtxHandle = Long.parseLong(s14);
        }
        catch (NumberFormatException ex2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        String s15 = null;
        if (properties != null) {
            s15 = properties.getProperty("OCIEnvHandle");
            if (s15 == null) {
                s15 = properties.getProperty("oracle.jdbc.OCIEnvHandle");
            }
        }
        if (s15 == null) {
            s15 = getSystemProperty("oracle.jdbc.OCIEnvHandle", null);
        }
        if (s15 == null) {
            s15 = "0";
        }
        try {
            this.ociEnvHandle = Long.parseLong(s15);
        }
        catch (NumberFormatException ex3) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        String s16 = null;
        if (properties != null) {
            s16 = properties.getProperty("OCIErrHandle");
            if (s16 == null) {
                s16 = properties.getProperty("oracle.jdbc.OCIErrHandle");
            }
        }
        if (s16 == null) {
            s16 = getSystemProperty("oracle.jdbc.OCIErrHandle", null);
        }
        if (s16 == null) {
            s16 = "0";
        }
        try {
            this.ociErrHandle = Long.parseLong(s16);
        }
        catch (NumberFormatException ex4) {
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        String s17 = null;
        if (properties != null) {
            s17 = properties.getProperty("prelim_auth");
            if (s17 == null) {
                s17 = properties.getProperty("oracle.jdbc.prelim_auth");
            }
        }
        if (s17 == null) {
            s17 = getSystemProperty("oracle.jdbc.prelim_auth", null);
        }
        if (s17 == null) {
            s17 = "false";
        }
        this.prelimAuth = (s17 != null && s17.equalsIgnoreCase("true"));
        String s18 = null;
        if (properties != null) {
            s18 = properties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
        }
        if (s18 == null) {
            s18 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", null);
        }
        if (s18 == null) {
            s18 = "false";
        }
        this.nlsLangBackdoor = (s18 != null && s18.equalsIgnoreCase("true"));
        String setNewPassword = null;
        if (properties != null) {
            setNewPassword = properties.getProperty("OCINewPassword");
            if (setNewPassword == null) {
                setNewPassword = properties.getProperty("oracle.jdbc.OCINewPassword");
            }
        }
        if (setNewPassword == null) {
            setNewPassword = getSystemProperty("oracle.jdbc.OCINewPassword", null);
        }
        if (setNewPassword == null) {
            setNewPassword = null;
        }
        this.setNewPassword = setNewPassword;
        String s19 = null;
        if (properties != null) {
            s19 = properties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
        }
        if (s19 == null) {
            s19 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", null);
        }
        if (s19 == null) {
            s19 = "false";
        }
        this.spawnNewThreadToCancel = (s19 != null && s19.equalsIgnoreCase("true"));
        String s20 = null;
        if (properties != null) {
            s20 = properties.getProperty("defaultExecuteBatch");
            if (s20 == null) {
                s20 = properties.getProperty("oracle.jdbc.defaultExecuteBatch");
            }
        }
        if (s20 == null) {
            s20 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", null);
        }
        if (s20 == null) {
            s20 = "1";
        }
        try {
            this.defaultExecuteBatch = Integer.parseInt(s20);
        }
        catch (NumberFormatException ex5) {
            final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
            sqlException5.fillInStackTrace();
            throw sqlException5;
        }
        String s21 = null;
        if (properties != null) {
            s21 = properties.getProperty("defaultRowPrefetch");
            if (s21 == null) {
                s21 = properties.getProperty("oracle.jdbc.defaultRowPrefetch");
            }
        }
        if (s21 == null) {
            s21 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", null);
        }
        if (s21 == null) {
            s21 = "10";
        }
        try {
            this.defaultRowPrefetch = Integer.parseInt(s21);
        }
        catch (NumberFormatException ex6) {
            final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
            sqlException6.fillInStackTrace();
            throw sqlException6;
        }
        String s22 = null;
        if (properties != null) {
            s22 = properties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
        }
        if (s22 == null) {
            s22 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", null);
        }
        if (s22 == null) {
            s22 = "4000";
        }
        try {
            this.defaultLobPrefetchSize = Integer.parseInt(s22);
        }
        catch (NumberFormatException ex7) {
            final SQLException sqlException7 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
            sqlException7.fillInStackTrace();
            throw sqlException7;
        }
        String s23 = null;
        if (properties != null) {
            s23 = properties.getProperty("oracle.jdbc.enableDataInLocator");
        }
        if (s23 == null) {
            s23 = getSystemProperty("oracle.jdbc.enableDataInLocator", null);
        }
        if (s23 == null) {
            s23 = "true";
        }
        this.enableDataInLocator = (s23 != null && s23.equalsIgnoreCase("true"));
        String s24 = null;
        if (properties != null) {
            s24 = properties.getProperty("oracle.jdbc.enableReadDataInLocator");
        }
        if (s24 == null) {
            s24 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", null);
        }
        if (s24 == null) {
            s24 = "true";
        }
        this.enableReadDataInLocator = (s24 != null && s24.equalsIgnoreCase("true"));
        String s25 = null;
        if (properties != null) {
            s25 = properties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
        }
        if (s25 == null) {
            s25 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", null);
        }
        if (s25 == null) {
            s25 = "false";
        }
        this.overrideEnableReadDataInLocator = (s25 != null && s25.equalsIgnoreCase("true"));
        String s26 = null;
        if (properties != null) {
            s26 = properties.getProperty("remarksReporting");
            if (s26 == null) {
                s26 = properties.getProperty("oracle.jdbc.remarksReporting");
            }
        }
        if (s26 == null) {
            s26 = getSystemProperty("oracle.jdbc.remarksReporting", null);
        }
        if (s26 == null) {
            s26 = "false";
        }
        this.reportRemarks = (s26 != null && s26.equalsIgnoreCase("true"));
        String s27 = null;
        if (properties != null) {
            s27 = properties.getProperty("includeSynonyms");
            if (s27 == null) {
                s27 = properties.getProperty("oracle.jdbc.includeSynonyms");
            }
        }
        if (s27 == null) {
            s27 = getSystemProperty("oracle.jdbc.includeSynonyms", null);
        }
        if (s27 == null) {
            s27 = "false";
        }
        this.includeSynonyms = (s27 != null && s27.equalsIgnoreCase("true"));
        String s28 = null;
        if (properties != null) {
            s28 = properties.getProperty("restrictGetTables");
            if (s28 == null) {
                s28 = properties.getProperty("oracle.jdbc.restrictGetTables");
            }
        }
        if (s28 == null) {
            s28 = getSystemProperty("oracle.jdbc.restrictGetTables", null);
        }
        if (s28 == null) {
            s28 = "false";
        }
        this.restrictGettables = (s28 != null && s28.equalsIgnoreCase("true"));
        String s29 = null;
        if (properties != null) {
            s29 = properties.getProperty("AccumulateBatchResult");
            if (s29 == null) {
                s29 = properties.getProperty("oracle.jdbc.AccumulateBatchResult");
            }
        }
        if (s29 == null) {
            s29 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", null);
        }
        if (s29 == null) {
            s29 = "true";
        }
        this.accumulateBatchResult = (s29 != null && s29.equalsIgnoreCase("true"));
        String s30 = null;
        if (properties != null) {
            s30 = properties.getProperty("useFetchSizeWithLongColumn");
            if (s30 == null) {
                s30 = properties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn");
            }
        }
        if (s30 == null) {
            s30 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", null);
        }
        if (s30 == null) {
            s30 = "false";
        }
        this.useFetchSizeWithLongColumn = (s30 != null && s30.equalsIgnoreCase("true"));
        String s31 = null;
        if (properties != null) {
            s31 = properties.getProperty("processEscapes");
            if (s31 == null) {
                s31 = properties.getProperty("oracle.jdbc.processEscapes");
            }
        }
        if (s31 == null) {
            s31 = getSystemProperty("oracle.jdbc.processEscapes", null);
        }
        if (s31 == null) {
            s31 = "true";
        }
        this.processEscapes = (s31 != null && s31.equalsIgnoreCase("true"));
        String s32 = null;
        if (properties != null) {
            s32 = properties.getProperty("fixedString");
            if (s32 == null) {
                s32 = properties.getProperty("oracle.jdbc.fixedString");
            }
        }
        if (s32 == null) {
            s32 = getSystemProperty("oracle.jdbc.fixedString", null);
        }
        if (s32 == null) {
            s32 = "false";
        }
        this.fixedString = (s32 != null && s32.equalsIgnoreCase("true"));
        String s33 = null;
        if (properties != null) {
            s33 = properties.getProperty("defaultNChar");
            if (s33 == null) {
                s33 = properties.getProperty("oracle.jdbc.defaultNChar");
            }
        }
        if (s33 == null) {
            s33 = getSystemProperty("oracle.jdbc.defaultNChar", null);
        }
        if (s33 == null) {
            s33 = "false";
        }
        this.defaultnchar = (s33 != null && s33.equalsIgnoreCase("true"));
        String s34 = null;
        if (properties != null) {
            s34 = properties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
        }
        if (s34 == null) {
            s34 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", null);
        }
        if (s34 == null) {
            s34 = "false";
        }
        this.permitTimestampDateMismatch = (s34 != null && s34.equalsIgnoreCase("true"));
        String resourceManagerId = null;
        if (properties != null) {
            resourceManagerId = properties.getProperty("RessourceManagerId");
            if (resourceManagerId == null) {
                resourceManagerId = properties.getProperty("oracle.jdbc.RessourceManagerId");
            }
        }
        if (resourceManagerId == null) {
            resourceManagerId = getSystemProperty("oracle.jdbc.RessourceManagerId", null);
        }
        if (resourceManagerId == null) {
            resourceManagerId = "0000";
        }
        this.resourceManagerId = resourceManagerId;
        String s35 = null;
        if (properties != null) {
            s35 = properties.getProperty("disableDefineColumnType");
            if (s35 == null) {
                s35 = properties.getProperty("oracle.jdbc.disableDefineColumnType");
            }
        }
        if (s35 == null) {
            s35 = getSystemProperty("oracle.jdbc.disableDefineColumnType", null);
        }
        if (s35 == null) {
            s35 = "false";
        }
        this.disableDefinecolumntype = (s35 != null && s35.equalsIgnoreCase("true"));
        String s36 = null;
        if (properties != null) {
            s36 = properties.getProperty("oracle.jdbc.convertNcharLiterals");
        }
        if (s36 == null) {
            s36 = getSystemProperty("oracle.jdbc.convertNcharLiterals", null);
        }
        if (s36 == null) {
            s36 = "false";
        }
        this.convertNcharLiterals = (s36 != null && s36.equalsIgnoreCase("true"));
        String s37 = null;
        if (properties != null) {
            s37 = properties.getProperty("oracle.jdbc.J2EE13Compliant");
        }
        if (s37 == null) {
            s37 = getSystemProperty("oracle.jdbc.J2EE13Compliant", null);
        }
        if (s37 == null) {
            s37 = "false";
        }
        this.j2ee13Compliant = (s37 != null && s37.equalsIgnoreCase("true"));
        String s38 = null;
        if (properties != null) {
            s38 = properties.getProperty("oracle.jdbc.mapDateToTimestamp");
        }
        if (s38 == null) {
            s38 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", null);
        }
        if (s38 == null) {
            s38 = "true";
        }
        this.mapDateToTimestamp = (s38 != null && s38.equalsIgnoreCase("true"));
        String s39 = null;
        if (properties != null) {
            s39 = properties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
        }
        if (s39 == null) {
            s39 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", null);
        }
        if (s39 == null) {
            s39 = "false";
        }
        this.useThreadLocalBufferCache = (s39 != null && s39.equalsIgnoreCase("true"));
        String driverNameAttribute = null;
        if (properties != null) {
            driverNameAttribute = properties.getProperty("oracle.jdbc.driverNameAttribute");
        }
        if (driverNameAttribute == null) {
            driverNameAttribute = getSystemProperty("oracle.jdbc.driverNameAttribute", null);
        }
        if (driverNameAttribute == null) {
            driverNameAttribute = null;
        }
        this.driverNameAttribute = driverNameAttribute;
        String s40 = null;
        if (properties != null) {
            s40 = properties.getProperty("oracle.jdbc.maxCachedBufferSize");
        }
        if (s40 == null) {
            s40 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", null);
        }
        if (s40 == null) {
            s40 = "30";
        }
        try {
            this.maxCachedBufferSize = Integer.parseInt(s40);
        }
        catch (NumberFormatException ex8) {
            final SQLException sqlException8 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
            sqlException8.fillInStackTrace();
            throw sqlException8;
        }
        String s41 = null;
        if (properties != null) {
            s41 = properties.getProperty("oracle.jdbc.implicitStatementCacheSize");
        }
        if (s41 == null) {
            s41 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", null);
        }
        if (s41 == null) {
            s41 = "0";
        }
        try {
            this.implicitStatementCacheSize = Integer.parseInt(s41);
        }
        catch (NumberFormatException ex9) {
            final SQLException sqlException9 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
            sqlException9.fillInStackTrace();
            throw sqlException9;
        }
        String s42 = null;
        if (properties != null) {
            s42 = properties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
        }
        if (s42 == null) {
            s42 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", null);
        }
        if (s42 == null) {
            s42 = "false";
        }
        this.lobStreamPosStandardCompliant = (s42 != null && s42.equalsIgnoreCase("true"));
        String s43 = null;
        if (properties != null) {
            s43 = properties.getProperty("oracle.jdbc.getObjectReturnsXMLType");
        }
        if (s43 == null) {
            s43 = getSystemProperty("oracle.jdbc.getObjectReturnsXMLType", null);
        }
        if (s43 == null) {
            s43 = "false";
        }
        this.getObjectReturnsXmlType = (s43 != null && s43.equalsIgnoreCase("true"));
        String s44 = null;
        if (properties != null) {
            s44 = properties.getProperty("oracle.jdbc.strictASCIIConversion");
        }
        if (s44 == null) {
            s44 = getSystemProperty("oracle.jdbc.strictASCIIConversion", null);
        }
        if (s44 == null) {
            s44 = "false";
        }
        this.isStrictAsciiConversion = (s44 != null && s44.equalsIgnoreCase("true"));
        String s45 = null;
        if (properties != null) {
            s45 = properties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
        }
        if (s45 == null) {
            s45 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", null);
        }
        if (s45 == null) {
            s45 = "false";
        }
        this.thinForceDnsLoadBalancing = (s45 != null && s45.equalsIgnoreCase("true"));
        String s46 = null;
        if (properties != null) {
            s46 = properties.getProperty("oracle.jdbc.commitOption");
        }
        if (s46 == null) {
            s46 = getSystemProperty("oracle.jdbc.commitOption", null);
        }
        if (s46 != null) {
            this.commitOption = 0;
            final String[] split = s46.split(",");
            if (split != null && split.length > 0) {
                for (final String s47 : split) {
                    if (s47.trim() != "") {
                        this.commitOption |= CommitOption.valueOf(s47.trim()).getCode();
                    }
                }
            }
        }
        this.includeSynonyms = parseConnectionProperty_boolean(properties, "synonyms", (byte)3, this.includeSynonyms);
        this.reportRemarks = parseConnectionProperty_boolean(properties, "remarks", (byte)3, this.reportRemarks);
        this.defaultRowPrefetch = parseConnectionProperty_int(properties, "prefetch", (byte)3, this.defaultRowPrefetch);
        this.defaultRowPrefetch = parseConnectionProperty_int(properties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);
        this.defaultExecuteBatch = parseConnectionProperty_int(properties, "batch", (byte)3, this.defaultExecuteBatch);
        this.defaultExecuteBatch = parseConnectionProperty_int(properties, "executeBatch", (byte)3, this.defaultExecuteBatch);
        this.proxyClientName = parseConnectionProperty_String(properties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);
        if (this.defaultRowPrefetch <= 0) {
            this.defaultRowPrefetch = Integer.parseInt("10");
        }
        if (this.defaultExecuteBatch <= 0) {
            this.defaultExecuteBatch = Integer.parseInt("1");
        }
        if (this.defaultLobPrefetchSize < -1) {
            final SQLException sqlException10 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 267);
            sqlException10.fillInStackTrace();
            throw sqlException10;
        }
        if (this.streamChunkSize > 0) {
            this.streamChunkSize = Math.max(4096, this.streamChunkSize);
        }
        else {
            this.streamChunkSize = Integer.parseInt("16384");
        }
        if (this.thinVsessionOsuser == null) {
            this.thinVsessionOsuser = getSystemProperty("user.name", null);
            if (this.thinVsessionOsuser == null) {
                this.thinVsessionOsuser = "jdbcuser";
            }
        }
        if (this.thinNetConnectTimeout == PhysicalConnection.CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT) {
            final int loginTimeout = DriverManager.getLoginTimeout();
            if (loginTimeout != 0) {
                this.thinNetConnectTimeout = "" + loginTimeout * 1000;
            }
        }
        this.url = url;
        final Hashtable url2 = parseUrl(this.url, this.walletLocation, this.walletPassword);
        if (this.userName == PhysicalConnection.CONNECTION_PROPERTY_USER_NAME_DEFAULT) {
            this.userName = url2.get("user");
        }
        final String[] array2 = { null };
        final String[] array3 = { null };
        this.userName = parseLoginOption(this.userName, properties, array2, array3);
        if (array2[0] != null) {
            this.internalLogon = array2[0];
        }
        if (array3[0] != null) {
            this.proxyClientName = array3[0];
        }
        String property6 = properties.getProperty("password", PhysicalConnection.CONNECTION_PROPERTY_PASSWORD_DEFAULT);
        if (property6 == PhysicalConnection.CONNECTION_PROPERTY_PASSWORD_DEFAULT) {
            property6 = url2.get("password");
        }
        this.initializePassword(property6);
        if (this.database == PhysicalConnection.CONNECTION_PROPERTY_DATABASE_DEFAULT) {
            this.database = properties.getProperty("server", PhysicalConnection.CONNECTION_PROPERTY_DATABASE_DEFAULT);
        }
        if (this.database == PhysicalConnection.CONNECTION_PROPERTY_DATABASE_DEFAULT) {
            this.database = url2.get("database");
        }
        this.protocol = url2.get("protocol");
        if (this.protocol == null) {
            final SQLException sqlException11 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
            sqlException11.fillInStackTrace();
            throw sqlException11;
        }
        if (this.protocol.equals("oci8") || this.protocol.equals("oci")) {
            this.database = this.translateConnStr(this.database);
        }
        if (properties.getProperty("is_connection_pooling") == "true" && this.database == null) {
            this.database = "";
        }
        if (this.userName != null && !this.userName.startsWith("\"")) {
            final char[] charArray = this.userName.toCharArray();
            for (int j = 0; j < charArray.length; ++j) {
                charArray[j] = Character.toUpperCase(charArray[j]);
            }
            this.userName = String.copyValueOf(charArray);
        }
        this.xaWantsError = false;
        this.usingXA = false;
        this.readOCIConnectionPoolProperties(properties);
        this.validateConnectionProperties();
    }
    
    private void readOCIConnectionPoolProperties(final Properties properties) throws SQLException {
        this.ociConnectionPoolMinLimit = parseConnectionProperty_int(properties, "connpool_min_limit", (byte)1, 0);
        this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(properties, "connpool_max_limit", (byte)1, 0);
        this.ociConnectionPoolIncrement = parseConnectionProperty_int(properties, "connpool_increment", (byte)1, 0);
        this.ociConnectionPoolTimeout = parseConnectionProperty_int(properties, "connpool_timeout", (byte)1, 0);
        this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(properties, "connpool_nowait", (byte)1, false);
        this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(properties, "transactions_distributed", (byte)1, false);
        this.ociConnectionPoolLogonMode = parseConnectionProperty_String(properties, "connection_pool", (byte)1, null);
        this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(properties, "is_connection_pooling", (byte)1, false);
        this.ociConnectionPoolObject = parseConnectionProperty_Object(properties, "connpool_object", null);
        this.ociConnectionPoolConnID = parseConnectionProperty_Object(properties, "connection_id", null);
        this.ociConnectionPoolProxyType = parseConnectionProperty_String(properties, "proxytype", (byte)1, null);
        this.ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(properties, "proxy_num_roles", 0);
        this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(properties, "proxy_roles", null);
        this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(properties, "proxy_user_name", (byte)1, null);
        this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(properties, "proxy_password", (byte)1, null);
        this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(properties, "proxy_distinguished_name", (byte)1, null);
        this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(properties, "proxy_certificate", null);
    }
    
    void validateConnectionProperties() throws SQLException {
        if (this.driverNameAttribute != null && !PhysicalConnection.driverNameAttributePattern.matcher(this.driverNameAttribute).matches()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 257);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    private static final Object parseConnectionProperty_Object(final Properties properties, final String key, final Object o) throws SQLException {
        Object o2 = o;
        if (properties != null) {
            final Object value = properties.get(key);
            if (value != null) {
                o2 = value;
            }
        }
        return o2;
    }
    
    private static final String parseConnectionProperty_String(final Properties properties, final String str, final byte b, final String s) throws SQLException {
        String s2 = null;
        if ((b == 1 || b == 3) && properties != null) {
            s2 = properties.getProperty(str);
            if (s2 == null && !str.startsWith("oracle.") && !str.startsWith("java.") && !str.startsWith("javax.")) {
                s2 = properties.getProperty("oracle.jdbc." + str);
            }
        }
        if (s2 == null && (b == 2 || b == 3)) {
            if (str.startsWith("oracle.") || str.startsWith("java.") || str.startsWith("javax.")) {
                s2 = getSystemProperty(str, null);
            }
            else {
                s2 = getSystemProperty("oracle.jdbc." + str, null);
            }
        }
        if (s2 == null) {
            s2 = s;
        }
        return s2;
    }
    
    private static final int parseConnectionProperty_int(final Properties properties, final String str, final byte b, final int n) throws SQLException {
        int int1 = n;
        final String connectionProperty_String = parseConnectionProperty_String(properties, str, b, null);
        if (connectionProperty_String != null) {
            try {
                int1 = Integer.parseInt(connectionProperty_String);
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(null, 190, "Property is '" + str + "' and value is '" + connectionProperty_String + "'");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return int1;
    }
    
    private static final long parseConnectionProperty_long(final Properties properties, final String str, final byte b, final long n) throws SQLException {
        long long1 = n;
        final String connectionProperty_String = parseConnectionProperty_String(properties, str, b, null);
        if (connectionProperty_String != null) {
            try {
                long1 = Long.parseLong(connectionProperty_String);
            }
            catch (NumberFormatException ex) {
                final SQLException sqlException = DatabaseError.createSqlException(null, 190, "Property is '" + str + "' and value is '" + connectionProperty_String + "'");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return long1;
    }
    
    private static final boolean parseConnectionProperty_boolean(final Properties properties, final String s, final byte b, final boolean b2) throws SQLException {
        boolean b3 = b2;
        final String connectionProperty_String = parseConnectionProperty_String(properties, s, b, null);
        if (connectionProperty_String != null) {
            if (connectionProperty_String.equalsIgnoreCase("false")) {
                b3 = false;
            }
            else if (connectionProperty_String.equalsIgnoreCase("true")) {
                b3 = true;
            }
        }
        return b3;
    }
    
    private static String parseLoginOption(String string, final Properties properties, final String[] array, final String[] array2) {
        if (string == null) {
            return null;
        }
        final int length = string.length();
        if (length == 0) {
            return null;
        }
        final int index = string.indexOf(91);
        if (index > 0) {
            final int index2 = string.indexOf(93);
            final String trim = string.substring(index + 1, index2).trim();
            if (trim.length() > 0) {
                array2[0] = trim;
            }
            string = string.substring(0, index) + string.substring(index2 + 1, length);
        }
        final String lowerCase = string.toLowerCase();
        int lastIndex = lowerCase.lastIndexOf(" as ");
        if (lastIndex == -1 || lastIndex < lowerCase.lastIndexOf("\"")) {
            return string;
        }
        final String substring = string.substring(0, lastIndex);
        for (lastIndex += 4; lastIndex < length && lowerCase.charAt(lastIndex) == ' '; ++lastIndex) {}
        if (lastIndex == length) {
            return string;
        }
        final String trim2 = lowerCase.substring(lastIndex).trim();
        if (trim2.length() > 0) {
            array[0] = trim2;
        }
        return substring;
    }
    
    private static final Hashtable parseUrl(final String s, final String s2, final String s3) throws SQLException {
        final Hashtable<String, String> hashtable = new Hashtable<String, String>(5);
        final int n = s.indexOf(58, s.indexOf(58) + 1) + 1;
        final int length = s.length();
        if (n == length) {
            return hashtable;
        }
        final int index = s.indexOf(58, n);
        if (index == -1) {
            return hashtable;
        }
        hashtable.put("protocol", s.substring(n, index));
        final int beginIndex = index + 1;
        int index2 = s.indexOf(47, beginIndex);
        int index3 = s.indexOf(64, beginIndex);
        if (index3 > beginIndex && beginIndex > n && index2 == -1) {
            final SQLException sqlException = DatabaseError.createSqlException(null, 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (index3 == -1) {
            index3 = length;
        }
        if (index2 == -1) {
            index2 = index3;
        }
        if (index2 < index3 && index2 != beginIndex && index3 != beginIndex) {
            hashtable.put("user", s.substring(beginIndex, index2));
            hashtable.put("password", s.substring(index2 + 1, index3));
        }
        if (index2 <= index3 && (index2 == beginIndex || index3 == beginIndex) && index3 < length) {
            final String[] secretStoreCredentials = getSecretStoreCredentials(s.substring(index3 + 1), s2, s3);
            if (secretStoreCredentials[0] != null || secretStoreCredentials[1] != null) {
                hashtable.put("user", secretStoreCredentials[0]);
                hashtable.put("password", secretStoreCredentials[1]);
            }
        }
        if (index3 < length) {
            hashtable.put("database", s.substring(index3 + 1));
        }
        return hashtable;
    }
    
    private static final String[] getSecretStoreCredentials(final String s, String string, final String s2) throws SQLException {
        final String[] array = { null, null };
        if (string != null) {
            try {
                if (string.startsWith("(")) {
                    string = "file:" + CustomSSLSocketFactory.processWalletLocation(string);
                }
                final OracleWallet oracleWallet = new OracleWallet();
                if (oracleWallet.exists(string)) {
                    char[] charArray = null;
                    if (s2 != null) {
                        charArray = s2.toCharArray();
                    }
                    oracleWallet.open(string, charArray);
                    final OracleSecretStore secretStore = oracleWallet.getSecretStore();
                    if (secretStore.containsAlias("oracle.security.client.default_username")) {
                        array[0] = new String(secretStore.getSecret("oracle.security.client.default_username"));
                    }
                    if (secretStore.containsAlias("oracle.security.client.default_password")) {
                        array[1] = new String(secretStore.getSecret("oracle.security.client.default_password"));
                    }
                    final Enumeration internalAliases = oracleWallet.getSecretStore().internalAliases();
                    while (internalAliases.hasMoreElements()) {
                        final String s3 = internalAliases.nextElement();
                        if (s3.startsWith("oracle.security.client.connect_string") && s.equalsIgnoreCase(new String(secretStore.getSecret(s3)))) {
                            final String substring = s3.substring("oracle.security.client.connect_string".length());
                            array[0] = new String(secretStore.getSecret("oracle.security.client.username" + substring));
                            array[1] = new String(secretStore.getSecret("oracle.security.client.password" + substring));
                            break;
                        }
                    }
                }
            }
            catch (NoClassDefFoundError noClassDefFoundError) {
                final SQLException sqlException = DatabaseError.createSqlException(null, 167, noClassDefFoundError);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            catch (Exception ex) {
                if (ex instanceof RuntimeException) {
                    throw (RuntimeException)ex;
                }
                final SQLException sqlException2 = DatabaseError.createSqlException(null, 168, ex);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
        return array;
    }
    
    private String translateConnStr(final String s) throws SQLException {
        int index = 0;
        if (s == null || s.equals("")) {
            return s;
        }
        if (s.indexOf(41) != -1) {
            return s;
        }
        boolean b = false;
        if (s.indexOf(91) != -1) {
            index = s.indexOf(93);
            if (index == -1) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67, s);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            b = true;
        }
        final int index2 = s.indexOf(58, index);
        if (index2 == -1) {
            return s;
        }
        final int index3 = s.indexOf(58, index2 + 1);
        if (index3 == -1) {
            return s;
        }
        if (s.indexOf(58, index3 + 1) != -1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67, s);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        String str;
        if (b) {
            str = s.substring(1, index2 - 1);
        }
        else {
            str = s.substring(0, index2);
        }
        return "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + str + ")(PORT=" + s.substring(index2 + 1, index3) + "))(CONNECT_DATA=(SID=" + s.substring(index3 + 1, s.length()) + ")))";
    }
    
    protected static String getSystemPropertyPollInterval() {
        return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
    }
    
    static String getSystemPropertyFastConnectionFailover(final String s) {
        return getSystemProperty("oracle.jdbc.FastConnectionFailover", s);
    }
    
    static String getSystemPropertyJserverVersion() {
        return getSystemProperty("oracle.jserver.version", null);
    }
    
    private static String getSystemProperty(final String s, final String s2) {
        if (s != null) {
            final String[] array = { s2 };
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
                @Override
                public Object run() {
                    array[0] = System.getProperty(s, s2);
                    return null;
                }
            });
            return array[0];
        }
        return s2;
    }
    
    abstract void initializePassword(final String p0) throws SQLException;
    
    @Override
    public Properties getProperties() {
        final Properties properties = new Properties();
        try {
            Class value = null;
            Class value2 = null;
            try {
                value = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
                value2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
            }
            catch (ClassNotFoundException ex) {}
            final Field[] declaredFields = value2.getDeclaredFields();
            for (int i = 0; i < declaredFields.length; ++i) {
                if (!Modifier.isStatic(declaredFields[i].getModifiers())) {
                    final String string = "CONNECTION_PROPERTY_" + propertyVariableName(declaredFields[i].getName());
                    Field field;
                    try {
                        field = value.getField(string);
                    }
                    catch (NoSuchFieldException ex2) {
                        continue;
                    }
                    if (!string.matches(".*PASSWORD.*")) {
                        final String key = (String)field.get(null);
                        final String name = declaredFields[i].getType().getName();
                        if (name.equals("boolean")) {
                            if (declaredFields[i].getBoolean(this)) {
                                properties.setProperty(key, "true");
                            }
                            else {
                                properties.setProperty(key, "false");
                            }
                        }
                        else if (name.equals("int")) {
                            properties.setProperty(key, Integer.toString(declaredFields[i].getInt(this)));
                        }
                        else if (name.equals("long")) {
                            properties.setProperty(key, Long.toString(declaredFields[i].getLong(this)));
                        }
                        else if (name.equals("java.lang.String")) {
                            final String value3 = (String)declaredFields[i].get(this);
                            if (value3 != null) {
                                properties.setProperty(key, value3);
                            }
                        }
                    }
                }
            }
        }
        catch (IllegalAccessException ex3) {}
        return properties;
    }
    
    @Override
    @Deprecated
    public synchronized Connection _getPC() {
        return null;
    }
    
    @Override
    public synchronized oracle.jdbc.internal.OracleConnection getPhysicalConnection() {
        return this;
    }
    
    @Override
    public synchronized boolean isLogicalConnection() {
        return false;
    }
    
    void initialize(final Hashtable hashtable, final Map map, final Map javaObjectMap) throws SQLException {
        this.clearStatementMetaData = false;
        if (hashtable != null) {
            this.descriptorCacheStack[this.dci] = hashtable;
        }
        else {
            this.descriptorCacheStack[this.dci] = new Hashtable(10);
        }
        this.map = map;
        if (javaObjectMap != null) {
            this.javaObjectMap = javaObjectMap;
        }
        else {
            this.javaObjectMap = new Hashtable(10);
        }
        this.lifecycle = 1;
        this.txnLevel = 2;
        this.clientIdSet = false;
    }
    
    void initializeSetCHARCharSetObjs() {
        this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
        this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
    }
    
    OracleTimeout getTimeout() throws SQLException {
        if (this.timeout == null) {
            this.timeout = OracleTimeout.newTimeout(this.url);
        }
        return this.timeout;
    }
    
    @Override
    public synchronized Statement createStatement() throws SQLException {
        return this.createStatement(-1, -1);
    }
    
    @Override
    public synchronized Statement createStatement(final int n, final int n2) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleStatementWrapper(this.driverExtension.allocateStatement(this, n, n2));
    }
    
    @Override
    public synchronized PreparedStatement prepareStatement(final String s) throws SQLException {
        return this.prepareStatement(s, -1, -1);
    }
    
    @Override
    @Deprecated
    public synchronized PreparedStatement prepareStatementWithKey(final String s) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (s == null) {
            return null;
        }
        if (!this.isStatementCacheInitialized()) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 95);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        oracle.jdbc.internal.OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchExplicitCache(s);
        if (oraclePreparedStatement != null) {
            oraclePreparedStatement = new OraclePreparedStatementWrapper(oraclePreparedStatement);
        }
        return oraclePreparedStatement;
    }
    
    @Override
    public synchronized PreparedStatement prepareStatement(final String s, final int n, final int n2) throws SQLException {
        if (s == null || s.length() == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 104);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.lifecycle != 1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        OraclePreparedStatement allocatePreparedStatement = null;
        if (this.statementCache != null) {
            allocatePreparedStatement = (OraclePreparedStatement)this.statementCache.searchImplicitCache(s, 1, (n != -1 || n2 != -1) ? ResultSetUtil.getRsetTypeCode(n, n2) : 1);
        }
        if (allocatePreparedStatement == null) {
            allocatePreparedStatement = this.driverExtension.allocatePreparedStatement(this, s, n, n2);
        }
        return new OraclePreparedStatementWrapper(allocatePreparedStatement);
    }
    
    @Override
    public synchronized CallableStatement prepareCall(final String s) throws SQLException {
        return this.prepareCall(s, -1, -1);
    }
    
    @Override
    public synchronized CallableStatement prepareCall(final String s, final int n, final int n2) throws SQLException {
        if (s == null || s.length() == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 104);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.lifecycle != 1) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        OracleCallableStatement allocateCallableStatement = null;
        if (this.statementCache != null) {
            allocateCallableStatement = (OracleCallableStatement)this.statementCache.searchImplicitCache(s, 2, (n != -1 || n2 != -1) ? ResultSetUtil.getRsetTypeCode(n, n2) : 1);
        }
        if (allocateCallableStatement == null) {
            allocateCallableStatement = this.driverExtension.allocateCallableStatement(this, s, n, n2);
        }
        return new OracleCallableStatementWrapper(allocateCallableStatement);
    }
    
    @Override
    public synchronized CallableStatement prepareCallWithKey(final String s) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (s == null) {
            return null;
        }
        if (!this.isStatementCacheInitialized()) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 95);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        oracle.jdbc.internal.OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchExplicitCache(s);
        if (oracleCallableStatement != null) {
            oracleCallableStatement = new OracleCallableStatementWrapper(oracleCallableStatement);
        }
        return oracleCallableStatement;
    }
    
    @Override
    public String nativeSQL(final String s) throws SQLException {
        if (this.sqlObj == null) {
            this.sqlObj = new OracleSql(this.conversion);
        }
        this.sqlObj.initialize(s);
        return this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
    }
    
    @Override
    public synchronized void setAutoCommit(final boolean autocommit) throws SQLException {
        if (autocommit) {
            this.disallowGlobalTxnMode(116);
        }
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.needLine();
        this.doSetAutoCommit(autocommit);
        this.autocommit = autocommit;
    }
    
    @Override
    public boolean getAutoCommit() throws SQLException {
        return this.autocommit;
    }
    
    @Override
    public void cancel() throws SQLException {
        OracleStatement oracleStatement = this.statements;
        if (this.lifecycle != 1 && this.lifecycle != 16) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        boolean b = false;
        while (oracleStatement != null) {
            try {
                if (oracleStatement.doCancel()) {
                    b = true;
                }
            }
            catch (SQLException ex) {}
            oracleStatement = oracleStatement.next;
        }
        if (!b) {
            this.cancelOperationOnServer();
        }
    }
    
    @Override
    public void commit(final EnumSet<CommitOption> set) throws SQLException {
        int n = 0;
        if (set != null) {
            if ((set.contains(CommitOption.WRITEBATCH) && set.contains(CommitOption.WRITEIMMED)) || (set.contains(CommitOption.WAIT) && set.contains(CommitOption.NOWAIT))) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 191);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final Iterator<CommitOption> iterator = set.iterator();
            while (iterator.hasNext()) {
                n |= iterator.next().getCode();
            }
        }
        this.commit(n);
    }
    
    synchronized void commit(final int n) throws SQLException {
        this.disallowGlobalTxnMode(114);
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        for (OracleStatement oracleStatement = this.statements; oracleStatement != null; oracleStatement = oracleStatement.next) {
            if (!oracleStatement.closed) {
                oracleStatement.sendBatch();
            }
        }
        if (((n & CommitOption.WRITEBATCH.getCode()) != 0x0 && (n & CommitOption.WRITEIMMED.getCode()) != 0x0) || ((n & CommitOption.WAIT.getCode()) != 0x0 && (n & CommitOption.NOWAIT.getCode()) != 0x0)) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 191);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.registerHeartbeat();
        this.needLine();
        this.doCommit(n);
    }
    
    @Override
    public void commit() throws SQLException {
        this.commit(this.commitOption);
    }
    
    @Override
    public synchronized void rollback() throws SQLException {
        this.disallowGlobalTxnMode(115);
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        for (OracleStatement oracleStatement = this.statements; oracleStatement != null; oracleStatement = oracleStatement.next) {
            if (oracleStatement.isOracleBatchStyle()) {
                oracleStatement.clearBatch();
            }
        }
        this.registerHeartbeat();
        this.needLine();
        this.doRollback();
    }
    
    @Override
    public synchronized void close() throws SQLException {
        if (this.lifecycle == 2 || this.lifecycle == 4) {
            return;
        }
        if (this.lifecycle == 1) {
            this.lifecycle = 2;
        }
        try {
            if (this.closeCallback != null) {
                this.closeCallback.beforeClose(this, this.privateData);
            }
            this.closeStatementCache();
            this.closeStatements(false);
            this.needLineUnchecked();
            if (this.isProxy) {
                this.close(1);
            }
            if (this.timeZoneTab != null) {
                this.timeZoneTab.freeInstance();
            }
            this.logoff();
            this.cleanup();
            if (this.timeout != null) {
                this.timeout.close();
            }
            if (this.closeCallback != null) {
                this.closeCallback.afterClose(this.privateData);
            }
        }
        finally {
            this.lifecycle = 4;
            this.isUsable = false;
        }
    }
    
    @Override
    public String getDataIntegrityAlgorithmName() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public String getEncryptionAlgorithmName() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public String getAuthenticationAdaptorName() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void closeInternal(final boolean b) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void cleanupAndClose(final boolean b) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    void cleanupAndClose() throws SQLException {
        if (this.lifecycle != 1) {
            return;
        }
        this.lifecycle = 16;
        this.cancel();
    }
    
    synchronized void closeLogicalConnection() throws SQLException {
        if (this.lifecycle == 1 || this.lifecycle == 16 || this.lifecycle == 2) {
            this.savepointStatement = null;
            this.closeStatements(true);
            if (this.clientIdSet) {
                this.clearClientIdentifier(this.clientId);
            }
            this.logicalConnectionAttached = null;
            this.lifecycle = 1;
        }
    }
    
    @Override
    public synchronized void close(final Properties properties) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized void close(final int n) throws SQLException {
        if ((n & 0x1000) != 0x0) {
            this.close();
            return;
        }
        if ((n & 0x1) != 0x0 && this.isProxy) {
            this.purgeStatementCache();
            this.closeStatements(false);
            this.descriptorCacheStack[this.dci--] = null;
            this.closeProxySession();
            this.isProxy = false;
        }
    }
    
    @Override
    public void abort() throws SQLException {
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            securityManager.checkPermission(PhysicalConnection.CALL_ABORT_PERMISSION);
        }
        if (this.lifecycle == 4 || this.lifecycle == 8) {
            return;
        }
        this.lifecycle = 8;
        this.doAbort();
    }
    
    abstract void doAbort() throws SQLException;
    
    void closeProxySession() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public Properties getServerSessionInfo() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public synchronized void applyConnectionAttributes(final Properties properties) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized Properties getConnectionAttributes() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized void setAbandonedTimeoutEnabled(final boolean b) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized void registerConnectionCacheCallback(final OracleConnectionCacheCallback oracleConnectionCacheCallback, final Object o, final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public Object getConnectionCacheCallbackPrivObj() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getConnectionCacheCallbackFlag() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized void setConnectionReleasePriority(final int n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getConnectionReleasePriority() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized boolean isClosed() throws SQLException {
        return this.lifecycle != 1;
    }
    
    @Override
    public synchronized boolean isProxySession() {
        return this.isProxy;
    }
    
    @Override
    public synchronized void openProxySession(final int n, final Properties properties) throws SQLException {
        if (this.isProxy) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 149);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.purgeStatementCache();
        this.closeStatements(false);
        final String property = properties.getProperty("PROXY_USER_NAME");
        final String property2 = properties.getProperty("PROXY_USER_PASSWORD");
        final String property3 = properties.getProperty("PROXY_DISTINGUISHED_NAME");
        final Object value = properties.get("PROXY_CERTIFICATE");
        Label_0223: {
            if (n == 1) {
                if (property == null && property2 == null) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 150);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
            }
            else {
                if (n != 2) {
                    if (n == 3) {
                        if (value == null) {
                            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 150);
                            sqlException3.fillInStackTrace();
                            throw sqlException3;
                        }
                        try {
                            final byte[] array = (byte[])value;
                            break Label_0223;
                        }
                        catch (ClassCastException ex) {
                            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 150);
                            sqlException4.fillInStackTrace();
                            throw sqlException4;
                        }
                    }
                    final SQLException sqlException5 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 150);
                    sqlException5.fillInStackTrace();
                    throw sqlException5;
                }
                if (property3 == null) {
                    final SQLException sqlException6 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 150);
                    sqlException6.fillInStackTrace();
                    throw sqlException6;
                }
            }
        }
        this.doProxySession(n, properties);
        ++this.dci;
    }
    
    void doProxySession(final int n, final Properties properties) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    void cleanup() {
        this.fdo = null;
        this.conversion = null;
        this.statements = null;
        this.descriptorCacheStack[this.dci] = null;
        this.map = null;
        this.javaObjectMap = null;
        this.statementHoldingLine = null;
        this.sqlObj = null;
        this.isProxy = false;
    }
    
    @Override
    public synchronized DatabaseMetaData getMetaData() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.databaseMetaData == null) {
            this.databaseMetaData = new oracle.jdbc.driver.OracleDatabaseMetaData(this);
        }
        return this.databaseMetaData;
    }
    
    @Override
    public void setReadOnly(final boolean readOnly) throws SQLException {
        this.readOnly = readOnly;
    }
    
    @Override
    public boolean isReadOnly() throws SQLException {
        return this.readOnly;
    }
    
    @Override
    public void setCatalog(final String s) throws SQLException {
    }
    
    @Override
    public String getCatalog() throws SQLException {
        return null;
    }
    
    @Override
    public synchronized void setTransactionIsolation(final int n) throws SQLException {
        if (this.txnLevel == n) {
            return;
        }
        final Statement statement = this.createStatement();
        try {
            switch (n) {
                case 2: {
                    statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
                    this.txnLevel = 2;
                    break;
                }
                case 8: {
                    statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
                    this.txnLevel = 8;
                    break;
                }
                default: {
                    final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 30);
                    sqlException.fillInStackTrace();
                    throw sqlException;
                }
            }
        }
        finally {
            statement.close();
        }
    }
    
    @Override
    public int getTransactionIsolation() throws SQLException {
        return this.txnLevel;
    }
    
    @Override
    public synchronized void setAutoClose(final boolean b) throws SQLException {
        if (!b) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 31);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public boolean getAutoClose() throws SQLException {
        return true;
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return this.sqlWarning;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        this.sqlWarning = null;
    }
    
    public void setWarnings(final SQLWarning sqlWarning) {
        this.sqlWarning = sqlWarning;
    }
    
    @Override
    public void setDefaultRowPrefetch(final int defaultRowPrefetch) throws SQLException {
        if (defaultRowPrefetch <= 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 20);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.defaultRowPrefetch = defaultRowPrefetch;
    }
    
    @Override
    public int getDefaultRowPrefetch() {
        return this.defaultRowPrefetch;
    }
    
    @Override
    public boolean getTimestamptzInGmt() {
        return this.timestamptzInGmt;
    }
    
    @Override
    public synchronized void setDefaultExecuteBatch(final int defaultExecuteBatch) throws SQLException {
        if (defaultExecuteBatch <= 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 42);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.defaultExecuteBatch = defaultExecuteBatch;
    }
    
    @Override
    public synchronized int getDefaultExecuteBatch() {
        return this.defaultExecuteBatch;
    }
    
    @Override
    public synchronized void setRemarksReporting(final boolean reportRemarks) {
        this.reportRemarks = reportRemarks;
    }
    
    @Override
    public synchronized boolean getRemarksReporting() {
        return this.reportRemarks;
    }
    
    @Override
    public void setIncludeSynonyms(final boolean includeSynonyms) {
        this.includeSynonyms = includeSynonyms;
    }
    
    @Override
    public synchronized String[] getEndToEndMetrics() throws SQLException {
        Object o;
        if (this.endToEndValues == null) {
            o = null;
        }
        else {
            o = new String[this.endToEndValues.length];
            System.arraycopy(this.endToEndValues, 0, o, 0, this.endToEndValues.length);
        }
        return (String[])o;
    }
    
    @Override
    public short getEndToEndECIDSequenceNumber() throws SQLException {
        return this.endToEndECIDSequenceNumber;
    }
    
    @Override
    public synchronized void setEndToEndMetrics(final String[] array, final short n) throws SQLException {
        final String[] array2 = new String[array.length];
        System.arraycopy(array, 0, array2, 0, array.length);
        this.setEndToEndMetricsInternal(array2, n);
    }
    
    void setEndToEndMetricsInternal(final String[] endToEndValues, final short endToEndECIDSequenceNumber) throws SQLException {
        if (endToEndValues != this.endToEndValues) {
            if (endToEndValues.length != 4) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 156);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            for (int i = 0; i < 4; ++i) {
                final String s = endToEndValues[i];
                if (s != null && s.length() > this.endToEndMaxLength[i]) {
                    final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 159, s);
                    sqlException2.fillInStackTrace();
                    throw sqlException2;
                }
            }
            if (this.endToEndValues != null) {
                for (int j = 0; j < 4; ++j) {
                    final String s2 = endToEndValues[j];
                    if ((s2 == null && this.endToEndValues[j] != null) || (s2 != null && !s2.equals(this.endToEndValues[j]))) {
                        this.endToEndHasChanged[j] = true;
                        this.endToEndAnyChanged = true;
                    }
                }
                final boolean[] endToEndHasChanged = this.endToEndHasChanged;
                final int n = 0;
                endToEndHasChanged[n] |= this.endToEndHasChanged[3];
            }
            else {
                for (int k = 0; k < 4; ++k) {
                    this.endToEndHasChanged[k] = true;
                }
                this.endToEndAnyChanged = true;
            }
            this.endToEndValues = endToEndValues;
        }
        this.endToEndECIDSequenceNumber = endToEndECIDSequenceNumber;
    }
    
    void updateSystemContext() throws SQLException {
    }
    
    void resetSystemContext() {
    }
    
    void updateSystemContext11() throws SQLException {
    }
    
    @Override
    public boolean getIncludeSynonyms() {
        return this.includeSynonyms;
    }
    
    @Override
    public void setRestrictGetTables(final boolean restrictGettables) {
        this.restrictGettables = restrictGettables;
    }
    
    @Override
    public boolean getRestrictGetTables() {
        return this.restrictGettables;
    }
    
    @Override
    public void setDefaultFixedString(final boolean fixedString) {
        this.fixedString = fixedString;
    }
    
    public void setDefaultNChar(final boolean defaultnchar) {
        this.defaultnchar = defaultnchar;
    }
    
    @Override
    public boolean getDefaultFixedString() {
        return this.fixedString;
    }
    
    public int getNlsRatio() {
        return 1;
    }
    
    @Override
    public int getC2SNlsRatio() {
        return 1;
    }
    
    synchronized void addStatement(final OracleStatement statements) {
        if (statements.next != null) {
            throw new Error("add_statement called twice on " + statements);
        }
        statements.next = this.statements;
        if (this.statements != null) {
            this.statements.prev = statements;
        }
        this.statements = statements;
    }
    
    synchronized void removeStatement(final OracleStatement oracleStatement) {
        final OracleStatement prev = oracleStatement.prev;
        final OracleStatement next = oracleStatement.next;
        if (prev == null) {
            if (this.statements != oracleStatement) {
                return;
            }
            this.statements = next;
        }
        else {
            prev.next = next;
        }
        if (next != null) {
            next.prev = prev;
        }
        oracleStatement.next = null;
        oracleStatement.prev = null;
    }
    
    synchronized void closeStatements(final boolean b) throws SQLException {
        OracleStatement nextChild;
        for (OracleStatement statements = this.statements; statements != null; statements = nextChild) {
            nextChild = statements.nextChild;
            if (statements.serverCursor) {
                statements.close();
                this.removeStatement(statements);
            }
        }
        OracleStatement next;
        for (OracleStatement statements2 = this.statements; statements2 != null; statements2 = next) {
            next = statements2.next;
            if (b) {
                statements2.close();
            }
            else {
                statements2.hardClose();
            }
            this.removeStatement(statements2);
        }
    }
    
    final void purgeStatementCache() throws SQLException {
        if (this.isStatementCacheInitialized()) {
            this.statementCache.purgeImplicitCache();
            this.statementCache.purgeExplicitCache();
        }
    }
    
    final void closeStatementCache() throws SQLException {
        if (this.isStatementCacheInitialized()) {
            this.statementCache.close();
            this.statementCache = null;
            this.clearStatementMetaData = true;
        }
    }
    
    void needLine() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.needLineUnchecked();
    }
    
    synchronized void needLineUnchecked() throws SQLException {
        if (this.statementHoldingLine != null) {
            this.statementHoldingLine.freeLine();
        }
    }
    
    synchronized void holdLine(final oracle.jdbc.internal.OracleStatement oracleStatement) {
        this.holdLine((OracleStatement)oracleStatement);
    }
    
    synchronized void holdLine(final OracleStatement statementHoldingLine) {
        this.statementHoldingLine = statementHoldingLine;
    }
    
    synchronized void releaseLine() {
        this.releaseLineForCancel();
    }
    
    void releaseLineForCancel() {
        this.statementHoldingLine = null;
    }
    
    @Override
    public synchronized void startup(final String s, final int n) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public synchronized void startup(final DatabaseStartupMode databaseStartupMode) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (databaseStartupMode == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.needLine();
        this.doStartup(databaseStartupMode.getMode());
    }
    
    void doStartup(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public synchronized void shutdown(final DatabaseShutdownMode databaseShutdownMode) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (databaseShutdownMode == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.needLine();
        this.doShutdown(databaseShutdownMode.getMode());
    }
    
    void doShutdown(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public synchronized void archive(final int n, final int n2, final String s) throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public synchronized void registerSQLType(final String s, final String s2) throws SQLException {
        if (s == null || s2 == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        try {
            this.registerSQLType(s, Class.forName(s2));
        }
        catch (ClassNotFoundException ex) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Class not found: " + s2);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
    }
    
    @Override
    public synchronized void registerSQLType(final String s, final Class clazz) throws SQLException {
        if (s == null || clazz == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.map == null) {
            this.map = new Hashtable(10);
        }
        this.map.put(s, clazz);
        this.map.put(clazz.getName(), s);
    }
    
    @Override
    public synchronized String getSQLType(final Object o) throws SQLException {
        if (o != null && this.map != null) {
            return this.map.get(o.getClass().getName());
        }
        return null;
    }
    
    @Override
    public synchronized Object getJavaObject(final String s) throws SQLException {
        Object instance = null;
        try {
            if (s != null && this.map != null) {
                instance = this.map.get(s).newInstance();
            }
        }
        catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }
        catch (InstantiationException ex2) {
            ex2.printStackTrace();
        }
        return instance;
    }
    
    @Override
    public synchronized void putDescriptor(final String key, final Object value) throws SQLException {
        if (key != null && value != null) {
            if (this.descriptorCacheStack[this.dci] == null) {
                this.descriptorCacheStack[this.dci] = new Hashtable(10);
            }
            ((TypeDescriptor)value).fixupConnection(this);
            this.descriptorCacheStack[this.dci].put(key, value);
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized Object getDescriptor(final String s) {
        Object o = null;
        if (s != null) {
            if (this.descriptorCacheStack[this.dci] != null) {
                o = this.descriptorCacheStack[this.dci].get(s);
            }
            if (o == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
                o = this.descriptorCacheStack[0].get(s);
            }
        }
        return o;
    }
    
    @Deprecated
    public synchronized void removeDecriptor(final String s) {
        this.removeDescriptor(s);
    }
    
    @Override
    public synchronized void removeDescriptor(final String s) {
        if (s != null && this.descriptorCacheStack[this.dci] != null) {
            this.descriptorCacheStack[this.dci].remove(s);
        }
        if (s != null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
            this.descriptorCacheStack[0].remove(s);
        }
    }
    
    @Override
    public synchronized void removeAllDescriptor() {
        for (int i = 0; i <= this.dci; ++i) {
            if (this.descriptorCacheStack[i] != null) {
                this.descriptorCacheStack[i].clear();
            }
        }
    }
    
    @Override
    public int numberOfDescriptorCacheEntries() {
        int n = 0;
        for (int i = 0; i <= this.dci; ++i) {
            if (this.descriptorCacheStack[i] != null) {
                n += this.descriptorCacheStack[i].size();
            }
        }
        return n;
    }
    
    @Override
    public Enumeration descriptorCacheKeys() {
        if (this.dci == 0) {
            if (this.descriptorCacheStack[this.dci] != null) {
                return this.descriptorCacheStack[this.dci].keys();
            }
            return null;
        }
        else {
            if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] != null) {
                return this.descriptorCacheStack[1].keys();
            }
            if (this.descriptorCacheStack[1] == null && this.descriptorCacheStack[0] != null) {
                return this.descriptorCacheStack[0].keys();
            }
            if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] == null) {
                return null;
            }
            final Vector vector = new Vector(this.descriptorCacheStack[1].keySet());
            vector.addAll(this.descriptorCacheStack[0].keySet());
            return vector.elements();
        }
    }
    
    @Override
    public synchronized void putDescriptor(final byte[] array, final Object value) throws SQLException {
        if (array != null && value != null) {
            if (this.descriptorCacheStack[this.dci] == null) {
                this.descriptorCacheStack[this.dci] = new Hashtable(10);
            }
            this.descriptorCacheStack[this.dci].put(new ByteArrayKey(array), value);
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized Object getDescriptor(final byte[] array) {
        Object o = null;
        if (array != null) {
            final ByteArrayKey byteArrayKey = new ByteArrayKey(array);
            if (this.descriptorCacheStack[this.dci] != null) {
                o = this.descriptorCacheStack[this.dci].get(byteArrayKey);
            }
            if (o == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
                o = this.descriptorCacheStack[0].get(byteArrayKey);
            }
        }
        return o;
    }
    
    public synchronized void removeDecriptor(final byte[] array) {
        if (array != null) {
            final ByteArrayKey byteArrayKey = new ByteArrayKey(array);
            if (this.descriptorCacheStack[this.dci] != null) {
                this.descriptorCacheStack[this.dci].remove(byteArrayKey);
            }
            if (this.dci == 1 && this.descriptorCacheStack[0] != null) {
                this.descriptorCacheStack[0].remove(byteArrayKey);
            }
        }
    }
    
    @Override
    public short getJdbcCsId() throws SQLException {
        if (this.conversion == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 65);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.conversion.getClientCharSet();
    }
    
    @Override
    public short getDbCsId() throws SQLException {
        if (this.conversion == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 65);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.conversion.getServerCharSetId();
    }
    
    public short getNCsId() throws SQLException {
        if (this.conversion == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 65);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.conversion.getNCharSetId();
    }
    
    @Override
    public short getStructAttrCsId() throws SQLException {
        return this.getDbCsId();
    }
    
    @Override
    public short getStructAttrNCsId() throws SQLException {
        return this.getNCsId();
    }
    
    @Override
    public synchronized Map getTypeMap() {
        if (this.map == null) {
            this.map = new Hashtable(10);
        }
        return this.map;
    }
    
    @Override
    public synchronized void setTypeMap(final Map map) {
        this.map = map;
    }
    
    @Override
    public synchronized void setUsingXAFlag(final boolean usingXA) {
        this.usingXA = usingXA;
    }
    
    @Override
    public synchronized boolean getUsingXAFlag() {
        return this.usingXA;
    }
    
    @Override
    public synchronized void setXAErrorFlag(final boolean xaWantsError) {
        this.xaWantsError = xaWantsError;
    }
    
    @Override
    public synchronized boolean getXAErrorFlag() {
        return this.xaWantsError;
    }
    
    String getPropertyFromDatabase(final String s) throws SQLException {
        String string = null;
        Statement statement = null;
        ResultSet executeQuery = null;
        try {
            statement = this.createStatement();
            statement.setFetchSize(1);
            executeQuery = statement.executeQuery(s);
            if (executeQuery.next()) {
                string = executeQuery.getString(1);
            }
        }
        finally {
            if (executeQuery != null) {
                executeQuery.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return string;
    }
    
    @Override
    public synchronized String getUserName() throws SQLException {
        if (this.userName == null) {
            this.userName = this.getPropertyFromDatabase("SELECT USER FROM DUAL");
        }
        return this.userName;
    }
    
    @Override
    public String getCurrentSchema() throws SQLException {
        return this.getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
    }
    
    @Override
    public String getDefaultSchemaNameForNamedTypes() throws SQLException {
        String s;
        if (this.createDescriptorUseCurrentSchemaForSchemaName) {
            s = this.getCurrentSchema();
        }
        else {
            s = this.getUserName();
        }
        return s;
    }
    
    @Override
    public synchronized void setStartTime(final long n) throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized long getStartTime() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    void registerHeartbeat() throws SQLException {
        if (this.logicalConnectionAttached != null) {
            this.logicalConnectionAttached.registerHeartbeat();
        }
    }
    
    @Override
    public int getHeartbeatNoChangeCount() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 152);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized byte[] getFDO(final boolean b) throws SQLException {
        if (this.fdo == null && b) {
            CallableStatement prepareCall = null;
            try {
                prepareCall = this.prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
                prepareCall.registerOutParameter(1, 2);
                prepareCall.registerOutParameter(2, -4);
                prepareCall.execute();
                this.fdo = prepareCall.getBytes(2);
            }
            finally {
                if (prepareCall != null) {
                    prepareCall.close();
                }
            }
        }
        return this.fdo;
    }
    
    @Override
    public synchronized void setFDO(final byte[] fdo) throws SQLException {
        this.fdo = fdo;
    }
    
    @Override
    public synchronized boolean getBigEndian() throws SQLException {
        if (this.bigEndian == null) {
            final int[] javaUnsignedBytes = Util.toJavaUnsignedBytes(this.getFDO(true));
            int n = (byte)(javaUnsignedBytes[6 + javaUnsignedBytes[5] + javaUnsignedBytes[6] + 5] & 0x10);
            if (n < 0) {
                n += 256;
            }
            if (n > 0) {
                this.bigEndian = Boolean.TRUE;
            }
            else {
                this.bigEndian = Boolean.FALSE;
            }
        }
        return this.bigEndian;
    }
    
    @Override
    public void setHoldability(final int n) throws SQLException {
    }
    
    @Override
    public int getHoldability() throws SQLException {
        return 1;
    }
    
    @Override
    public synchronized Savepoint setSavepoint() throws SQLException {
        return this.oracleSetSavepoint();
    }
    
    @Override
    public synchronized Savepoint setSavepoint(final String s) throws SQLException {
        return this.oracleSetSavepoint(s);
    }
    
    @Override
    public synchronized void rollback(final Savepoint savepoint) throws SQLException {
        this.disallowGlobalTxnMode(122);
        if (this.autocommit) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 121);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.savepointStatement == null) {
            this.savepointStatement = this.createStatement();
        }
        String str;
        try {
            str = savepoint.getSavepointName();
        }
        catch (SQLException ex) {
            str = "ORACLE_SVPT_" + savepoint.getSavepointId();
        }
        this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
    }
    
    @Override
    public synchronized void releaseSavepoint(final Savepoint savepoint) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public Statement createStatement(final int n, final int n2, final int n3) throws SQLException {
        return this.createStatement(n, n2);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int n, final int n2, final int n3) throws SQLException {
        return this.prepareStatement(s, n, n2);
    }
    
    @Override
    public CallableStatement prepareCall(final String s, final int n, final int n2, final int n3) throws SQLException {
        return this.prepareCall(s, n, n2);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int n) throws SQLException {
        final AutoKeyInfo autoKeyInfo = new AutoKeyInfo(s);
        if (n == 2 || !autoKeyInfo.isInsertSqlStmt()) {
            return this.prepareStatement(s);
        }
        if (n != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final oracle.jdbc.OraclePreparedStatement oraclePreparedStatement = (oracle.jdbc.OraclePreparedStatement)this.prepareStatement(autoKeyInfo.getNewSql());
        final OraclePreparedStatement oraclePreparedStatement2 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
        oraclePreparedStatement2.isAutoGeneratedKey = true;
        oraclePreparedStatement2.autoKeyInfo = autoKeyInfo;
        oraclePreparedStatement2.registerReturnParamsForAutoKey();
        return oraclePreparedStatement;
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int[] array) throws SQLException {
        final AutoKeyInfo autoKeyInfo = new AutoKeyInfo(s, array);
        if (!autoKeyInfo.isInsertSqlStmt()) {
            return this.prepareStatement(s);
        }
        if (array == null || array.length == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.doDescribeTable(autoKeyInfo);
        final oracle.jdbc.OraclePreparedStatement oraclePreparedStatement = (oracle.jdbc.OraclePreparedStatement)this.prepareStatement(autoKeyInfo.getNewSql());
        final OraclePreparedStatement oraclePreparedStatement2 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
        oraclePreparedStatement2.isAutoGeneratedKey = true;
        oraclePreparedStatement2.autoKeyInfo = autoKeyInfo;
        oraclePreparedStatement2.registerReturnParamsForAutoKey();
        return oraclePreparedStatement;
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final String[] array) throws SQLException {
        final AutoKeyInfo autoKeyInfo = new AutoKeyInfo(s, array);
        if (!autoKeyInfo.isInsertSqlStmt()) {
            return this.prepareStatement(s);
        }
        if (array == null || array.length == 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.doDescribeTable(autoKeyInfo);
        final oracle.jdbc.OraclePreparedStatement oraclePreparedStatement = (oracle.jdbc.OraclePreparedStatement)this.prepareStatement(autoKeyInfo.getNewSql());
        final OraclePreparedStatement oraclePreparedStatement2 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
        oraclePreparedStatement2.isAutoGeneratedKey = true;
        oraclePreparedStatement2.autoKeyInfo = autoKeyInfo;
        oraclePreparedStatement2.registerReturnParamsForAutoKey();
        return oraclePreparedStatement;
    }
    
    @Override
    public synchronized OracleSavepoint oracleSetSavepoint() throws SQLException {
        this.disallowGlobalTxnMode(117);
        if (this.autocommit) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 120);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.savepointStatement == null) {
            this.savepointStatement = this.createStatement();
        }
        final oracle.jdbc.driver.OracleSavepoint oracleSavepoint = new oracle.jdbc.driver.OracleSavepoint();
        this.savepointStatement.executeUpdate("SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId());
        return oracleSavepoint;
    }
    
    @Override
    public synchronized OracleSavepoint oracleSetSavepoint(final String s) throws SQLException {
        this.disallowGlobalTxnMode(117);
        if (this.autocommit) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 120);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.savepointStatement == null) {
            this.savepointStatement = this.createStatement();
        }
        final oracle.jdbc.driver.OracleSavepoint oracleSavepoint = new oracle.jdbc.driver.OracleSavepoint(s);
        this.savepointStatement.executeUpdate("SAVEPOINT " + oracleSavepoint.getSavepointName());
        return oracleSavepoint;
    }
    
    @Override
    public synchronized void oracleRollback(final OracleSavepoint oracleSavepoint) throws SQLException {
        this.disallowGlobalTxnMode(115);
        if (this.autocommit) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 121);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.savepointStatement == null) {
            this.savepointStatement = this.createStatement();
        }
        String str;
        try {
            str = oracleSavepoint.getSavepointName();
        }
        catch (SQLException ex) {
            str = "ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
        }
        this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
    }
    
    @Override
    public synchronized void oracleReleaseSavepoint(final OracleSavepoint oracleSavepoint) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    void disallowGlobalTxnMode(final int n) throws SQLException {
        if (this.txnMode == 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), n);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public void setTxnMode(final int txnMode) {
        this.txnMode = txnMode;
    }
    
    @Override
    public int getTxnMode() {
        return this.txnMode;
    }
    
    @Override
    public synchronized Object getClientData(final Object key) {
        if (this.clientData == null) {
            return null;
        }
        return this.clientData.get(key);
    }
    
    @Override
    public synchronized Object setClientData(final Object key, final Object value) {
        if (this.clientData == null) {
            this.clientData = new Hashtable();
        }
        return this.clientData.put(key, value);
    }
    
    @Override
    public synchronized Object removeClientData(final Object key) {
        if (this.clientData == null) {
            return null;
        }
        return this.clientData.remove(key);
    }
    
    @Override
    public BlobDBAccess createBlobDBAccess() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public ClobDBAccess createClobDBAccess() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public BfileDBAccess createBfileDBAccess() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    public void printState() {
        try {
            this.getJdbcCsId();
            this.getDbCsId();
            this.getStructAttrCsId();
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public String getProtocolType() {
        return this.protocol;
    }
    
    @Override
    public String getURL() {
        return this.url;
    }
    
    @Override
    @Deprecated
    public synchronized void setStmtCacheSize(final int statementCacheSize) throws SQLException {
        this.setStatementCacheSize(statementCacheSize);
        this.setImplicitCachingEnabled(true);
        this.setExplicitCachingEnabled(true);
    }
    
    @Override
    @Deprecated
    public synchronized void setStmtCacheSize(final int statementCacheSize, final boolean clearStatementMetaData) throws SQLException {
        this.setStatementCacheSize(statementCacheSize);
        this.setImplicitCachingEnabled(true);
        this.setExplicitCachingEnabled(true);
        this.clearStatementMetaData = clearStatementMetaData;
    }
    
    @Override
    @Deprecated
    public synchronized int getStmtCacheSize() {
        int statementCacheSize = 0;
        try {
            statementCacheSize = this.getStatementCacheSize();
        }
        catch (SQLException ex) {}
        if (statementCacheSize == -1) {
            statementCacheSize = 0;
        }
        return statementCacheSize;
    }
    
    @Override
    public synchronized void setStatementCacheSize(final int n) throws SQLException {
        if (this.statementCache == null) {
            this.statementCache = new LRUStatementCache(n);
        }
        else {
            this.statementCache.resize(n);
        }
    }
    
    @Override
    public synchronized int getStatementCacheSize() throws SQLException {
        if (this.statementCache == null) {
            return -1;
        }
        return this.statementCache.getCacheSize();
    }
    
    @Override
    public synchronized void setImplicitCachingEnabled(final boolean implicitCachingEnabled) throws SQLException {
        if (this.statementCache == null) {
            this.statementCache = new LRUStatementCache(0);
        }
        this.statementCache.setImplicitCachingEnabled(implicitCachingEnabled);
    }
    
    @Override
    public synchronized boolean getImplicitCachingEnabled() throws SQLException {
        return this.statementCache != null && this.statementCache.getImplicitCachingEnabled();
    }
    
    @Override
    public synchronized void setExplicitCachingEnabled(final boolean explicitCachingEnabled) throws SQLException {
        if (this.statementCache == null) {
            this.statementCache = new LRUStatementCache(0);
        }
        this.statementCache.setExplicitCachingEnabled(explicitCachingEnabled);
    }
    
    @Override
    public synchronized boolean getExplicitCachingEnabled() throws SQLException {
        return this.statementCache != null && this.statementCache.getExplicitCachingEnabled();
    }
    
    @Override
    public synchronized void purgeImplicitCache() throws SQLException {
        if (this.statementCache != null) {
            this.statementCache.purgeImplicitCache();
        }
    }
    
    @Override
    public synchronized void purgeExplicitCache() throws SQLException {
        if (this.statementCache != null) {
            this.statementCache.purgeExplicitCache();
        }
    }
    
    @Override
    public synchronized PreparedStatement getStatementWithKey(final String s) throws SQLException {
        if (this.statementCache == null) {
            return null;
        }
        final OracleStatement searchExplicitCache = this.statementCache.searchExplicitCache(s);
        if (searchExplicitCache == null || searchExplicitCache.statementType == 1) {
            return (PreparedStatement)searchExplicitCache;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 125);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public synchronized CallableStatement getCallWithKey(final String s) throws SQLException {
        if (this.statementCache == null) {
            return null;
        }
        final OracleStatement searchExplicitCache = this.statementCache.searchExplicitCache(s);
        if (searchExplicitCache == null || searchExplicitCache.statementType == 2) {
            return (CallableStatement)searchExplicitCache;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 125);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public synchronized void cacheImplicitStatement(final OraclePreparedStatement oraclePreparedStatement, final String s, final int n, final int n2) throws SQLException {
        if (this.statementCache == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 95);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.statementCache.addToImplicitCache(oraclePreparedStatement, s, n, n2);
    }
    
    public synchronized void cacheExplicitStatement(final OraclePreparedStatement oraclePreparedStatement, final String s) throws SQLException {
        if (this.statementCache == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 95);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.statementCache.addToExplicitCache(oraclePreparedStatement, s);
    }
    
    @Override
    public synchronized boolean isStatementCacheInitialized() {
        return this.statementCache != null && this.statementCache.getCacheSize() != 0;
    }
    
    private BufferCacheStore getBufferCacheStore() {
        if (this.useThreadLocalBufferCache) {
            if (PhysicalConnection.threadLocalBufferCacheStore == null) {
                BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
                PhysicalConnection.threadLocalBufferCacheStore = new ThreadLocal<BufferCacheStore>() {
                    @Override
                    protected BufferCacheStore initialValue() {
                        return new BufferCacheStore();
                    }
                };
            }
            return PhysicalConnection.threadLocalBufferCacheStore.get();
        }
        if (this.connectionBufferCacheStore == null) {
            this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
        }
        return this.connectionBufferCacheStore;
    }
    
    void cacheBuffer(final byte[] array) {
        if (array != null) {
            this.getBufferCacheStore().byteBufferCache.put(array);
        }
    }
    
    void cacheBuffer(final char[] array) {
        if (array != null) {
            this.getBufferCacheStore().charBufferCache.put(array);
        }
    }
    
    public void cacheBufferSync(final char[] array) {
        synchronized (this) {
            this.cacheBuffer(array);
        }
    }
    
    byte[] getByteBuffer(final int n) {
        return this.getBufferCacheStore().byteBufferCache.get(Byte.TYPE, n);
    }
    
    char[] getCharBuffer(final int n) {
        return this.getBufferCacheStore().charBufferCache.get(Character.TYPE, n);
    }
    
    public char[] getCharBufferSync(final int n) {
        synchronized (this) {
            return this.getCharBuffer(n);
        }
    }
    
    @Override
    public BufferCacheStatistics getByteBufferCacheStatistics() {
        return this.getBufferCacheStore().byteBufferCache.getStatistics();
    }
    
    @Override
    public BufferCacheStatistics getCharBufferCacheStatistics() {
        return this.getBufferCacheStore().charBufferCache.getStatistics();
    }
    
    @Override
    public synchronized void registerTAFCallback(final OracleOCIFailover oracleOCIFailover, final Object o) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public String getDatabaseProductVersion() throws SQLException {
        if (this.databaseProductVersion == "") {
            this.needLine();
            this.databaseProductVersion = this.doGetDatabaseProductVersion();
        }
        return this.databaseProductVersion;
    }
    
    public synchronized boolean getReportRemarks() {
        return this.reportRemarks;
    }
    
    @Override
    public short getVersionNumber() throws SQLException {
        if (this.versionNumber == -1) {
            synchronized (this) {
                if (this.versionNumber == -1) {
                    this.needLine();
                    this.versionNumber = this.doGetVersionNumber();
                }
            }
        }
        return this.versionNumber;
    }
    
    public synchronized void registerCloseCallback(final OracleCloseCallback closeCallback, final Object privateData) {
        this.closeCallback = closeCallback;
        this.privateData = privateData;
    }
    
    @Override
    public void setCreateStatementAsRefCursor(final boolean b) {
    }
    
    @Override
    public boolean getCreateStatementAsRefCursor() {
        return false;
    }
    
    @Override
    public int pingDatabase() throws SQLException {
        if (this.lifecycle != 1) {
            return -1;
        }
        return this.doPingDatabase();
    }
    
    @Override
    @Deprecated
    public int pingDatabase(final int n) throws SQLException {
        if (this.lifecycle != 1) {
            return -1;
        }
        if (n == 0) {
            return this.pingDatabase();
        }
        try {
            this.pingResult = -2;
            final Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
                    }
                    catch (Throwable t) {}
                }
            });
            thread.start();
            thread.join(n * 1000);
            return this.pingResult;
        }
        catch (InterruptedException ex) {
            return -3;
        }
    }
    
    int doPingDatabase() throws SQLException {
        Statement statement = null;
        try {
            statement = this.createStatement();
            ((oracle.jdbc.OracleStatement)statement).defineColumnType(1, 12, 1);
            statement.executeQuery("SELECT 'x' FROM DUAL");
        }
        catch (SQLException ex) {
            return -1;
        }
        finally {
            if (statement != null) {
                statement.close();
            }
        }
        return 0;
    }
    
    @Override
    public synchronized Map getJavaObjectTypeMap() {
        return this.javaObjectMap;
    }
    
    @Override
    public synchronized void setJavaObjectTypeMap(final Map javaObjectMap) {
        this.javaObjectMap = javaObjectMap;
    }
    
    @Override
    @Deprecated
    public void clearClientIdentifier(final String s) throws SQLException {
        if (s != null && s.length() != 0) {
            final String[] endToEndMetrics = this.getEndToEndMetrics();
            if (endToEndMetrics != null && s.equals(endToEndMetrics[1])) {
                endToEndMetrics[1] = null;
                this.setEndToEndMetrics(endToEndMetrics, this.getEndToEndECIDSequenceNumber());
            }
        }
    }
    
    @Override
    @Deprecated
    public void setClientIdentifier(final String s) throws SQLException {
        String[] endToEndMetrics = this.getEndToEndMetrics();
        if (endToEndMetrics == null) {
            endToEndMetrics = new String[4];
        }
        endToEndMetrics[1] = s;
        this.setEndToEndMetrics(endToEndMetrics, this.getEndToEndECIDSequenceNumber());
    }
    
    @Override
    public void setSessionTimeZone(final String s) throws SQLException {
        Statement statement = null;
        try {
            statement = this.createStatement();
            statement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + s + "'");
            if (this.dbTzCalendar == null) {
                this.setDbTzCalendar(this.getDatabaseTimeZone());
            }
        }
        catch (SQLException ex) {
            throw ex;
        }
        finally {
            if (statement != null) {
                statement.close();
            }
        }
        this.sessionTimeZone = s;
    }
    
    @Override
    public String getDatabaseTimeZone() throws SQLException {
        if (this.databaseTimeZone == null) {
            this.databaseTimeZone = this.getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");
        }
        return this.databaseTimeZone;
    }
    
    @Override
    public String getSessionTimeZone() {
        return this.sessionTimeZone;
    }
    
    private static String to2DigitString(final int n) {
        String s;
        if (n < 10) {
            s = "0" + n;
        }
        else {
            s = "" + n;
        }
        return s;
    }
    
    public String tzToOffset(String id) {
        if (id == null) {
            return id;
        }
        final char char1 = id.charAt(0);
        if (char1 != '-' && char1 != '+') {
            final int offset = TimeZone.getTimeZone(id).getOffset(System.currentTimeMillis());
            if (offset != 0) {
                final int n = offset / 60000;
                final int n2 = n / 60;
                final int n3 = n - n2 * 60;
                if (offset > 0) {
                    id = "+" + to2DigitString(n2) + ":" + to2DigitString(n3);
                }
                else {
                    id = "-" + to2DigitString(-n2) + ":" + to2DigitString(-n3);
                }
            }
            else {
                id = "+00:00";
            }
        }
        return id;
    }
    
    @Override
    public String getSessionTimeZoneOffset() throws SQLException {
        String s = this.getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL");
        if (s != null) {
            s = this.tzToOffset(s.trim());
        }
        return s;
    }
    
    private void setDbTzCalendar(String string) {
        final char char1 = string.charAt(0);
        if (char1 == '-' || char1 == '+') {
            string = "GMT" + string;
        }
        this.dbTzCalendar = new GregorianCalendar(TimeZone.getTimeZone(string));
    }
    
    public Calendar getDbTzCalendar() throws SQLException {
        if (this.dbTzCalendar == null) {
            this.setDbTzCalendar(this.getDatabaseTimeZone());
        }
        return this.dbTzCalendar;
    }
    
    public void setAccumulateBatchResult(final boolean accumulateBatchResult) {
        this.accumulateBatchResult = accumulateBatchResult;
    }
    
    public boolean isAccumulateBatchResult() {
        return this.accumulateBatchResult;
    }
    
    public void setJ2EE13Compliant(final boolean j2ee13Compliant) {
        this.j2ee13Compliant = j2ee13Compliant;
    }
    
    public boolean getJ2EE13Compliant() {
        return this.j2ee13Compliant;
    }
    
    @Override
    public Class classForNameAndSchema(final String className, final String s) throws ClassNotFoundException {
        return Class.forName(className);
    }
    
    public Class safelyGetClassForName(final String className) throws ClassNotFoundException {
        return Class.forName(className);
    }
    
    @Override
    public int getHeapAllocSize() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public int getOCIEnvHeapAllocSize() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    public static OracleConnection unwrapCompletely(final oracle.jdbc.OracleConnection oracleConnection) {
        oracle.jdbc.OracleConnection unwrap;
        oracle.jdbc.OracleConnection oracleConnection2;
        for (oracleConnection2 = (unwrap = oracleConnection); unwrap != null; unwrap = oracleConnection2.unwrap()) {
            oracleConnection2 = unwrap;
        }
        return (OracleConnection)oracleConnection2;
    }
    
    @Override
    public void setWrapper(final oracle.jdbc.OracleConnection wrapper) {
        this.wrapper = wrapper;
    }
    
    @Override
    public oracle.jdbc.OracleConnection unwrap() {
        return null;
    }
    
    @Override
    public oracle.jdbc.OracleConnection getWrapper() {
        if (this.wrapper != null) {
            return this.wrapper;
        }
        return this;
    }
    
    static oracle.jdbc.internal.OracleConnection _physicalConnectionWithin(final Connection connection) {
        oracle.jdbc.internal.OracleConnection unwrapCompletely = null;
        if (connection != null) {
            unwrapCompletely = unwrapCompletely((oracle.jdbc.OracleConnection)connection);
        }
        return unwrapCompletely;
    }
    
    @Override
    public oracle.jdbc.internal.OracleConnection physicalConnectionWithin() {
        return this;
    }
    
    @Override
    public long getTdoCState(final String s, final String s2) throws SQLException {
        return 0L;
    }
    
    public void getOracleTypeADT(final OracleTypeADT oracleTypeADT) throws SQLException {
    }
    
    @Override
    public Datum toDatum(final CustomDatum customDatum) throws SQLException {
        return customDatum.toDatum(this);
    }
    
    @Override
    public short getNCharSet() {
        return this.conversion.getNCharSetId();
    }
    
    @Override
    public ResultSet newArrayDataResultSet(final Datum[] array, final long n, final int n2, final Map map) throws SQLException {
        return new ArrayDataResultSet(this, array, n, n2, map);
    }
    
    @Override
    public ResultSet newArrayDataResultSet(final ARRAY array, final long n, final int n2, final Map map) throws SQLException {
        return new ArrayDataResultSet(this, array, n, n2, map);
    }
    
    @Override
    public ResultSet newArrayLocatorResultSet(final ArrayDescriptor arrayDescriptor, final byte[] array, final long n, final int n2, final Map map) throws SQLException {
        return new ArrayLocatorResultSet(this, arrayDescriptor, array, n, n2, map);
    }
    
    @Override
    public ResultSetMetaData newStructMetaData(final StructDescriptor structDescriptor) throws SQLException {
        return new StructMetaData(structDescriptor);
    }
    
    @Override
    public int CHARBytesToJavaChars(final byte[] array, final int n, final char[] array2) throws SQLException {
        return this.conversion.CHARBytesToJavaChars(array, 0, array2, 0, new int[] { n }, array2.length);
    }
    
    @Override
    public int NCHARBytesToJavaChars(final byte[] array, final int n, final char[] array2) throws SQLException {
        return this.conversion.NCHARBytesToJavaChars(array, 0, array2, 0, new int[1], array2.length);
    }
    
    @Override
    public boolean IsNCharFixedWith() {
        return this.conversion.IsNCharFixedWith();
    }
    
    @Override
    public short getDriverCharSet() {
        return this.conversion.getClientCharSet();
    }
    
    @Override
    public int getMaxCharSize() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 58);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public int getMaxCharbyteSize() {
        return this.conversion.getMaxCharbyteSize();
    }
    
    @Override
    public int getMaxNCharbyteSize() {
        return this.conversion.getMaxNCharbyteSize();
    }
    
    @Override
    public boolean isCharSetMultibyte(final short n) {
        final DBConversion conversion = this.conversion;
        return DBConversion.isCharSetMultibyte(n);
    }
    
    @Override
    public int javaCharsToCHARBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.conversion.javaCharsToCHARBytes(array, n, array2);
    }
    
    @Override
    public int javaCharsToNCHARBytes(final char[] array, final int n, final byte[] array2) throws SQLException {
        return this.conversion.javaCharsToNCHARBytes(array, n, array2);
    }
    
    @Override
    public abstract void getPropertyForPooledConnection(final OraclePooledConnection p0) throws SQLException;
    
    final void getPropertyForPooledConnection(final OraclePooledConnection oraclePooledConnection, final String value) throws SQLException {
        final Hashtable<String, Properties> properties = new Hashtable<String, Properties>();
        properties.put("obj_type_map", (Properties)this.javaObjectMap);
        final Properties value2 = new Properties();
        value2.put("user", this.userName);
        value2.put("password", value);
        value2.put("connection_url", this.url);
        value2.put("connect_auto_commit", "" + this.autocommit);
        value2.put("trans_isolation", "" + this.txnLevel);
        if (this.getStatementCacheSize() != -1) {
            value2.put("stmt_cache_size", "" + this.getStatementCacheSize());
            value2.put("implicit_cache_enabled", "" + this.getImplicitCachingEnabled());
            value2.put("explict_cache_enabled", "" + this.getExplicitCachingEnabled());
        }
        value2.put("defaultExecuteBatch", "" + this.defaultExecuteBatch);
        value2.put("defaultRowPrefetch", "" + this.defaultRowPrefetch);
        value2.put("remarksReporting", "" + this.reportRemarks);
        value2.put("AccumulateBatchResult", "" + this.accumulateBatchResult);
        value2.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant);
        value2.put("processEscapes", "" + this.processEscapes);
        value2.put("restrictGetTables", "" + this.restrictGettables);
        value2.put("includeSynonyms", "" + this.includeSynonyms);
        value2.put("fixedString", "" + this.fixedString);
        properties.put("connection_properties", value2);
        oraclePooledConnection.setProperties(properties);
    }
    
    @Override
    public Properties getDBAccessProperties() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public Properties getOCIHandles() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    abstract void logon() throws SQLException;
    
    void logoff() throws SQLException {
    }
    
    abstract void open(final OracleStatement p0) throws SQLException;
    
    abstract void cancelOperationOnServer() throws SQLException;
    
    abstract void doSetAutoCommit(final boolean p0) throws SQLException;
    
    abstract void doCommit(final int p0) throws SQLException;
    
    abstract void doRollback() throws SQLException;
    
    abstract String doGetDatabaseProductVersion() throws SQLException;
    
    abstract short doGetVersionNumber() throws SQLException;
    
    int getDefaultStreamChunkSize() {
        return this.streamChunkSize;
    }
    
    abstract OracleStatement RefCursorBytesToStatement(final byte[] p0, final OracleStatement p1) throws SQLException;
    
    @Override
    public oracle.jdbc.internal.OracleStatement refCursorCursorToStatement(final int n) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public Connection getLogicalConnection(final OraclePooledConnection oraclePooledConnection, final boolean b) throws SQLException {
        if (this.logicalConnectionAttached != null || oraclePooledConnection.getPhysicalHandle() != this) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 143);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.logicalConnectionAttached = new LogicalConnection(oraclePooledConnection, this, b);
    }
    
    @Override
    public void getForm(final OracleTypeADT oracleTypeADT, final OracleTypeCLOB oracleTypeCLOB, final int n) throws SQLException {
    }
    
    @Override
    public CLOB createClob(final byte[] array) throws SQLException {
        return new CLOB(this, array);
    }
    
    @Override
    public CLOB createClobWithUnpickledBytes(final byte[] array) throws SQLException {
        return new CLOB(this, array, true);
    }
    
    @Override
    public CLOB createClob(final byte[] array, final short n) throws SQLException {
        if (n == 2) {
            return new NCLOB(this, array);
        }
        return new CLOB(this, array, n);
    }
    
    @Override
    public BLOB createBlob(final byte[] array) throws SQLException {
        return new BLOB(this, array);
    }
    
    @Override
    public BLOB createBlobWithUnpickledBytes(final byte[] array) throws SQLException {
        return new BLOB(this, array, true);
    }
    
    @Override
    public BFILE createBfile(final byte[] array) throws SQLException {
        return new BFILE(this, array);
    }
    
    @Override
    public ARRAY createARRAY(final String s, final Object o) throws SQLException {
        return new ARRAY(ArrayDescriptor.createDescriptor(s, this), this, o);
    }
    
    @Override
    public BINARY_DOUBLE createBINARY_DOUBLE(final double n) throws SQLException {
        return new BINARY_DOUBLE(n);
    }
    
    @Override
    public BINARY_FLOAT createBINARY_FLOAT(final float n) throws SQLException {
        return new BINARY_FLOAT(n);
    }
    
    @Override
    public DATE createDATE(final Date date) throws SQLException {
        return new DATE(date);
    }
    
    @Override
    public DATE createDATE(final Time time) throws SQLException {
        return new DATE(time);
    }
    
    @Override
    public DATE createDATE(final Timestamp timestamp) throws SQLException {
        return new DATE(timestamp);
    }
    
    @Override
    public DATE createDATE(final Date date, final Calendar calendar) throws SQLException {
        return new DATE(date);
    }
    
    @Override
    public DATE createDATE(final Time time, final Calendar calendar) throws SQLException {
        return new DATE(time);
    }
    
    @Override
    public DATE createDATE(final Timestamp timestamp, final Calendar calendar) throws SQLException {
        return new DATE(timestamp);
    }
    
    @Override
    public DATE createDATE(final String s) throws SQLException {
        return new DATE(s);
    }
    
    @Override
    public INTERVALDS createINTERVALDS(final String s) throws SQLException {
        return new INTERVALDS(s);
    }
    
    @Override
    public INTERVALYM createINTERVALYM(final String s) throws SQLException {
        return new INTERVALYM(s);
    }
    
    @Override
    public NUMBER createNUMBER(final boolean b) throws SQLException {
        return new NUMBER(b);
    }
    
    @Override
    public NUMBER createNUMBER(final byte b) throws SQLException {
        return new NUMBER(b);
    }
    
    @Override
    public NUMBER createNUMBER(final short n) throws SQLException {
        return new NUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final int n) throws SQLException {
        return new NUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final long n) throws SQLException {
        return new NUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final float n) throws SQLException {
        return new NUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final double n) throws SQLException {
        return new NUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final BigDecimal bigDecimal) throws SQLException {
        return new NUMBER(bigDecimal);
    }
    
    @Override
    public NUMBER createNUMBER(final BigInteger bigInteger) throws SQLException {
        return new NUMBER(bigInteger);
    }
    
    @Override
    public NUMBER createNUMBER(final String s, final int n) throws SQLException {
        return new NUMBER(s, n);
    }
    
    @Override
    public Array createArrayOf(final String s, final Object[] array) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public Struct createStruct(final String s, final Object[] array) throws SQLException {
        return new STRUCT(StructDescriptor.createDescriptor(s, this), this, array);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final Date date) throws SQLException {
        return new TIMESTAMP(date);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final DATE date) throws SQLException {
        return new TIMESTAMP(date);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final Time time) throws SQLException {
        return new TIMESTAMP(time);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final Timestamp timestamp) throws SQLException {
        return new TIMESTAMP(timestamp);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final String s) throws SQLException {
        return new TIMESTAMP(s);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Date date) throws SQLException {
        return new TIMESTAMPTZ(this, date);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Date date, final Calendar calendar) throws SQLException {
        return new TIMESTAMPTZ(this, date, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Time time) throws SQLException {
        return new TIMESTAMPTZ(this, time);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Time time, final Calendar calendar) throws SQLException {
        return new TIMESTAMPTZ(this, time, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Timestamp timestamp) throws SQLException {
        return new TIMESTAMPTZ(this, timestamp);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Timestamp timestamp, final Calendar calendar) throws SQLException {
        return new TIMESTAMPTZ(this, timestamp, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final String s) throws SQLException {
        return new TIMESTAMPTZ(this, s);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final String s, final Calendar calendar) throws SQLException {
        return new TIMESTAMPTZ(this, s, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final DATE date) throws SQLException {
        return new TIMESTAMPTZ(this, date);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final Date date, final Calendar calendar) throws SQLException {
        return new TIMESTAMPLTZ(this, calendar, date);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final Time time, final Calendar calendar) throws SQLException {
        return new TIMESTAMPLTZ(this, calendar, time);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final Timestamp timestamp, final Calendar calendar) throws SQLException {
        return new TIMESTAMPLTZ(this, calendar, timestamp);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final String s, final Calendar calendar) throws SQLException {
        return new TIMESTAMPLTZ(this, calendar, s);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final DATE date, final Calendar calendar) throws SQLException {
        return new TIMESTAMPLTZ(this, calendar, date);
    }
    
    public abstract BLOB createTemporaryBlob(final Connection p0, final boolean p1, final int p2) throws SQLException;
    
    public abstract CLOB createTemporaryClob(final Connection p0, final boolean p1, final int p2, final short p3) throws SQLException;
    
    @Override
    public Blob createBlob() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.createTemporaryBlob(this, true, 10);
    }
    
    @Override
    public Clob createClob() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return this.createTemporaryClob(this, true, 10, (short)1);
    }
    
    @Override
    public NClob createNClob() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return (NClob)this.createTemporaryClob(this, true, 10, (short)2);
    }
    
    @Override
    public SQLXML createSQLXML() throws SQLException {
        if (this.lifecycle != 1) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return new OracleSQLXML(this);
    }
    
    @Override
    public boolean isDescriptorSharable(final oracle.jdbc.internal.OracleConnection oracleConnection) throws SQLException {
        final PhysicalConnection physicalConnection = (PhysicalConnection)oracleConnection.getPhysicalConnection();
        return this == physicalConnection || this.url.equals(physicalConnection.url) || (physicalConnection.protocol != null && physicalConnection.protocol.equals("kprb"));
    }
    
    boolean useLittleEndianSetCHARBinder() throws SQLException {
        return false;
    }
    
    @Override
    public void setPlsqlWarnings(String trim) throws SQLException {
        if (trim == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (trim != null && (trim = trim.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(trim)) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        final String string = "ALTER SESSION SET PLSQL_WARNINGS=" + trim;
        final String s = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'";
        Statement statement = null;
        try {
            statement = this.createStatement(-1, -1);
            statement.execute(string);
            if (trim.equals("'DISABLE:ALL'")) {
                this.plsqlCompilerWarnings = false;
            }
            else {
                statement.execute(s);
                this.plsqlCompilerWarnings = true;
            }
        }
        finally {
            if (statement != null) {
                statement.close();
            }
        }
    }
    
    void internalClose() throws SQLException {
        this.lifecycle = 4;
        OracleStatement nextChild;
        for (OracleStatement statements = this.statements; statements != null; statements = nextChild) {
            nextChild = statements.nextChild;
            if (statements.serverCursor) {
                statements.internalClose();
                this.removeStatement(statements);
            }
        }
        OracleStatement next;
        for (OracleStatement statements2 = this.statements; statements2 != null; statements2 = next) {
            next = statements2.next;
            statements2.internalClose();
        }
        this.statements = null;
    }
    
    @Override
    public XAResource getXAResource() throws SQLException {
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 164);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected void doDescribeTable(final AutoKeyInfo autoKeyInfo) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void setApplicationContext(final String s, final String s2, final String s3) throws SQLException {
        if (s == null || s2 == null || s3 == null) {
            throw new NullPointerException();
        }
        if (s.equals("")) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 170);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (s.compareToIgnoreCase("CLIENTCONTEXT") != 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 174);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (s2.length() > 30) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 171);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        if (s3.length() > 4000) {
            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 172);
            sqlException4.fillInStackTrace();
            throw sqlException4;
        }
        this.doSetApplicationContext(s, s2, s3);
    }
    
    void doSetApplicationContext(final String s, final String s2, final String s3) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void clearAllApplicationContext(final String s) throws SQLException {
        if (s == null) {
            throw new NullPointerException();
        }
        if (s.equals("")) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 170);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.doClearAllApplicationContext(s);
    }
    
    void doClearAllApplicationContext(final String s) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public byte[] createLightweightSession(final String s, final KeywordValueLong[] array, final int n, final KeywordValueLong[][] array2, final int[] array3) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void executeLightweightSessionRoundtrip(final int n, final byte[] array, final KeywordValueLong[] array2, final int n2, final KeywordValueLong[][] array3, final int[] array4) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void executeLightweightSessionPiggyback(final int n, final byte[] array, final KeywordValueLong[] array2, final int n2) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2, final XSNamespace[][] array3) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void doXSNamespaceOp(final XSOperationCode xsOperationCode, final byte[] array, final XSNamespace[] array2) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void enqueue(final String s, final AQEnqueueOptions aqEnqueueOptions, final AQMessage aqMessage) throws SQLException {
        final AQMessageI aqMessageI = (AQMessageI)aqMessage;
        final byte[][] array = { null };
        this.doEnqueue(s, aqEnqueueOptions, aqMessageI.getMessagePropertiesI(), aqMessageI.getPayloadTOID(), aqMessageI.getPayload(), array, aqMessageI.isRAWPayload());
        if (array[0] != null) {
            aqMessageI.setMessageId(array[0]);
        }
    }
    
    @Override
    public AQMessage dequeue(final String s, final AQDequeueOptions aqDequeueOptions, final byte[] array) throws SQLException {
        final byte[][] array2 = { null };
        final AQMessagePropertiesI aqMessagePropertiesI = new AQMessagePropertiesI();
        final byte[][] array3 = { null };
        final boolean doDequeue = this.doDequeue(s, aqDequeueOptions, aqMessagePropertiesI, array, array3, array2, AQMessageI.compareToid(array, TypeDescriptor.RAWTOID));
        AQMessageI aqMessageI = null;
        if (doDequeue) {
            aqMessageI = new AQMessageI(aqMessagePropertiesI, this);
            aqMessageI.setPayload(array3[0], array);
            aqMessageI.setMessageId(array2[0]);
        }
        return aqMessageI;
    }
    
    @Override
    public AQMessage dequeue(final String s, final AQDequeueOptions aqDequeueOptions, final String typeName) throws SQLException {
        TypeDescriptor typeDescriptor = null;
        byte[] array;
        if ("RAW".equals(typeName) || "SYS.RAW".equals(typeName)) {
            array = TypeDescriptor.RAWTOID;
        }
        else if ("SYS.ANYDATA".equals(typeName)) {
            array = TypeDescriptor.ANYDATATOID;
        }
        else if ("SYS.XMLTYPE".equals(typeName)) {
            array = TypeDescriptor.XMLTYPETOID;
        }
        else {
            typeDescriptor = TypeDescriptor.getTypeDescriptor(typeName, this);
            array = ((OracleTypeADT)typeDescriptor.getPickler()).getTOID();
        }
        final AQMessageI aqMessageI = (AQMessageI)this.dequeue(s, aqDequeueOptions, array);
        if (aqMessageI != null) {
            aqMessageI.setTypeName(typeName);
            aqMessageI.setTypeDescriptor(typeDescriptor);
        }
        return aqMessageI;
    }
    
    synchronized void doEnqueue(final String s, final AQEnqueueOptions aqEnqueueOptions, final AQMessagePropertiesI aqMessagePropertiesI, final byte[] array, final byte[] array2, final byte[][] array3, final boolean b) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    synchronized boolean doDequeue(final String s, final AQDequeueOptions aqDequeueOptions, final AQMessagePropertiesI aqMessagePropertiesI, final byte[] array, final byte[][] array2, final byte[][] array3, final boolean b) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public boolean isGetObjectReturnsXMLType() {
        return this.getObjectReturnsXmlType;
    }
    
    @Override
    @Deprecated
    public boolean isV8Compatible() throws SQLException {
        return this.mapDateToTimestamp;
    }
    
    @Override
    public boolean getMapDateToTimestamp() {
        return this.mapDateToTimestamp;
    }
    
    @Override
    public byte getInstanceProperty(final InstanceProperty instanceProperty) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public AQNotificationRegistration[] registerAQNotification(final String[] array, final Properties[] array2, final Properties properties) throws SQLException {
        return this.doRegisterAQNotification(array, this.readNTFlocalhost(properties), this.readNTFtcpport(properties), array2);
    }
    
    NTFAQRegistration[] doRegisterAQNotification(final String[] array, final String s, final int n, final Properties[] array2) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void unregisterAQNotification(final AQNotificationRegistration aqNotificationRegistration) throws SQLException {
        this.doUnregisterAQNotification((NTFAQRegistration)aqNotificationRegistration);
    }
    
    void doUnregisterAQNotification(final NTFAQRegistration ntfaqRegistration) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    private String readNTFlocalhost(final Properties properties) throws SQLException {
        String property;
        try {
            property = properties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress());
        }
        catch (UnknownHostException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 240);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        catch (SecurityException ex2) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 241);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return property;
    }
    
    private int readNTFtcpport(final Properties properties) throws SQLException {
        int int1;
        try {
            int1 = Integer.parseInt(properties.getProperty("NTF_LOCAL_TCP_PORT", "0"));
            if (int1 < 0) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 242);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 242);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        return int1;
    }
    
    int readNTFtimeout(final Properties properties) throws SQLException {
        int int1;
        try {
            int1 = Integer.parseInt(properties.getProperty("NTF_TIMEOUT", "0"));
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 243);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        return int1;
    }
    
    @Override
    public DatabaseChangeRegistration registerDatabaseChangeNotification(final Properties properties) throws SQLException {
        final String ntFlocalhost = this.readNTFlocalhost(properties);
        final int ntFtcpport = this.readNTFtcpport(properties);
        final int ntFtimeout = this.readNTFtimeout(properties);
        int int1;
        try {
            int1 = Integer.parseInt(properties.getProperty("DCN_NOTIFY_CHANGELAG", "0"));
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 244);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final NTFDCNRegistration doRegisterDatabaseChangeNotification = this.doRegisterDatabaseChangeNotification(ntFlocalhost, ntFtcpport, properties, ntFtimeout, int1);
        PhysicalConnection.ntfManager.addRegistration(doRegisterDatabaseChangeNotification);
        return doRegisterDatabaseChangeNotification;
    }
    
    NTFDCNRegistration doRegisterDatabaseChangeNotification(final String s, final int n, final Properties properties, final int n2, final int n3) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public DatabaseChangeRegistration getDatabaseChangeRegistration(final int n) throws SQLException {
        return new NTFDCNRegistration(this.instanceName, n, this.userName, this.versionNumber);
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final DatabaseChangeRegistration databaseChangeRegistration) throws SQLException {
        final NTFDCNRegistration ntfdcnRegistration = (NTFDCNRegistration)databaseChangeRegistration;
        if (ntfdcnRegistration.getDatabaseName().compareToIgnoreCase(this.instanceName) != 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 245);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.doUnregisterDatabaseChangeNotification(ntfdcnRegistration);
    }
    
    void doUnregisterDatabaseChangeNotification(final NTFDCNRegistration ntfdcnRegistration) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final int n) throws SQLException {
        String hostAddress = null;
        try {
            hostAddress = InetAddress.getLocalHost().getHostAddress();
        }
        catch (Exception ex) {}
        this.unregisterDatabaseChangeNotification(n, hostAddress, 47632);
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final int n, final String str, final int i) throws SQLException {
        this.unregisterDatabaseChangeNotification(n, "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str + ")(PORT=" + i + "))?PR=0");
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final long n, final String s) throws SQLException {
        this.doUnregisterDatabaseChangeNotification(n, s);
    }
    
    void doUnregisterDatabaseChangeNotification(final long n, final String s) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void addXSEventListener(final XSEventListener xsEventListener) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void addXSEventListener(final XSEventListener xsEventListener, final Executor executor) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public void removeXSEventListener(final XSEventListener xsEventListener) throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    @Override
    public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException {
        TypeDescriptor[] typeDescriptorsFromResultSet = null;
        Statement statement = null;
        try {
            statement = this.createStatement();
            final ResultSet executeQuery = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())");
            typeDescriptorsFromResultSet = this.getTypeDescriptorsFromResultSet(executeQuery);
            executeQuery.close();
        }
        catch (SQLException ex) {
            if (ex.getErrorCode() == 904) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 165);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            throw ex;
        }
        finally {
            if (statement != null) {
                statement.close();
            }
        }
        return typeDescriptorsFromResultSet;
    }
    
    @Override
    public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(final String[] array) throws SQLException {
        final String s = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))";
        TypeDescriptor[] typeDescriptorsFromResultSet = null;
        PreparedStatement prepareStatement = null;
        try {
            prepareStatement = this.prepareStatement(s);
            final int length = array.length;
            final StringBuffer sb = new StringBuffer(length * 8);
            for (int i = 0; i < length; ++i) {
                sb.append(array[i]);
                if (i < length - 1) {
                    sb.append(',');
                }
            }
            prepareStatement.setString(1, sb.toString());
            final ResultSet executeQuery = prepareStatement.executeQuery();
            typeDescriptorsFromResultSet = this.getTypeDescriptorsFromResultSet(executeQuery);
            executeQuery.close();
        }
        catch (SQLException ex) {
            if (ex.getErrorCode() == 904) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 165);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            throw ex;
        }
        finally {
            if (prepareStatement != null) {
                prepareStatement.close();
            }
        }
        return typeDescriptorsFromResultSet;
    }
    
    @Override
    public TypeDescriptor[] getTypeDescriptorsFromList(final String[][] array) throws SQLException {
        TypeDescriptor[] typeDescriptorsFromResultSet = null;
        PreparedStatement prepareStatement = null;
        final int length = array.length;
        final StringBuffer sb = new StringBuffer(length * 8);
        final StringBuffer sb2 = new StringBuffer(length * 8);
        for (int i = 0; i < length; ++i) {
            sb.append(array[i][0]);
            sb2.append(array[i][1]);
            if (i < length - 1) {
                sb.append(',');
                sb2.append(',');
            }
        }
        try {
            prepareStatement = this.prepareStatement("SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))");
            prepareStatement.setString(1, sb.toString());
            prepareStatement.setString(2, sb2.toString());
            final ResultSet executeQuery = prepareStatement.executeQuery();
            typeDescriptorsFromResultSet = this.getTypeDescriptorsFromResultSet(executeQuery);
            executeQuery.close();
        }
        catch (SQLException ex) {
            if (ex.getErrorCode() == 904) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 165);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            throw ex;
        }
        finally {
            if (prepareStatement != null) {
                prepareStatement.close();
            }
        }
        return typeDescriptorsFromResultSet;
    }
    
    TypeDescriptor[] getTypeDescriptorsFromResultSet(final ResultSet set) throws SQLException {
        final ArrayList<StructDescriptor> list = new ArrayList<StructDescriptor>();
        while (set.next()) {
            final String string = set.getString(1);
            final String string2 = set.getString(2);
            final byte[] bytes = set.getBytes(3);
            final String string3 = set.getString(4);
            final int int1 = set.getInt(5);
            final byte[] bytes2 = set.getBytes(6);
            final SQLName sqlName = new SQLName(string, string2, this);
            if (string3.equals("OBJECT")) {
                final StructDescriptor descriptor = StructDescriptor.createDescriptor(sqlName, bytes, int1, bytes2, this);
                this.putDescriptor(bytes, descriptor);
                this.putDescriptor(descriptor.getName(), descriptor);
                list.add(descriptor);
            }
            else {
                if (!string3.equals("COLLECTION")) {
                    continue;
                }
                final ArrayDescriptor descriptor2 = ArrayDescriptor.createDescriptor(sqlName, bytes, int1, bytes2, this);
                this.putDescriptor(bytes, descriptor2);
                this.putDescriptor(descriptor2.getName(), descriptor2);
                list.add((StructDescriptor)descriptor2);
            }
        }
        final TypeDescriptor[] array = new TypeDescriptor[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            array[i] = list.get(i);
        }
        return array;
    }
    
    @Override
    public synchronized boolean isUsable() {
        return this.isUsable;
    }
    
    @Override
    public synchronized void setUsable(final boolean isUsable) {
        this.isUsable = isUsable;
    }
    
    void queryFCFProperties(final Properties properties) throws SQLException {
        Statement statement = null;
        ResultSet executeQuery = null;
        final String s = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual";
        try {
            statement = this.createStatement();
            statement.setFetchSize(1);
            executeQuery = statement.executeQuery(s);
            while (executeQuery.next()) {
                final String string = executeQuery.getString(1);
                if (string != null) {
                    properties.put("INSTANCE_NAME", string.trim());
                }
                final String string2 = executeQuery.getString(2);
                if (string2 != null) {
                    properties.put("SERVER_HOST", string2.trim());
                }
                final String string3 = executeQuery.getString(3);
                if (string3 != null) {
                    properties.put("SERVICE_NAME", string3.trim());
                }
                final String string4 = executeQuery.getString(4);
                if (string4 != null) {
                    properties.put("DATABASE_NAME", string4.trim());
                }
            }
        }
        finally {
            if (executeQuery != null) {
                executeQuery.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
    }
    
    @Override
    public void setDefaultTimeZone(final TimeZone defaultTimeZone) throws SQLException {
        this.defaultTimeZone = defaultTimeZone;
    }
    
    @Override
    public TimeZone getDefaultTimeZone() throws SQLException {
        return this.defaultTimeZone;
    }
    
    @Override
    public int getTimezoneVersionNumber() throws SQLException {
        return this.timeZoneVersionNumber;
    }
    
    @Override
    public TIMEZONETAB getTIMEZONETAB() throws SQLException {
        if (this.timeZoneTab == null) {
            this.timeZoneTab = TIMEZONETAB.getInstance(this.getTimezoneVersionNumber());
        }
        return this.timeZoneTab;
    }
    
    @Override
    public boolean isDataInLocatorEnabled() throws SQLException {
        return (this.getVersionNumber() >= 10200 & this.getVersionNumber() < 11000 & this.enableReadDataInLocator) | this.overrideEnableReadDataInLocator;
    }
    
    static {
        EMPTY_BYTE_ARRAY = new byte[0];
        PhysicalConnection.ntfManager = new NTFManager();
        driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
        CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort");
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    private static final class BufferCacheStore
    {
        static int MAX_CACHED_BUFFER_SIZE;
        final BufferCache<byte[]> byteBufferCache;
        final BufferCache<char[]> charBufferCache;
        
        BufferCacheStore() {
            this(BufferCacheStore.MAX_CACHED_BUFFER_SIZE);
        }
        
        BufferCacheStore(final int n) {
            this.byteBufferCache = new BufferCache<byte[]>(n);
            this.charBufferCache = new BufferCache<char[]>(n);
        }
        
        static {
            BufferCacheStore.MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
        }
    }
}
