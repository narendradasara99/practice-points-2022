// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Connection;
import java.util.Properties;

abstract class OracleDriverExtension
{
    abstract Connection getConnection(final String p0, final Properties p1) throws SQLException;
    
    abstract OracleStatement allocateStatement(final PhysicalConnection p0, final int p1, final int p2) throws SQLException;
    
    abstract OraclePreparedStatement allocatePreparedStatement(final PhysicalConnection p0, final String p1, final int p2, final int p3) throws SQLException;
    
    abstract OracleCallableStatement allocateCallableStatement(final PhysicalConnection p0, final String p1, final int p2, final int p3) throws SQLException;
    
    abstract OracleInputStream createInputStream(final OracleStatement p0, final int p1, final Accessor p2) throws SQLException;
}
