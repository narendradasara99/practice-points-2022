// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.driver;

public interface DiagnosabilityMXBean
{
    boolean stateManageable();
    
    boolean statisticsProvider();
    
    boolean getLoggingEnabled();
    
    void setLoggingEnabled(final boolean p0);
}
