// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

public class Const
{
    public static final short NCHAR = 2;
    public static final short CHAR = 1;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
