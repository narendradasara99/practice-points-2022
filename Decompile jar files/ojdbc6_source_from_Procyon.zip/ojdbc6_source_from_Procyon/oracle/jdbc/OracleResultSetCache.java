// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import java.io.IOException;

public interface OracleResultSetCache
{
    void put(final int p0, final int p1, final Object p2) throws IOException;
    
    Object get(final int p0, final int p1) throws IOException;
    
    void remove(final int p0) throws IOException;
    
    void remove(final int p0, final int p1) throws IOException;
    
    void clear() throws IOException;
    
    void close() throws IOException;
}
