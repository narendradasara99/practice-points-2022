// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.connector;

import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.spi.EISSystemException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleDatabaseMetaData;
import javax.resource.spi.ManagedConnectionMetaData;

public class OracleManagedConnectionMetaData implements ManagedConnectionMetaData
{
    private OracleManagedConnection managedConnection;
    private OracleDatabaseMetaData databaseMetaData;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleManagedConnectionMetaData(final OracleManagedConnection managedConnection) throws ResourceException {
        this.managedConnection = null;
        this.databaseMetaData = null;
        try {
            this.managedConnection = managedConnection;
            this.databaseMetaData = (OracleDatabaseMetaData)((OracleConnection)managedConnection.getPhysicalConnection()).getMetaData();
        }
        catch (Exception linkedException) {
            final EISSystemException ex = new EISSystemException("Exception: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException(linkedException);
            throw ex;
        }
    }
    
    public String getEISProductName() throws ResourceException {
        try {
            return this.databaseMetaData.getDatabaseProductName();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public String getEISProductVersion() throws ResourceException {
        try {
            return this.databaseMetaData.getDatabaseProductVersion();
        }
        catch (Exception linkedException) {
            final EISSystemException ex = new EISSystemException("Exception: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException(linkedException);
            throw ex;
        }
    }
    
    public int getMaxConnections() throws ResourceException {
        try {
            return this.databaseMetaData.getMaxConnections();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public String getUserName() throws ResourceException {
        try {
            return this.databaseMetaData.getUserName();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
