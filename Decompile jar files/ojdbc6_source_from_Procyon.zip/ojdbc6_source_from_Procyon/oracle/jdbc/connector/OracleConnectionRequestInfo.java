// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.connector;

import javax.resource.spi.ConnectionRequestInfo;

public class OracleConnectionRequestInfo implements ConnectionRequestInfo
{
    private String user;
    private String password;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConnectionRequestInfo(final String user, final String password) {
        this.user = null;
        this.password = null;
        this.user = user;
        this.password = password;
    }
    
    public String getUser() {
        return this.user;
    }
    
    public void setUser(final String user) {
        this.user = user;
    }
    
    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(final String password) {
        this.password = password;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof OracleConnectionRequestInfo)) {
            return false;
        }
        final OracleConnectionRequestInfo oracleConnectionRequestInfo = (OracleConnectionRequestInfo)o;
        return this.user.equalsIgnoreCase(oracleConnectionRequestInfo.getUser()) && this.password.equals(oracleConnectionRequestInfo.getPassword());
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
