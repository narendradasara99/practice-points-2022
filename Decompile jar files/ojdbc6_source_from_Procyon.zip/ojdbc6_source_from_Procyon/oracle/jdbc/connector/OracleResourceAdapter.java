// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.connector;

import javax.resource.ResourceException;
import javax.transaction.xa.XAResource;
import javax.resource.NotSupportedException;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import javax.resource.spi.ResourceAdapterInternalException;
import javax.resource.spi.BootstrapContext;
import javax.resource.spi.ResourceAdapter;

public class OracleResourceAdapter implements ResourceAdapter
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public void start(final BootstrapContext bootstrapContext) throws ResourceAdapterInternalException {
    }
    
    public void stop() {
    }
    
    public void endpointActivation(final MessageEndpointFactory messageEndpointFactory, final ActivationSpec activationSpec) throws NotSupportedException {
    }
    
    public void endpointDeactivation(final MessageEndpointFactory messageEndpointFactory, final ActivationSpec activationSpec) {
    }
    
    public XAResource[] getXAResources(final ActivationSpec[] array) throws ResourceException {
        return new XAResource[0];
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
