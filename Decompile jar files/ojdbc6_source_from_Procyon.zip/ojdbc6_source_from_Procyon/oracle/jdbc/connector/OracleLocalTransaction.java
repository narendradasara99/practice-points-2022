// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.connector;

import javax.resource.spi.LocalTransactionException;
import java.sql.SQLException;
import javax.resource.spi.EISSystemException;
import javax.resource.spi.IllegalStateException;
import oracle.jdbc.internal.OracleConnection;
import javax.resource.ResourceException;
import java.sql.Connection;
import javax.resource.spi.LocalTransaction;

public class OracleLocalTransaction implements LocalTransaction
{
    private OracleManagedConnection managedConnection;
    private Connection connection;
    boolean isBeginCalled;
    private static final String RAERR_LTXN_COMMIT = "commit without begin";
    private static final String RAERR_LTXN_ROLLBACK = "rollback without begin";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleLocalTransaction(final OracleManagedConnection managedConnection) throws ResourceException {
        this.managedConnection = null;
        this.connection = null;
        this.isBeginCalled = false;
        this.managedConnection = managedConnection;
        this.connection = managedConnection.getPhysicalConnection();
        this.isBeginCalled = false;
    }
    
    public void begin() throws ResourceException {
        try {
            if (((OracleConnection)this.connection).getTxnMode() == 1) {
                throw new IllegalStateException("Could not start a new transaction inside an active transaction");
            }
            if (this.connection.getAutoCommit()) {
                this.connection.setAutoCommit(false);
            }
            this.isBeginCalled = true;
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
        this.managedConnection.eventOccurred(2);
    }
    
    public void commit() throws ResourceException {
        if (!this.isBeginCalled) {
            throw new LocalTransactionException("begin() must be called before commit()", "commit without begin");
        }
        try {
            this.connection.commit();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
        this.isBeginCalled = false;
        this.managedConnection.eventOccurred(3);
    }
    
    public void rollback() throws ResourceException {
        if (!this.isBeginCalled) {
            throw new LocalTransactionException("begin() must be called before rollback()", "rollback without begin");
        }
        try {
            this.connection.rollback();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
        this.isBeginCalled = false;
        this.managedConnection.eventOccurred(4);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
