// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.connector;

import java.util.Enumeration;
import javax.resource.spi.ConnectionEvent;
import javax.resource.spi.ManagedConnectionMetaData;
import javax.resource.spi.LocalTransaction;
import javax.transaction.xa.XAResource;
import javax.resource.spi.ConnectionEventListener;
import javax.resource.spi.IllegalStateException;
import oracle.jdbc.internal.OracleConnection;
import javax.resource.ResourceException;
import java.sql.SQLException;
import javax.resource.spi.EISSystemException;
import javax.resource.spi.ConnectionRequestInfo;
import javax.security.auth.Subject;
import javax.sql.XAConnection;
import javax.resource.spi.security.PasswordCredential;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Hashtable;
import oracle.jdbc.xa.OracleXAConnection;
import javax.resource.spi.ManagedConnection;

public class OracleManagedConnection implements ManagedConnection
{
    private OracleXAConnection xaConnection;
    private Hashtable connectionListeners;
    private Connection connection;
    private PrintWriter logWriter;
    private PasswordCredential passwordCredential;
    private OracleLocalTransaction localTxn;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleManagedConnection(final XAConnection xaConnection) {
        this.xaConnection = null;
        this.connectionListeners = null;
        this.connection = null;
        this.logWriter = null;
        this.passwordCredential = null;
        this.localTxn = null;
        this.xaConnection = (OracleXAConnection)xaConnection;
        this.connectionListeners = new Hashtable(10);
    }
    
    public Object getConnection(final Subject subject, final ConnectionRequestInfo connectionRequestInfo) throws ResourceException {
        try {
            if (this.connection != null) {
                this.connection.close();
            }
            return this.connection = this.xaConnection.getConnection();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public void destroy() throws ResourceException {
        try {
            if (this.xaConnection != null) {
                final Connection physicalHandle = this.xaConnection.getPhysicalHandle();
                if ((this.localTxn != null && this.localTxn.isBeginCalled) || ((OracleConnection)physicalHandle).getTxnMode() == 1) {
                    throw new IllegalStateException("Could not close connection while transaction is active");
                }
            }
            if (this.connection != null) {
                this.connection.close();
            }
            if (this.xaConnection != null) {
                this.xaConnection.close();
            }
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public void cleanup() throws ResourceException {
        try {
            if (this.connection != null) {
                if ((this.localTxn != null && this.localTxn.isBeginCalled) || ((OracleConnection)this.connection).getTxnMode() == 1) {
                    throw new IllegalStateException("Could not close connection while transaction is active");
                }
                this.connection.close();
            }
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public void associateConnection(final Object o) {
    }
    
    public void addConnectionEventListener(final ConnectionEventListener connectionEventListener) {
        this.connectionListeners.put(connectionEventListener, connectionEventListener);
    }
    
    public void removeConnectionEventListener(final ConnectionEventListener key) {
        this.connectionListeners.remove(key);
    }
    
    public XAResource getXAResource() throws ResourceException {
        return this.xaConnection.getXAResource();
    }
    
    public LocalTransaction getLocalTransaction() throws ResourceException {
        if (this.localTxn == null) {
            this.localTxn = new OracleLocalTransaction(this);
        }
        return (LocalTransaction)this.localTxn;
    }
    
    public ManagedConnectionMetaData getMetaData() throws ResourceException {
        return (ManagedConnectionMetaData)new OracleManagedConnectionMetaData(this);
    }
    
    public void setLogWriter(final PrintWriter logWriter) throws ResourceException {
        this.logWriter = logWriter;
    }
    
    public PrintWriter getLogWriter() throws ResourceException {
        return this.logWriter;
    }
    
    Connection getPhysicalConnection() throws ResourceException {
        try {
            return this.xaConnection.getPhysicalHandle();
        }
        catch (Exception linkedException) {
            final EISSystemException ex = new EISSystemException("Exception: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException(linkedException);
            throw ex;
        }
    }
    
    void setPasswordCredential(final PasswordCredential passwordCredential) {
        this.passwordCredential = passwordCredential;
    }
    
    PasswordCredential getPasswordCredential() {
        return this.passwordCredential;
    }
    
    void eventOccurred(final int i) throws ResourceException {
        final Enumeration<ConnectionEventListener> keys = this.connectionListeners.keys();
        while (keys.hasMoreElements()) {
            final ConnectionEventListener connectionEventListener = keys.nextElement();
            final ConnectionEvent connectionEvent = new ConnectionEvent((ManagedConnection)this, i);
            switch (i) {
                case 1: {
                    connectionEventListener.connectionClosed(connectionEvent);
                    continue;
                }
                case 2: {
                    connectionEventListener.localTransactionStarted(connectionEvent);
                    continue;
                }
                case 3: {
                    connectionEventListener.localTransactionCommitted(connectionEvent);
                    continue;
                }
                case 4: {
                    connectionEventListener.localTransactionRolledback(connectionEvent);
                    continue;
                }
                case 5: {
                    connectionEventListener.connectionErrorOccurred(connectionEvent);
                    continue;
                }
                default: {
                    throw new IllegalArgumentException("Illegal eventType in eventOccurred(): " + i);
                }
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
