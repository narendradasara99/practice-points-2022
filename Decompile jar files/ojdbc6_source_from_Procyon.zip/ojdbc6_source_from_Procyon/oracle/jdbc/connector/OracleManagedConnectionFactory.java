// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.connector;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.resource.spi.ResourceAdapterInternalException;
import java.util.Hashtable;
import javax.naming.InitialContext;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Set;
import javax.sql.XAConnection;
import javax.resource.spi.security.PasswordCredential;
import java.sql.SQLException;
import javax.resource.spi.EISSystemException;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ConnectionRequestInfo;
import javax.security.auth.Subject;
import javax.sql.DataSource;
import javax.resource.spi.ConnectionManager;
import javax.resource.ResourceException;
import javax.sql.XADataSource;
import javax.resource.spi.ManagedConnectionFactory;

public class OracleManagedConnectionFactory implements ManagedConnectionFactory
{
    private XADataSource xaDataSource;
    private String xaDataSourceName;
    private static final String RAERR_MCF_SET_XADS = "invalid xads";
    private static final String RAERR_MCF_GET_PCRED = "no password credential";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleManagedConnectionFactory() throws ResourceException {
        this.xaDataSource = null;
        this.xaDataSourceName = null;
    }
    
    public OracleManagedConnectionFactory(final XADataSource xaDataSource) throws ResourceException {
        this.xaDataSource = null;
        this.xaDataSourceName = null;
        this.xaDataSource = xaDataSource;
        this.xaDataSourceName = "XADataSource";
    }
    
    public void setXADataSourceName(final String xaDataSourceName) {
        this.xaDataSourceName = xaDataSourceName;
    }
    
    public String getXADataSourceName() {
        return this.xaDataSourceName;
    }
    
    public Object createConnectionFactory(final ConnectionManager connectionManager) throws ResourceException {
        if (this.xaDataSource == null) {
            this.setupXADataSource();
        }
        return this.xaDataSource;
    }
    
    public Object createConnectionFactory() throws ResourceException {
        return this.createConnectionFactory(null);
    }
    
    public ManagedConnection createManagedConnection(final Subject subject, final ConnectionRequestInfo connectionRequestInfo) throws ResourceException {
        try {
            if (this.xaDataSource == null) {
                this.setupXADataSource();
            }
            final PasswordCredential passwordCredential = this.getPasswordCredential(subject, connectionRequestInfo);
            XAConnection xaConnection;
            if (passwordCredential == null) {
                xaConnection = this.xaDataSource.getXAConnection();
            }
            else {
                xaConnection = this.xaDataSource.getXAConnection(passwordCredential.getUserName(), new String(passwordCredential.getPassword()));
            }
            final OracleManagedConnection oracleManagedConnection = new OracleManagedConnection(xaConnection);
            oracleManagedConnection.setPasswordCredential(passwordCredential);
            oracleManagedConnection.setLogWriter(this.getLogWriter());
            return (ManagedConnection)oracleManagedConnection;
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public ManagedConnection matchManagedConnections(final Set set, final Subject subject, final ConnectionRequestInfo connectionRequestInfo) throws ResourceException {
        final PasswordCredential passwordCredential = this.getPasswordCredential(subject, connectionRequestInfo);
        for (final OracleManagedConnection next : set) {
            if (next instanceof OracleManagedConnection) {
                final OracleManagedConnection oracleManagedConnection = next;
                if (oracleManagedConnection.getPasswordCredential().equals((Object)passwordCredential)) {
                    return (ManagedConnection)oracleManagedConnection;
                }
                continue;
            }
        }
        return null;
    }
    
    public void setLogWriter(final PrintWriter logWriter) throws ResourceException {
        try {
            if (this.xaDataSource == null) {
                this.setupXADataSource();
            }
            this.xaDataSource.setLogWriter(logWriter);
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    public PrintWriter getLogWriter() throws ResourceException {
        try {
            if (this.xaDataSource == null) {
                this.setupXADataSource();
            }
            return this.xaDataSource.getLogWriter();
        }
        catch (SQLException linkedException) {
            final EISSystemException ex = new EISSystemException("SQLException: " + linkedException.getMessage());
            ((ResourceException)ex).setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    private void setupXADataSource() throws ResourceException {
        try {
            Context context = null;
            try {
                context = new InitialContext(System.getProperties());
            }
            catch (SecurityException ex2) {}
            if (context == null) {
                context = new InitialContext();
            }
            final XADataSource xaDataSource = (XADataSource)context.lookup(this.xaDataSourceName);
            if (xaDataSource == null) {
                throw new ResourceAdapterInternalException("Invalid XADataSource object");
            }
            this.xaDataSource = xaDataSource;
        }
        catch (NamingException linkedException) {
            final ResourceException ex = new ResourceException("NamingException: " + linkedException.getMessage());
            ex.setLinkedException((Exception)linkedException);
            throw ex;
        }
    }
    
    private PasswordCredential getPasswordCredential(final Subject subject, final ConnectionRequestInfo connectionRequestInfo) throws ResourceException {
        if (subject != null) {
            for (final PasswordCredential passwordCredential : subject.getPrivateCredentials(PasswordCredential.class)) {
                if (passwordCredential.getManagedConnectionFactory().equals(this)) {
                    return passwordCredential;
                }
            }
            throw new javax.resource.spi.SecurityException("Can not find user/password information", "no password credential");
        }
        if (connectionRequestInfo == null) {
            return null;
        }
        final OracleConnectionRequestInfo oracleConnectionRequestInfo = (OracleConnectionRequestInfo)connectionRequestInfo;
        final PasswordCredential passwordCredential2 = new PasswordCredential(oracleConnectionRequestInfo.getUser(), oracleConnectionRequestInfo.getPassword().toCharArray());
        passwordCredential2.setManagedConnectionFactory((ManagedConnectionFactory)this);
        return passwordCredential2;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
