// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import java.io.OutputStream;
import java.io.ByteArrayOutputStream;

public class OracleDriver extends oracle.jdbc.driver.OracleDriver
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static final boolean isDMS() {
        return false;
    }
    
    public static final boolean isInServer() {
        return false;
    }
    
    @Deprecated
    public static final boolean isJDK14() {
        return true;
    }
    
    public static final boolean isDebug() {
        return false;
    }
    
    public static final boolean isPrivateDebug() {
        return false;
    }
    
    public static final String getJDBCVersion() {
        return "JDBC 4.0";
    }
    
    public static final String getDriverVersion() {
        return "11.2.0.2.0";
    }
    
    public static final String getBuildDate() {
        return "Thu_Aug_26_18:10:24_PDT_2010";
    }
    
    public static void main(final String[] array) throws Exception {
        System.out.println("Oracle " + getDriverVersion() + " " + getJDBCVersion() + (isDMS() ? " DMS" : "") + (isPrivateDebug() ? " private" : "") + (isDebug() ? " debug" : "") + (isInServer() ? " for JAVAVM" : "") + " compiled with " + "JDK6" + " on " + getBuildDate());
        final ByteArrayOutputStream out = new ByteArrayOutputStream(128);
        OracleDriver.DEFAULT_CONNECTION_PROPERTIES.store(out, "Default Connection Properties Resource");
        System.out.println(out.toString("ISO-8859-1"));
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
