// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import java.lang.reflect.Method;
import java.util.TimeZone;
import oracle.sql.TypeDescriptor;
import java.util.EnumSet;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import oracle.jdbc.driver.DatabaseError;
import java.sql.SQLClientInfoException;
import java.sql.Struct;
import java.sql.SQLXML;
import java.sql.NClob;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.Array;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import java.math.BigInteger;
import java.math.BigDecimal;
import oracle.sql.NUMBER;
import oracle.sql.INTERVALYM;
import oracle.sql.INTERVALDS;
import java.util.Calendar;
import java.sql.Timestamp;
import java.sql.Time;
import oracle.sql.DATE;
import java.sql.Date;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.ARRAY;
import java.sql.Savepoint;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import java.sql.Connection;
import java.util.Properties;
import java.sql.SQLWarning;
import java.sql.DatabaseMetaData;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class OracleConnectionWrapper implements OracleConnection
{
    protected OracleConnection connection;
    private Map<Class, Object> proxies;
    private static Map<Class, Class> proxyClasses;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConnectionWrapper() {
        this.proxies = new HashMap<Class, Object>(3);
    }
    
    public OracleConnectionWrapper(final OracleConnection connection) {
        this.proxies = new HashMap<Class, Object>(3);
        (this.connection = connection).setWrapper(this);
    }
    
    @Override
    public OracleConnection unwrap() {
        return this.connection;
    }
    
    @Override
    public oracle.jdbc.internal.OracleConnection physicalConnectionWithin() {
        return this.connection.physicalConnectionWithin();
    }
    
    public String getDatabaseTimeZone() throws SQLException {
        return this.physicalConnectionWithin().getDatabaseTimeZone();
    }
    
    @Override
    public void setWrapper(final OracleConnection wrapper) {
        this.connection.setWrapper(wrapper);
    }
    
    @Override
    public Statement createStatement() throws SQLException {
        return this.connection.createStatement();
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s) throws SQLException {
        return this.connection.prepareStatement(s);
    }
    
    @Override
    public CallableStatement prepareCall(final String s) throws SQLException {
        return this.connection.prepareCall(s);
    }
    
    @Override
    public String nativeSQL(final String s) throws SQLException {
        return this.connection.nativeSQL(s);
    }
    
    @Override
    public void setAutoCommit(final boolean autoCommit) throws SQLException {
        this.connection.setAutoCommit(autoCommit);
    }
    
    @Override
    public boolean getAutoCommit() throws SQLException {
        return this.connection.getAutoCommit();
    }
    
    @Override
    public void commit() throws SQLException {
        this.connection.commit();
    }
    
    @Override
    public void rollback() throws SQLException {
        this.connection.rollback();
    }
    
    @Override
    public void close() throws SQLException {
        this.connection.close();
    }
    
    @Override
    public boolean isClosed() throws SQLException {
        return this.connection.isClosed();
    }
    
    @Override
    public DatabaseMetaData getMetaData() throws SQLException {
        return this.connection.getMetaData();
    }
    
    @Override
    public void setReadOnly(final boolean readOnly) throws SQLException {
        this.connection.setReadOnly(readOnly);
    }
    
    @Override
    public boolean isReadOnly() throws SQLException {
        return this.connection.isReadOnly();
    }
    
    @Override
    public void setCatalog(final String catalog) throws SQLException {
        this.connection.setCatalog(catalog);
    }
    
    @Override
    public String getCatalog() throws SQLException {
        return this.connection.getCatalog();
    }
    
    @Override
    public void setTransactionIsolation(final int transactionIsolation) throws SQLException {
        this.connection.setTransactionIsolation(transactionIsolation);
    }
    
    @Override
    public int getTransactionIsolation() throws SQLException {
        return this.connection.getTransactionIsolation();
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return this.connection.getWarnings();
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        this.connection.clearWarnings();
    }
    
    @Override
    public Statement createStatement(final int n, final int n2) throws SQLException {
        return this.connection.createStatement(n, n2);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int n, final int n2) throws SQLException {
        return this.connection.prepareStatement(s, n, n2);
    }
    
    @Override
    public CallableStatement prepareCall(final String s, final int n, final int n2) throws SQLException {
        return this.connection.prepareCall(s, n, n2);
    }
    
    @Override
    public Map getTypeMap() throws SQLException {
        return this.connection.getTypeMap();
    }
    
    @Override
    public void setTypeMap(final Map typeMap) throws SQLException {
        this.connection.setTypeMap(typeMap);
    }
    
    @Override
    public boolean isProxySession() {
        return this.connection.isProxySession();
    }
    
    @Override
    public void openProxySession(final int n, final Properties properties) throws SQLException {
        this.connection.openProxySession(n, properties);
    }
    
    @Override
    public void archive(final int n, final int n2, final String s) throws SQLException {
        this.connection.archive(n, n2, s);
    }
    
    @Override
    public boolean getAutoClose() throws SQLException {
        return this.connection.getAutoClose();
    }
    
    @Override
    public CallableStatement getCallWithKey(final String s) throws SQLException {
        return this.connection.getCallWithKey(s);
    }
    
    @Override
    public int getDefaultExecuteBatch() {
        return this.connection.getDefaultExecuteBatch();
    }
    
    @Override
    public int getDefaultRowPrefetch() {
        return this.connection.getDefaultRowPrefetch();
    }
    
    @Override
    public Object getDescriptor(final String s) {
        return this.connection.getDescriptor(s);
    }
    
    @Override
    public String[] getEndToEndMetrics() throws SQLException {
        return this.connection.getEndToEndMetrics();
    }
    
    @Override
    public short getEndToEndECIDSequenceNumber() throws SQLException {
        return this.connection.getEndToEndECIDSequenceNumber();
    }
    
    @Override
    public boolean getIncludeSynonyms() {
        return this.connection.getIncludeSynonyms();
    }
    
    @Override
    public boolean getRestrictGetTables() {
        return this.connection.getRestrictGetTables();
    }
    
    @Override
    public boolean getImplicitCachingEnabled() throws SQLException {
        return this.connection.getImplicitCachingEnabled();
    }
    
    @Override
    public boolean getExplicitCachingEnabled() throws SQLException {
        return this.connection.getExplicitCachingEnabled();
    }
    
    @Override
    public Object getJavaObject(final String s) throws SQLException {
        return this.connection.getJavaObject(s);
    }
    
    @Override
    public boolean getRemarksReporting() {
        return this.connection.getRemarksReporting();
    }
    
    @Override
    public String getSQLType(final Object o) throws SQLException {
        return this.connection.getSQLType(o);
    }
    
    @Override
    public int getStmtCacheSize() {
        return this.connection.getStmtCacheSize();
    }
    
    @Override
    public int getStatementCacheSize() throws SQLException {
        return this.connection.getStatementCacheSize();
    }
    
    @Override
    public PreparedStatement getStatementWithKey(final String s) throws SQLException {
        return this.connection.getStatementWithKey(s);
    }
    
    @Override
    public short getStructAttrCsId() throws SQLException {
        return this.connection.getStructAttrCsId();
    }
    
    @Override
    public String getUserName() throws SQLException {
        return this.connection.getUserName();
    }
    
    @Override
    public String getCurrentSchema() throws SQLException {
        return this.connection.getCurrentSchema();
    }
    
    @Override
    public boolean getUsingXAFlag() {
        return this.connection.getUsingXAFlag();
    }
    
    @Override
    public boolean getXAErrorFlag() {
        return this.connection.getXAErrorFlag();
    }
    
    @Override
    public OracleSavepoint oracleSetSavepoint() throws SQLException {
        return this.connection.oracleSetSavepoint();
    }
    
    @Override
    public OracleSavepoint oracleSetSavepoint(final String s) throws SQLException {
        return this.connection.oracleSetSavepoint(s);
    }
    
    @Override
    public void oracleRollback(final OracleSavepoint oracleSavepoint) throws SQLException {
        this.connection.oracleRollback(oracleSavepoint);
    }
    
    @Override
    public void oracleReleaseSavepoint(final OracleSavepoint oracleSavepoint) throws SQLException {
        this.connection.oracleReleaseSavepoint(oracleSavepoint);
    }
    
    @Override
    public int pingDatabase() throws SQLException {
        return this.connection.pingDatabase();
    }
    
    @Override
    public int pingDatabase(final int n) throws SQLException {
        return this.connection.pingDatabase(n);
    }
    
    @Override
    public void purgeExplicitCache() throws SQLException {
        this.connection.purgeExplicitCache();
    }
    
    @Override
    public void purgeImplicitCache() throws SQLException {
        this.connection.purgeImplicitCache();
    }
    
    @Override
    public void putDescriptor(final String s, final Object o) throws SQLException {
        this.connection.putDescriptor(s, o);
    }
    
    @Override
    public void registerSQLType(final String s, final Class clazz) throws SQLException {
        this.connection.registerSQLType(s, clazz);
    }
    
    @Override
    public void registerSQLType(final String s, final String s2) throws SQLException {
        this.connection.registerSQLType(s, s2);
    }
    
    @Override
    public void setAutoClose(final boolean autoClose) throws SQLException {
        this.connection.setAutoClose(autoClose);
    }
    
    @Override
    public void setDefaultExecuteBatch(final int defaultExecuteBatch) throws SQLException {
        this.connection.setDefaultExecuteBatch(defaultExecuteBatch);
    }
    
    @Override
    public void setDefaultRowPrefetch(final int defaultRowPrefetch) throws SQLException {
        this.connection.setDefaultRowPrefetch(defaultRowPrefetch);
    }
    
    @Override
    public void setEndToEndMetrics(final String[] array, final short n) throws SQLException {
        this.connection.setEndToEndMetrics(array, n);
    }
    
    @Override
    public void setExplicitCachingEnabled(final boolean explicitCachingEnabled) throws SQLException {
        this.connection.setExplicitCachingEnabled(explicitCachingEnabled);
    }
    
    @Override
    public void setImplicitCachingEnabled(final boolean implicitCachingEnabled) throws SQLException {
        this.connection.setImplicitCachingEnabled(implicitCachingEnabled);
    }
    
    @Override
    public void setIncludeSynonyms(final boolean includeSynonyms) {
        this.connection.setIncludeSynonyms(includeSynonyms);
    }
    
    @Override
    public void setRemarksReporting(final boolean remarksReporting) {
        this.connection.setRemarksReporting(remarksReporting);
    }
    
    @Override
    public void setRestrictGetTables(final boolean restrictGetTables) {
        this.connection.setRestrictGetTables(restrictGetTables);
    }
    
    @Override
    public void setStmtCacheSize(final int stmtCacheSize) throws SQLException {
        this.connection.setStmtCacheSize(stmtCacheSize);
    }
    
    @Override
    public void setStatementCacheSize(final int statementCacheSize) throws SQLException {
        this.connection.setStatementCacheSize(statementCacheSize);
    }
    
    @Override
    public void setStmtCacheSize(final int n, final boolean b) throws SQLException {
        this.connection.setStmtCacheSize(n, b);
    }
    
    @Override
    public void setUsingXAFlag(final boolean usingXAFlag) {
        this.connection.setUsingXAFlag(usingXAFlag);
    }
    
    @Override
    public void setXAErrorFlag(final boolean xaErrorFlag) {
        this.connection.setXAErrorFlag(xaErrorFlag);
    }
    
    @Override
    public void shutdown(final DatabaseShutdownMode databaseShutdownMode) throws SQLException {
        this.connection.shutdown(databaseShutdownMode);
    }
    
    @Override
    public void startup(final String s, final int n) throws SQLException {
        this.connection.startup(s, n);
    }
    
    @Override
    public void startup(final DatabaseStartupMode databaseStartupMode) throws SQLException {
        this.connection.startup(databaseStartupMode);
    }
    
    @Override
    public PreparedStatement prepareStatementWithKey(final String s) throws SQLException {
        return this.connection.prepareStatementWithKey(s);
    }
    
    @Override
    public CallableStatement prepareCallWithKey(final String s) throws SQLException {
        return this.connection.prepareCallWithKey(s);
    }
    
    @Override
    public void setCreateStatementAsRefCursor(final boolean createStatementAsRefCursor) {
        this.connection.setCreateStatementAsRefCursor(createStatementAsRefCursor);
    }
    
    @Override
    public boolean getCreateStatementAsRefCursor() {
        return this.connection.getCreateStatementAsRefCursor();
    }
    
    @Override
    public void setSessionTimeZone(final String sessionTimeZone) throws SQLException {
        this.connection.setSessionTimeZone(sessionTimeZone);
    }
    
    @Override
    public String getSessionTimeZone() {
        return this.connection.getSessionTimeZone();
    }
    
    @Override
    public String getSessionTimeZoneOffset() throws SQLException {
        return this.connection.getSessionTimeZoneOffset();
    }
    
    @Override
    public Connection _getPC() {
        return this.connection._getPC();
    }
    
    @Override
    public boolean isLogicalConnection() {
        return this.connection.isLogicalConnection();
    }
    
    @Override
    public void registerTAFCallback(final OracleOCIFailover oracleOCIFailover, final Object o) throws SQLException {
        this.connection.registerTAFCallback(oracleOCIFailover, o);
    }
    
    @Override
    public Properties getProperties() {
        return this.connection.getProperties();
    }
    
    @Override
    public void close(final Properties properties) throws SQLException {
        this.connection.close(properties);
    }
    
    @Override
    public void close(final int n) throws SQLException {
        this.connection.close(n);
    }
    
    @Override
    public void applyConnectionAttributes(final Properties properties) throws SQLException {
        this.connection.applyConnectionAttributes(properties);
    }
    
    @Override
    public Properties getConnectionAttributes() throws SQLException {
        return this.connection.getConnectionAttributes();
    }
    
    @Override
    public Properties getUnMatchedConnectionAttributes() throws SQLException {
        return this.connection.getUnMatchedConnectionAttributes();
    }
    
    @Override
    public void registerConnectionCacheCallback(final OracleConnectionCacheCallback oracleConnectionCacheCallback, final Object o, final int n) throws SQLException {
        this.connection.registerConnectionCacheCallback(oracleConnectionCacheCallback, o, n);
    }
    
    @Override
    public void setConnectionReleasePriority(final int connectionReleasePriority) throws SQLException {
        this.connection.setConnectionReleasePriority(connectionReleasePriority);
    }
    
    @Override
    public int getConnectionReleasePriority() throws SQLException {
        return this.connection.getConnectionReleasePriority();
    }
    
    @Override
    public void setPlsqlWarnings(final String plsqlWarnings) throws SQLException {
        this.connection.setPlsqlWarnings(plsqlWarnings);
    }
    
    @Override
    public void setHoldability(final int holdability) throws SQLException {
        this.connection.setHoldability(holdability);
    }
    
    @Override
    public int getHoldability() throws SQLException {
        return this.connection.getHoldability();
    }
    
    @Override
    public Statement createStatement(final int n, final int n2, final int n3) throws SQLException {
        return this.connection.createStatement(n, n2, n3);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int n, final int n2, final int n3) throws SQLException {
        return this.connection.prepareStatement(s, n, n2, n3);
    }
    
    @Override
    public CallableStatement prepareCall(final String s, final int n, final int n2, final int n3) throws SQLException {
        return this.connection.prepareCall(s, n, n2, n3);
    }
    
    @Override
    public synchronized Savepoint setSavepoint() throws SQLException {
        return this.connection.setSavepoint();
    }
    
    @Override
    public synchronized Savepoint setSavepoint(final String savepoint) throws SQLException {
        return this.connection.setSavepoint(savepoint);
    }
    
    @Override
    public synchronized void rollback(final Savepoint savepoint) throws SQLException {
        this.connection.rollback(savepoint);
    }
    
    @Override
    public synchronized void releaseSavepoint(final Savepoint savepoint) throws SQLException {
        this.connection.releaseSavepoint(savepoint);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int n) throws SQLException {
        return this.connection.prepareStatement(s, n);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final int[] array) throws SQLException {
        return this.connection.prepareStatement(s, array);
    }
    
    @Override
    public PreparedStatement prepareStatement(final String s, final String[] array) throws SQLException {
        return this.connection.prepareStatement(s, array);
    }
    
    @Override
    public ARRAY createARRAY(final String s, final Object o) throws SQLException {
        return this.connection.createARRAY(s, o);
    }
    
    @Override
    public BINARY_DOUBLE createBINARY_DOUBLE(final double n) throws SQLException {
        return this.connection.createBINARY_DOUBLE(n);
    }
    
    @Override
    public BINARY_FLOAT createBINARY_FLOAT(final float n) throws SQLException {
        return this.connection.createBINARY_FLOAT(n);
    }
    
    @Override
    public DATE createDATE(final Date date) throws SQLException {
        return this.connection.createDATE(date);
    }
    
    @Override
    public DATE createDATE(final Time time) throws SQLException {
        return this.connection.createDATE(time);
    }
    
    @Override
    public DATE createDATE(final Timestamp timestamp) throws SQLException {
        return this.connection.createDATE(timestamp);
    }
    
    @Override
    public DATE createDATE(final Date date, final Calendar calendar) throws SQLException {
        return this.connection.createDATE(date, calendar);
    }
    
    @Override
    public DATE createDATE(final Time time, final Calendar calendar) throws SQLException {
        return this.connection.createDATE(time, calendar);
    }
    
    @Override
    public DATE createDATE(final Timestamp timestamp, final Calendar calendar) throws SQLException {
        return this.connection.createDATE(timestamp, calendar);
    }
    
    @Override
    public DATE createDATE(final String s) throws SQLException {
        return this.connection.createDATE(s);
    }
    
    @Override
    public INTERVALDS createINTERVALDS(final String s) throws SQLException {
        return this.connection.createINTERVALDS(s);
    }
    
    @Override
    public INTERVALYM createINTERVALYM(final String s) throws SQLException {
        return this.connection.createINTERVALYM(s);
    }
    
    @Override
    public NUMBER createNUMBER(final boolean b) throws SQLException {
        return this.connection.createNUMBER(b);
    }
    
    @Override
    public NUMBER createNUMBER(final byte b) throws SQLException {
        return this.connection.createNUMBER(b);
    }
    
    @Override
    public NUMBER createNUMBER(final short n) throws SQLException {
        return this.connection.createNUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final int n) throws SQLException {
        return this.connection.createNUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final long n) throws SQLException {
        return this.connection.createNUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final float n) throws SQLException {
        return this.connection.createNUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final double n) throws SQLException {
        return this.connection.createNUMBER(n);
    }
    
    @Override
    public NUMBER createNUMBER(final BigDecimal bigDecimal) throws SQLException {
        return this.connection.createNUMBER(bigDecimal);
    }
    
    @Override
    public NUMBER createNUMBER(final BigInteger bigInteger) throws SQLException {
        return this.connection.createNUMBER(bigInteger);
    }
    
    @Override
    public NUMBER createNUMBER(final String s, final int n) throws SQLException {
        return this.connection.createNUMBER(s, n);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final Date date) throws SQLException {
        return this.connection.createTIMESTAMP(date);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final DATE date) throws SQLException {
        return this.connection.createTIMESTAMP(date);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final Time time) throws SQLException {
        return this.connection.createTIMESTAMP(time);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final Timestamp timestamp) throws SQLException {
        return this.connection.createTIMESTAMP(timestamp);
    }
    
    @Override
    public TIMESTAMP createTIMESTAMP(final String s) throws SQLException {
        return this.connection.createTIMESTAMP(s);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Date date) throws SQLException {
        return this.connection.createTIMESTAMPTZ(date);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Date date, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPTZ(date, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Time time) throws SQLException {
        return this.connection.createTIMESTAMPTZ(time);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Time time, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPTZ(time, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Timestamp timestamp) throws SQLException {
        return this.connection.createTIMESTAMPTZ(timestamp);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final Timestamp timestamp, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPTZ(timestamp, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final String s) throws SQLException {
        return this.connection.createTIMESTAMPTZ(s);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final String s, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPTZ(s, calendar);
    }
    
    @Override
    public TIMESTAMPTZ createTIMESTAMPTZ(final DATE date) throws SQLException {
        return this.connection.createTIMESTAMPTZ(date);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final Date date, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPLTZ(date, calendar);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final Time time, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPLTZ(time, calendar);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final Timestamp timestamp, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPLTZ(timestamp, calendar);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final String s, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPLTZ(s, calendar);
    }
    
    @Override
    public TIMESTAMPLTZ createTIMESTAMPLTZ(final DATE date, final Calendar calendar) throws SQLException {
        return this.connection.createTIMESTAMPLTZ(date, calendar);
    }
    
    @Override
    public Array createArrayOf(final String s, final Object[] array) throws SQLException {
        return this.connection.createArrayOf(s, array);
    }
    
    @Override
    public Blob createBlob() throws SQLException {
        return this.connection.createBlob();
    }
    
    @Override
    public Clob createClob() throws SQLException {
        return this.connection.createClob();
    }
    
    @Override
    public NClob createNClob() throws SQLException {
        return this.connection.createNClob();
    }
    
    @Override
    public SQLXML createSQLXML() throws SQLException {
        return this.connection.createSQLXML();
    }
    
    @Override
    public Struct createStruct(final String s, final Object[] array) throws SQLException {
        return this.connection.createStruct(s, array);
    }
    
    @Override
    public boolean isValid(final int n) throws SQLException {
        return this.connection.isValid(n);
    }
    
    @Override
    public void setClientInfo(final String s, final String s2) throws SQLClientInfoException {
        this.connection.setClientInfo(s, s2);
    }
    
    @Override
    public void setClientInfo(final Properties clientInfo) throws SQLClientInfoException {
        this.connection.setClientInfo(clientInfo);
    }
    
    @Override
    public String getClientInfo(final String s) throws SQLException {
        return this.connection.getClientInfo(s);
    }
    
    @Override
    public Properties getClientInfo() throws SQLException {
        return this.connection.getClientInfo();
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this) || this.connection.isWrapperFor(clazz);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected <T> T proxyFor(final Object o, final Class<T> clazz) throws SQLException {
        try {
            Object o2 = this.proxies.get(clazz);
            if (o2 == null) {
                Class<?> proxyClass = OracleConnectionWrapper.proxyClasses.get(clazz);
                if (proxyClass == null) {
                    proxyClass = Proxy.getProxyClass(clazz.getClassLoader(), clazz);
                    OracleConnectionWrapper.proxyClasses.put(clazz, proxyClass);
                }
                o2 = proxyClass.getConstructor(InvocationHandler.class).newInstance(new CloseInvocationHandler(this));
                this.proxies.put(clazz, o2);
            }
            return (T)o2;
        }
        catch (Exception ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "Cannot construct proxy");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (!clazz.isInterface()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (clazz.isInstance(this)) {
            return (T)this;
        }
        return this.proxyFor(this.connection.unwrap(clazz), clazz);
    }
    
    @Override
    public DatabaseChangeRegistration registerDatabaseChangeNotification(final Properties properties) throws SQLException {
        return this.connection.registerDatabaseChangeNotification(properties);
    }
    
    @Override
    public DatabaseChangeRegistration getDatabaseChangeRegistration(final int n) throws SQLException {
        return this.connection.getDatabaseChangeRegistration(n);
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final DatabaseChangeRegistration databaseChangeRegistration) throws SQLException {
        this.connection.unregisterDatabaseChangeNotification(databaseChangeRegistration);
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final int n, final String s, final int n2) throws SQLException {
        this.connection.unregisterDatabaseChangeNotification(n, s, n2);
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final int n) throws SQLException {
        this.connection.unregisterDatabaseChangeNotification(n);
    }
    
    @Override
    public void unregisterDatabaseChangeNotification(final long n, final String s) throws SQLException {
        this.connection.unregisterDatabaseChangeNotification(n, s);
    }
    
    @Override
    public AQNotificationRegistration[] registerAQNotification(final String[] array, final Properties[] array2, final Properties properties) throws SQLException {
        return this.connection.registerAQNotification(array, array2, properties);
    }
    
    @Override
    public void unregisterAQNotification(final AQNotificationRegistration aqNotificationRegistration) throws SQLException {
        this.connection.unregisterAQNotification(aqNotificationRegistration);
    }
    
    @Override
    public AQMessage dequeue(final String s, final AQDequeueOptions aqDequeueOptions, final byte[] array) throws SQLException {
        return this.connection.dequeue(s, aqDequeueOptions, array);
    }
    
    @Override
    public AQMessage dequeue(final String s, final AQDequeueOptions aqDequeueOptions, final String s2) throws SQLException {
        return this.connection.dequeue(s, aqDequeueOptions, s2);
    }
    
    @Override
    public void enqueue(final String s, final AQEnqueueOptions aqEnqueueOptions, final AQMessage aqMessage) throws SQLException {
        this.connection.enqueue(s, aqEnqueueOptions, aqMessage);
    }
    
    @Override
    public void commit(final EnumSet<CommitOption> set) throws SQLException {
        this.connection.commit(set);
    }
    
    @Override
    public void cancel() throws SQLException {
        this.connection.cancel();
    }
    
    @Override
    public void abort() throws SQLException {
        this.connection.abort();
    }
    
    @Override
    public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException {
        return this.connection.getAllTypeDescriptorsInCurrentSchema();
    }
    
    @Override
    public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(final String[] array) throws SQLException {
        return this.connection.getTypeDescriptorsFromListInCurrentSchema(array);
    }
    
    @Override
    public TypeDescriptor[] getTypeDescriptorsFromList(final String[][] array) throws SQLException {
        return this.connection.getTypeDescriptorsFromList(array);
    }
    
    @Override
    public String getDataIntegrityAlgorithmName() throws SQLException {
        return this.connection.getDataIntegrityAlgorithmName();
    }
    
    @Override
    public String getEncryptionAlgorithmName() throws SQLException {
        return this.connection.getEncryptionAlgorithmName();
    }
    
    @Override
    public String getAuthenticationAdaptorName() throws SQLException {
        return this.connection.getAuthenticationAdaptorName();
    }
    
    @Override
    public boolean isUsable() {
        return this.connection.isUsable();
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    @Override
    public void setDefaultTimeZone(final TimeZone defaultTimeZone) throws SQLException {
        this.connection.setDefaultTimeZone(defaultTimeZone);
    }
    
    @Override
    public TimeZone getDefaultTimeZone() throws SQLException {
        return this.connection.getDefaultTimeZone();
    }
    
    @Override
    public void setApplicationContext(final String s, final String s2, final String s3) throws SQLException {
        this.connection.setApplicationContext(s, s2, s3);
    }
    
    @Override
    public void clearAllApplicationContext(final String s) throws SQLException {
        this.connection.clearAllApplicationContext(s);
    }
    
    static {
        OracleConnectionWrapper.proxyClasses = new HashMap<Class, Class>();
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    protected class CloseInvocationHandler implements InvocationHandler
    {
        private OracleConnectionWrapper wrapper;
        
        protected CloseInvocationHandler(final OracleConnectionWrapper wrapper) {
            this.wrapper = wrapper;
        }
        
        @Override
        public Object invoke(final Object o, final Method method, final Object[] array) throws Throwable {
            try {
                return method.invoke(this.wrapper, array);
            }
            catch (IllegalArgumentException ex) {
                return method.invoke(this.wrapper.connection, array);
            }
        }
    }
}
