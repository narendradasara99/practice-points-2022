// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import oracle.xdb.XMLType;
import oracle.sql.RAW;
import oracle.sql.ANYDATA;
import oracle.sql.STRUCT;
import java.sql.SQLException;

public interface AQMessage
{
    byte[] getMessageId() throws SQLException;
    
    AQMessageProperties getMessageProperties() throws SQLException;
    
    void setPayload(final byte[] p0) throws SQLException;
    
    void setPayload(final byte[] p0, final byte[] p1) throws SQLException;
    
    void setPayload(final STRUCT p0) throws SQLException;
    
    void setPayload(final ANYDATA p0) throws SQLException;
    
    void setPayload(final RAW p0) throws SQLException;
    
    void setPayload(final XMLType p0) throws SQLException;
    
    byte[] getPayload() throws SQLException;
    
    byte[] getPayloadTOID();
    
    STRUCT getSTRUCTPayload() throws SQLException;
    
    boolean isSTRUCTPayload() throws SQLException;
    
    ANYDATA getANYDATAPayload() throws SQLException;
    
    boolean isANYDATAPayload() throws SQLException;
    
    RAW getRAWPayload() throws SQLException;
    
    boolean isRAWPayload() throws SQLException;
    
    XMLType getXMLTypePayload() throws SQLException;
    
    boolean isXMLTypePayload() throws SQLException;
    
    String toString();
}
