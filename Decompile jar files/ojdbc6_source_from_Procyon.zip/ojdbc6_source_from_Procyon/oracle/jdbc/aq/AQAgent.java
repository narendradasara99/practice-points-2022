// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.sql.SQLException;

public interface AQAgent
{
    void setAddress(final String p0) throws SQLException;
    
    String getAddress();
    
    void setName(final String p0) throws SQLException;
    
    String getName();
    
    void setProtocol(final int p0) throws SQLException;
    
    int getProtocol();
    
    String toString();
}
