// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.sql.SQLException;

public class AQEnqueueOptions
{
    private byte[] attrRelativeMessageId;
    private SequenceDeviationOption attrSequenceDeviation;
    private VisibilityOption attrVisibility;
    private DeliveryMode attrDeliveryMode;
    private boolean retrieveMsgId;
    private String transformation;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public AQEnqueueOptions() {
        this.attrRelativeMessageId = null;
        this.attrSequenceDeviation = SequenceDeviationOption.BOTTOM;
        this.attrVisibility = VisibilityOption.ON_COMMIT;
        this.attrDeliveryMode = DeliveryMode.PERSISTENT;
        this.retrieveMsgId = false;
    }
    
    @Deprecated
    public void setRelativeMessageId(final byte[] attrRelativeMessageId) throws SQLException {
        this.attrRelativeMessageId = attrRelativeMessageId;
    }
    
    public byte[] getRelativeMessageId() {
        return this.attrRelativeMessageId;
    }
    
    @Deprecated
    public void setSequenceDeviation(final SequenceDeviationOption attrSequenceDeviation) throws SQLException {
        this.attrSequenceDeviation = attrSequenceDeviation;
    }
    
    public SequenceDeviationOption getSequenceDeviation() {
        return this.attrSequenceDeviation;
    }
    
    public void setVisibility(final VisibilityOption attrVisibility) throws SQLException {
        this.attrVisibility = attrVisibility;
    }
    
    public VisibilityOption getVisibility() {
        return this.attrVisibility;
    }
    
    public void setDeliveryMode(final DeliveryMode attrDeliveryMode) throws SQLException {
        this.attrDeliveryMode = attrDeliveryMode;
    }
    
    public DeliveryMode getDeliveryMode() {
        return this.attrDeliveryMode;
    }
    
    public void setRetrieveMessageId(final boolean retrieveMsgId) {
        this.retrieveMsgId = retrieveMsgId;
    }
    
    public boolean getRetrieveMessageId() {
        return this.retrieveMsgId;
    }
    
    public void setTransformation(final String transformation) {
        this.transformation = transformation;
    }
    
    public String getTransformation() {
        return this.transformation;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    public enum VisibilityOption
    {
        ON_COMMIT(2), 
        IMMEDIATE(1);
        
        private final int mode;
        
        private VisibilityOption(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
    
    public enum SequenceDeviationOption
    {
        BOTTOM(0), 
        BEFORE(2), 
        TOP(3);
        
        private final int mode;
        
        private SequenceDeviationOption(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
    
    public enum DeliveryMode
    {
        PERSISTENT(AQDequeueOptions.DeliveryFilter.PERSISTENT.getCode()), 
        BUFFERED(AQDequeueOptions.DeliveryFilter.BUFFERED.getCode());
        
        private final int mode;
        
        private DeliveryMode(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
}
