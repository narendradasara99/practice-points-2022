// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.sql.Timestamp;
import java.sql.SQLException;

public interface AQMessageProperties
{
    public static final int MESSAGE_NO_DELAY = 0;
    public static final int MESSAGE_NO_EXPIRATION = -1;
    
    int getDequeueAttemptsCount();
    
    void setCorrelation(final String p0) throws SQLException;
    
    String getCorrelation();
    
    void setDelay(final int p0) throws SQLException;
    
    int getDelay();
    
    Timestamp getEnqueueTime();
    
    void setExceptionQueue(final String p0) throws SQLException;
    
    String getExceptionQueue();
    
    void setExpiration(final int p0) throws SQLException;
    
    int getExpiration();
    
    MessageState getState();
    
    void setPriority(final int p0) throws SQLException;
    
    int getPriority();
    
    void setRecipientList(final AQAgent[] p0) throws SQLException;
    
    AQAgent[] getRecipientList();
    
    void setSender(final AQAgent p0) throws SQLException;
    
    AQAgent getSender();
    
    String getTransactionGroup();
    
    byte[] getPreviousQueueMessageId();
    
    DeliveryMode getDeliveryMode();
    
    String toString();
    
    public enum MessageState
    {
        WAITING(1), 
        READY(0), 
        PROCESSED(2), 
        EXPIRED(3);
        
        private final int code;
        
        private MessageState(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final MessageState getMessageState(final int n) {
            if (n == MessageState.WAITING.getCode()) {
                return MessageState.WAITING;
            }
            if (n == MessageState.READY.getCode()) {
                return MessageState.READY;
            }
            if (n == MessageState.PROCESSED.getCode()) {
                return MessageState.PROCESSED;
            }
            return MessageState.EXPIRED;
        }
    }
    
    public enum DeliveryMode
    {
        PERSISTENT(1), 
        BUFFERED(2);
        
        private final int code;
        
        private DeliveryMode(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final DeliveryMode getDeliveryMode(final int n) {
            if (n == DeliveryMode.BUFFERED.getCode()) {
                return DeliveryMode.BUFFERED;
            }
            return DeliveryMode.PERSISTENT;
        }
    }
}
