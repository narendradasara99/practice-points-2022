// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;

public abstract class AQFactory
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public static AQMessage createAQMessage(final AQMessageProperties aqMessageProperties) throws SQLException {
        return InternalFactory.createAQMessage(aqMessageProperties);
    }
    
    public static AQMessageProperties createAQMessageProperties() throws SQLException {
        return InternalFactory.createAQMessageProperties();
    }
    
    public static AQAgent createAQAgent() throws SQLException {
        return InternalFactory.createAQAgent();
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
