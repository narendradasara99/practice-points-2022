// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.sql.SQLException;

public class AQDequeueOptions
{
    public static final int DEQUEUE_WAIT_FOREVER = -1;
    public static final int DEQUEUE_NO_WAIT = 0;
    private String attrConsumerName;
    private String attrCorrelation;
    private DequeueMode attrDeqMode;
    private byte[] attrDeqMsgId;
    private NavigationOption attrNavigation;
    private VisibilityOption attrVisibility;
    private int attrWait;
    private int maxBufferLength;
    private DeliveryFilter attrDeliveryMode;
    private boolean retrieveMsgId;
    private String transformation;
    private String condition;
    public static final int MAX_RAW_PAYLOAD = 67108787;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public AQDequeueOptions() {
        this.attrConsumerName = null;
        this.attrCorrelation = null;
        this.attrDeqMode = DequeueMode.REMOVE;
        this.attrDeqMsgId = null;
        this.attrNavigation = NavigationOption.NEXT_MESSAGE;
        this.attrVisibility = VisibilityOption.ON_COMMIT;
        this.attrWait = -1;
        this.maxBufferLength = 67108787;
        this.attrDeliveryMode = DeliveryFilter.PERSISTENT;
        this.retrieveMsgId = false;
    }
    
    public void setConsumerName(final String attrConsumerName) throws SQLException {
        this.attrConsumerName = attrConsumerName;
    }
    
    public String getConsumerName() {
        return this.attrConsumerName;
    }
    
    public void setCorrelation(final String attrCorrelation) throws SQLException {
        this.attrCorrelation = attrCorrelation;
    }
    
    public String getCorrelation() {
        return this.attrCorrelation;
    }
    
    public void setDequeueMode(final DequeueMode attrDeqMode) throws SQLException {
        this.attrDeqMode = attrDeqMode;
    }
    
    public DequeueMode getDequeueMode() {
        return this.attrDeqMode;
    }
    
    public void setDequeueMessageId(final byte[] attrDeqMsgId) throws SQLException {
        this.attrDeqMsgId = attrDeqMsgId;
    }
    
    public byte[] getDequeueMessageId() {
        return this.attrDeqMsgId;
    }
    
    public void setNavigation(final NavigationOption attrNavigation) throws SQLException {
        this.attrNavigation = attrNavigation;
    }
    
    public NavigationOption getNavigation() {
        return this.attrNavigation;
    }
    
    public void setVisibility(final VisibilityOption attrVisibility) throws SQLException {
        this.attrVisibility = attrVisibility;
    }
    
    public VisibilityOption getVisibility() {
        return this.attrVisibility;
    }
    
    public void setWait(final int attrWait) throws SQLException {
        this.attrWait = attrWait;
    }
    
    public int getWait() {
        return this.attrWait;
    }
    
    public void setMaximumBufferLength(final int maxBufferLength) throws SQLException {
        if (maxBufferLength > 0) {
            this.maxBufferLength = maxBufferLength;
        }
    }
    
    public int getMaximumBufferLength() {
        return this.maxBufferLength;
    }
    
    public void setDeliveryFilter(final DeliveryFilter attrDeliveryMode) throws SQLException {
        this.attrDeliveryMode = attrDeliveryMode;
    }
    
    public DeliveryFilter getDeliveryFilter() {
        return this.attrDeliveryMode;
    }
    
    public void setRetrieveMessageId(final boolean retrieveMsgId) {
        this.retrieveMsgId = retrieveMsgId;
    }
    
    public boolean getRetrieveMessageId() {
        return this.retrieveMsgId;
    }
    
    public void setTransformation(final String transformation) {
        this.transformation = transformation;
    }
    
    public String getTransformation() {
        return this.transformation;
    }
    
    public void setCondition(final String condition) {
        this.condition = condition;
    }
    
    public String getCondition() {
        return this.condition;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    public enum DequeueMode
    {
        BROWSE(1), 
        LOCKED(2), 
        REMOVE(3), 
        REMOVE_NODATA(4);
        
        private final int mode;
        
        private DequeueMode(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
    
    public enum NavigationOption
    {
        FIRST_MESSAGE(1), 
        NEXT_MESSAGE(3), 
        NEXT_TRANSACTION(2);
        
        private final int mode;
        
        private NavigationOption(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
    
    public enum VisibilityOption
    {
        ON_COMMIT(2), 
        IMMEDIATE(1);
        
        private final int mode;
        
        private VisibilityOption(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
    
    public enum DeliveryFilter
    {
        PERSISTENT(1), 
        BUFFERED(2), 
        PERSISTENT_OR_BUFFERED(3);
        
        private final int mode;
        
        private DeliveryFilter(final int mode) {
            this.mode = mode;
        }
        
        public final int getCode() {
            return this.mode;
        }
    }
}
