// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.util.EventListener;

public interface AQNotificationListener extends EventListener
{
    void onAQNotification(final AQNotificationEvent p0);
}
