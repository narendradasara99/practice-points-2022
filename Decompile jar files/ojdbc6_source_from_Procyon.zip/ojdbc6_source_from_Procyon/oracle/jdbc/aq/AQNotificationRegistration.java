// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.aq;

import java.util.concurrent.Executor;
import java.sql.SQLException;
import oracle.jdbc.NotificationRegistration;

public interface AQNotificationRegistration extends NotificationRegistration
{
    void addListener(final AQNotificationListener p0) throws SQLException;
    
    void addListener(final AQNotificationListener p0, final Executor p1) throws SQLException;
    
    void removeListener(final AQNotificationListener p0) throws SQLException;
    
    String getQueueName();
}
