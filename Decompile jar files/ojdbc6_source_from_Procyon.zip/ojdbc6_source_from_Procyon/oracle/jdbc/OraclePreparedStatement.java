// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import java.sql.SQLXML;
import java.sql.RowId;
import java.sql.NClob;
import java.net.URL;
import java.sql.Ref;
import java.sql.Timestamp;
import java.sql.Time;
import java.util.Calendar;
import java.sql.Date;
import java.io.Reader;
import java.sql.Clob;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Array;
import java.math.BigDecimal;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.StructDescriptor;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.NUMBER;
import oracle.sql.DATE;
import oracle.sql.ORAData;
import oracle.sql.CustomDatum;
import java.sql.ResultSet;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BFILE;
import oracle.sql.ARRAY;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public interface OraclePreparedStatement extends PreparedStatement, OracleStatement
{
    public static final short FORM_NCHAR = 2;
    public static final short FORM_CHAR = 1;
    
    void defineParameterTypeBytes(final int p0, final int p1, final int p2) throws SQLException;
    
    void defineParameterTypeChars(final int p0, final int p1, final int p2) throws SQLException;
    
    void defineParameterType(final int p0, final int p1, final int p2) throws SQLException;
    
    int getExecuteBatch();
    
    int sendBatch() throws SQLException;
    
    void setARRAY(final int p0, final ARRAY p1) throws SQLException;
    
    void setBfile(final int p0, final BFILE p1) throws SQLException;
    
    void setBFILE(final int p0, final BFILE p1) throws SQLException;
    
    void setBLOB(final int p0, final BLOB p1) throws SQLException;
    
    void setCHAR(final int p0, final CHAR p1) throws SQLException;
    
    void setCLOB(final int p0, final CLOB p1) throws SQLException;
    
    @Deprecated
    void setCursor(final int p0, final ResultSet p1) throws SQLException;
    
    @Deprecated
    void setCustomDatum(final int p0, final CustomDatum p1) throws SQLException;
    
    void setORAData(final int p0, final ORAData p1) throws SQLException;
    
    void setDATE(final int p0, final DATE p1) throws SQLException;
    
    void setExecuteBatch(final int p0) throws SQLException;
    
    void setFixedCHAR(final int p0, final String p1) throws SQLException;
    
    void setNUMBER(final int p0, final NUMBER p1) throws SQLException;
    
    void setBinaryFloat(final int p0, final float p1) throws SQLException;
    
    void setBinaryFloat(final int p0, final BINARY_FLOAT p1) throws SQLException;
    
    void setBinaryDouble(final int p0, final double p1) throws SQLException;
    
    void setBinaryDouble(final int p0, final BINARY_DOUBLE p1) throws SQLException;
    
    void setOPAQUE(final int p0, final OPAQUE p1) throws SQLException;
    
    void setOracleObject(final int p0, final Datum p1) throws SQLException;
    
    void setStructDescriptor(final int p0, final StructDescriptor p1) throws SQLException;
    
    void setRAW(final int p0, final RAW p1) throws SQLException;
    
    void setREF(final int p0, final REF p1) throws SQLException;
    
    void setRefType(final int p0, final REF p1) throws SQLException;
    
    void setROWID(final int p0, final ROWID p1) throws SQLException;
    
    void setSTRUCT(final int p0, final STRUCT p1) throws SQLException;
    
    void setTIMESTAMP(final int p0, final TIMESTAMP p1) throws SQLException;
    
    void setTIMESTAMPTZ(final int p0, final TIMESTAMPTZ p1) throws SQLException;
    
    void setTIMESTAMPLTZ(final int p0, final TIMESTAMPLTZ p1) throws SQLException;
    
    void setINTERVALYM(final int p0, final INTERVALYM p1) throws SQLException;
    
    void setINTERVALDS(final int p0, final INTERVALDS p1) throws SQLException;
    
    void setNullAtName(final String p0, final int p1, final String p2) throws SQLException;
    
    void setNullAtName(final String p0, final int p1) throws SQLException;
    
    void setBooleanAtName(final String p0, final boolean p1) throws SQLException;
    
    void setByteAtName(final String p0, final byte p1) throws SQLException;
    
    void setShortAtName(final String p0, final short p1) throws SQLException;
    
    void setIntAtName(final String p0, final int p1) throws SQLException;
    
    void setLongAtName(final String p0, final long p1) throws SQLException;
    
    void setFloatAtName(final String p0, final float p1) throws SQLException;
    
    void setDoubleAtName(final String p0, final double p1) throws SQLException;
    
    void setBinaryFloatAtName(final String p0, final float p1) throws SQLException;
    
    void setBinaryFloatAtName(final String p0, final BINARY_FLOAT p1) throws SQLException;
    
    void setBinaryDoubleAtName(final String p0, final double p1) throws SQLException;
    
    void setBinaryDoubleAtName(final String p0, final BINARY_DOUBLE p1) throws SQLException;
    
    void setBigDecimalAtName(final String p0, final BigDecimal p1) throws SQLException;
    
    void setStringAtName(final String p0, final String p1) throws SQLException;
    
    void setStringForClob(final int p0, final String p1) throws SQLException;
    
    void setStringForClobAtName(final String p0, final String p1) throws SQLException;
    
    void setFixedCHARAtName(final String p0, final String p1) throws SQLException;
    
    void setCursorAtName(final String p0, final ResultSet p1) throws SQLException;
    
    void setROWIDAtName(final String p0, final ROWID p1) throws SQLException;
    
    void setArrayAtName(final String p0, final Array p1) throws SQLException;
    
    void setARRAYAtName(final String p0, final ARRAY p1) throws SQLException;
    
    void setOPAQUEAtName(final String p0, final OPAQUE p1) throws SQLException;
    
    void setStructDescriptorAtName(final String p0, final StructDescriptor p1) throws SQLException;
    
    void setSTRUCTAtName(final String p0, final STRUCT p1) throws SQLException;
    
    void setRAWAtName(final String p0, final RAW p1) throws SQLException;
    
    void setCHARAtName(final String p0, final CHAR p1) throws SQLException;
    
    void setDATEAtName(final String p0, final DATE p1) throws SQLException;
    
    void setNUMBERAtName(final String p0, final NUMBER p1) throws SQLException;
    
    void setBLOBAtName(final String p0, final BLOB p1) throws SQLException;
    
    void setBlobAtName(final String p0, final Blob p1) throws SQLException;
    
    void setBlobAtName(final String p0, final InputStream p1, final long p2) throws SQLException;
    
    void setBlobAtName(final String p0, final InputStream p1) throws SQLException;
    
    void setCLOBAtName(final String p0, final CLOB p1) throws SQLException;
    
    void setClobAtName(final String p0, final Clob p1) throws SQLException;
    
    void setClobAtName(final String p0, final Reader p1, final long p2) throws SQLException;
    
    void setClobAtName(final String p0, final Reader p1) throws SQLException;
    
    void setBFILEAtName(final String p0, final BFILE p1) throws SQLException;
    
    void setBfileAtName(final String p0, final BFILE p1) throws SQLException;
    
    void setBytesAtName(final String p0, final byte[] p1) throws SQLException;
    
    void setBytesForBlob(final int p0, final byte[] p1) throws SQLException;
    
    void setBytesForBlobAtName(final String p0, final byte[] p1) throws SQLException;
    
    void setDateAtName(final String p0, final Date p1) throws SQLException;
    
    void setDateAtName(final String p0, final Date p1, final Calendar p2) throws SQLException;
    
    void setTimeAtName(final String p0, final Time p1) throws SQLException;
    
    void setTimeAtName(final String p0, final Time p1, final Calendar p2) throws SQLException;
    
    void setTimestampAtName(final String p0, final Timestamp p1) throws SQLException;
    
    void setTimestampAtName(final String p0, final Timestamp p1, final Calendar p2) throws SQLException;
    
    void setINTERVALYMAtName(final String p0, final INTERVALYM p1) throws SQLException;
    
    void setINTERVALDSAtName(final String p0, final INTERVALDS p1) throws SQLException;
    
    void setTIMESTAMPAtName(final String p0, final TIMESTAMP p1) throws SQLException;
    
    void setTIMESTAMPTZAtName(final String p0, final TIMESTAMPTZ p1) throws SQLException;
    
    void setTIMESTAMPLTZAtName(final String p0, final TIMESTAMPLTZ p1) throws SQLException;
    
    void setAsciiStreamAtName(final String p0, final InputStream p1, final int p2) throws SQLException;
    
    void setAsciiStreamAtName(final String p0, final InputStream p1, final long p2) throws SQLException;
    
    void setAsciiStreamAtName(final String p0, final InputStream p1) throws SQLException;
    
    void setBinaryStreamAtName(final String p0, final InputStream p1, final int p2) throws SQLException;
    
    void setBinaryStreamAtName(final String p0, final InputStream p1, final long p2) throws SQLException;
    
    void setBinaryStreamAtName(final String p0, final InputStream p1) throws SQLException;
    
    void setCharacterStreamAtName(final String p0, final Reader p1, final long p2) throws SQLException;
    
    void setCharacterStreamAtName(final String p0, final Reader p1) throws SQLException;
    
    void setUnicodeStreamAtName(final String p0, final InputStream p1, final int p2) throws SQLException;
    
    void setCustomDatumAtName(final String p0, final CustomDatum p1) throws SQLException;
    
    void setORADataAtName(final String p0, final ORAData p1) throws SQLException;
    
    void setObjectAtName(final String p0, final Object p1, final int p2, final int p3) throws SQLException;
    
    void setObjectAtName(final String p0, final Object p1, final int p2) throws SQLException;
    
    void setRefTypeAtName(final String p0, final REF p1) throws SQLException;
    
    void setRefAtName(final String p0, final Ref p1) throws SQLException;
    
    void setREFAtName(final String p0, final REF p1) throws SQLException;
    
    void setObjectAtName(final String p0, final Object p1) throws SQLException;
    
    void setOracleObjectAtName(final String p0, final Datum p1) throws SQLException;
    
    void setURLAtName(final String p0, final URL p1) throws SQLException;
    
    void setCheckBindTypes(final boolean p0);
    
    void setPlsqlIndexTable(final int p0, final Object p1, final int p2, final int p3, final int p4, final int p5) throws SQLException;
    
    void setFormOfUse(final int p0, final short p1);
    
    void setDisableStmtCaching(final boolean p0);
    
    OracleParameterMetaData OracleGetParameterMetaData() throws SQLException;
    
    void registerReturnParameter(final int p0, final int p1) throws SQLException;
    
    void registerReturnParameter(final int p0, final int p1, final int p2) throws SQLException;
    
    void registerReturnParameter(final int p0, final int p1, final String p2) throws SQLException;
    
    ResultSet getReturnResultSet() throws SQLException;
    
    void setNCharacterStreamAtName(final String p0, final Reader p1, final long p2) throws SQLException;
    
    void setNCharacterStreamAtName(final String p0, final Reader p1) throws SQLException;
    
    void setNClobAtName(final String p0, final NClob p1) throws SQLException;
    
    void setNClobAtName(final String p0, final Reader p1, final long p2) throws SQLException;
    
    void setNClobAtName(final String p0, final Reader p1) throws SQLException;
    
    void setNStringAtName(final String p0, final String p1) throws SQLException;
    
    void setRowIdAtName(final String p0, final RowId p1) throws SQLException;
    
    void setSQLXMLAtName(final String p0, final SQLXML p1) throws SQLException;
}
