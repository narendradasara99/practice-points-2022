// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import java.sql.SQLException;
import java.sql.ResultSetMetaData;

public interface OracleResultSetMetaData extends ResultSetMetaData
{
    boolean isNCHAR(final int p0) throws SQLException;
    
    SecurityAttribute getSecurityAttribute(final int p0) throws SQLException;
    
    public enum SecurityAttribute
    {
        NONE, 
        ENABLED, 
        UNKNOWN;
    }
}
