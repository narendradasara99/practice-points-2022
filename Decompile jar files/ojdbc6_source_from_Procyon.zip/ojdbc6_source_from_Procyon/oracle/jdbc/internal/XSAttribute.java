// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;

public abstract class XSAttribute
{
    public static final XSAttribute constructXSAttribute() throws SQLException {
        return InternalFactory.createXSAttribute();
    }
    
    public abstract void setAttributeName(final String p0) throws SQLException;
    
    public abstract void setAttributeValue(final String p0) throws SQLException;
    
    public abstract void setAttributeDefaultValue(final String p0) throws SQLException;
    
    public abstract void setFlag(final long p0) throws SQLException;
    
    public abstract String getAttributeName();
    
    public abstract String getAttributeValue();
    
    public abstract String getAttributeDefaultValue();
    
    public abstract long getFlag();
}
