// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

public interface ClientDataSupport
{
    Object getClientData(final Object p0);
    
    Object setClientData(final Object p0, final Object p1);
    
    Object removeClientData(final Object p0);
}
