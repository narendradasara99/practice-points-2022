// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import oracle.jdbc.driver.InternalFactory;
import java.sql.SQLException;

public abstract class KeywordValueLong
{
    public abstract int getKeyword() throws SQLException;
    
    public abstract byte[] getBinaryValue() throws SQLException;
    
    public abstract String getTextValue() throws SQLException;
    
    public static final KeywordValueLong constructKeywordValue(final int n, final String s) throws SQLException {
        return InternalFactory.createKeywordValueLong(n, s, null);
    }
    
    public static final KeywordValueLong constructKeywordValue(final int n, final byte[] array) throws SQLException {
        return InternalFactory.createKeywordValueLong(n, null, array);
    }
}
