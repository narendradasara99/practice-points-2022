// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.util.EventObject;

public abstract class XSEvent extends EventObject
{
    protected XSEvent(final Object source) {
        super(source);
    }
    
    public abstract byte[] getSessionId();
    
    public abstract KeywordValueLong[] getDetails();
    
    public abstract int getFlags();
}
