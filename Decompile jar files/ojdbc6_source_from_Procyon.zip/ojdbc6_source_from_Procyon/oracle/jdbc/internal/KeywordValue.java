// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import oracle.jdbc.driver.InternalFactory;
import java.sql.SQLException;

public abstract class KeywordValue
{
    public abstract int getKeyword() throws SQLException;
    
    public abstract byte[] getBinaryValue() throws SQLException;
    
    public abstract String getTextValue() throws SQLException;
    
    public static final KeywordValue constructKeywordValue(final int n, final String s) throws SQLException {
        return InternalFactory.createKeywordValue(n, s, null);
    }
    
    public static final KeywordValue constructKeywordValue(final int n, final byte[] array) throws SQLException {
        return InternalFactory.createKeywordValue(n, null, array);
    }
}
