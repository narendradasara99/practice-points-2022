// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import oracle.sql.TIMEZONETAB;
import java.util.concurrent.Executor;
import javax.transaction.xa.XAResource;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import java.sql.Connection;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.oracore.OracleTypeADT;
import java.sql.ResultSetMetaData;
import oracle.sql.StructDescriptor;
import oracle.sql.ArrayDescriptor;
import oracle.sql.ARRAY;
import java.sql.ResultSet;
import oracle.sql.Datum;
import oracle.sql.CustomDatum;
import java.util.Enumeration;
import oracle.sql.ClobDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.BfileDBAccess;
import java.util.Properties;
import java.util.Map;
import java.sql.SQLException;

public interface OracleConnection extends oracle.jdbc.OracleConnection
{
    public static final String CONNECTION_PROPERTY_LOGON_CAP = "oracle.jdbc.thinLogonCapability";
    public static final String CONNECTION_PROPERTY_LOGON_CAP_DEFAULT = "o5";
    public static final byte CONNECTION_PROPERTY_LOGON_CAP_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR = "oracle.jdbc.ociNlsLangBackwardCompatible";
    public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL = "oracle.jdbc.spawnNewThreadToCancel";
    public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR = "oracle.jdbc.overrideEnableReadDataInLocator";
    public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
    public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_ACCESSMODE = 3;
    public static final int CHAR_TO_ASCII = 0;
    public static final int CHAR_TO_UNICODE = 1;
    public static final int RAW_TO_ASCII = 2;
    public static final int RAW_TO_UNICODE = 3;
    public static final int UNICODE_TO_CHAR = 4;
    public static final int ASCII_TO_CHAR = 5;
    public static final int NONE = 6;
    public static final int JAVACHAR_TO_CHAR = 7;
    public static final int RAW_TO_JAVACHAR = 8;
    public static final int CHAR_TO_JAVACHAR = 9;
    public static final int GLOBAL_TXN = 1;
    public static final int NO_GLOBAL_TXN = 0;
    
    short getStructAttrNCsId() throws SQLException;
    
    Map getTypeMap() throws SQLException;
    
    Properties getDBAccessProperties() throws SQLException;
    
    Properties getOCIHandles() throws SQLException;
    
    String getDatabaseProductVersion() throws SQLException;
    
    String getURL() throws SQLException;
    
    short getVersionNumber() throws SQLException;
    
    Map getJavaObjectTypeMap();
    
    void setJavaObjectTypeMap(final Map p0);
    
    byte getInstanceProperty(final InstanceProperty p0) throws SQLException;
    
    BfileDBAccess createBfileDBAccess() throws SQLException;
    
    BlobDBAccess createBlobDBAccess() throws SQLException;
    
    ClobDBAccess createClobDBAccess() throws SQLException;
    
    void setDefaultFixedString(final boolean p0);
    
    boolean getDefaultFixedString();
    
    oracle.jdbc.OracleConnection getWrapper();
    
    Class classForNameAndSchema(final String p0, final String p1) throws ClassNotFoundException;
    
    void setFDO(final byte[] p0) throws SQLException;
    
    byte[] getFDO(final boolean p0) throws SQLException;
    
    boolean getBigEndian() throws SQLException;
    
    Object getDescriptor(final byte[] p0);
    
    void putDescriptor(final byte[] p0, final Object p1) throws SQLException;
    
    OracleConnection getPhysicalConnection();
    
    void removeDescriptor(final String p0);
    
    void removeAllDescriptor();
    
    int numberOfDescriptorCacheEntries();
    
    Enumeration descriptorCacheKeys();
    
    long getTdoCState(final String p0, final String p1) throws SQLException;
    
    BufferCacheStatistics getByteBufferCacheStatistics();
    
    BufferCacheStatistics getCharBufferCacheStatistics();
    
    Datum toDatum(final CustomDatum p0) throws SQLException;
    
    short getDbCsId() throws SQLException;
    
    short getJdbcCsId() throws SQLException;
    
    short getNCharSet();
    
    ResultSet newArrayDataResultSet(final Datum[] p0, final long p1, final int p2, final Map p3) throws SQLException;
    
    ResultSet newArrayDataResultSet(final ARRAY p0, final long p1, final int p2, final Map p3) throws SQLException;
    
    ResultSet newArrayLocatorResultSet(final ArrayDescriptor p0, final byte[] p1, final long p2, final int p3, final Map p4) throws SQLException;
    
    ResultSetMetaData newStructMetaData(final StructDescriptor p0) throws SQLException;
    
    void getForm(final OracleTypeADT p0, final OracleTypeCLOB p1, final int p2) throws SQLException;
    
    int CHARBytesToJavaChars(final byte[] p0, final int p1, final char[] p2) throws SQLException;
    
    int NCHARBytesToJavaChars(final byte[] p0, final int p1, final char[] p2) throws SQLException;
    
    boolean IsNCharFixedWith();
    
    short getDriverCharSet();
    
    int getC2SNlsRatio();
    
    int getMaxCharSize() throws SQLException;
    
    int getMaxCharbyteSize();
    
    int getMaxNCharbyteSize();
    
    boolean isCharSetMultibyte(final short p0);
    
    int javaCharsToCHARBytes(final char[] p0, final int p1, final byte[] p2) throws SQLException;
    
    int javaCharsToNCHARBytes(final char[] p0, final int p1, final byte[] p2) throws SQLException;
    
    void setStartTime(final long p0) throws SQLException;
    
    long getStartTime() throws SQLException;
    
    boolean isStatementCacheInitialized();
    
    void getPropertyForPooledConnection(final OraclePooledConnection p0) throws SQLException;
    
    void setTypeMap(final Map p0) throws SQLException;
    
    String getProtocolType();
    
    Connection getLogicalConnection(final OraclePooledConnection p0, final boolean p1) throws SQLException;
    
    void setTxnMode(final int p0);
    
    int getTxnMode();
    
    int getHeapAllocSize() throws SQLException;
    
    int getOCIEnvHeapAllocSize() throws SQLException;
    
    void setAbandonedTimeoutEnabled(final boolean p0) throws SQLException;
    
    int getHeartbeatNoChangeCount() throws SQLException;
    
    void closeInternal(final boolean p0) throws SQLException;
    
    void cleanupAndClose(final boolean p0) throws SQLException;
    
    OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException;
    
    Object getConnectionCacheCallbackPrivObj() throws SQLException;
    
    int getConnectionCacheCallbackFlag() throws SQLException;
    
    Properties getServerSessionInfo() throws SQLException;
    
    CLOB createClob(final byte[] p0) throws SQLException;
    
    CLOB createClobWithUnpickledBytes(final byte[] p0) throws SQLException;
    
    CLOB createClob(final byte[] p0, final short p1) throws SQLException;
    
    BLOB createBlob(final byte[] p0) throws SQLException;
    
    BLOB createBlobWithUnpickledBytes(final byte[] p0) throws SQLException;
    
    BFILE createBfile(final byte[] p0) throws SQLException;
    
    boolean isDescriptorSharable(final OracleConnection p0) throws SQLException;
    
    OracleStatement refCursorCursorToStatement(final int p0) throws SQLException;
    
    XAResource getXAResource() throws SQLException;
    
    @Deprecated
    boolean isV8Compatible() throws SQLException;
    
    boolean getMapDateToTimestamp();
    
    boolean isGetObjectReturnsXMLType();
    
    byte[] createLightweightSession(final String p0, final KeywordValueLong[] p1, final int p2, final KeywordValueLong[][] p3, final int[] p4) throws SQLException;
    
    void executeLightweightSessionRoundtrip(final int p0, final byte[] p1, final KeywordValueLong[] p2, final int p3, final KeywordValueLong[][] p4, final int[] p5) throws SQLException;
    
    void executeLightweightSessionPiggyback(final int p0, final byte[] p1, final KeywordValueLong[] p2, final int p3) throws SQLException;
    
    void doXSNamespaceOp(final XSOperationCode p0, final byte[] p1, final XSNamespace[] p2, final XSNamespace[][] p3) throws SQLException;
    
    void doXSNamespaceOp(final XSOperationCode p0, final byte[] p1, final XSNamespace[] p2) throws SQLException;
    
    String getDefaultSchemaNameForNamedTypes() throws SQLException;
    
    void setUsable(final boolean p0);
    
    Class getClassForType(final String p0, final Map<String, Class> p1);
    
    void addXSEventListener(final XSEventListener p0) throws SQLException;
    
    void addXSEventListener(final XSEventListener p0, final Executor p1) throws SQLException;
    
    void removeXSEventListener(final XSEventListener p0) throws SQLException;
    
    int getTimezoneVersionNumber() throws SQLException;
    
    TIMEZONETAB getTIMEZONETAB() throws SQLException;
    
    String getDatabaseTimeZone() throws SQLException;
    
    boolean getTimestamptzInGmt();
    
    boolean isDataInLocatorEnabled() throws SQLException;
    
    public enum InstanceProperty
    {
        ASM_VOLUME_SUPPORTED, 
        INSTANCE_TYPE;
    }
    
    public enum XSOperationCode
    {
        NAMESPACE_CREATE(1), 
        NAMESPACE_DELETE(2), 
        ATTRIBUTE_CREATE(3), 
        ATTRIBUTE_SET(4), 
        ATTRIBUTE_DELETE(5), 
        ATTRIBUTE_RESET(6);
        
        private final int code;
        
        private XSOperationCode(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
    }
    
    public interface BufferCacheStatistics
    {
        int getId();
        
        int[] getBufferSizes();
        
        int getCacheHits(final int p0);
        
        int getCacheMisses(final int p0);
        
        int getBuffersCached(final int p0);
        
        int getBucketsFull(final int p0);
        
        int getReferencesCleared(final int p0);
        
        int getTooBigToCache();
    }
}
