// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.sql.SQLException;

public interface OracleStatement extends oracle.jdbc.OracleStatement
{
    public static final int DEFAULT_RSET_TYPE = 1;
    public static final int CLOSED = 0;
    public static final int ACTIVE = 1;
    public static final int CACHED = 2;
    public static final int NON_CACHED = 3;
    
    void setFixedString(final boolean p0);
    
    boolean getFixedString();
    
    int sendBatch() throws SQLException;
    
    boolean getserverCursor();
    
    int getcacheState();
    
    int getstatementType();
}
