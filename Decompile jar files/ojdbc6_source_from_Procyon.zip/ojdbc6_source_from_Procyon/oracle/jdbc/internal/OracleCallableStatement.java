// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.io.Reader;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.SQLException;

public interface OracleCallableStatement extends oracle.jdbc.OracleCallableStatement, OraclePreparedStatement
{
    byte[] privateGetBytes(final int p0) throws SQLException;
    
    @Deprecated
    BigDecimal getBigDecimal(final String p0, final int p1) throws SQLException;
    
    @Deprecated
    InputStream getAsciiStream(final String p0) throws SQLException;
    
    @Deprecated
    Reader getCharacterStream(final String p0) throws SQLException;
}
