// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.util.EventListener;

public interface XSEventListener extends EventListener
{
    void onXSEvent(final XSEvent p0);
}
