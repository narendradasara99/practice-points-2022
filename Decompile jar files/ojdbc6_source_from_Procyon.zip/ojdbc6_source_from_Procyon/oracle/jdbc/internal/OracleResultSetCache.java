// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

public interface OracleResultSetCache extends oracle.jdbc.OracleResultSetCache
{
}
