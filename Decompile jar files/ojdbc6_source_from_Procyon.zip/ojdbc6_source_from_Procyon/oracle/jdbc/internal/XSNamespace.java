// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import oracle.sql.TIMESTAMPTZ;
import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;

public abstract class XSNamespace
{
    public static final int ACL_ID_LENGTH = 16;
    
    public static final XSNamespace constructXSNamespace() throws SQLException {
        return InternalFactory.createXSNamespace();
    }
    
    public abstract void setNamespaceName(final String p0) throws SQLException;
    
    public abstract void setTimestamp(final TIMESTAMPTZ p0) throws SQLException;
    
    public abstract void setFlag(final long p0) throws SQLException;
    
    public abstract void setAttributes(final XSAttribute[] p0) throws SQLException;
    
    public abstract void setACLIdList(final byte[][] p0) throws SQLException;
    
    public abstract String getNamespaceName();
    
    public abstract TIMESTAMPTZ getTimestamp();
    
    public abstract long getFlag();
    
    public abstract XSAttribute[] getAttributes();
    
    public abstract byte[][] getACLIdList();
}
