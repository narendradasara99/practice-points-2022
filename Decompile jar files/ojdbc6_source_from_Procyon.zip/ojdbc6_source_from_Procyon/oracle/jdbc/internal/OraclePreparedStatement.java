// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.io.Reader;
import java.sql.SQLException;

public interface OraclePreparedStatement extends oracle.jdbc.OraclePreparedStatement, OracleStatement
{
    void setCheckBindTypes(final boolean p0);
    
    void setInternalBytes(final int p0, final byte[] p1, final int p2) throws SQLException;
    
    void enterImplicitCache() throws SQLException;
    
    void enterExplicitCache() throws SQLException;
    
    void exitImplicitCacheToActive() throws SQLException;
    
    void exitExplicitCacheToActive() throws SQLException;
    
    void exitImplicitCacheToClose() throws SQLException;
    
    void exitExplicitCacheToClose() throws SQLException;
    
    @Deprecated
    void setCharacterStreamAtName(final String p0, final Reader p1, final int p2) throws SQLException;
    
    String getOriginalSql() throws SQLException;
}
