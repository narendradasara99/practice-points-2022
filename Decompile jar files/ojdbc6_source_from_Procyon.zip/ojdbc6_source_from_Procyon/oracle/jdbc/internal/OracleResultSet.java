// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.internal;

import java.sql.SQLException;

public interface OracleResultSet extends oracle.jdbc.OracleResultSet
{
    void closeStatementOnClose() throws SQLException;
}
