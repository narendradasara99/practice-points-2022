// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.dcn;

public interface QueryChangeDescription
{
    long getQueryId();
    
    QueryChangeEventType getQueryChangeEventType();
    
    TableChangeDescription[] getTableChangeDescription();
    
    public enum QueryChangeEventType
    {
        DEREG(DatabaseChangeEvent.EventType.DEREG.getCode()), 
        QUERYCHANGE(DatabaseChangeEvent.EventType.QUERYCHANGE.getCode());
        
        private final int code;
        
        private QueryChangeEventType(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final QueryChangeEventType getQueryChangeEventType(final int n) {
            if (n == QueryChangeEventType.DEREG.getCode()) {
                return QueryChangeEventType.DEREG;
            }
            return QueryChangeEventType.QUERYCHANGE;
        }
    }
}
