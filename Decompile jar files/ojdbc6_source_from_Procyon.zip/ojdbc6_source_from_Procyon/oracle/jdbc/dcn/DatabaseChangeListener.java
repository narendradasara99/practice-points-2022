// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.dcn;

import java.util.EventListener;

public interface DatabaseChangeListener extends EventListener
{
    void onDatabaseChangeNotification(final DatabaseChangeEvent p0);
}
