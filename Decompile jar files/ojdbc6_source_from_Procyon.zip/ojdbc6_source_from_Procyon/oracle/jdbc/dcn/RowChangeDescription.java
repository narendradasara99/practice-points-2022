// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.dcn;

import oracle.sql.ROWID;

public interface RowChangeDescription
{
    RowOperation getRowOperation();
    
    ROWID getRowid();
    
    public enum RowOperation
    {
        INSERT(TableChangeDescription.TableOperation.INSERT.getCode()), 
        UPDATE(TableChangeDescription.TableOperation.UPDATE.getCode()), 
        DELETE(TableChangeDescription.TableOperation.DELETE.getCode());
        
        private final int code;
        
        private RowOperation(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final RowOperation getRowOperation(final int n) {
            if (n == RowOperation.INSERT.getCode()) {
                return RowOperation.INSERT;
            }
            if (n == RowOperation.UPDATE.getCode()) {
                return RowOperation.UPDATE;
            }
            return RowOperation.DELETE;
        }
    }
}
