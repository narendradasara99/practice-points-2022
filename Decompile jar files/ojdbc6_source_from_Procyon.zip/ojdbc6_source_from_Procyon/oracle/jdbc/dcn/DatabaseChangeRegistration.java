// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.dcn;

import java.util.concurrent.Executor;
import java.sql.SQLException;
import oracle.jdbc.NotificationRegistration;

public interface DatabaseChangeRegistration extends NotificationRegistration
{
    @Deprecated
    int getRegistrationId();
    
    long getRegId();
    
    String[] getTables();
    
    void addListener(final DatabaseChangeListener p0) throws SQLException;
    
    void addListener(final DatabaseChangeListener p0, final Executor p1) throws SQLException;
    
    void removeListener(final DatabaseChangeListener p0) throws SQLException;
}
