// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.dcn;

import java.util.EnumSet;

public interface TableChangeDescription
{
    EnumSet<TableOperation> getTableOperations();
    
    String getTableName();
    
    int getObjectNumber();
    
    RowChangeDescription[] getRowChangeDescription();
    
    public enum TableOperation
    {
        ALL_ROWS(1), 
        INSERT(2), 
        UPDATE(4), 
        DELETE(8), 
        ALTER(16), 
        DROP(32);
        
        private final int code;
        
        private TableOperation(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final EnumSet<TableOperation> getTableOperations(final int n) {
            final EnumSet<TableOperation> none = EnumSet.noneOf(TableOperation.class);
            if ((n & TableOperation.ALL_ROWS.getCode()) != 0x0) {
                none.add(TableOperation.ALL_ROWS);
            }
            if ((n & TableOperation.INSERT.getCode()) != 0x0) {
                none.add(TableOperation.INSERT);
            }
            if ((n & TableOperation.UPDATE.getCode()) != 0x0) {
                none.add(TableOperation.UPDATE);
            }
            if ((n & TableOperation.DELETE.getCode()) != 0x0) {
                none.add(TableOperation.DELETE);
            }
            if ((n & TableOperation.ALTER.getCode()) != 0x0) {
                none.add(TableOperation.ALTER);
            }
            if ((n & TableOperation.DROP.getCode()) != 0x0) {
                none.add(TableOperation.DROP);
            }
            return none;
        }
    }
}
