// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.dcn;

import java.util.EventObject;

public abstract class DatabaseChangeEvent extends EventObject
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    protected DatabaseChangeEvent(final Object source) {
        super(source);
    }
    
    public abstract EventType getEventType();
    
    public abstract AdditionalEventType getAdditionalEventType();
    
    public abstract TableChangeDescription[] getTableChangeDescription();
    
    public abstract QueryChangeDescription[] getQueryChangeDescription();
    
    public abstract String getConnectionInformation();
    
    public abstract String getDatabaseName();
    
    @Deprecated
    public abstract int getRegistrationId();
    
    public abstract long getRegId();
    
    public abstract byte[] getTransactionId();
    
    public abstract String getTransactionId(final boolean p0);
    
    @Override
    public abstract String toString();
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    public enum EventType
    {
        NONE(0), 
        STARTUP(1), 
        SHUTDOWN(2), 
        SHUTDOWN_ANY(3), 
        DEREG(5), 
        OBJCHANGE(6), 
        QUERYCHANGE(7);
        
        private final int code;
        
        private EventType(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final EventType getEventType(final int n) {
            if (n == EventType.STARTUP.getCode()) {
                return EventType.STARTUP;
            }
            if (n == EventType.SHUTDOWN.getCode()) {
                return EventType.SHUTDOWN;
            }
            if (n == EventType.SHUTDOWN_ANY.getCode()) {
                return EventType.SHUTDOWN_ANY;
            }
            if (n == EventType.DEREG.getCode()) {
                return EventType.DEREG;
            }
            if (n == EventType.OBJCHANGE.getCode()) {
                return EventType.OBJCHANGE;
            }
            if (n == EventType.QUERYCHANGE.getCode()) {
                return EventType.QUERYCHANGE;
            }
            return EventType.NONE;
        }
    }
    
    public enum AdditionalEventType
    {
        NONE(0), 
        TIMEOUT(1), 
        GROUPING(2);
        
        private final int code;
        
        private AdditionalEventType(final int code) {
            this.code = code;
        }
        
        public final int getCode() {
            return this.code;
        }
        
        public static final AdditionalEventType getEventType(final int n) {
            if (n == AdditionalEventType.TIMEOUT.getCode()) {
                return AdditionalEventType.TIMEOUT;
            }
            if (n == AdditionalEventType.GROUPING.getCode()) {
                return AdditionalEventType.GROUPING;
            }
            return AdditionalEventType.NONE;
        }
    }
}
