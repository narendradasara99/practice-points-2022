// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc;

import oracle.sql.STRUCT;
import oracle.sql.ROWID;
import oracle.sql.REF;
import oracle.sql.RAW;
import oracle.sql.Datum;
import oracle.sql.NUMBER;
import oracle.sql.DATE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMESTAMP;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.OPAQUE;
import oracle.sql.CLOB;
import oracle.sql.CHAR;
import oracle.sql.BLOB;
import oracle.sql.BFILE;
import java.sql.SQLException;
import oracle.sql.ARRAY;
import java.sql.ResultSet;

public interface OracleResultSet extends ResultSet
{
    public static final int HOLD_CURSORS_OVER_COMMIT = 1;
    public static final int CLOSE_CURSORS_AT_COMMIT = 2;
    
    ARRAY getARRAY(final int p0) throws SQLException;
    
    ARRAY getARRAY(final String p0) throws SQLException;
    
    BFILE getBfile(final int p0) throws SQLException;
    
    BFILE getBFILE(final int p0) throws SQLException;
    
    BFILE getBfile(final String p0) throws SQLException;
    
    BFILE getBFILE(final String p0) throws SQLException;
    
    BLOB getBLOB(final int p0) throws SQLException;
    
    BLOB getBLOB(final String p0) throws SQLException;
    
    CHAR getCHAR(final int p0) throws SQLException;
    
    CHAR getCHAR(final String p0) throws SQLException;
    
    CLOB getCLOB(final int p0) throws SQLException;
    
    CLOB getCLOB(final String p0) throws SQLException;
    
    OPAQUE getOPAQUE(final int p0) throws SQLException;
    
    OPAQUE getOPAQUE(final String p0) throws SQLException;
    
    INTERVALYM getINTERVALYM(final int p0) throws SQLException;
    
    INTERVALYM getINTERVALYM(final String p0) throws SQLException;
    
    INTERVALDS getINTERVALDS(final int p0) throws SQLException;
    
    INTERVALDS getINTERVALDS(final String p0) throws SQLException;
    
    TIMESTAMP getTIMESTAMP(final int p0) throws SQLException;
    
    TIMESTAMP getTIMESTAMP(final String p0) throws SQLException;
    
    TIMESTAMPTZ getTIMESTAMPTZ(final int p0) throws SQLException;
    
    TIMESTAMPTZ getTIMESTAMPTZ(final String p0) throws SQLException;
    
    TIMESTAMPLTZ getTIMESTAMPLTZ(final int p0) throws SQLException;
    
    TIMESTAMPLTZ getTIMESTAMPLTZ(final String p0) throws SQLException;
    
    ResultSet getCursor(final int p0) throws SQLException;
    
    ResultSet getCursor(final String p0) throws SQLException;
    
    @Deprecated
    CustomDatum getCustomDatum(final int p0, final CustomDatumFactory p1) throws SQLException;
    
    ORAData getORAData(final int p0, final ORADataFactory p1) throws SQLException;
    
    @Deprecated
    CustomDatum getCustomDatum(final String p0, final CustomDatumFactory p1) throws SQLException;
    
    ORAData getORAData(final String p0, final ORADataFactory p1) throws SQLException;
    
    DATE getDATE(final int p0) throws SQLException;
    
    DATE getDATE(final String p0) throws SQLException;
    
    NUMBER getNUMBER(final int p0) throws SQLException;
    
    NUMBER getNUMBER(final String p0) throws SQLException;
    
    Datum getOracleObject(final int p0) throws SQLException;
    
    Datum getOracleObject(final String p0) throws SQLException;
    
    RAW getRAW(final int p0) throws SQLException;
    
    RAW getRAW(final String p0) throws SQLException;
    
    REF getREF(final int p0) throws SQLException;
    
    REF getREF(final String p0) throws SQLException;
    
    ROWID getROWID(final int p0) throws SQLException;
    
    ROWID getROWID(final String p0) throws SQLException;
    
    STRUCT getSTRUCT(final int p0) throws SQLException;
    
    STRUCT getSTRUCT(final String p0) throws SQLException;
    
    void updateARRAY(final int p0, final ARRAY p1) throws SQLException;
    
    void updateARRAY(final String p0, final ARRAY p1) throws SQLException;
    
    void updateBfile(final int p0, final BFILE p1) throws SQLException;
    
    void updateBFILE(final int p0, final BFILE p1) throws SQLException;
    
    void updateBfile(final String p0, final BFILE p1) throws SQLException;
    
    void updateBFILE(final String p0, final BFILE p1) throws SQLException;
    
    void updateBLOB(final int p0, final BLOB p1) throws SQLException;
    
    void updateBLOB(final String p0, final BLOB p1) throws SQLException;
    
    void updateCHAR(final int p0, final CHAR p1) throws SQLException;
    
    void updateCHAR(final String p0, final CHAR p1) throws SQLException;
    
    void updateCLOB(final int p0, final CLOB p1) throws SQLException;
    
    void updateCLOB(final String p0, final CLOB p1) throws SQLException;
    
    @Deprecated
    void updateCustomDatum(final int p0, final CustomDatum p1) throws SQLException;
    
    void updateORAData(final int p0, final ORAData p1) throws SQLException;
    
    @Deprecated
    void updateCustomDatum(final String p0, final CustomDatum p1) throws SQLException;
    
    void updateORAData(final String p0, final ORAData p1) throws SQLException;
    
    void updateDATE(final int p0, final DATE p1) throws SQLException;
    
    void updateDATE(final String p0, final DATE p1) throws SQLException;
    
    void updateINTERVALYM(final int p0, final INTERVALYM p1) throws SQLException;
    
    void updateINTERVALYM(final String p0, final INTERVALYM p1) throws SQLException;
    
    void updateINTERVALDS(final int p0, final INTERVALDS p1) throws SQLException;
    
    void updateINTERVALDS(final String p0, final INTERVALDS p1) throws SQLException;
    
    void updateTIMESTAMP(final int p0, final TIMESTAMP p1) throws SQLException;
    
    void updateTIMESTAMP(final String p0, final TIMESTAMP p1) throws SQLException;
    
    void updateTIMESTAMPTZ(final int p0, final TIMESTAMPTZ p1) throws SQLException;
    
    void updateTIMESTAMPTZ(final String p0, final TIMESTAMPTZ p1) throws SQLException;
    
    void updateTIMESTAMPLTZ(final int p0, final TIMESTAMPLTZ p1) throws SQLException;
    
    void updateTIMESTAMPLTZ(final String p0, final TIMESTAMPLTZ p1) throws SQLException;
    
    void updateNUMBER(final int p0, final NUMBER p1) throws SQLException;
    
    void updateNUMBER(final String p0, final NUMBER p1) throws SQLException;
    
    void updateOracleObject(final int p0, final Datum p1) throws SQLException;
    
    void updateOracleObject(final String p0, final Datum p1) throws SQLException;
    
    void updateRAW(final int p0, final RAW p1) throws SQLException;
    
    void updateRAW(final String p0, final RAW p1) throws SQLException;
    
    void updateREF(final int p0, final REF p1) throws SQLException;
    
    void updateREF(final String p0, final REF p1) throws SQLException;
    
    void updateROWID(final int p0, final ROWID p1) throws SQLException;
    
    void updateROWID(final String p0, final ROWID p1) throws SQLException;
    
    void updateSTRUCT(final int p0, final STRUCT p1) throws SQLException;
    
    void updateSTRUCT(final String p0, final STRUCT p1) throws SQLException;
    
    AuthorizationIndicator getAuthorizationIndicator(final int p0) throws SQLException;
    
    AuthorizationIndicator getAuthorizationIndicator(final String p0) throws SQLException;
    
    public enum AuthorizationIndicator
    {
        NONE, 
        UNAUTHORIZED, 
        UNKNOWN;
    }
}
