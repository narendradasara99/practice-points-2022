// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;
import java.util.StringTokenizer;
import oracle.jdbc.driver.DatabaseError;
import javax.naming.StringRefAddr;
import oracle.jdbc.xa.client.OracleXADataSource;
import java.util.Properties;
import javax.naming.Reference;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.ObjectFactory;

public class OracleDataSourceFactory implements ObjectFactory
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    @Override
    public Object getObjectInstance(final Object o, final Name name, final Context context, final Hashtable hashtable) throws Exception {
        final Reference reference = (Reference)o;
        final String className = reference.getClassName();
        final Properties poolConfig = new Properties();
        OracleDataSource oracleDataSource;
        if (className.equals("oracle.jdbc.pool.OracleDataSource") || className.equals("oracle.jdbc.xa.client.OracleXADataSource")) {
            if (className.equals("oracle.jdbc.pool.OracleDataSource")) {
                oracleDataSource = new OracleDataSource();
            }
            else {
                oracleDataSource = new OracleXADataSource();
            }
            final StringRefAddr stringRefAddr;
            if ((stringRefAddr = (StringRefAddr)reference.get("connectionCachingEnabled")) != null && ((String)stringRefAddr.getContent()).equals(String.valueOf("true"))) {
                oracleDataSource.setConnectionCachingEnabled(true);
            }
            final StringRefAddr stringRefAddr2;
            if ((stringRefAddr2 = (StringRefAddr)reference.get("connectionCacheName")) != null) {
                oracleDataSource.setConnectionCacheName((String)stringRefAddr2.getContent());
            }
            final StringRefAddr stringRefAddr3;
            if ((stringRefAddr3 = (StringRefAddr)reference.get("connectionCacheProperties")) != null) {
                oracleDataSource.setConnectionCacheProperties(this.extractConnectionCacheProperties((String)stringRefAddr3.getContent()));
            }
            final StringRefAddr stringRefAddr4;
            if ((stringRefAddr4 = (StringRefAddr)reference.get("fastConnectionFailoverEnabled")) != null && ((String)stringRefAddr4.getContent()).equals(String.valueOf("true"))) {
                oracleDataSource.setFastConnectionFailoverEnabled(true);
            }
            final StringRefAddr stringRefAddr5;
            if ((stringRefAddr5 = (StringRefAddr)reference.get("onsConfigStr")) != null) {
                oracleDataSource.setONSConfiguration((String)stringRefAddr5.getContent());
            }
        }
        else if (className.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource")) {
            oracleDataSource = new OracleConnectionPoolDataSource();
        }
        else {
            if (!className.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
                return null;
            }
            oracleDataSource = new OracleOCIConnectionPool();
            Object value = null;
            Object value2 = null;
            Object value3 = null;
            Object value4 = null;
            Object value5 = null;
            Object value6 = null;
            String value7 = null;
            String value8 = null;
            final StringRefAddr stringRefAddr6;
            if ((stringRefAddr6 = (StringRefAddr)reference.get("connpool_min_limit")) != null) {
                value = stringRefAddr6.getContent();
            }
            final StringRefAddr stringRefAddr7;
            if ((stringRefAddr7 = (StringRefAddr)reference.get("connpool_max_limit")) != null) {
                value2 = stringRefAddr7.getContent();
            }
            final StringRefAddr stringRefAddr8;
            if ((stringRefAddr8 = (StringRefAddr)reference.get("connpool_increment")) != null) {
                value3 = stringRefAddr8.getContent();
            }
            final StringRefAddr stringRefAddr9;
            if ((stringRefAddr9 = (StringRefAddr)reference.get("connpool_active_size")) != null) {
                value4 = stringRefAddr9.getContent();
            }
            final StringRefAddr stringRefAddr10;
            if ((stringRefAddr10 = (StringRefAddr)reference.get("connpool_pool_size")) != null) {
                value5 = stringRefAddr10.getContent();
            }
            final StringRefAddr stringRefAddr11;
            if ((stringRefAddr11 = (StringRefAddr)reference.get("connpool_timeout")) != null) {
                value6 = stringRefAddr11.getContent();
            }
            final StringRefAddr stringRefAddr12;
            if ((stringRefAddr12 = (StringRefAddr)reference.get("connpool_nowait")) != null) {
                value7 = (String)stringRefAddr12.getContent();
            }
            final StringRefAddr stringRefAddr13;
            if ((stringRefAddr13 = (StringRefAddr)reference.get("transactions_distributed")) != null) {
                value8 = (String)stringRefAddr13.getContent();
            }
            poolConfig.put("connpool_min_limit", value);
            poolConfig.put("connpool_max_limit", value2);
            poolConfig.put("connpool_increment", value3);
            poolConfig.put("connpool_active_size", value4);
            poolConfig.put("connpool_pool_size", value5);
            poolConfig.put("connpool_timeout", value6);
            if (value7 == "true") {
                poolConfig.put("connpool_nowait", value7);
            }
            if (value8 == "true") {
                poolConfig.put("transactions_distributed", value8);
            }
        }
        if (oracleDataSource != null) {
            final StringRefAddr stringRefAddr14;
            if ((stringRefAddr14 = (StringRefAddr)reference.get("url")) != null) {
                oracleDataSource.setURL((String)stringRefAddr14.getContent());
            }
            StringRefAddr stringRefAddr15;
            if ((stringRefAddr15 = (StringRefAddr)reference.get("userName")) != null || (stringRefAddr15 = (StringRefAddr)reference.get("u")) != null || (stringRefAddr15 = (StringRefAddr)reference.get("user")) != null) {
                oracleDataSource.setUser((String)stringRefAddr15.getContent());
            }
            StringRefAddr stringRefAddr16;
            if ((stringRefAddr16 = (StringRefAddr)reference.get("passWord")) != null || (stringRefAddr16 = (StringRefAddr)reference.get("password")) != null) {
                oracleDataSource.setPassword((String)stringRefAddr16.getContent());
            }
            StringRefAddr stringRefAddr17;
            if ((stringRefAddr17 = (StringRefAddr)reference.get("description")) != null || (stringRefAddr17 = (StringRefAddr)reference.get("describe")) != null) {
                oracleDataSource.setDescription((String)stringRefAddr17.getContent());
            }
            StringRefAddr stringRefAddr18;
            if ((stringRefAddr18 = (StringRefAddr)reference.get("driverType")) != null || (stringRefAddr18 = (StringRefAddr)reference.get("driver")) != null) {
                oracleDataSource.setDriverType((String)stringRefAddr18.getContent());
            }
            StringRefAddr stringRefAddr19;
            if ((stringRefAddr19 = (StringRefAddr)reference.get("serverName")) != null || (stringRefAddr19 = (StringRefAddr)reference.get("host")) != null) {
                oracleDataSource.setServerName((String)stringRefAddr19.getContent());
            }
            StringRefAddr stringRefAddr20;
            if ((stringRefAddr20 = (StringRefAddr)reference.get("databaseName")) != null || (stringRefAddr20 = (StringRefAddr)reference.get("sid")) != null) {
                oracleDataSource.setDatabaseName((String)stringRefAddr20.getContent());
            }
            final StringRefAddr stringRefAddr21;
            if ((stringRefAddr21 = (StringRefAddr)reference.get("serviceName")) != null) {
                oracleDataSource.setServiceName((String)stringRefAddr21.getContent());
            }
            StringRefAddr stringRefAddr22;
            if ((stringRefAddr22 = (StringRefAddr)reference.get("networkProtocol")) != null || (stringRefAddr22 = (StringRefAddr)reference.get("protocol")) != null) {
                oracleDataSource.setNetworkProtocol((String)stringRefAddr22.getContent());
            }
            StringRefAddr stringRefAddr23;
            if ((stringRefAddr23 = (StringRefAddr)reference.get("portNumber")) != null || (stringRefAddr23 = (StringRefAddr)reference.get("port")) != null) {
                oracleDataSource.setPortNumber(Integer.parseInt((String)stringRefAddr23.getContent()));
            }
            StringRefAddr stringRefAddr24;
            if ((stringRefAddr24 = (StringRefAddr)reference.get("tnsentryname")) != null || (stringRefAddr24 = (StringRefAddr)reference.get("tns")) != null) {
                oracleDataSource.setTNSEntryName((String)stringRefAddr24.getContent());
            }
            else if (className.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
                String s = null;
                final StringRefAddr stringRefAddr25;
                if ((stringRefAddr25 = (StringRefAddr)reference.get("connpool_is_poolcreated")) != null) {
                    s = (String)stringRefAddr25.getContent();
                }
                if (s.equals(String.valueOf("true"))) {
                    ((OracleOCIConnectionPool)oracleDataSource).setPoolConfig(poolConfig);
                }
            }
        }
        return oracleDataSource;
    }
    
    private Properties extractConnectionCacheProperties(String str) throws SQLException {
        final Properties properties = new Properties();
        str = str.substring(1, str.length() - 1);
        final int index = str.indexOf("AttributeWeights", 0);
        if (index >= 0) {
            if (str.charAt(index + 16) != '=' || (index > 0 && str.charAt(index - 1) != ' ')) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 139);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            final Properties value = new Properties();
            final int index2 = str.indexOf("}", index);
            final StringTokenizer stringTokenizer = new StringTokenizer(str.substring(index, index2).substring(18), ", ");
            synchronized (stringTokenizer) {
                while (stringTokenizer.hasMoreTokens()) {
                    final String nextToken = stringTokenizer.nextToken();
                    final int length = nextToken.length();
                    final int index3 = nextToken.indexOf("=");
                    value.setProperty(nextToken.substring(0, index3), nextToken.substring(index3 + 1, length));
                }
            }
            properties.put("AttributeWeights", value);
            if (index > 0 && index2 + 1 == str.length()) {
                str = str.substring(0, index - 2);
            }
            else if (index > 0 && index2 + 1 < str.length()) {
                str = str.substring(0, index - 2).concat(str.substring(index2 + 1, str.length()));
            }
            else {
                str = str.substring(index2 + 2, str.length());
            }
        }
        final StringTokenizer stringTokenizer2 = new StringTokenizer(str, ", ");
        synchronized (stringTokenizer2) {
            while (stringTokenizer2.hasMoreTokens()) {
                final String nextToken2 = stringTokenizer2.nextToken();
                final int length2 = nextToken2.length();
                final int index4 = nextToken2.indexOf("=");
                properties.setProperty(nextToken2.substring(0, index4), nextToken2.substring(index4 + 1, length2));
            }
        }
        return properties;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
