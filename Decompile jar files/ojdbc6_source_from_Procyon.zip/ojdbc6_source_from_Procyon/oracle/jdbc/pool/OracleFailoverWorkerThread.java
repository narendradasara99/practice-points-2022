// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.sql.SQLException;

class OracleFailoverWorkerThread extends Thread
{
    protected OracleImplicitConnectionCache implicitCache;
    protected int eventType;
    protected String eventServiceName;
    protected String instanceNameKey;
    protected String databaseNameKey;
    protected String hostNameKey;
    protected String status;
    protected int cardinality;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleFailoverWorkerThread(final OracleImplicitConnectionCache implicitCache, final int eventType, final String instanceNameKey, final String databaseNameKey, final String hostNameKey, final String status, final int cardinality) throws SQLException {
        this.implicitCache = null;
        this.eventType = 0;
        this.eventServiceName = null;
        this.instanceNameKey = null;
        this.databaseNameKey = null;
        this.hostNameKey = null;
        this.status = null;
        this.cardinality = 0;
        this.implicitCache = implicitCache;
        this.eventType = eventType;
        this.instanceNameKey = instanceNameKey;
        this.databaseNameKey = databaseNameKey;
        this.hostNameKey = hostNameKey;
        this.status = status;
        this.cardinality = cardinality;
    }
    
    @Override
    public void run() {
        try {
            if (this.status != null) {
                this.implicitCache.processFailoverEvent(this.eventType, this.instanceNameKey, this.databaseNameKey, this.hostNameKey, this.status, this.cardinality);
            }
        }
        catch (Exception ex) {}
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
