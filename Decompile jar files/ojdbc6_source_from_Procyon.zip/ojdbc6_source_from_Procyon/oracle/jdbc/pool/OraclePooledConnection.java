// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import javax.sql.StatementEventListener;
import java.util.Map;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import javax.transaction.xa.XAResource;
import java.util.HashMap;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.util.Enumeration;
import javax.sql.ConnectionEvent;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import oracle.jdbc.driver.OracleDriver;
import oracle.jdbc.driver.OracleCloseCallback;
import java.util.Properties;
import oracle.jdbc.internal.OracleConnection;
import javax.sql.ConnectionEventListener;
import java.sql.SQLException;
import java.util.Hashtable;
import java.io.Serializable;
import javax.sql.PooledConnection;

public class OraclePooledConnection implements PooledConnection, Serializable
{
    static final long serialVersionUID = -203725628718322873L;
    public static final String url_string = "connection_url";
    public static final String pool_auto_commit_string = "pool_auto_commit";
    public static final String object_type_map = "obj_type_map";
    public static final String transaction_isolation = "trans_isolation";
    public static final String statement_cache_size = "stmt_cache_size";
    public static final String isClearMetaData = "stmt_cache_clear_metadata";
    public static final String ImplicitStatementCachingEnabled = "ImplicitStatementCachingEnabled";
    public static final String ExplicitStatementCachingEnabled = "ExplicitStatementCachingEnabled";
    public static final String LoginTimeout = "LoginTimeout";
    public static final String connect_auto_commit_string = "connect_auto_commit";
    public static final String implicit_caching_enabled = "implicit_cache_enabled";
    public static final String explicit_caching_enabled = "explict_cache_enabled";
    public static final String connection_properties_string = "connection_properties";
    public static final String event_listener_string = "event_listener";
    public static final String sql_exception_string = "sql_exception";
    public static final String close_callback_string = "close_callback";
    public static final String private_data = "private_data";
    static final int CONNECTION_CLOSED_EVENT = 101;
    static final int CONNECTION_ERROROCCURED_EVENT = 102;
    private Hashtable eventListeners;
    private SQLException sqlException;
    protected boolean autoCommit;
    private ConnectionEventListener iccEventListener;
    protected transient OracleConnection logicalHandle;
    protected transient OracleConnection physicalConn;
    private Hashtable connectionProperty;
    public Properties cachedConnectionAttributes;
    public Properties unMatchedCachedConnAttr;
    public int closeOption;
    private String pcKey;
    private OracleCloseCallback closeCallback;
    private Object privateData;
    private long lastAccessedTime;
    protected String dataSourceInstanceNameKey;
    protected String dataSourceHostNameKey;
    protected String dataSourceDbUniqNameKey;
    protected boolean connectionMarkedDown;
    protected boolean needToAbort;
    protected transient OracleDriver oracleDriver;
    boolean localTxnCommitOnClose;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OraclePooledConnection() {
        this((Connection)null);
    }
    
    public OraclePooledConnection(final String s) throws SQLException {
        this.eventListeners = null;
        this.sqlException = null;
        this.autoCommit = true;
        this.iccEventListener = null;
        this.logicalHandle = null;
        this.physicalConn = null;
        this.connectionProperty = null;
        this.cachedConnectionAttributes = null;
        this.unMatchedCachedConnAttr = null;
        this.closeOption = 0;
        this.pcKey = null;
        this.closeCallback = null;
        this.privateData = null;
        this.lastAccessedTime = 0L;
        this.dataSourceInstanceNameKey = null;
        this.dataSourceHostNameKey = null;
        this.dataSourceDbUniqNameKey = null;
        this.connectionMarkedDown = false;
        this.needToAbort = false;
        this.oracleDriver = new OracleDriver();
        this.localTxnCommitOnClose = false;
        final Connection connect = this.oracleDriver.connect(s, new Properties());
        if (connect == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.initialize(connect);
    }
    
    public OraclePooledConnection(final String s, final String value, final String value2) throws SQLException {
        this.eventListeners = null;
        this.sqlException = null;
        this.autoCommit = true;
        this.iccEventListener = null;
        this.logicalHandle = null;
        this.physicalConn = null;
        this.connectionProperty = null;
        this.cachedConnectionAttributes = null;
        this.unMatchedCachedConnAttr = null;
        this.closeOption = 0;
        this.pcKey = null;
        this.closeCallback = null;
        this.privateData = null;
        this.lastAccessedTime = 0L;
        this.dataSourceInstanceNameKey = null;
        this.dataSourceHostNameKey = null;
        this.dataSourceDbUniqNameKey = null;
        this.connectionMarkedDown = false;
        this.needToAbort = false;
        this.oracleDriver = new OracleDriver();
        this.localTxnCommitOnClose = false;
        final Properties properties = new Properties();
        properties.put("user", value);
        properties.put("password", value2);
        final Connection connect = this.oracleDriver.connect(s, properties);
        if (connect == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.initialize(connect);
    }
    
    public OraclePooledConnection(final Connection connection) {
        this.eventListeners = null;
        this.sqlException = null;
        this.autoCommit = true;
        this.iccEventListener = null;
        this.logicalHandle = null;
        this.physicalConn = null;
        this.connectionProperty = null;
        this.cachedConnectionAttributes = null;
        this.unMatchedCachedConnAttr = null;
        this.closeOption = 0;
        this.pcKey = null;
        this.closeCallback = null;
        this.privateData = null;
        this.lastAccessedTime = 0L;
        this.dataSourceInstanceNameKey = null;
        this.dataSourceHostNameKey = null;
        this.dataSourceDbUniqNameKey = null;
        this.connectionMarkedDown = false;
        this.needToAbort = false;
        this.oracleDriver = new OracleDriver();
        this.localTxnCommitOnClose = false;
        this.initialize(connection);
    }
    
    public OraclePooledConnection(final Connection connection, final boolean autoCommit) {
        this(connection);
        this.autoCommit = autoCommit;
    }
    
    private void initialize(final Connection connection) {
        this.physicalConn = (OracleConnection)connection;
        this.eventListeners = new Hashtable(10);
        this.closeCallback = null;
        this.privateData = null;
        this.lastAccessedTime = 0L;
    }
    
    @Override
    public synchronized void addConnectionEventListener(final ConnectionEventListener connectionEventListener) {
        if (this.eventListeners == null) {
            this.sqlException = new SQLException("Listener Hashtable Null");
        }
        else {
            this.eventListeners.put(connectionEventListener, connectionEventListener);
        }
    }
    
    @Override
    public synchronized void close() throws SQLException {
        if (this.closeCallback != null) {
            this.closeCallback.beforeClose(this.physicalConn, this.privateData);
        }
        if (this.physicalConn != null) {
            try {
                this.physicalConn.close();
            }
            catch (SQLException ex) {}
            this.physicalConn = null;
        }
        if (this.closeCallback != null) {
            this.closeCallback.afterClose(this.privateData);
        }
        this.lastAccessedTime = 0L;
        this.iccEventListener = null;
    }
    
    @Override
    public synchronized Connection getConnection() throws SQLException {
        if (this.physicalConn == null) {
            this.sqlException = new SQLException("Physical Connection doesn't exist");
            this.callListener(102);
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        try {
            if (this.logicalHandle != null) {
                this.logicalHandle.closeInternal(false);
            }
            this.logicalHandle = (OracleConnection)this.physicalConn.getLogicalConnection(this, this.autoCommit);
        }
        catch (SQLException sqlException2) {
            this.sqlException = sqlException2;
            this.callListener(102);
            this.callImplicitCacheListener(102);
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8, "OraclePooledConnection.getConnection() - SQLException Ocurred:" + sqlException2.getMessage());
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        return this.logicalHandle;
    }
    
    public Connection getLogicalHandle() throws SQLException {
        return this.logicalHandle;
    }
    
    public Connection getPhysicalHandle() throws SQLException {
        return this.physicalConn;
    }
    
    public synchronized void setLastAccessedTime(final long lastAccessedTime) throws SQLException {
        this.lastAccessedTime = lastAccessedTime;
    }
    
    public long getLastAccessedTime() throws SQLException {
        return this.lastAccessedTime;
    }
    
    public synchronized void registerCloseCallback(final OracleCloseCallback closeCallback, final Object privateData) {
        this.closeCallback = closeCallback;
        this.privateData = privateData;
    }
    
    @Override
    public synchronized void removeConnectionEventListener(final ConnectionEventListener key) {
        if (this.eventListeners == null) {
            this.sqlException = new SQLException("Listener Hashtable Null");
        }
        else {
            this.eventListeners.remove(key);
        }
    }
    
    public synchronized void registerImplicitCacheConnectionEventListener(final ConnectionEventListener iccEventListener) {
        if (this.iccEventListener != null) {
            this.sqlException = new SQLException("Implicit cache listeneralready registered");
        }
        else {
            this.iccEventListener = iccEventListener;
        }
    }
    
    public void logicalCloseForImplicitConnectionCache() {
        if (this.closeOption == 4096) {
            this.callImplicitCacheListener(102);
        }
        else {
            this.callImplicitCacheListener(101);
        }
    }
    
    public void logicalClose() {
        if (this.cachedConnectionAttributes != null) {
            this.logicalCloseForImplicitConnectionCache();
        }
        else {
            this.callListener(101);
        }
    }
    
    private void callListener(final int n) {
        if (this.eventListeners == null) {
            return;
        }
        final Enumeration<ConnectionEventListener> keys = this.eventListeners.keys();
        final ConnectionEvent connectionEvent = new ConnectionEvent(this, this.sqlException);
        while (keys.hasMoreElements()) {
            final ConnectionEventListener connectionEventListener = this.eventListeners.get(keys.nextElement());
            if (n == 101) {
                connectionEventListener.connectionClosed(connectionEvent);
            }
            else {
                if (n != 102) {
                    continue;
                }
                connectionEventListener.connectionErrorOccurred(connectionEvent);
            }
        }
    }
    
    private void callImplicitCacheListener(final int n) {
        if (this.iccEventListener == null) {
            return;
        }
        final ConnectionEvent connectionEvent = new ConnectionEvent(this, this.sqlException);
        switch (n) {
            case 101: {
                this.iccEventListener.connectionClosed(connectionEvent);
                break;
            }
            case 102: {
                this.iccEventListener.connectionErrorOccurred(connectionEvent);
                break;
            }
        }
    }
    
    @Deprecated
    public synchronized void setStmtCacheSize(final int n) throws SQLException {
        this.setStmtCacheSize(n, false);
    }
    
    @Deprecated
    public synchronized void setStmtCacheSize(final int n, final boolean b) throws SQLException {
        if (n < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.physicalConn != null) {
            this.physicalConn.setStmtCacheSize(n, b);
        }
    }
    
    @Deprecated
    public synchronized int getStmtCacheSize() {
        if (this.physicalConn != null) {
            return this.physicalConn.getStmtCacheSize();
        }
        return 0;
    }
    
    public void setStatementCacheSize(final int statementCacheSize) throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.setStatementCacheSize(statementCacheSize);
        }
    }
    
    public int getStatementCacheSize() throws SQLException {
        if (this.physicalConn != null) {
            return this.physicalConn.getStatementCacheSize();
        }
        return 0;
    }
    
    public void setImplicitCachingEnabled(final boolean implicitCachingEnabled) throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.setImplicitCachingEnabled(implicitCachingEnabled);
        }
    }
    
    public boolean getImplicitCachingEnabled() throws SQLException {
        return this.physicalConn != null && this.physicalConn.getImplicitCachingEnabled();
    }
    
    public void setExplicitCachingEnabled(final boolean explicitCachingEnabled) throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.setExplicitCachingEnabled(explicitCachingEnabled);
        }
    }
    
    public boolean getExplicitCachingEnabled() throws SQLException {
        return this.physicalConn != null && this.physicalConn.getExplicitCachingEnabled();
    }
    
    public void purgeImplicitCache() throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.purgeImplicitCache();
        }
    }
    
    public void purgeExplicitCache() throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.purgeExplicitCache();
        }
    }
    
    public PreparedStatement getStatementWithKey(final String s) throws SQLException {
        if (this.physicalConn != null) {
            return this.physicalConn.getStatementWithKey(s);
        }
        return null;
    }
    
    public CallableStatement getCallWithKey(final String s) throws SQLException {
        if (this.physicalConn != null) {
            return this.physicalConn.getCallWithKey(s);
        }
        return null;
    }
    
    public boolean isStatementCacheInitialized() {
        return this.physicalConn != null && this.physicalConn.isStatementCacheInitialized();
    }
    
    public final void setProperties(final Hashtable connectionProperty) {
        this.connectionProperty = connectionProperty;
    }
    
    public final void setUserName(final String s, final String s2) {
        this.pcKey = generateKey(s, s2);
    }
    
    static final String generateKey(final String s, final String str) {
        return s.toUpperCase() + str;
    }
    
    final OracleConnectionCacheEntry addToImplicitCache(final HashMap hashMap, final OracleConnectionCacheEntry value) {
        return hashMap.put(this.pcKey, value);
    }
    
    final OracleConnectionCacheEntry removeFromImplictCache(final HashMap hashMap) {
        return hashMap.get(this.pcKey);
    }
    
    final boolean isSameUser(final String str, final String str2) {
        return str != null && str2 != null && this.pcKey.equalsIgnoreCase(str + str2);
    }
    
    public XAResource getXAResource() throws SQLException {
        final SQLException unsupportedFeatureSqlException = DatabaseError.createUnsupportedFeatureSqlException();
        unsupportedFeatureSqlException.fillInStackTrace();
        throw unsupportedFeatureSqlException;
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        try {
            this.physicalConn.getPropertyForPooledConnection(this);
            if (this.eventListeners != null) {
                this.connectionProperty.put("event_listener", this.eventListeners);
            }
            if (this.sqlException != null) {
                this.connectionProperty.put("sql_exception", this.sqlException);
            }
            this.connectionProperty.put("pool_auto_commit", "" + this.autoCommit);
            if (this.closeCallback != null) {
                this.connectionProperty.put("close_callback", this.closeCallback);
            }
            if (this.privateData != null) {
                this.connectionProperty.put("private_data", this.privateData);
            }
            objectOutputStream.writeObject(this.connectionProperty);
            this.physicalConn.close();
        }
        catch (SQLException ex) {}
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException, SQLException {
        objectInputStream.defaultReadObject();
        this.connectionProperty = (Hashtable)objectInputStream.readObject();
        try {
            final Properties properties = this.connectionProperty.get("connection_properties");
            final String property = properties.getProperty("connection_url");
            this.oracleDriver = new OracleDriver();
            final Connection connect = this.oracleDriver.connect(property, properties);
            this.initialize(connect);
            this.eventListeners = this.connectionProperty.get("event_listener");
            this.sqlException = this.connectionProperty.get("sql_exception");
            this.autoCommit = this.connectionProperty.get("pool_auto_commit").equals("true");
            this.closeCallback = this.connectionProperty.get("close_callback");
            this.privateData = this.connectionProperty.get("private_data");
            final Map typeMap = this.connectionProperty.get("obj_type_map");
            if (typeMap != null) {
                ((OracleConnection)connect).setTypeMap(typeMap);
            }
            connect.setTransactionIsolation(Integer.parseInt(properties.getProperty("trans_isolation")));
            final int int1 = Integer.parseInt(properties.getProperty("stmt_cache_size"));
            if (int1 != -1) {
                this.setStatementCacheSize(int1);
                final String property2 = properties.getProperty("implicit_cache_enabled");
                if (property2 != null && property2.equalsIgnoreCase("true")) {
                    this.setImplicitCachingEnabled(true);
                }
                else {
                    this.setImplicitCachingEnabled(false);
                }
                final String property3 = properties.getProperty("explict_cache_enabled");
                if (property3 != null && property3.equalsIgnoreCase("true")) {
                    this.setExplicitCachingEnabled(true);
                }
                else {
                    this.setExplicitCachingEnabled(false);
                }
            }
            this.physicalConn.setAutoCommit(((String)properties.get("connect_auto_commit")).equals("true"));
        }
        catch (Exception ex) {}
    }
    
    @Override
    public void addStatementEventListener(final StatementEventListener statementEventListener) {
    }
    
    @Override
    public void removeStatementEventListener(final StatementEventListener statementEventListener) {
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
