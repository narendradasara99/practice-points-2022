// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

public interface OracleConnectionCacheCallback
{
    @Deprecated
    boolean handleAbandonedConnection(final OracleConnection p0, final Object p1);
    
    @Deprecated
    void releaseConnection(final OracleConnection p0, final Object p1);
}
