// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import oracle.jdbc.internal.OracleConnection;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import java.io.UnsupportedEncodingException;
import java.util.StringTokenizer;
import javax.sql.ConnectionPoolDataSource;
import java.security.PrivilegedActionException;
import java.security.AccessController;
import oracle.ons.ONSException;
import oracle.ons.ONS;
import java.security.PrivilegedExceptionAction;
import oracle.jdbc.driver.DatabaseError;
import java.util.Properties;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Hashtable;

public class OracleConnectionCacheManager
{
    private static OracleConnectionCacheManager cacheManagerInstance;
    protected Hashtable m_connCache;
    public static final int REFRESH_INVALID_CONNECTIONS = 4096;
    public static final int REFRESH_ALL_CONNECTIONS = 8192;
    public static final String PHYSICAL_CONNECTION_CREATED_COUNT = "PhysicalConnectionCreatedCount";
    public static final String PHYSICAL_CONNECTION_CLOSED_COUNT = "PhysicalConnectionClosedCount";
    protected static final int FAILOVER_EVENT_TYPE_SERVICE = 256;
    protected static final int FAILOVER_EVENT_TYPE_HOST = 512;
    protected static final String EVENT_DELIMITER = "{} =";
    protected OracleFailoverEventHandlerThread failoverEventHandlerThread;
    private static boolean isONSInitializedForRemoteSubscription;
    static final int ORAERROR_END_OF_FILE_ON_COM_CHANNEL = 3113;
    static final int ORAERROR_NOT_CONNECTED_TO_ORACLE = 3114;
    static final int ORAERROR_INIT_SHUTDOWN_IN_PROGRESS = 1033;
    static final int ORAERROR_ORACLE_NOT_AVAILABLE = 1034;
    static final int ORAERROR_IMMEDIATE_SHUTDOWN_IN_PROGRESS = 1089;
    static final int ORAERROR_SHUTDOWN_IN_PROGRESS_NO_CONN = 1090;
    static final int ORAERROR_NET_IO_EXCEPTION = 17002;
    protected int[] fatalErrorCodes;
    protected int failoverEnabledCacheCount;
    protected static AtomicInteger UNNAMED_CACHE_COUNT;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    private OracleConnectionCacheManager() {
        this.m_connCache = null;
        this.failoverEventHandlerThread = null;
        this.fatalErrorCodes = null;
        this.failoverEnabledCacheCount = 0;
        this.m_connCache = new Hashtable();
        OracleConnectionCacheManager.UNNAMED_CACHE_COUNT = new AtomicInteger();
    }
    
    @Deprecated
    public static synchronized OracleConnectionCacheManager getConnectionCacheManagerInstance() throws SQLException {
        try {
            if (OracleConnectionCacheManager.cacheManagerInstance == null) {
                OracleConnectionCacheManager.cacheManagerInstance = new OracleConnectionCacheManager();
            }
        }
        catch (RuntimeException ex) {}
        return OracleConnectionCacheManager.cacheManagerInstance;
    }
    
    @Deprecated
    public String createCache(final OracleDataSource oracleDataSource, final Properties properties) throws SQLException {
        if (oracleDataSource == null || !oracleDataSource.getConnectionCachingEnabled()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 137);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        String s;
        if (oracleDataSource.connCacheName != null) {
            s = oracleDataSource.connCacheName;
        }
        else {
            s = oracleDataSource.dataSourceName + "#0x" + Integer.toHexString(OracleConnectionCacheManager.UNNAMED_CACHE_COUNT.getAndIncrement());
        }
        this.createCache(s, oracleDataSource, properties);
        return s;
    }
    
    @Deprecated
    public void createCache(final String key, final OracleDataSource oracleDataSource, final Properties properties) throws SQLException {
        if (oracleDataSource == null || !oracleDataSource.getConnectionCachingEnabled()) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 137);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (key == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 138);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        if (this.m_connCache.containsKey(key)) {
            final SQLException sqlException3 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 140);
            sqlException3.fillInStackTrace();
            throw sqlException3;
        }
        final boolean fastConnectionFailoverEnabled = oracleDataSource.getFastConnectionFailoverEnabled();
        if (fastConnectionFailoverEnabled && this.failoverEventHandlerThread == null) {
            final String onsConfiguration = oracleDataSource.getONSConfiguration();
            if (onsConfiguration != null && !onsConfiguration.equals("")) {
                synchronized (this) {
                    if (!OracleConnectionCacheManager.isONSInitializedForRemoteSubscription) {
                        try {
                            AccessController.doPrivileged((PrivilegedExceptionAction<Object>)new PrivilegedExceptionAction() {
                                @Override
                                public Object run() throws ONSException {
                                    final ONS ons = new ONS(onsConfiguration);
                                    return null;
                                }
                            });
                        }
                        catch (PrivilegedActionException ex) {
                            final SQLException sqlException4 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 175, ex);
                            sqlException4.fillInStackTrace();
                            throw sqlException4;
                        }
                        OracleConnectionCacheManager.isONSInitializedForRemoteSubscription = true;
                    }
                }
            }
            this.failoverEventHandlerThread = new OracleFailoverEventHandlerThread();
        }
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = new OracleImplicitConnectionCache(oracleDataSource, properties);
        oracleImplicitConnectionCache.cacheName = key;
        oracleDataSource.odsCache = oracleImplicitConnectionCache;
        this.m_connCache.put(key, oracleImplicitConnectionCache);
        if (fastConnectionFailoverEnabled) {
            this.checkAndStartThread(this.failoverEventHandlerThread);
        }
    }
    
    @Deprecated
    public void removeCache(final String key, final long n) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.remove(key) : null;
        if (oracleImplicitConnectionCache != null) {
            oracleImplicitConnectionCache.disableConnectionCache();
            if (n > 0L) {
                try {
                    Thread.currentThread();
                    Thread.sleep(n * 1000L);
                }
                catch (InterruptedException ex) {}
            }
            if (oracleImplicitConnectionCache.cacheEnabledDS.getFastConnectionFailoverEnabled()) {
                this.cleanupFCFThreads(oracleImplicitConnectionCache);
            }
            oracleImplicitConnectionCache.closeConnectionCache((n < 0L) ? 32 : 1);
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public void reinitializeCache(final String key, final Properties properties) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            this.disableCache(key);
            oracleImplicitConnectionCache.reinitializeCacheConnections(properties);
            this.enableCache(key);
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public boolean existsCache(final String key) throws SQLException {
        return this.m_connCache.containsKey(key);
    }
    
    @Deprecated
    public void enableCache(final String key) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            oracleImplicitConnectionCache.enableConnectionCache();
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public void disableCache(final String key) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            oracleImplicitConnectionCache.disableConnectionCache();
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public void refreshCache(final String key, final int n) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        switch (n) {
            case 4096:
            case 8192: {
                oracleImplicitConnectionCache.refreshCacheConnections(n);
            }
            default: {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    @Deprecated
    public void purgeCache(final String key, final boolean b) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            oracleImplicitConnectionCache.purgeCacheConnections(b, 1);
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public Properties getCacheProperties(final String key) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            return oracleImplicitConnectionCache.getConnectionCacheProperties();
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public String[] getCacheNameList() throws SQLException {
        return (String[])this.m_connCache.keySet().toArray(new String[this.m_connCache.size()]);
    }
    
    @Deprecated
    public int getNumberOfAvailableConnections(final String key) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            return oracleImplicitConnectionCache.cacheSize;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public int getNumberOfActiveConnections(final String key) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache != null) {
            return oracleImplicitConnectionCache.getNumberOfCheckedOutConnections();
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Deprecated
    public synchronized void setConnectionPoolDataSource(final String key, final ConnectionPoolDataSource connectionPoolDataSource) throws SQLException {
        final OracleImplicitConnectionCache oracleImplicitConnectionCache = (key != null) ? this.m_connCache.get(key) : null;
        if (oracleImplicitConnectionCache == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 141);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (oracleImplicitConnectionCache.cacheSize > 0) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 78);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        ((OracleConnectionPoolDataSource)connectionPoolDataSource).makeURL();
        ((OracleConnectionPoolDataSource)connectionPoolDataSource).setURL(((OracleConnectionPoolDataSource)connectionPoolDataSource).url);
        oracleImplicitConnectionCache.connectionPoolDS = (OracleConnectionPoolDataSource)connectionPoolDataSource;
    }
    
    protected void verifyAndHandleEvent(final int n, final byte[] bytes) throws SQLException {
        String s = null;
        String intern = null;
        String intern2 = null;
        String intern3 = null;
        String s2 = null;
        int int1 = 0;
        StringTokenizer stringTokenizer = null;
        try {
            stringTokenizer = new StringTokenizer(new String(bytes, "UTF-8"), "{} =", true);
        }
        catch (UnsupportedEncodingException ex) {}
        String s3 = null;
        while (stringTokenizer.hasMoreTokens()) {
            String nextToken = null;
            final String nextToken2 = stringTokenizer.nextToken();
            if (nextToken2.equals("=") && stringTokenizer.hasMoreTokens()) {
                nextToken = stringTokenizer.nextToken();
            }
            else {
                s3 = nextToken2;
            }
            if (s3.equalsIgnoreCase("version") && nextToken != null && !nextToken.equals("1.0")) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 146);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (s3.equalsIgnoreCase("service") && nextToken != null) {
                s = nextToken;
            }
            if (s3.equalsIgnoreCase("instance") && nextToken != null && !nextToken.equals(" ")) {
                intern = nextToken.toLowerCase().intern();
            }
            if (s3.equalsIgnoreCase("database") && nextToken != null) {
                intern2 = nextToken.toLowerCase().intern();
            }
            if (s3.equalsIgnoreCase("host") && nextToken != null) {
                intern3 = nextToken.toLowerCase().intern();
            }
            if (s3.equalsIgnoreCase("status") && nextToken != null) {
                s2 = nextToken;
            }
            if (!s3.equalsIgnoreCase("card") || nextToken == null) {
                continue;
            }
            try {
                int1 = Integer.parseInt(nextToken);
            }
            catch (NumberFormatException ex2) {}
        }
        this.invokeFailoverProcessingThreads(n, s, intern, intern2, intern3, s2, int1);
    }
    
    private void invokeFailoverProcessingThreads(final int n, final String s, final String s2, final String s3, final String s4, final String s5, final int n2) throws SQLException {
        boolean b = false;
        boolean b2 = false;
        if (n == 256) {
            b = true;
        }
        if (n == 512) {
            b2 = true;
        }
        for (final OracleImplicitConnectionCache oracleImplicitConnectionCache : this.m_connCache.values()) {
            if ((b && s.equalsIgnoreCase(oracleImplicitConnectionCache.dataSourceServiceName)) || b2) {
                final OracleFailoverWorkerThread failoverWorkerThread = new OracleFailoverWorkerThread(oracleImplicitConnectionCache, n, s2, s3, s4, s5, n2);
                this.checkAndStartThread(failoverWorkerThread);
                oracleImplicitConnectionCache.failoverWorkerThread = failoverWorkerThread;
            }
        }
    }
    
    protected void checkAndStartThread(final Thread thread) throws SQLException {
        try {
            if (!thread.isAlive()) {
                thread.setDaemon(true);
                thread.start();
            }
        }
        catch (IllegalThreadStateException ex) {}
    }
    
    protected boolean failoverEnabledCacheExists() {
        return this.failoverEnabledCacheCount > 0;
    }
    
    protected void parseRuntimeLoadBalancingEvent(final String s, final byte[] array) throws SQLException {
        final Enumeration<OracleImplicitConnectionCache> elements = this.m_connCache.elements();
        while (elements.hasMoreElements()) {
            try {
                final OracleImplicitConnectionCache oracleImplicitConnectionCache = elements.nextElement();
                if (!s.equalsIgnoreCase(oracleImplicitConnectionCache.dataSourceServiceName)) {
                    continue;
                }
                if (array == null) {
                    oracleImplicitConnectionCache.zapRLBInfo();
                }
                else {
                    this.retrieveServiceMetrics(oracleImplicitConnectionCache, array);
                }
            }
            catch (Exception ex) {}
        }
    }
    
    private void retrieveServiceMetrics(final OracleImplicitConnectionCache oracleImplicitConnectionCache, final byte[] bytes) throws SQLException {
        StringTokenizer stringTokenizer = null;
        String intern = null;
        String intern2 = null;
        int int1 = 0;
        int n = 0;
        int n2 = 0;
        try {
            stringTokenizer = new StringTokenizer(new String(bytes, "UTF-8"), "{} =", true);
        }
        catch (UnsupportedEncodingException ex) {}
        String s = null;
        while (stringTokenizer.hasMoreTokens()) {
            String nextToken = null;
            final String nextToken2 = stringTokenizer.nextToken();
            if (nextToken2.equals("=") && stringTokenizer.hasMoreTokens()) {
                nextToken = stringTokenizer.nextToken();
            }
            else if (nextToken2.equals("}")) {
                if (n2 != 0) {
                    oracleImplicitConnectionCache.updateDatabaseInstance(intern2, intern, int1, n);
                    n2 = 0;
                    continue;
                }
                continue;
            }
            else {
                if (nextToken2.equals("{")) {
                    continue;
                }
                if (nextToken2.equals(" ")) {
                    continue;
                }
                s = nextToken2;
                n2 = 1;
            }
            if (s.equalsIgnoreCase("version") && nextToken != null && !nextToken.equals("1.0")) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 146);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            if (s.equalsIgnoreCase("database") && nextToken != null) {
                intern2 = nextToken.toLowerCase().intern();
            }
            if (s.equalsIgnoreCase("instance") && nextToken != null) {
                intern = nextToken.toLowerCase().intern();
            }
            if (s.equalsIgnoreCase("percent") && nextToken != null) {
                try {
                    int1 = Integer.parseInt(nextToken);
                    if (int1 == 0) {
                        int1 = 1;
                    }
                }
                catch (NumberFormatException ex2) {}
            }
            if (!s.equalsIgnoreCase("flag") || nextToken == null) {
                continue;
            }
            if (nextToken.equalsIgnoreCase("good")) {
                n = 1;
            }
            else if (nextToken.equalsIgnoreCase("violating")) {
                n = 3;
            }
            else if (nextToken.equalsIgnoreCase("NO_DATA")) {
                n = 4;
            }
            else if (nextToken.equalsIgnoreCase("UNKNOWN")) {
                n = 2;
            }
            else {
                if (!nextToken.equalsIgnoreCase("BLOCKED")) {
                    continue;
                }
                n = 5;
            }
        }
        oracleImplicitConnectionCache.processDatabaseInstances();
    }
    
    protected void cleanupFCFThreads(final OracleImplicitConnectionCache oracleImplicitConnectionCache) throws SQLException {
        this.cleanupFCFWorkerThread(oracleImplicitConnectionCache);
        oracleImplicitConnectionCache.cleanupRLBThreads();
        if (this.failoverEnabledCacheCount <= 0) {
            this.cleanupFCFEventHandlerThread();
        }
        --this.failoverEnabledCacheCount;
    }
    
    protected void cleanupFCFWorkerThread(final OracleImplicitConnectionCache oracleImplicitConnectionCache) throws SQLException {
        if (oracleImplicitConnectionCache.failoverWorkerThread != null) {
            try {
                if (oracleImplicitConnectionCache.failoverWorkerThread.isAlive()) {
                    oracleImplicitConnectionCache.failoverWorkerThread.join();
                }
            }
            catch (InterruptedException ex) {}
            oracleImplicitConnectionCache.failoverWorkerThread = null;
        }
    }
    
    protected void cleanupFCFEventHandlerThread() throws SQLException {
        if (this.failoverEventHandlerThread != null) {
            try {
                this.failoverEventHandlerThread.interrupt();
            }
            catch (Exception ex) {}
            this.failoverEventHandlerThread = null;
        }
    }
    
    public boolean isFatalConnectionError(final SQLException ex) {
        boolean b = false;
        final int errorCode = ex.getErrorCode();
        if (errorCode == 3113 || errorCode == 3114 || errorCode == 1033 || errorCode == 1034 || errorCode == 1089 || errorCode == 1090 || errorCode == 17002) {
            b = true;
        }
        if (!b && this.fatalErrorCodes != null) {
            for (int i = 0; i < this.fatalErrorCodes.length; ++i) {
                if (errorCode == this.fatalErrorCodes[i]) {
                    b = true;
                    break;
                }
            }
        }
        return b;
    }
    
    public synchronized void setConnectionErrorCodes(final int[] fatalErrorCodes) throws SQLException {
        if (fatalErrorCodes != null) {
            this.fatalErrorCodes = fatalErrorCodes;
        }
    }
    
    public int[] getConnectionErrorCodes() throws SQLException {
        return this.fatalErrorCodes;
    }
    
    @Deprecated
    public Map getStatistics(final String key) throws SQLException {
        Map statistics = null;
        final OracleImplicitConnectionCache oracleImplicitConnectionCache;
        if (this.m_connCache != null && (oracleImplicitConnectionCache = this.m_connCache.get(key)) != null) {
            statistics = oracleImplicitConnectionCache.getStatistics();
        }
        return statistics;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        OracleConnectionCacheManager.cacheManagerInstance = null;
        OracleConnectionCacheManager.isONSInitializedForRemoteSubscription = false;
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
