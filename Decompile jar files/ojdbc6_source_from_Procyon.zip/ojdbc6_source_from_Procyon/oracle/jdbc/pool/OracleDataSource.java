// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Enumeration;
import java.sql.SQLWarning;
import javax.naming.RefAddr;
import javax.naming.StringRefAddr;
import javax.naming.NamingException;
import javax.naming.Reference;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.driver.OracleDriver;
import java.util.Properties;
import java.io.PrintWriter;
import javax.naming.Referenceable;
import java.io.Serializable;
import javax.sql.DataSource;

public class OracleDataSource implements DataSource, Serializable, Referenceable
{
    static final long serialVersionUID = 3349652938965166731L;
    protected PrintWriter logWriter;
    protected int loginTimeout;
    protected String databaseName;
    protected String serviceName;
    protected String dataSourceName;
    protected String description;
    protected String networkProtocol;
    protected int portNumber;
    protected String user;
    protected String password;
    protected String serverName;
    protected String url;
    protected String driverType;
    protected String tnsEntry;
    protected int maxStatements;
    protected boolean implicitCachingEnabled;
    protected boolean explicitCachingEnabled;
    protected transient OracleImplicitConnectionCache odsCache;
    protected transient OracleConnectionCacheManager cacheManager;
    protected String connCacheName;
    protected Properties connCacheProperties;
    protected Properties connectionProperties;
    protected boolean connCachingEnabled;
    protected boolean fastConnFailover;
    protected String onsConfigStr;
    public boolean isOracleDataSource;
    private static final boolean fastConnectionFailoverSysProperty;
    private boolean urlExplicit;
    private boolean useDefaultConnection;
    protected transient OracleDriver driver;
    private static final String spawnNewThreadToCancelProperty = "oracle.jdbc.spawnNewThreadToCancel";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleDataSource() throws SQLException {
        this.logWriter = null;
        this.loginTimeout = 0;
        this.databaseName = null;
        this.serviceName = null;
        this.dataSourceName = "OracleDataSource";
        this.description = null;
        this.networkProtocol = "tcp";
        this.portNumber = 0;
        this.user = null;
        this.password = null;
        this.serverName = null;
        this.url = null;
        this.driverType = null;
        this.tnsEntry = null;
        this.maxStatements = 0;
        this.implicitCachingEnabled = false;
        this.explicitCachingEnabled = false;
        this.odsCache = null;
        this.cacheManager = null;
        this.connCacheName = null;
        this.connCacheProperties = null;
        this.connectionProperties = null;
        this.connCachingEnabled = false;
        this.fastConnFailover = false;
        this.onsConfigStr = null;
        this.isOracleDataSource = true;
        this.urlExplicit = false;
        this.useDefaultConnection = false;
        this.driver = new OracleDriver();
        this.processFastConnectionFailoverSysProperty();
    }
    
    void processFastConnectionFailoverSysProperty() {
        if (this.isOracleDataSource && OracleDataSource.fastConnectionFailoverSysProperty) {
            this.connCachingEnabled = true;
            if (this.cacheManager == null) {
                try {
                    this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
                }
                catch (SQLException ex) {}
            }
            this.setSpawnNewThreadToCancel(this.fastConnFailover = true);
        }
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        String user = null;
        String password = null;
        synchronized (this) {
            user = this.user;
            password = this.password;
        }
        return this.getConnection(user, password);
    }
    
    @Override
    public Connection getConnection(final String value, final String value2) throws SQLException {
        Properties properties = null;
        Connection connection;
        if (this.connCachingEnabled) {
            connection = this.getConnection(value, value2, null);
        }
        else {
            synchronized (this) {
                this.makeURL();
                properties = (Properties)((this.connectionProperties == null) ? new Properties() : this.connectionProperties.clone());
                if (this.url != null) {
                    properties.setProperty("connection_url", this.url);
                }
                if (value != null) {
                    properties.setProperty("user", value);
                }
                if (value2 != null) {
                    properties.setProperty("password", value2);
                }
                if (this.loginTimeout != 0) {
                    properties.setProperty("LoginTimeout", "" + this.loginTimeout);
                }
                if (this.maxStatements != 0) {
                    properties.setProperty("stmt_cache_size", "" + this.maxStatements);
                }
            }
            connection = this.getPhysicalConnection(properties);
            if (connection == null) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
        }
        return connection;
    }
    
    protected Connection getPhysicalConnection(final Properties properties) throws SQLException {
        Properties properties2 = properties;
        String s = properties.getProperty("connection_url");
        final String property = properties.getProperty("user");
        final String property2 = properties2.getProperty("password");
        boolean useDefaultConnection = false;
        synchronized (this) {
            if (this.connectionProperties != null) {
                properties2 = (Properties)this.connectionProperties.clone();
                if (property != null) {
                    properties2.put("user", property);
                }
                if (property2 != null) {
                    properties2.put("password", property2);
                }
            }
            if (property == null && this.user != null) {
                properties2.put("user", this.user);
            }
            if (property2 == null && this.password != null) {
                properties2.put("password", this.password);
            }
            if (s == null) {
                s = this.url;
            }
            final String property3 = properties.getProperty("LoginTimeout");
            if (property3 != null) {
                properties2.put("oracle.net.CONNECT_TIMEOUT", "" + Integer.parseInt(property3) * 1000);
            }
            useDefaultConnection = this.useDefaultConnection;
            if (this.driver == null) {
                this.driver = new OracleDriver();
            }
        }
        Connection connection;
        if (useDefaultConnection) {
            connection = this.driver.defaultConnection();
        }
        else {
            connection = this.driver.connect(s, properties2);
        }
        if (connection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final String property4 = properties.getProperty("stmt_cache_size");
        int int1 = 0;
        if (property4 != null) {
            ((OracleConnection)connection).setStatementCacheSize(int1 = Integer.parseInt(property4));
        }
        boolean equals = false;
        final String property5 = properties.getProperty("ExplicitStatementCachingEnabled");
        if (property5 != null) {
            ((OracleConnection)connection).setExplicitCachingEnabled(equals = property5.equals("true"));
        }
        boolean equals2 = false;
        final String property6 = properties.getProperty("ImplicitStatementCachingEnabled");
        if (property6 != null) {
            ((OracleConnection)connection).setImplicitCachingEnabled(equals2 = property6.equals("true"));
        }
        if (int1 > 0 && !equals && !equals2) {
            ((OracleConnection)connection).setImplicitCachingEnabled(true);
            ((OracleConnection)connection).setExplicitCachingEnabled(true);
        }
        return connection;
    }
    
    @Deprecated
    public Connection getConnection(final Properties properties) throws SQLException {
        String user = null;
        String password = null;
        synchronized (this) {
            if (!this.connCachingEnabled) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 137);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            user = this.user;
            password = this.password;
        }
        return this.getConnection(user, password, properties);
    }
    
    @Deprecated
    public Connection getConnection(final String s, final String s2, final Properties properties) throws SQLException {
        if (!this.connCachingEnabled) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 137);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.odsCache == null) {
            this.cacheInitialize();
        }
        return this.odsCache.getConnection(s, s2, properties);
    }
    
    private synchronized void cacheInitialize() throws SQLException {
        if (this.odsCache == null) {
            if (this.connCacheName != null) {
                this.cacheManager.createCache(this.connCacheName, this, this.connCacheProperties);
            }
            else {
                this.connCacheName = this.cacheManager.createCache(this, this.connCacheProperties);
            }
        }
    }
    
    @Deprecated
    public synchronized void close() throws SQLException {
        if (this.connCachingEnabled && this.odsCache != null) {
            this.cacheManager.removeCache(this.odsCache.cacheName, 0L);
            this.odsCache = null;
        }
    }
    
    @Deprecated
    public synchronized void setConnectionCachingEnabled(final boolean b) throws SQLException {
        if (this.isOracleDataSource) {
            if (b) {
                this.connCachingEnabled = true;
                if (this.cacheManager == null) {
                    this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
                }
            }
            else if (this.odsCache == null) {
                this.connCachingEnabled = false;
                this.setSpawnNewThreadToCancel(this.fastConnFailover = false);
                this.connCacheName = null;
                this.connCacheProperties = null;
            }
            return;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 137);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    public boolean getConnectionCachingEnabled() throws SQLException {
        return this.connCachingEnabled;
    }
    
    public synchronized void setConnectionCacheName(final String connCacheName) throws SQLException {
        if (connCacheName == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 138);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.connCacheName = connCacheName;
    }
    
    public String getConnectionCacheName() throws SQLException {
        if (this.connCachingEnabled && this.odsCache != null) {
            return this.odsCache.cacheName;
        }
        return this.connCacheName;
    }
    
    @Deprecated
    public synchronized void setConnectionCacheProperties(final Properties connCacheProperties) throws SQLException {
        this.connCacheProperties = connCacheProperties;
    }
    
    public Properties getConnectionCacheProperties() throws SQLException {
        if (this.connCachingEnabled && this.odsCache != null) {
            return this.odsCache.getConnectionCacheProperties();
        }
        return this.connCacheProperties;
    }
    
    public synchronized void setFastConnectionFailoverEnabled(final boolean fastConnFailover) throws SQLException {
        if (!this.fastConnFailover) {
            this.setSpawnNewThreadToCancel(this.fastConnFailover = fastConnFailover);
        }
        else if (!fastConnFailover) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 255);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public boolean getFastConnectionFailoverEnabled() throws SQLException {
        return this.fastConnFailover;
    }
    
    @Deprecated
    public String getONSConfiguration() throws SQLException {
        return this.onsConfigStr;
    }
    
    @Deprecated
    public synchronized void setONSConfiguration(final String onsConfigStr) throws SQLException {
        this.onsConfigStr = onsConfigStr;
    }
    
    @Override
    public synchronized int getLoginTimeout() {
        return this.loginTimeout;
    }
    
    @Override
    public synchronized void setLoginTimeout(final int loginTimeout) {
        this.loginTimeout = loginTimeout;
    }
    
    @Override
    public synchronized void setLogWriter(final PrintWriter logWriter) {
        this.logWriter = logWriter;
    }
    
    @Override
    public synchronized PrintWriter getLogWriter() {
        return this.logWriter;
    }
    
    public synchronized void setTNSEntryName(final String tnsEntry) {
        this.tnsEntry = tnsEntry;
    }
    
    public synchronized String getTNSEntryName() {
        return this.tnsEntry;
    }
    
    public synchronized void setDataSourceName(final String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }
    
    public synchronized String getDataSourceName() {
        return this.dataSourceName;
    }
    
    public synchronized String getDatabaseName() {
        return this.databaseName;
    }
    
    public synchronized void setDatabaseName(final String databaseName) {
        this.databaseName = databaseName;
    }
    
    public synchronized void setServiceName(final String serviceName) {
        this.serviceName = serviceName;
    }
    
    public synchronized String getServiceName() {
        return this.serviceName;
    }
    
    public synchronized void setServerName(final String serverName) {
        this.serverName = serverName;
    }
    
    public synchronized String getServerName() {
        return this.serverName;
    }
    
    public synchronized void setURL(final String s) {
        this.url = s;
        if (this.url != null) {
            this.urlExplicit = true;
        }
        if (this.connCachingEnabled && this.odsCache != null && this.odsCache.connectionPoolDS != null) {
            this.odsCache.connectionPoolDS.url = s;
        }
    }
    
    public synchronized String getURL() throws SQLException {
        if (!this.urlExplicit) {
            this.makeURL();
        }
        return this.url;
    }
    
    public synchronized void setUser(final String user) {
        this.user = user;
    }
    
    public String getUser() {
        return this.user;
    }
    
    public synchronized void setPassword(final String password) {
        this.password = password;
    }
    
    protected String getPassword() {
        return this.password;
    }
    
    public synchronized String getDescription() {
        return this.description;
    }
    
    public synchronized void setDescription(final String description) {
        this.description = description;
    }
    
    public synchronized String getDriverType() {
        return this.driverType;
    }
    
    public synchronized void setDriverType(final String driverType) {
        this.driverType = driverType;
    }
    
    public synchronized String getNetworkProtocol() {
        return this.networkProtocol;
    }
    
    public synchronized void setNetworkProtocol(final String networkProtocol) {
        this.networkProtocol = networkProtocol;
    }
    
    public synchronized void setPortNumber(final int portNumber) {
        this.portNumber = portNumber;
    }
    
    public synchronized int getPortNumber() {
        return this.portNumber;
    }
    
    @Override
    public synchronized Reference getReference() throws NamingException {
        final Reference reference = new Reference(this.getClass().getName(), "oracle.jdbc.pool.OracleDataSourceFactory", null);
        this.addRefProperties(reference);
        return reference;
    }
    
    protected void addRefProperties(final Reference reference) {
        if (this.url != null) {
            reference.add(new StringRefAddr("url", this.url));
        }
        if (this.user != null) {
            reference.add(new StringRefAddr("userName", this.user));
        }
        if (this.password != null) {
            reference.add(new StringRefAddr("passWord", this.password));
        }
        if (this.description != null) {
            reference.add(new StringRefAddr("description", this.description));
        }
        if (this.driverType != null) {
            reference.add(new StringRefAddr("driverType", this.driverType));
        }
        if (this.serverName != null) {
            reference.add(new StringRefAddr("serverName", this.serverName));
        }
        if (this.databaseName != null) {
            reference.add(new StringRefAddr("databaseName", this.databaseName));
        }
        if (this.serviceName != null) {
            reference.add(new StringRefAddr("serviceName", this.serviceName));
        }
        if (this.networkProtocol != null) {
            reference.add(new StringRefAddr("networkProtocol", this.networkProtocol));
        }
        if (this.portNumber != 0) {
            reference.add(new StringRefAddr("portNumber", Integer.toString(this.portNumber)));
        }
        if (this.tnsEntry != null) {
            reference.add(new StringRefAddr("tnsentryname", this.tnsEntry));
        }
        if (this.maxStatements != 0) {
            reference.add(new StringRefAddr("maxStatements", Integer.toString(this.maxStatements)));
        }
        if (this.implicitCachingEnabled) {
            reference.add(new StringRefAddr("implicitCachingEnabled", "true"));
        }
        if (this.explicitCachingEnabled) {
            reference.add(new StringRefAddr("explicitCachingEnabled", "true"));
        }
        if (this.connCachingEnabled) {
            reference.add(new StringRefAddr("connectionCachingEnabled", "true"));
        }
        if (this.connCacheName != null) {
            reference.add(new StringRefAddr("connectionCacheName", this.connCacheName));
        }
        if (this.connCacheProperties != null) {
            reference.add(new StringRefAddr("connectionCacheProperties", this.connCacheProperties.toString()));
        }
        if (this.fastConnFailover) {
            reference.add(new StringRefAddr("fastConnectionFailoverEnabled", "true"));
        }
        if (this.onsConfigStr != null) {
            reference.add(new StringRefAddr("onsConfigStr", this.onsConfigStr));
        }
    }
    
    void makeURL() throws SQLException {
        if (this.urlExplicit) {
            return;
        }
        if (this.driverType == null || (!this.driverType.equals("oci8") && !this.driverType.equals("oci") && !this.driverType.equals("thin") && !this.driverType.equals("kprb"))) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67, "OracleDataSource.makeURL");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (this.driverType.equals("kprb")) {
            this.useDefaultConnection = true;
            this.url = "jdbc:oracle:kprb:@";
            return;
        }
        if ((this.driverType.equals("oci8") || this.driverType.equals("oci")) && this.networkProtocol != null && this.networkProtocol.equals("ipc")) {
            this.url = "jdbc:oracle:oci:@";
            return;
        }
        if (this.tnsEntry != null) {
            this.url = "jdbc:oracle:" + this.driverType + ":@" + this.tnsEntry;
            return;
        }
        if (this.serviceName != null) {
            this.url = "jdbc:oracle:" + this.driverType + ":@(DESCRIPTION=(ADDRESS=(PROTOCOL=" + this.networkProtocol + ")(PORT=" + this.portNumber + ")(HOST=" + this.serverName + "))(CONNECT_DATA=(SERVICE_NAME=" + this.serviceName + ")))";
        }
        else {
            this.url = "jdbc:oracle:" + this.driverType + ":@(DESCRIPTION=(ADDRESS=(PROTOCOL=" + this.networkProtocol + ")(PORT=" + this.portNumber + ")(HOST=" + this.serverName + "))(CONNECT_DATA=(SID=" + this.databaseName + ")))";
            DatabaseError.addSqlWarning(null, new SQLWarning("URL with SID jdbc:subprotocol:@host:port:sid will be deprecated in 10i\nPlease use URL with SERVICE_NAME as jdbc:subprotocol:@//host:port/service_name"));
            if (this.fastConnFailover) {
                final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67, "OracleDataSource.makeURL");
                sqlException2.fillInStackTrace();
                throw sqlException2;
            }
        }
    }
    
    protected void trace(final String s) {
        if (this.logWriter != null) {}
    }
    
    protected void copy(final OracleDataSource oracleDataSource) throws SQLException {
        oracleDataSource.setUser(this.user);
        oracleDataSource.setPassword(this.password);
        oracleDataSource.setTNSEntryName(this.tnsEntry);
        this.makeURL();
        oracleDataSource.setURL(this.url);
        if (this.loginTimeout > 0) {
            oracleDataSource.setLoginTimeout(this.loginTimeout);
        }
        oracleDataSource.connectionProperties = this.connectionProperties;
    }
    
    @Deprecated
    public void setMaxStatements(final int maxStatements) throws SQLException {
        this.maxStatements = maxStatements;
    }
    
    public int getMaxStatements() throws SQLException {
        return this.maxStatements;
    }
    
    public void setImplicitCachingEnabled(final boolean implicitCachingEnabled) throws SQLException {
        this.implicitCachingEnabled = implicitCachingEnabled;
    }
    
    public boolean getImplicitCachingEnabled() throws SQLException {
        return this.implicitCachingEnabled;
    }
    
    public void setExplicitCachingEnabled(final boolean explicitCachingEnabled) throws SQLException {
        this.explicitCachingEnabled = explicitCachingEnabled;
    }
    
    public boolean getExplicitCachingEnabled() throws SQLException {
        return this.explicitCachingEnabled;
    }
    
    public void setConnectionProperties(final Properties connectionProperties) throws SQLException {
        if (connectionProperties == null) {
            this.connectionProperties = connectionProperties;
        }
        else {
            this.connectionProperties = (Properties)connectionProperties.clone();
        }
        this.setSpawnNewThreadToCancel(this.fastConnFailover);
    }
    
    public Properties getConnectionProperties() throws SQLException {
        return filterConnectionProperties(this.connectionProperties);
    }
    
    public static final Properties filterConnectionProperties(final Properties properties) {
        Properties properties2 = null;
        if (properties != null) {
            properties2 = (Properties)properties.clone();
            final Enumeration<?> propertyNames = properties2.propertyNames();
            while (propertyNames.hasMoreElements()) {
                final String key = (String)propertyNames.nextElement();
                if (key != null && key.matches(".*[P,p][A,a][S,s][S,s][W,w][O,o][R,r][D,d].*")) {
                    properties2.remove(key);
                }
            }
            properties.remove("oracle.jdbc.spawnNewThreadToCancel");
        }
        return properties2;
    }
    
    private void setSpawnNewThreadToCancel(final boolean b) {
        if (b) {
            if (this.connectionProperties == null) {
                this.connectionProperties = new Properties();
            }
            this.connectionProperties.setProperty("oracle.jdbc.spawnNewThreadToCancel", "true");
        }
        else if (this.connectionProperties != null) {
            this.connectionProperties.remove("oracle.jdbc.spawnNewThreadToCancel");
        }
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException, SQLException {
        objectInputStream.defaultReadObject();
        if (this.connCachingEnabled) {
            this.setConnectionCachingEnabled(this.connCachingEnabled);
        }
    }
    
    @Override
    public boolean isWrapperFor(final Class<?> clazz) throws SQLException {
        if (clazz.isInterface()) {
            return clazz.isInstance(this);
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    @Override
    public <T> T unwrap(final Class<T> clazz) throws SQLException {
        if (clazz.isInterface() && clazz.isInstance(this)) {
            return (T)this;
        }
        final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 177);
        sqlException.fillInStackTrace();
        throw sqlException;
    }
    
    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        fastConnectionFailoverSysProperty = "true".equalsIgnoreCase(OracleDriver.getSystemPropertyFastConnectionFailover("false"));
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
