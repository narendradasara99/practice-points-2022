// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.util.Enumeration;
import java.util.Iterator;
import oracle.jdbc.internal.OracleConnection;
import javax.naming.NamingException;
import javax.naming.RefAddr;
import javax.naming.StringRefAddr;
import javax.naming.Reference;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import java.util.Properties;
import oracle.jdbc.driver.OracleDriver;
import java.util.Hashtable;
import oracle.jdbc.oci.OracleOCIConnection;

public class OracleOCIConnectionPool extends OracleDataSource
{
    public OracleOCIConnection m_connection_pool;
    public static final String IS_CONNECTION_POOLING = "is_connection_pooling";
    private int m_conn_min_limit;
    private int m_conn_max_limit;
    private int m_conn_increment;
    private int m_conn_active_size;
    private int m_conn_pool_size;
    private int m_conn_timeout;
    private String m_conn_nowait;
    private int m_is_transactions_distributed;
    public static final String CONNPOOL_OBJECT = "connpool_object";
    public static final String CONNPOOL_LOGON_MODE = "connection_pool";
    public static final String CONNECTION_POOL = "connection_pool";
    public static final String CONNPOOL_CONNECTION = "connpool_connection";
    public static final String CONNPOOL_PROXY_CONNECTION = "connpool_proxy_connection";
    public static final String CONNPOOL_ALIASED_CONNECTION = "connpool_alias_connection";
    public static final String PROXY_USER_NAME = "proxy_user_name";
    public static final String PROXY_DISTINGUISHED_NAME = "proxy_distinguished_name";
    public static final String PROXY_CERTIFICATE = "proxy_certificate";
    public static final String PROXY_ROLES = "proxy_roles";
    public static final String PROXY_NUM_ROLES = "proxy_num_roles";
    public static final String PROXY_PASSWORD = "proxy_password";
    public static final String PROXYTYPE = "proxytype";
    public static final String PROXYTYPE_USER_NAME = "proxytype_user_name";
    public static final String PROXYTYPE_DISTINGUISHED_NAME = "proxytype_distinguished_name";
    public static final String PROXYTYPE_CERTIFICATE = "proxytype_certificate";
    public static final String CONNECTION_ID = "connection_id";
    public static final String CONNPOOL_MIN_LIMIT = "connpool_min_limit";
    public static final String CONNPOOL_MAX_LIMIT = "connpool_max_limit";
    public static final String CONNPOOL_INCREMENT = "connpool_increment";
    public static final String CONNPOOL_ACTIVE_SIZE = "connpool_active_size";
    public static final String CONNPOOL_POOL_SIZE = "connpool_pool_size";
    public static final String CONNPOOL_TIMEOUT = "connpool_timeout";
    public static final String CONNPOOL_NOWAIT = "connpool_nowait";
    public static final String CONNPOOL_IS_POOLCREATED = "connpool_is_poolcreated";
    public static final String TRANSACTIONS_DISTRIBUTED = "transactions_distributed";
    private Hashtable m_lconnections;
    private Lifecycle lifecycle;
    private OracleDriver m_oracleDriver;
    protected int m_stmtCacheSize;
    protected boolean m_stmtClearMetaData;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    private void ensureOpen() throws SQLException {
        if (this.lifecycle == Lifecycle.NEW) {
            this.createConnectionPool(null);
        }
        if (this.lifecycle != Lifecycle.OPEN) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 8);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public OracleOCIConnectionPool(final String user, final String password, final String url, final Properties properties) throws SQLException {
        this();
        this.setURL(url);
        this.setUser(user);
        this.setPassword(password);
        this.createConnectionPool(properties);
    }
    
    @Deprecated
    public OracleOCIConnectionPool(final String user, final String password, final String url) throws SQLException {
        this();
        this.setURL(url);
        this.setUser(user);
        this.setPassword(password);
        this.createConnectionPool(null);
    }
    
    public OracleOCIConnectionPool() throws SQLException {
        this.m_conn_min_limit = 0;
        this.m_conn_max_limit = 0;
        this.m_conn_increment = 0;
        this.m_conn_active_size = 0;
        this.m_conn_pool_size = 0;
        this.m_conn_timeout = 0;
        this.m_conn_nowait = "false";
        this.m_is_transactions_distributed = 0;
        this.m_lconnections = null;
        this.lifecycle = Lifecycle.NEW;
        this.m_oracleDriver = new OracleDriver();
        this.m_stmtCacheSize = 0;
        this.m_stmtClearMetaData = false;
        this.isOracleDataSource = false;
        this.m_lconnections = new Hashtable(10);
        this.setDriverType("oci8");
    }
    
    @Override
    public synchronized Connection getConnection() throws SQLException {
        this.ensureOpen();
        return this.getConnection(this.user, this.password);
    }
    
    @Override
    public synchronized Connection getConnection(final String value, final String value2) throws SQLException {
        this.ensureOpen();
        Properties properties;
        if (this.connectionProperties != null) {
            properties = new Properties(this.connectionProperties);
        }
        else {
            properties = new Properties();
        }
        properties.put("is_connection_pooling", "true");
        properties.put("user", value);
        properties.put("password", value2);
        properties.put("connection_pool", "connpool_connection");
        properties.put("connpool_object", this.m_connection_pool);
        final OracleOCIConnection oracleOCIConnection = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties);
        if (oracleOCIConnection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        oracleOCIConnection.setStmtCacheSize(this.m_stmtCacheSize, this.m_stmtClearMetaData);
        this.m_lconnections.put(oracleOCIConnection, oracleOCIConnection);
        oracleOCIConnection.setConnectionPool(this);
        return oracleOCIConnection;
    }
    
    @Override
    public synchronized Reference getReference() throws NamingException {
        final Reference reference = new Reference(this.getClass().getName(), "oracle.jdbc.pool.OracleDataSourceFactory", null);
        super.addRefProperties(reference);
        reference.add(new StringRefAddr("connpool_min_limit", String.valueOf(this.m_conn_min_limit)));
        reference.add(new StringRefAddr("connpool_max_limit", String.valueOf(this.m_conn_max_limit)));
        reference.add(new StringRefAddr("connpool_increment", String.valueOf(this.m_conn_increment)));
        reference.add(new StringRefAddr("connpool_active_size", String.valueOf(this.m_conn_active_size)));
        reference.add(new StringRefAddr("connpool_pool_size", String.valueOf(this.m_conn_pool_size)));
        reference.add(new StringRefAddr("connpool_timeout", String.valueOf(this.m_conn_timeout)));
        reference.add(new StringRefAddr("connpool_nowait", this.m_conn_nowait));
        reference.add(new StringRefAddr("connpool_is_poolcreated", String.valueOf(this.isPoolCreated())));
        reference.add(new StringRefAddr("transactions_distributed", String.valueOf(this.isDistributedTransEnabled())));
        return reference;
    }
    
    public synchronized OracleConnection getProxyConnection(final String s, final Properties properties) throws SQLException {
        this.ensureOpen();
        if ("proxytype_user_name".equals(s)) {
            properties.put("user", properties.getProperty("proxy_user_name"));
        }
        else if ("proxytype_distinguished_name".equals(s)) {
            properties.put("user", properties.getProperty("proxy_distinguished_name"));
        }
        else {
            if (!"proxytype_certificate".equals(s)) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 107, "null properties");
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            properties.put("user", String.valueOf(properties.getProperty("proxy_user_name")));
        }
        properties.put("is_connection_pooling", "true");
        properties.put("proxytype", s);
        final String[] array;
        if ((array = (String[])properties.get("proxy_roles")) != null) {
            properties.put("proxy_num_roles", new Integer(array.length));
        }
        else {
            properties.put("proxy_num_roles", new Integer(0));
        }
        properties.put("connection_pool", "connpool_proxy_connection");
        properties.put("connpool_object", this.m_connection_pool);
        final OracleOCIConnection oracleOCIConnection = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties);
        if (oracleOCIConnection == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        oracleOCIConnection.setStmtCacheSize(this.m_stmtCacheSize, this.m_stmtClearMetaData);
        this.m_lconnections.put(oracleOCIConnection, oracleOCIConnection);
        oracleOCIConnection.setConnectionPool(this);
        return oracleOCIConnection;
    }
    
    public synchronized OracleConnection getAliasedConnection(final byte[] value) throws SQLException {
        this.ensureOpen();
        final Properties properties = new Properties();
        properties.put("is_connection_pooling", "true");
        properties.put("connection_id", value);
        properties.put("connection_pool", "connpool_alias_connection");
        properties.put("connpool_object", this.m_connection_pool);
        final OracleOCIConnection oracleOCIConnection = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties);
        if (oracleOCIConnection == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        oracleOCIConnection.setStmtCacheSize(this.m_stmtCacheSize, this.m_stmtClearMetaData);
        this.m_lconnections.put(oracleOCIConnection, oracleOCIConnection);
        oracleOCIConnection.setConnectionPool(this);
        return oracleOCIConnection;
    }
    
    @Override
    public synchronized void close() throws SQLException {
        if (this.lifecycle != Lifecycle.OPEN) {
            return;
        }
        this.lifecycle = Lifecycle.CLOSING;
        final Iterator<OracleOCIConnection> iterator = this.m_lconnections.values().iterator();
        while (iterator.hasNext()) {
            final OracleOCIConnection oracleOCIConnection = iterator.next();
            if (oracleOCIConnection != null && oracleOCIConnection != this.m_connection_pool) {
                oracleOCIConnection.close();
            }
            iterator.remove();
        }
        this.m_connection_pool.close();
        this.lifecycle = Lifecycle.CLOSED;
    }
    
    public synchronized void setPoolConfig(final Properties properties) throws SQLException {
        if (properties == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 106, "null properties");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        if (!this.isPoolCreated()) {
            this.createConnectionPool(properties);
        }
        else {
            final Properties properties2 = new Properties();
            this.checkPoolConfig(properties, properties2);
            final int[] array = new int[6];
            readPoolConfig(properties2, array);
            this.m_connection_pool.setConnectionPoolInfo(array[0], array[1], array[2], array[3], array[4], array[5]);
        }
        this.storePoolProperties();
    }
    
    public static void readPoolConfig(final int n, final int n2, final int n3, final int n4, final boolean b, final boolean b2, final int[] array) {
        for (int i = 0; i < 6; ++i) {
            array[i] = 0;
        }
        array[0] = n;
        array[1] = n2;
        array[2] = n3;
        array[3] = n4;
        if (b) {
            array[4] = 1;
        }
        if (b2) {
            array[5] = 1;
        }
    }
    
    public static void readPoolConfig(final Properties properties, final int[] array) {
        final String property = properties.getProperty("connpool_min_limit");
        if (property != null) {
            array[0] = Integer.parseInt(property);
        }
        final String property2 = properties.getProperty("connpool_max_limit");
        if (property2 != null) {
            array[1] = Integer.parseInt(property2);
        }
        final String property3 = properties.getProperty("connpool_increment");
        if (property3 != null) {
            array[2] = Integer.parseInt(property3);
        }
        final String property4 = properties.getProperty("connpool_timeout");
        if (property4 != null) {
            array[3] = Integer.parseInt(property4);
        }
        final String property5 = properties.getProperty("connpool_nowait");
        if (property5 != null && property5.equalsIgnoreCase("true")) {
            array[4] = 1;
        }
        final String property6 = properties.getProperty("transactions_distributed");
        if (property6 != null && property6.equalsIgnoreCase("true")) {
            array[5] = 1;
        }
    }
    
    private void checkPoolConfig(final Properties properties, final Properties properties2) throws SQLException {
        final String s = (String)properties.get("transactions_distributed");
        final String s2 = (String)properties.get("connpool_nowait");
        if ((s != null && !s.equalsIgnoreCase("true")) || (s2 != null && !s2.equalsIgnoreCase("true")) || properties.get("connpool_min_limit") == null || properties.get("connpool_max_limit") == null || properties.get("connpool_increment") == null || Integer.decode((String)properties.get("connpool_min_limit")) < 0 || Integer.decode((String)properties.get("connpool_max_limit")) < 0 || Integer.decode((String)properties.get("connpool_increment")) < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 106, "");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final Enumeration<?> propertyNames = properties.propertyNames();
        while (propertyNames.hasMoreElements()) {
            final String key = (String)propertyNames.nextElement();
            final String property = properties.getProperty(key);
            if ("transactions_distributed".equals(key) || "connpool_nowait".equals(key)) {
                properties2.put(key, "true");
            }
            else {
                properties2.put(key, property);
            }
        }
    }
    
    private synchronized void storePoolProperties() throws SQLException {
        final Properties poolConfig = this.getPoolConfig();
        this.m_conn_min_limit = Integer.decode(poolConfig.getProperty("connpool_min_limit"));
        this.m_conn_max_limit = Integer.decode(poolConfig.getProperty("connpool_max_limit"));
        this.m_conn_increment = Integer.decode(poolConfig.getProperty("connpool_increment"));
        this.m_conn_active_size = Integer.decode(poolConfig.getProperty("connpool_active_size"));
        this.m_conn_pool_size = Integer.decode(poolConfig.getProperty("connpool_pool_size"));
        this.m_conn_timeout = Integer.decode(poolConfig.getProperty("connpool_timeout"));
        this.m_conn_nowait = poolConfig.getProperty("connpool_nowait");
    }
    
    public synchronized Properties getPoolConfig() throws SQLException {
        this.ensureOpen();
        final Properties connectionPoolInfo = this.m_connection_pool.getConnectionPoolInfo();
        connectionPoolInfo.put("connpool_is_poolcreated", String.valueOf(this.isPoolCreated()));
        return connectionPoolInfo;
    }
    
    public synchronized int getActiveSize() throws SQLException {
        this.ensureOpen();
        return Integer.decode(this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_active_size"));
    }
    
    public synchronized int getPoolSize() throws SQLException {
        this.ensureOpen();
        return Integer.decode(this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_pool_size"));
    }
    
    public synchronized int getTimeout() throws SQLException {
        this.ensureOpen();
        return Integer.decode(this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_timeout"));
    }
    
    public synchronized String getNoWait() throws SQLException {
        this.ensureOpen();
        return this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_nowait");
    }
    
    public synchronized int getMinLimit() throws SQLException {
        this.ensureOpen();
        return Integer.decode(this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_min_limit"));
    }
    
    public synchronized int getMaxLimit() throws SQLException {
        this.ensureOpen();
        return Integer.decode(this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_max_limit"));
    }
    
    public synchronized int getConnectionIncrement() throws SQLException {
        this.ensureOpen();
        return Integer.decode(this.m_connection_pool.getConnectionPoolInfo().getProperty("connpool_increment"));
    }
    
    public synchronized boolean isDistributedTransEnabled() {
        return this.m_is_transactions_distributed == 1;
    }
    
    private void createConnectionPool(final Properties properties) throws SQLException {
        if (this.lifecycle != Lifecycle.NEW) {
            return;
        }
        if (this.user == null || this.password == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 106, " ");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        final Properties properties2 = new Properties();
        if (properties != null) {
            this.checkPoolConfig(properties, properties2);
        }
        properties2.put("is_connection_pooling", "true");
        properties2.put("user", this.user);
        properties2.put("password", this.password);
        properties2.put("connection_pool", "connection_pool");
        if (this.getURL() == null) {
            this.makeURL();
        }
        this.m_connection_pool = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties2);
        if (this.m_connection_pool == null) {
            final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 67);
            sqlException2.fillInStackTrace();
            throw sqlException2;
        }
        this.m_connection_pool.setConnectionPool(this);
        this.m_lconnections.put(this.m_connection_pool, this.m_connection_pool);
        this.lifecycle = Lifecycle.OPEN;
        this.storePoolProperties();
        if (properties != null && "true".equalsIgnoreCase(properties.getProperty("transactions_distributed"))) {
            this.m_is_transactions_distributed = 1;
        }
    }
    
    public synchronized boolean isPoolCreated() {
        return this.lifecycle == Lifecycle.OPEN;
    }
    
    public synchronized void connectionClosed(final OracleOCIConnection key) throws SQLException {
        if (this.lifecycle != Lifecycle.CLOSING && this.m_lconnections.remove(key) == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 1, "internal OracleOCIConnectionPool error");
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    public synchronized void setStmtCacheSize(final int n) throws SQLException {
        this.setStmtCacheSize(n, false);
    }
    
    public synchronized void setStmtCacheSize(final int stmtCacheSize, final boolean stmtClearMetaData) throws SQLException {
        if (stmtCacheSize < 0) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 68);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
        this.m_stmtCacheSize = stmtCacheSize;
        this.m_stmtClearMetaData = stmtClearMetaData;
    }
    
    public synchronized int getStmtCacheSize() {
        return this.m_stmtCacheSize;
    }
    
    public synchronized boolean isStmtCacheEnabled() {
        return this.m_stmtCacheSize > 0;
    }
    
    @Override
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
    
    private enum Lifecycle
    {
        NEW, 
        OPEN, 
        CLOSING, 
        CLOSED;
    }
}
