// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.sql.SQLException;
import javax.sql.PooledConnection;
import javax.sql.DataSource;

public interface OracleConnectionCache extends DataSource
{
    void reusePooledConnection(final PooledConnection p0) throws SQLException;
    
    void closePooledConnection(final PooledConnection p0) throws SQLException;
    
    void close() throws SQLException;
}
