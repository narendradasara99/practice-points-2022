// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.sql.SQLException;
import javax.sql.PooledConnection;
import javax.sql.ConnectionEvent;
import java.io.Serializable;
import javax.sql.ConnectionEventListener;

class OracleConnectionCacheEventListener implements ConnectionEventListener, Serializable
{
    static final int CONNECTION_CLOSED_EVENT = 101;
    static final int CONNECTION_ERROROCCURED_EVENT = 102;
    protected OracleImplicitConnectionCache implicitCache;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConnectionCacheEventListener() {
        this(null);
    }
    
    public OracleConnectionCacheEventListener(final OracleImplicitConnectionCache implicitCache) {
        this.implicitCache = null;
        this.implicitCache = implicitCache;
    }
    
    @Override
    public void connectionClosed(final ConnectionEvent connectionEvent) {
        try {
            if (this.implicitCache != null) {
                this.implicitCache.reusePooledConnection((PooledConnection)connectionEvent.getSource());
            }
        }
        catch (SQLException ex) {}
    }
    
    @Override
    public void connectionErrorOccurred(final ConnectionEvent connectionEvent) {
        try {
            if (this.implicitCache != null) {
                this.implicitCache.closePooledConnection((PooledConnection)connectionEvent.getSource());
            }
        }
        catch (SQLException ex) {}
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
