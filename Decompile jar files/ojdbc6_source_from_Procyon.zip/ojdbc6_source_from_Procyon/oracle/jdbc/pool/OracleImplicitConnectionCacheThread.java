// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.sql.Connection;
import oracle.jdbc.internal.OracleConnection;
import java.sql.SQLException;

class OracleImplicitConnectionCacheThread extends Thread
{
    private OracleImplicitConnectionCache implicitCache;
    protected boolean timeToLive;
    protected boolean isSleeping;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleImplicitConnectionCacheThread(final OracleImplicitConnectionCache implicitCache) throws SQLException {
        this.implicitCache = null;
        this.timeToLive = true;
        this.isSleeping = false;
        this.implicitCache = implicitCache;
    }
    
    @Override
    public void run() {
        long n = 0L;
        long n2 = 0L;
        long n3 = 0L;
        while (this.timeToLive) {
            try {
                if (this.timeToLive && (n = this.implicitCache.getCacheTimeToLiveTimeout()) > 0L) {
                    this.runTimeToLiveTimeout(n);
                }
                if (this.timeToLive && (n2 = this.implicitCache.getCacheInactivityTimeout()) > 0L) {
                    this.runInactivityTimeout();
                }
                if (this.timeToLive && (n3 = this.implicitCache.getCacheAbandonedTimeout()) > 0L) {
                    this.runAbandonedTimeout(n3);
                }
                if (this.timeToLive) {
                    this.isSleeping = true;
                    try {
                        Thread.sleep(this.implicitCache.getCachePropertyCheckInterval() * 1000);
                    }
                    catch (InterruptedException ex) {}
                    this.isSleeping = false;
                }
                if (this.implicitCache != null && (n > 0L || n2 > 0L || n3 > 0L)) {
                    continue;
                }
                this.timeToLive = false;
            }
            catch (SQLException ex2) {}
        }
    }
    
    private void runTimeToLiveTimeout(final long n) throws SQLException {
        if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
            synchronized (this.implicitCache) {
                final Object[] array = this.implicitCache.checkedOutConnectionList.toArray();
                for (int size = this.implicitCache.checkedOutConnectionList.size(), i = 0; i < size; ++i) {
                    final OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)array[i];
                    final Connection logicalHandle = oraclePooledConnection.getLogicalHandle();
                    if (logicalHandle != null && System.currentTimeMillis() - ((OracleConnection)logicalHandle).getStartTime() > n * 1000L) {
                        try {
                            this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
                        }
                        catch (SQLException ex) {}
                    }
                }
            }
        }
    }
    
    private void runInactivityTimeout() {
        try {
            final OracleImplicitConnectionCache implicitCache = this.implicitCache;
            final OracleImplicitConnectionCache implicitCache2 = this.implicitCache;
            implicitCache.doForEveryCachedConnection(4);
        }
        catch (SQLException ex) {}
    }
    
    private void runAbandonedTimeout(final long n) throws SQLException {
        if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
            synchronized (this.implicitCache) {
                final Object[] array = this.implicitCache.checkedOutConnectionList.toArray();
                for (int i = 0; i < array.length; ++i) {
                    final OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)array[i];
                    final OracleConnection oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
                    if (oracleConnection != null) {
                        final OracleConnectionCacheCallback connectionCacheCallbackObj = oracleConnection.getConnectionCacheCallbackObj();
                        if (oracleConnection.getHeartbeatNoChangeCount() * this.implicitCache.getCachePropertyCheckInterval() > n) {
                            try {
                                boolean handleAbandonedConnection = true;
                                if (connectionCacheCallbackObj != null && (oracleConnection.getConnectionCacheCallbackFlag() == 4 || oracleConnection.getConnectionCacheCallbackFlag() == 1)) {
                                    handleAbandonedConnection = connectionCacheCallbackObj.handleAbandonedConnection(oracleConnection, oracleConnection.getConnectionCacheCallbackPrivObj());
                                }
                                if (handleAbandonedConnection) {
                                    this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
                                }
                            }
                            catch (SQLException ex) {}
                        }
                    }
                }
            }
        }
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
