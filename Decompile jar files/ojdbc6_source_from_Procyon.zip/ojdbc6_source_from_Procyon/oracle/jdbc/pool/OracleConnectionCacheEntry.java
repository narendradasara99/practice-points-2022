// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.util.HashMap;
import java.util.Vector;

class OracleConnectionCacheEntry
{
    Vector userConnList;
    HashMap attrConnMap;
    
    OracleConnectionCacheEntry() {
        this.userConnList = null;
        this.attrConnMap = null;
    }
}
