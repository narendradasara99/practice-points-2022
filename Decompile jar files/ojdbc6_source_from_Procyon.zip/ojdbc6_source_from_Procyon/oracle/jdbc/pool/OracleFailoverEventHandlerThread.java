// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import oracle.ons.ONSException;
import java.security.PrivilegedActionException;
import java.security.AccessController;
import oracle.ons.SubscriptionException;
import java.security.PrivilegedExceptionAction;
import oracle.ons.Subscriber;
import java.sql.SQLException;
import oracle.ons.Notification;

class OracleFailoverEventHandlerThread extends Thread
{
    private Notification event;
    private OracleConnectionCacheManager cacheManager;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleFailoverEventHandlerThread() throws SQLException {
        this.event = null;
        this.cacheManager = null;
        this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
    }
    
    @Override
    public void run() {
        Subscriber subscriber = null;
        while (this.cacheManager.failoverEnabledCacheExists()) {
            try {
                subscriber = AccessController.doPrivileged((PrivilegedExceptionAction<Subscriber>)new PrivilegedExceptionAction() {
                    @Override
                    public Object run() {
                        try {
                            return new Subscriber("(%\"eventType=database/event/service\")|(%\"eventType=database/event/host\")", "", 30000L);
                        }
                        catch (SubscriptionException ex) {
                            return null;
                        }
                    }
                });
            }
            catch (PrivilegedActionException ex) {}
            if (subscriber != null) {
                try {
                    while (this.cacheManager.failoverEnabledCacheExists()) {
                        if ((this.event = subscriber.receive(true)) != null) {
                            this.handleEvent(this.event);
                        }
                    }
                }
                catch (ONSException ex2) {
                    subscriber.close();
                }
            }
            try {
                Thread.currentThread();
                Thread.sleep(10000L);
            }
            catch (InterruptedException ex3) {}
        }
    }
    
    void handleEvent(final Notification notification) {
        try {
            int n = 0;
            if (notification.type().equalsIgnoreCase("database/event/service")) {
                final OracleConnectionCacheManager cacheManager = this.cacheManager;
                n = 256;
            }
            else if (notification.type().equalsIgnoreCase("database/event/host")) {
                final OracleConnectionCacheManager cacheManager2 = this.cacheManager;
                n = 512;
            }
            if (n != 0) {
                this.cacheManager.verifyAndHandleEvent(n, notification.body());
            }
        }
        catch (SQLException ex) {}
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
