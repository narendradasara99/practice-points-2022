// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import oracle.ons.ONSException;
import java.security.PrivilegedActionException;
import java.security.AccessController;
import oracle.ons.SubscriptionException;
import java.security.PrivilegedExceptionAction;
import oracle.ons.Subscriber;
import java.sql.SQLException;
import oracle.ons.Notification;

class OracleRuntimeLoadBalancingEventHandlerThread extends Thread
{
    private Notification event;
    private OracleConnectionCacheManager cacheManager;
    String m_service;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleRuntimeLoadBalancingEventHandlerThread(final String service) throws SQLException {
        this.event = null;
        this.cacheManager = null;
        this.m_service = service;
        this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
    }
    
    @Override
    public void run() {
        Subscriber subscriber = null;
        final String string = "%\"eventType=database/event/servicemetrics/" + this.m_service + "\"";
        while (this.cacheManager.failoverEnabledCacheExists()) {
            try {
                subscriber = AccessController.doPrivileged((PrivilegedExceptionAction<Subscriber>)new PrivilegedExceptionAction() {
                    @Override
                    public Object run() {
                        try {
                            return new Subscriber(string, "", 30000L);
                        }
                        catch (SubscriptionException ex) {
                            return null;
                        }
                    }
                });
            }
            catch (PrivilegedActionException ex) {}
            if (subscriber != null) {
                try {
                    while (this.cacheManager.failoverEnabledCacheExists()) {
                        if ((this.event = subscriber.receive(300000L)) != null) {
                            this.handleEvent(this.event);
                        }
                    }
                }
                catch (ONSException ex2) {
                    subscriber.close();
                }
            }
            try {
                Thread.currentThread();
                Thread.sleep(10000L);
            }
            catch (InterruptedException ex3) {}
        }
    }
    
    void handleEvent(final Notification notification) {
        try {
            this.cacheManager.parseRuntimeLoadBalancingEvent(this.m_service, (byte[])((notification == null) ? null : notification.body()));
        }
        catch (SQLException ex) {}
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
