// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import javax.sql.PooledConnection;
import javax.sql.ConnectionEventListener;
import java.util.Iterator;
import java.util.Map;
import oracle.jdbc.internal.OracleConnection;
import java.sql.Connection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.xa.client.OracleXADataSource;
import java.sql.SQLException;
import java.util.Random;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Vector;
import java.util.Properties;

class OracleImplicitConnectionCache
{
    protected OracleDataSource cacheEnabledDS;
    protected String cacheName;
    protected OracleConnectionPoolDataSource connectionPoolDS;
    protected boolean fastConnectionFailoverEnabled;
    protected String defaultUser;
    protected String defaultPassword;
    protected static final int DEFAULT_MIN_LIMIT = 0;
    protected static final int DEFAULT_MAX_LIMIT = Integer.MAX_VALUE;
    protected static final int DEFAULT_INITIAL_LIMIT = 0;
    protected static final int DEFAULT_MAX_STATEMENTS_LIMIT = 0;
    protected static final int DEFAULT_INACTIVITY_TIMEOUT = 0;
    protected static final int DEFAULT_TIMETOLIVE_TIMEOUT = 0;
    protected static final int DEFAULT_ABANDONED_CONN_TIMEOUT = 0;
    protected static final int DEFAULT_CONNECTION_WAIT_TIMEOUT = 0;
    protected static final String DEFAULT_ATTRIBUTE_WEIGHT = "0";
    protected static final int DEFAULT_LOWER_THRESHOLD_LIMIT = 20;
    protected static final int DEFAULT_PROPERTY_CHECK_INTERVAL = 900;
    protected static final int CLOSE_AND_REMOVE_ALL_CONNECTIONS = 1;
    protected static final int CLOSE_AND_REMOVE_FAILOVER_CONNECTIONS = 2;
    protected static final int PROCESS_INACTIVITY_TIMEOUT = 4;
    protected static final int CLOSE_AND_REMOVE_N_CONNECTIONS = 8;
    protected static final int DISABLE_STATEMENT_CACHING = 16;
    protected static final int RESET_STATEMENT_CACHE_SIZE = 18;
    protected static final int CLOSE_AND_REMOVE_RLB_CONNECTIONS = 24;
    protected static final int ABORT_AND_CLOSE_ALL_CONNECTIONS = 32;
    public static final int REFRESH_INVALID_CONNECTIONS = 4096;
    public static final int REFRESH_ALL_CONNECTIONS = 8192;
    private static final String ATTRKEY_DELIM = "0xffff";
    protected int cacheMinLimit;
    protected int cacheMaxLimit;
    protected int cacheInitialLimit;
    protected int cacheMaxStatementsLimit;
    protected Properties cacheAttributeWeights;
    protected int cacheInactivityTimeout;
    protected int cacheTimeToLiveTimeout;
    protected int cacheAbandonedConnectionTimeout;
    protected int cacheLowerThresholdLimit;
    protected int cachePropertyCheckInterval;
    protected boolean cacheClosestConnectionMatch;
    protected boolean cacheValidateConnection;
    protected int cacheConnectionWaitTimeout;
    static final String MIN_LIMIT_KEY = "MinLimit";
    static final String MAX_LIMIT_KEY = "MaxLimit";
    static final String INITIAL_LIMIT_KEY = "InitialLimit";
    static final String MAX_STATEMENTS_LIMIT_KEY = "MaxStatementsLimit";
    static final String ATTRIBUTE_WEIGHTS_KEY = "AttributeWeights";
    static final String INACTIVITY_TIMEOUT_KEY = "InactivityTimeout";
    static final String TIME_TO_LIVE_TIMEOUT_KEY = "TimeToLiveTimeout";
    static final String ABANDONED_CONNECTION_TIMEOUT_KEY = "AbandonedConnectionTimeout";
    static final String LOWER_THRESHOLD_LIMIT_KEY = "LowerThresholdLimit";
    static final String PROPERTY_CHECK_INTERVAL_KEY = "PropertyCheckInterval";
    static final String VALIDATE_CONNECTION_KEY = "ValidateConnection";
    static final String CLOSEST_CONNECTION_MATCH_KEY = "ClosestConnectionMatch";
    static final String CONNECTION_WAIT_TIMEOUT_KEY = "ConnectionWaitTimeout";
    static final String LOCAL_TXN_COMMIT_ON_CLOSE = "LocalTransactionCommitOnClose";
    static final int INSTANCE_GOOD = 1;
    static final int INSTANCE_UNKNOWN = 2;
    static final int INSTANCE_VIOLATING = 3;
    static final int INSTANCE_NO_DATA = 4;
    static final int INSTANCE_BLOCKED = 5;
    static final int RLB_NUMBER_OF_HITS_PER_INSTANCE = 1000;
    int dbInstancePercentTotal;
    boolean useGoodGroup;
    Vector instancesToRetireQueue;
    OracleDatabaseInstance instanceToRetire;
    int retireConnectionsCount;
    int countTotal;
    protected OracleConnectionCacheManager cacheManager;
    protected boolean disableConnectionRequest;
    protected OracleImplicitConnectionCacheThread timeoutThread;
    protected OracleRuntimeLoadBalancingEventHandlerThread runtimeLoadBalancingThread;
    protected OracleGravitateConnectionCacheThread gravitateCacheThread;
    protected int connectionsToRemove;
    private HashMap userMap;
    Vector checkedOutConnectionList;
    LinkedList databaseInstancesList;
    int cacheSize;
    protected static final String EVENT_DELIMITER = " ";
    protected boolean isEntireServiceDownProcessed;
    protected int defaultUserPreFailureSize;
    protected String dataSourceServiceName;
    protected OracleFailoverWorkerThread failoverWorkerThread;
    protected Random rand;
    protected int downEventCount;
    protected int upEventCount;
    protected int pendingCreationRequests;
    protected int connectionClosedCount;
    protected int connectionCreatedCount;
    boolean cacheLocalTxnCommitOnClose;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    OracleImplicitConnectionCache(final OracleDataSource cacheEnabledDS, final Properties connectionCacheProperties) throws SQLException {
        this.cacheEnabledDS = null;
        this.cacheName = null;
        this.connectionPoolDS = null;
        this.fastConnectionFailoverEnabled = false;
        this.defaultUser = null;
        this.defaultPassword = null;
        this.cacheMinLimit = 0;
        this.cacheMaxLimit = Integer.MAX_VALUE;
        this.cacheInitialLimit = 0;
        this.cacheMaxStatementsLimit = 0;
        this.cacheAttributeWeights = null;
        this.cacheInactivityTimeout = 0;
        this.cacheTimeToLiveTimeout = 0;
        this.cacheAbandonedConnectionTimeout = 0;
        this.cacheLowerThresholdLimit = 20;
        this.cachePropertyCheckInterval = 900;
        this.cacheClosestConnectionMatch = false;
        this.cacheValidateConnection = false;
        this.cacheConnectionWaitTimeout = 0;
        this.dbInstancePercentTotal = 0;
        this.useGoodGroup = false;
        this.instancesToRetireQueue = null;
        this.instanceToRetire = null;
        this.retireConnectionsCount = 0;
        this.countTotal = 0;
        this.cacheManager = null;
        this.disableConnectionRequest = false;
        this.timeoutThread = null;
        this.runtimeLoadBalancingThread = null;
        this.gravitateCacheThread = null;
        this.connectionsToRemove = 0;
        this.userMap = null;
        this.checkedOutConnectionList = null;
        this.databaseInstancesList = null;
        this.cacheSize = 0;
        this.isEntireServiceDownProcessed = false;
        this.defaultUserPreFailureSize = 0;
        this.dataSourceServiceName = null;
        this.failoverWorkerThread = null;
        this.rand = null;
        this.downEventCount = 0;
        this.upEventCount = 0;
        this.pendingCreationRequests = 0;
        this.connectionClosedCount = 0;
        this.connectionCreatedCount = 0;
        this.cacheLocalTxnCommitOnClose = false;
        this.cacheEnabledDS = cacheEnabledDS;
        this.initializeConnectionCache();
        this.setConnectionCacheProperties(connectionCacheProperties);
        this.defaultUserPrePopulateCache(this.cacheInitialLimit);
    }
    
    private void defaultUserPrePopulateCache(final int n) throws SQLException {
        if (n > 0) {
            final String defaultUser = this.defaultUser;
            final String defaultPassword = this.defaultPassword;
            this.validateUser(defaultUser, defaultPassword);
            for (int i = 0; i < n; ++i) {
                final OraclePooledConnection oneConnection = this.makeOneConnection(defaultUser, defaultPassword);
                synchronized (this) {
                    if (oneConnection != null) {
                        --this.cacheSize;
                        this.storeCacheConnection(null, oneConnection);
                    }
                }
            }
        }
    }
    
    protected void initializeConnectionCache() throws SQLException {
        this.userMap = new HashMap();
        this.checkedOutConnectionList = new Vector();
        if (this.cacheManager == null) {
            this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
        }
        if (this.cacheEnabledDS.user != null && !this.cacheEnabledDS.user.startsWith("\"")) {
            this.defaultUser = this.cacheEnabledDS.user.toLowerCase();
        }
        else {
            this.defaultUser = this.cacheEnabledDS.user;
        }
        this.defaultPassword = this.cacheEnabledDS.password;
        if (this.connectionPoolDS == null) {
            if (this.cacheEnabledDS instanceof OracleXADataSource) {
                this.connectionPoolDS = new OracleXADataSource();
            }
            else {
                this.connectionPoolDS = new OracleConnectionPoolDataSource();
            }
            this.cacheEnabledDS.copy(this.connectionPoolDS);
        }
        final boolean fastConnectionFailoverEnabled = this.cacheEnabledDS.getFastConnectionFailoverEnabled();
        this.fastConnectionFailoverEnabled = fastConnectionFailoverEnabled;
        if (fastConnectionFailoverEnabled) {
            this.rand = new Random(0L);
            this.instancesToRetireQueue = new Vector();
            final OracleConnectionCacheManager cacheManager = this.cacheManager;
            ++cacheManager.failoverEnabledCacheCount;
        }
    }
    
    private void validateUser(final String s, final String s2) throws SQLException {
        if (s == null || s2 == null) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 79);
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    protected Connection getConnection(String lowerCase, final String s, final Properties properties) throws SQLException {
        OraclePooledConnection obj = null;
        Connection connection = null;
        try {
            if (this.disableConnectionRequest) {
                final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 142);
                sqlException.fillInStackTrace();
                throw sqlException;
            }
            this.validateUser(lowerCase, s);
            if (!lowerCase.startsWith("\"")) {
                lowerCase = lowerCase.toLowerCase();
            }
            if (this.getNumberOfCheckedOutConnections() < this.cacheMaxLimit) {
                obj = this.getCacheConnection(lowerCase, s, properties);
            }
            if (obj == null) {
                this.processConnectionCacheCallback();
                if (this.cacheSize > 0) {
                    obj = this.getCacheConnection(lowerCase, s, properties);
                }
                if (obj == null && this.cacheConnectionWaitTimeout > 0) {
                    long n = this.cacheConnectionWaitTimeout * 1000L;
                    long currentTimeMillis = System.currentTimeMillis();
                    do {
                        this.processConnectionWaitTimeout(n);
                        if (this.cacheSize > 0) {
                            obj = this.getCacheConnection(lowerCase, s, properties);
                        }
                        final long currentTimeMillis2 = System.currentTimeMillis();
                        n -= System.currentTimeMillis() - currentTimeMillis;
                        currentTimeMillis = currentTimeMillis2;
                    } while (obj == null && n > 0L);
                }
            }
            if (obj != null && obj.physicalConn != null) {
                connection = obj.getConnection();
                if (connection != null) {
                    if (this.cacheValidateConnection && this.testDatabaseConnection((OracleConnection)connection) != 0) {
                        ((OracleConnection)connection).close(4096);
                        final SQLException sqlException2 = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 143);
                        sqlException2.fillInStackTrace();
                        throw sqlException2;
                    }
                    if (this.cacheAbandonedConnectionTimeout > 0) {
                        ((OracleConnection)connection).setAbandonedTimeoutEnabled(true);
                    }
                    if (this.cacheTimeToLiveTimeout > 0) {
                        ((OracleConnection)connection).setStartTime(System.currentTimeMillis());
                    }
                    synchronized (this) {
                        --this.cacheSize;
                        this.checkedOutConnectionList.addElement(obj);
                    }
                }
            }
        }
        catch (SQLException ex) {
            synchronized (this) {
                if (obj != null) {
                    --this.cacheSize;
                    this.abortConnection(obj);
                }
            }
            throw ex;
        }
        return connection;
    }
    
    private OraclePooledConnection getCacheConnection(final String s, final String s2, final Properties properties) throws SQLException {
        OraclePooledConnection oraclePooledConnection = this.retrieveCacheConnection(s, s2, properties);
        if (oraclePooledConnection == null) {
            oraclePooledConnection = this.makeOneConnection(s, s2);
            if (oraclePooledConnection != null && properties != null && !properties.isEmpty()) {
                this.setUnMatchedAttributes(properties, oraclePooledConnection);
            }
        }
        return oraclePooledConnection;
    }
    
    OraclePooledConnection makeOneConnection(final String s, final String s2) throws SQLException {
        OraclePooledConnection cacheConnection = null;
        boolean b = false;
        synchronized (this) {
            if (this.getTotalCachedConnections() + this.pendingCreationRequests < this.cacheMaxLimit) {
                ++this.pendingCreationRequests;
                b = true;
            }
        }
        if (b) {
            try {
                cacheConnection = this.makeCacheConnection(s, s2);
            }
            finally {
                synchronized (this) {
                    if (cacheConnection != null) {
                        ++this.connectionCreatedCount;
                    }
                    --this.pendingCreationRequests;
                }
            }
        }
        return cacheConnection;
    }
    
    protected int getTotalCachedConnections() {
        return this.cacheSize + this.getNumberOfCheckedOutConnections();
    }
    
    protected int getNumberOfCheckedOutConnections() {
        return this.checkedOutConnectionList.size();
    }
    
    private synchronized OraclePooledConnection retrieveCacheConnection(final String s, final String s2, final Properties properties) throws SQLException {
        OraclePooledConnection oraclePooledConnection = null;
        final OracleConnectionCacheEntry oracleConnectionCacheEntry = this.userMap.get(OraclePooledConnection.generateKey(s, s2));
        if (oracleConnectionCacheEntry != null) {
            if (properties == null || (properties != null && properties.isEmpty())) {
                if (oracleConnectionCacheEntry.userConnList != null) {
                    oraclePooledConnection = this.retrieveFromConnectionList(oracleConnectionCacheEntry.userConnList);
                }
            }
            else if (oracleConnectionCacheEntry.attrConnMap != null) {
                final Vector vector = oracleConnectionCacheEntry.attrConnMap.get(this.buildAttrKey(properties));
                if (vector != null) {
                    oraclePooledConnection = this.retrieveFromConnectionList(vector);
                }
                if (oraclePooledConnection == null && this.cacheClosestConnectionMatch) {
                    oraclePooledConnection = this.retrieveClosestConnectionMatch(oracleConnectionCacheEntry.attrConnMap, properties);
                }
                if (oraclePooledConnection == null && oracleConnectionCacheEntry.userConnList != null) {
                    oraclePooledConnection = this.retrieveFromConnectionList(oracleConnectionCacheEntry.userConnList);
                }
            }
        }
        if (oraclePooledConnection != null && properties != null && !properties.isEmpty()) {
            this.setUnMatchedAttributes(properties, oraclePooledConnection);
        }
        return oraclePooledConnection;
    }
    
    private OraclePooledConnection retrieveClosestConnectionMatch(final HashMap hashMap, final Properties properties) throws SQLException {
        OraclePooledConnection o = null;
        Vector vector = null;
        final int size = properties.size();
        int attributesWeightCount = 0;
        int n = 0;
        int n2 = 0;
        if (this.cacheAttributeWeights != null) {
            attributesWeightCount = this.getAttributesWeightCount(properties, null);
        }
        if (hashMap != null && !hashMap.isEmpty()) {
            final Iterator<Map.Entry<K, Vector>> iterator = hashMap.entrySet().iterator();
            while (iterator.hasNext()) {
                final Vector vector2 = iterator.next().getValue();
                final Object[] array = vector2.toArray();
                for (int size2 = vector2.size(), i = 0; i < size2; ++i) {
                    final OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)array[i];
                    if (oraclePooledConnection.cachedConnectionAttributes != null && !oraclePooledConnection.cachedConnectionAttributes.isEmpty() && oraclePooledConnection.cachedConnectionAttributes.size() <= size) {
                        if (attributesWeightCount > 0) {
                            final int attributesWeightCount2 = this.getAttributesWeightCount(properties, oraclePooledConnection.cachedConnectionAttributes);
                            if (attributesWeightCount2 > n) {
                                o = oraclePooledConnection;
                                n = attributesWeightCount2;
                                vector = vector2;
                            }
                        }
                        else {
                            final int attributesMatchCount = this.getAttributesMatchCount(properties, oraclePooledConnection.cachedConnectionAttributes);
                            if (attributesMatchCount > n2) {
                                o = oraclePooledConnection;
                                n2 = attributesMatchCount;
                                vector = vector2;
                            }
                        }
                    }
                }
            }
        }
        if (vector != null) {
            vector.remove(o);
        }
        return o;
    }
    
    private int getAttributesMatchCount(final Properties properties, final Properties properties2) throws SQLException {
        int n = 0;
        for (final Map.Entry<Object, Object> entry : properties.entrySet()) {
            final Object key = entry.getKey();
            final Object value = entry.getValue();
            if (properties2.containsKey(key) && value.equals(properties2.get(key))) {
                ++n;
            }
        }
        return n;
    }
    
    private int getAttributesWeightCount(final Properties properties, final Properties properties2) throws SQLException {
        int n = 0;
        for (final Map.Entry<Object, Object> entry : properties.entrySet()) {
            final Object key = entry.getKey();
            final Object value = entry.getValue();
            if (properties2 == null) {
                if (!this.cacheAttributeWeights.containsKey(key)) {
                    continue;
                }
                n += Integer.parseInt((String)this.cacheAttributeWeights.get(key));
            }
            else {
                if (!properties2.containsKey(key) || !value.equals(properties2.get(key))) {
                    continue;
                }
                if (this.cacheAttributeWeights.containsKey(key)) {
                    n += Integer.parseInt((String)this.cacheAttributeWeights.get(key));
                }
                else {
                    ++n;
                }
            }
        }
        return n;
    }
    
    private void setUnMatchedAttributes(final Properties t, final OraclePooledConnection oraclePooledConnection) throws SQLException {
        if (oraclePooledConnection.unMatchedCachedConnAttr == null) {
            oraclePooledConnection.unMatchedCachedConnAttr = new Properties();
        }
        else {
            oraclePooledConnection.unMatchedCachedConnAttr.clear();
        }
        if (!this.cacheClosestConnectionMatch) {
            oraclePooledConnection.unMatchedCachedConnAttr.putAll(t);
        }
        else {
            final Properties cachedConnectionAttributes = oraclePooledConnection.cachedConnectionAttributes;
            for (final Map.Entry<Object, Object> entry : t.entrySet()) {
                final Object key = entry.getKey();
                final Object value = entry.getValue();
                if (!cachedConnectionAttributes.containsKey(key) && !value.equals(cachedConnectionAttributes.get(key))) {
                    oraclePooledConnection.unMatchedCachedConnAttr.put(key, value);
                }
            }
        }
    }
    
    private OraclePooledConnection retrieveFromConnectionList(final Vector vector) throws SQLException {
        if (vector.isEmpty()) {
            return null;
        }
        OraclePooledConnection selectConnectionFromList = null;
        if (this.fastConnectionFailoverEnabled) {
            if (this.useGoodGroup && this.databaseInstancesList != null && this.databaseInstancesList.size() > 0) {
                synchronized (this.databaseInstancesList) {
                    final int size = this.databaseInstancesList.size();
                    final boolean[] array = new boolean[size];
                    int dbInstancePercentTotal = this.dbInstancePercentTotal;
                Label_0234:
                    for (int i = 0; i < size; ++i) {
                        int n = 0;
                        int nextInt;
                        if (dbInstancePercentTotal <= 1) {
                            nextInt = 0;
                        }
                        else {
                            nextInt = this.rand.nextInt(dbInstancePercentTotal - 1);
                        }
                        for (int j = 0; j < size; ++j) {
                            final OracleDatabaseInstance oracleDatabaseInstance = this.databaseInstancesList.get(j);
                            if (!array[j] && oracleDatabaseInstance.flag <= 3) {
                                n += oracleDatabaseInstance.percent;
                                if (nextInt <= n) {
                                    if (i == 0) {
                                        final OracleDatabaseInstance oracleDatabaseInstance2 = oracleDatabaseInstance;
                                        ++oracleDatabaseInstance2.attemptedConnRequestCount;
                                    }
                                    if ((selectConnectionFromList = this.selectConnectionFromList(vector, oracleDatabaseInstance)) != null) {
                                        break Label_0234;
                                    }
                                    dbInstancePercentTotal -= oracleDatabaseInstance.percent;
                                    array[j] = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            else {
                final int size2 = vector.size();
                int nextInt2 = this.rand.nextInt(size2);
                for (int k = 0; k < size2; ++k) {
                    final OraclePooledConnection oraclePooledConnection = vector.get((nextInt2++ + size2) % size2);
                    if (!oraclePooledConnection.connectionMarkedDown) {
                        selectConnectionFromList = oraclePooledConnection;
                        vector.remove(selectConnectionFromList);
                        break;
                    }
                }
            }
        }
        else {
            selectConnectionFromList = vector.remove(0);
        }
        return selectConnectionFromList;
    }
    
    private OraclePooledConnection selectConnectionFromList(final Vector vector, final OracleDatabaseInstance oracleDatabaseInstance) {
        OraclePooledConnection o = null;
        for (int size = vector.size(), i = 0; i < size; ++i) {
            final OraclePooledConnection oraclePooledConnection = vector.get(i);
            if (!oraclePooledConnection.connectionMarkedDown && oraclePooledConnection.dataSourceDbUniqNameKey == oracleDatabaseInstance.databaseUniqName && oraclePooledConnection.dataSourceInstanceNameKey == oracleDatabaseInstance.instanceName) {
                o = oraclePooledConnection;
                vector.remove(o);
                break;
            }
        }
        return o;
    }
    
    private void removeCacheConnection(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        boolean b = false;
        final OracleConnectionCacheEntry removeFromImplictCache = oraclePooledConnection.removeFromImplictCache(this.userMap);
        if (removeFromImplictCache != null) {
            final Properties cachedConnectionAttributes = oraclePooledConnection.cachedConnectionAttributes;
            if (cachedConnectionAttributes == null || (cachedConnectionAttributes != null && cachedConnectionAttributes.isEmpty())) {
                if (removeFromImplictCache.userConnList != null) {
                    b = removeFromImplictCache.userConnList.removeElement(oraclePooledConnection);
                }
            }
            else if (removeFromImplictCache.attrConnMap != null) {
                final Vector vector = removeFromImplictCache.attrConnMap.get(this.buildAttrKey(cachedConnectionAttributes));
                if (vector != null) {
                    if (oraclePooledConnection.unMatchedCachedConnAttr != null) {
                        oraclePooledConnection.unMatchedCachedConnAttr.clear();
                        oraclePooledConnection.unMatchedCachedConnAttr = null;
                    }
                    if (oraclePooledConnection.cachedConnectionAttributes != null) {
                        oraclePooledConnection.cachedConnectionAttributes.clear();
                        oraclePooledConnection.cachedConnectionAttributes = null;
                    }
                    b = vector.removeElement(oraclePooledConnection);
                }
            }
        }
        if (b) {
            --this.cacheSize;
        }
    }
    
    protected void doForEveryCachedConnection(final int n) throws SQLException {
        int n2 = 0;
        synchronized (this) {
            if (this.userMap != null && !this.userMap.isEmpty()) {
                final Iterator<Map.Entry<K, OracleConnectionCacheEntry>> iterator = this.userMap.entrySet().iterator();
                while (iterator.hasNext()) {
                    final OracleConnectionCacheEntry oracleConnectionCacheEntry = iterator.next().getValue();
                    if (oracleConnectionCacheEntry.userConnList != null && !oracleConnectionCacheEntry.userConnList.isEmpty()) {
                        final Object[] array = oracleConnectionCacheEntry.userConnList.toArray();
                        for (int i = 0; i < array.length; ++i) {
                            final OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)array[i];
                            if (oraclePooledConnection != null && this.performPooledConnectionTask(oraclePooledConnection, n)) {
                                ++n2;
                            }
                        }
                    }
                    if (oracleConnectionCacheEntry.attrConnMap != null && !oracleConnectionCacheEntry.attrConnMap.isEmpty()) {
                        final Iterator<Map.Entry<K, Vector>> iterator2 = oracleConnectionCacheEntry.attrConnMap.entrySet().iterator();
                        while (iterator2.hasNext()) {
                            final Object[] array2 = iterator2.next().getValue().toArray();
                            for (int j = 0; j < array2.length; ++j) {
                                final OraclePooledConnection oraclePooledConnection2 = (OraclePooledConnection)array2[j];
                                if (oraclePooledConnection2 != null && this.performPooledConnectionTask(oraclePooledConnection2, n)) {
                                    ++n2;
                                }
                            }
                        }
                        if (n != 1 && n != 32) {
                            continue;
                        }
                        oracleConnectionCacheEntry.attrConnMap.clear();
                    }
                }
                if (n == 1 || n == 32) {
                    this.userMap.clear();
                    this.cacheSize = 0;
                }
            }
        }
        if (n2 > 0) {
            this.defaultUserPrePopulateCache(n2);
        }
    }
    
    private boolean performPooledConnectionTask(final OraclePooledConnection oraclePooledConnection, final int n) throws SQLException {
        boolean b = false;
        switch (n) {
            case 2: {
                if (oraclePooledConnection.connectionMarkedDown) {
                    oraclePooledConnection.needToAbort = true;
                    this.closeAndRemovePooledConnection(oraclePooledConnection);
                    break;
                }
                break;
            }
            case 8: {
                if (this.connectionsToRemove > 0) {
                    this.closeAndRemovePooledConnection(oraclePooledConnection);
                    --this.connectionsToRemove;
                    break;
                }
                break;
            }
            case 24: {
                if (this.retireConnectionsCount <= 0 || this.instanceToRetire.databaseUniqName != oraclePooledConnection.dataSourceDbUniqNameKey || this.instanceToRetire.instanceName != oraclePooledConnection.dataSourceInstanceNameKey) {
                    break;
                }
                this.closeAndRemovePooledConnection(oraclePooledConnection);
                --this.retireConnectionsCount;
                if (this.getTotalCachedConnections() < this.cacheMinLimit) {
                    b = true;
                    break;
                }
                break;
            }
            case 4096: {
                Connection connection = oraclePooledConnection.getLogicalHandle();
                if ((connection != null || (connection = oraclePooledConnection.getPhysicalHandle()) != null) && this.testDatabaseConnection((OracleConnection)connection) != 0) {
                    this.closeAndRemovePooledConnection(oraclePooledConnection);
                    b = true;
                    break;
                }
                break;
            }
            case 8192: {
                this.closeAndRemovePooledConnection(oraclePooledConnection);
                b = true;
                break;
            }
            case 1: {
                this.closeAndRemovePooledConnection(oraclePooledConnection);
                break;
            }
            case 4: {
                this.processInactivityTimeout(oraclePooledConnection);
                break;
            }
            case 16: {
                this.setStatementCaching(oraclePooledConnection, this.cacheMaxStatementsLimit, false);
                break;
            }
            case 18: {
                this.setStatementCaching(oraclePooledConnection, this.cacheMaxStatementsLimit, true);
                break;
            }
            case 32: {
                this.abortConnection(oraclePooledConnection);
                this.closeAndRemovePooledConnection(oraclePooledConnection);
                break;
            }
        }
        return b;
    }
    
    protected synchronized void doForEveryCheckedOutConnection(final int n) throws SQLException {
        final int size = this.checkedOutConnectionList.size();
        switch (n) {
            case 1: {
                for (int i = 0; i < size; ++i) {
                    this.closeCheckedOutConnection((OraclePooledConnection)this.checkedOutConnectionList.get(i), false);
                }
                this.checkedOutConnectionList.removeAllElements();
                break;
            }
            case 24: {
                for (int index = 0; index < size && this.retireConnectionsCount > 0; ++index) {
                    final OraclePooledConnection oraclePooledConnection = this.checkedOutConnectionList.get(index);
                    if (this.instanceToRetire.databaseUniqName == oraclePooledConnection.dataSourceDbUniqNameKey && this.instanceToRetire.instanceName == oraclePooledConnection.dataSourceInstanceNameKey) {
                        oraclePooledConnection.closeOption = 4096;
                        this.retireConnectionsCount -= 2;
                    }
                }
                break;
            }
            case 32: {
                for (int j = 0; j < size; ++j) {
                    final OraclePooledConnection oraclePooledConnection2;
                    this.abortConnection(oraclePooledConnection2 = this.checkedOutConnectionList.get(j));
                    this.closeCheckedOutConnection(oraclePooledConnection2, false);
                }
                this.checkedOutConnectionList.removeAllElements();
                break;
            }
        }
    }
    
    protected void closeCheckedOutConnection(final OraclePooledConnection oraclePooledConnection, final boolean b) throws SQLException {
        if (oraclePooledConnection != null) {
            final OracleConnection oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
            try {
                if (!oracleConnection.getAutoCommit() && !oraclePooledConnection.needToAbort) {
                    oracleConnection.rollback();
                }
            }
            catch (SQLException ex) {}
            if (b) {
                final boolean localTxnCommitOnClose = oraclePooledConnection.localTxnCommitOnClose;
                try {
                    oraclePooledConnection.localTxnCommitOnClose = false;
                    oracleConnection.cleanupAndClose(true);
                }
                catch (SQLException ex2) {}
                finally {
                    if (oraclePooledConnection.localTxnCommitOnClose != localTxnCommitOnClose) {
                        oraclePooledConnection.localTxnCommitOnClose = localTxnCommitOnClose;
                    }
                }
            }
            else {
                this.actualPooledConnectionClose(oraclePooledConnection);
            }
        }
    }
    
    private synchronized void storeCacheConnection(final Properties properties, final OraclePooledConnection e) throws SQLException {
        if (e == null || e.physicalConn == null) {
            return;
        }
        if (this.cacheInactivityTimeout > 0) {
            e.setLastAccessedTime(System.currentTimeMillis());
        }
        if (e.unMatchedCachedConnAttr != null) {
            e.unMatchedCachedConnAttr.clear();
            e.unMatchedCachedConnAttr = null;
        }
        final OracleConnectionCacheEntry removeFromImplictCache = e.removeFromImplictCache(this.userMap);
        boolean b;
        if (removeFromImplictCache != null) {
            if (properties == null || (properties != null && properties.isEmpty())) {
                if (removeFromImplictCache.userConnList == null) {
                    removeFromImplictCache.userConnList = new Vector();
                }
                b = removeFromImplictCache.userConnList.add(e);
            }
            else {
                e.cachedConnectionAttributes = properties;
                if (removeFromImplictCache.attrConnMap == null) {
                    removeFromImplictCache.attrConnMap = new HashMap();
                }
                final String buildAttrKey = this.buildAttrKey(properties);
                final Vector<OraclePooledConnection> vector = removeFromImplictCache.attrConnMap.get(buildAttrKey);
                if (vector != null) {
                    b = vector.add(e);
                }
                else {
                    final Vector<OraclePooledConnection> value = new Vector<OraclePooledConnection>();
                    b = value.add(e);
                    removeFromImplictCache.attrConnMap.put(buildAttrKey, value);
                }
            }
        }
        else {
            final OracleConnectionCacheEntry oracleConnectionCacheEntry = new OracleConnectionCacheEntry();
            e.addToImplicitCache(this.userMap, oracleConnectionCacheEntry);
            if (properties == null || (properties != null && properties.isEmpty())) {
                final Vector<OraclePooledConnection> userConnList = new Vector<OraclePooledConnection>();
                b = userConnList.add(e);
                oracleConnectionCacheEntry.userConnList = userConnList;
            }
            else {
                final String buildAttrKey2 = this.buildAttrKey(properties);
                e.cachedConnectionAttributes = properties;
                final HashMap<String, Vector<OraclePooledConnection>> attrConnMap = new HashMap<String, Vector<OraclePooledConnection>>();
                final Vector<OraclePooledConnection> value2 = new Vector<OraclePooledConnection>();
                b = value2.add(e);
                attrConnMap.put(buildAttrKey2, value2);
                oracleConnectionCacheEntry.attrConnMap = attrConnMap;
            }
        }
        if (b) {
            ++this.cacheSize;
        }
        if (this.cacheConnectionWaitTimeout > 0) {
            this.notifyAll();
        }
    }
    
    private String buildAttrKey(final Properties properties) throws SQLException {
        final int size = properties.keySet().size();
        final Object[] array = properties.keySet().toArray();
        int i = 1;
        final StringBuffer sb = new StringBuffer();
        while (i != 0) {
            i = 0;
            for (int j = 0; j < size - 1; ++j) {
                if (((String)array[j]).compareTo((String)array[j + 1]) > 0) {
                    i = 1;
                    final Object o = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = o;
                }
            }
        }
        for (int k = 0; k < size; ++k) {
            sb.append(array[k] + "0xffff" + properties.get(array[k]));
        }
        return sb.toString();
    }
    
    protected OraclePooledConnection makeCacheConnection(final String s, final String s2) throws SQLException {
        final OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)this.connectionPoolDS.getPooledConnection(s, s2);
        if (oraclePooledConnection != null) {
            if (this.cacheMaxStatementsLimit > 0) {
                this.setStatementCaching(oraclePooledConnection, this.cacheMaxStatementsLimit, true);
            }
            oraclePooledConnection.registerImplicitCacheConnectionEventListener(new OracleConnectionCacheEventListener(this));
            oraclePooledConnection.cachedConnectionAttributes = new Properties();
            if (this.fastConnectionFailoverEnabled) {
                this.initFailoverParameters(oraclePooledConnection);
            }
            synchronized (this) {
                ++this.cacheSize;
                if (this.fastConnectionFailoverEnabled && this.runtimeLoadBalancingThread == null) {
                    this.runtimeLoadBalancingThread = new OracleRuntimeLoadBalancingEventHandlerThread(this.dataSourceServiceName);
                    this.cacheManager.checkAndStartThread(this.runtimeLoadBalancingThread);
                }
            }
            oraclePooledConnection.localTxnCommitOnClose = this.cacheLocalTxnCommitOnClose;
        }
        return oraclePooledConnection;
    }
    
    private void setStatementCaching(final OraclePooledConnection oraclePooledConnection, final int statementCacheSize, final boolean b) throws SQLException {
        if (statementCacheSize > 0) {
            oraclePooledConnection.setStatementCacheSize(statementCacheSize);
        }
        oraclePooledConnection.setImplicitCachingEnabled(b);
        oraclePooledConnection.setExplicitCachingEnabled(b);
    }
    
    protected synchronized void reusePooledConnection(final PooledConnection pooledConnection) throws SQLException {
        final OraclePooledConnection obj = (OraclePooledConnection)pooledConnection;
        if (obj != null && obj.physicalConn != null) {
            if (obj.localTxnCommitOnClose) {
                obj.physicalConn.commit();
            }
            this.storeCacheConnection(obj.cachedConnectionAttributes, obj);
            this.checkedOutConnectionList.removeElement(obj);
            obj.logicalHandle = null;
        }
    }
    
    protected void closePooledConnection(final PooledConnection obj) throws SQLException {
        if (obj != null) {
            this.actualPooledConnectionClose((OraclePooledConnection)obj);
            if (((OraclePooledConnection)obj).closeOption == 4096) {
                this.checkedOutConnectionList.removeElement(obj);
            }
            if (this.getTotalCachedConnections() < this.cacheMinLimit) {
                this.defaultUserPrePopulateCache(1);
            }
        }
    }
    
    protected void refreshCacheConnections(final int n) throws SQLException {
        this.doForEveryCachedConnection(n);
    }
    
    protected void reinitializeCacheConnections(final Properties connectionCacheProperties) throws SQLException {
        int n = 0;
        synchronized (this) {
            this.defaultUser = this.cacheEnabledDS.user;
            this.defaultPassword = this.cacheEnabledDS.password;
            this.fastConnectionFailoverEnabled = this.cacheEnabledDS.getFastConnectionFailoverEnabled();
            this.cleanupTimeoutThread();
            this.doForEveryCheckedOutConnection(1);
            final int cacheInitialLimit = this.cacheInitialLimit;
            final int cacheMaxLimit = this.cacheMaxLimit;
            final int cacheMaxStatementsLimit = this.cacheMaxStatementsLimit;
            this.setConnectionCacheProperties(connectionCacheProperties);
            if (this.cacheInitialLimit > cacheInitialLimit) {
                n = this.cacheInitialLimit - cacheInitialLimit;
            }
            if (cacheMaxLimit != Integer.MAX_VALUE && this.cacheMaxLimit < cacheMaxLimit && this.cacheSize > this.cacheMaxLimit) {
                this.connectionsToRemove = this.cacheSize - this.cacheMaxLimit;
                this.doForEveryCachedConnection(8);
                this.connectionsToRemove = 0;
            }
            if (this.cacheMaxStatementsLimit != cacheMaxStatementsLimit) {
                if (this.cacheMaxStatementsLimit == 0) {
                    this.doForEveryCachedConnection(16);
                }
                else {
                    this.doForEveryCachedConnection(18);
                }
            }
        }
        if (n > 0) {
            this.defaultUserPrePopulateCache(n);
        }
    }
    
    protected synchronized void setConnectionCacheProperties(final Properties properties) throws SQLException {
        try {
            if (properties != null) {
                final String property;
                if ((property = properties.getProperty("MinLimit")) != null && (this.cacheMinLimit = Integer.parseInt(property)) < 0) {
                    this.cacheMinLimit = 0;
                }
                final String property2;
                if ((property2 = properties.getProperty("MaxLimit")) != null && (this.cacheMaxLimit = Integer.parseInt(property2)) < 0) {
                    this.cacheMaxLimit = Integer.MAX_VALUE;
                }
                if (this.cacheMaxLimit < this.cacheMinLimit) {
                    this.cacheMinLimit = this.cacheMaxLimit;
                }
                final String property3;
                if ((property3 = properties.getProperty("InitialLimit")) != null && (this.cacheInitialLimit = Integer.parseInt(property3)) < 0) {
                    this.cacheInitialLimit = 0;
                }
                if (this.cacheInitialLimit > this.cacheMaxLimit) {
                    this.cacheInitialLimit = this.cacheMaxLimit;
                }
                final String property4;
                if ((property4 = properties.getProperty("MaxStatementsLimit")) != null && (this.cacheMaxStatementsLimit = Integer.parseInt(property4)) < 0) {
                    this.cacheMaxStatementsLimit = 0;
                }
                final Properties t = (Properties)properties.get("AttributeWeights");
                if (t != null) {
                    final Iterator<Map.Entry<Object, Object>> iterator = t.entrySet().iterator();
                    while (iterator.hasNext()) {
                        final Object key = iterator.next().getKey();
                        final String s;
                        final int int1;
                        if ((s = (String)t.get(key)) != null && (int1 = Integer.parseInt(s)) < 0) {
                            t.put(key, "0");
                        }
                    }
                    if (this.cacheAttributeWeights == null) {
                        this.cacheAttributeWeights = new Properties();
                    }
                    this.cacheAttributeWeights.putAll(t);
                }
                final String property5;
                if ((property5 = properties.getProperty("InactivityTimeout")) != null && (this.cacheInactivityTimeout = Integer.parseInt(property5)) < 0) {
                    this.cacheInactivityTimeout = 0;
                }
                final String property6;
                if ((property6 = properties.getProperty("TimeToLiveTimeout")) != null && (this.cacheTimeToLiveTimeout = Integer.parseInt(property6)) < 0) {
                    this.cacheTimeToLiveTimeout = 0;
                }
                final String property7;
                if ((property7 = properties.getProperty("AbandonedConnectionTimeout")) != null && (this.cacheAbandonedConnectionTimeout = Integer.parseInt(property7)) < 0) {
                    this.cacheAbandonedConnectionTimeout = 0;
                }
                final String property8;
                if ((property8 = properties.getProperty("LowerThresholdLimit")) != null) {
                    this.cacheLowerThresholdLimit = Integer.parseInt(property8);
                    if (this.cacheLowerThresholdLimit < 0 || this.cacheLowerThresholdLimit > 100) {
                        this.cacheLowerThresholdLimit = 20;
                    }
                }
                final String property9;
                if ((property9 = properties.getProperty("PropertyCheckInterval")) != null && (this.cachePropertyCheckInterval = Integer.parseInt(property9)) < 0) {
                    this.cachePropertyCheckInterval = 900;
                }
                final String property10;
                if ((property10 = properties.getProperty("ValidateConnection")) != null) {
                    this.cacheValidateConnection = Boolean.valueOf(property10);
                }
                final String property11;
                if ((property11 = properties.getProperty("ClosestConnectionMatch")) != null) {
                    this.cacheClosestConnectionMatch = Boolean.valueOf(property11);
                }
                final String property12;
                if ((property12 = properties.getProperty("ConnectionWaitTimeout")) != null && (this.cacheConnectionWaitTimeout = Integer.parseInt(property12)) < 0) {
                    this.cacheConnectionWaitTimeout = 0;
                }
                final String property13;
                if ((property13 = properties.getProperty("LocalTransactionCommitOnClose")) != null) {
                    this.cacheLocalTxnCommitOnClose = property13.equalsIgnoreCase("true");
                }
            }
            else {
                this.cacheMinLimit = 0;
                this.cacheMaxLimit = Integer.MAX_VALUE;
                this.cacheInitialLimit = 0;
                this.cacheMaxStatementsLimit = 0;
                this.cacheAttributeWeights = null;
                this.cacheInactivityTimeout = 0;
                this.cacheTimeToLiveTimeout = 0;
                this.cacheAbandonedConnectionTimeout = 0;
                this.cacheLowerThresholdLimit = 20;
                this.cachePropertyCheckInterval = 900;
                this.cacheClosestConnectionMatch = false;
                this.cacheValidateConnection = false;
                this.cacheConnectionWaitTimeout = 0;
                this.cacheLocalTxnCommitOnClose = false;
            }
            if ((this.cacheInactivityTimeout > 0 || this.cacheTimeToLiveTimeout > 0 || this.cacheAbandonedConnectionTimeout > 0) && this.cachePropertyCheckInterval > 0) {
                if (this.timeoutThread == null) {
                    this.timeoutThread = new OracleImplicitConnectionCacheThread(this);
                }
                this.cacheManager.checkAndStartThread(this.timeoutThread);
            }
            if (this.cachePropertyCheckInterval == 0) {
                this.cleanupTimeoutThread();
            }
        }
        catch (NumberFormatException ex) {
            final SQLException sqlException = DatabaseError.createSqlException(this.getConnectionDuringExceptionHandling(), 139, "OracleImplicitConnectionCache:setConnectionCacheProperties() - NumberFormatException Occurred :" + ex.getMessage());
            sqlException.fillInStackTrace();
            throw sqlException;
        }
    }
    
    protected Properties getConnectionCacheProperties() throws SQLException {
        final Properties properties = new Properties();
        properties.setProperty("MinLimit", String.valueOf(this.cacheMinLimit));
        properties.setProperty("MaxLimit", String.valueOf(this.cacheMaxLimit));
        properties.setProperty("InitialLimit", String.valueOf(this.cacheInitialLimit));
        properties.setProperty("MaxStatementsLimit", String.valueOf(this.cacheMaxStatementsLimit));
        if (this.cacheAttributeWeights != null) {
            properties.put("AttributeWeights", this.cacheAttributeWeights);
        }
        else {
            properties.setProperty("AttributeWeights", "NULL");
        }
        properties.setProperty("InactivityTimeout", String.valueOf(this.cacheInactivityTimeout));
        properties.setProperty("TimeToLiveTimeout", String.valueOf(this.cacheTimeToLiveTimeout));
        properties.setProperty("AbandonedConnectionTimeout", String.valueOf(this.cacheAbandonedConnectionTimeout));
        properties.setProperty("LowerThresholdLimit", String.valueOf(this.cacheLowerThresholdLimit));
        properties.setProperty("PropertyCheckInterval", String.valueOf(this.cachePropertyCheckInterval));
        properties.setProperty("ConnectionWaitTimeout", String.valueOf(this.cacheConnectionWaitTimeout));
        properties.setProperty("ValidateConnection", String.valueOf(this.cacheValidateConnection));
        properties.setProperty("ClosestConnectionMatch", String.valueOf(this.cacheClosestConnectionMatch));
        properties.setProperty("LocalTransactionCommitOnClose", String.valueOf(this.cacheLocalTxnCommitOnClose));
        return properties;
    }
    
    protected int testDatabaseConnection(final OracleConnection oracleConnection) throws SQLException {
        return oracleConnection.pingDatabase();
    }
    
    protected synchronized void closeConnectionCache(final int n) throws SQLException {
        this.cleanupTimeoutThread();
        this.purgeCacheConnections(true, n);
        this.connectionPoolDS = null;
        this.cacheEnabledDS = null;
        this.checkedOutConnectionList = null;
        this.userMap = null;
        this.cacheManager = null;
    }
    
    protected synchronized void disableConnectionCache() throws SQLException {
        this.disableConnectionRequest = true;
    }
    
    protected synchronized void enableConnectionCache() throws SQLException {
        this.disableConnectionRequest = false;
    }
    
    protected void initFailoverParameters(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        String s = null;
        String s2 = null;
        final Properties serverSessionInfo = ((OracleConnection)oraclePooledConnection.getPhysicalHandle()).getServerSessionInfo();
        final String property = serverSessionInfo.getProperty("INSTANCE_NAME");
        if (property != null) {
            final String intern = property.trim().toLowerCase().intern();
            oraclePooledConnection.dataSourceInstanceNameKey = intern;
            s = intern;
        }
        final String property2 = serverSessionInfo.getProperty("SERVER_HOST");
        if (property2 != null) {
            oraclePooledConnection.dataSourceHostNameKey = property2.trim().toLowerCase().intern();
        }
        final String property3 = serverSessionInfo.getProperty("SERVICE_NAME");
        if (property3 != null) {
            this.dataSourceServiceName = property3.trim();
        }
        final String property4 = serverSessionInfo.getProperty("DATABASE_NAME");
        if (property4 != null) {
            final String intern2 = property4.trim().toLowerCase().intern();
            oraclePooledConnection.dataSourceDbUniqNameKey = intern2;
            s2 = intern2;
        }
        if (this.databaseInstancesList == null) {
            this.databaseInstancesList = new LinkedList();
        }
        final int size = this.databaseInstancesList.size();
        synchronized (this.databaseInstancesList) {
            boolean b = false;
            for (int i = 0; i < size; ++i) {
                final OracleDatabaseInstance oracleDatabaseInstance = this.databaseInstancesList.get(i);
                if (oracleDatabaseInstance.databaseUniqName == s2 && oracleDatabaseInstance.instanceName == s) {
                    final OracleDatabaseInstance oracleDatabaseInstance2 = oracleDatabaseInstance;
                    ++oracleDatabaseInstance2.numberOfConnectionsCount;
                    b = true;
                    break;
                }
            }
            if (!b) {
                final OracleDatabaseInstance oracleDatabaseInstance3;
                final OracleDatabaseInstance e = oracleDatabaseInstance3 = new OracleDatabaseInstance(s2, s);
                ++oracleDatabaseInstance3.numberOfConnectionsCount;
                this.databaseInstancesList.add(e);
            }
        }
    }
    
    protected void processFailoverEvent(final int n, final String s, final String s2, final String s3, final String s4, final int n2) {
        if (n == 256) {
            if (s4.equalsIgnoreCase("down") || s4.equalsIgnoreCase("not_restarting") || s4.equalsIgnoreCase("restart_failed")) {
                ++this.downEventCount;
                this.markDownLostConnections(true, false, s, s2, s3, s4);
                this.cleanupFailoverConnections(true, false, s, s2, s3, s4);
            }
            else if (s4.equalsIgnoreCase("up")) {
                if (this.downEventCount > 0) {
                    ++this.upEventCount;
                }
                try {
                    this.processUpEvent(n2);
                }
                catch (Exception ex) {}
                this.isEntireServiceDownProcessed = false;
            }
        }
        else if (n == 512 && s4.equalsIgnoreCase("nodedown")) {
            this.markDownLostConnections(false, true, s, s2, s3, s4);
            this.cleanupFailoverConnections(false, true, s, s2, s3, s4);
        }
    }
    
    void processUpEvent(int n) throws SQLException {
        int n2 = 0;
        final int totalCachedConnections = this.getTotalCachedConnections();
        boolean b = false;
        synchronized (this) {
            if (n <= 1) {
                n = 2;
            }
            int defaultUserPreFailureSize;
            if (this.downEventCount == 0 && this.upEventCount == 0 && this.getNumberOfDefaultUserConnections() > 0) {
                defaultUserPreFailureSize = (int)(this.cacheSize * 0.25);
            }
            else {
                defaultUserPreFailureSize = this.defaultUserPreFailureSize;
            }
            if (defaultUserPreFailureSize <= 0) {
                if (this.getNumberOfDefaultUserConnections() <= 0) {
                    return;
                }
                n2 = (int)(this.cacheSize * 0.25);
                b = true;
            }
            else {
                n2 = defaultUserPreFailureSize / n;
                if (n2 + totalCachedConnections > this.cacheMaxLimit) {
                    b = true;
                }
            }
            if (this.downEventCount == this.upEventCount) {
                this.defaultUserPreFailureSize = 0;
                this.downEventCount = 0;
                this.upEventCount = 0;
            }
        }
        if (n2 > 0) {
            this.loadBalanceConnections(n2, b);
        }
    }
    
    private void loadBalanceConnections(final int connectionsToRemove, final boolean b) throws SQLException {
        if (b) {
            this.connectionsToRemove = connectionsToRemove;
            this.doForEveryCachedConnection(8);
            this.connectionsToRemove = 0;
        }
        if (connectionsToRemove <= 10) {
            try {
                this.defaultUserPrePopulateCache(connectionsToRemove);
            }
            catch (Exception ex) {}
        }
        else {
            final int n = (int)(connectionsToRemove * 0.25);
            for (int i = 0; i < 4; ++i) {
                try {
                    this.defaultUserPrePopulateCache(n);
                }
                catch (Exception ex2) {}
            }
        }
    }
    
    private int getNumberOfDefaultUserConnections() {
        int size = 0;
        if (this.userMap != null && !this.userMap.isEmpty()) {
            final OracleConnectionCacheEntry oracleConnectionCacheEntry = this.userMap.get(OraclePooledConnection.generateKey(this.defaultUser, this.defaultPassword));
            if (oracleConnectionCacheEntry != null && oracleConnectionCacheEntry.userConnList != null && !oracleConnectionCacheEntry.userConnList.isEmpty()) {
                size = oracleConnectionCacheEntry.userConnList.size();
            }
        }
        return size;
    }
    
    synchronized void markDownLostConnections(final boolean b, final boolean b2, final String s, final String s2, final String s3, final String s4) {
        if (!this.isEntireServiceDownProcessed) {
            if (this.userMap != null && !this.userMap.isEmpty()) {
                final Iterator<Map.Entry<String, V>> iterator = this.userMap.entrySet().iterator();
                while (iterator.hasNext()) {
                    boolean b3 = false;
                    final Map.Entry<String, V> entry = iterator.next();
                    String string = null;
                    if (this.defaultUser != null && this.defaultPassword != null) {
                        string = this.defaultUser + this.defaultPassword;
                    }
                    if (string != null && string.equalsIgnoreCase(entry.getKey())) {
                        b3 = true;
                    }
                    final OracleConnectionCacheEntry oracleConnectionCacheEntry = (OracleConnectionCacheEntry)entry.getValue();
                    if (oracleConnectionCacheEntry != null && oracleConnectionCacheEntry.userConnList != null && !oracleConnectionCacheEntry.userConnList.isEmpty()) {
                        boolean b4 = false;
                        for (final OraclePooledConnection oraclePooledConnection : oracleConnectionCacheEntry.userConnList) {
                            if (b) {
                                b4 = this.markDownConnectionsForServiceEvent(s, s2, oraclePooledConnection);
                            }
                            else if (b2) {
                                b4 = this.markDownConnectionsForHostEvent(s3, oraclePooledConnection);
                            }
                            if (b4 && b3) {
                                ++this.defaultUserPreFailureSize;
                            }
                        }
                    }
                    if (oracleConnectionCacheEntry != null && oracleConnectionCacheEntry.attrConnMap != null && !oracleConnectionCacheEntry.attrConnMap.isEmpty()) {
                        final Iterator<Map.Entry<K, Vector>> iterator3 = oracleConnectionCacheEntry.attrConnMap.entrySet().iterator();
                        while (iterator3.hasNext()) {
                            for (final OraclePooledConnection oraclePooledConnection2 : iterator3.next().getValue()) {
                                if (b) {
                                    this.markDownConnectionsForServiceEvent(s, s2, oraclePooledConnection2);
                                }
                                else {
                                    if (!b2) {
                                        continue;
                                    }
                                    this.markDownConnectionsForHostEvent(s3, oraclePooledConnection2);
                                }
                            }
                        }
                    }
                }
            }
            if (s == null) {
                this.isEntireServiceDownProcessed = true;
            }
        }
    }
    
    private boolean markDownConnectionsForServiceEvent(final String s, final String s2, final OraclePooledConnection oraclePooledConnection) {
        boolean b = false;
        if (s == null || (s2 == oraclePooledConnection.dataSourceDbUniqNameKey && s == oraclePooledConnection.dataSourceInstanceNameKey)) {
            oraclePooledConnection.connectionMarkedDown = true;
            b = true;
        }
        return b;
    }
    
    private boolean markDownConnectionsForHostEvent(final String s, final OraclePooledConnection oraclePooledConnection) {
        boolean b = false;
        if (s == oraclePooledConnection.dataSourceHostNameKey) {
            oraclePooledConnection.connectionMarkedDown = true;
            oraclePooledConnection.needToAbort = true;
            b = true;
        }
        return b;
    }
    
    synchronized void cleanupFailoverConnections(final boolean b, final boolean b2, final String s, final String s2, final String s3, final String s4) {
        final Object[] array = this.checkedOutConnectionList.toArray();
        final int size = this.checkedOutConnectionList.size();
        final OraclePooledConnection[] array2 = new OraclePooledConnection[size];
        int n = 0;
        for (int i = 0; i < size; ++i) {
            try {
                final OraclePooledConnection obj = (OraclePooledConnection)array[i];
                if ((b && (s == null || s == obj.dataSourceInstanceNameKey) && s2 == obj.dataSourceDbUniqNameKey) || (b2 && s3 == obj.dataSourceHostNameKey)) {
                    if (obj.isSameUser(this.defaultUser, this.defaultPassword) && obj.cachedConnectionAttributes != null && obj.cachedConnectionAttributes.isEmpty()) {
                        ++this.defaultUserPreFailureSize;
                    }
                    this.checkedOutConnectionList.removeElement(obj);
                    this.abortConnection(obj);
                    obj.needToAbort = true;
                    array2[n++] = obj;
                }
            }
            catch (Exception ex) {}
        }
        for (int j = 0; j < n; ++j) {
            try {
                this.closeCheckedOutConnection(array2[j], false);
            }
            catch (SQLException ex2) {}
        }
        if (this.checkedOutConnectionList.size() < size && this.cacheConnectionWaitTimeout > 0) {
            this.notifyAll();
        }
        try {
            this.doForEveryCachedConnection(2);
        }
        catch (SQLException ex3) {}
        final int size2;
        if (this.databaseInstancesList != null && (size2 = this.databaseInstancesList.size()) > 0) {
            synchronized (this.databaseInstancesList) {
                final Object[] array3 = this.databaseInstancesList.toArray();
                for (int k = 0; k < size2; ++k) {
                    final OracleDatabaseInstance o = (OracleDatabaseInstance)array3[k];
                    if (o.databaseUniqName == s2 && o.instanceName == s) {
                        if (o.flag <= 3) {
                            this.dbInstancePercentTotal -= o.percent;
                        }
                        this.databaseInstancesList.remove(o);
                    }
                }
            }
        }
    }
    
    void zapRLBInfo() {
        this.databaseInstancesList.clear();
    }
    
    protected synchronized void closeAndRemovePooledConnection(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        if (oraclePooledConnection != null) {
            if (oraclePooledConnection.needToAbort) {
                this.abortConnection(oraclePooledConnection);
            }
            this.actualPooledConnectionClose(oraclePooledConnection);
            this.removeCacheConnection(oraclePooledConnection);
        }
    }
    
    private void abortConnection(final OraclePooledConnection oraclePooledConnection) {
        try {
            ((OracleConnection)oraclePooledConnection.getPhysicalHandle()).abort();
        }
        catch (Exception ex) {}
    }
    
    private void actualPooledConnectionClose(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        final int size;
        if (this.databaseInstancesList != null && (size = this.databaseInstancesList.size()) > 0) {
            synchronized (this.databaseInstancesList) {
                int i = 0;
                while (i < size) {
                    final OracleDatabaseInstance oracleDatabaseInstance = this.databaseInstancesList.get(i);
                    if (oracleDatabaseInstance.databaseUniqName == oraclePooledConnection.dataSourceDbUniqNameKey && oracleDatabaseInstance.instanceName == oraclePooledConnection.dataSourceInstanceNameKey) {
                        if (oracleDatabaseInstance.numberOfConnectionsCount > 0) {
                            final OracleDatabaseInstance oracleDatabaseInstance2 = oracleDatabaseInstance;
                            --oracleDatabaseInstance2.numberOfConnectionsCount;
                            break;
                        }
                        break;
                    }
                    else {
                        ++i;
                    }
                }
            }
        }
        try {
            ++this.connectionClosedCount;
            oraclePooledConnection.close();
        }
        catch (SQLException ex) {}
    }
    
    protected int getCacheTimeToLiveTimeout() {
        return this.cacheTimeToLiveTimeout;
    }
    
    protected int getCacheInactivityTimeout() {
        return this.cacheInactivityTimeout;
    }
    
    protected int getCachePropertyCheckInterval() {
        return this.cachePropertyCheckInterval;
    }
    
    protected int getCacheAbandonedTimeout() {
        return this.cacheAbandonedConnectionTimeout;
    }
    
    private synchronized void processConnectionCacheCallback() throws SQLException {
        final int n = (int)(this.cacheLowerThresholdLimit * (this.cacheMaxLimit / 100.0f));
        this.releaseBasedOnPriority(1024, n);
        if (this.cacheSize < n) {
            this.releaseBasedOnPriority(512, n);
        }
    }
    
    private void releaseBasedOnPriority(final int n, final int n2) throws SQLException {
        final Object[] array = this.checkedOutConnectionList.toArray();
        for (int n3 = 0; n3 < array.length && this.cacheSize < n2; ++n3) {
            final OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)array[n3];
            OracleConnection oracleConnection = null;
            if (oraclePooledConnection != null) {
                oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
            }
            if (oracleConnection != null) {
                final OracleConnectionCacheCallback connectionCacheCallbackObj = oracleConnection.getConnectionCacheCallbackObj();
                if (connectionCacheCallbackObj != null && (oracleConnection.getConnectionCacheCallbackFlag() == 2 || oracleConnection.getConnectionCacheCallbackFlag() == 4) && n == oracleConnection.getConnectionReleasePriority()) {
                    connectionCacheCallbackObj.releaseConnection(oracleConnection, oracleConnection.getConnectionCacheCallbackPrivObj());
                }
            }
        }
    }
    
    private synchronized void processConnectionWaitTimeout(final long n) throws SQLException {
        try {
            this.wait(n);
        }
        catch (InterruptedException ex) {}
    }
    
    private void processInactivityTimeout(final OraclePooledConnection oraclePooledConnection) throws SQLException {
        final long lastAccessedTime = oraclePooledConnection.getLastAccessedTime();
        final long currentTimeMillis = System.currentTimeMillis();
        if (this.getTotalCachedConnections() > this.cacheMinLimit && currentTimeMillis - lastAccessedTime > this.cacheInactivityTimeout * 1000) {
            this.closeAndRemovePooledConnection(oraclePooledConnection);
        }
    }
    
    private void cleanupTimeoutThread() throws SQLException {
        if (this.timeoutThread != null) {
            this.timeoutThread.timeToLive = false;
            if (this.timeoutThread.isSleeping) {
                this.timeoutThread.interrupt();
            }
            this.timeoutThread = null;
        }
    }
    
    protected void purgeCacheConnections(final boolean b, final int n) {
        try {
            if (b) {
                this.doForEveryCheckedOutConnection(n);
            }
            this.doForEveryCachedConnection(n);
        }
        catch (SQLException ex) {}
    }
    
    protected void updateDatabaseInstance(final String s, final String s2, final int n, final int n2) {
        if (this.databaseInstancesList == null) {
            this.databaseInstancesList = new LinkedList();
        }
        synchronized (this.databaseInstancesList) {
            final int size = this.databaseInstancesList.size();
            boolean b = false;
            for (int i = 0; i < size; ++i) {
                final OracleDatabaseInstance oracleDatabaseInstance = this.databaseInstancesList.get(i);
                if (oracleDatabaseInstance.databaseUniqName == s && oracleDatabaseInstance.instanceName == s2) {
                    oracleDatabaseInstance.percent = n;
                    oracleDatabaseInstance.flag = n2;
                    b = true;
                    break;
                }
            }
            if (!b) {
                final OracleDatabaseInstance e = new OracleDatabaseInstance(s, s2);
                e.percent = n;
                e.flag = n2;
                this.databaseInstancesList.add(e);
            }
        }
    }
    
    protected void processDatabaseInstances() throws SQLException {
        if (this.databaseInstancesList != null) {
            synchronized (this.databaseInstancesList) {
                int dbInstancePercentTotal = 0;
                boolean b = false;
                this.useGoodGroup = false;
                final int size = this.databaseInstancesList.size();
                for (int i = 0; i < size; ++i) {
                    final OracleDatabaseInstance oracleDatabaseInstance = this.databaseInstancesList.get(i);
                    if (oracleDatabaseInstance.flag <= 3) {
                        dbInstancePercentTotal += oracleDatabaseInstance.percent;
                    }
                }
                if (dbInstancePercentTotal > 0) {
                    this.dbInstancePercentTotal = dbInstancePercentTotal;
                    this.useGoodGroup = true;
                }
                if (size > 1) {
                    for (int j = 0; j < size; ++j) {
                        this.countTotal += ((OracleDatabaseInstance)this.databaseInstancesList.get(j)).attemptedConnRequestCount;
                    }
                    if (this.countTotal > size * 1000) {
                        for (int k = 0; k < size; ++k) {
                            final OracleDatabaseInstance obj = this.databaseInstancesList.get(k);
                            if (obj.numberOfConnectionsCount / (float)this.getTotalCachedConnections() > obj.attemptedConnRequestCount / (float)this.countTotal * 2.0f) {
                                if ((int)(obj.numberOfConnectionsCount * 0.25) >= 1) {
                                    this.instancesToRetireQueue.addElement(obj);
                                }
                                b = true;
                            }
                        }
                        if (b) {
                            for (int l = 0; l < size; ++l) {
                                ((OracleDatabaseInstance)this.databaseInstancesList.get(l)).attemptedConnRequestCount = 0;
                            }
                        }
                    }
                }
            }
            if (this.instancesToRetireQueue.size() > 0) {
                if (this.gravitateCacheThread != null) {
                    try {
                        this.gravitateCacheThread.interrupt();
                        this.gravitateCacheThread.join();
                    }
                    catch (InterruptedException ex) {}
                    this.gravitateCacheThread = null;
                }
                this.gravitateCacheThread = new OracleGravitateConnectionCacheThread(this);
                this.cacheManager.checkAndStartThread(this.gravitateCacheThread);
            }
        }
    }
    
    protected void gravitateCache() {
        while (this.instancesToRetireQueue.size() > 0) {
            this.instanceToRetire = this.instancesToRetireQueue.remove(0);
            this.retireConnectionsCount = (int)(this.instanceToRetire.numberOfConnectionsCount * 0.25);
            try {
                this.doForEveryCachedConnection(24);
            }
            catch (SQLException ex) {}
            if (this.retireConnectionsCount > 0) {
                try {
                    this.doForEveryCheckedOutConnection(24);
                }
                catch (SQLException ex2) {}
            }
        }
        this.retireConnectionsCount = 0;
        this.instanceToRetire = null;
        this.countTotal = 0;
    }
    
    protected void cleanupRLBThreads() {
        if (this.gravitateCacheThread != null) {
            try {
                this.gravitateCacheThread.interrupt();
                this.gravitateCacheThread.join();
            }
            catch (InterruptedException ex) {}
            this.gravitateCacheThread = null;
        }
        if (this.runtimeLoadBalancingThread != null) {
            try {
                this.runtimeLoadBalancingThread.interrupt();
            }
            catch (Exception ex2) {}
            this.runtimeLoadBalancingThread = null;
        }
    }
    
    Map getStatistics() throws SQLException {
        final HashMap<String, Integer> hashMap = new HashMap<String, Integer>(2);
        hashMap.put("PhysicalConnectionClosedCount", new Integer(this.connectionClosedCount));
        hashMap.put("PhysicalConnectionCreatedCount", new Integer(this.connectionCreatedCount));
        return hashMap;
    }
    
    protected OracleConnection getConnectionDuringExceptionHandling() {
        return null;
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
