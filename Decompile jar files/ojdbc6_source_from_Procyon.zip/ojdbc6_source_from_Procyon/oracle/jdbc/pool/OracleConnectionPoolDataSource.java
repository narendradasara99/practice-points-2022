// 
// Decompiled by Procyon v0.5.36
// 

package oracle.jdbc.pool;

import java.sql.Connection;
import oracle.jdbc.internal.OracleConnection;
import java.util.Properties;
import javax.sql.PooledConnection;
import java.sql.SQLException;
import javax.sql.ConnectionPoolDataSource;

public class OracleConnectionPoolDataSource extends OracleDataSource implements ConnectionPoolDataSource
{
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_;
    public static final String BUILD_DATE = "Thu_Aug_26_18:10:24_PDT_2010";
    public static final boolean TRACE = false;
    
    public OracleConnectionPoolDataSource() throws SQLException {
        this.dataSourceName = "OracleConnectionPoolDataSource";
        this.isOracleDataSource = false;
        this.connCachingEnabled = false;
        this.fastConnFailover = false;
    }
    
    @Override
    public PooledConnection getPooledConnection() throws SQLException {
        String user = null;
        String password = null;
        synchronized (this) {
            user = this.user;
            password = this.password;
        }
        return this.getPooledConnection(user, password);
    }
    
    @Override
    public PooledConnection getPooledConnection(final String s, String password) throws SQLException {
        final OraclePooledConnection oraclePooledConnection = new OraclePooledConnection(this.getPhysicalConnection(this.url, s, password));
        if (password == null) {
            password = this.password;
        }
        oraclePooledConnection.setUserName(s.startsWith("\"") ? s : s.toLowerCase(), password);
        return oraclePooledConnection;
    }
    
    PooledConnection getPooledConnection(final Properties properties) throws SQLException {
        final Connection physicalConnection = this.getPhysicalConnection(properties);
        final OraclePooledConnection oraclePooledConnection = new OraclePooledConnection(physicalConnection);
        String s = properties.getProperty("user");
        if (s == null) {
            s = ((OracleConnection)physicalConnection).getUserName();
        }
        String s2 = properties.getProperty("password");
        if (s2 == null) {
            s2 = this.password;
        }
        oraclePooledConnection.setUserName(s.startsWith("\"") ? s : s.toLowerCase(), s2);
        return oraclePooledConnection;
    }
    
    protected Connection getPhysicalConnection() throws SQLException {
        return super.getConnection(this.user, this.password);
    }
    
    protected Connection getPhysicalConnection(final String url, final String s, final String s2) throws SQLException {
        this.url = url;
        return super.getConnection(s, s2);
    }
    
    protected Connection getPhysicalConnection(final String s, final String s2) throws SQLException {
        return super.getConnection(s, s2);
    }
    
    static {
        _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    }
}
