// 
// Decompiled by Procyon v0.5.36
// 

package oracle.security.o5logon;

import java.io.IOException;

public final class a extends IOException
{
    private int a;
    
    public a(final int a) {
        this.a = a;
    }
    
    @Override
    public final String getMessage() {
        return Integer.toString(this.a);
    }
}
