// 
// Decompiled by Procyon v0.5.36
// 

package oracle.security.o5logon;

import java.security.SecureRandom;
import oracle.security.o3logon.O3LoginProtocolHelper;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import java.security.MessageDigest;

public class O5LoginClientHelper
{
    public static byte[] concatKeys(final int n, final byte[] array, final int n2, final byte[] array2, final int n3) throws Exception {
        final MessageDigest instance = MessageDigest.getInstance("MD5");
        byte[] digest = null;
        switch (n) {
            case 2361: {
                final byte[] input = new byte[16];
                for (int i = 0; i < 16; ++i) {
                    input[i] = (byte)(array[i + n2] ^ array2[i + n3]);
                }
                instance.reset();
                digest = instance.digest(input);
                break;
            }
            case 6949: {
                final byte[] array3 = new byte[24];
                for (int j = 0; j < 24; ++j) {
                    array3[j] = (byte)(array[j + n2] ^ array2[j + n3]);
                }
                final byte[] array4 = new byte[24];
                instance.reset();
                instance.update(array3, 0, 16);
                System.arraycopy(instance.digest(), 0, array4, 0, 16);
                instance.reset();
                instance.update(array3, 16, 8);
                System.arraycopy(instance.digest(), 0, array4, 16, 8);
                return array4;
            }
            default: {
                digest = new byte[0];
                break;
            }
        }
        return digest;
    }
    
    public static byte[] decryptAES(final String transformation, final byte[] key, final String s) throws Exception {
        if (key == null) {
            return new byte[0];
        }
        final byte[] iv = new byte[16];
        for (int i = 0; i < iv.length; ++i) {
            iv[0] = 0;
        }
        byte[] array = new byte[0];
        byte[] array2;
        if (key.length == 16) {
            final Cipher instance;
            (instance = Cipher.getInstance(transformation)).init(2, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
            array2 = instance.doFinal(toBinArray(s));
        }
        else {
            if (key.length != 24 || !transformation.endsWith("PKCS5Padding")) {
                return array;
            }
            final b b;
            (b = new b(1, 2, 2)).a(key);
            array2 = b.b(toBinArray(s));
        }
        array = array2;
        return array;
    }
    
    public static byte[] encryptAES(final String transformation, final byte[] key, final byte[] input) throws Exception {
        if (key == null) {
            return new byte[0];
        }
        final byte[] iv = new byte[16];
        for (int i = 0; i < iv.length; ++i) {
            iv[0] = 0;
        }
        byte[] array = new byte[0];
        byte[] array2;
        if (key.length == 16) {
            final Cipher instance;
            (instance = Cipher.getInstance(transformation)).init(1, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
            array2 = instance.doFinal(input);
        }
        else {
            if (key.length != 24 || !transformation.endsWith("PKCS5Padding")) {
                return array;
            }
            final b b;
            (b = new b(1, 2, 2)).a(key);
            array2 = b.c(input);
        }
        array = array2;
        return array;
    }
    
    public static byte nibbleToHex(final byte b) {
        final byte b2;
        int n;
        int n2;
        if ((b2 = (byte)(b & 0xF)) < 10) {
            n = b2;
            n2 = 48;
        }
        else {
            n = b2 - 10;
            n2 = 65;
        }
        return (byte)(n + n2);
    }
    
    public static void bArray2Nibbles(final byte[] array, final byte[] array2) {
        for (int i = 0; i < array.length; ++i) {
            array2[i * 2] = nibbleToHex((byte)((array[i] & 0xF0) >> 4));
            array2[i * 2 + 1] = nibbleToHex((byte)(array[i] & 0xF));
        }
    }
    
    public static byte[] toBinArray(final String s) {
        final byte[] array = new byte[s.length() / 2];
        for (int i = 0; i < s.length() / 2; ++i) {
            array[i] = (byte)(Byte.parseByte(s.substring(2 * i + 1, 2 * i + 2), 16) | Byte.parseByte(s.substring(2 * i, 2 * i + 1), 16) << 4);
        }
        return array;
    }
    
    public static boolean generateOAuthResponse(final int n, final byte[] array, final String s, final String s2, final byte[] array2, final byte[] array3, final byte[] array4) {
        return generateOAuthResponse(n, array, s, s2, s2.getBytes(), array2, array3, array4, true);
    }
    
    public static boolean generateOAuthResponse(final int n, final byte[] array, final String s, final String s2, final byte[] array2, final byte[] array3, final byte[] array4, final byte[] array5) {
        return generateOAuthResponse(n, array, s, s2, array2, array3, array4, array5, true);
    }
    
    public static boolean generateOAuthResponse(final int n, final byte[] bytes, final String s, final String s2, final byte[] array, final byte[] bytes2, final byte[] array2, final byte[] array3, final boolean b) {
        boolean b2 = true;
        try {
            int n2;
            int n3;
            int n4;
            String s3;
            String s4;
            String s5;
            byte[] array4;
            if (n == 2361) {
                n2 = 16;
                n3 = 32;
                n4 = 64;
                s3 = "AES/CBC/NoPadding";
                s4 = "AES/CBC/NoPadding";
                s5 = "AES/CBC/PKCS5Padding";
                final byte[] verifier = new O3LoginProtocolHelper().getVerifier(s, s2, b);
                array4 = new byte[16];
                System.arraycopy(verifier, 0, array4, 0, 8);
                for (int i = 8; i < 16; ++i) {
                    array4[i] = 0;
                }
            }
            else {
                if (n != 6949) {
                    return false;
                }
                n2 = 24;
                n3 = 40;
                n4 = 96;
                s3 = "AES/CBC/PKCS5Padding";
                s4 = "AES/CBC/PKCS5Padding";
                s5 = "AES/CBC/PKCS5Padding";
                final MessageDigest instance;
                (instance = MessageDigest.getInstance("SHA1")).update(s2.getBytes("UTF-8"));
                instance.update(toBinArray(new String(bytes)));
                final byte[] digest = instance.digest();
                array4 = new byte[24];
                for (int j = 0; j < array4.length; ++j) {
                    array4[j] = 0;
                }
                System.arraycopy(digest, 0, array4, 0, digest.length);
            }
            final byte[] decryptAES = decryptAES(s3, array4, new String(bytes2));
            final SecureRandom instance2 = SecureRandom.getInstance("SHA1PRNG");
            final byte[] bytes3 = new byte[n3];
            instance2.nextBytes(bytes3);
            final byte[] encryptAES = encryptAES(s4, array4, bytes3);
            if (array2 == null || array2.length != n4) {
                return false;
            }
            bArray2Nibbles(encryptAES, array2);
            final byte[] concatKeys;
            if ((concatKeys = concatKeys(n, decryptAES, decryptAES.length - n2, bytes3, bytes3.length - n2)).length != n2) {
                return false;
            }
            final byte[] bytes4 = new byte[16];
            instance2.nextBytes(bytes4);
            final byte[] array5 = new byte[16 + array.length];
            System.arraycopy(bytes4, 0, array5, 0, 16);
            System.arraycopy(array, 0, array5, 16, array.length);
            if (array3 == null) {
                return false;
            }
            bArray2Nibbles(encryptAES(s5, concatKeys, array5), array3);
        }
        catch (Exception ex) {
            b2 = false;
        }
        return b2;
    }
}
