// 
// Decompiled by Procyon v0.5.36
// 

package oracle.security.o3logon;

public final class O3LoginClientHelper
{
    private b a;
    private boolean b;
    
    public O3LoginClientHelper() {
        this.b = true;
        this.a = new b();
    }
    
    public O3LoginClientHelper(final boolean b) {
        this.b = b;
        this.a = new b();
    }
    
    public final byte[] getSessionKey(final String s, final String s2, final byte[] array) {
        return oracle.security.o3logon.b.a(this.a.a(s, s2, this.b), array);
    }
    
    public final byte[] getEPasswd(final byte[] array, final byte[] array2) {
        return oracle.security.o3logon.b.b(array, array2);
    }
}
