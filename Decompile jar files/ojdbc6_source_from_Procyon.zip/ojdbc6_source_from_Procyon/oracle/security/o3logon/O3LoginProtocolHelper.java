// 
// Decompiled by Procyon v0.5.36
// 

package oracle.security.o3logon;

import java.security.SecureRandom;

public final class O3LoginProtocolHelper
{
    private final byte[] a;
    private final byte[] b;
    private static long c;
    private static int d;
    private static b e;
    
    public O3LoginProtocolHelper() {
        this.b = new byte[8];
        this.a = null;
    }
    
    public O3LoginProtocolHelper(final byte[] a) {
        this.b = new byte[8];
        this.a = a;
    }
    
    public final byte[] getVerifier(final String s, final String s2) {
        return this.getVerifier(s, s2, true);
    }
    
    public final byte[] getVerifier(final String s, final String s2, final Boolean b) {
        if (O3LoginProtocolHelper.e == null) {
            O3LoginProtocolHelper.e = new b();
        }
        return O3LoginProtocolHelper.e.a(s, s2, b);
    }
    
    public final boolean authenticate(final String s, final String s2) {
        try {
            Thread.sleep(O3LoginProtocolHelper.d * 1000);
        }
        catch (InterruptedException ex) {}
        if (O3LoginProtocolHelper.e == null) {
            O3LoginProtocolHelper.e = new b();
        }
        final byte[] a = O3LoginProtocolHelper.e.a(s, s2);
        if (this.a.length != a.length) {
            ++O3LoginProtocolHelper.d;
            return false;
        }
        for (int i = 0; i < a.length; ++i) {
            if (a[i] != this.a[i]) {
                ++O3LoginProtocolHelper.d;
                return false;
            }
        }
        return true;
    }
    
    public final byte[] getChallenge(final byte[] seed) {
        final SecureRandom secureRandom = new SecureRandom(seed);
        secureRandom.setSeed(O3LoginProtocolHelper.c += System.currentTimeMillis());
        secureRandom.setSeed(this.a);
        secureRandom.nextBytes(this.b);
        return new a().a(this.a, this.b);
    }
    
    public final String getPassword(final byte[] array) {
        final a a = new a();
        final byte b = array[array.length - 1];
        final byte[] array2 = new byte[array.length - 1];
        System.arraycopy(array, 0, array2, 0, array2.length);
        byte[] b2;
        try {
            b2 = a.b(this.b, array2);
        }
        catch (Exception ex) {
            return null;
        }
        final byte[] bytes = new byte[b2.length - b];
        System.arraycopy(b2, 0, bytes, 0, bytes.length);
        return new String(bytes).toUpperCase();
    }
    
    public static byte[] getResponse(final String s, final String s2, final byte[] array) {
        if (O3LoginProtocolHelper.e == null) {
            O3LoginProtocolHelper.e = new b();
        }
        final a a;
        final byte[] b = (a = new a()).b(O3LoginProtocolHelper.e.a(s, s2), array);
        final byte[] bytes;
        final byte b2 = (byte)(((bytes = s2.getBytes()).length % 8 > 0) ? ((byte)(8 - bytes.length % 8)) : 0);
        final byte[] array2 = new byte[bytes.length + b2];
        System.arraycopy(bytes, 0, array2, 0, bytes.length);
        final byte[] a2;
        final byte[] array3 = new byte[(a2 = a.a(b, array2)).length + 1];
        System.arraycopy(a2, 0, array3, 0, a2.length);
        array3[array3.length - 1] = b2;
        return array3;
    }
    
    static {
        O3LoginProtocolHelper.c = System.currentTimeMillis();
        O3LoginProtocolHelper.d = 0;
    }
}
